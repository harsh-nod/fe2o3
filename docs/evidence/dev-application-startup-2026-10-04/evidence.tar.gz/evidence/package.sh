#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-application-startup-20261004-jtNBYVcv
out="$scratch/evidence"
destination="$repo/docs/evidence/dev-application-startup-2026-10-04"
mkdir "$out"
cp "$scratch/qualify.sh" "$scratch/final-audit.sh" "$scratch/baseline.cjs" "$scratch/package.sh" "$out/"
cp "$scratch/"*.log "$scratch/"*.txt "$scratch/"*.sha256 "$scratch/baseline.json" "$out/"
cd "$repo"
git rev-parse HEAD > "$out/source-commit.txt"
git show --format=fuller --binary HEAD > "$out/source.patch"
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers verify-commit HEAD > "$out/signature.log" 2>&1
sha256sum -c "$scratch/sources.sha256" > "$out/source-package-recheck.log"
sha256sum -c "$scratch/binaries.sha256" > "$out/binary-package-recheck.log"
cd "$out"
find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c SHA256SUMS
tar -czf "$destination/evidence.tar.gz" -C "$scratch" evidence
tar -dzf "$destination/evidence.tar.gz" -C "$scratch"
sha256sum "$destination/evidence.tar.gz" "$out/source.patch"
