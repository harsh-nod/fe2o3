#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-application-startup-20261004-jtNBYVcv
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=4
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
export TMPDIR="$scratch/test-tmp"
if cargo test -p cargo-fe2o3 --bin cargo-fe2o3 -- --test-threads=4 > "$scratch/unit-final.log" 2>&1; then
    printf '0\n' > "$scratch/unit-final-status.txt"
else
    printf '%s\n' "$?" > "$scratch/unit-final-status.txt"
fi
node "$scratch/baseline.cjs" > "$scratch/baseline.json"
sha256sum -c "$scratch/sources.sha256" > "$scratch/source-final-recheck.log"
sha256sum target/debug/deps/cargo_fe2o3-2c6ec74a439c2830 target/debug/deps/worker_v3_load_envelope_vertical-b4774b8da24b8b16 target/debug/cargo-fe2o3 /dev/shm/fe2o3-application-static-20261004-my05Znpc/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-worker-v3-host-consumer-app-fixture /dev/shm/fe2o3-application-static-20261004-my05Znpc/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-runner-app-fixture /dev/shm/fe2o3-application-static-20261004-my05Znpc/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-runner-chain-fixture > "$scratch/binaries.sha256"
printf 'Final source and baseline audit recorded; full unit result:\n'
tail -n 8 "$scratch/unit-final.log"
