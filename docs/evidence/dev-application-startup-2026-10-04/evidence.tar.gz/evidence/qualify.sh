#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-application-startup-20261004-jtNBYVcv
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=4
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
export FE2O3_V3_STATIC_FIXTURE_TARGET_DIR=/dev/shm/fe2o3-application-static-20261004-my05Znpc
export FE2O3_TEST_HSACO_WORKER_FIXTURE="$repo/target/debug/fe2o3-worker-v3-hsaco-fixture"
unset CARGO_ENCODED_RUSTFLAGS
mkdir -p "$scratch/test-tmp"
export TMPDIR="$scratch/test-tmp"
sha256sum crates/cargo-fe2o3/src/application_handoff.rs crates/cargo-fe2o3/src/application_handoff/startup_tests.rs crates/cargo-fe2o3/src/application_sandbox.rs crates/cargo-fe2o3/src/main.rs > "$scratch/sources.sha256"
rustc -vV > "$scratch/rustc-version.txt"
cargo -vV > "$scratch/cargo-version.txt"
git rev-parse HEAD > "$scratch/base-commit.txt"
cargo test -p cargo-fe2o3 --bin cargo-fe2o3 application_handoff:: -- --test-threads=4 > "$scratch/handoff.log" 2>&1
cargo test -p cargo-fe2o3 --bin cargo-fe2o3 application_sandbox:: -- --test-threads=4 > "$scratch/sandbox.log" 2>&1
printf 'Cargo handoff and sandbox unit tests passed\n'
cargo clippy -p cargo-fe2o3 --all-targets --no-deps -- -D warnings > "$scratch/clippy.log" 2>&1
printf 'Cargo all-target Clippy passed\n'
cargo test -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical strict_v3 -- --test-threads=1 > "$scratch/vertical.log" 2>&1
printf 'Strict V3 static vertical tests passed\n'
rustfmt --edition 2024 --config skip_children=true --check crates/cargo-fe2o3/src/application_handoff.rs crates/cargo-fe2o3/src/application_handoff/startup_tests.rs crates/cargo-fe2o3/src/application_sandbox.rs crates/cargo-fe2o3/src/main.rs > "$scratch/format.log" 2>&1
git diff --check > "$scratch/whitespace.log"
sha256sum -c "$scratch/sources.sha256" > "$scratch/source-recheck.log"
printf 'Frozen sources, formatting and whitespace passed\n'
