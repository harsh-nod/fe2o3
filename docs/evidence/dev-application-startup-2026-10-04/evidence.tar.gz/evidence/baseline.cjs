const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const childProcess = require('node:child_process');
const assert = require('node:assert/strict');
const repo = '/home/harsh/.codex-tmp/fe2o3-r61-execution';
const base = '0b896d9255a3989a44af470a7d829a3d3d6cbe20';
const macroRoot = 'crates/fe2o3-macros';
const pinSource = 'crates/cargo-fe2o3/src/authorized_kernel_closure.rs';
const git = (...args) => childProcess.execFileSync('git', args, { cwd: repo });
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function digest(entries) {
  // All recorded relative names are ASCII; use bytewise order like Rust String::cmp.
  entries.sort((a, b) => Buffer.compare(Buffer.from(a[0]), Buffer.from(b[0])));
  const hash = crypto.createHash('sha256').update('fe2o3-canonical-source-tree-v1\0');
  for (const [name, bytes] of entries) hash.update(`${sha(bytes)}  ${name}\n`);
  return hash.digest('hex');
}
function committed(commit) {
  const names = git('ls-tree', '-r', '-z', '--name-only', commit, '--', macroRoot)
    .toString().split('\0').filter(Boolean);
  return digest(names.map(name => [name.slice(macroRoot.length + 1), git('show', `${commit}:${name}`)]));
}
const entries = [];
function walk(directory, relative = '') {
  for (const name of fs.readdirSync(directory)) {
    const file = path.join(directory, name);
    const key = relative ? `${relative}/${name}` : name;
    const stat = fs.lstatSync(file);
    assert(!stat.isSymbolicLink());
    if (stat.isDirectory()) walk(file, key);
    else {
      assert(stat.isFile());
      entries.push([key, fs.readFileSync(file)]);
    }
  }
}
walk(path.join(repo, macroRoot));
const pinned = git('show', `${base}:${pinSource}`).toString()
  .match(/const TRUSTED_FE2O3_MACROS_TREE: &str\s*=\s*"([a-f0-9]{64})"/)[1];
const current = digest(entries);
const baseline = committed(base);
const pinCommit = '3494de45f';
const atPinCommit = committed(pinCommit);
assert.equal(current, baseline);
assert.equal(atPinCommit, pinned);
assert.notEqual(baseline, pinned);
git('diff', '--exit-code', base, '--', macroRoot, pinSource,
    'crates/fe2o3-semantic-import/src/profiler_bundle.rs');
console.log(JSON.stringify({ base, macroRoot, pinCommit, pinned, atPinCommit,
  baseline, current, unchangedFromBaseline: current === baseline,
  sourceChangesAfterPin: git('log', '--format=%H %s', `${pinCommit}..${base}`, '--', macroRoot)
    .toString().trim().split('\n') }, null, 2));
