# Epoch Reservation And Heap-Backed Template Qualification

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Branch: `codex/r65-runtime-drain-versions`.
Implementation source: `a773f33653527a21cb6be80881df6fbe6e012d5f`.
Final qualification source: `e9cd6fa17265345f3547e818675a59f1e7de280f`.

No MI300X/MI350 work, GPU work, or external model workers were used. Three native
agents reviewed production custody, tests and proof/checker boundaries read-only.
Primary owned edits, integration, builds, solvers, signing and publication.

## Signed Campaigns

Run serially from the repository:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-dispatch-epoch-reserve.py --output /home/harsh/.codex-tmp/fe2o3-epoch-reserve-20260928-kkeGKZ7Z/reserve-final-2 --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
python3 -I -B crates/fe2o3-runtime-model/verus/check-dispatch-epoch-cancel.py --output /home/harsh/.codex-tmp/fe2o3-epoch-reserve-20260928-kkeGKZ7Z/cancel-final --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
python3 -I -B /home/harsh/.codex-tmp/fe2o3-epoch-reserve-20260928-kkeGKZ7Z/qualify.py /home/harsh/.codex-tmp/fe2o3-r61-execution
python3 -I -B /home/harsh/.codex-tmp/fe2o3-epoch-reserve-20260928-kkeGKZ7Z/audit-final.py
```

Reproduction needs fresh output names/directories. Controllers require clean,
signed source and pin the verifier, inherited controller/classifier, relocation,
source hashes and owned process groups. Exact CPU commands and expected results
are in `qualify.py`; each executed command/environment has a process record.
CPU uses `nightly-2026-04-03`, two Cargo build jobs and no incremental artifacts;
core dumps are disabled. Stack regressions explicitly create 2 MiB threads.
The new reservation and cancellation campaigns use `--no-cheating`.
Existing completion preparation/rollback positive roots retain their disclosed
standard-library contracts; source failure remains no-cheating.

## Development Records

`dev-1` failed to compile a proof witness using Result::unwrap without Debug.
`dev-2` exposed missing quantifier instantiations; `dev-3` and `dev-4` passed
after proof-only assertions and an explicit exhausted-prefix witness.

`cpu-dev-1.log` records the original fixed-array stack overflow on an ordinary
test thread. No core was dumped. Production was changed to preserve boxed
templates through live submission and completion binding.
`cpu-dev-2.log` records a missed test trait signature caught by compilation.
`cpu-dev-3.log` records two incorrect test assertions: the snapshot counts
available slots, not occupied slots. Those expected values were corrected to 8192.
The test-only large-array map was also replaced by an iterator-collected Vec.
`clippy-dev.log` records the preliminary strict all-feature/all-target check.

The signed `reserve-final` campaign is intentionally retained as rejected.
Its truncation mutant had the intended postcondition failure plus a cast-range
recommendation. The strict classifier rejected the mixed result. The final
mutant expresses identical Rust truncation with modulo 65536, avoiding the
recommendation. No diagnostic acceptance rule was relaxed. The generic
reserve/cancel witness was renamed so the `*reserve` mutation selector cannot
also select that witness. The complete campaign was rerun at the final source.

The independent audit initially overcounted mutation manifests because the
`premature-mutation` result itself also matches `*-mutation.json`. The auditor
now derives manifest names from the exact failing-stage entries in `results.json`,
retaining the expected counts and full manifest, source and selector checks.
The corrected audit passes all 66 campaign stages, 17 CPU/static/positive-proof
stages and independent absence checks for all 108 recorded process groups.

## Boundaries

Host epoch behavior is formally refined. The resource-to-template producer is
CPU-tested, not completely source-refined. The large-template success fixture
duplicates genuine retained packet metadata; it does not prove maximum-size
public preparation reachability. The source-flow stack test uses CPU no-effect
receipts on both lanes; it does not publish or execute native packets.
Allocation abort/unwind, resource constructor provenance, mapping authentication,
SHA collision implications, native publication and outer terminalization remain
outside these claims. No HIP/HSA performance result is asserted.
