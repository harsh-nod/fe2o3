#!/usr/bin/env python3
"""Independent source/blob, mutation-byte, result and process-absence audit."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess

root = Path(__file__).resolve().parent
repo = Path("/home/harsh/.codex-tmp/fe2o3-r61-execution")
expected = {
    "reserve-final-2": (36, 23, 4, "crates/fe2o3-kfd/src/queue_dispatch_binding/epoch_reserve_body.rs"),
    "cancel-final": (30, 16, 2, "crates/fe2o3-kfd/src/queue_dispatch_binding/epoch_cancel_body.rs"),
}
reference = json.loads((root / "reserve-final-2/source-before.json").read_text())
assert reference["commit"] == "e9cd6fa17265345f3547e818675a59f1e7de280f"
assert len(reference["inputs"]) == 6248
report = dict(source_commit=reference["commit"], source_hashes=len(reference["inputs"]), campaigns={})
blobs = {}


def tree(directory):
    assert directory.is_dir() and not directory.is_symlink()
    result = {}
    for path in directory.rglob("*"):
        assert not path.is_symlink()
        if path.is_dir():
            continue
        assert path.is_file()
        result[path.relative_to(directory).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def canonical(manifest):
    for path, digest in manifest.items():
        relative = PurePosixPath(path)
        assert not relative.is_absolute() and ".." not in relative.parts and str(relative) == path
        assert len(digest) == 64 and all(ch in "0123456789abcdef" for ch in digest)


for name, (count, verified, file_count, body) in expected.items():
    directory = root / name
    results = json.loads((directory / "results.json").read_text())
    assert len(results) == count and all(row["passed"] is True for row in results.values())
    for side in ("before", "after"):
        assert json.loads((directory / ("source-" + side + ".json")).read_text()) == reference
    for stage in ("proof-before", "relocated-proof", "proof-after"):
        actual = json.loads((directory / stage / "stdout.log").read_text())["verification-results"]
        assert actual == {"encountered-error": False, "encountered-vir-error": False,
                          "success": True, "verified": verified, "errors": 0, "is-verifying-entire-crate": True}
        assert "--no-cheating" in json.loads((directory / stage / "record.json").read_text())["command"]
    source_command = json.loads((directory / "proof-before/record.json").read_text())["command"]
    proof_path = Path(source_command[-1]).relative_to(repo)
    recorded_output = Path(json.loads((directory / "environment.json").read_text())["TMPDIR"])
    manifest = json.loads((directory / "relocated-inputs.json").read_text())
    canonical(manifest)
    assert len(manifest) == file_count and tree(directory / "relocated-source") == manifest
    signed = json.loads((directory / "signed-inputs.json").read_text())
    assert signed.keys() == reference["inputs"].keys()
    for path, digest in manifest.items():
        assert digest == reference["inputs"][path] == signed[path]["sha256"]
        if path not in blobs:
            object_name = reference["commit"] + ":" + path
            data = subprocess.check_output(["/usr/bin/git", "--no-replace-objects", "cat-file", "blob", object_name], cwd=repo)
            blob = subprocess.check_output(["/usr/bin/git", "--no-replace-objects", "rev-parse", object_name], cwd=repo).decode().strip()
            blobs[path] = (hashlib.sha256(data).hexdigest(), blob)
        assert blobs[path] == (digest, signed[path]["git_blob"])
    assert json.loads((directory / "relocated-proof/record.json").read_text())["command"][-1] == str(recorded_output / "relocated-source" / proof_path)
    names = {name for name, row in results.items() if row["status"] == 1}
    assert len(names) == count - 8
    mutations = [directory / (name + "-mutation.json") for name in sorted(names)]
    assert {path.name for path in directory.glob("*-source")} == {"relocated-source"} | {n + "-source" for n in names}
    for path in mutations:
        mutation = json.loads(path.read_text())
        stage = path.name.removesuffix("-mutation.json")
        canonical(mutation["inputs"])
        assert mutation["inputs"].keys() == manifest.keys() and mutation["path"] == body
        assert {p for p in manifest if mutation["inputs"][p] != manifest[p]} == {body}
        assert tree(directory / (stage + "-source")) == mutation["inputs"]
        record = json.loads((directory / stage / "record.json").read_text())
        command = record["command"]
        assert record["status"] == 1 and command.count("--verify-function") == 1
        assert command[command.index("--verify-function") + 1] == mutation["selector"]
        assert command[-1] == str(recorded_output / (stage + "-source") / proof_path)
        assert "--no-cheating" in command
    report["campaigns"][name] = dict(stages=count, verified=verified, mutants=count - 8, audited_closure_files=file_count)

cpu = root / "cpu-final"
results = json.loads((cpu / "results.json").read_text())
assert len(results) == 17 and all(row["passed"] is True and row["status"] == 0 for row in results.values())
for side in ("before", "after"):
    assert json.loads((cpu / ("source-" + side + ".json")).read_text()) == reference
for name, row in results.items():
    if "expected" not in row:
        continue
    assert json.loads((cpu / name / "stdout.log").read_text())["verification-results"] == row["expected"]
    command = json.loads((cpu / name / "record.json").read_text())["command"]
    assert ("--no-cheating" in command) is row["no_cheating"]
    for path, digest in row["files"].items():
        assert digest == reference["inputs"][path]
report["cpu_and_positive_regressions"] = results
stopped = root / "reserve-final"
assert json.loads((stopped / "truncates-index.json").read_text()) == {"passed": False, "status": 1}
assert json.loads((stopped / "source-before.json").read_text())["commit"] == "a773f33653527a21cb6be80881df6fbe6e012d5f"
assert not (stopped / "results.json").exists()
assert len(list(stopped.rglob("record.json"))) == 25
report["rejected_campaign_groups"] = 25
records = sorted(root.rglob("record.json"))
assert len(records) == 108
groups = []
for path in records:
    record = json.loads(path.read_text())
    assert record["group_absent"] is True and "exception" not in record
    assert isinstance(record["status"], int) and record["finished_ns"] >= record["started_ns"]
    group = record["process_group"]
    try:
        os.killpg(group, 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError("owned process group still exists: " + str(group))
    groups.append(group)
assert len(groups) == len(set(groups))
report["independently_absent_process_groups"] = groups
with (root / "final-audit.json").open("x") as output:
    json.dump(report, output, indent=2, sort_keys=True)
    output.write("\n")
print("PASS: 66 campaign stages, 17 CPU/static/positive-regression stages, 108 absent groups")
