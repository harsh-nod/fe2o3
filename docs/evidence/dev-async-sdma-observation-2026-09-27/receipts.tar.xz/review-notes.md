# Read-only Swarm Review

Primary owns all edits, integration, tests and commits. Review agents performed
read-only source inspection without builds, GPU work, permission requests or
escalation. These are review notes, not independent execution/proof receipts.

Both reviewers recommended keeping exact async descriptors in active_sdma
through observation, instead of allocating during failure-path reinsertion or
using a single terminal descriptor slot that cannot represent nested ancestors.
Published owners move downward while their descriptors remain Quarantined;
Ready dependency ancestors remain indexed. Neither review found a remaining
healthy-path semantic blocker in the final observation/retirement structure.

The completion predicate checks local release prerequisites. Binary search uses
private monotone owner/stream indexes; it is not a whole-index arbitrary-memory-
corruption validator. Dependency admission may publish immediately after
checking Succeeded results without advancing its cursor. Requiring cursor ==
roster length would reject valid state, so that initial review suggestion was
withdrawn after tracing admission. Final preflight instead also checks retained
dependency results remain Succeeded.

Review-driven test additions exercise successful release with later same-stream
owners and adjacent duplicate stream/owner mutations. New failure snapshots
contain only IDs, metadata and addresses, not native owning handles. Child tests
explicitly drop the real unrepaired backend and require an inspection marker
followed by SIGABRT. Private preflight corruption is distinguished from public
admission and the existing scripted lower fault cases.

## Next Publication Boundary

Immediate public copy_async with a scripted Submit(ProcessTeardown) already
retains both buffers under terminal_sdma_custody -> Scripted -> Pair but loses
its admitted descriptor. Capture next_handle and the original pair IDs before
the call, then require descriptor/FIFO/tail/custody/reservation correspondence
and the real terminal Drop. This is not evidence of native-owner freeing.

For genuine flush coverage, admit A then B on the same stream/endpoints. Finish
and retire A through public poll, then flush B with Submit(ProcessTeardown).
B's cursor legitimately advances over A; its other metadata/backing addresses
must remain. Flushing while A is still published does not reach B. Ordinary
Retryable submit is a healthy restoration/refund control, not a terminal fault.

This patch does not fix publication detachment, unpublished Failed/Quiescent
cleanup detachment, global representation proofs, or every opaque native-owner
panic boundary. Scripted retirement roots its moved pair before panicking;
the tests do not establish that for every actual KFD operation.
