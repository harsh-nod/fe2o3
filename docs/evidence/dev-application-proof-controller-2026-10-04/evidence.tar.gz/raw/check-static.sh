#!/bin/bash
set -euo pipefail
readonly image=${1:?exact static binary}
file "$image"
readelf -hW "$image"
readelf -lW "$image"
readelf -dW "$image"
if readelf -lW "$image" | grep -Eq 'INTERP|DYNAMIC'; then exit 1; fi
if readelf -dW "$image" | grep -q NEEDED; then exit 1; fi
[[ -z $(nm -u "$image") ]]
entry=$(readelf -hW "$image" | awk '/Entry point address:/ {print $4}')
secure=$(nm -n "$image" | awk '$3=="fe2o3_secure_start_v1" {print "0x"$1}')
[[ -n $entry && -n $secure && $((entry)) == $((secure)) ]]
printf 'static secure entry verified: %s\n' "$entry"
sha256sum "$image"
