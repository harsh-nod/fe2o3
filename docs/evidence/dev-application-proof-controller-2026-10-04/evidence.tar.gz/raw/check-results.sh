#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-application-custodian-20261004-H51EUWMz
readonly root_cases=(poll-pair poll-cancel-proof poll-cancel-gated poll-drop-gated poll-deadline poll-proof-deadline poll-probe-timeout good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison)
readonly labels=(app-good app-payload app-duplicate-final app-stale-final "${root_cases[@]/%/-final}")
for label in "${labels[@]}"; do
    grep -q 'test result: ok. 1 passed; 0 failed; 0 ignored' "$scratch/$label.log"
    grep -q '^outer cgroup removed:' "$scratch/$label.log"
    grep -q '^PASS: no live task remains in pid:' "$scratch/$label-namespace.log"
    [[ -s "$scratch/$label/pid-namespace.txt" ]]
    printf 'PASS case and cleanup: %s\n' "$label"
done
[[ ${#labels[@]} == 22 ]]
for label in prepare-app prepare-final; do
    grep -q 'test result: ok. 1 passed; 0 failed; 0 ignored' "$scratch/$label.log"
    grep -q '^outer cgroup removed:' "$scratch/$label.log"
done
[[ -s "$scratch/app-good/subject.bin" ]]
grep -q 'original proof recomputed and retained' "$scratch/app-good/quarantine.txt"
grep -q 'helper group absent' "$scratch/app-good/cleanup.txt"
grep -q 'FinalizedLengthMismatch' "$scratch/app-payload/rejection.txt"
grep -q 'aliased application proof inputs' "$scratch/app-duplicate-final/rejection.txt"
grep -q 'application proof session mismatch' "$scratch/app-stale-final/rejection.txt"
grep -q '7 passed; 0 failed' "$scratch/multi-open.log"
grep -q '1 passed; 0 failed' "$scratch/generated-gate.log"
printf 'PASS all 22 root cases, two independent measurements, and focused multi-device tests\n'
