#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-application-custodian-20261004-H51EUWMz
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
git rev-parse HEAD > "$scratch/raw/source-commit.txt"
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$scratch/raw/allowed-signers" verify-commit HEAD > "$scratch/raw/source-signature.log" 2>&1
git show --format= --binary HEAD > "$scratch/raw/committed.patch"
cmp "$scratch/raw/committed.patch" "$scratch/raw/source.patch"
sha256sum -c "$scratch/raw/sources.sha256"
sha256sum -c "$scratch/raw/binaries.sha256"
git diff --check
git diff --cached --check
