#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-application-custodian-20261004-H51EUWMz
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly output="$repo/docs/evidence/dev-application-proof-controller-2026-10-04"
bash "$scratch/raw/check-results.sh"
mkdir -m 700 "$scratch/evidence"
mkdir "$scratch/evidence/raw" "$scratch/evidence/captures"
cp -R -- "$scratch/raw/." "$scratch/evidence/raw/"
for log in "$scratch/"*.log; do
    [[ $log == "$scratch/package.log" ]] && continue
    cp -- "$log" "$scratch/evidence/raw/"
done
cp -- "$scratch/deployment-v1" "$scratch/application-deployment-v1" "$scratch/evidence/raw/"
cp -R -- "$scratch/captures/inputs-2" "$scratch/evidence/captures/"
for capture in "$scratch/app-good" "$scratch/app-payload" "$scratch/"*-final; do
    [[ -d $capture && -s "$capture/pid-namespace.txt" ]] || continue
    cp -R -- "$capture" "$scratch/evidence/captures/"
done
cd "$scratch/evidence"
find raw captures -type f -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum -c MANIFEST.sha256
mkdir -p "$output"
tar -czf "$output/evidence.tar.gz" MANIFEST.sha256 raw captures
sha256sum "$output/evidence.tar.gz"
