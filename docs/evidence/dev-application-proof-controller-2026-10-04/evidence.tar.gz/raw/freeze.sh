#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-application-custodian-20261004-H51EUWMz
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
git rev-parse HEAD > "$scratch/raw/source-parent.txt"
git diff --cached --binary > "$scratch/raw/source.patch"
git diff --cached --name-only -z | xargs -0 sha256sum > "$scratch/raw/sources.sha256"
sha256sum target/debug/deps/fe2o3_proof_custodian-fad06578352827f8 \
    target/debug/deps/fe2o3_runtime-8b285d6a23c74f5c \
    target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-application-proof-controller \
    target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-conditional-fill-proof-controller \
    > "$scratch/raw/binaries.sha256"
sha256sum "$scratch/deployment-v1" "$scratch/application-deployment-v1" "$scratch/captures/inputs-2/"* \
    docs/evidence/dev-proof-custodian-reactor-2026-10-04/evidence.tar.gz > "$scratch/raw/inputs.sha256"
git diff --check
git diff --cached --check
