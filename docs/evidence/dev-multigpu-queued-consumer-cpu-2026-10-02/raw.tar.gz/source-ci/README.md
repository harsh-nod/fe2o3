# Source-control support scope

The current support.py reuses the five explicitly pinned reference files and
configures repository, baseline and output locations. Following proposal-01's
failure, it additionally reviews exactly one changed admission-filter line and
four unchanged observer methods, then permits the derived reconstructed-owner
SHA literal to change. This preserves the equality predicate and records both
historical and current identities. Following the first workflow run, it also
refreshes exactly the duplicate PINS['producer_readers.rs'] entry in
test-producer-input-composition.py, constrained by the same owner preimages.
All other PINS entries, including historical preflight pins, remain unchanged.
The initial wrapper is retained as support-before-observer-identity.py.
The copied reference/provenance.json describes
the previous campaign; its old wrapper/shim fields are historical, not evidence
of the current support implementation.

The exact 32-command workflow includes that duplicate owner identity test, but
not the historical producer-input preflight or completion-adapter correspondence
checks. Their exact-source proof
packets do not cover this increment's changed Context adapter. Metadata-only
source inventory checks and unchanged proof bodies are not a new formal proof.
