#!/usr/bin/env python3
"""Reuse pinned metadata audits and the exact accepted 32-command workflow.

Run with python3 -I -B. `check` reads only historical support and workflow inputs.
Only after the root agent declares all source frozen:

  support.py propose --source-frozen --name proposal-01
  # Inspect proposal-01/metadata.patch and apply it with apply_patch.
  support.py verify --source-frozen --proposal proposal-01 --label after-apply
  support.py run --source-frozen --proposal proposal-01 --name attempt-01-after

No command applies metadata, invokes a build, or invokes a solver. Each proposal,
workflow attempt, and labelled verification receipt must have a fresh path.
"""

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shlex
import subprocess
import sys
import time

import yaml


ROOT = Path(os.environ.get('FE2O3_REPLAY_ROOT', '/home/harsh/.codex-tmp/fe2o3-r61-execution')).resolve()
OUT = Path(__file__).resolve().parent
BASE = '91bb347442e58e7883adb01bd526e22e31dcae65'
PREVIOUS = OUT / 'reference'
RUNNER = PREVIOUS / 'run.py'
WORKFLOW = Path('.github/workflows/runtime-component-source-guards.yml')
PINS = {
    PREVIOUS / 'propose.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    PREVIOUS / 'verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
    RUNNER: '9e8b7c1601cb73bc09a405e2df3cee1dc00deb31ab6830115e8d1d0d2e920be1',
    PREVIOUS / 'inputs.json': '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e',
    PREVIOUS / 'result.json': 'f18598d8a126f3ae6ce39ab7d0b35801fbed9483be58738a90bd14ca8bfaa0e8',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *arguments], cwd=ROOT)


def fresh_json(path, value):
    with path.open('x') as target:
        target.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def artifact(name):
    need(re.fullmatch(r'[a-z][a-z0-9-]{0,79}', name) is not None, 'simple owned artifact name')
    path = OUT / name
    need(not path.is_symlink(), 'ordinary owned artifact path')
    return path


def check_support():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize,
         'run python3 -I -B without optimized assertions')
    need(git('rev-parse', 'HEAD').decode().strip() == BASE, 'exact accepted baseline HEAD')
    for path, digest in PINS.items():
        need(path.is_file() and not path.is_symlink(), 'ordinary pinned support: ' + str(path))
        need(sha(path.read_bytes()) == digest, 'unchanged pinned support: ' + str(path))
    previous_inputs = json.loads((PREVIOUS / 'inputs.json').read_bytes())
    previous_result = json.loads((PREVIOUS / 'result.json').read_bytes())
    need(previous_result['accepted'] and previous_result['command_count'] == 32
         and previous_result['source_unchanged'] and not previous_result['failed'],
         'accepted historical exact32 result')
    workflow = (ROOT / WORKFLOW).read_bytes()
    need(workflow == git('show', f'{BASE}:{WORKFLOW}'), 'unchanged baseline workflow')
    need(sha(workflow) == previous_inputs['workflow_sha256'], 'unchanged historical workflow')
    job = yaml.safe_load(workflow)['jobs']['source-controls']
    commands = [[step['name'], line, shlex.split(line)]
                for step in job['steps'] if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    need(len(commands) == 32 and commands == previous_inputs['commands'],
         'exact accepted source-controls commands in the same order')
    need(all(argv[:3] == ['python3', '-I', '-B'] for _, _, argv in commands),
         'isolated source-control commands only')
    return dict(baseline=BASE, workflow_sha256=sha(workflow), exact_command_count=32,
                support_sha256={str(path): digest for path, digest in PINS.items()},
                prior_result_accepted=True, build_invocations=0, solver_invocations=0,
                gpu_invocations=0, formal_qualification=False)


def verify(proposal, label):
    folder = artifact(proposal)
    need(folder.is_dir(), 'existing owned proposal')
    report = json.loads((folder / 'metadata-report.json').read_bytes())
    need(report['baseline'] == BASE, 'proposal names the exact current baseline')
    receipt = folder / (artifact(label).name + '-audit.json')
    transient = folder / 'applied-audit.json'
    need(not receipt.exists() and not transient.exists(), 'fresh labelled audit receipt')
    raw = (PREVIOUS / 'verify-applied.py').read_bytes()
    tree = ast.parse(raw)
    roots = [node for node in tree.body
             if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == 'ROOT'
                     for target in node.targets)]
    need(len(roots) == 1 and isinstance(roots[0].value, ast.Call)
         and isinstance(roots[0].value.func, ast.Name) and roots[0].value.func.id == 'Path'
         and len(roots[0].value.args) == 1
         and isinstance(roots[0].value.args[0], ast.Constant),
         'one exact retained verifier repository path')
    roots[0].value.args[0].value = str(ROOT)
    # Only the repository path is configured; the verifier derives OUT from __file__.
    namespace = {'__name__': 'reused_metadata_verifier',
                 '__file__': str(folder / 'verify-applied.py')}
    exec(compile(tree, str(PREVIOUS / 'verify-applied.py'), 'exec'), namespace)
    need(transient.is_file(), 'original verifier emitted its complete audit receipt')
    transient.rename(receipt)
    return receipt


def propose(name, support):
    folder = artifact(name)
    folder.mkdir()
    fresh_json(folder / 'invocation.json', dict(
        support, recorded_utc_ns=time.time_ns(), command=sys.argv,
        source_freeze_declared=True,
        approved_delta='SHA-256 literal identities and exact source-roster cardinality literals only',
        predicates_contracts_expected_solver_and_mutant_counts_must_remain_unchanged=True))
    raw = (PREVIOUS / 'propose.py').read_bytes()
    namespace = {'__name__': 'reused_metadata_proposer',
                 '__file__': str(PREVIOUS / 'propose.py')}
    exec(compile(raw, str(PREVIOUS / 'propose.py'), 'exec'), namespace)
    main = namespace['main']
    main.__globals__['BASE'] = BASE
    main.__globals__['ROOT'] = ROOT
    main.__globals__['OUT'] = folder
    main()


def run_workflow(name, proposal, support):
    folder = artifact(name)
    need(not folder.exists(), 'fresh workflow evidence directory')
    verify(proposal, 'before-' + name)
    original_argv = sys.argv
    try:
        sys.argv = [str(RUNNER), str(folder)]
        namespace = runpy.run_path(str(RUNNER), run_name='reused_exact_source_runner')
        namespace['main'].__globals__['REPO'] = ROOT
        try:
            namespace['main']()
        except SystemExit as exit_status:
            status = exit_status.code
        else:
            status = 0
    finally:
        sys.argv = original_argv
    closing = verify(proposal, 'after-' + name)
    result = json.loads((folder / 'result.json').read_bytes())
    inputs = json.loads((folder / 'inputs.json').read_bytes())
    previous = json.loads((PREVIOUS / 'inputs.json').read_bytes())
    need(inputs['commands'] == previous['commands'], 'runner executed exact historical commands')
    need(inputs['head'] == BASE, 'runner retained exact baseline HEAD')
    fresh_json(folder / 'reused-support.json', dict(
        support, recorded_utc_ns=time.time_ns(), command=sys.argv,
        metadata_proposal=proposal, closing_metadata_audit=str(closing),
        workflow_exit=status, workflow_accepted=result['accepted'],
        metadata_patch_applied_by_this_support=False))
    raise SystemExit(status)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='operation', required=True)
    commands.add_parser('check')
    proposal = commands.add_parser('propose')
    proposal.add_argument('--name', required=True)
    verification = commands.add_parser('verify')
    verification.add_argument('--proposal', required=True)
    verification.add_argument('--label', required=True)
    workflow = commands.add_parser('run')
    workflow.add_argument('--proposal', required=True)
    workflow.add_argument('--name', required=True)
    for subcommand in (proposal, verification, workflow):
        subcommand.add_argument('--source-frozen', action='store_true', required=True)
    args = parser.parse_args()
    os.umask(0o077)
    support = check_support()
    if args.operation == 'check':
        print(json.dumps(dict(support, status='prepared; no current source snapshot or guard execution'),
                         sort_keys=True))
    elif args.operation == 'propose':
        propose(args.name, support)
    elif args.operation == 'verify':
        verify(args.proposal, args.label)
    elif args.operation == 'run':
        run_workflow(args.name, args.proposal, support)


if __name__ == '__main__':
    main()
