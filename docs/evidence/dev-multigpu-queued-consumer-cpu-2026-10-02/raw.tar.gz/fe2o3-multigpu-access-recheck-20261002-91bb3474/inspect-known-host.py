#!/usr/bin/env python3
"""Inspect only offline SSH records for the authorized alias and hostname."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


out = Path(__file__).resolve().parent / "admission" / "same-host-known-records.json"
assert not out.exists()
records = []
for hostname in ["mi300x", "sharkmi300x-1"]:
    argv = ["ssh-keygen", "-F", hostname]
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=10, check=False)
    entries = []
    for line in result.stdout.decode("utf-8", "replace").splitlines():
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        if fields[0].startswith("@"):
            fields = fields[1:]
        if len(fields) >= 3:
            labels = fields[0]
            entries.append(dict(host_labels="hashed" if labels.startswith("|") else labels,
                                key_type=fields[1],
                                public_key_text_sha256=hashlib.sha256(fields[2].encode()).hexdigest()))
    records.append(dict(command=argv, exit_code=result.returncode,
                        stdout_bytes=len(result.stdout), stderr_bytes=len(result.stderr),
                        stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                        stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
                        matching_entries=entries))
receipt = dict(observed_at_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
               network_commands=0, configuration_changes=0, lookups=records)
with out.open("x") as target:
    target.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
