#!/bin/bash
set -euo pipefail
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-multigpu-queued-consumer-20261002
packet="$root/docs/evidence/dev-multigpu-queued-consumer-cpu-2026-10-02"
base=91bb347442e58e7883adb01bd526e22e31dcae65
build=${1:?final build attempt}
runtime=${2:?final runtime attempt}
checks=${3:?final tooling attempt}
cd "$root"
test "$(git rev-parse HEAD)" = "$base"
test ! -e "$packet/raw.tar.gz"
test "$(< "$raw/$build/build/overall.exit")" = 0
test "$(< "$raw/$checks/checks/overall.exit")" = 0
for filter in deferred_compute queued_consumer producer_launch compute_xgmi multi_group_drain_tests; do
    test "$(< "$raw/$runtime/runtime/$filter.exit")" = 0
    test "$(< "$raw/$runtime/runtime/$filter-list.exit")" = 0
    grep -Eq '^[1-9][0-9]* tests?, 0 benchmarks$' "$raw/$runtime/runtime/$filter-list.stdout"
done
case "$(< "$raw/$runtime/runtime/full.exit")" in
    0|101) ;;
    *) exit 125 ;;
esac
test -z "$(git ls-files --others --exclude-standard -- crates/fe2o3-runtime crates/fe2o3-runtime-model/verus)"
sha256sum -c "$raw/$build/build/elf.sha256"
unit=$(< "$raw/$build/build/executable.path")
sha256sum "$unit" \
    target/debug/examples/gfx942-runtime-compute-xgmi-smoke > "$raw/final-elf.sha256"
cmp <(tail -n 1 "$raw/final-elf.sha256") <(tail -n 1 "$raw/$checks/checks/elf-final.sha256")
printf '%s\n' "$base" > "$raw/base-commit.txt"
printf 'build=%s\nruntime=%s\nchecks=%s\n' "$build" "$runtime" "$checks" > "$raw/final-attempts.txt"
git diff --binary "$base" -- crates/fe2o3-runtime crates/fe2o3-runtime-model/verus > "$raw/source.patch"
git diff --name-only "$base" -- crates/fe2o3-runtime crates/fe2o3-runtime-model/verus > "$raw/source-paths.txt"
mapfile -t paths < "$raw/source-paths.txt"
test "${#paths[@]}" -gt 0
sha256sum "${paths[@]}" > "$raw/source.sha256"
sha256sum "$raw/source.patch" > "$raw/source-patch.sha256"
rustc +nightly-2026-04-03 -Vv > "$raw/rustc.txt"
cargo +nightly-2026-04-03 -V > "$raw/cargo.txt"
uname -a > "$raw/uname.txt"
mkdir -p "$packet"
tar -czf "$packet/raw.tar.gz" -C "$raw" .
cd "$packet"
sha256sum raw.tar.gz > SHA256SUMS
