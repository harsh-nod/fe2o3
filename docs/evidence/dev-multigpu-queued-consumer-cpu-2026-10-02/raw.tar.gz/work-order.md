# Queued Multi-GPU Consumer

Base: 91bb347442e58e7883adb01bd526e22e31dcae65, signed and confirmed on both
runtime branch remotes. Previous goal turn: progress, not no-progress.

Objective of this increment: support an explicitly producer-aware consumer
behind an ordinary native compute/XGMI copy through the existing Context and
router APIs, without acquiring child allocation custody before the copy has
retired its queue and restored both endpoint owners. Full parity remains open.

Ownership: xgmi_source_ci owns Context admission, leaf reconciliation and Context
tests; xgmi_integration_review owns router deferred submission and router tests;
multigpu_host_admission owns public queued-consumer integration tests. Root owns
the optional native witness mode, integration, builds, source guards, evidence,
review, signed commit and pushes. No Qwen worker is used.

Hardware: the fresh single SSH attempt at 2026-10-02T02:26:39Z fails DNS before
remote execution. A local same-host Tailscale-map read also fails without an
address. No configuration/daemon changes, remote scratch, workload or admitted
GPU pair. Original records remain in the sibling access-recheck packet.

Validation: final-source pinned-toolchain all-feature runtime unit build, direct
focused and unfiltered tests with before/after ELF hashes, strict Clippy,
no-default check, example tests/build, formatting, whitespace and the exact
existing source-control workflow. Every attempt gets a fresh directory; failures
are retained and never relabeled. Existing socket-inspection EPERM failures are
reported explicitly if repeated, not ignored. No CPU/source-control result is
native execution, a new formal proof, parity or a performance measurement.
