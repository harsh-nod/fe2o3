#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-ordered-outer-join-20260928-PohBg69f
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
aggregate=0
run() {
    local name=$1
    shift
    printf 'START %s %s\n' "$name" "$(date -u +%FT%TZ)"
    printf '%q ' "$@"
    printf '\n'
    "$@" > "$out/$name.log" 2>&1
    local status=$?
    printf 'END %s status=%s %s\n' "$name" "$status" "$(date -u +%FT%TZ)"
    if [ "$status" != 0 ]; then aggregate=1; fi
}
run focused-cpu cargo test --locked -p fe2o3-runtime --all-features --lib cpu_receipts -- --test-threads=1 --nocapture
run focused-ordered cargo test --locked -p fe2o3-runtime --all-features --lib materialized_publication_tests::completion::ordered -- --test-threads=1 --nocapture
run preflight-clippy cargo clippy --locked -p fe2o3-runtime --all-features --all-targets -- -D warnings
printf 'aggregate %s\n' "$aggregate"
exit "$aggregate"
