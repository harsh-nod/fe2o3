#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-ordered-outer-join-20260928-PohBg69f
name=$1
code=$2
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
git rev-parse HEAD
git diff --binary -- crates > "$out/$name.patch"
test -s "$out/$name.patch"
printf 'START %s %s\n' "$name" "$(date -u +%FT%TZ)"
set +e
cargo check --locked -p fe2o3-runtime --all-features --tests --message-format=json > "$out/$name.jsonl" 2> "$out/$name.stderr"
status=$?
set -e
printf 'END %s status=%s %s\n' "$name" "$status" "$(date -u +%FT%TZ)"
test "$status" = 101
jq -s -e --arg code "$code" '
    [.[] | select(.reason == "compiler-message") | .message
      | select(.level == "error")] as $errors
    | ($errors | length) > 0
      and all($errors[]; .code.code == $code
        and any(.spans[]; .is_primary
          and (.file_name | endswith("kfd_backend/ordered_publication.rs"))))
' "$out/$name.jsonl"
printf 'intended compiler refusal verified: %s\n' "$code"
