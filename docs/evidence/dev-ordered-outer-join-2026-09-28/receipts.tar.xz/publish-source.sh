#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-ordered-outer-join-20260928-PohBg69f
expected=c08b3c8bb5fd99268395bce3c23664d7dd31d963
branch=codex/r65-runtime-drain-versions
export GIT_SSL_CAINFO=/home/harsh/.codex-openai/amd-zscaler-ca.pem
test "$(git rev-parse HEAD)" = "$expected"
git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
git diff --exit-code "$expected" -- crates Cargo.lock Cargo.toml rust-toolchain.toml
git diff --check
git status --short
git remote -v
for remote in origin upstream; do
    git push "$remote" "HEAD:refs/heads/$branch"
    git ls-remote --exit-code "$remote" "refs/heads/$branch" > "$out/$remote-source-head.log"
    read -r observed ref < "$out/$remote-source-head.log"
    test "$observed" = "$expected"
    test "$ref" = "refs/heads/$branch"
    printf 'verified %s %s %s\n' "$remote" "$observed" "$(date -u +%FT%TZ)"
done
printf 'source publication checks passed\n'
