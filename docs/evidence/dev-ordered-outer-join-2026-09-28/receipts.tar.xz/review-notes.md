# Ordered Outer-Close Join Review

Primary owns edits, qualification and publication. Swarm reviewers are read-only.
No reviewer builds, permission prompts, Qwen workers or remote hardware tasks.

The reviewed production change replaces the unit-return/identity-only settlement
call sequence with a non-Copy object holding the exact mutable pipeline loan and
staged identity. A native object is returned only from the complete Ok(Ok(()))
outer lane result; the scripted equivalent returns only after its outer-fault
decision. Neither batch nor profile leaves indexed custody in the object.
Settlement consumes the object and accepts no substitute arena or identity.

Exact entry / Publishing / Unattempted preflight now rejects destructive private
reentry before the shared Attempt::submit can overwrite a returned receipt.
Both reviewers found no runtime correctness blocker. The lifetime is tied to the
selected backend loan, so caller-side safe mutation of either arena is excluded
until consuming settlement ends. This is not an independently branded native
capability, nor does it protect against arbitrary unsafe internal corruption.

Settlement keeps publication-duration recording first, Retryable withdrawal
before publication timestamp mutation, and Published timestamp mutation before
confirmation. Refused confirmation retains the indexed Published root. After
confirmation the exact batch is moved to the completion cell before an observer
payload escapes. Existing scripted ProfileUnwind stays after this deposit.

Tests were strengthened without inventing replacement receipts: the real A/B/C
success chain compares each installed identity against the provider's immediately
preceding lower-submit result and frames earlier receipt identities. Terminal
outer-close cases compare exact next/frontier/staged heads, because checking only
Quarantined phase could hide premature confirmation. Scripted ProfileUnwind must
observe exactly one metadata confirmation and no remaining staged marker.

Remaining scope: shared executable-body Verus composition with metadata
confirm/withdraw, opaque receipt/profile payload movement, and retained-resource
settlement. Existing 44 metadata obligations do not prove this new caller join.
No native CODE/DATA/currentness, Context/Worker, GPU fault, performance or full
parity qualification follows from these CPU and Rust ownership checks.

Preparatory results: 10 CPU receipt groups and 5 ordered-publication groups passed,
and strict all-target Clippy passed. Review then added must-use to the returned
object and strengthened the scripted profile head tuple to an exact one-epoch
advance. A formatting check caught the Copy-identity dereference layout; the
format-only correction is the final signed source c08b3c8b, on parent 1e02cd3c.

Compiler probes mutate actual production caller source. The first duplicate-use
placement also extended a borrow across error mapping and was rejected by the
strict single-code classifier (E0382 plus E0499); its logs remain preserved. The
isolated placement before normal settlement produces only E0382, use of moved
returned value, in library and library-test builds. Conflicting pipeline mutation
before consumption produces only E0499 at that exact statement in both builds.
The diagnostic classifier was not relaxed. These are compiler-negative ownership
controls, not solver proofs or device execution.

The actual native outer-error arm was then mutated to confirm pipeline metadata
before terminalization. The genuine CPU publication test compiled and ran, then
failed its new exact-head assertion in the ordered child: (Some(2), Some(1), None)
instead of unchanged heads plus the retained staged identity. The negative
controller required a test failure summary and these exact observed head values.
The mutation was removed, and git diff against signed c08b3c8b confirmed complete
implementation restoration before the frozen final qualification began.

A read-only roadmap audit found no milestone promotion. Recommended native work
after caller proof composition: the existing retained_release_tests/mixed_duration
artifact-correctness cell, real short-before-long native completion and observer
timeout/drop/backpressure canaries, then scale_capacity/native_depth's two-lane
2048-retained-receipt cell. The earlier mixed-duration native upload was interrupted
before test launch; the newer ordered 64-launch smoke does not replace it.
Retained-depth evidence must not claim simultaneously unfinished GPU operations.
Worker refinement authority and strict threaded-release native lifecycle remain
independent outstanding tranches. This audit was read-only and ran no native tests.

Final qualification on signed c08b3c8bb5fd99268395bce3c23664d7dd31d963 completed
with aggregate zero at 2026-09-28T18:15:25Z: 10 CPU receipt groups, 5 ordered groups,
1816 runtime library tests (0 failures, 28 existing ignores), 52 doctests (8 positive
and 44 compile-fail), strict Clippy, no-default-feature compilation, workspace
formatting, signature, source continuity and diff check all passed. Issue #182 was
observed open. An intermediary commentary incorrectly stated 9 ordered groups;
the actual preparatory and final logs both show 5, and the count was corrected
before publication. The focused total is 15, overlapping the full library suite.
