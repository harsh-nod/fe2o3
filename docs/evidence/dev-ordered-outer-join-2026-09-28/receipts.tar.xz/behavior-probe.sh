#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-ordered-outer-join-20260928-PohBg69f
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
ulimit -c 0
git rev-parse HEAD
git diff --binary -- crates > "$out/premature-confirmation.patch"
test -s "$out/premature-confirmation.patch"
printf 'START premature-confirmation %s\n' "$(date -u +%FT%TZ)"
set +e
cargo test --locked -p fe2o3-runtime --all-features --lib kfd_backend::tests::cpu_receipt_tests::cpu_receipts_outer_fault_retains_exact_indexed_publication -- --exact --nocapture > "$out/premature-confirmation-test.log" 2>&1
status=$?
set -e
printf 'END premature-confirmation status=%s %s\n' "$status" "$(date -u +%FT%TZ)"
test "$status" = 101
rg -F 'test result: FAILED. 0 passed; 1 failed;' "$out/premature-confirmation-test.log"
rg -F 'left: (Some(2), Some(1), None)' "$out/premature-confirmation-test.log"
rg -F 'right: (Some(1), None, Some(RuntimeComputePipelineIdentityV1' "$out/premature-confirmation-test.log"
printf 'intended premature-confirmation head-frame refusal verified\n'
