#!/usr/bin/env bash
set -u
set -o pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-ordered-outer-join-20260928-PohBg69f
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
source=$(git rev-parse HEAD)
aggregate=0
run() {
    local name=$1
    shift
    printf 'START %s %s\n' "$name" "$(date -u +%FT%TZ)"
    printf '%q ' "$@"
    printf '\n'
    "$@" >"$out/$name.log" 2>&1
    local status=$?
    printf 'END %s status=%s %s\n' "$name" "$status" "$(date -u +%FT%TZ)"
    if (( status != 0 )); then aggregate=1; fi
}
run source git show -s --format=fuller --show-signature HEAD
run tree git rev-parse HEAD HEAD^{tree}
run signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run focused cargo test --locked -p fe2o3-runtime --all-features --lib cpu_receipts -- --test-threads=1 --nocapture
run ordered cargo test --locked -p fe2o3-runtime --all-features --lib materialized_publication_tests::completion::ordered -- --test-threads=1 --nocapture
run runtime-lib cargo test --locked -p fe2o3-runtime --all-features --lib
run runtime-doc cargo test --locked -p fe2o3-runtime --all-features --doc
run clippy cargo clippy --locked -p fe2o3-runtime --all-features --all-targets -- -D warnings
run runtime-default cargo check --locked -p fe2o3-runtime --no-default-features
run fmt cargo fmt --all -- --check
run continuity git diff --exit-code "$source" -- crates Cargo.lock Cargo.toml rust-toolchain.toml
run diff-check git diff --check
run issue-182 gh api repos/harsh-nod/fe2o3/issues/182
printf 'aggregate %s\n' "$aggregate"
exit "$aggregate"
