#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly logs=/home/harsh/.codex-tmp/fe2o3-conditional-coverage-20261003-9nL8tm
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
run() {
    local name=$1
    shift
    printf 'RUN %s\n' "$name"
    { printf 'COMMAND'; printf ' %q' "$@"; printf '\n'; "$@"; } >"$logs/$name.log" 2>&1
    tail -n 4 "$logs/$name.log"
}
run ownership cargo +nightly-2026-04-03 test -p fe2o3-kernel-analysis --test pliron_hierarchical_ownership --locked --offline
run staging cargo +nightly-2026-04-03 test -p fe2o3-pliron --features internal-proof-staging --test production_middle_end_evidence_v5 --locked --offline
run pipeline cargo +nightly-2026-04-03 test -p fe2o3-pliron --features internal-proof-staging --test production_ranked_pipeline --locked --offline
run compiler cargo +nightly-2026-04-03 test -p rustc-codegen-fe2o3 --lib --locked --offline
run staging-lib cargo +nightly-2026-04-03 test -p fe2o3-pliron --features internal-proof-staging --lib --locked --offline
run clippy cargo +nightly-2026-04-03 clippy -p fe2o3-kernel-analysis -p fe2o3-pliron -p rustc-codegen-fe2o3 --lib --locked --offline --no-deps -- -D warnings
run formatting rustup run nightly-2026-04-03 rustfmt --check --edition 2024 --config skip_children=true crates/fe2o3-kernel-analysis/src/pliron_hierarchical_ownership.rs crates/fe2o3-kernel-analysis/src/pliron_hierarchical_ownership/conditional.rs crates/fe2o3-kernel-analysis/tests/pliron_hierarchical_ownership.rs crates/fe2o3-pliron/src/lib.rs crates/fe2o3-pliron/src/production/total_output_refinement_v2.rs crates/fe2o3-pliron/tests/production_middle_end_evidence_v5.rs crates/rustc-codegen-fe2o3/src/production_reference_effect_join_v2.rs crates/rustc-codegen-fe2o3/src/production_ranked_projection_v1.rs crates/rustc-codegen-fe2o3/tests/production_extraction_driver_v1.rs
run whitespace git diff --check
