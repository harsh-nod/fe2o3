#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-runtime-cpu-receipts-20260928-aDRIRy3e
expected=7c46c4238881f8c4533ad2f03d91fc8f72b617ef
branch=codex/r65-runtime-drain-versions
test "$(git rev-parse HEAD)" = "$expected"
git remote -v
for remote in origin upstream; do
    git push "$remote" "HEAD:refs/heads/$branch"
    git ls-remote --exit-code "$remote" "refs/heads/$branch" > "$out/source-$remote-head.log"
    read -r observed ref < "$out/source-$remote-head.log"
    test "$observed" = "$expected"
    test "$ref" = "refs/heads/$branch"
    printf 'verified %s %s %s\n' "$remote" "$observed" "$(date -u +%FT%TZ)"
done
