# Read-Only Swarm Review

Primary owned all edits, builds, integration and qualification. Reviewers did
not run builds or change files. No MI300X, Qwen or other external worker used.

`binding_custody_review` checked the concrete adapter's two callback lifetimes,
preserved nested results, inline retryable completed receipts, deposit-before-
outer-close ordering and cleanup guards. No production ownership blocker found.
The review requested a tuple-pattern fix, the source-wiring assertion update,
fault consumption only after admitted callback entry, and exact passive identity
and custody snapshots for terminal cases. These were implemented. Intentional
Drop abort now runs with core dumps disabled. Terminal poll/cancel/shutdown
refusals explicitly require Terminal and preserve indexed logical facts.

`binding_tests_review` checked the public setup and test oracles. An initial
assumption that submit always leaves Pending was wrong: clean work can publish
immediately. The fixture now creates a genuinely completed P, records an event,
and submits targets with that dependency, so the production cursor keeps them
Pending. Checked CPU metadata-cache release precedes target setup. No Pending
owner or dependency retain is manually settled. The tests now verify generation
increments on genuine retries, publication counts, exact retained-allocation
rosters/reservations, primary lower/runtime framing during AUX work, distinct
receipt identities and explicit event-retain handoff.

Preparatory runs:
- 01-build: compile failure for Retired tuple pattern, fixed to Retired(_).
- 02-focused: runtime abort after test indexed a Pending owner already published
  by submit; corrected with actual completed-event dependency, not a progress
  bypass. Core limit was zero; no core file found in the worktree.
- 03-focused: 3 groups passed.
- 04-focused: 6 groups passed, including 8 terminal children and 1 Drop child.
- 05-clippy: manual-is-multiple-of lint in case selector; replaced with bit test.

Initial workspace formatting and the first preparatory no-run build overlapped
briefly because formatting yielded a live handle. Both were polled to terminal;
that preparatory build failed and is not qualification evidence. Subsequent
format/build/test runs were serialized, including the final qualify.sh campaign.

Remaining scope: no native CODE/DATA materialization or cache rebinding, device
writes/readback, prepared cancellation, populated-arena ordered retry, runtime
pin-recycle retry, outer-failure-after-Retryable or completion outer-fault matrix,
or new formal correspondence. Cache release requires all lower lanes clean.
Snapshots omit full dependency-ledger contents and completion-owner phase.
Terminal children intentionally retain poisoned ownership until process exit;
only nonterminal scenarios establish checked clean CPU teardown.

First frozen qualification at 61517a85 passed focused7, doctests, strict Clippy,
default checking, formatting and source continuity, but the full parallel runtime
suite aborted with owner-thread stack overflow. Aggregate1, not waived.
Read-only compiled DWARF inspection found KfdRuntimeBackendV1=104072 bytes and
Option<CpuOrdinaryQueueV1>=40608 bytes even when None. The fixture includes a
39208-byte queue session. Exact raw output is in inline-layout.log and
inline-option-layout.log. Commands:

```sh
llvm-dwarfdump --name=CpuOrdinaryQueueV1 --name=CpuFixedDispatchFixtureV1 --name=CpuLane --name=KfdRuntimeBackendV1 --name=ComputeAqlQueueSessionV1 target/debug/deps/fe2o3_runtime-9769d8672ea75741
llvm-dwarfdump --debug-info=0x6b75d --recurse-depth=0 target/debug/deps/fe2o3_runtime-9769d8672ea75741
```

7c46c423 boxes only the test-only CPU field and passes borrowed references at
the three adapters. It does not increase thread stacks or change native storage.
The separate final/ campaign reruns every gate on this corrected signed source;
the parent qualification.log and associated logs preserve the failed campaign.

Corrected compiled DWARF in final/boxed-layout.log records backend size 0xf7f0
(63472 bytes); obtained with llvm-dwarfdump --name=KfdRuntimeBackendV1 on the same
test executable after recompilation. The owner-thread bridge test passes in the
full suite. Final aggregate0: focused7, runtime1813/0failed/28ignored,
doctests8+44, strict Clippy/default/fmt/signature/continuity/API all exit0.
No implementation was changed during either frozen campaign.

Final documentation review corrected overly broad callback timestamp language:
completion transitions and first-Ready timing are inside the callback, while
publication timestamping and ordered confirmation remain in their existing outer
callers. Cache refusal tests compare descriptors/lower snapshots, not every
RecycledDispatch field. No new native/formal/parity claim is accepted.
