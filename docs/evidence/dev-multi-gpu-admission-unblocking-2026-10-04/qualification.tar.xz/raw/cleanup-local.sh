#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly packet="$repo/docs/evidence/dev-multi-gpu-admission-unblocking-2026-10-04"
readonly retained="$repo/target/qualification-startup-20261004-8266028a3"
exec > "$packet/cleanup.log" 2>&1
test -s "$packet/qualification.tar.xz"
tar -tJf "$packet/qualification.tar.xz" > /dev/null
test "$(cat "$scratch/auditor-final-check.status")" = 0
test ! -e "$scratch/install"
test ! -e "$scratch/qualification"
test ! -e "$scratch/attempt-41a56d2dc/install"
test ! -e "$scratch/attempt-41a56d2dc/qualification"
test -z "$(git -C "$scratch/source" status --porcelain --untracked-files=normal)"
git -C "$repo" worktree remove "$scratch/source"
test ! -e "$scratch/source"
mkdir "$retained"
mv "$scratch/bundle" "$scratch/base" "$scratch/source-commit.txt" "$retained/"
printf 'retained_independently_pinned_inputs=%s\n' "$retained"
test ! -L "$scratch"
rm -rf --one-file-system -- "$scratch"
test ! -e "$scratch"
printf 'owned_scratch=removed\nowned_worktree=removed\nremote_resources_created=none\ncleanup=complete\n'
