#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/check.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
bash scripts/tests/compiler-execution-deployment-bundle.sh > "$scratch/contract.log" 2>&1
bash scripts/tests/compiler-execution-qualification-base.sh >> "$scratch/contract.log" 2>&1
cargo test --locked -p fe2o3-compiler-execution-deployment --all-targets > "$scratch/unit.log" 2>&1
cargo clippy --locked -p fe2o3-compiler-execution-deployment --all-targets -- -D warnings > "$scratch/clippy.log" 2>&1
rustfmt +nightly-2026-04-03 --check --edition 2024 crates/fe2o3-compiler-execution-deployment/src/boot.rs crates/fe2o3-compiler-execution-deployment/src/qualification.rs crates/fe2o3-compiler-execution-deployment/src/lib.rs > "$scratch/format.log" 2>&1
git diff --check > "$scratch/whitespace.log"
