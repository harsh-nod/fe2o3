#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly test_image=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_compiler_execution_deployment-d3dc5624d28bdabe
trap 'printf "%s\n" "$?" > "$scratch/mount-gzip-test.status"' EXIT
test "$(id -u)" = 0
timeout --kill-after=5s 30s "$test_image" \
    mount::tests::root_mounts_gzip_fixture_from_sealed_read_only_loop \
    --exact --ignored --nocapture --test-threads=1 > "$scratch/mount-gzip-test.log" 2>&1
