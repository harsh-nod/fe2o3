#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly cargo=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/qualification-static-deployment/cargo
readonly qualifier="$cargo/x86_64-unknown-linux-musl/release/fe2o3-compiler-execution-qualification"
trap 'printf "%s\n" "$?" > "$scratch/run.status"' EXIT
test "$(id -u)" = 0
test "$(cat "$scratch/build.status")" = 0
test "$(cat "$scratch/base.status")" = 0
manifest=$(sed -n 's/^manifest_sha256=\([0-9a-f]\{64\}\)$/\1/p' "$scratch/build.log")
base=$(sed -n 's/^base_image_sha256=\([0-9a-f]\{64\}\)$/\1/p' "$scratch/base.log")
commit=$(cat "$scratch/source-commit.txt")
test "${#manifest}" = 64
test "${#base}" = 64
test "${#commit}" = 40
"$qualifier" probe > "$scratch/probe.log" 2> "$scratch/probe.stderr"
install -d -o 0 -g 0 -m 0700 "$scratch/install" "$scratch/qualification"
"$qualifier" run "$scratch/bundle" "$manifest" "$commit" "$scratch/install" \
    "$scratch/base/qualification-base-v1.squashfs" "$base" "$scratch/qualification" \
    > "$scratch/run.stdout" 2> "$scratch/run.stderr"
find "$scratch/qualification" -mindepth 1 -maxdepth 1 -printf '%f\n' > "$scratch/qualification-after.txt"
test ! -s "$scratch/qualification-after.txt"
test ! -s "$scratch/run.stderr"
