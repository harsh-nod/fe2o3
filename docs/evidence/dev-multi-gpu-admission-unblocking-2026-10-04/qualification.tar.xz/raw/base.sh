#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
trap 'printf "%s\n" "$?" > "$scratch/base.status"' EXIT
cd "$scratch/source"
/usr/bin/time -v bash scripts/build-compiler-execution-qualification-base.sh "$scratch/base" > "$scratch/base.log" 2>&1
