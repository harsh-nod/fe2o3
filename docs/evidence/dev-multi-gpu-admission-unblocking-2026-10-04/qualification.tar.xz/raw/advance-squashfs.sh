#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly source="$scratch/source"
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
test "$(cat "$scratch/build.status")" = 0
test "$(cat "$scratch/run.status")" = 1
test "$(cat "$scratch/check.status")" = 0
test -z "$(git -C "$source" status --porcelain --untracked-files=normal)"
mkdir "$scratch/attempt-41a56d2dc"
for path in bundle build.log build.status source-commit.txt source-status.txt probe.log probe.stderr run.stdout run.stderr run.status install qualification; do
    mv "$scratch/$path" "$scratch/attempt-41a56d2dc/"
done
git -C "$source" merge --ff-only "$(git -C "$repo" rev-parse HEAD)"
test -z "$(git -C "$source" status --porcelain --untracked-files=normal)"
