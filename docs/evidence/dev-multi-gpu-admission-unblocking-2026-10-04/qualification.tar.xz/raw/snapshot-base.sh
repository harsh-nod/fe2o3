#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
export APT_CONFIG="$scratch/apt/apt.conf"
trap 'printf "%s\n" "$?" > "$scratch/snapshot-base.status"' EXIT
mkdir -p "$scratch/apt/state/lists/partial" "$scratch/apt/cache/archives/partial" "$scratch/apt/log" "$scratch/apt/empty.d"
timeout --kill-after=5s 120s apt-get update > "$scratch/apt-update.log" 2>&1
apt-cache policy coreutils libc6 systemd > "$scratch/apt-policy.log"
bash "$scratch/base.sh"
