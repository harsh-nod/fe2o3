#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/auditor-final-check.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1 FE2O3_HIP_SYS_DISABLE=1
export TMPDIR="$scratch/application-test-tmp"
export FE2O3_V3_STATIC_FIXTURE_TARGET_DIR="$TMPDIR/cargo-fe2o3-v3-static-host-consumer-1046447"
cargo test --locked -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --test worker_v3_load_envelope_vertical strict_v3_seccomp_ \
    -- --nocapture --test-threads=1 > "$scratch/auditor-integration-final.log" 2>&1
bash "$scratch/auditor-lint.sh"
