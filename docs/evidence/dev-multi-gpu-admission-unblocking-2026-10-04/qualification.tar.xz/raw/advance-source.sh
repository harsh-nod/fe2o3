#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
test "$(cat "$scratch/build.status")" = 0
test "$(cat "$scratch/base.status")" = 0
mkdir "$scratch/initial-93fcecfbf"
for name in bundle build.log build.status base base.log base.status source-commit.txt source-status.txt; do
    mv "$scratch/$name" "$scratch/initial-93fcecfbf/$name"
done
git -C "$scratch/source" merge --ff-only 41a56d2dc106e388c96743ab311a26a60b8f96d5
