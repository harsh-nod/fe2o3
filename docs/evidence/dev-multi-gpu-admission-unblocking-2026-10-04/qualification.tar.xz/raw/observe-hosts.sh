#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
uname -a > "$scratch/local-kernel.log"
zgrep CONFIG_SQUASHFS /proc/config.gz > "$scratch/local-squashfs-config.log"
ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x uname -r > "$scratch/mi300x-kernel.log"
ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x \
    'grep CONFIG_SQUASHFS_ZSTD /boot/config-6.8.0-124-generic' > "$scratch/mi300x-squashfs-config.log"
if ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x sudo -n true > "$scratch/mi300x-root.log" 2>&1; then
    printf '0\n' > "$scratch/mi300x-root.status"
else
    printf '%s\n' "$?" > "$scratch/mi300x-root.status"
fi
for attempt in "$scratch/attempt-41a56d2dc" "$scratch"; do
    test ! -e "$attempt/install"
    test ! -e "$attempt/qualification"
done
printf 'owned_root_parents=absent\nremote_resources_created=none\n' > "$scratch/cleanup.log"
