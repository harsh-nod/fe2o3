#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly qualifier=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-compiler-execution-qualification
test "$(id -u)" = 0
test -d "$scratch"
test ! -L "$scratch"
for attempt in "$scratch/attempt-41a56d2dc" "$scratch"; do
    manifest=$(sed -n 's/^manifest_sha256=\([0-9a-f]\{64\}\)$/\1/p' "$attempt/build.log")
    test "${#manifest}" = 64
    "$qualifier" recover "$attempt/qualification" > "$attempt/recovery.log" 2>&1
    "$qualifier" recover-install "$manifest" "$attempt/install" > "$attempt/install-recovery.log" 2>&1
    test -z "$(find "$attempt/qualification" -mindepth 1 -maxdepth 1 -printf '%f\n')"
    test ! -L "$attempt/install"
    test ! -L "$attempt/qualification"
    rm -rf --one-file-system -- "$attempt/install" "$attempt/qualification"
    printf 'removed_owned_root_parents=%s\n' "$attempt"
done
printf 'cleanup=complete\n'
