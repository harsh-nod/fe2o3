#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly packet="$repo/docs/evidence/dev-multi-gpu-admission-unblocking-2026-10-04"
readonly raw="$scratch/evidence/raw"
test "$(cat "$scratch/check.status")" = 0
test "$(cat "$scratch/auditor-check.status")" = 101
test "$(cat "$scratch/auditor-final-check.status")" = 0
test "$(cat "$scratch/auditor-lint.status")" = 0
rg -Fq 'test result: ok. 3 passed; 0 failed;' "$scratch/auditor-integration.log"
rg -Fq 'test result: ok. 7 passed; 0 failed;' "$scratch/auditor-unit.log"
test "$(cat "$scratch/mount-gzip-test.status")" = 0
test "$(cat "$scratch/run.status")" = 1
mkdir -p "$raw/initial-93fcecfbf" "$raw/attempt-41a56d2dc" "$raw/base" "$raw/bundle" "$raw/apt"
cp "$scratch"/*.log "$scratch"/*.status "$scratch"/*.sh "$scratch"/*.txt "$scratch"/*.stderr "$scratch"/*.stdout "$raw/"
cp "$scratch/initial-93fcecfbf"/*.log "$scratch/initial-93fcecfbf"/*.status "$scratch/initial-93fcecfbf"/*.txt "$raw/initial-93fcecfbf/"
cp "$scratch/attempt-41a56d2dc"/*.log "$scratch/attempt-41a56d2dc"/*.status "$scratch/attempt-41a56d2dc"/*.txt "$scratch/attempt-41a56d2dc"/*.stderr "$scratch/attempt-41a56d2dc"/*.stdout "$raw/attempt-41a56d2dc/"
cp "$scratch/base/BASE-INFO" "$scratch/base/SHA256SUMS" "$raw/base/"
cp "$scratch/bundle/BUILD-INFO" "$scratch/bundle/INSTALL-MANIFEST-V1" "$scratch/bundle/SHA256SUMS" "$raw/bundle/"
cp "$scratch/apt/apt.conf" "$scratch/apt/sources.list" "$raw/apt/"
git -C "$repo" log -5 --format='%H %s' > "$raw/commits.log"
git -C "$repo" diff --check > "$raw/final-whitespace.log"
cd "$repo"
rustfmt +nightly-2026-04-03 --check --edition 2024 \
    crates/cargo-fe2o3/src/application_sandbox.rs \
    crates/cargo-fe2o3/tests/fixtures/runner_app_fixture.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs \
    crates/fe2o3-compiler-execution-deployment/src/mount.rs \
    > "$raw/final-format.log" 2>&1
sha256sum \
    crates/cargo-fe2o3/src/application_sandbox.rs \
    crates/cargo-fe2o3/tests/fixtures/auditor_syscall_probe.rs \
    crates/cargo-fe2o3/tests/fixtures/runner_app_fixture.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs \
    crates/fe2o3-compiler-execution-deployment/src/mount.rs \
    crates/fe2o3-compiler-execution-deployment/src/qualification.rs \
    crates/fe2o3-compiler-execution-deployment/tests/fixtures/*.squashfs \
    > "$raw/source-sha256.log"
tar -cJf "$packet/qualification.tar.xz" -C "$scratch/evidence" raw
tar -tJf "$packet/qualification.tar.xz" > "$scratch/packet-inventory.log"
sha256sum "$packet/qualification.tar.xz"
