#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-measured-startup-20261004-ySXj6w14
readonly source="$scratch/source"
trap 'printf "%s\n" "$?" > "$scratch/build.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
export FE2O3_STATIC_DEPLOYMENT_TARGET_DIR=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/qualification-static-deployment
cd "$source"
git rev-parse HEAD > "$scratch/source-commit.txt"
git status --porcelain --untracked-files=normal > "$scratch/source-status.txt"
test ! -s "$scratch/source-status.txt"
/usr/bin/time -v bash scripts/build-static-compiler-execution-deployment.sh "$scratch/bundle" > "$scratch/build.log" 2>&1
