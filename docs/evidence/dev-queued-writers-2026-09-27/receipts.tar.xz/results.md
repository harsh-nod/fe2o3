# Final Results

Source: `9ff331dace8b4a47cc156aa92930fbf85d405626`, verified SSH signature.

| Check | Exit | Result |
| --- | --- | --- |
| Full model suite | 0 | 1,054 passed; 19 existing ignored; 29 doctests passed |
| Runtime all-feature library | 101 | 1,673 passed; 3 failures; 28 existing ignored |
| Runtime all-feature doctests | 0 | 8 + 44 passed |
| Strict all-feature/all-target Clippy, both crates | 0 | No warnings |
| Minimal model check | 0 | Passed |
| Formatting and staged whitespace | 0 | Passed |
| Existing mixed-acquisition Verus root | 0 | 738 verified; 0 errors |
| MI300X probe | 255 | DNS failure; no remote effects |
| Origin head probe | 128 | DNS failure; publication not established |

The runtime failures are the same three previously recorded authorized_execution
tests: cooperative_debug_telemetry_emits_only_bounded_logical_records,
failed_session_end_is_explicit_and_terminal, and
pre_native_telemetry_failure_is_returned_and_poisoned. All fail at
authorized_execution.rs:1317 with InspectSocket(PermissionDenied). No waiver or
successful execution of these tests is claimed.

Twenty new queue test groups include a 384-case four-writer outcome/order matrix.
These are CPU model checks, not evidence of GPU order or speed. The new owner is
not integrated into Context and has no outer-queue formal-refinement proof yet.
