# Queued Writer Developer Checks

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`
Source commit: `9ff331dace8b4a47cc156aa92930fbf85d405626`

All Cargo runs are offline, one build job. Final Cargo runs set
`CARGO_INCREMENTAL=0`. No GPU command ran beyond the failed SSH hostname probe.

Final model suite (`model-final-clean.log`):
```sh
env CARGO_INCREMENTAL=0 cargo test --offline -p fe2o3-runtime-model -j 1
```

Runtime regression (`runtime-full.log`):
```sh
env CARGO_INCREMENTAL=0 cargo test --offline -p fe2o3-runtime --all-features --lib -j 1
```

Runtime doctests (`runtime-doctests.log`):
```sh
env CARGO_INCREMENTAL=0 cargo test --offline -p fe2o3-runtime --all-features --doc -j 1
```

Strict lint (`clippy-final.log`):
```sh
env CARGO_INCREMENTAL=0 cargo clippy --offline -p fe2o3-runtime-model -p fe2o3-runtime --all-features --all-targets -j 1 -- -D warnings
```

Source checks (`fmt.log`, `whitespace-final.log`):
```sh
cargo fmt -p fe2o3-runtime-model --check
git diff --cached --check
```

Existing mixed-acquisition proof regression (`mixed-verus-current.log`):
```sh
env VERUS_Z3_PATH=/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/z3 timeout --foreground --signal=TERM --kill-after=5 1200 /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus --crate-type lib --triggers-mode silent --no-cheating --num-threads 2 crates/fe2o3-runtime-model/verus/context_mixed_acquire_historical_v1.rs
```

This is a direct regression check of the existing shared mixed-acquisition
execution/model root after preflight extraction. It is not a proof of the new
queued owner, a new authenticated proof campaign, or a change to historical
qualification pins. No new mutation or relocation campaign was run.

Development logs preserve a missing-macro compile failure, a corrected
test-expectation failure, and the corrected unused-must-use test warning. They
are superseded by the final clean model run, not treated as passes.

Network probes:
```sh
ssh -o BatchMode=yes -o ConnectTimeout=15 mi300x hostname
env GIT_TERMINAL_PROMPT=0 git ls-remote origin refs/heads/codex/r65-runtime-drain-versions
```

Both failed DNS resolution. No remote files, processes or reservations were created.

Minimal/no-default-feature check (`model-minimal.log`):
```sh
env CARGO_INCREMENTAL=0 cargo check --offline -p fe2o3-runtime-model --no-default-features -j 1
```
