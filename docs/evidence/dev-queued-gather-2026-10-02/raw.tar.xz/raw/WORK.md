# Ordered Multi-GPU Gather

Baseline: dd3fad75f7c471b9847de48a8e546b3c3a2cb171.

Scope: prequeue success-ordered compute-backed peer windows into one initialized
PUBLIC DeviceLocal destination, then a dependent whole-allocation D2H. Preserve
untouched bytes and ordered overlap semantics, exact latest-writer dependencies,
whole-owner custody, failure propagation, and bounded final-only progress.

Context, native backend, and pending-readback agents own separate modules. Root
owns explicit backend contract, native witness, builds, hardware cleanup and Git.
Existing launch full-overwrite rules and compute authorities remain unchanged.

No general application authority, whole-adapter formal proof, native concurrency,
performance acceptance, or HIP/HSA parity claim follows from this increment.
