#!/usr/bin/env python3
"""Authenticate historical exact-ELF KFD and arithmetic evidence, without reruns.

Run: python3 -I -B reuse-check.py
The caller must capture this command again after its final source freeze.
This is not current runtime execution or a proof of the changed runtime adapter.
"""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'dd3fad75f7c471b9847de48a8e546b3c3a2cb171'
ARCHIVE = ROOT / 'docs/evidence/dev-native-peer-subranges-2026-10-02/raw.tar.xz'
ARCHIVE_SHA = '27d84a8e8f168c92c8220f0bd641b8b2d5ca7669c12f564288ecee620c72c734'
PINS = {
    'audit-02.json': '72c38a2979a6d4d0042bd9e0fd23e1cf16e3c58f34a2768943335cb794d00e37',
    'attempt-01/build/source-before.json': '4d83fbb42e5018ee0f288d2183498cc5dca346df9615dd3307a29fbb8d83a37b',
    'attempt-01/build/result.json': 'c62f8352334337851aeee819fadfb0b5d63f327b736e3e0e5513bf04fab5bd6a',
    'attempt-01/tests/result.json': '39d710d12f786fcabf19bc45b4e1946a1c01a93b0dddc379e1532890796bb02c',
    'proof/proof-attempt-02/result.json': 'f7f72fad691a14997aa59d0a7d54b840c5a6a95cae3e5b18bf6c7babb2fa49cd',
    'proof/proof-attempt-02/source-before.json': '16b40831c30526a4f831930126bc8844725f89d73e26faaa8f29222cd37f2080',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *args], cwd=ROOT)


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize,
         'run python3 -I -B without optimized assertions')
    need(git('rev-parse', 'HEAD').decode().strip() == BASE, 'exact current baseline')
    need(sha(ARCHIVE.read_bytes()) == ARCHIVE_SHA, 'authenticated accepted archive')
    with tarfile.open(ARCHIVE) as archive:
        members = {member.name: member for member in archive.getmembers()}
        need(len(members) == len(archive.getmembers()), 'unique archive members')

        def raw(name):
            member = members['raw/' + name]
            need(member.isfile(), 'ordinary retained receipt: ' + name)
            return archive.extractfile(member).read()

        def read(name):
            return json.loads(raw(name))

        for path, digest in PINS.items():
            need(sha(raw(path)) == digest, 'exact selected historical receipt: ' + path)
        audit = read('audit-02.json')
        build = read('attempt-01/build/result.json')
        tests = read('attempt-01/tests/result.json')
        need(audit['accepted'] and build['accepted'] and tests['accepted'],
             'selected historical CPU receipts accepted')
        need(audit['cpu']['kfd_passed'] == 1934, 'exact historical KFD count')
        before = read('attempt-01/build/source-before.json')
        need(before == read('attempt-01/build/source-after.json'), 'historical build continuity')

        def selected(path):
            return (path.startswith('crates/')
                    and not path.startswith('crates/fe2o3-runtime/')
                    and not path.startswith('crates/fe2o3-runtime-model/verus/')) \
                or path in ('Cargo.lock', 'Cargo.toml', 'rust-toolchain.toml')

        closure = {path: digest for path, digest in before.items() if selected(path)}
        current = {path for path in git(
            'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
            'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml',
        ).decode().split('\0') if path and selected(path)}
        need(len(closure) == 3499 and current == set(closure), 'exact conservative dependency roster')
        for path, digest in closure.items():
            need(sha((ROOT / path).read_bytes()) == digest, 'unchanged KFD dependency source: ' + path)
        elf = audit['cpu']['library_executables']['fe2o3_kfd']
        emitted = build['results']['executables']['fe2o3_kfd']
        need(all(emitted[key] == elf[key] for key in ('path', 'sha256', 'byte_length'))
             and len(emitted['list']) == len(set(emitted['list'])) == 1934
             and emitted['ignored'] == [], 'exact historical KFD artifact and roster')
        executable = Path(elf['path']).read_bytes()
        need(len(executable) == elf['byte_length'] and sha(executable) == elf['sha256'],
             'current exact historical KFD executable')
        proof = read('proof/proof-attempt-02/result.json')
        proof_sources = read('proof/proof-attempt-02/source-before.json')
        need(proof['accepted'] and proof['full_campaign']
             and len(proof_sources) == 14
             and proof_sources == read('proof/proof-attempt-02/source-after.json'),
             'selected complete arithmetic campaign and source continuity')
        for path, digest in proof_sources.items():
            need(sha((ROOT / path).read_bytes()) == digest, 'unchanged arithmetic input: ' + path)
    print(json.dumps(dict(
        historical_reuse_valid=True, baseline=BASE, controller_sha256=sha(Path(__file__).read_bytes()),
        archive_sha256=ARCHIVE_SHA, receipt_sha256=PINS, kfd_executable=elf,
        kfd_passed=1934, kfd_ignored=0, dependency_source_files=len(closure),
        arithmetic_source_files=len(proof_sources), arithmetic=audit['proof'],
        runtime_execution_reused=False, whole_adapter_verified=False,
        executed_builds=0, executed_tests=0, executed_solvers=0, executed_hardware_commands=0,
    ), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
