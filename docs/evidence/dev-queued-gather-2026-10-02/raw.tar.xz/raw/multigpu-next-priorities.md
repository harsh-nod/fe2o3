# Multi GPU Follow Up Priorities

Read-only source review of the queued-gather candidate identified these remaining
application-useful steps. They are not implemented or qualified by this packet.

1. Gathered frame into queued compute. Context producer_readers.rs currently
   allows queued frame reads for Copy only. Launch still requires coverage by
   the final copied window; backend deferred_compute.rs also limits that coverage
   and requires explicit ancestor dependencies. Reuse the authenticated frame
   and bounded predecessor chain for Read-only consumer aliases, keeping native
   custody deferred until all predecessors succeed and restore original owners.
   Cover gather -> compute -> peer/D2H, released events, final-stream progress,
   overlap/guards, cancellation, failed ancestors and corrupted ranks.
2. A genuine compiled-kernel evidence provider. Public multi-device production
   constructors already exist. The protected verifier and semantic-machine
   providers required by fe2o3-host/worker_v3_verification_admission.rs currently
   have only test implementations. Integrate one actual compiler artifact through
   the existing refining adapter, with substitution, currentness and effects
   negatives and a real two-GPU output oracle. Do not substitute a broader finite
   qualification gate or local integer proof for this production contract.
3. Generated application binding to PUBLIC multi-device allocations. The current
   generated_runtime_invocation.rs targets a single KfdRuntimeBackendV1 and
   generated persistent storage. After the genuine provider exists, retain the
   original move-only evidence/currentness owner through narrow selected-device
   binding. Check device, module, geometry, ranges, aliases, stale evidence and
   unwind; validate two changed batches and explicit original-owner cleanup.

The immediate next implementation is item 1. Items 2 and 3 are production
authority integration, not missing peer-routing constructors.
