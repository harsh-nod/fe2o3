"""Record native assembler executable identity; this is not loader-closure custody."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys


OUT = Path(__file__).resolve().parent
label = sys.argv[1]
if label not in ['before', 'after']:
    raise SystemExit('expected before or after')
rows = []
for name in ['/usr/lib/llvm-18/bin/llvm-mc', '/opt/rocm/llvm/bin/llvm-mc']:
    path = Path(name).resolve(strict=True)
    data = path.read_bytes()
    result = subprocess.run([str(path), '--version'], check=True, capture_output=True,
                            timeout=30, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'})
    rows.append({'configured': name, 'resolved': str(path), 'bytes': len(data),
                 'sha256': hashlib.sha256(data).hexdigest(),
                 'version': result.stdout.decode(), 'stderr': result.stderr.decode()})
record = {'measured': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'tools': rows,
          'native_loader_closure_authenticated': False}
with (OUT / ('native-tools-' + label + '.json')).open('x') as output:
    json.dump(record, output, indent=2, sort_keys=True)
    output.write('\n')
print(json.dumps(record, sort_keys=True))
