"""Replay the repository's complete source-control workflow, without a solver."""

import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
WORKFLOW = ROOT / '.github/workflows/runtime-component-source-guards.yml'


def main():
    label, = sys.argv[1:]
    raw = WORKFLOW.read_bytes()
    steps = yaml.safe_load(raw)['jobs']['source-controls']['steps']
    commands = [(step['name'], shlex.split(line))
                for step in steps if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    assert len(commands) == 32
    assert all(command[:3] == ['python3', '-I', '-B'] for _, command in commands)
    receipt_path = OUT / (label + '.json')
    assert not receipt_path.exists()
    rows = []
    for index, (step, command) in enumerate(commands, 1):
        name = label + '-' + str(index).zfill(2)
        result = subprocess.run([sys.executable, '-I', '-B', str(OUT / 'capture.py'),
                                 name, '300s', *command], check=False)
        rows.append({'step': step, 'capture': name, 'command': command, 'exit': result.returncode})
    unchanged = raw == WORKFLOW.read_bytes()
    accepted = unchanged and all(row['exit'] == 0 for row in rows)
    receipt = {'workflow_sha256': hashlib.sha256(raw).hexdigest(),
               'workflow_unchanged': unchanged, 'commands': rows, 'accepted': accepted}
    with receipt_path.open('x') as stream:
        stream.write(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'accepted': accepted, 'commands': len(rows)}), flush=True)
    return 0 if accepted else 1


if __name__ == '__main__':
    sys.exit(main())
