"""Remove only measured obsolete rlibs after the complete Cargo matrix closes."""

import datetime
import hashlib
import json
from pathlib import Path
import stat

RAW = Path(__file__).resolve().parent
PARENT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps')
PLAN_SHA = '0c0850f75282d463e1a0bc57f1cba851c851c0bd516a840495a196f650dba7a3'
data = (RAW / 'stale-cache-plan.json').read_bytes()
assert hashlib.sha256(data).hexdigest() == PLAN_SHA
plan = json.loads(data)
assert plan['allowed_parent'] == str(PARENT) and plan['count'] == len(plan['files']) == 25
assert plan['deletion_performed'] is False
for name in ['build-01', 'roster-01', 'cpu-01', 'doc-01', 'llvm18-01', 'llvm22-01',
             'clippy-01', 'check-no-default-01', 'check-host-01']:
    receipt = json.loads((RAW / name / 'receipt.json').read_text())
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True
artifacts = set()
for name in ['diagnostic-build-01', 'build-01']:
    stream = (RAW / name / 'stdout').read_bytes()
    receipt = json.loads((RAW / name / 'receipt.json').read_text())
    assert hashlib.sha256(stream).hexdigest() == receipt['stdout_sha256']
    for line in stream.splitlines():
        row = json.loads(line)
        if row.get('reason') == 'compiler-artifact':
            artifacts.update(row['filenames'])
            if row.get('executable'):
                artifacts.add(row['executable'])


def validate(row):
    path = Path(row['path'])
    assert path.parent == PARENT and path.resolve() == path and not path.is_symlink()
    assert path.name.startswith(('libfe2o3_', 'libdialect_')) and path.suffix == '.rlib'
    assert str(path) not in artifacts and 'kfd' not in path.name
    metadata = path.stat()
    assert stat.S_ISREG(metadata.st_mode)
    for field, value in [('st_size', row['size_bytes']), ('st_mtime_ns', row['mtime_ns']),
                         ('st_ctime_ns', row['ctime_ns']), ('st_dev', row['device']),
                         ('st_ino', row['inode']), ('st_nlink', 1), ('st_mode', row['mode'])]:
        assert getattr(metadata, field) == value, (path, field)
    payload = path.read_bytes()
    assert payload.startswith(b'!<arch>\n') and hashlib.sha256(payload).hexdigest() == row['sha256']
    return path


assert len({row['path'] for row in plan['files']}) == 25
for row in plan['files']:
    validate(row)
with (RAW / 'cache-cleanup.jsonl').open('x') as output:
    for row in plan['files']:
        path = validate(row)
        path.unlink()
        assert not path.exists()
        record = {'path': str(path), 'sha256': row['sha256'], 'bytes': row['size_bytes'],
                  'removed': True, 'time': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        output.write(json.dumps(record, sort_keys=True) + '\n')
        output.flush()
print(json.dumps({'removed': 25, 'bytes': plan['total_size_bytes'],
                  'allocated_bytes': plan['total_allocated_bytes'],
                  'scope': 'obsolete owned rlib cache only; no executables or evidence'}))
