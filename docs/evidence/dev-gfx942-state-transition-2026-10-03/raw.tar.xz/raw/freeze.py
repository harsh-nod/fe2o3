"""Record exact staged candidate bytes without including documentation archives."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
SCOPE = ['crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT)


assert not git('diff', '--name-only', '--', *SCOPE)
assert not git('ls-files', '--others', '--exclude-standard', '--', *SCOPE)
patch = git('diff', '--cached', '--binary', 'HEAD', '--', *SCOPE)
assert patch
with (OUT / 'candidate.patch').open('xb') as stream:
    stream.write(patch)
paths = git('diff', '--cached', '--name-only', '-z', 'HEAD', '--', *SCOPE).split(b'\0')
rows = {}
for raw in paths:
    if not raw:
        continue
    path = raw.decode()
    data = (ROOT / path).read_bytes()
    assert data == git('show', ':' + path)
    rows[path] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
result = {'base': git('rev-parse', 'HEAD').decode().strip(),
          'patch_sha256': hashlib.sha256(patch).hexdigest(), 'sources': rows}
with (OUT / 'candidate.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(result, sort_keys=True))
