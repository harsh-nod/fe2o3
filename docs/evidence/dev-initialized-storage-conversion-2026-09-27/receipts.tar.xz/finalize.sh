#!/usr/bin/env bash
set -eu
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-storage-conversion-20260927-4WEoJ3jP
git rev-parse HEAD >"$out/source-commit.txt"
git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD >"$out/source-signature.log" 2>&1
git show --format=fuller --stat HEAD >"$out/source-commit.log"
git show --format= --binary HEAD >"$out/committed-source.patch"
cmp "$out/final-source.patch" "$out/committed-source.patch" >"$out/committed-patch-check.log" 2>&1
sha256sum --check "$out/inputs.final.sha256" >"$out/committed-input-check.log" 2>&1
git diff --exit-code HEAD -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model >"$out/committed-source-clean.log"
date -u +%FT%TZ >"$out/frozen-at.txt"
printf 'Signed source and committed input identities verified; raw packet frozen.\n'
