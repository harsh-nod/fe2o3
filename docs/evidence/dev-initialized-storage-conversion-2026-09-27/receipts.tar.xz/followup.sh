#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
out=/home/harsh/.codex-tmp/fe2o3-storage-conversion-20260927-4WEoJ3jP
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
run() {
    local name=$1
    shift
    printf '%s START %s\n' "$(date -u +%FT%TZ)" "$name"
    "$@" >"$out/$name.log" 2>&1
    local result=$?
    printf '%s END %s exit=%s\n' "$(date -u +%FT%TZ)" "$name" "$result" | tee -a "$out/followup-results.txt"
}
run corrected-persistent-cancel cargo test --offline -p fe2o3-kfd --lib persistent_cancel
run final-conversion cargo test --offline -p fe2o3-kfd --lib initialized_storage_conversion
run final-replay cargo test --offline -p fe2o3-kfd --lib persistent_write_replay_replaces_stale_initialization
run layout cargo test --offline -p fe2o3-kfd --lib persistent_owner_and_queue_layouts -- --nocapture
run runtime-minimal cargo check --offline -p fe2o3-runtime --no-default-features --lib
run runtime-doc cargo test --offline -p fe2o3-runtime --all-features --doc
run final-kfd-clippy cargo clippy --offline -p fe2o3-kfd --all-features --all-targets -- -D warnings
run final-fmt cargo fmt --all -- --check
run final-whitespace git diff --check
printf '%s FOLLOWUP COMPLETE\n' "$(date -u +%FT%TZ)"
