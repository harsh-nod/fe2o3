#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
out=/home/harsh/.codex-tmp/fe2o3-storage-conversion-20260927-4WEoJ3jP
date -u +%FT%TZ >"$out/observation-time.txt"
rustc --version --verbose >"$out/rustc.txt" 2>&1
cargo --version >"$out/cargo.txt" 2>&1
ssh -o BatchMode=yes -o ConnectTimeout=8 mi300x hostname >"$out/mi300x-probe.log" 2>&1
printf 'mi300x probe exit=%s\n' "$?" >>"$out/probe-results.txt"
gh issue view 182 --repo harsh-nod/fe2o3 --json number,title,state,updatedAt,url >"$out/issue-182.json" 2>"$out/issue-182-error.log"
printf 'issue readback exit=%s\n' "$?" >>"$out/probe-results.txt"
sha256sum target/debug/deps/fe2o3_kfd-9280442e7aa71d90 >"$out/final-kfd-test-binary.sha256"
