# Remaining Runtime Bridge

This checkpoint implements the direct-KFD native conversion and fixes stale
initialization replay. It does not install the high-level runtime consumer.
Issue #182 and the full HIP/HSA parity goal remain open.

The read-only runtime review identifies the following connected work:

1. Add a distinct InitializedStorage source and typed storage container. Ready
   admission must inspect the actual sealed native input and exact full extent.
   A raw native owner is only a conversion candidate, never ready authority.
2. Admit candidates only under the existing full-range single or distinct R/R/W
   shape and existing device, lifetime, stream and explicit-dependency rules.
   Runtime flags, producer success and stale CPU shadow are not native evidence.
3. Convert after successful peer/explicit dependencies and native FIFO ordering,
   before three-binding readiness rejection. Recompute source admission after
   conversion. Observational poll/gate paths remain free of conversion effects.
4. Preallocate the input box before extracting the native Device owner. Reuse
   that exact original box as retry restoration storage. Restore before diagnostic
   formatting. Root opaque terminal promotion custody without allocating.
5. Wrap the new progression stage in an outer unwind guard that reinserts the
   exact pending submission before poisoning. The existing publication guard is
   later in progression and cannot protect this new stage.
6. Preallocate a typed input restoration shell for every new-source binding,
   including read-only A/B. Whole-roster preflight must validate exact in-flight
   slots, returned input variants and shells before moving any owner. Cancellation
   preserves InitializedStorage; genuine completion may return AfterDispatch.
7. Update source-specific snapshots, extraction, retained-control replacement,
   normalization/release and terminal custody. Never upload stale CPU shadow to
   manufacture initialization or downgrade the returned authority.
8. Qualify missing-shell/corrupt-slot failures at each ordinal and gate success
   without backing coverage. Keep scripted scheduling tests separate from genuine
   native-owner tests and eventual MI300X execution.

Keep pending cooperative-peer public admission closed until its independent
ancestry-authenticated deferred validation and producer-retain integration is
implemented and qualified. Completed-peer conversion does not establish that
contract. A native full-range-write initialization witness is also separate:
ordinary compute completion does not prove that an initially cold entire buffer
was written.

The broader goal still includes A0-A7, Worker V3 production application,
device-language/typed async coverage, full stream/event/memory and multi-device
contracts, machine-code-refined atomic/collective support, profiling and matched
HIP/HSA measurements. These are not accepted by this checkpoint.

## Fallback Compatibility

The ordinary single/partial-read path currently downloads native bytes through
`synchronize_sdma_shadow_v1` before materialization. It is freshness-preserving,
though synchronous and expensive; do not replace it with blanket rejection.
Device-local partial Write/ReadWrite is already unsupported by the ordinary
snapshot path and must not gain accidental admission.

Fresh native DeviceLocal allocation runs `zero_sdma_range_v1`. Exact full-page
zeroed backing is therefore a valid conversion candidate without a prior user
copy, dirty-shadow flag or digest. Candidate selection must not require any of
those. Partial bindings and logical/physical mismatches remain outside full-range
conversion. Initialized storage still must be established by the actual native
conversion, not inferred from allocation or completion success alone.

Before runtime integration, add a typed ineligibility refusal to the native
conversion API. Its current retryable preflight error does not distinguish
missing coverage from wrong scope. Do not parse diagnostic strings or treat all
retryable errors as an optimization miss. A true NotEligible result may restore
the owner and use the existing single-Read synchronized fallback; ownership and
currentness failures must propagate with custody retained.

Exclude candidates from early ordered-successor recipe reuse. That path skips
shadow synchronization; guard read-capable dirty-shadow bindings defensively,
without rejecting clean host-visible write-only reuse. The review did not
establish a currently reachable stale-shadow publication bug under the existing
custody checks.
