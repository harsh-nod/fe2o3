#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
out=/home/harsh/.codex-tmp/fe2o3-storage-conversion-20260927-4WEoJ3jP
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
run() {
    local name=$1
    shift
    printf '%s START %s\n' "$(date -u +%FT%TZ)" "$name"
    "$@" >"$out/$name.log" 2>&1
    local result=$?
    printf '%s END %s exit=%s\n' "$(date -u +%FT%TZ)" "$name" "$result" | tee -a "$out/results.txt"
}
git rev-parse HEAD >"$out/base.txt"
git diff --binary HEAD >"$out/source.patch"
git ls-files -z -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model | xargs -0 sha256sum >"$out/inputs.before.sha256"
sha256sum crates/fe2o3-kfd/src/queue_live/initialized_storage.rs crates/fe2o3-kfd/src/queue_live/construction_primary/integration_initialized_storage_tests.rs >>"$out/inputs.before.sha256"
run conversion cargo test --offline -p fe2o3-kfd --lib initialized_storage_conversion
run replay cargo test --offline -p fe2o3-kfd --lib persistent_write_replay_replaces_stale_initialization
run cancellation cargo test --offline -p fe2o3-kfd --lib cancellation
run kfd cargo test --offline -p fe2o3-kfd --lib
run kfd-doc cargo test --offline -p fe2o3-kfd --doc
run runtime-check cargo check --offline -p fe2o3-runtime --all-features --all-targets
run runtime cargo test --offline -p fe2o3-runtime --all-features --lib
run kfd-clippy cargo clippy --offline -p fe2o3-kfd --all-features --all-targets -- -D warnings
run runtime-clippy cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
run fmt cargo fmt --all -- --check
run whitespace git diff --check
run continuity sha256sum --check "$out/inputs.before.sha256"
printf '%s QUALIFICATION COMPLETE\n' "$(date -u +%FT%TZ)"
