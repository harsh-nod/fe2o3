# Qualification Source Boundaries

The KFD production source was frozen before `qualify.sh` started at 2026-09-27T06:06:03Z.
All ten conversion tests, the stale-replay regression and fifteen cancellation
tests passed before the full KFD suite began at 06:06:14Z.

While that suite was running, the high-level runtime's two exhaustive matches
were updated for the new public native input variant. This companion does not
install deferred conversion. Single-input unexpected storage-origin custody is
retained terminally; the three-binding whole-roster validator continues to reject
it before any output is moved. It is not relabeled as compute replay.

The companion was complete before 06:13:35Z, before any runtime build in the
qualification script. Its SHA256 is:

```
943abfad9a9b22d1160224ad754896484e5c7b0930450ad2e4580dd0384a1b53  crates/fe2o3-runtime/src/kfd_backend.rs
```

The first full KFD run also exposed two existing tests that explicitly accepted
initialization mismatches during single-input cancellation. Their expectations
were updated to the stricter production contract, and an actual constructed
single/three-binding storage-origin cancellation test was added. This is a
test-only revision of `integration_persistent_cancel_tests.rs`, after the initial
full test binary was built. Retain both initial failures and subsequent reruns.

Consequently the original all-input continuity check is expected to reject the
runtime companion and this test file. Retain that result, and separately verify
the exact final input set.
The KFD crate does not depend on the runtime crate; its production source, runtime-model
dependency and embedded runtime fixture files were not changed during the run.
Do not describe the original all-input check as passing.

After that initial script completed, strict KFD Clippy's sole diagnostic was
fixed by collapsing a nested conditional in the new conversion test driver.
This third revision is test-only, has its own `conversion-tests.sha256` pin,
and is included in the follow-up conversion tests and strict Clippy rerun.
The original continuity log predates this lint fix; the final audit accounts
for all three revised files without replacing the original results.
