#!/usr/bin/env bash
set -eu
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-storage-conversion-20260927-4WEoJ3jP
rg -v '  crates/fe2o3-runtime/src/kfd_backend.rs$|  crates/fe2o3-kfd/src/queue_live/construction_auxiliary/integration_persistent_cancel_tests.rs$|  crates/fe2o3-kfd/src/queue_live/construction_primary/integration_initialized_storage_tests.rs$' "$out/inputs.before.sha256" >"$out/unchanged.sha256"
sha256sum --check "$out/unchanged.sha256" >"$out/unchanged-check.log" 2>&1
sha256sum --check "$out/runtime-companion.sha256" >"$out/runtime-companion-check.log" 2>&1
sha256sum --check "$out/cancellation-tests.sha256" >"$out/cancellation-tests-check.log" 2>&1
sha256sum --check "$out/conversion-tests.sha256" >"$out/conversion-tests-check.log" 2>&1
cat "$out/unchanged.sha256" "$out/runtime-companion.sha256" "$out/cancellation-tests.sha256" "$out/conversion-tests.sha256" | LC_ALL=C sort -u >"$out/inputs.final.sha256"
sha256sum --check "$out/inputs.final.sha256" >"$out/final-input-check.log" 2>&1
git diff --binary HEAD >"$out/final-source.patch"
git diff --check HEAD >"$out/final-whitespace-complete.log" 2>&1
git diff --exit-code HEAD -- crates/fe2o3-runtime-model >"$out/model-source-unchanged.log"
git diff --exit-code HEAD -- crates/fe2o3-kfd/src/target_debug_telemetry_v2.rs crates/fe2o3-runtime/src/authorized_execution.rs >"$out/baseline-failure-sources-unchanged.log"
printf 'Final input identities verified; runtime companion boundary recorded separately.\n'
