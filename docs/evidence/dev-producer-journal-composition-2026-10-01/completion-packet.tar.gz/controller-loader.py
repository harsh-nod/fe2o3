"""Authenticate and reuse the existing managed-process controller unchanged."""
import hashlib
from pathlib import Path
import signal
import sys
import types


SOURCE = Path("/home/harsh/.codex-tmp/fe2o3-r61-execution/crates/fe2o3-runtime-model/verus/check-journal-issuance.py")
SHA256 = "36d5e0641300bf2568884ec4c440c668477a4b24a07ee95273a91eab34659480"


def load():
    content = SOURCE.read_bytes()
    if hashlib.sha256(content).hexdigest() != SHA256:
        raise ValueError("managed-process controller source changed")
    module = types.ModuleType("cpu_pinned_process_controller")
    module.__file__ = str(SOURCE)
    sys.modules[module.__name__] = module
    exec(compile(content, str(SOURCE), "exec"), module.__dict__)
    for signum in module.SIGNALS:
        signal.signal(signum, module.interrupted)
    signal.pthread_sigmask(signal.SIG_UNBLOCK, module.SIGNALS)
    return module


def archive(folder):
    content = SOURCE.read_bytes()
    if hashlib.sha256(content).hexdigest() != SHA256:
        raise ValueError("managed-process controller source changed")
    with (folder / "process-controller.py").open("xb") as stream:
        stream.write(content)
    with (folder / "controller-loader.py").open("xb") as stream:
        stream.write(Path(__file__).read_bytes())
