#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-controller-proof-20261004-wjOKHJ44
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 \
    --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical \
    --no-run > "$scratch/test-build.log" 2>&1
CARGO_TARGET_DIR=target/qualification-static-deployment/cargo \
    cargo +nightly-2026-04-03 rustc --locked --offline --release --target x86_64-unknown-linux-musl \
    -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --example retained-fill-proof-controller-fixture -- \
    -C target-feature=+crt-static -C relocation-model=static -C link-arg=-static -C link-arg=-no-pie \
    -C link-arg=-Wl,-e,fe2o3_secure_start_v1 > "$scratch/static-build.log" 2>&1
