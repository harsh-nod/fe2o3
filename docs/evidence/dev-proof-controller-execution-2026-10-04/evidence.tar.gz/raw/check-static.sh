#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-controller-proof-20261004-wjOKHJ44
readonly binary=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/examples/retained-fill-proof-controller-fixture
readelf -WhlWdWs "$binary" > "$scratch/static-elf-final.txt"
readonly entry=$(awk '/Entry point address:/ {print $4}' "$scratch/static-elf-final.txt")
readonly symbol=$(awk '$8 == "fe2o3_secure_start_v1" {print "0x" $2}' "$scratch/static-elf-final.txt")
[[ $((entry)) == $((symbol)) ]]
rg -q 'Type: +EXEC ' "$scratch/static-elf-final.txt"
rg -q 'GNU_STACK .* RW ' "$scratch/static-elf-final.txt"
if rg 'INTERP|DYNAMIC|NEEDED|RPATH|RUNPATH' "$scratch/static-elf-final.txt"; then exit 1; fi
[[ -z $(nm -u "$binary") ]]
printf 'PASS: static EXEC, secure entry %s, nonexecutable stack, no dynamic loader/dependencies/undefined symbols\n' "$entry"
sha256sum "$binary"
