#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-controller-proof-20261004-wjOKHJ44
readonly evidence="$scratch/evidence"
readonly destination="$repo/docs/evidence/dev-proof-controller-execution-2026-10-04"
cd "$repo"
git diff --check
sha256sum --check "$scratch/sources.sha256" > "$scratch/final-source-check.log"
sha256sum --check "$scratch/binaries.sha256" > "$scratch/final-binary-check.log"
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$scratch/allowed-signers" verify-commit HEAD > "$scratch/source-signature.log" 2>&1
git show --format= --binary HEAD > "$scratch/committed.patch"
cmp "$scratch/qualified.patch" "$scratch/committed.patch"
git show --format=fuller --no-patch HEAD > "$scratch/source-commit.txt"
mkdir -p "$evidence/raw" "$evidence/captures" "$destination"
cp "$scratch"/*.log "$scratch"/*.sh "$scratch"/*.sha256 "$scratch"/*.patch \
    "$scratch/commands.txt" "$scratch/source-commit.txt" "$scratch/allowed-signers" \
    "$scratch/static-elf-final.txt" "$evidence/raw/"
for name in inputs-2 good-final worker-final runtime-final payload-final cancel-final; do
    cp -r "$scratch/$name" "$evidence/captures/"
done
cd "$evidence"
find raw captures -type f -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum --check MANIFEST.sha256 > "$scratch/archive-manifest-check.log"
tar -czf "$destination/evidence.tar.gz" MANIFEST.sha256 raw captures
tar -df "$destination/evidence.tar.gz" -z
sha256sum "$destination/evidence.tar.gz" "$scratch/qualified.patch"
