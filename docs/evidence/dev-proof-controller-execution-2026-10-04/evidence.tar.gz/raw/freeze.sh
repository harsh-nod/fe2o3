#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-controller-proof-20261004-wjOKHJ44
cd "$repo"
git diff --cached --check
git diff --cached --binary > "$scratch/qualified.patch"
git diff --cached --name-only -z | xargs -0 sha256sum > "$scratch/sources.sha256"
sha256sum target/debug/deps/worker_v3_load_envelope_vertical-46ee6c58a0d017c5 \
    target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/examples/retained-fill-proof-controller-fixture \
    target/qualification-native-workers/fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715/fe2o3-llvm-link-worker \
    > "$scratch/binaries.sha256"
sha256sum --check "$scratch/sources.sha256"
sha256sum --check "$scratch/binaries.sha256"
rustfmt +nightly-2026-04-03 --edition 2024 --check \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_controller.rs \
    crates/cargo-fe2o3/tests/fixtures/proof_controller_protocol.rs \
    crates/cargo-fe2o3/tests/fixtures/retained_fill_proof_controller_fixture.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs \
    crates/fe2o3-verifier/src/functional_refinement_process_tree_v1_linux.rs
