#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-controller-proof-20261004-wjOKHJ44
readonly run=${1:?fresh run label}
readonly mode=${2:?prepare or case}
readonly binary=${3:?exact test binary}
readonly worker="$repo/target/qualification-native-workers/fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715"
readonly worker_id="$(<"$worker/fe2o3-worker-build-id.txt")"
readonly capture="$scratch/$run"
readonly inputs="$scratch/${4:-inputs}"
readonly fixture="$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/examples/retained-fill-proof-controller-fixture"
mkdir -m 700 "$scratch/$run-tmp" "$scratch/$run-runtime"
if [[ $mode == prepare ]]; then
    args=(/usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups --inh-caps=-all --ambient-caps=-all --bounding-set=-all)
    test_name=conditional_fill_controller::prepare_fixed_controller_inputs
else
    args=()
    test_name=conditional_fill_controller::root_fixed_controller_executes_and_retains_fill
fi
status=0
timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" "${args[@]}" /usr/bin/env \
    TMPDIR="$scratch/$run-tmp" XDG_RUNTIME_DIR="$scratch/$run-runtime" \
    FE2O3_TEST_REAL_WORKER="$worker/fe2o3-llvm-link-worker" \
    FE2O3_TEST_REAL_WORKER_BUILD_ID="$worker_id" FE2O3_TEST_REAL_LLVM_BUILD_ID=7.2.4 \
    FE2O3_TEST_HSACO_WORKER_FIXTURE="$repo/target/debug/fe2o3-worker-v3-hsaco-fixture" \
    FE2O3_PROOF_CONTROLLER_INPUTS="$inputs" FE2O3_PROOF_CONTROLLER_CAPTURE="$capture" \
    FE2O3_PROOF_CONTROLLER_CASE="$mode" FE2O3_PROOF_CONTROLLER_FIXTURE="$fixture" \
    "$binary" --exact "$test_name" --ignored --nocapture --test-threads=1 \
    > "$capture.log" 2>&1 || status=$?
if [[ $mode != prepare ]]; then
    /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
        "$scratch/check-namespace.sh" "$capture" > "$capture-namespace.log" 2>&1
fi
exit "$status"
