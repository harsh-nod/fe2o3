#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-controller-proof-20261004-wjOKHJ44
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly binary="$repo/target/debug/deps/worker_v3_load_envelope_vertical-46ee6c58a0d017c5"
status=0
for case in good worker runtime payload cancel; do
    result=0
    bash "$scratch/run.sh" "$case-final" "$case" "$binary" inputs-2 || result=$?
    printf '%s exit=%s\n' "$case" "$result"
    if [[ $result != 0 ]]; then
        status=1
    fi
done
exit "$status"
