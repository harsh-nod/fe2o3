"""Development diagnostic collection only, not a qualification campaign."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

repo = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
scratch = Path('/home/harsh/.codex-tmp/fe2o3-fill-analysis-20261003-JUwXyS')
spec = importlib.util.spec_from_file_location('dispatch', repo / 'crates/fe2o3-kernel-analysis/verus/gfx942_fill_dispatch_check.py')
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)
before = check.snapshot()
owner = types.ModuleType('discovery_owned_process')
owner.__file__ = str(repo / check.support.OWNER)
sys.modules[owner.__name__] = owner
exec(compile(before[str(check.support.OWNER)], owner.__file__, 'exec'), owner.__dict__)
out = scratch / 'development-mutants'
out.mkdir()
(out / 'tmp').mkdir()
env = dict(os.environ, VERUS_Z3_PATH='/home/harsh/.local/opt/verus/z3', TMPDIR=str(out / 'tmp'))
for name, body, target in check.mutations(before[str(check.BODY)].decode('ascii')):
    stage = out / (name + '-source')
    for path in [check.PROOF, check.BODY, check.wave.PROOF, check.wave.BODY]:
        dest = stage / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(body.encode('ascii') if path == check.BODY else before[str(path)])
    command = ['/usr/bin/timeout', '--foreground', '--kill-after=5', '120', '/home/harsh/.local/opt/verus/verus',
               '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating', '--output-json',
               '--error-format=json', '--no-report-long-running', '--num-threads', '1', '--multiple-errors', '1',
               '--verify-function', '*' + target, '--verify-root', '--no-auto-recommends-check', str(stage / check.PROOF)]
    status, stdout, stderr = owner.run_owned(command, 130, out / name, env)
    result = json.loads(stdout)['verification-results']
    errors = []
    for line in stderr.splitlines():
        row = json.loads(line)
        if row.get('level') == 'error':
            errors.append({'message': row['message'], 'spans': [
                {k: s.get(k) for k in ['is_primary', 'label', 'line_start', 'column_start', 'line_end', 'column_end']}
                for s in row.get('spans', [])]})
    print(json.dumps(dict(name=name, status=status, result=result, errors=errors)), flush=True)
