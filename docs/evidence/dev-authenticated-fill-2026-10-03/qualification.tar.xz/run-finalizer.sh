#!/bin/bash
set -euo pipefail
readonly owned=/tmp/fe2o3-fill-analysis-20261003-up46kY
readonly run="$owned/${1:?fresh run name}"
mkdir -m 700 "$run"
mkdir -m 700 "$run/tmp"
readonly worker_build_id="$(<"$owned/build/fe2o3-worker-build-id.txt")"
sha256sum "$owned/finalizer-test" "$owned/build/fe2o3-llvm-link-worker" >"$run/executables.sha256"
env TMPDIR="$run/tmp" FE2O3_TEST_REAL_WORKER="$owned/build/fe2o3-llvm-link-worker" \
  FE2O3_TEST_REAL_WORKER_BUILD_ID="$worker_build_id" \
  FE2O3_TEST_REAL_LLVM_BUILD_ID=7.2.4 FE2O3_FILL_FINALIZER_CAPTURE="$run" \
  timeout --kill-after=15s 300s "$owned/finalizer-test" \
  conditional_fill_analysis::genuine_conditional_handoff_reaches_finalizer_and_authenticated_fill_model \
  --ignored --exact --nocapture --test-threads=1 >"$run/test.log" 2>&1
test -z "$(ls -A "$run/tmp")"
