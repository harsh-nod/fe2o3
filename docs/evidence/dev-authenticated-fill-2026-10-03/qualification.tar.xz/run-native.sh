#!/bin/bash
set -euo pipefail
readonly owned=/tmp/fe2o3-fill-analysis-20261003-up46kY
readonly run="$owned/${1:?fresh run name}"
mkdir -m 700 "$run"
sha256sum "$owned/authenticated-fill-analysis" "$owned/build/fe2o3-llvm-link-worker" >"$run/executables.sha256"
env FE2O3_MACHINE_EFFECT_NATIVE_WORKER="$owned/build/fe2o3-llvm-link-worker" \
  FE2O3_FILL_ANALYSIS_HSACO="$owned/${2:-analysis-fill.hsaco}" \
  FE2O3_FILL_ANALYSIS_CAPTURE="$run" \
  timeout --kill-after=10s 180s "$owned/authenticated-fill-analysis" \
  native_authenticated_fill_analysis_retains_exact_model_and_dispatch \
  --ignored --exact --nocapture --test-threads=1 >"$run/test.log" 2>&1
