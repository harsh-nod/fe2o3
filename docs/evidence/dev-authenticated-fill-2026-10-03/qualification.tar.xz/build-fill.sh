#!/bin/bash
set -euo pipefail
cd /tmp/fe2o3-fill-analysis-20261003-up46kY
export LC_ALL=C SOURCE_DATE_EPOCH=0
/opt/rocm-7.2.4/lib/llvm/bin/clang --target=amdgcn-amd-amdhsa \
  -mcpu=gfx942:xnack- -nogpulib -O2 -c kernel.ll -o analysis-fill.o
/opt/rocm-7.2.4/lib/llvm/bin/ld.lld --shared -Bsymbolic --no-undefined \
  --export-dynamic --build-id=none --nostdlib --no-dependent-libraries \
  --fatal-warnings --threads=1 --undefined=fill_write_only \
  --undefined=fill_write_only.kd analysis-fill.o -o analysis-fill.hsaco
sha256sum kernel.ll analysis-fill.hsaco >fill.sha256
readelf -d -S -l analysis-fill.hsaco >fill-elf.txt
