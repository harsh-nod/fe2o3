#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-analysis-20261003-JUwXyS
readonly verus=/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus
python3 -I -B crates/fe2o3-kernel-analysis/verus/gfx942_fill_dispatch_check.py \
  --verus "$verus" --output "$scratch/qualified-dispatch" >"$scratch/dispatch-campaign.log" 2>&1
python3 -I -B crates/fe2o3-kernel-analysis/verus/gfx942_fill_wave_check.py \
  --verus "$verus" --output "$scratch/qualified-wave" >"$scratch/wave-campaign.log" 2>&1
