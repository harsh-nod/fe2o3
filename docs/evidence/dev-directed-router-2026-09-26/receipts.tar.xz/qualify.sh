#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
receipts=/home/harsh/.codex-tmp/fe2o3-directed-router-20260926-sebfAFFD
run() {
    name=$1
    shift
    printf '%s: %s\n' "$name" "$*"
    "$@" >"$receipts/$name.log" 2>&1
    status=$?
    printf '%s exit=%s\n' "$name" "$status" | tee -a "$receipts/results.txt"
    tail -8 "$receipts/$name.log"
}
sha256sum crates/fe2o3-runtime/src/kfd_backend.rs \
    crates/fe2o3-runtime/src/kfd_backend/cooperative_directed.rs \
    crates/fe2o3-runtime/src/kfd_backend/cooperative_sdma.rs \
    crates/fe2o3-runtime/src/kfd_backend/native_reconcile.rs \
    crates/fe2o3-runtime/src/kfd_backend/tests/cooperative_directed_tests.rs \
    crates/fe2o3-runtime/src/kfd_backend/tests/cooperative_sdma_tests.rs >"$receipts/source.sha256"
run focused-final cargo test --offline -p fe2o3-runtime --all-features --lib directed_router -- --test-threads=1
run runtime-final cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=1
run doctests-final cargo test --offline -p fe2o3-runtime --all-features --doc
run clippy-final cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
run minimal-final cargo check --offline -p fe2o3-runtime --no-default-features
run fmt-final cargo fmt --all -- --check
run continuity-final sha256sum -c "$receipts/source.sha256"
run whitespace-final git diff --check
