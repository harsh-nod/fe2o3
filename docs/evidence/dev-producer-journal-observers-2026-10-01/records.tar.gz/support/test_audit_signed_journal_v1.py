#!/usr/bin/env python3
"""Small archive, roster and saved-census rejection controls; no full audit launch."""
import copy
from pathlib import Path
import types
import unittest

PATH = Path(__file__).resolve().parent / "audit_signed_journal_v1.py"
a = types.ModuleType("journal_audit_controls")
a.__file__ = str(PATH)
exec(compile(PATH.read_bytes(), str(PATH), "exec"), a.__dict__)


class AuditControls(unittest.TestCase):
    def test_exact_archive_join(self):
        pins = {"/ordinary/source.py": "a" * 64}
        a.archive_join({"/ordinary/source.py": {"sha256": "a" * 64, "archive": "raw-helpers/ordinary/source.py.source"}}, pins)

    def test_archive_missing_extra_wrong_hash_or_alias_rejected(self):
        pins = {"/ordinary/source.py": "a" * 64}
        good = {"/ordinary/source.py": {"sha256": "a" * 64, "archive": "raw-helpers/ordinary/source.py.source"}}
        for change in ("missing", "extra", "wrong-hash", "wrong-path"):
            index = copy.deepcopy(good)
            if change == "missing":
                index.clear()
            elif change == "extra":
                index["/extra.py"] = dict(next(iter(good.values())))
            elif change == "wrong-hash":
                index["/ordinary/source.py"]["sha256"] = "b" * 64
            else:
                index["/ordinary/source.py"]["archive"] = "elsewhere.source"
            with self.subTest(change=change), self.assertRaises(ValueError):
                a.archive_join(index, pins)

    def test_saved_exact_twenty_three_groups(self):
        groups = list(range(100, 123))
        a.saved_census({"all_recorded_groups_absent": True, "namespace": {"id": 1}, "recorded_groups": groups,
                        "members": [], "uncertain": []}, {"id": 1}, groups)

    def test_saved_census_duplicates_wrong_namespace_live_or_uncertain_rejected(self):
        groups = list(range(100, 123))
        good = {"all_recorded_groups_absent": True, "namespace": {"id": 1}, "recorded_groups": groups,
                "members": [], "uncertain": []}
        for key, value in (("namespace", {"id": 2}), ("members", [1]), ("uncertain", [1]),
                           ("all_recorded_groups_absent", 1), ("recorded_groups", groups[:-1])):
            with self.subTest(key=key), self.assertRaises(ValueError):
                a.saved_census(dict(good, **{key: value}), {"id": 1}, groups)
        duplicate = groups[:-1] + [groups[0]]
        with self.assertRaises(ValueError):
            a.saved_census(dict(good, recorded_groups=duplicate), {"id": 1}, duplicate)

    def test_complete_actual_stage_roster_shape(self):
        commands = [{"name": str(index)} for index in range(23)]
        rows = [dict(row, accepted=True, group_absent=True, owned_launch_attempted=True) for row in commands]
        a.stage_roster(commands, rows)
        for changed in (rows[:-1], rows + [rows[-1]], list(reversed(rows))):
            with self.assertRaises(ValueError):
                a.stage_roster(commands, changed)

    def test_any_failed_unlaunched_or_open_group_rejected(self):
        commands = [{"name": str(index)} for index in range(23)]
        rows = [dict(row, accepted=True, group_absent=True, owned_launch_attempted=True) for row in commands]
        for key in ("accepted", "group_absent", "owned_launch_attempted"):
            for index in range(23):
                changed = copy.deepcopy(rows)
                changed[index][key] = False
                with self.subTest(key=key, index=index), self.assertRaises(ValueError):
                    a.stage_roster(commands, changed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
