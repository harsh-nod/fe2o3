#!/usr/bin/env python3
"""Read-only independent reconstruction of the completed signed23 raw packet."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import types

BASE = Path(__file__).resolve().parent
OWNER_SHA = "c317a4268e6ab6cf15fe9e317a11e062b2ec181c3ef9641d7df4a2bf963dbc91"
CONTROLS_SHA = "6919a92fd7a3c80a3ffaabb327f6ddc8402f73cb50d4085f71dcff754cc27932"
PREPARED_SHA = "89daac27cf6adbd501a1d78c13c400593361e92f1ae5a099136c4e98b145ae2e"
RESULT_SHA = "696a56951d502d2ebff9cb184e5275bef90d65e690040b98e0348e1a214aa67d"
CENSUS_SHA = "4bb2e5fd2c675e1437aafb56aaa6fd3bb1055f6a71dc8686a36362217a479578"
CLOSING_SHA = "dab953ce98117d261bebfd0c0730ac2ced97527da9af613eacb5e2d8c59fabfc"


def need(value, message):
    if not value:
        raise ValueError(message)


def owner():
    path = BASE / "signed_journal_campaign_v2.py"
    raw = path.read_bytes()
    need(path.resolve() == path and not path.is_symlink() and hashlib.sha256(raw).hexdigest() == OWNER_SHA,
         "reviewed signed campaign owner")
    module = types.ModuleType("signed_journal_readback")
    module.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def archive_join(index, pins):
    need(set(index) == set(pins), "complete raw archive key bijection")
    need(len({row["archive"] for row in index.values()}) == len(index), "unique raw archive destinations")
    for path, digest in pins.items():
        expected = "raw-helpers/" + str(Path(path).relative_to("/")) + ".source"
        need(index[path] == {"sha256": digest, "archive": expected}, "exact original path/hash/archive join")


def saved_census(closure, namespace, groups):
    need(closure["all_recorded_groups_absent"] is True and closure["namespace"] == namespace
         and closure["recorded_groups"] == groups and len(groups) == len(set(groups)) == 23
         and closure["members"] == [] and closure["uncertain"] == [],
         "saved original fresh23-group census, no historical process query")


def stage_roster(commands, rows):
    need(len(commands) == len(rows) == 23 and [row["name"] for row in rows] == [row["name"] for row in commands]
         and all(row["accepted"] is True and row["group_absent"] is True and row["owned_launch_attempted"] is True for row in rows),
         "exact complete accepted raw23 stage roster")


def audit():
    w = owner()
    x = w.components()
    o, c, h, packet = x.o, x.c, x.h, w.OUTPUT
    need(o.sha(BASE / "test_signed_journal_campaign_v2.py") == CONTROLS_SHA
         and o.sha(w.PREPARED) == PREPARED_SHA and o.sha(packet / "results.json") == RESULT_SHA
         and o.sha(packet / "fresh-process-closure.json") == CENSUS_SHA
         and o.sha(packet / "closing-inputs.json") == CLOSING_SHA, "reviewed owner/preparation and terminal packet pins")
    before = c.prior.tree(packet, h)
    prepared = json.loads(o.raw(w.PREPARED))
    commands = w.plan(x)
    need(prepared["commands"] == commands and prepared["source"] == x.source and prepared["signed_blobs"] == x.blobs
         and prepared["commit_sha256"] == x.commit_sha256 and prepared["signed_commit"] == w.SIGNED
         and prepared["pre_sign_sha256"] == w.REVIEW_SHA and prepared["tools"] == x.original["tools"]
         and prepared["proof_closure"] == x.review["proof_closure"] and prepared["cases"] == x.cases
         and prepared["historical_trees"] == x.history and prepared["raw_pins"] == x.pins,
         "actual signed source/blobs, pre-sign, tools, history, cases and reviewed command plan")
    opening = json.loads(o.raw(packet / "inputs.json"))
    namespace, env = opening.pop("namespace"), opening.pop("environment")
    need(opening == prepared and env == c.d.environment(packet), "exact opening source/command/environment binding")
    closing = json.loads(o.raw(packet / "closing-inputs.json"))
    need(closing == {"source": w.signed_source(h, x.review), "tools": c.d.tool_inventory(c.s),
                    "signed_commit": w.SIGNED, "namespace": namespace}, "closing complete source/tool/namespace binding")
    result = json.loads(o.raw(packet / "results.json"))
    need(result["signed_wrapper_campaign_qualified"] is True and result["errors"] == []
         and result["prior_captures_promoted"] is False and result["fresh_cpu_execution"] is False
         and result["direct_validator_fold_or_native_live_credit_arc_qualified"] is False,
         "exact accepted wrapper-only terminal scope")
    stage_roster(commands, result["stages"])
    groups, classified, projections = [], [], {}
    for spec, row in zip(commands, result["stages"]):
        folder = packet / spec["name"]
        need(json.loads(o.raw(folder / "command.json")) == dict(spec, cwd=str(w.REPO), environment=env)
             and json.loads(o.raw(folder / "result.json")) == row and row["kind"] == spec["kind"], "exact stage command and receipt joins")
        expected_status = 1 if spec["kind"] == "negative" else 0
        need(type(row["returncode"]) is int and row["returncode"] == expected_status, "expected actual terminal exit")
        record = json.loads(o.raw(folder / "owned/record.json"))
        c.base.owned_record(record, expected_status, spec["argv"])
        groups.append(record["process_group"])
        texts = None
        if "root" in spec:
            texts, pins = x.capture.projection(x.texts, x.review["proof_closure"], x.cases[spec["case"]] if spec["case"] else None)
            root = Path(spec["root"])
            if root != w.REPO:
                need(c.prior.tree(root, h) == pins, "actual complete relocated/mutated source, no extra files")
                projections[str(root)] = pins
        stdout, stderr = (o.raw(folder / "owned" / name).decode() for name in ("stdout.log", "stderr.log"))
        detail = w.classify(x, spec, texts, expected_status, stdout, stderr)
        need(detail["accepted"] is True and all(row[key] == value for key, value in detail.items()),
             "independent raw-stream reclassification matches every recorded stage")
        classified.append({"name": spec["name"], "kind": spec["kind"], "classification": detail,
            "stdout_sha256": o.sha(folder / "owned/stdout.log"), "stderr_sha256": o.sha(folder / "owned/stderr.log")})
    need(projections == prepared["projections"] == json.loads(o.raw(packet / "generated-inputs.json"))
         and len(projections) == 10, "one relocated and all nine actual-body projections exactly")
    need(json.loads(o.raw(packet / "fresh-census-inputs.json")) == [row["name"] + "/owned/record.json" for row in commands],
         "exact original recorder group-input roster")
    closure = json.loads(o.raw(packet / "fresh-process-closure.json"))
    saved_census(closure, namespace, groups)
    pins = dict(x.pins, **{str(w.PREPARED): PREPARED_SHA})
    index = json.loads(o.raw(packet / "raw-archive-index.json"))
    archive_join(index, pins)
    h.validate_raw_archive(packet, index)
    boundaries = [row["classification"]["classification"]["boundary"] for row in classified if row["kind"] == "negative"]
    need(boundaries.count("actual-journal-result-equality") == 8 and boundaries.count("wrapper-ghost-trace-only") == 1,
         "eight semantic versus one ghost-only boundary")
    need(c.prior.tree(packet, h) == before, "audit did not mutate original evidence")
    digest = hashlib.sha256(json.dumps(before, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"raw_packet_readback_passed": True, "signed_commit": w.SIGNED, "pre_sign_sha256": w.REVIEW_SHA,
        "prepared_sha256": PREPARED_SHA, "packet_tree_sha256": digest, "packet_files": len(before),
        "stages": classified, "source_files": len(x.source), "signed_blobs": len(x.blobs), "proof_inputs": 38,
        "full165_positives": 3, "fresh_logical_controls": 9, "result_equality_controls": 8, "ghost_trace_only_controls": 1,
        "saved_fresh_groups": len(groups), "historical_pid_probes": False, "cpu_or_solver_rerun": False,
        "original_packet_changed": False, "scope": w.SCOPE}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, "python3 -I -B")
    need(args.output.parent == BASE and args.output.is_absolute() and not args.output.exists(), "fresh small external audit report")
    result = audit()
    raw = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
    need(len(raw) <= 1024**2, "small external readback report")
    with args.output.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"readback_passed": True, "sha256": hashlib.sha256(raw).hexdigest(),
                      "packet_tree_sha256": result["packet_tree_sha256"], "packet_files": result["packet_files"]}))
