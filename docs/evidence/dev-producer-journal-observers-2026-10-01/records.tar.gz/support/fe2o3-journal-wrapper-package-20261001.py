#!/usr/bin/env python3
"""Publish the frozen signed wrapper campaign, without rerunning its proofs."""
import hashlib
import json
from pathlib import Path
import resource
import stat
import subprocess
import tarfile

BASE = Path('/home/harsh/.codex-tmp')
RECORDS = BASE / 'fe2o3-a2-native-journal-observers-records-20261001-audit'
PACKET = RECORDS / 'signed-journal-attempt-1'
REPO = BASE / 'fe2o3-a2-native-journal-observers-20261001-qualified'
DEST = BASE / 'fe2o3-r61-execution/docs/evidence/dev-producer-journal-observers-2026-10-01'
SIGNED = '441cef8c7e49aee436f6e31b5255d461115d5559'
PARENT = '6c0718c1d325e5c5bf5a95ea57e4cf6a842aaf2a'
SIGNERS = BASE / 'fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and path.resolve(strict=True) == path and info.st_nlink == 1
    return {'sha256': sha(path), 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode)}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def bounds():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 1024**2, 32 * 1024**2))


def main():
    audit_path = RECORDS / 'journal-post-audit-root-v1.json'
    assert sha(audit_path) == '982cda3fe8952f8b86d38a5d4cac98bd2efc9e387f3571fe0828c17efbe0453d'
    audit = json.loads(audit_path.read_bytes())
    assert audit['raw_packet_readback_passed'] and audit['signed_commit'] == SIGNED
    assert audit['saved_fresh_groups'] == 23 and audit['proof_inputs'] == 38
    assert (audit['full165_positives'], audit['result_equality_controls'], audit['ghost_trace_only_controls']) == (3, 8, 1)
    entries = list(PACKET.rglob('*'))
    assert all(path.resolve(strict=True) == path and not path.is_symlink() for path in entries)
    sources = {'campaign/' + str(path.relative_to(PACKET)): path for path in entries if path.is_file()}
    tree = {str(path.relative_to(PACKET)): sha(path) for path in sources.values()}
    assert len(tree) == audit['packet_files'] == 705
    assert hashlib.sha256(canonical(tree)).hexdigest() == audit['packet_tree_sha256']
    for name in ('journal-post-audit-root-v1.json', 'journal-post-audit-v1.json',
                 'journal-candidate-before-signing-v1.json', 'prepared-signed-journal-v2.json',
                 'signed_journal_campaign_v2.py', 'test_signed_journal_campaign_v2.py',
                 'audit_signed_journal_v1.py', 'test_audit_signed_journal_v1.py'):
        sources['support/' + name] = RECORDS / name
    sources['support/' + Path(__file__).name] = Path(__file__)
    inventory = {name: {**identity(path), 'original': str(path)} for name, path in sorted(sources.items())}
    assert sum(row['bytes'] for row in inventory.values()) < 64 * 1024**2
    DEST.mkdir(mode=0o755)
    commands = []
    def git(arguments):
        argv = ['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', '-c', 'pack.threads=1', *arguments]
        completed = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=120, preexec_fn=bounds)
        commands.append({'argv': argv, 'cwd': str(REPO), 'exit': completed.returncode,
                         'stdout': completed.stdout.decode(), 'stderr': completed.stderr.decode()})
        assert completed.returncode == 0, commands[-1]
        return completed.stdout
    assert git(['rev-parse', 'HEAD']).decode().strip() == SIGNED
    assert git(['rev-parse', 'HEAD^']).decode().strip() == PARENT
    git(['-c', 'gpg.ssh.allowedSignersFile=' + str(SIGNERS), 'verify-commit', SIGNED])
    bundle = DEST / 'signed-source.bundle'
    git(['bundle', 'create', str(bundle), 'HEAD', '^' + PARENT])
    assert git(['bundle', 'list-heads', str(bundle)]).decode() == SIGNED + ' HEAD\n'
    git(['bundle', 'verify', str(bundle)])
    archive_path = DEST / 'records.tar.gz'
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz', compresslevel=6) as archive:
            for name, path in sorted(sources.items()):
                archive.add(path, arcname=name, recursive=False)
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name in inventory and member.name not in seen
            row = inventory[member.name]
            assert member.mode == row['mode'] and member.size == row['bytes']
            with archive.extractfile(member) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']
            assert identity(sources[member.name]) == {key: row[key] for key in ('sha256', 'bytes', 'mode')}
            seen.add(member.name)
    assert seen == set(inventory)
    manifest = {'schema': 'fe2o3.producer-journal-wrapper-public-records.v1',
                'signed_commit': SIGNED, 'public_parent': PARENT,
                'archive': {**identity(archive_path), 'path': archive_path.name},
                'source_bundle': {**identity(bundle), 'path': bundle.name},
                'members': inventory, 'complete_campaign_files': 705,
                'packet_tree_sha256': audit['packet_tree_sha256'], 'git_commands': commands,
                'all_archived_originals_rechecked': True, 'proofs_reexecuted_by_packaging': False,
                'external_prerequisites': [
                    'The source bundle requires the public parent commit.',
                    'Original CPU executable, toolchain/runtime libraries and inherited CPU/tool/history prerequisites remain external.',
                    'Controllers retain original absolute paths and require explicit mapping for relocation; no turnkey portable replay claim.'],
                'scope': audit['scope']}
    with (DEST / 'manifest.json').open('x') as stream:
        json.dump(manifest, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps({key: manifest[key] for key in ('signed_commit', 'public_parent', 'archive', 'source_bundle',
                                                  'complete_campaign_files', 'packet_tree_sha256')}, sort_keys=True))


if __name__ == '__main__':
    main()
