#!/usr/bin/env python3
"""Fresh signed four-wrapper proof qualification, never historical-capture promotion."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import types

BASE = Path(__file__).resolve().parent
REPO = Path("/home/harsh/.codex-tmp/fe2o3-a2-native-journal-observers-20261001-qualified")
SIGNED = "441cef8c7e49aee436f6e31b5255d461115d5559"
REVIEW = BASE / "journal-candidate-before-signing-v1.json"
REVIEW_SHA = "58b8bff82e589e1c7a4f6a7bb37c0aecc618c13bde6e20953eeb17602aecea8b"
BINDER_SHA = "02d32ee11d59a6a89df5ac431088680f4fdab74e53417a261d34596885f86837"
BINDER_TEST_SHA = "54684d4a0a5f980381ed6eab377503441c6a4cf7451a12c4078cba23bb04d09c"
CAPTURE_SHA = "4aa001c23d6a29b87823e8e8b74ba0ca4926e5014a59f5ff5ce8f2c0a89e5882"
V = Path("crates/fe2o3-runtime-model/verus")
OUTPUT = BASE / "signed-journal-attempt-1"
PREPARED = BASE / "prepared-signed-journal-v2.json"
PRIOR_PREPARATION = {
    "signed_journal_campaign_v1.py": "b8a211c04775cc9bfbd5a70f92594dad4569710b5de2aef6049b7d2ec84f5929",
    "test_signed_journal_campaign_v1.py": "dbd0a3a7e0c582ad9a39f02b14b1c540fcfa3fa563e06292488d6c8387498942",
    "prepared-signed-journal-v1.json": "499143fca17435e1df7adb88644dca4036555c9acdeb8937c08de03111a5174f",
}
LIMIT, FLOOR = 128 * 1024**2, 4 * 1024**3
SCOPE = ("Fresh signed full165 wrapper/journal closure and all nine unfiltered actual-body mutations. "
         "Eight failures establish actual result-equality sensitivity; the eager-status mutation only "
         "establishes wrapper ghost-trace sensitivity at early question-mark return, never inner query "
         "call counts or a result-equality failure. Full-before, independent relocated and full-after "
         "positives, tool-release and signature brackets are required. Counts are verifier obligations, "
         "not independent runtime properties. The original fresh CPU suite is accepted through linked "
         "strict readback plus a separate missing-Clippy continuation; the original rejection is retained. "
         "Native/proof inputs are unchanged from that CPU source, but later main-model integration needs "
         "a combined CPU regression. No direct validator/fold, native live/credit-lock/Arc/shared-interior, "
         "compiler/ISA, GPU, performance or HIP/HSA parity claim. Historical observations never become "
         "fresh kills. Dynamic host/loader dependencies are not hermetically attested. No automatic retry. "
         "Per-command deadlines only; disk guards are startup/stage-boundary checks, not quotas or continuous limits.")


def need(value, message):
    if not value:
        raise ValueError(message)


def load(path, digest, name):
    need(path.is_file() and path.resolve() == path and not path.is_symlink(), "ordinary canonical helper")
    raw = path.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == digest, "reviewed helper bytes")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def signed_source(h, review):
    need(h.git("rev-parse", "HEAD").decode().strip() == SIGNED
         and h.git("rev-parse", "HEAD^").decode().strip() == review["base_commit"], "exact signed successor and parent")
    need(not h.git("status", "--porcelain=v1", "--untracked-files=all"), "clean entire signed worktree")
    names = {os.fsdecode(path) for path in h.git("ls-files", "--cached", "-z", "--", *review["selectors"]).split(b"\0") if path}
    source = {path: {"sha256": h.sha(REPO / path), "bytes": (REPO / path).stat().st_size} for path in sorted(names)}
    need(source == review["source"] and len(source) == 6537, "all signed source equals retained pre-sign snapshot")
    changed = {os.fsdecode(path) for path in h.git("diff-tree", "--no-commit-id", "--name-only", "-r", "-z", SIGNED).split(b"\0") if path}
    need(changed == set(review["changed_paths_from_base"]) and len(changed) == 13, "exact reviewed signed path roster")
    return source


def cpu_continuity(o, p, review):
    elf = review["cpu_original_readback"]["original_fresh_elf"]
    need(elf["sha256"] == "36a7f78c4f8004ccb1800b9fac21a4e1bb4431775ce9e0826758001334483e09"
         and elf["bytes"] == 43603592 and p.file_identity(Path(elf["path"]))
         == {key: elf[key] for key in ("path", "sha256", "bytes", "mode")}, "original fresh extraction test ELF retained")
    return elf


def retained_journal_trees(original, cpu, c, h, m):
    rejected = original["preserved_frontend_rejection"]
    trees = {rejected["path"]: rejected["files"],
             str(m.OUTPUT): cpu["original_source_binding"]["preserved_discovery_tree"]}
    need(all(c.prior.tree(Path(root), h) == tree for root, tree in trees.items()),
         "complete original rejected and accepted discovery packets unchanged")
    packet = BASE / "mutation-observations-attempt-1"
    tree = c.prior.tree(packet, h)
    fixture = json.loads(h.raw(REPO / V / "producer-journal-diagnostic-fixtures-v1.json"))
    need(tree["results.json"] == fixture["result_sha256"]
         and tree["fresh-process-closure.json"] == fixture["saved_original_closure_sha256"],
         "original observation result and saved fresh closure match signed fixture provenance")
    for row in fixture["cases"].values():
        prefix = row["original_stage"] + "/owned/"
        need(tree[prefix + "stdout.log"] == row["original_stdout_sha256"]
             and tree[prefix + "stderr.log"] == row["original_stderr_sha256"],
             "all nine complete original raw observations remain byte-identical")
    trees[str(packet)] = tree
    return trees


def components():
    b = load(BASE / "bind_journal_candidate_v1.py", BINDER_SHA, "signed_journal_binder")
    k = b.continuation()
    o, m, c, old_h, p, _limits, cpu = k.components()
    need(o.sha(REVIEW) == REVIEW_SHA, "retained pre-sign binding")
    review = json.loads(o.raw(REVIEW))
    # The unsigned binder's old-HEAD capture must never be called after signing.
    need(b.readback(k, o, m, c, old_h, p, cpu) == review["preserved_clippy_packet_without_target"]
         and cpu["retained_original_packet_without_target"] == review["preserved_original_cpu_packet_without_target"]
         and cpu["original_readback"] == review["cpu_original_readback"], "unchanged accepted linked CPU evidence")
    original = cpu["original_source_binding"]["source_binding"]
    need(original["source"] == review["tested_source"], "same actual measured/tested source")
    h = load(Path(old_h.__file__), o.sha(Path(old_h.__file__)), "signed_journal_source_helper")
    h.REPO = REPO
    source = signed_source(h, review)
    b.source_delta(original["source"], source)
    inherited = c.classifier.inherited()
    leaf = load(Path(inherited.__file__), o.sha(Path(inherited.__file__)), "signed_journal_blob_bridge")
    leaf.ROOT = REPO
    blobs = leaf.bind_signed_blobs(types.SimpleNamespace(git=h.git, INPUTS=review["selectors"]),
        {"commit": SIGNED, "inputs": {path: row["sha256"] for path, row in source.items()}})
    guard = load(REPO / m.GUARD, source[str(m.GUARD)]["sha256"], "signed_journal_guard")
    source_texts = guard.snapshot()
    guard.audit(source_texts)
    need({str(path): source[str(path)] for path in guard.files()} == original["closure"] == review["proof_closure"]
         and guard.EXPECTED_VERIFIED == 165 and guard.QUALIFIED is False, "complete unchanged calibrated closure, source guard cannot qualify")
    diagnostic = guard.diagnostic_classifier()
    capture = load(BASE / "mutation_capture_v1.py", CAPTURE_SHA, "signed_journal_projection_helpers")
    cases = capture.cases(guard, source_texts)
    need(set(cases) == diagnostic.CASES and len(cases) == 9, "all original nine actual-body mutations")
    elf = cpu_continuity(o, p, review)
    history = dict(original["external_historical_trees"])
    history.update(retained_journal_trees(original, cpu, c, h, m))
    history[str(o.OUTPUT)] = review["preserved_original_cpu_packet_without_target"]
    history[str(k.OUTPUT)] = review["preserved_clippy_packet_without_target"]
    pins = dict(cpu["original_source_binding"]["raw_pins"]) | cpu["raw_pins"] | review["evidence_pins"]
    pins.update({str(REVIEW): REVIEW_SHA, str(BASE / "bind_journal_candidate_v1.py"): BINDER_SHA,
        str(BASE / "test_bind_journal_candidate_v1.py"): BINDER_TEST_SHA,
        str(BASE / "mutation_capture_v1.py"): CAPTURE_SHA, str(k.PREPARED): b.PREPARED_SHA})
    pins.update({str(REPO / path): source[path]["sha256"] for path in review["changed_paths_from_base"]})
    pins.update({str(BASE / name): digest for name, digest in PRIOR_PREPARATION.items()})
    for name in ("signed_journal_campaign_v2.py", "test_signed_journal_campaign_v2.py"):
        pins[str(BASE / name)] = o.sha(BASE / name)
    need(all(o.sha(Path(path)) == digest for path, digest in pins.items()), "all reviewed source, fixture, owner and provenance pins")
    return types.SimpleNamespace(b=b, k=k, o=o, m=m, c=c, old_h=old_h, h=h, p=p, cpu=cpu, review=review,
        original=original, source=source, blobs=blobs, guard=guard, texts=source_texts, diagnostic=diagnostic,
        capture=capture, cases=cases, elf=elf, history=history, pins=pins,
        commit_sha256=hashlib.sha256(h.git("cat-file", "commit", SIGNED)).hexdigest())


def plan(x):
    rows = []
    def add(name, kind, argv, timeout=130, **extra):
        rows.append(dict(name=str(len(rows) + 1).zfill(3) + "-" + name, kind=kind, argv=list(argv), timeout=timeout, **extra))
    original = {row["kind"]: row for row in x.original["commands"]}
    signature = list(original["signature"]["argv"])
    need(signature[-2:] == ["verify-commit", x.review["base_commit"]], "reviewed signed-parent verification template")
    signature[-1] = SIGNED
    add("signature-before", "signature", signature, 60)
    for label, name, count, class_name in (
        ("validator-controls", "test-producer-input-validate.py", 5, None),
        ("fold-controls", "test-producer-input-fold.py", 4, None),
        ("composition-controls", "test-producer-input-composition.py", 12, None),
        ("composition-mutation-controls", "test-producer-input-composition-qualification.py", 5, None),
        ("shared-diagnostic-controls", "test-producer-input-diagnostics.py", 14, None),
        ("wrapper-source-controls", "test-producer-journal-observers.py", 8, "SourceControls"),
        ("wrapper-diagnostic-controls", "test-producer-journal-diagnostics.py", 17, "DiagnosticControls"),
    ):
        names = x.o.control_names(REPO / V / name, class_name, count) if class_name else None
        add(label, "control", ["/usr/bin/python3", "-I", "-B", str(REPO / V / name)], 60,
            count=count, class_name=class_name, control_names=names, fold_control=label == "fold-controls")
    release = ["/bin/sh", str(REPO / x.c.d.CLOSURE), str(x.c.d.VERUS.parent), str(REPO / x.c.d.MANIFEST)]
    add("tool-release-before", "release", release)
    items = [("full-before", "positive", None), ("relocated", "positive", None)]
    items += [(case, "negative", case) for case in x.cases]
    items.append(("full-after", "positive", None))
    for name, kind, case in items:
        root = REPO if name in ("full-before", "full-after") else OUTPUT / "projections" / name
        argv = list(original["positive"]["argv"])
        argv[-1] = str(root / x.guard.PROOF)
        need(not {"--verify-function", "--verify-only-module", "--verify-root", "--verify-module"}.intersection(argv)
             and argv[argv.index("--num-threads") + 1] == "4" and argv[argv.index("--multiple-errors") + 1] == "1"
             and "--no-cheating" in argv and argv[4] == "120", "unfiltered four-thread bounded proof command")
        add(name, kind, argv, root=str(root), case=case)
    add("tool-release-after", "release", release)
    add("signature-after", "signature", signature, 60)
    need(len(rows) == len({row["name"] for row in rows}) == 23, "exact signed23 stage roster")
    return rows


def classify(x, spec, texts, status, stdout, stderr):
    kind = spec["kind"]
    if kind == "negative":
        try:
            result = x.diagnostic.negative(REPO / V / "producer-input-diagnostics-v1.py", x.c.identity.VERIFIER,
                {Path(path): text for path, text in texts.items()}, {Path(path) for path in x.review["proof_closure"]},
                Path(spec["root"]), spec["case"], status, stdout, stderr)
            need(result["logical_diagnostic_accepted"] is True and result["signed_campaign_qualified"] is False
                 and result["historical_capture_is_qualified_kill"] is False, "diagnostic predicate alone never qualifies")
            return {"accepted": True, "classification": result}
        except (ValueError, TypeError, KeyError) as error:
            return {"accepted": False, "classification": {"logical_diagnostic_accepted": False,
                "rejection": type(error).__name__ + ": " + str(error)}}
    if kind == "positive":
        paths = {str(Path(spec["root"]) / path) for path in x.review["proof_closure"]}
        result = x.c.d.classify(x.c.classifier, x.c.identity.VERIFIER, paths, status, stdout, stderr)
        return {"accepted": result["candidate_accepted"] is True and result["observed_verified"] == 165 and stderr == "",
                "classification": result}
    accepted = type(status) is int and status == 0
    if kind == "signature":
        accepted = accepted and stdout == "" and stderr == x.c.s.SIGNATURE
    elif kind == "release":
        accepted = accepted and stdout == x.c.d.CLOSURE_OK and stderr == ""
    else:
        need(kind == "control", "known stage kind")
        if spec["fold_control"]:
            accepted = accepted and stdout == "PASS: producer-input fold source/controller calibration (4 groups; 22 logical mutants constructed, not executed)\n" and stderr == ""
        elif spec["class_name"]:
            accepted = accepted and x.o.controls_pass(spec["control_names"], spec["class_name"], stdout, stderr)
        else:
            pattern = r"\.{{{0}}}\n-{{70}}\nRan {0} tests in [0-9]+\.[0-9]+s\n\nOK\n".format(spec["count"])
            accepted = accepted and stdout == "" and re.fullmatch(pattern, stderr) is not None
    return {"accepted": accepted}


def qualified(commands, rows, errors, closed):
    return len(commands) == len(rows) == 23 and [row["name"] for row in rows] == [row["name"] for row in commands] \
        and all(row.get("accepted") is True and row.get("group_absent") is True for row in rows) \
        and sum(row["kind"] == "negative" for row in rows) == 9 and not errors and closed is True


def execute_plan(commands, stage):
    errors = []
    try:
        for spec in commands[:-2]:
            stage(spec)
    except BaseException as error:
        errors.append(type(error).__name__ + ": " + str(error))
    finally:
        for spec in commands[-2:]:
            try:
                stage(spec)
            except BaseException as error:
                errors.append(spec["name"] + ": " + type(error).__name__ + ": " + str(error))
    return errors


def footprint(startup=False):
    need(shutil.disk_usage(BASE).free >= FLOOR + (LIMIT if startup else 0), "reviewed host disk floor")
    size = 0
    for path in OUTPUT.rglob("*") if OUTPUT.exists() else ():
        need(not path.is_symlink(), "no output symlink aliases")
        if path.is_file():
            size += path.stat().st_size
    need(size <= LIMIT, "stage-boundary packet byte bound")
    return {"packet_bytes": size, "free_bytes": shutil.disk_usage(BASE).free}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--prepared-sha256")
    args = parser.parse_args()
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize and args.prepare != args.execute,
         "explicit isolated prepare or separately reviewed execute")
    x = components()
    o, c, h = x.o, x.c, x.h
    commands = plan(x)
    projections = {row["root"]: x.capture.projection(x.texts, x.review["proof_closure"], x.cases[row["case"]] if row["case"] else None)[1]
        for row in commands if row.get("root") not in (None, str(REPO))}
    frozen = {"signed_commit": SIGNED, "commit_sha256": x.commit_sha256, "signed_blobs": x.blobs,
        "pre_sign_sha256": REVIEW_SHA, "source": x.source, "tools": x.original["tools"], "commands": commands,
        "cases": x.cases, "proof_closure": x.review["proof_closure"], "projections": projections,
        "raw_pins": x.pins, "historical_trees": x.history, "retained_fresh_cpu_elf": x.elf,
        "linked_cpu_readback_and_continuation": True, "scope": SCOPE, "prior_captures_promoted": False,
        "fresh_cpu_execution": False, "automatic_retries": False,
        "storage": {"packet_bound_bytes": LIMIT, "startup_free_bytes": FLOOR + LIMIT, "stage_floor_bytes": FLOOR,
            "raw_archive_bytes_before_prepared": sum(Path(path).stat().st_size for path in x.pins),
            "projection_bytes": sum(sum(len(text.encode()) for text in x.capture.projection(x.texts, x.review["proof_closure"],
                x.cases[row["case"]] if row["case"] else None)[0].values()) for row in commands if row.get("root") not in (None, str(REPO)))},
        "bounds": {"solver_threads": 4, "inner_proof_seconds": 120, "owned_proof_seconds": 130,
                   "total_owner_deadline": None, "command_timeout_sum_seconds": sum(row["timeout"] for row in commands)}}
    need(frozen["storage"]["raw_archive_bytes_before_prepared"] + frozen["storage"]["projection_bytes"] < LIMIT // 2,
         "bounded nonrecursive raw archive and minimal projections")
    need(not OUTPUT.exists() and OUTPUT.resolve() == OUTPUT, "fresh never-reused signed campaign output")
    if args.prepare:
        need(args.prepared_sha256 is None, "preparation only")
        o.save(PREPARED, frozen)
        print(json.dumps({"prepared_sha256": o.sha(PREPARED), "stages": len(commands), "cases": len(x.cases),
            "signed_blobs": len(x.blobs), "source_files": len(x.source), "storage": frozen["storage"]}), flush=True)
        return
    need(args.prepared_sha256 == o.sha(PREPARED) and json.loads(o.raw(PREPARED)) == frozen, "exact reviewed signed campaign")
    footprint(startup=True)
    OUTPUT.mkdir()
    (OUTPUT / "tmp").mkdir()
    namespace, env = c.s.process_namespace_identity(), c.d.environment(OUTPUT)
    o.save(OUTPUT / "inputs.json", dict(frozen, namespace=namespace, environment=env))
    pins = dict(x.pins, **{str(PREPARED): args.prepared_sha256})
    archive = h.archive_raw_buffers(OUTPUT, pins)
    managed = c.loader.load()
    c.loader.archive(OUTPUT)
    rows, generated, errors = [], {}, []

    def current():
        need(signed_source(h, x.review) == x.source
             and x.m.source_inventory(x.old_h, x.original["selectors"]) == x.original["source"], "signed and frozen tested source unchanged")
        need(c.d.tool_inventory(c.s) == frozen["tools"] and c.s.process_namespace_identity() == namespace
             and all(o.sha(Path(path)) == digest for path, digest in pins.items()), "unchanged tools, raw pins and original process namespace")
        cpu_continuity(o, x.p, x.review)
        for root, tree in x.history.items():
            excluded = Path(root) / "target" if root in (str(o.OUTPUT), str(x.k.OUTPUT)) else None
            observed = {str(path.relative_to(root)): o.sha(path) for path in Path(root).rglob("*")
                if path.is_file() and (excluded is None or not path.is_relative_to(excluded))}
            need(observed == tree, "all retained original evidence unchanged")
        need(all(c.prior.tree(Path(root), h) == tree for root, tree in generated.items()), "all actual projections unchanged")
        footprint()

    def stage(spec):
        current()
        texts = None
        if "root" in spec:
            texts, projected = x.capture.projection(x.texts, x.review["proof_closure"], x.cases[spec["case"]] if spec["case"] else None)
            root = Path(spec["root"])
            if root != REPO:
                need(str(root) in projections and projected == projections[str(root)] and not root.exists(), "fresh exact prepared projection")
                for path, text in texts.items():
                    target = root / path
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with target.open("xb") as stream:
                        stream.write(text.encode())
                generated[str(root)] = projected
            current()
        folder = OUTPUT / spec["name"]
        folder.mkdir()
        o.save(folder / "command.json", dict(spec, cwd=str(REPO), environment=env))
        row = {"name": spec["name"], "kind": spec["kind"], "accepted": False, "owned_launch_attempted": False}
        rows.append(row)
        print("START " + spec["name"], flush=True)
        try:
            previous = Path.cwd()
            try:
                os.chdir(REPO)
                row["owned_launch_attempted"] = True
                status, stdout, stderr = managed.run_owned(spec["argv"], spec["timeout"], folder / "owned", env)
            finally:
                os.chdir(previous)
            record = json.loads(o.raw(folder / "owned/record.json"))
            c.base.owned_record(record, status, spec["argv"])
            need(o.raw(folder / "owned/stdout.log").decode() == stdout and o.raw(folder / "owned/stderr.log").decode() == stderr,
                 "exact raw streams and current receipt")
            row.update(returncode=status, group_absent=record["group_absent"])
            result = classify(x, spec, texts, status, stdout, stderr)
            current()
            row.update(result)
            need(spec["kind"] == "negative" or row["accepted"], "required signature/source/tool/positive bracket")
        finally:
            o.save(folder / "result.json", row)
            print("END " + spec["name"] + " accepted=" + str(row["accepted"]), flush=True)

    errors = execute_plan(commands, stage)
    closed = False
    try:
        current()
        h.validate_raw_archive(OUTPUT, archive)
        need(set(archive) == set(pins) and all(archive[path]["sha256"] == digest for path, digest in pins.items()), "complete exact archived pin map")
        o.save(OUTPUT / "closing-inputs.json", {"source": signed_source(h, x.review), "tools": c.d.tool_inventory(c.s),
            "signed_commit": SIGNED, "namespace": c.s.process_namespace_identity()})
    except BaseException as error:
        errors.append("closing continuity/archive: " + type(error).__name__ + ": " + str(error))
    try:
        o.save(OUTPUT / "generated-inputs.json", generated)
        o.save(OUTPUT / "fresh-census-inputs.json", h.census_input_roster(OUTPUT, rows))
        closure = c.s.independent_absence(OUTPUT, namespace)
        o.save(OUTPUT / "fresh-process-closure.json", closure)
        groups = [json.loads(o.raw(OUTPUT / row["name"] / "owned/record.json"))["process_group"] for row in rows if row["owned_launch_attempted"]]
        need(closure["all_recorded_groups_absent"] is True and closure["recorded_groups"] == groups
             and closure["namespace"] == namespace and closure["members"] == [] and closure["uncertain"] == [],
             "fresh original campaign groups only, no historical PID probing")
        o.save(OUTPUT / "final-resources.json", footprint())
        closed = True
    except BaseException as error:
        errors.append("closing census: " + type(error).__name__ + ": " + str(error))
    accepted = qualified(commands, rows, errors, closed)
    o.save(OUTPUT / "results.json", {"signed_wrapper_campaign_qualified": accepted, "stages": rows, "errors": errors,
        "scope": SCOPE, "prior_captures_promoted": False, "fresh_cpu_execution": False,
        "eight_result_equality_and_one_ghost_trace_controls_qualified": accepted,
        "direct_validator_fold_or_native_live_credit_arc_qualified": False})
    print(json.dumps({"signed_wrapper_campaign_qualified": accepted, "errors": errors}), flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == "__main__":
    main()
