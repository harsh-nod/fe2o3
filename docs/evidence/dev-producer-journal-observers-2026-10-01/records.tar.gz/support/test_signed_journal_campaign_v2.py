#!/usr/bin/env python3
"""Read-only signed-wrapper campaign controls; no compiler or verifier execution."""
import copy
import json
from pathlib import Path
import types
import unittest

BASE = Path(__file__).resolve().parent
PATH = BASE / "signed_journal_campaign_v2.py"
owner = types.ModuleType("journal_campaign_controls")
owner.__file__ = str(PATH)
exec(compile(PATH.read_bytes(), str(PATH), "exec"), owner.__dict__)


class CampaignControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.x = owner.components()
        cls.commands = owner.plan(cls.x)
        cls.fixtures = json.loads((owner.REPO / owner.V / "producer-journal-diagnostic-fixtures-v1.json").read_bytes())["cases"]

    def test_signed_source_matches_presign_not_unsigned_head_checks(self):
        self.assertEqual(owner.signed_source(self.x.h, self.x.review), self.x.review["source"])
        self.assertEqual(len(self.x.source), 6537)
        self.assertEqual(len(self.x.blobs), 6537)
        self.assertEqual(self.x.review["base_commit"], "6c0718c1d325e5c5bf5a95ea57e4cf6a842aaf2a")
        self.assertNotEqual(owner.SIGNED, self.x.review["base_commit"])

    def test_exact_twenty_three_stages_three_positives_nine_negatives(self):
        self.assertEqual(len(self.commands), 23)
        counts = {kind: sum(row["kind"] == kind for row in self.commands) for kind in ("signature", "control", "release", "positive", "negative")}
        self.assertEqual(counts, {"signature": 2, "control": 7, "release": 2, "positive": 3, "negative": 9})
        self.assertEqual([row["kind"] for row in self.commands[-2:]], ["release", "signature"])
        self.assertEqual({row["case"] for row in self.commands if row["kind"] == "negative"}, set(self.x.cases))

    def test_all_proof_commands_unfiltered_four_threads_and_bounded(self):
        for row in self.commands:
            if row["kind"] not in ("negative", "positive"):
                continue
            argv = row["argv"]
            self.assertEqual(argv[4], "120")
            self.assertEqual(row["timeout"], 130)
            self.assertEqual(argv[argv.index("--num-threads") + 1], "4")
            self.assertEqual(argv[argv.index("--multiple-errors") + 1], "1")
            self.assertIn("--no-cheating", argv)
            self.assertFalse({"--verify-function", "--verify-root", "--verify-only-module", "--verify-module"}.intersection(argv))

    def test_exact_complete_projection_and_only_actual_body_mutates(self):
        closure = self.x.review["proof_closure"]
        for name, mutation in {None: None, **self.x.cases}.items():
            texts, pins = self.x.capture.projection(self.x.texts, closure, mutation)
            self.assertEqual(len(texts), 38)
            self.assertEqual(set(pins), set(closure))
            self.assertEqual({path for path in pins if pins[path] != closure[path]["sha256"]},
                             {str(self.x.guard.BODY)} if name else set())
        broken = copy.deepcopy(closure)
        broken[str(self.x.guard.PROOF)]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            self.x.capture.projection(self.x.texts, broken, None)

    def test_all_historical_fixtures_classify_only_as_diagnostics(self):
        boundaries = []
        for case, fixture in self.fixtures.items():
            spec = dict(next(row for row in self.commands if row.get("case") == case), root=fixture["root"])
            texts, _pins = self.x.capture.projection(self.x.texts, self.x.review["proof_closure"], self.x.cases[case])
            result = owner.classify(self.x, spec, texts, 1, fixture["stdout"], fixture["stderr"])
            self.assertTrue(result["accepted"])
            detail = result["classification"]
            self.assertFalse(detail["signed_campaign_qualified"])
            self.assertFalse(detail["historical_capture_is_qualified_kill"])
            self.assertFalse(detail["inner_query_call_count_proved"])
            boundaries.append(detail["boundary"])
        self.assertEqual(boundaries.count("actual-journal-result-equality"), 8)
        self.assertEqual(boundaries.count("wrapper-ghost-trace-only"), 1)

    def test_negative_rejects_success_timeout_signal_and_wrong_boundary(self):
        case = "active_lookup-error-coerced"
        fixture = self.fixtures[case]
        spec = dict(next(row for row in self.commands if row.get("case") == case), root=fixture["root"])
        texts, _pins = self.x.capture.projection(self.x.texts, self.x.review["proof_closure"], self.x.cases[case])
        for status in (0, True, 124, -15):
            self.assertFalse(owner.classify(self.x, spec, texts, status, fixture["stdout"], fixture["stderr"])["accepted"])
        other = dict(spec, case="active_lookup-prefetch-status")
        self.assertFalse(owner.classify(self.x, other, texts, 1, fixture["stdout"], fixture["stderr"])["accepted"])

    def test_measured_positive_requires_full165_and_clean_completion(self):
        spec = next(row for row in self.commands if row["kind"] == "positive")
        stdout = (BASE / "discovery-attempt-2/004-full-proof/owned/stdout.log").read_text()
        self.assertTrue(owner.classify(self.x, spec, None, 0, stdout, "")["accepted"])
        for status, changed, stderr in ((1, stdout, ""), (0, stdout.replace('"verified": 165', '"verified": 164'), ""),
                                        (0, stdout, "unexpected\n")):
            try:
                result = owner.classify(self.x, spec, None, status, changed, stderr)
            except ValueError:
                continue
            self.assertFalse(result["accepted"])

    def test_exact_control_result_rosters_and_no_partial_or_extra_output(self):
        for spec in (row for row in self.commands if row["kind"] == "control"):
            if spec["fold_control"]:
                stdout, stderr = "PASS: producer-input fold source/controller calibration (4 groups; 22 logical mutants constructed, not executed)\n", ""
            else:
                stdout = ""
                prefix = ("".join(name + " (__main__." + spec["class_name"] + "." + name + ") ... ok\n" for name in spec["control_names"])
                          if spec["class_name"] else "." * spec["count"] + "\n")
                stderr = prefix + ("\n" if spec["class_name"] else "") + "-" * 70 + "\nRan " + str(spec["count"]) + " tests in 0.123s\n\nOK\n"
            self.assertTrue(owner.classify(self.x, spec, None, 0, stdout, stderr)["accepted"])
            self.assertFalse(owner.classify(self.x, spec, None, 0, stdout + "extra", stderr)["accepted"])
            self.assertFalse(owner.classify(self.x, spec, None, True, stdout, stderr)["accepted"])

    def test_exact_signature_and_release_brackets(self):
        for kind, stdout, stderr in (("signature", "", self.x.c.s.SIGNATURE), ("release", self.x.c.d.CLOSURE_OK, "")):
            spec = next(row for row in self.commands if row["kind"] == kind)
            self.assertTrue(owner.classify(self.x, spec, None, 0, stdout, stderr)["accepted"])
            self.assertFalse(owner.classify(self.x, spec, None, 0, stdout, stderr + "unexpected")["accepted"])
            self.assertFalse(owner.classify(self.x, spec, None, 1, stdout, stderr)["accepted"])

    def test_every_stage_and_closed_group_needed_for_campaign_acceptance(self):
        rows = [dict(row, accepted=True, group_absent=True) for row in self.commands]
        self.assertTrue(owner.qualified(self.commands, rows, [], True))
        for changed in (rows[:-1], rows + [rows[-1]], list(reversed(rows))):
            self.assertFalse(owner.qualified(self.commands, changed, [], True))
        for index in range(len(rows)):
            changed = copy.deepcopy(rows)
            changed[index]["accepted"] = False
            self.assertFalse(owner.qualified(self.commands, changed, [], True))
            changed[index]["accepted"], changed[index]["group_absent"] = True, False
            self.assertFalse(owner.qualified(self.commands, changed, [], True))
        self.assertFalse(owner.qualified(self.commands, rows, ["failure"], True))
        self.assertFalse(owner.qualified(self.commands, rows, [], False))

    def test_both_closing_brackets_attempted_after_failure_without_retry(self):
        reached = []
        def stage(row):
            reached.append(row["name"])
            if len(reached) == 3 or row["kind"] == "release":
                raise ValueError("controlled failure")
        errors = owner.execute_plan(self.commands, stage)
        self.assertEqual(reached, [row["name"] for row in self.commands[:3] + self.commands[-2:]])
        self.assertEqual(len(errors), 2)
        self.assertEqual(len(reached), len(set(reached)))

    def test_linked_cpu_and_scope_boundaries_remain_explicit(self):
        self.assertEqual(owner.cpu_continuity(self.x.o, self.x.p, self.x.review)["sha256"],
                         "36a7f78c4f8004ccb1800b9fac21a4e1bb4431775ce9e0826758001334483e09")
        self.assertTrue(self.x.review["cpu_evidence_is_linked_readback_and_continuation"])
        self.assertFalse(self.x.review["fresh_cpu_or_solver_execution"])
        self.assertFalse(self.x.review["fixtures_are_qualified_kills"])
        self.assertIn("combined CPU regression", owner.SCOPE)
        self.assertIn("No direct validator/fold", owner.SCOPE)

    def test_all_three_wrapper_history_trees_and_v1_preparation_retained(self):
        trees = owner.retained_journal_trees(self.x.original, self.x.cpu, self.x.c, self.x.h, self.x.m)
        self.assertEqual(set(trees), {str(BASE / name) for name in (
            "discovery-attempt-1", "discovery-attempt-2", "mutation-observations-attempt-1")})
        for root, tree in trees.items():
            self.assertEqual(self.x.history[root], tree)
        for name, digest in owner.PRIOR_PREPARATION.items():
            self.assertEqual(self.x.o.sha(BASE / name), digest)
            self.assertEqual(self.x.pins[str(BASE / name)], digest)

    def test_missing_extra_or_changed_historical_inputs_rejected(self):
        original_tree = self.x.c.prior.tree
        try:
            target = BASE / "discovery-attempt-1"
            for change in ("missing", "extra", "wrong-hash"):
                def changed_tree(root, helper):
                    tree = original_tree(root, helper)
                    if root == target:
                        if change == "missing":
                            tree.pop("results.json")
                        elif change == "extra":
                            tree["unexpected.log"] = "0" * 64
                        else:
                            tree["results.json"] = "0" * 64
                    return tree
                self.x.c.prior.tree = changed_tree
                with self.subTest(change=change), self.assertRaises(ValueError):
                    owner.retained_journal_trees(self.x.original, self.x.cpu, self.x.c, self.x.h, self.x.m)
            def changed_observation(root, helper):
                tree = original_tree(root, helper)
                if root == BASE / "mutation-observations-attempt-1":
                    stage = next(iter(self.fixtures.values()))["original_stage"]
                    tree[stage + "/owned/stderr.log"] = "0" * 64
                return tree
            self.x.c.prior.tree = changed_observation
            with self.assertRaises(ValueError):
                owner.retained_journal_trees(self.x.original, self.x.cpu, self.x.c, self.x.h, self.x.m)
        finally:
            self.x.c.prior.tree = original_tree


if __name__ == "__main__":
    unittest.main(verbosity=2)
