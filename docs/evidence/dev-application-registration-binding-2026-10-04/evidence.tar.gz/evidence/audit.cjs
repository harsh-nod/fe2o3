const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const path = require('node:path');
const out = __dirname;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const before = JSON.parse(fs.readFileSync(path.join(out, 'sources-before.json')));
const after = JSON.parse(fs.readFileSync(path.join(out, 'sources-after.json')));
if (JSON.stringify(before) !== JSON.stringify(after)) throw Error('source changed during qualification');
const current = JSON.parse(cp.execFileSync(process.execPath, [path.join(out, 'snapshot.cjs')]));
if (JSON.stringify(after) !== JSON.stringify(current)) throw Error('source changed after qualification');
const binaries = {};
for (const name of ['protocol-client.log', 'cargo-bins.log']) {
  const log = fs.readFileSync(path.join(out, name), 'utf8');
  for (const match of log.matchAll(/Running .* \((target\/debug\/deps\/[^)]+)\)/g)) {
    binaries[match[1]] = sha(fs.readFileSync(match[1]));
  }
}
const commit = cp.execFileSync('git', ['rev-parse', 'HEAD'], {encoding:'utf8'}).trim();
const entries = Object.entries(after);
const blobs = cp.execFileSync('git', ['cat-file', '--batch'], {
  input: entries.map(([p]) => `${commit}:${p}\n`).join(''), maxBuffer:256*1024*1024,
});
let offset = 0;
for (const [p, digest] of entries) {
  const newline = blobs.indexOf(10, offset);
  const header = /^([0-9a-f]+) blob (\d+)$/.exec(blobs.subarray(offset, newline).toString());
  if (newline < 0 || !header) throw Error(`invalid batch entry: ${p}`);
  const end = newline + 1 + Number(header[2]);
  if (blobs[end] !== 10 || sha(blobs.subarray(newline + 1, end)) !== digest) {
    throw Error(`commit/source mismatch: ${p}`);
  }
  offset = end + 1;
}
if (offset !== blobs.length) throw Error('trailing git batch output');
const result = {commit, sources: Object.keys(after).length, binaries, frozenSources: true, committedSourcesMatch: true};
fs.writeFileSync(path.join(out, 'audit.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({commit, sources: result.sources, binaries: Object.keys(binaries).length, success:true}));
