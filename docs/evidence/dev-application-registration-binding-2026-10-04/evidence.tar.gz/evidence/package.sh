#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-application-binding-20261004-poc1TjOT
destination="$repo/docs/evidence/dev-application-registration-binding-2026-10-04"
cd "$repo"
node "$out/audit.cjs"
mkdir -p "$destination" "$out/evidence" "$out/verify"
node - "$out" <<'JS'
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = process.argv[2];
const names = fs.readdirSync(root).filter(n => fs.lstatSync(path.join(root,n)).isFile()).sort();
const manifest = names.map(n => {
  const bytes = fs.readFileSync(path.join(root,n));
  fs.writeFileSync(path.join(root,'evidence',n),bytes);
  return crypto.createHash('sha256').update(bytes).digest('hex') + '  ' + n;
});
fs.writeFileSync(path.join(root,'evidence','SHA256SUMS'),manifest.join('\n')+'\n');
JS
tar --sort=name -czf "$destination/evidence.tar.gz" -C "$out" evidence
tar -xzf "$destination/evidence.tar.gz" -C "$out/verify"
cd "$out/verify/evidence"
sha256sum -c SHA256SUMS
cmp source.patch "$out/source.patch"
sha256sum "$destination/evidence.tar.gz" source.patch
