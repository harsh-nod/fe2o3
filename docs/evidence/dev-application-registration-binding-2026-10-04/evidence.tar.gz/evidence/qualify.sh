#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-application-binding-20261004-poc1TjOT
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
node "$out/snapshot.cjs" > "$out/sources-before.json"
git rev-parse HEAD > "$out/base-commit.txt"
rustc -Vv > "$out/rustc-version.txt"
cargo -V > "$out/cargo-version.txt"
run() {
    local name=$1
    shift
    printf 'START %s\n' "$name"
    if "$@" > "$out/$name.log" 2>&1; then
        printf 'PASS %s\n' "$name"
    else
        local status=$?
        tail -n 80 "$out/$name.log"
        printf 'FAIL %s: %s\n' "$name" "$status"
        return "$status"
    fi
}
run protocol-client cargo test --offline --locked -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-protocol -p fe2o3-compiler-execution-client -- --test-threads=1
run cargo-bins cargo test --offline --locked -p cargo-fe2o3 --bins -- --test-threads=1
run clippy cargo clippy --offline --locked -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-protocol -p fe2o3-compiler-execution-client -p cargo-fe2o3 --all-targets --no-deps -- -D warnings
run format cargo fmt -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-protocol -p fe2o3-compiler-execution-client -p cargo-fe2o3 --check
run whitespace git diff --check
node "$out/snapshot.cjs" > "$out/sources-after.json"
cmp "$out/sources-before.json" "$out/sources-after.json"
printf 'PASS frozen sources\n'
