const fs = require('node:fs');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const paths = cp.execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z'], {maxBuffer: 32 * 1024 * 1024})
  .toString().split('\0').filter(p => p && (p.startsWith('crates/') || p.startsWith('.cargo/') || /^(Cargo\.(toml|lock)|rust-toolchain\.toml|rustfmt\.toml)$/.test(p)));
const files = Object.fromEntries([...new Set(paths)].sort().map(p => [p, crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')]));
process.stdout.write(JSON.stringify(files, null, 2) + '\n');
