#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
expected=$1
out=$2
test "$(git rev-parse HEAD)" = "$expected"
mkdir "$out"
export GIT_SSL_CAINFO=/home/harsh/.codex-openai/amd-zscaler-ca.pem
branch=refs/heads/codex/r65-runtime-drain-versions
for remote in origin upstream; do
    date -u +%FT%TZ > "$out/$remote-started"
    git push "$remote" "HEAD:$branch" > "$out/$remote-push.log" 2>&1
    git ls-remote --exit-code "$remote" "$branch" > "$out/$remote-observed.log"
    test "$(cat "$out/$remote-observed.log")" = "$(printf '%s\t%s' "$expected" "$branch")"
    date -u +%FT%TZ > "$out/$remote-finished"
done
