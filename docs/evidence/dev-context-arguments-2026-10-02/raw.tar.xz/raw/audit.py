"""Check retained CPU receipts and exact executable rosters, not native authority."""

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '25ba6ee2a78e524d98820ac4a57908b9f64a4167'
PINS = {
    'capture.py': '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1',
    'final_checks.py': 'b3ecfc5321f35d657a09987684bdf30587e2cca2469ad3fded059abbcd5e2314',
}


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def module(name):
    path = RAW / (name + '.py')
    assert sha(path) == PINS[path.name]
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


capture = module('capture')
checks = module('final_checks')
source = capture.snapshot()
assert source == read(RAW / 'context-fixture-03/source-before.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
subprocess.run(['git', 'diff', '--exit-code', BASE, '--', 'crates/fe2o3-runtime',
                'crates/fe2o3-runtime-model', 'crates/fe2o3-kfd'], cwd=ROOT, check=True)
jobs = list(checks.JOBS) + [
    ('libraries-final', '900s', checks.CARGO + ['test', *checks.COMMON,
        *checks.HOST_MACROS, '--all-features', '--lib', '--', '--test-threads=1']),
    ('runtime-final', '900s', checks.CARGO + ['test', *checks.COMMON,
        '-p', 'fe2o3-runtime', '--all-features', '--lib', '--', '--test-threads=1']),
    ('macro-integration-final', '1200s', checks.CARGO + ['test', *checks.COMMON,
        '-p', 'fe2o3-macros', '--test', 'renamed_dependency', '--test',
        'typed_kernel_fixtures', '--', '--test-threads=1']),
    ('context-fixture-03', '600s', checks.CARGO + ['test', '--offline', '--locked',
        '--manifest-path', checks.FIXTURE + 'generic-worker-v3-adapter/Cargo.toml',
        '--target-dir', 'target/generic-worker-v3-adapter-test', '--lib',
        '--', '--test-threads=1']),
    ('fixture-build-final', '600s', checks.CARGO + ['test', '--offline', '--locked',
        '--manifest-path', checks.FIXTURE + 'generic-worker-v3-adapter/Cargo.toml',
        '--target-dir', 'target/generic-worker-v3-adapter-test', '--lib',
        '--no-run', '--message-format=json']),
]
receipts = {}
for label, bound, command in jobs:
    directory = RAW / label
    receipt = read(directory / 'receipt.json')
    invocation = read(directory / 'command.json')
    assert all(receipt[key] == value for key, value in invocation.items()), label
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', bound, *command], label
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, label
    assert receipt['base'] == BASE and receipt['cwd'] == str(ROOT), label
    assert receipt['controller_sha256'] == PINS['capture.py'], label
    assert receipt['environment'] == capture.ENV, label
    assert read(directory / 'source-before.json') == read(directory / 'source-after.json') == source, label
    for output in ['stdout', 'stderr']:
        assert sha(directory / output) == receipt[output + '_sha256'], label
    receipts[label] = {'receipt_sha256': sha(directory / 'receipt.json')}

expected = {
    'libraries-final': [(307, 0, 4), (64, 0, 0)],
    'runtime-final': [(2198, 0, 32)],
    'context-fixture-03': [(5, 0, 0)],
    'macro-integration-final': [(2, 0, 0), (9, 0, 0)],
    'host-ui-final': [(1, 0, 0)] * 4,
    'doc-tests-final': [(7, 0, 0), (23, 0, 0), (0, 0, 0)],
}
for label, summaries in expected.items():
    output = (RAW / label / 'stdout').read_text()
    actual = [tuple(map(int, values)) for values in re.findall(
        r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; 0 filtered out;',
        output, re.M)]
    assert actual == summaries, (label, actual)
    assert len(re.findall(r'^test .+ \.\.\. ok$', output, re.M)) == sum(row[0] for row in summaries), label
    receipts[label]['summaries'] = actual

rosters = {}
sysroot = Path(subprocess.check_output(
    ['rustc', '+nightly-2026-04-03', '--print', 'sysroot'],
    env=capture.ENV, text=True, timeout=30).strip())
rust_libraries = sysroot / 'lib/rustlib/x86_64-unknown-linux-gnu/lib'
roster_environment = dict(capture.ENV, LD_LIBRARY_PATH=str(rust_libraries))
for build, run in [('library-build-final', 'libraries-final'),
                   ('runtime-build-final', 'runtime-final'),
                   ('fixture-build-final', 'context-fixture-03')]:
    artifacts = read(RAW / build / 'receipt.json')['executables']
    tested = (RAW / run / 'stdout').read_text()
    executed = (RAW / run / 'stderr').read_text()
    names = []
    for filename, artifact in artifacts.items():
        path = Path(filename)
        assert artifact['test'] is True and sha(path) == artifact['sha256']
        assert path.stat().st_size == artifact['byte_length']
        assert '(' + str(path.relative_to(ROOT)) + ')' in executed, filename
        listing = subprocess.check_output([filename, '--list'], cwd=ROOT,
                                          env=roster_environment, text=True, timeout=60)
        roster = re.findall(r'^(.+): test$', listing, re.M)
        assert len(roster) == len(set(roster)) and roster, filename
        names.extend(roster)
        rosters[filename] = {'artifact': artifact, 'listing': listing, 'tests': roster,
                             'environment': roster_environment}
    outcomes = re.findall(r'^test (.+?) \.\.\. (?:ok|ignored(?:, [^\n]*)?)$', tested, re.M)
    assert sorted(names) == sorted(outcomes), run

with (RAW / 'rosters.json').open('x') as output:
    json.dump(rosters, output, indent=2, sort_keys=True)
    output.write('\n')
result = {'accepted': True, 'scope': 'local CPU qualification only', 'base': BASE,
          'source_files': len(source), 'selected': receipts,
          'rosters_sha256': sha(RAW / 'rosters.json'),
          'unit_passes': 2569, 'unit_ignores': 36, 'fixture_passes': 5,
          'macro_integration_passes': 11, 'host_ui_suites': 4, 'doctest_passes': 30,
          'hardware_run': False, 'solver_run': False}
with (RAW / 'audit-01.json').open('x') as output:
    json.dump(result, output, indent=2, sort_keys=True)
    output.write('\n')
print(json.dumps(result, sort_keys=True))
