"""Run remaining bounded checks on the frozen Context argument source."""

from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
CARGO = ['cargo', '+nightly-2026-04-03']
COMMON = ['--locked', '--offline', '--jobs', '4']
HOST_MACROS = ['-p', 'fe2o3-host', '-p', 'fe2o3-macros']
FIXTURE = 'crates/fe2o3-macros/tests/fixtures/'
FORMATTED = [
    FIXTURE + 'generic-worker-v3-adapter/src/lib.rs',
    FIXTURE + 'generic-worker-v3-adapter/src/context_arguments.rs',
    *[FIXTURE + 'generic-worker-v3-adapter/src/bin/' + name + '.rs' for name in [
        'context_aggregate_unsupported', 'context_kernel_substitution',
        'context_mapped_unsupported', 'context_pointer_unsupported',
        'context_private_fields', 'context_wrong_access', 'context_wrong_element',
    ]],
    FIXTURE + 'renamed-typed-host/src/main.rs',
    FIXTURE + 'renamed-typed-host/host-stub/src/lib.rs',
]
JOBS = [
    ('library-build-final', '900s', CARGO + ['test', *COMMON, *HOST_MACROS,
        '--all-features', '--lib', '--no-run', '--message-format=json']),
    ('runtime-build-final', '900s', CARGO + ['test', *COMMON, '-p', 'fe2o3-runtime',
        '--all-features', '--lib', '--no-run', '--message-format=json']),
    ('clippy-final', '1200s', CARGO + ['clippy', *COMMON, *HOST_MACROS,
        '--all-features', '--lib', '--tests', '--', '-D', 'warnings']),
    ('doc-tests-final', '900s', CARGO + ['test', *COMMON, *HOST_MACROS,
        '--no-default-features', '--doc']),
    ('host-ui-final', '1200s', CARGO + ['test', *COMMON, '-p', 'fe2o3-host',
        '--no-default-features', '--test', 'generated_spi_ui',
        '--test', 'worker_v3_verification_admission_ui',
        '--test', 'production_application_handoff_ui',
        '--test', 'recovered_worker_v3_admission_ui', '--', '--test-threads=1']),
    ('format-selected-final', '300s', CARGO + ['fmt', *HOST_MACROS, '--', '--check']),
    ('format-changed-fixtures-final', '180s',
        ['rustfmt', '+nightly-2026-04-03', '--edition', '2024', '--check', *FORMATTED]),
    ('whitespace-final', '60s', ['git', 'diff', '--check']),
]

if __name__ == '__main__':
    for label, bound, command in JOBS:
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'),
                                 label, bound, *command], check=False)
        if result.returncode:
            sys.exit(result.returncode)
