"""Record one bounded local CPU/proof command against an exact source cohort."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
SCOPES = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'scripts', '.github', 'tests', 'examples', 'tools', 'toolchains', 'deployment']
BASE = '902e05a54a665674d7f4106f123b161cf8690a8b'
VERUS = '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', *SCOPES], cwd=ROOT).split(b'\0')
    return {path.decode(): sha((ROOT / path.decode()).read_bytes()) for path in sorted(set(paths)) if path}


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


label, *command = sys.argv[1:]
assert label and '/' not in label and command
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
out = RAW / label
out.mkdir()
(RAW / 'tmp').mkdir(exist_ok=True)
env = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
           LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='4', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1',
           CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
           FE2O3_HIP_SYS_DISABLE='1', RUST_TEST_THREADS='1', TMPDIR=str(RAW / 'tmp'),
           VERUS=VERUS + '/verus', VERUS_Z3_PATH=VERUS + '/z3')
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
before = snapshot()
save(out / 'source-before.json', before)
record = dict(command=command, environment=env, cwd=str(ROOT), base=BASE,
              controller_sha256=sha(Path(__file__).read_bytes()), started=time.time())
save(out / 'command.json', record)
with (out / 'stdout').open('xb') as stdout, (out / 'stderr').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    record['process_group'] = process.pid
    save(out / 'running.json', record)
    timed_out = False
    try:
        code = process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
    try:
        os.killpg(process.pid, 0)
        group_absent = False
    except ProcessLookupError:
        group_absent = True
    if not group_absent:
        os.killpg(process.pid, signal.SIGTERM)
        time.sleep(2)
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
after = snapshot()
save(out / 'source-after.json', after)
record.update(exit=code, finished=time.time(), timed_out=timed_out, group_absent=group_absent,
              source_unchanged=before == after,
              stdout_sha256=sha((out / 'stdout').read_bytes()), stderr_sha256=sha((out / 'stderr').read_bytes()))
save(out / 'receipt.json', record)
print(json.dumps({key: record[key] for key in ['command', 'exit', 'timed_out', 'group_absent', 'source_unchanged']}))
raise SystemExit(code if before == after and group_absent else 125)
