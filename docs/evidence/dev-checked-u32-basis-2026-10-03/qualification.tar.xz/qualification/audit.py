"""Audit final CPU/proof receipts without promoting them to kernel authority."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '902e05a54a665674d7f4106f123b161cf8690a8b'
VERUS = '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f'
ACCEPTED = (
    'campaign-03', 'verifier-lib-02', 'verifier-public-03', 'verifier-docs-02',
    'verifier-clippy-02', 'genuine-source-02', 'format-02', 'ci-dispatch-02',
    'shell-wrapper-01', 'no-default-01',
)
COMMANDS = {
    'campaign-03': f'python3 -I -B crates/fe2o3-verifier/verus/checked_u32_prefix_check.py --verus {VERUS}/verus --output {RAW}/proof-campaign-03',
    'verifier-lib-02': 'cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --all-features --lib',
    'verifier-public-03': 'cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --all-features --test gfx942_local_checked_u32_add_v1',
    'verifier-docs-02': 'cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --all-features --doc',
    'verifier-clippy-02': 'cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-verifier --all-features --lib -- -D warnings',
    'genuine-source-02': 'cargo +nightly-2026-04-03 test --locked --offline -p rustc-codegen-fe2o3 --test production_extraction_driver_v1 checked_u32_prefix_extraction_v1::genuine_checked_u32_prefix_extraction_uses_actual_sources_and_rejects_unsupported_profiles -- --ignored --exact --nocapture --test-threads=1',
    'format-02': 'rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/source_prefix.rs crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/source_prefix/basis.rs crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/source_prefix/basis_body.rs',
    'ci-dispatch-02': 'env PATH=/home/harsh/.codex-openai/packages/standalone/releases/0.160.0-x86_64-unknown-linux-musl/codex-path:/home/harsh/.cargo/bin:/usr/local/bin:/usr/bin:/bin bash scripts/tests/ci-local-test-gate.sh',
    'shell-wrapper-01': f'env RUNNER_TEMP={RAW}/tmp bash crates/fe2o3-verifier/verus/run-checked-u32-prefix.sh',
    'no-default-01': 'cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-verifier --no-default-features --lib',
}
ENV = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
           LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='4', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1',
           CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
           FE2O3_HIP_SYS_DISABLE='1', RUST_TEST_THREADS='1', TMPDIR=str(RAW / 'tmp'),
           VERUS=VERUS + '/verus', VERUS_Z3_PATH=VERUS + '/z3')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


cohort = read(RAW / 'campaign-03/source-before.json')
controller = sha((RAW / 'run.py').read_bytes())
assert controller == '9570548cf9a6a2d70364977612a9b02e08d052feb4e55c1fdc7214bc92bd69c3'
for stage in ACCEPTED:
    folder = RAW / stage
    receipt = read(folder / 'receipt.json')
    assert receipt['exit'] == 0 and receipt['group_absent'] is True
    assert receipt['source_unchanged'] is True and receipt['timed_out'] is False
    assert receipt['base'] == BASE and receipt['cwd'] == str(ROOT)
    assert receipt['controller_sha256'] == controller
    assert receipt['command'] == shlex.split(COMMANDS[stage]) and receipt['environment'] == ENV
    assert read(folder / 'source-before.json') == cohort == read(folder / 'source-after.json')
    for stream in ('stdout', 'stderr'):
        assert sha((folder / stream).read_bytes()) == receipt[stream + '_sha256']
for path, expected in cohort.items():
    assert sha((ROOT / path).read_bytes()) == expected, path
for stage, summary in (
    ('verifier-lib-02', '120 passed; 0 failed; 4 ignored;'),
    ('verifier-public-03', '7 passed; 0 failed; 0 ignored;'),
    ('verifier-docs-02', '30 passed; 0 failed; 0 ignored;'),
    ('genuine-source-02', '1 passed; 0 failed;'),
):
    assert summary in (RAW / stage / 'stdout').read_text()
genuine = (RAW / 'genuine-source-02/stderr').read_text()
for profile in ('checked-u32-prefix', 'checked-u32-prefix-second'):
    assert f'checked-u32 case={profile} status=exit status: 0' in genuine
for rejection in ('MissingEntryHelperCheckedAdd', 'AmbiguousEntryHelperCheckedAdd',
                  'RootCount', 'unsupported checked-u32 entry prefix: Source'):
    assert rejection in genuine
assert genuine.count('fe2o3 checked-u32-prefix extraction: ') == 2

spec = importlib.util.spec_from_file_location(
    'basis_audit_check', ROOT / 'crates/fe2o3-verifier/verus/checked_u32_prefix_check.py')
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)
proof = RAW / 'proof-campaign-03'
assert read(proof / 'environment.json') == dict(
    HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin', LANG='C.UTF-8',
    LC_ALL='C.UTF-8', RUSTUP_HOME='/home/harsh/.rustup', CARGO_HOME='/home/harsh/.cargo',
    VERUS_Z3_PATH=VERUS + '/z3', TMPDIR=str(proof / 'tmp'))
result = read(proof / 'result.json')
assert result['accepted'] is True and result['source_unchanged'] is True
assert result['verified_obligations'] == 18 and result['logical_mutants'] == 16
assert result['controls'] == 8 and result['proves_argument_basis_initialization'] is True
assert result['proves_normalization_adapters'] is False
assert result['grants_application_authority'] is False
assert len(result['stages']) == 21 and all(row['accepted'] for row in result['stages'])
sources = check.snapshot()
for path, data in sources.items():
    assert (proof / 'inputs' / path).read_bytes() == data
for row in result['stages']:
    assert read(proof / row['name'] / 'record.json')['group_absent'] is True
for stage in ('release-before', 'release-after'):
    folder = proof / stage
    receipt = read(folder / 'record.json')
    assert receipt['status'] == 0
    assert receipt['command'] == ['/bin/sh', str(ROOT / check.support.CLOSURE), VERUS,
                                  str(ROOT / check.support.MANIFEST)]
    assert not (folder / 'stderr.log').read_bytes()
    assert (folder / 'stdout.log').read_text() == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n'
controls = proof / 'controls'
assert read(controls / 'record.json')['command'] == ['/usr/bin/python3', '-I', '-B', str(ROOT / check.TEST)]
assert read(controls / 'record.json')['status'] == 0 and not (controls / 'stdout.log').read_bytes()
assert '\nRan 8 tests in ' in (controls / 'stderr.log').read_text()
assert (controls / 'stderr.log').read_text().endswith('\nOK\n')
expected = [('positive-before', None, 'fold', None), ('positive-after', None, 'fold', None)]
expected.extend(('negative-' + name, body, 'fold', 'loop' if loop else 'post')
                for name, (body, loop) in check.mutants(sources[str(check.BODY)].decode()).items())
expected.extend(('negative-basis-' + name, body, 'basis', failure)
                for name, (body, failure) in check.basis_mutants(sources[str(check.BASIS_BODY)].decode()).items())
assert {row['name'] for row in result['stages']} == {'controls', 'release-before', 'release-after'} | {row[0] for row in expected}
for stage, mutation, target, failure in expected:
    staged = proof / (stage + '-source')
    for path in (check.PROOF, check.BODY, check.BASIS_BODY, check.base.BODY):
        data = mutation.encode() if mutation is not None and path == check.TARGETS[target]['body'] else sources[str(path)]
        assert (staged / path).read_bytes() == data
    folder = proof / stage
    status = next(row['status'] for row in result['stages'] if row['name'] == stage)
    receipt = read(folder / 'record.json')
    assert receipt['status'] == status
    assert receipt['command'] == [
        '/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5', '120', VERUS + '/verus',
        '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating', '--output-json',
        '--error-format=json', '--no-report-long-running', '--num-threads', '1', '--multiple-errors', '1',
        *(['--verify-function', '*' + check.TARGETS[target]['function'], '--verify-root'] if mutation is not None else []),
        str(staged / check.PROOF)]
    assert check.classify(status, (folder / 'stdout.log').read_text(), (folder / 'stderr.log').read_text(),
                          staged / check.PROOF, target, failure), stage
assert not list((RAW / 'tmp').iterdir()), 'owned scratch not cleaned'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
report = dict(accepted_stages=list(ACCEPTED), source_files=len(cohort), proof_files=len(sources),
              obligations=18, logical_mutants=16, runner_controls=8,
              application_authority=False, native_execution=False,
              controller_sha256=controller, audit_sha256=sha(Path(__file__).read_bytes()))
(RAW / 'audit.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
