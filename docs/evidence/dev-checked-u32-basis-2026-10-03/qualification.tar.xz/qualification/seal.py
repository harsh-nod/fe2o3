"""Archive the bounded local qualification, retaining failed attempts separately."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
DEST = ROOT / 'docs/evidence/dev-checked-u32-basis-2026-10-03'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


subprocess.run(['/usr/bin/python3', '-I', '-B', str(RAW / 'audit.py')], check=True)
patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--no-ext-diff'], cwd=ROOT)
assert patch and b'basis_body.rs' in patch and b'runtime-multi-gpu-critical-path.md' in patch
assert b'dev-owner-inspection' not in patch and b'qualification.tar.xz' not in patch
(RAW / 'candidate.patch').write_bytes(patch)
(RAW / 'README.md').write_bytes((DEST / 'README.md').read_bytes())
identities = {}
for stage in ('verifier-lib-02', 'verifier-public-03', 'genuine-source-02'):
    log = (RAW / stage / 'stderr').read_text()
    for name in re.findall(r'\((target/debug/deps/[^ )]+)\)', log):
        path = ROOT / name
        assert path.is_file()
        identities[name] = dict(bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
for name in ('target/debug/fe2o3-rustc-extract',):
    path = ROOT / name
    identities[name] = dict(bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
assert len(identities) == 4
save(RAW / 'binary-identities.json', identities)
toolchain = {}
for name, command in (
    ('rustc', ['rustc', '+nightly-2026-04-03', '-vV']),
    ('cargo', ['cargo', '+nightly-2026-04-03', '-V']),
):
    toolchain[name] = dict(command=command, stdout=subprocess.check_output(command, cwd=ROOT, text=True))
toolchain['verus_sha256'] = sha(Path('/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus').read_bytes())
save(RAW / 'toolchain.json', toolchain)
files = {}
for path in sorted(RAW.rglob('*')):
    assert not path.is_symlink(), path
    if path.is_file() and path.name != 'manifest.json':
        files[str(path.relative_to(RAW))] = dict(bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
save(RAW / 'manifest.json', files)
archive = DEST / 'qualification.tar.xz'
assert not archive.exists()
with tarfile.open(archive, 'w:xz') as output:
    for name in sorted([*files, 'manifest.json']):
        data = (RAW / name).read_bytes()
        if name in files:
            assert sha(data) == files[name]['sha256']
        info = tarfile.TarInfo('qualification/' + name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as archived:
    assert len(archived.getmembers()) == len(files) + 1
    for name, identity in files.items():
        data = archived.extractfile('qualification/' + name).read()
        assert len(data) == identity['bytes'] and sha(data) == identity['sha256']
metadata = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
                manifest_files=len(files), candidate_patch_sha256=sha(patch),
                audit_sha256=sha((RAW / 'audit.py').read_bytes()),
                base='902e05a54a665674d7f4106f123b161cf8690a8b',
                gpu_execution=False, grants_application_authority=False)
save(DEST / 'archive.json', metadata)
print(json.dumps(metadata, sort_keys=True))
