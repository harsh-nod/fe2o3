git status --short 
