git show -s --format=fuller --pretty=format:commit\ %H%ntree\ %T%nparents\ %P%nsubject\ %s HEAD 
