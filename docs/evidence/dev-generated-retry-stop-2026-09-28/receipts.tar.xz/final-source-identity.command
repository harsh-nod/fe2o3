git show -s --format=commit\ %H%ntree\ %T%nparents\ %P%nsubject\ %s HEAD 
