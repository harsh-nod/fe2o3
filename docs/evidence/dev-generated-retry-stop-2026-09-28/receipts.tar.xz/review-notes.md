# Generated Retry/Stop Review

Primary owns edits, integration, tests and signing. Two read-only agents
reviewed lower admission/continuation and runtime receipt/retirement coupling.
Neither ran builds/tests nor requested approvals.

## Production Argument

Ordinary binding failures classify as RejectedBeforeSideEffect, not retryable.
The lower ordinary path returns RetryableBeforeSideEffect only after a reserved
epoch's exact cancellation succeeds. Cancellation leaves queue, slot-generation
and next-generation history. Published/completed epochs cannot become vacant
except through recycle, which leaves a sticky recycled-generation marker.

Separate cancelled-only admission therefore requires nonpoisoned prepared state,
exact queue, no recycled or detached-predecessor history, at least one nonzero
slot generation, next >= 2, ordinary control and releasable completion state.
The strict pristine predicate is unchanged. Both use the existing rooted abort,
control cleanup, closing retake and terminal parent-transport implementation.

The compact unpublished continuation preserves queue, next generation, capacity
and account identity. It refunds the epoch table at detach and reacquires credit
at rebind; it does not promise continuous table-debit retention. Rebind validates
the historical queue before consuming continuation/data, then mints a fresh
pristine occurrence. MAX permits disposal but not preallocation or rebind.

Runtime RetryReady is set only from classified lower retry. It remains eligible
for authority-bracketed issue and Stop retirement, but generic observation does
not publish. Ready/no submission -> pristine abort; RetryReady -> cancelled-only
abort; Recycled -> recycled detach. Readback remains Recycled-only. Unknown
handoffs and live receipts cannot retire immediately. Submission release still
requires native retirement to have been recorded.

## Review Outcome And Corrections

No production correctness blocker found by the read-only reviews. Suggested
coverage was added for repeated retries, exact returned token retention,
unknown handoffs, positive metadata release, full-session foreign-key and
exhausted-counter rebind rejection, exact errors and pre-entry custody.

The foreign-key mutation is defensive private-state corruption, not a healthy
public queue migration. Lower constructed fixtures execute production state and
cleanup reducers; runtime receipt fixtures and metadata-only backend fixtures
are separate. They do not execute protected Worker-to-native composition or
the direct generated lane routing on hardware. No new formal proof was added.

Historical evidence is retained: the first added rebind assertion incorrectly
used equality on an error enum without PartialEq; this was replaced with exact
pattern matching. The positive metadata retirement fixture initially retained
control in its host shell, contradicting adopted state. The real disposal guard
rejected it; the fixture was corrected without weakening production checks.
The first serial runtime run lost its exec handle without a terminal receipt;
see runtime-full.interrupted.md. It is not a completed test result.

## Next Gap

Ordinary MaterializedPrepared cancellation still conservatively returns TooLate.
It can follow either newly bound cancelled-only history or reuse of a previously
recycled attached recipe. Supporting both is required; do not infer provenance
from performance.data_path or send both to cancelled-only abort.

Relevant sources: kfd_backend.rs cancel_v1 (around 12869/12918),
compute_dispatch.rs publish reused_attached (around 2640), retry-prepared
installation (around 2915), dependency-retain handoff (around 1688), and
tests/sdma_pending_allocation_tests.rs materialized host-read admission.

Future implementation must keep Active indexed through lower retirement and
returned DATA rooting, support primary/AUX lanes, preserve successors' retains,
avoid writebacks/dirty extents, and settle cancellation only after exact owner,
reservation, allocation/module and lane-lease settlement. Existing scripted
materialization bypasses retry publication, so qualification needs a production-
coupled retry/prepared/cancellation boundary plus separate native evidence.
