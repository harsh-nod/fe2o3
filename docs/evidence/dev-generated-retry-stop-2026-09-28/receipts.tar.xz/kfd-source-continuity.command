git diff --exit-code 3f69dcf058e49a8fd8210001a0ebdf493e2a12f3 e77f8524379bf8a2e06bdcbfdfced303687908b2 -- crates/fe2o3-kfd 
