# Frozen Qualification Receipts

Do not append to or modify this directory after archiving.

Qualified source: e77f8524379bf8a2e06bdcbfdfced303687908b2
Qualified tree: bce8976f9936441ea956a828b16a61727cbc0693
Production fix: 3f69dcf058e49a8fd8210001a0ebdf493e2a12f3

Every recorded final qualification command has a terminal receipt. The earlier
runtime-full run is explicitly incomplete (missing process handle and terminal
receipt), not passing; runtime-full.interrupted.md records that limitation.
Final runtime-full is 1758 passed, 3 failed, 28 ignored; isolated KFD telemetry
also fails. Neither failure gate is waived. No hardware run or benchmark occurred.

The qualified-kfd-pristine run preceded the two commits but used their exact KFD
source; source continuity records and the signed commits preserve that identity.
Post-archive documentation, signature checks and pushes belong in a separate
publication receipt directory.
