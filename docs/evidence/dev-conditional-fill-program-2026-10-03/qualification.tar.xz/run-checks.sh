#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-profile-20261003-k0UOEj
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --lib >"$scratch/verifier-lib.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --doc >"$scratch/verifier-doc.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --test compiler_proof_binding_v4 >"$scratch/compiler-binding.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib >"$scratch/host-lib.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-verifier -p rustc-codegen-fe2o3 --lib --no-deps -- -D warnings >"$scratch/clippy.log" 2>&1
rustfmt +nightly-2026-04-03 --edition 2024 --check crates/fe2o3-verifier/src/conditional_fill_program_v1.rs crates/rustc-codegen-fe2o3/tests/production_extraction_driver_v1.rs
git diff --check
