#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-clone-compat-20261004-3OE6rF4M
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/qualify.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
cargo +nightly-2026-04-03 test -p fe2o3-protected-service-spawn -p fe2o3-compiler-execution-supervisor --lib --no-run --message-format=json --locked --offline > "$scratch/build.json" 2> "$scratch/build.log"
root_binary=$(jq -r 'select(.reason=="compiler-artifact" and .target.name=="fe2o3_protected_service_spawn" and .profile.test and .executable != null) | .executable' "$scratch/build.json")
supervisor_binary=$(jq -r 'select(.reason=="compiler-artifact" and .target.name=="fe2o3_compiler_execution_supervisor" and .profile.test and .executable != null) | .executable' "$scratch/build.json")
sha256sum "$root_binary" "$supervisor_binary" > "$scratch/binaries.before.sha256"
timeout --kill-after=5s 120s "$scratch/systemd-filter" "$supervisor_binary" --nocapture --test-threads=1 > "$scratch/supervisor-systemd.log" 2>&1
FE2O3_STATIC_PREEXEC_LAUNCHER="$scratch/static/fe2o3-static-preexec-launcher" timeout --kill-after=5s 30s "$scratch/systemd-filter" "$supervisor_binary" --exact tests::real_static_launcher_crosses_both_exec_boundaries --ignored --nocapture --test-threads=1 > "$scratch/static-launch-systemd.log" 2>&1
for mode in plain systemd; do
    for case in native enosys eperm einval eagain legacy_eperm handler restore_once restore_controller drop_retry; do
        timeout --kill-after=5s 30s /mnt/c/Windows/System32/wsl.exe --user root --exec \
            /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
            --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
            --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN \
            --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
            /bin/bash "$scratch/inside-root.sh" "$root_binary" "$mode" "$case" \
            > "$scratch/root-$mode-$case.log" 2>&1
    done
done
sha256sum "$root_binary" "$supervisor_binary" > "$scratch/binaries.after.sha256"
cmp "$scratch/binaries.before.sha256" "$scratch/binaries.after.sha256"
