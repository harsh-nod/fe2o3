#!/bin/bash
set -euo pipefail
chmod 1777 /tmp
cp "$1" /tmp/root-spawn-test
chmod 555 /tmp/root-spawn-test
cmp "$1" /tmp/root-spawn-test
export FE2O3_ROOT_CLONE_CASE="$3"
test_name=syscall::tests::root_atomic_pidfd_launch
if test "$3" = restore_controller; then
    test_name=syscall::tests::root_restore_failure_is_contained
fi
if test "$2" = systemd; then
    exec /home/harsh/.codex-tmp/fe2o3-clone-compat-20261004-3OE6rF4M/systemd-filter /tmp/root-spawn-test --exact "$test_name" --ignored --nocapture --test-threads=1
fi
exec /tmp/root-spawn-test --exact "$test_name" --ignored --nocapture --test-threads=1
