#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-clone-compat-20261004-3OE6rF4M
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-clone-compatibility-2026-10-04"
test "$(cat "$scratch/final.status")" = 0
test "$(cat "$scratch/qualify.status")" = 0
test "$(cat "$scratch/check.status")" = 0
cd "$repo"
git diff --cached --binary -- crates/fe2o3-protected-service-spawn crates/fe2o3-compiler-execution-supervisor > "$scratch/code.patch"
git rev-parse HEAD > "$scratch/base-commit.txt"
uname -a > "$scratch/uname.txt"
systemd --version > "$scratch/systemd-version.txt"
sha256sum /usr/lib/x86_64-linux-gnu/systemd/libsystemd-shared-255.so > "$scratch/systemd-library.sha256"
objdump -d --disassemble=seccomp_restrict_namespaces /usr/lib/x86_64-linux-gnu/systemd/libsystemd-shared-255.so > "$scratch/systemd-namespace-filter.txt"
mkdir -p "$evidence"
cd "$scratch"
sha256sum code.patch systemd-filter static/fe2o3-static-preexec-launcher > artifact-hashes.txt
tar -czf "$evidence/evidence.tar.gz" \
    check.sh qualify.sh inside-root.sh final-check.sh package.sh systemd-filter.c \
    check.status qualify.status final.status unit.log doc.log clippy.log \
    static-configure.log static-build.log static-test.log static-launch-systemd.log \
    supervisor-systemd.log root-*.log build.json build.log \
    binaries.before.sha256 binaries.after.sha256 format.log whitespace.log \
    base-commit.txt code.patch artifact-hashes.txt uname.txt systemd-version.txt \
    systemd-library.sha256 systemd-namespace-filter.txt \
    static/fe2o3-static-preexec-launcher static/fe2o3-static-preexec.readelf.txt
sha256sum "$evidence/evidence.tar.gz"
cat artifact-hashes.txt binaries.after.sha256
