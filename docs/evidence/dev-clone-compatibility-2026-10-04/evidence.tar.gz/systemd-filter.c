#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>

static void expect_error(const char *name, long result, int expected) {
    int error = errno;
    fprintf(stderr, "%s result=%ld errno=%d expected=%d\n", name, result, error, expected);
    if (result != -1 || error != expected)
        exit(70);
}

int main(int argc, char **argv) {
    if (argc < 2)
        return 64;
    const char *library = "/usr/lib/x86_64-linux-gnu/systemd/libsystemd-shared-255.so";
    void *handle = dlopen(library, RTLD_NOW | RTLD_LOCAL);
    if (!handle) {
        fprintf(stderr, "%s\n", dlerror());
        return 65;
    }
    void *symbol = dlsym(handle, "seccomp_restrict_namespaces");
    int (*restrict_namespaces)(unsigned long) = NULL;
    _Static_assert(sizeof(symbol) == sizeof(restrict_namespaces), "function pointer ABI");
    memcpy(&restrict_namespaces, &symbol, sizeof(symbol));
    if (!restrict_namespaces || prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0)
        return 66;
    int result = restrict_namespaces(0);
    fprintf(stderr, "systemd namespace helper result=%d\n", result);
    if (result < 0)
        return 67;
    expect_error("clone3", syscall(SYS_clone3, NULL, 0), ENOSYS);
    expect_error("setns", syscall(SYS_setns, -1, 0), EPERM);
    expect_error("unshare user", syscall(SYS_unshare, CLONE_NEWUSER), EPERM);
    expect_error("unshare mount", syscall(SYS_unshare, CLONE_NEWNS), EPERM);
    long child = syscall(SYS_clone, CLONE_NEWUSER | SIGCHLD, NULL, NULL, NULL, 0UL);
    if (child == 0)
        _exit(71);
    if (child > 0) {
        kill((pid_t)child, SIGKILL);
        waitpid((pid_t)child, NULL, 0);
        return 72;
    }
    expect_error("clone user", child, EPERM);
    execv(argv[1], &argv[1]);
    perror("execv");
    return 68;
}
