#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-clone-compat-20261004-3OE6rF4M
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/check.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
packages=(-p fe2o3-protected-service-spawn -p fe2o3-compiler-execution-supervisor -p fe2o3-compiler-execution-coordinator -p fe2o3-external-anchor-coordinator)
cargo +nightly-2026-04-03 test "${packages[@]}" --lib --locked --offline -- --test-threads=1 > "$scratch/unit.log" 2>&1
cargo +nightly-2026-04-03 test "${packages[@]}" --doc --locked --offline > "$scratch/doc.log" 2>&1
cargo +nightly-2026-04-03 clippy "${packages[@]}" --all-targets --locked --offline -- -D warnings > "$scratch/clippy.log" 2>&1
