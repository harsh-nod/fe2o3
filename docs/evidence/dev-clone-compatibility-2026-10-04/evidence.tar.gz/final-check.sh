#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-clone-compat-20261004-3OE6rF4M
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/final.status"' EXIT
bash "$scratch/check.sh"
cmake -S tools/fe2o3-static-preexec-launcher -B "$scratch/static" -DCMAKE_BUILD_TYPE=Release > "$scratch/static-configure.log" 2>&1
cmake --build "$scratch/static" --parallel 2 > "$scratch/static-build.log" 2>&1
ctest --test-dir "$scratch/static" --output-on-failure > "$scratch/static-test.log" 2>&1
bash "$scratch/qualify.sh"
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check \
    crates/fe2o3-protected-service-spawn/src/syscall.rs \
    crates/fe2o3-protected-service-spawn/src/syscall/tests.rs \
    crates/fe2o3-protected-service-spawn/src/syscall/signal_mask_tests.rs \
    crates/fe2o3-compiler-execution-supervisor/src/process.rs \
    crates/fe2o3-compiler-execution-supervisor/src/process/signal_mask_tests.rs \
    crates/fe2o3-compiler-execution-supervisor/src/tests.rs \
    crates/fe2o3-compiler-execution-supervisor/src/tests/clone_compat.rs > "$scratch/format.log" 2>&1
git diff --check > "$scratch/whitespace.log" 2>&1
