# Completion Source Rollback Qualification

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`, branch
`codex/r65-runtime-drain-versions`. All solver/build/test stages ran serially.
No MI300X or other remote hardware was used. The GitHub issue capture is a
read-only API query, not hardware qualification.

## Source History

- `c4d778cab75f32345923bf2b54bc30dc56b9c749`: shared completion cleanup,
  consuming/forwarding adapters, common proof schema, composed contracts and
  witnesses, eight-case terminal-prefix CPU oracle, fail-closed qualification.
- `dca90b9e1`: express eager-cancellation mutation with explicit evaluation
  temporaries instead of Boolean bitwise OR, which the pinned verifier does
  not support. Production and proof contracts are unchanged by this correction.
- `f225e1d66e026ad3f12c71b8d82e3fd8ad5d7708`, final qualified source,
  adds the exact `unable to prove post-condition of closure`
  logical error only for the cancellation-adapter selector, with hostile
  diagnostic calibration. The frozen base classifier is unchanged.

Development `composed-dev-*` records include unsupported closure syntax,
the initially missing closure projection contract, witness index/spec-mode
errors, and subsequent positives. They are not signed campaign acceptance.
The completed initial standalone campaigns remain under `bound-campaign` and
`batch-campaign`. `composed-campaign` stops at the unsupported Boolean-OR
negative; its frontend failure must not count as a logical negative.
The intermediate `composed-final` campaign passes. `adapters-final` then stops
because the exact closure-postcondition diagnostic was not yet recognized.
Both are preserved; neither is substituted for final-source qualification.

Final signed campaigns use `bound-final`, `batch-final`, `composed-qualified`
and `adapters-qualified`. Each requires an original,
exactly relocated and closing whole-crate positive, all declared executable
logical negatives, signature/source continuity and pinned tool closure.
Standalone cancellation retains `--no-cheating`; batch/composition explicitly
use the unchanged two reservation-content contracts instead.

## Reproduction

Select a new absolute output root outside the repository and use the pinned
Verus release authenticated by `pins/VERUS_CLOSURE_MANIFEST`. Do not reuse output
directories: controllers deliberately refuse them. From the repository root:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-source-rollback.py --output "$OUT/composed-qualified" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-source-rollback.py --adapters --output "$OUT/adapters-qualified" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-bound-cancel.py --output "$OUT/bound-final" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-event-batch-release.py --output "$OUT/batch-final" --verus "$VERUS"
python3 -I -B "$OUT/qualify.py" "$REPO"
```

The included `qualify.py` records full serial commands, exact test summaries,
source hashes and owned process lifetimes under `cpu-complete` on a new full run. It requires the
same signed source as `bound-final`. It runs the KFD library suite excluding
`construction_primary`, the full runtime library suite, three crates' doctests,
strict all-feature/all-target Clippy, no-default-feature production checks,
workspace/included-body formatting and diff checks. The compiler version and
selected environment are retained. The 320 excluded KFD construction tests
were not rerun in this packet; no previous full-suite result is attributed to it.

This packet retains the first script as `qualify-initial.py` and its output as
`cpu-final`. Compiler, KFD and runtime checks pass there. All 124 doctests also
exit successfully, but that script wrongly expected the runtime 53-test total
as one summary. Rustdoc emits 9 and 44 separately. The corrected exact four
summary expectation is in `qualify.py`; `--rest` reruns doctests and all remaining
checks under `cpu-rest`, bracketed by the same signed source. No failed test was
reclassified, and the original harness refusal remains in evidence.

During CPU qualification, the unused, non-running cached host-test executable
`target/debug/deps/fe2o3_host-fee15e70660320e5` (487795384 bytes) was removed from
this owned worktree after checking file ownership and `fuser`. Its absence was
checked. No source, retained evidence or foreign/shared-machine files were removed.

`audit-final.py` independently checks final result/source records and confirms
all owned campaign/CPU process groups are absent. Its total includes initial
runs and the stopped campaign; it is specific to this evidence packet, not a
generic acceptance runner for a different run history.

For archival, the raw root receives a sorted SHA256SUMS manifest, is compressed,
then extracted into a fresh owned directory. Every restored hash and recursive
content comparison must pass before removing that directory and verifying its
absence. The final publication report records the archive counts and digest.
