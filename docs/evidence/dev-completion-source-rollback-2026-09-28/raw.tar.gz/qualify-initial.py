#!/usr/bin/env python3
"""Serial CPU/static qualification at an already signed campaign source."""
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import signal
import sys

repo = Path(sys.argv[1]).resolve()
root = Path(__file__).resolve().parent
out = root / "cpu-final"
out.mkdir()
os.chdir(repo)
campaign = runpy.run_path(str(repo / "crates/fe2o3-runtime-model/verus/check-completion-source-rollback.py"))["campaign"]()
classifier = campaign.inherited()
leaf = classifier.inherited()
prior = leaf.load("cpu_source", repo / leaf.PRIOR, leaf.PRIOR_SHA)
prior.INPUTS = ["Cargo.toml", "Cargo.lock", "rust-toolchain.toml", ".cargo", "crates", "examples", "tests",
                str(classifier.LEAF), str(classifier.LEAF.with_name("test-run.py")), str(leaf.PRIOR)]
owner = leaf.load("cpu_owner", repo / prior.CONTROLLER, prior.CONTROLLER_SHA)
for number in owner.SIGNALS:
    signal.signal(number, owner.interrupted)
before = json.loads((root / "bound-final/source-before.json").read_text())

def current():
    prior.clean_source()
    measured = dict(commit=prior.git("rev-parse", "HEAD").decode().strip(), inputs=prior.snapshot())
    prior.need(measured == before, "signed source continuity")
    return measured

prior.save(out / "source-before.json", current())
env = dict(os.environ, CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="2")
prior.save(out / "environment.json", {key: env.get(key) for key in (
    "PATH", "CARGO_TARGET_DIR", "CARGO_INCREMENTAL", "CARGO_BUILD_JOBS", "RUSTFLAGS", "RUSTDOCFLAGS", "RUSTUP_TOOLCHAIN")})
cargo = ["prlimit", "--core=0:0", "--", "cargo", "+nightly-2026-04-03"]
phases = [
    ("rustc", ["rustc", "+nightly-2026-04-03", "--version", "--verbose"], None),
    ("kfd", cargo + ["test", "-p", "fe2o3-kfd", "--all-features", "--lib", "--", "--skip", "construction_primary", "--test-threads=2"], [(1418, 0, 0, 0, 320)]),
    ("runtime", cargo + ["test", "-p", "fe2o3-runtime", "--all-features", "--lib", "--", "--test-threads=2"], [(1828, 0, 30, 0, 0)]),
    ("doctests", cargo + ["test", "-p", "fe2o3-kfd", "-p", "fe2o3-runtime", "-p", "fe2o3-runtime-model", "--all-features", "--doc"], [(42, 0, 0, 0, 0), (53, 0, 0, 0, 0), (29, 0, 0, 0, 0)]),
    ("clippy", cargo + ["clippy", "-p", "fe2o3-kfd", "-p", "fe2o3-runtime", "--all-features", "--all-targets", "--", "-D", "warnings"], None),
    ("production", cargo + ["check", "-p", "fe2o3-kfd", "-p", "fe2o3-runtime", "--no-default-features", "--lib"], None),
    ("format", cargo + ["fmt", "--all", "--", "--check"], None),
    ("included-format", ["rustfmt", "+nightly-2026-04-03", "--edition", "2024", "--check", "--config", "skip_children=true",
        "crates/fe2o3-kfd/src/queue_completion/rollback_adapters_body.rs", "crates/fe2o3-kfd/src/queue_completion/source_rollback_body.rs"], None),
    ("diff", ["git", "diff", "--check"], None),
]
results = {}
for name, command, expected in phases:
    current()
    status, stdout, stderr = owner.run_owned(command, 600, out / name, env)
    summaries = [tuple(map(int, row)) for row in re.findall(
        r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", stdout)]
    passed = status == 0 and (expected is None or summaries == expected)
    results[name] = dict(passed=passed, status=status, test_summaries=summaries)
    prior.save(out / (name + "-result.json"), results[name])
    print(name + (": PASS" if passed else ": FAIL"), flush=True)
    current()
    prior.need(passed, "failed qualification: " + name)
prior.save(out / "source-after.json", current())
prior.save(out / "results.json", results)
