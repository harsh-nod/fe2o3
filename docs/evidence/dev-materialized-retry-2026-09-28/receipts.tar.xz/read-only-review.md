# Read-only Swarm Review

Primary integrated all edits and ran all tests. Reviewers did not edit, build,
test, request permissions, or escalate. These are review notes, not formal proof.

binding_custody_review found no blocking defect in shared initial/retry submit:
pre-callback rejection retains Unattempted, attempted failure retains NativeOwned,
and returned Retryable/Published outcomes are rooted before the outer lane close.
The bounded descriptor reducer preserves first-binding order and exact ranges;
its deliberate new restriction rejects more than the native maximum 16 DATA
descriptors. The common ownership guard still checks module/allocation retains,
stream custody and reservation before any retry attempt. Geometry work is
O(B*D+B+D), with expected-constant allocation-table lookups and fixed stack space.
Owner-roster binary searches add their own cost. Phase publication timing omits
the new custody preflight, so it is not an end-to-end performance measurement.

binding_tests_review confirmed retry fault indexing, all 32 Drop subprocess
combinations, sentinel/counter behavior and counted retries. It recommended
backing-Arc pointer and reservation/stream-map snapshots; these were added.
Both reviewers found the independent descriptor oracle compared content hashes
even though production ignores them. The oracle was corrected and positive
digest controls added. Isolated 1/8/4096 alignment controls replaced masked
multi-alias edge cases. Synthetic descriptor records qualify geometry, not native
storage. Valid multi-binding writeback retry coverage remains a test gap.

The next ordinary-lifetime gaps are unchanged: ordered-successor submission
precedes pipeline-owner installation; ordinary frontier/pipeline poll and recycle
take the owner off-index; logical completion releases retain/dirty-state custody
before installing the final record. A future indexed pipeline publication state
must update the Pending error handoff, not merely use self.active's helper.
Completion needs exact returned-receipt states plus checked logical commit.

No reviewer claims native execution, Rust/native formal refinement, protected
Worker application, matched performance, or complete HIP/HSA parity.
