#!/usr/bin/env bash
set -uo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-materialized-retry-20260928-dHCIBWPL
run() {
    bash "$raw/run.sh" "$@"
}
run source-identity git show --no-patch --format=fuller HEAD
run source-tree git rev-parse 'HEAD^{tree}'
run source-signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run focused env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib materialized_ -- --test-threads=1
focused=$?
if test "$focused" -ne 0; then
    exit "$focused"
fi
run backend env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib kfd_backend:: -- --test-threads=1
backend=$?
run runtime env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1
runtime=$?
run clippy env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo clippy -p fe2o3-runtime -p fe2o3-kfd --all-features --all-targets -- -D warnings
clippy=$?
run no-default env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo check -p fe2o3-runtime --no-default-features
no_default=$?
run fmt-check cargo fmt --all -- --check
fmt=$?
printf 'focused=%s backend=%s runtime=%s clippy=%s no-default=%s fmt=%s\n' "$focused" "$backend" "$runtime" "$clippy" "$no_default" "$fmt"
test "$backend" -eq 0 && test "$runtime" -eq 0 && test "$clippy" -eq 0 && test "$no_default" -eq 0 && test "$fmt" -eq 0
