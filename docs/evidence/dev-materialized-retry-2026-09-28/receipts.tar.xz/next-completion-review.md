# Next Ordinary Completion Packet: Read-only Design

Both reviewers inspected current code while qualification ran. This is a design
work order, not implementation, test execution, or formal evidence.

Keep published/completed native receipt variants; add explicit consuming Poll
and Recycle states plus successful physical-retirement observation. The actual
Gfx942CompletionRecycleObservationV1 is Copy packet-count metadata, NOT a
generation-bound ownership receipt. Never manufacture native batches in tests.

Select frontier or exact pipeline identity; split queue/active/pipeline borrows.
Replace native take_physical_owner/restore paths with generation/identity-checked
mutable entry access. Inside the native callback, replace the receipt immediately
before consumption; index every returned outcome before outer close. Outer
preselection failure must leave the original receipt present. Poison/quarantine
must retain entries, not remove the current owner. Frontier promotion must install
the next owner before callbacks and distinguish empty from corrupt/missing state.

Public poll_fixed_dispatch consumes its input. It returns Pending(batch),
Ready(completed), or an error WITHOUT a recoverable batch. Public recycle failure
into_parts returns error plus Option<completed>; ONLY Some permits retry.
Public resource-phase preselection preserves Some, and accepted recycling exposes
Some for SignalPinned. Internal retaining helpers returning tokens on other
errors do not broaden public retry authority. Blocking native waits return no
published batch on timeout and are unsuitable for recoverable runtime deadlines.
Queue Drop performs no ioctl/MMIO/unmap/FREE; dropping it is not verified cleanup.

Do not reuse the Prepared custody guard wholesale: completion can coexist with
successors, deferred predecessor retains and prior recycled metadata. Prevalidate
exact logical custody, descriptor/writeback projection, result capacity, distinct
missing dirty extents and checked counters, then commit without allocation or
callbacks. Install result, retire retains exactly once, and promote the next
owner/release the lease before completion profiling.

Both ordinary and ordered-successor publication already reserve dirty Vec capacity
before submit. Retain these reservations. Identical pipeline epochs produce the
same extents, so a later valid epoch can add zero distinct extents with no spare
capacity. Late guards must not demand writebacks.len() spare elements. Tests need
aliases, duplicate extents, exact capacity exhaustion and existing dirty records.
publish_to_completion currently changes on completed-receipt recycle retry;
record it only on first Ready instead.

Reusable lower tests are in fe2o3-kfd queue_completion.rs (native generic reducer,
MockBackend, Pending/Ready/recycle, currentness/reset faults), dependency_event.rs
(event and reader pins independently block recycling), and queue_live.rs (sibling
process-gating, returned versus consumed recycling, out-of-order A/B/C, real AUX
wrapper unwind). These CPU fixtures do not establish Linux execution or ordinary
native DATA/engine composition. Persistent registered-storage tests are not an
ordinary execution substitute.
