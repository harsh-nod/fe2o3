git show --format=fuller --stat HEAD 
