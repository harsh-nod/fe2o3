#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-pending-fill-20261004-pY1UvPlE
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/build-tests.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 check --offline -p fe2o3-host --lib > "$scratch/lock-check.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 \
    --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical \
    --no-run --message-format=json > "$scratch/build-tests.jsonl" 2> "$scratch/build-tests.log"
