#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-pending-fill-20261004-pY1UvPlE
readonly run="$scratch/${1:?fresh run name}"
readonly worker_build_id="$(<"$scratch/fe2o3-worker-build-id.txt")"
mkdir -m 700 "$run" "$run/tmp" "$run/captures" "$run/runtime"
trap 'printf "%s\n" "$?" > "$run/status"' EXIT
timeout --kill-after=15s 1500s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" /usr/bin/env \
    TMPDIR="$run/tmp" XDG_RUNTIME_DIR="$run/runtime" \
    FE2O3_TEST_REAL_WORKER="$scratch/fe2o3-llvm-link-worker" \
    FE2O3_TEST_REAL_WORKER_BUILD_ID="$worker_build_id" FE2O3_TEST_REAL_LLVM_BUILD_ID=7.2.4 \
    FE2O3_TEST_HSACO_WORKER_FIXTURE=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/fe2o3-worker-v3-hsaco-fixture \
    FE2O3_PENDING_FILL_CAPTURE="$run/captures" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --test worker_v3_load_envelope_vertical \
    conditional_fill_pending::genuine_fill_pending_retains_original_evidence_and_currentness \
    -- --ignored --exact --nocapture --test-threads=1 > "$run/test.log" 2>&1
test -z "$(ls -A "$run/tmp")"
