#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-pending-fill-20261004-pY1UvPlE
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-pending-fill-admission-2026-10-04"
cd "$repo"
test "$(<"$scratch/qualified-2/status")" = 0
test "$(<"$scratch/regression.status")" = 0
test -z "$(ls -A "$scratch/qualified-2/tmp")"
git diff --binary HEAD -- Cargo.lock crates/cargo-fe2o3/Cargo.toml \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_pending.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs \
    crates/fe2o3-host/src/lib.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/pending.rs \
    > "$scratch/code.patch"
cd "$scratch"
sha256sum code.patch fe2o3-llvm-link-worker qualified-2/captures/*/* \
    > evidence-files.sha256
tar --sort=name --mtime=2026-10-04T00:00:00Z --owner=0 --group=0 --numeric-owner \
    -czf "$evidence/evidence.tar.gz" \
    code.patch evidence-files.sha256 package-evidence.sh \
    check-host.sh build-native.sh build-tests.sh prepare-runtime.sh isolated-runtime.sh \
    run-native.sh regression.sh \
    build-tests.log build-tests.status build-tests.jsonl \
    configure.log build.log build.status worker-tests.log worker-ldd.txt \
    worker-source.tar.gz worker.sha256 fe2o3-worker-build-id.txt \
    development-must-use.log host.status lock-check.log \
    host-final.log host-doc-final.log vertical-regression.log v2-regression.log \
    host-clippy.log vertical-clippy.log formatting.log whitespace.log regression.status \
    qualified-1/test.log qualified-1/status \
    qualified-2/test.log qualified-2/status qualified-2/captures
sha256sum code.patch "$evidence/evidence.tar.gz"
