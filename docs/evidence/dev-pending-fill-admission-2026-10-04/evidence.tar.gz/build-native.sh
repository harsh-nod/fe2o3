#!/bin/bash
set -euo pipefail
cd /tmp/fe2o3-pending-fill-20261004-vfyhwL9q
trap 'printf "%s\n" "$?" > build.status' EXIT
tar -xzf worker-source.tar.gz
cmake -S tools/fe2o3-llvm-link-worker -B build -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DLLVM_DIR=/opt/rocm-7.2.4/lib/llvm/lib/cmake/llvm \
    -DLLD_DIR=/opt/rocm-7.2.4/lib/llvm/lib/cmake/lld \
    -DFE2O3_PINNED_LLVM_VERSION=22.0.0git \
    -DFE2O3_EXPECTED_LLVM_BUILD_ID=7.2.4 \
    -DFE2O3_LLVM_BUILD_ID_FILE=/opt/rocm-7.2.4/.info/version \
    -DBUILD_TESTING=ON > configure.log 2>&1
cmake --build build --target fe2o3-llvm-link-worker fe2o3-worker-machine-effect-tests -j2 > build.log 2>&1
ctest --test-dir build -R '^fe2o3-worker-machine-effect-tests$' --output-on-failure > worker-tests.log 2>&1
sha256sum build/fe2o3-llvm-link-worker > worker.sha256
ldd build/fe2o3-llvm-link-worker > worker-ldd.txt
