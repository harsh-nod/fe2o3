#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-pending-fill-20261004-pY1UvPlE
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/regression.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib > "$scratch/host-final.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --doc > "$scratch/host-doc-final.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --test worker_v3_load_envelope_vertical -- --skip strict_v3_ --skip cargo_supervisor_and_static_host_consumer \
    > "$scratch/vertical-regression.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --test worker_v3_load_envelope_v2 > "$scratch/v2-regression.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-host --lib --no-deps -- -D warnings \
    > "$scratch/host-clippy.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --test worker_v3_load_envelope_vertical --no-deps -- -D warnings > "$scratch/vertical-clippy.log" 2>&1
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check \
    crates/fe2o3-host/src/lib.rs crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/pending.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_pending.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs > "$scratch/formatting.log" 2>&1
git diff --check > "$scratch/whitespace.log" 2>&1
