#!/usr/bin/env bash
set -Eeuo pipefail
trap 'printf "projection failed at line %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR
[[ $(id -u) == 1000 && $(id -g) == 1000 ]]
[[ ! -e /home/harsh/.cargo/registry && ! -e /root/.cargo ]]
for path in \
  /home/harsh/.codex-tmp/fe2o3-r61-execution/crates/fe2o3-runtime/Cargo.toml \
  /run/qualification-input-v1/copied/data/rust/lib \
  /run/qualification-input-v1/copied/data/cargo/registry \
  /run/qualification-input-v1/copied/data/cargo/git; do
  [[ -r $path && ! -w $path ]]
done
/run/input-qualification --exact rustc_lib_tree::tests::qualification_copied_toolchain_preserves_runtime_pin --ignored --nocapture --test-threads=1
/run/input-qualification --exact authorized_kernel_closure::tests::reviewed_workspace_host_code_trees_match_their_complete_pins --nocapture --test-threads=1
/run/input-qualification --exact authorized_kernel_closure::tests::reviewed_workspace_host_code_requires_exact_local_or_git_revision_identity --nocapture --test-threads=1
printf 'private UID1002-to-UID1000 projection checks passed\n'
