#!/usr/bin/env bash
set -Eeuo pipefail
trap 'printf "campaign failed at line %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR
export PATH=/usr/bin:/bin LANG=C LC_ALL=C PYTHONDONTWRITEBYTECODE=1
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/dev/shm/fe2o3-application-inputs-20261004-nZBSZvj6
install -d -o 1000 -g 1000 -m 0700 "$scratch/storage/work"
setpriv --reuid=1000 --regid=1000 --clear-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all \
  /usr/bin/python3 -B "$repo/scripts/qualification_input_bundle.py" prepare-application \
  "$repo" "$scratch/genuine-env.json" "$scratch/storage/work/bundle" > "$scratch/bundle-sha256.log"
FE2O3_GENUINE_INPUT_BUNDLE="$scratch/storage/work/bundle"
FE2O3_GENUINE_INPUT_SHA256=$(<"$scratch/bundle-sha256.log")
export FE2O3_GENUINE_INPUT_BUNDLE FE2O3_GENUINE_INPUT_SHA256
[[ $FE2O3_GENUINE_INPUT_SHA256 =~ ^[0-9a-f]{64}$ ]]
chown -R 1002:1002 "$scratch/storage/work"
chmod 0700 "$scratch/storage/work"
cp "$FE2O3_GENUINE_INPUT_BUNDLE/MANIFEST.json" "$scratch/bundle-manifest.json"
printf 'bundle complete; independent copies now owned by UID1002\n'
source "$repo/scripts/qualify-application-inputs.sh"
FE2O3_GENUINE_INPUT_SOURCE_ROOT=$repo
export FE2O3_GENUINE_INPUT_SOURCE_ROOT
configure_application_projection
# bwrap opens sources before applying mounts, so this standalone probe names the
# original bundle source. The harness uses /run only in its later namespace layer.
for index in "${!FE2O3_APPLICATION_PROJECTION[@]}"; do
  if [[ ${FE2O3_APPLICATION_PROJECTION[$index]} == "$FE2O3_APPLICATION_INPUT_MOUNT/data/source" ]]; then
    FE2O3_APPLICATION_PROJECTION[$index]="$FE2O3_GENUINE_INPUT_BUNDLE/data/source"
  fi
done
bwrap --die-with-parent --ro-bind / / --proc /proc --dev /dev --tmpfs /run \
  --dir /run/qualification-input-v1 --chmod 0555 /run/qualification-input-v1 \
  --ro-bind "$FE2O3_GENUINE_INPUT_BUNDLE" "$FE2O3_APPLICATION_INPUT_MOUNT" \
  --ro-bind "$repo/target/debug/deps/cargo_fe2o3-5cf922c4de19b59e" /run/input-qualification \
  --ro-bind "$scratch/projection-check.sh" /run/input-projection-check.sh \
  "${FE2O3_APPLICATION_PROJECTION[@]}" \
  --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
  /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups \
  --bounding-set=-all --inh-caps=-all --ambient-caps=-all \
  /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C \
  FE2O3_QUALIFICATION_RUSTC="$FE2O3_APPLICATION_INPUT_MOUNT/data/rust/bin/rustc" \
  FE2O3_QUALIFICATION_RUNTIME_SHA256="$FE2O3_AUTHORITY_RUSTC_RUNTIME_SHA256_V1" \
  /bin/bash /run/input-projection-check.sh
/usr/bin/time -p /bin/bash "$repo/scripts/qualify-proof-resource-inspection.sh"
