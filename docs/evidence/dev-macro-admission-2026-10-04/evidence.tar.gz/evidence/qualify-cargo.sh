#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-macro-admission-20261004-wBsi7aVl
cd "$repo"
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE_V1 FE2O3_SIMULATION_ATTEMPT_V1
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS CARGO_TARGET_DIR
export CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1 FE2O3_HIP_SYS_DISABLE=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
node "$out/snapshot.cjs" "$repo" > "$out/sources-pinned-before.json"
run() {
    local name=$1
    shift
    printf 'RUN %s\n' "$name"
    if timeout --kill-after=15s 1800s "$@" > "$out/$name.log" 2>&1; then
        tail -n 12 "$out/$name.log"
    else
        local status=$?
        tail -n 80 "$out/$name.log"
        exit "$status"
    fi
}
run cargo-unit cargo +nightly-2026-04-03 test --offline --locked -p cargo-fe2o3 --bins -- --test-threads=1
run cargo-clippy cargo +nightly-2026-04-03 clippy --offline --locked -p cargo-fe2o3 --all-targets --no-deps -- -D warnings
run format rustfmt +nightly-2026-04-03 --check --edition 2024 crates/fe2o3-macros/src/lib.rs crates/fe2o3-macros/src/runtime_adapter_tests.rs crates/cargo-fe2o3/src/authorized_kernel_closure.rs
run whitespace git diff --check
node "$out/snapshot.cjs" "$repo" > "$out/sources-pinned-after.json"
cmp "$out/sources-pinned-before.json" "$out/sources-pinned-after.json"
printf 'PASS Cargo qualification and source stability\n'
