#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
ram=/dev/shm/fe2o3-macro-admission-20261004-XPFnpPVA
cd "$repo"
names=(renamed-typed-host-test generic-worker-v3-adapter-test typed-kernel-invalid-test renamed-device-marker-test)
for name in "${names[@]}"; do
    test -L "target/$name"
    test "$(readlink "target/$name")" = "$ram/$name"
done
for name in "${names[@]}"; do
    rm -- "target/$name"
    test ! -e "target/$name" && test ! -L "target/$name"
    printf 'Removed owned link target/%s\n' "$name"
done
test -d "$ram" && test ! -L "$ram"
rm -r -- "$ram"
test ! -e "$ram"
printf 'Removed owned RAM root %s\n' "$ram"
