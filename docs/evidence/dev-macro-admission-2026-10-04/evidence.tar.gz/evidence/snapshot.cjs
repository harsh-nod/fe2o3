const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

const repo = process.argv[2];
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const macroRoot = path.join(repo, 'crates/fe2o3-macros');
const macroFiles = [];
function walk(directory) {
  for (const name of fs.readdirSync(directory)) {
    const file = path.join(directory, name);
    const stat = fs.lstatSync(file);
    if (stat.isDirectory()) walk(file);
    else if (stat.isFile()) macroFiles.push(path.relative(macroRoot, file));
    else throw new Error(`non-regular source: ${file}`);
  }
}
walk(macroRoot);
macroFiles.sort((a, b) => Buffer.compare(Buffer.from(a), Buffer.from(b)));
const tree = crypto.createHash('sha256').update('fe2o3-canonical-source-tree-v1\0');
for (const file of macroFiles) {
  if (/[\r\n]/.test(file)) throw new Error(`invalid source path: ${file}`);
  tree.update(`${sha256(fs.readFileSync(path.join(macroRoot, file)))}  ${file}\n`);
}
const tracked = execFileSync('git', ['ls-files', '-z', '--', 'crates', 'Cargo.lock', 'Cargo.toml', 'rust-toolchain.toml'], { cwd: repo }).toString().split('\0').filter(Boolean);
const files = [...new Set([...tracked, ...macroFiles.map(file => `crates/fe2o3-macros/${file}`)])].sort();
const sources = {};
for (const file of files) sources[file] = sha256(fs.readFileSync(path.join(repo, file)));
console.log(JSON.stringify({ macroTree: tree.digest('hex'), sources }, null, 2));
