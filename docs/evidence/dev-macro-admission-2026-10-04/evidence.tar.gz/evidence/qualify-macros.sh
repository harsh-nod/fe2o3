#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-macro-admission-20261004-wBsi7aVl
ram=/dev/shm/fe2o3-macro-admission-20261004-XPFnpPVA
cd "$repo"
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE_V1 FE2O3_SIMULATION_ATTEMPT_V1
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS CARGO_TARGET_DIR
export CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1 FE2O3_HIP_SYS_DISABLE=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
for name in renamed-typed-host-test generic-worker-v3-adapter-test typed-kernel-invalid-test renamed-device-marker-test; do
    if test -L "target/$name"; then
        test "$(readlink "target/$name")" = "$ram/$name"
        test -d "$ram/$name"
    else
        test ! -e "target/$name"
        mkdir "$ram/$name"
        ln -s "$ram/$name" "target/$name"
    fi
done
git rev-parse HEAD > "$out/base-commit.txt"
cargo +nightly-2026-04-03 --version > "$out/cargo-version.txt"
rustc +nightly-2026-04-03 -Vv > "$out/rustc-version.txt"
node "$out/snapshot.cjs" "$repo" > "$out/sources-before.json"
run() {
    local name=$1
    shift
    printf 'RUN %s\n' "$name"
    if timeout --kill-after=15s 1800s "$@" > "$out/$name.log" 2>&1; then
        tail -n 8 "$out/$name.log"
    else
        local status=$?
        tail -n 80 "$out/$name.log"
        exit "$status"
    fi
}
run macro-unit cargo +nightly-2026-04-03 test --offline --locked -p fe2o3-macros --lib -- --test-threads=1
run typed-fixtures cargo +nightly-2026-04-03 test --offline --locked -p fe2o3-macros --test typed_kernel_fixtures -- --test-threads=1
run renamed-fixtures cargo +nightly-2026-04-03 test --offline --locked -p fe2o3-macros --test renamed_dependency -- --test-threads=1
run macro-clippy cargo +nightly-2026-04-03 clippy --offline --locked -p fe2o3-macros --all-targets --all-features --no-deps -- -D warnings
run host-runtime cargo +nightly-2026-04-03 test --offline --locked -p fe2o3-host --lib generated_runtime -- --test-threads=1
node "$out/snapshot.cjs" "$repo" > "$out/sources-after.json"
cmp "$out/sources-before.json" "$out/sources-after.json"
git diff --check
printf 'PASS macro qualification and source stability\n'
