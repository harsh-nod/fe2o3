# Reviewed Workspace Macro Admission

Base: d0647edfaf243216d371a26435da417f98913fbb.
Previous pin change: 3494de45f.

The primary integrated the tests and lock refresh. Independent native agents
reviewed the intervening macro changes, the new oracle, and the qualification
sequence read-only. No Qwen worker, GPU job, or remote deployment was used.

The nine intervening macro commits are:

- bd8aa3ded708ecd6e799a803bee8e9c7ccd6c91a
- d5ada879bc88a70523a1a5b6ab97f7aa218cbc11
- dd202891448daca7027cdbe74dc97ab76537eac9
- fb1e27e66cee27bb11f0b7c08f2d5994c5d168da
- 3a1861282ac5bb89492f029b6850594a0545e95a
- e43e6a98dfc625374f8badee24174e2bcb8ebd95
- 06fc26d1c64ca852eb61261e91cd023d66231df1
- 3c8afa96a2a9f0cb71da500b125054ce08153824
- 62846ad4d7e78db663d1c22f3dd252af7c658893

Production changes introduce owned runtime arguments and ordinary Context
arguments. Review found no new proc-macro dependency, filesystem/network/process
operation, or generated raw-pointer/assembly operation. The added unsafe surface
is the generated argument trait assertion. Existing bounded canonical ABI parsing
and marker-specific typed ownership remain in place.

The new independent oracle covers all four emitted items for an eight-argument
mixed fixture. It fixes the complete 104-byte ABI, access and alias classifications,
argument positions, both mapped index spaces, move-only field/constructor shape,
ordered accounting, supplied budget, consuming binding and complete unsafe impls.
It compares exact syntax, including the literal documentation attribute.
Nine post-generation AST mutations calibrate this comparison; these are not
compiled production-source mutants or authenticated mutation evidence. Four
mixed unsupported profiles require entirely empty output. The borrowed argument
struct is emitted by a different unchanged helper and is typechecked downstream.

The standalone generic fixture lock was refreshed with offline Cargo metadata.
Its diff only adds six dependency edges to existing workspace package entries;
no package, version, source, or checksum was added or changed.

This gate admits only the reviewed local macro tree. It does not newly authenticate
host/runtime implementations, install a production custodian, grant invocation
authority, prove a new theorem, or establish multi-GPU or performance parity.
