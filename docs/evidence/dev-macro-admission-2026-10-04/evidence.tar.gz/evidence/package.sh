#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-macro-admission-20261004-wBsi7aVl
destination="$repo/docs/evidence/dev-macro-admission-2026-10-04"
cd "$repo"
node "$out/snapshot.cjs" "$repo" > "$out/sources-package.json"
cmp "$out/sources-pinned-after.json" "$out/sources-package.json"
node "$out/final-audit.cjs" > "$out/final-audit-package.json"
cmp "$out/final-audit.json" "$out/final-audit-package.json"
mkdir "$out/evidence"
cp "$out"/qualify-*.sh "$out/snapshot.cjs" "$out/final-audit.cjs" \
    "$out/package.sh" "$out/review.md" "$out/cleanup.sh" "$out/cleanup.log" \
    "$out/base-commit.txt" "$out/cargo-version.txt" "$out/rustc-version.txt" \
    "$out"/sources-*.json "$out/final-audit.json" \
    "$out/macro-unit.log" "$out/typed-fixtures.log" "$out/renamed-fixtures.log" \
    "$out/macro-clippy.log" "$out/macro-clippy-development.log" \
    "$out/host-runtime.log" "$out/cargo-unit.log" "$out/cargo-clippy.log" \
    "$out/format.log" "$out/whitespace.log" "$out/evidence/"
git rev-parse HEAD > "$out/evidence/source-commit.txt"
base=$(<"$out/base-commit.txt")
git diff "$base" HEAD -- crates/cargo-fe2o3/src/authorized_kernel_closure.rs \
    crates/fe2o3-macros > "$out/evidence/source.patch"
git -c gpg.format=ssh \
    -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers \
    verify-commit HEAD > "$out/evidence/signature.log" 2>&1
cd "$out/evidence"
find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c SHA256SUMS > "$out/manifest-check.log"
mkdir -p "$destination"
tar -czf "$destination/evidence.tar.gz" -C "$out" evidence
tar -dzf "$destination/evidence.tar.gz" -C "$out"
sha256sum "$destination/evidence.tar.gz" "$out/evidence/source.patch"
printf 'PASS archive manifest and source comparison\n'
