const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const repo = '/home/harsh/.codex-tmp/fe2o3-r61-execution';
const out = __dirname;
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const read = name => JSON.parse(fs.readFileSync(path.join(out, name)));
const before = read('sources-before.json');
const after = read('sources-after.json');
const pinned = read('sources-pinned-before.json');
const final = read('sources-pinned-after.json');
assert.deepEqual(before, after);
assert.deepEqual(pinned, final);
assert.equal(before.macroTree, final.macroTree);
const pinSource = 'crates/cargo-fe2o3/src/authorized_kernel_closure.rs';
assert.deepEqual(Object.keys(before.sources), Object.keys(final.sources));
const changed = Object.keys(before.sources).filter(file => before.sources[file] !== final.sources[file]);
assert.deepEqual(changed, [pinSource]);
const source = fs.readFileSync(path.join(repo, pinSource), 'utf8');
const pin = source.match(/const TRUSTED_FE2O3_MACROS_TREE: &str\s*=\s*"([a-f0-9]{64})"/)[1];
const external = source.match(/const TRUSTED_FE2O3_EXTERNAL_MACROS_TREE: &str\s*=\s*"([a-f0-9]{64})"/)[1];
assert.equal(pin, final.macroTree);
assert.equal(external, 'a6ae6e79c48ee48389411aee2db6b438599e525009e45f5773d5e0d3ba57efcc');
const base = fs.readFileSync(path.join(out, 'base-commit.txt'), 'utf8').trim();
const original = execFileSync('git', ['show', `${base}:${pinSource}`], { cwd: repo }).toString();
assert.equal(source, original.replace('83559900a74b536f33006952ff4f0248286352d107f99acf3c5810e18252c377', pin));
const tests = {};
const binaries = {};
for (const name of ['macro-unit', 'typed-fixtures', 'renamed-fixtures', 'host-runtime', 'cargo-unit']) {
  const log = fs.readFileSync(path.join(out, `${name}.log`), 'utf8');
  tests[name] = [...log.matchAll(/^test result: (.+)$/gm)].map(match => match[1]);
  assert(tests[name].length > 0 && tests[name].every(result => result.startsWith('ok.')));
  for (const match of log.matchAll(/^\s*Running .+ \((target\/[^)]+)\)$/gm)) {
    binaries[match[1]] = sha256(fs.readFileSync(path.join(repo, match[1])));
  }
}
assert(Object.keys(binaries).length >= 5);
console.log(JSON.stringify({ base, pin, external, sourceStableDuringEachStage: true, onlyInterstageChange: changed, tests, binaries }, null, 2));
