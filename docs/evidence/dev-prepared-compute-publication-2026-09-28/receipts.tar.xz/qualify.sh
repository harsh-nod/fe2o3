#!/usr/bin/env bash
set -u
root=/home/harsh/.codex-tmp/fe2o3-prepared-publication-20260927-ox7LM82q
prefix=${1:-}
run() { local label=$1; shift; bash "$root/run.sh" "${prefix}${label}" "$@"; }
overall=0
run source-head git show -s --format=fuller HEAD || overall=1
run source-tree git rev-parse HEAD HEAD^{tree} || overall=1
run source-signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD || overall=1
run lower-persistent env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-kfd --all-features --lib persistent_ -- --nocapture || overall=1
run full-runtime-model env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime -p fe2o3-runtime-model --all-features --no-fail-fast || overall=1
run clippy env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo clippy -p fe2o3-runtime -p fe2o3-runtime-model -p fe2o3-kfd --all-features --all-targets -- -D warnings || overall=1
run no-default env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo check -p fe2o3-runtime --no-default-features || overall=1
run fmt-check cargo fmt --all --check || overall=1
run source-continuity git diff --exit-code HEAD -- crates/fe2o3-runtime crates/fe2o3-runtime-model crates/fe2o3-kfd || overall=1
exit "$overall"
