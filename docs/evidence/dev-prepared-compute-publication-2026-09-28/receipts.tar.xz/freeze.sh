#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-prepared-publication-20260927-ox7LM82q
packet=/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-prepared-compute-publication-2026-09-28
for started in "$raw"/*.started; do
    base=${started%.started}
    test -s "$base.finished"
    test -s "$base.status"
done
for label in source-head source-tree source-signature lower-persistent clippy no-default fmt-check source-continuity; do
    test "$(<"$raw/verified-source-$label.status")" = 0
done
test "$(<"$raw/verified-source-full-runtime-model.status")" = 101
tar --sort=name -cJf "$packet/receipts.tar.xz" -C "$raw" .
sha256sum "$packet/receipts.tar.xz"
