#!/usr/bin/env bash
set -u
root=/home/harsh/.codex-tmp/fe2o3-compute-import-20260927-HMjuqKWr
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
git rev-parse HEAD > "$root/source-before.txt"
git diff --exit-code HEAD -- crates Cargo.toml Cargo.lock rust-toolchain.toml .cargo > "$root/source-clean-before.log" || exit 2
run() {
    local name=$1 start rc
    shift
    start=$SECONDS
    printf '%s\t' "$name" >> "$root/commands.tsv"
    printf '%q ' "$@" >> "$root/commands.tsv"
    printf '\n' >> "$root/commands.tsv"
    "$@" > "$root/$name.log" 2>&1
    rc=$?
    printf '%s\t%s\t%s\n' "$name" "$rc" "$((SECONDS - start))" >> "$root/results.tsv"
    printf '%s: exit=%s seconds=%s\n' "$name" "$rc" "$((SECONDS - start))"
}
run signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run kfd cargo test --offline -p fe2o3-kfd --lib -- --test-threads=8
run layout cargo test --offline -p fe2o3-kfd --lib persistent_owner_and_queue_layouts -- --nocapture
run runtime cargo test --offline -p fe2o3-runtime --lib -- --test-threads=8
run runtime-all-features cargo test --offline -p fe2o3-runtime --lib --all-features -- --test-threads=8
run doctests cargo test --offline -p fe2o3-kfd -p fe2o3-runtime --doc
run clippy cargo clippy --offline -p fe2o3-kfd -p fe2o3-runtime --all-targets --all-features -- -D warnings
run minimal cargo check --offline -p fe2o3-runtime --no-default-features
run format cargo fmt --all -- --check
run whitespace git diff --check
run scalar-source-continuity git diff --exit-code 8de35fdaae044498a1ff7455f5ffbb914fa3eed7 -- crates/fe2o3-kfd/src/initialized_prefix.rs crates/fe2o3-kfd/src/initialized_prefix_body.rs crates/fe2o3-runtime-model/verus/initialized_prefix_v1.rs crates/fe2o3-runtime-model/verus/check-initialized-prefix.py
run source-continuity git diff --exit-code "$(<"$root/source-before.txt")" -- crates Cargo.toml Cargo.lock rust-toolchain.toml .cargo
run mi300x-access ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname
run issue-state gh issue view 182 --repo harsh-nod/fe2o3 --json number,state,title,updatedAt,url
git rev-parse HEAD > "$root/source-after.txt"
