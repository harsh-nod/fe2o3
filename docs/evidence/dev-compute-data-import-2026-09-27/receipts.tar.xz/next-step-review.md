# Next Conversion Boundary (Read-Only Agent Review)

Add sealed InitializedStorage payload and queue-owned consuming promotion of an
exact directional persistent allocation. No raw constructor, mutable access,
digest or Clone. Preserve foreign/clean rejection separately from opaque terminal
custody. New native currentness/retake errors cannot return usable initialized
authority.

Borrowed owner/backing admission must require attached local mapping, no detached
compute stamp, no quarantine, entirely empty ledger including settled records,
no retained frontier, exact queue/pool generation/identity/extents and
0 < logical == physical == owner byte length. Initialization metadata must be
present and cover the entire extent. Do not use matches_scope alone: absent
metadata intentionally accepts raw storage there. Do not use try_into_native as
the quiescence predicate: it accepts retained settled records.

Use execute_live_model_custody_v1 with a queue-owned root, borrowed native mapped
facts/currentness validation and successful retake before minting. Copy the rooted
control-flow pattern from sdma_promotion, not its actual transition: that helper
consumes a buffer, creates an owner and changes outstanding-buffer accounting.
Demoting/re-promoting would distort generations and lose coverage.

The current allocation/optional-SHA/bool decomposition cannot preserve origin.
Prefer one private discriminator: Uninitialized, AuthenticatedH2d(digest),
InitializedStorage, AfterDispatch. Carry it through attachments, bounded/single
conversion, retained-control replay, bind rejection, persistent_bind,
persistent_cancel, three_binding_entries_into_inputs_v1 and coexistence input
matching. Actual completed compute may become AfterDispatch; prepublication
cancellation and bind rejection must preserve Storage. Internal dispatch-data
construction must not claim prior compute for an SDMA-initialized input.

Runtime needs a distinct initialized-storage source, single/three extraction,
preallocated restore shells, exact rejection restoration and terminal custody.
Fresh storage readiness must invoke the real queue conversion after cooperative
producers settle. Neither peer success nor runtime sdma_initialized is authority.

Tests: genuine multipart coverage before conversion; gaps, raw/pool reset,
padding, wrong scope, detached/quarantined/live/settled owners; every model-loan
failure/panic boundary; origin-preserving single/three bind/cancel and runtime
restoration; external compile-fail forging/clone/reuse controls. Registered
fixtures must use memory.primary_vm(). No GPU or formal native result follows
from these CPU tests.
