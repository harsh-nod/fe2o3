# Development History

These are development observations, not frozen-source qualification logs.

- Initial whole-data implementation: 169 focused persistent/prefix tests passed.
- Direct new owner tests first failed compilation on a missing import and private
  post-dispatch constructor. The import was fixed; post-dispatch coverage stays
  within queue-owned public-path fixtures, without widening constructor access.
- Both direct owner tests then passed.
- Public-path fixture compilation caught a missing enum import and an unwrap_err
  Debug bound; test code was corrected without changing production API types.
- Public-path fixture execution then failed all three groups before restoration,
  with WrongQueueGeneration at bind_templates. The synthetic queue's VM differed
  from the registered fixture memory VM. The fixture now reads its real VM through
  a test-only accessor; production validation is unchanged.
- A read-only agent reviewed the production custody path and fixture design.
  It caught test API mismatches and the need for explicit simulated terminal
  teardown instead of resetting a poisoned control owner. No production recovery
  API was added. The agent found no remaining production blocker.
- After binding the fixture's exact VM, all five new groups passed: two direct
  owner groups and three public single/three-buffer groups. The frozen-source
  full-suite campaign follows in the recorded commands and logs.

No GPU observation, copy, compute, formal native refinement or performance result
is established by these tests. Scalar range sources are unchanged and their prior
proof campaign is not relabeled as a proof of typed-data import.
