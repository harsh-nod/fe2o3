#!/usr/bin/env bash
set -eu
root=/home/harsh/.codex-tmp/fe2o3-compute-import-20260927-HMjuqKWr
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
git diff --exit-code 8de35fdaae044498a1ff7455f5ffbb914fa3eed7 -- crates/fe2o3-kfd/src/target_debug_telemetry_v2.rs crates/fe2o3-runtime/src/authorized_execution.rs > "$root/baseline-source-continuity.log"
git status --porcelain -- crates Cargo.toml Cargo.lock rust-toolchain.toml .cargo > "$root/source-status.log"
test ! -s "$root/source-status.log"
cmp "$root/source-before.txt" "$root/source-after.txt"
sha256sum target/debug/deps/fe2o3_kfd-9280442e7aa71d90 target/debug/deps/fe2o3_runtime-84865fc0c8221886 target/debug/deps/fe2o3_runtime-e03b9552edb097b6 > "$root/test-binaries.sha256"
