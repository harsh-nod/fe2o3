"""Development diagnostics only; this does not qualify or accept a proof campaign."""
import importlib.util
import json
from pathlib import Path
import subprocess

root = Path("/home/harsh/.codex-tmp/fe2o3-r61-execution")
scratch = Path(__file__).resolve().parent
script = root / "crates/fe2o3-kernel-analysis/verus/gfx942_fill_dispatch_check.py"
spec = importlib.util.spec_from_file_location("dispatch_check", script)
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)
paths = [check.PROOF, check.BODY, check.wave.PROOF, check.wave.BODY]
original = {path: (root / path).read_bytes() for path in paths}
for name, body, target in check.mutations(original[check.BODY].decode("ascii")):
    staged = scratch / ("development-" + name)
    staged.mkdir()
    for path in paths:
        file = staged / path
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(body.encode("ascii") if path == check.BODY else original[path])
    command = ["/usr/bin/timeout", "--foreground", "--kill-after=5", "120",
               "/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus",
               "--crate-type", "lib", "--triggers-mode", "silent", "--no-cheating", "--output-json",
               "--error-format=json", "--no-report-long-running", "--num-threads", "1", "--multiple-errors", "1",
               "--verify-function", "*" + target, "--verify-root", "--no-auto-recommends-check", str(staged / check.PROOF)]
    with (staged / "stdout.json").open("x") as out, (staged / "stderr.jsonl").open("x") as err:
        result = subprocess.run(command, stdout=out, stderr=err, check=False)
    data = json.loads((staged / "stdout.json").read_text())
    rows = [json.loads(line) for line in (staged / "stderr.jsonl").read_text().splitlines()]
    failures = [(row["message"], [tuple(span[key] for key in
                 ("line_start", "column_start", "line_end", "column_end"))
                 for span in row.get("spans", []) if span.get("is_primary")])
                 for row in rows if row.get("level") == "error" and row.get("spans")]
    print(name, result.returncode, data["verification-results"], failures, flush=True)
