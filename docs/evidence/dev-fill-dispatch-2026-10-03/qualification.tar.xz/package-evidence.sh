#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-dispatch-20261003-DP8FbR
readonly evidence="$repo/docs/evidence/dev-fill-dispatch-2026-10-03"
cd "$repo"
test "$(git rev-parse HEAD)" = 9526e023380db65da143e3e0cccb140a601ee431
git diff --cached --check
git diff --cached --binary -- crates/fe2o3-kernel-analysis >"$scratch/code.patch"
test -s "$scratch/code.patch"
git diff --cached --stat -- crates/fe2o3-kernel-analysis >"$scratch/code-stat.txt"
sha256sum "$scratch/code.patch"
tar -C "$scratch" -cJf "$evidence/qualification.tar.xz" .
tar -tJf "$evidence/qualification.tar.xz" >"$scratch/archive-listing.txt"
test "$(tar -xJOf "$evidence/qualification.tar.xz" ./code.patch | sha256sum | cut -d ' ' -f 1)" = "$(sha256sum "$scratch/code.patch" | cut -d ' ' -f 1)"
sha256sum "$evidence/qualification.tar.xz"
wc -l "$scratch/archive-listing.txt"
