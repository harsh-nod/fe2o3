#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-dispatch-20261003-DP8FbR
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly verus=/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus
python3 -I -B crates/fe2o3-kernel-analysis/verus/gfx942_fill_wave_check.py --verus "$verus" --output "$scratch/qualified-wave"
python3 -I -B crates/fe2o3-kernel-analysis/verus/gfx942_fill_dispatch_check.py --verus "$verus" --output "$scratch/qualified-dispatch-final"
