#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-dispatch-20261003-DP8FbR
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-kernel-analysis --no-default-features --features authenticated-machine-effect --lib >"$scratch/cpu-lib-final.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-kernel-analysis --no-default-features --features authenticated-machine-effect --doc >"$scratch/cpu-doc.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-kernel-analysis --no-default-features --features authenticated-machine-effect --lib --no-deps -- -D warnings >"$scratch/clippy.log" 2>&1
rustfmt +nightly-2026-04-03 --edition 2024 --check crates/fe2o3-kernel-analysis/src/gfx942_fill_wave_v1.rs crates/fe2o3-kernel-analysis/src/gfx942_fill_wave_v1/dispatch.rs crates/fe2o3-kernel-analysis/src/gfx942_fill_wave_v1/dispatch_body.rs
git diff --check
