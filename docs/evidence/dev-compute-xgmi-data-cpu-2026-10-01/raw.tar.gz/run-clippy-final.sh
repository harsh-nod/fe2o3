#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-data-20261001
env -i PATH=/home/harsh/.cargo/bin:/usr/bin:/bin HOME=/home/harsh \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    timeout --signal=TERM --kill-after=30s 900s \
    cargo +nightly-2026-04-03 clippy --locked --offline \
    -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --tests --no-deps -- -D warnings \
    > "$out/combined-clippy-final.stdout" 2> "$out/combined-clippy-final.stderr"
status=$?
printf '%s\n' "$status" > "$out/combined-clippy-final.exit"
exit "$status"
