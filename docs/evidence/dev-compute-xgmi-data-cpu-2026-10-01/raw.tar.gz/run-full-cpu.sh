#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-data-20261001
env -i PATH=/home/harsh/.cargo/bin:/usr/bin:/bin HOME=/home/harsh \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 \
    timeout --signal=TERM --kill-after=30s 1800s \
    cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-kfd -p fe2o3-runtime --lib --all-features -- --test-threads=1 \
    > "$out/full-cpu.stdout" 2> "$out/full-cpu.stderr"
status=$?
printf '%s\n' "$status" > "$out/full-cpu.exit"
exit "$status"
