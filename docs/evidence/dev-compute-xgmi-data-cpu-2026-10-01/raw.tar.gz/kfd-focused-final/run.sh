#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-data-20261001/kfd-focused-final
elf=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-408178a9a9b41651
expected=e444496b0c4976d4ec35790a062466e85459d14cb70a112ddc545c5a295ce561
overall=0
for filter in compute_xgmi model_pair_loan public_; do
    packet="$out/$filter"
    mkdir "$packet" || exit 2
    sha256sum "$elf" > "$packet/elf-before.sha256" || exit 2
    read -r measured ignored < "$packet/elf-before.sha256"
    if [[ "$measured" != "$expected" ]]; then
        printf '%s\n' 'ELF identity mismatch before execution' > "$packet/identity-error"
        exit 125
    fi
    command=(env -i PATH=/home/harsh/.cargo/bin:/usr/bin:/bin HOME=/home/harsh
        LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1
        timeout --signal=TERM --kill-after=30s 300s "$elf" "$filter" --test-threads=1)
    printf '%q ' "${command[@]}" > "$packet/command.txt"
    printf '\n' >> "$packet/command.txt"
    date -u '+%Y-%m-%dT%H:%M:%S.%NZ' > "$packet/started.txt"
    "${command[@]}" > "$packet/stdout" 2> "$packet/stderr"
    status=$?
    printf '%s\n' "$status" > "$packet/exit"
    date -u '+%Y-%m-%dT%H:%M:%S.%NZ' > "$packet/finished.txt"
    sha256sum "$elf" > "$packet/elf-after.sha256" || exit 2
    read -r measured ignored < "$packet/elf-after.sha256"
    printf '%s exit=%s\n' "$filter" "$status"
    if [[ "$measured" != "$expected" ]]; then
        printf '%s\n' 'ELF identity mismatch after execution' > "$packet/identity-error"
        exit 125
    fi
    if [[ "$status" != 0 ]]; then
        overall=1
    fi
done
printf '%s\n' "$overall" > "$out/exit"
exit "$overall"
