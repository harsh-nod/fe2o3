#!/bin/bash
set -u

artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-data-20261001/runtime-direct
runtime_elf=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_runtime-6f56d726eb64a207
expected_sha256=1d9813aae38c72905bf9302e8cc1578333dba074fc24f2def70cca2fd8101b08

cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/started-utc.txt"
sha256sum "$runtime_elf" > "$artifact_dir/elf-before.sha256" || exit 125
read -r actual_sha256 _ < "$artifact_dir/elf-before.sha256"
if [[ "$actual_sha256" != "$expected_sha256" ]]; then
    printf '%s\n' 'ELF SHA256 mismatch; tests were not started.' > "$artifact_dir/stderr.log"
    printf '%s\n' 125 > "$artifact_dir/exit-code.txt"
    exit 125
fi

timeout --signal=TERM --kill-after=10s 600s env -i \
    HOME=/home/harsh \
    PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
    LANG=C.UTF-8 \
    LC_ALL=C.UTF-8 \
    RUST_TEST_THREADS=1 \
    "$runtime_elf" --test-threads=1 \
    > "$artifact_dir/stdout.log" 2> "$artifact_dir/stderr.log"
runtime_exit=$?
printf '%s\n' "$runtime_exit" > "$artifact_dir/exit-code.txt"
sha256sum "$runtime_elf" > "$artifact_dir/elf-after.sha256"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/finished-utc.txt"
exit "$runtime_exit"
