#!/usr/bin/env python3
"""Propose only source-identity constants after replaying unchanged proof closures."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = 'c7a9b585ba9174dd2a197511d7101276d65a8975'
V = Path('crates/fe2o3-runtime-model/verus')
GUARDS = ('check-retained-credit-dispatch.py', 'check-retained-pair-owned-storage.py',
          'check-retained-pair-post-catch.py')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args, input=None):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *args], cwd=REPO, input=input)


def blobs(paths):
    paths = sorted(paths)
    raw = git('cat-file', '--batch', input=''.join(f'{BASE}:{path}\n' for path in paths).encode())
    offset, result = 0, {}
    for path in paths:
        end = raw.index(b'\n', offset)
        oid, kind, size = raw[offset:end].split()
        need(kind == b'blob', f'ordinary baseline blob: {path}')
        size = int(size)
        offset = end + 1
        result[path] = raw[offset:offset + size].decode()
        offset += size
        need(raw[offset:offset + 1] == b'\n', 'batch object delimiter')
        offset += 1
    need(offset == len(raw), 'complete batch read')
    return result


def load(path):
    module = types.ModuleType(path.stem.replace('-', '_'))
    module.__file__ = str(path)
    sys.modules[module.__name__] = module
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize,
         'python3 -I -B')
    head = git('rev-parse', 'HEAD').decode().strip()
    baseline_paths = {Path(name) for name in git('ls-tree', '-r', '--name-only', '-z', BASE)
                      .decode().split('\0') if name}
    proof_files, changes, audited_sources = {}, [], {}
    previous = json.loads((OUT / 'metadata-all-report.json').read_bytes())
    previous_guards = {row['path']: row['proposed_sha256'] for row in previous['changes']}
    patch = ['*** Begin Patch\n']
    for name in GUARDS:
        relative = V / name
        path = REPO / relative
        original = path.read_text()
        need(sha(original.encode()) == previous_guards[str(relative)], 'exact preceding metadata-only guard')
        module = load(path)
        candidate = module.snapshot()
        baseline = blobs(set(candidate) & baseline_paths)
        base_guard = ast.parse(blobs([relative])[relative])
        base_hash = next(ast.literal_eval(node.value) for node in base_guard.body
                         if isinstance(node, ast.Assign)
                         and any(isinstance(target, ast.Name) and target.id == 'SOURCE_TREE_SHA'
                                 for target in node.targets))
        prior_hash = module.SOURCE_TREE_SHA
        module.SOURCE_TREE_SHA = base_hash
        if hasattr(module, 'source_paths'):
            current_source_paths = module.source_paths
            module.source_paths = lambda: set(baseline)
        module.audit(baseline)
        module.SOURCE_TREE_SHA = prior_hash
        if hasattr(module, 'source_paths'):
            module.source_paths = current_source_paths
        need(all(baseline[leaf] == candidate[leaf] for leaf in module.FILES),
             'unchanged complete executable proof closure')
        for leaf in module.FILES:
            proof_files[str(leaf)] = sha(candidate[leaf].encode())
        if hasattr(module, 'SOURCE_TREE_SHA'):
            old = module.SOURCE_TREE_SHA
            new = module.tree_hash({leaf: text for leaf, text in candidate.items() if leaf != module.PROOF})
            module.SOURCE_TREE_SHA = new
            replacements = {old: new} if old != new else {}
        else:
            replacements = {}
            for leaf, pin in module.PINS.items():
                new = sha(candidate[leaf].encode())
                if pin != new:
                    need(leaf not in module.FILES, 'never replace executable proof input identity')
                    replacements[pin] = new
                    module.PINS[leaf] = new
        module.audit(candidate)
        audited_sources.update({str(leaf): sha(text.encode()) for leaf, text in candidate.items()})
        proposed = original
        for before, after in replacements.items():
            need(original.count(before) == 1, 'unique reviewed source identity constant')
            proposed = proposed.replace(before, after)
        old_ast, new_ast = ast.parse(original), ast.parse(proposed)
        for node in ast.walk(old_ast):
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in replacements:
                node.value = replacements[node.value]
        need(ast.dump(old_ast, include_attributes=False) == ast.dump(new_ast, include_attributes=False),
             'only reviewed identity constants changed; contracts and counts untouched')
        if replacements:
            patch.append('*** Update File: ' + str(REPO / relative) + '\n')
            patch.extend(list(difflib.unified_diff(original.splitlines(True), proposed.splitlines(True), n=3))[2:])
        changes.append(dict(path=str(relative), original_sha256=sha(original.encode()),
            proposed_sha256=sha(proposed.encode()), replacements=replacements,
            files=[str(leaf) for leaf in module.FILES],
            expected_verified=getattr(module, 'EXPECTED_VERIFIED', None),
            mutant_count=getattr(module, 'MUTANT_COUNT', None)))
    patch.append('*** End Patch\n')
    need(all(sha((REPO / leaf).read_bytes()) == digest for leaf, digest in audited_sources.items()),
         'frozen source unchanged during proposal')
    need(git('rev-parse', 'HEAD').decode().strip() == head, 'HEAD unchanged during proposal')
    (OUT / 'metadata-corrected.patch').write_text(''.join(patch))
    (OUT / 'metadata-corrected-report.json').write_text(json.dumps(dict(
        baseline=BASE, head=head, proof_closure_unchanged=True, proof_files=proof_files,
        proof_counts_changed=False, solver_executed=False, formal_qualification=False,
        changes=changes, audited_source_sha256=audited_sources), indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(changed_guards=sum(bool(row['replacements']) for row in changes),
        changed_constants=sum(len(row['replacements']) for row in changes),
        unchanged_proof_files=len(proof_files), audited_source_files=len(audited_sources))))


if __name__ == '__main__':
    main()
