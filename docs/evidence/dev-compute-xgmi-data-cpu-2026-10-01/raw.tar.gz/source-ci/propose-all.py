#!/usr/bin/env python3
"""Propose only source-identity constants after replaying unchanged proof closures."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = 'c7a9b585ba9174dd2a197511d7101276d65a8975'
V = Path('crates/fe2o3-runtime-model/verus')
GUARDS = ('check-retained-credit-dispatch.py', 'check-retained-pair-owned-storage.py',
          'check-retained-pair-post-catch.py', 'check-retained-pair-cadence.py',
          'check-producer-input-fold.py', 'check-producer-input-validate.py',
          'check-producer-journal-observers.py', 'check-retained-pair-routing.py',
          'check-producer-input-composition.py', 'check-producer-journal-composition.py')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args, input=None):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *args], cwd=REPO, input=input)


def blobs(paths):
    paths = sorted(paths)
    raw = git('cat-file', '--batch', input=''.join(f'{BASE}:{path}\n' for path in paths).encode())
    offset, result = 0, {}
    for path in paths:
        end = raw.index(b'\n', offset)
        oid, kind, size = raw[offset:end].split()
        need(kind == b'blob', f'ordinary baseline blob: {path}')
        size = int(size)
        offset = end + 1
        result[path] = raw[offset:offset + size].decode()
        offset += size
        need(raw[offset:offset + 1] == b'\n', 'batch object delimiter')
        offset += 1
    need(offset == len(raw), 'complete batch read')
    return result


def load(path):
    module = types.ModuleType(path.stem.replace('-', '_'))
    module.__file__ = str(path)
    sys.modules[module.__name__] = module
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize,
         'python3 -I -B')
    head = git('rev-parse', 'HEAD').decode().strip()
    baseline_paths = {Path(name) for name in git('ls-tree', '-r', '--name-only', '-z', BASE)
                      .decode().split('\0') if name}
    proof_files, changes, audited_sources, candidate_modules, proposed_sources = {}, [], {}, {}, {}
    patch = ['*** Begin Patch\n']
    for name in GUARDS:
        relative = V / name
        path = REPO / relative
        original = path.read_text()
        need(original == blobs([relative])[relative], 'guard unchanged from accepted baseline')
        module = load(path)
        candidate = module.snapshot()
        baseline = blobs(set(candidate) & baseline_paths)
        if hasattr(module, 'source_paths'):
            current_source_paths = module.source_paths
            module.source_paths = lambda: set(baseline)
        module.audit(baseline)
        if hasattr(module, 'source_paths'):
            module.source_paths = current_source_paths
        files = module.FILES if hasattr(module, 'FILES') else module.files()
        need(all(baseline[leaf] == candidate[leaf] for leaf in files),
             'unchanged complete executable proof closure')
        for leaf in files:
            proof_files[str(leaf)] = sha(candidate[leaf].encode())
        replacements = {}
        if hasattr(module, 'SOURCE_TREE_SHA'):
            old = module.SOURCE_TREE_SHA
            if name in ('check-producer-input-fold.py', 'check-producer-input-validate.py',
                        'check-retained-pair-routing.py'):
                implementation = {leaf: text for leaf, text in candidate.items()
                                  if leaf.is_relative_to(module.SRC)
                                  or (name == 'check-producer-input-validate.py'
                                      and leaf in module.DECLARATIONS)}
            else:
                implementation = {leaf: text for leaf, text in candidate.items() if leaf != module.PROOF}
            new = module.tree_hash(implementation)
            module.SOURCE_TREE_SHA = new
            replacements = {old: new} if old != new else {}
        elif hasattr(module, 'RUNTIME_SHA'):
            old = module.RUNTIME_SHA
            new = module.tree_hash({leaf: text for leaf, text in candidate.items()
                                   if leaf.is_relative_to(module.RUNTIME)})
            module.RUNTIME_SHA = new
            replacements = {old: new} if old != new else {}
        elif hasattr(module, 'PINS'):
            for leaf, pin in module.PINS.items():
                new = sha(candidate[leaf].encode())
                if pin != new:
                    need(leaf not in files, 'never replace executable proof input identity')
                    replacements[pin] = new
                    module.PINS[leaf] = new
        for attribute in ('CHECKER_PINS', 'HELPERS'):
            if hasattr(module, attribute):
                for helper, pin in getattr(module, attribute).items():
                    new = sha(proposed_sources[helper].encode())
                    if pin != new:
                        replacements[pin] = new
                        getattr(module, attribute)[helper] = new
        if hasattr(module, 'load_checker'):
            module.load_checker = lambda name: candidate_modules[name]
        if hasattr(module, 'helper'):
            module.helper = lambda name: candidate_modules[name]
        module.audit(candidate)
        audited_sources.update({str(leaf): sha(text.encode()) for leaf, text in candidate.items()})
        proposed = original
        for before, after in replacements.items():
            need(original.count(before) == 1, 'unique reviewed source identity constant')
            proposed = proposed.replace(before, after)
        old_ast, new_ast = ast.parse(original), ast.parse(proposed)
        for node in ast.walk(old_ast):
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in replacements:
                node.value = replacements[node.value]
        need(ast.dump(old_ast, include_attributes=False) == ast.dump(new_ast, include_attributes=False),
             'only reviewed identity constants changed; contracts and counts untouched')
        candidate_modules[name] = module
        proposed_sources[name] = proposed
        if replacements:
            patch.append('*** Update File: ' + str(REPO / relative) + '\n')
            patch.extend(list(difflib.unified_diff(original.splitlines(True), proposed.splitlines(True), n=3))[2:])
        changes.append(dict(path=str(relative), original_sha256=sha(original.encode()),
            proposed_sha256=sha(proposed.encode()), replacements=replacements,
            files=[str(leaf) for leaf in files],
            expected_verified=getattr(module, 'EXPECTED_VERIFIED', None),
            mutant_count=getattr(module, 'MUTANT_COUNT', None)))
    patch.append('*** End Patch\n')
    need(all(sha((REPO / leaf).read_bytes()) == digest for leaf, digest in audited_sources.items()),
         'frozen source unchanged during proposal')
    need(git('rev-parse', 'HEAD').decode().strip() == head, 'HEAD unchanged during proposal')
    (OUT / 'metadata-all.patch').write_text(''.join(patch))
    (OUT / 'metadata-all-report.json').write_text(json.dumps(dict(
        baseline=BASE, head=head, proof_closure_unchanged=True, proof_files=proof_files,
        proof_counts_changed=False, solver_executed=False, formal_qualification=False,
        changes=changes, audited_source_sha256=audited_sources), indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(changed_guards=sum(bool(row['replacements']) for row in changes),
        changed_constants=sum(len(row['replacements']) for row in changes),
        unchanged_proof_files=len(proof_files), audited_source_files=len(audited_sources))))


if __name__ == '__main__':
    main()
