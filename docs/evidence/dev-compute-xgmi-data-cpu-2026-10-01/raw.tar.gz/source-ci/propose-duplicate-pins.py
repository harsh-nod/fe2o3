#!/usr/bin/env python3
"""Audit duplicate source identities without changing any control logic."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types
import unittest

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = 'c7a9b585ba9174dd2a197511d7101276d65a8975'
V = Path('crates/fe2o3-runtime-model/verus')
assert sys.flags.isolated and sys.flags.dont_write_bytecode


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


reports = [json.loads((OUT / name).read_bytes()) for name in
           ('metadata-all-report.json', 'metadata-corrected-report.json')]
replacements, proof_files, guard_pins = {}, {}, {}
for report in reports:
    assert report['proof_closure_unchanged'] and not report['proof_counts_changed']
    proof_files.update(report['proof_files'])
    for row in report['changes']:
        replacements.update(row['replacements'])
        replacements[row['original_sha256']] = row['proposed_sha256']
        guard_pins[row['path']] = row['proposed_sha256']
assert all(sha((ROOT / path).read_bytes()) == digest for path, digest in proof_files.items())
assert all(sha((ROOT / path).read_bytes()) == digest for path, digest in guard_pins.items())
patch, changes = ['*** Begin Patch\n'], []
for name in ('test-producer-input-composition.py', 'producer-journal-composition-mutations-v1.py'):
    relative = V / name
    original = (ROOT / relative).read_text()
    assert original.encode() == subprocess.check_output(['git', 'show', f'{BASE}:{relative}'], cwd=ROOT)
    used = {old: new for old, new in replacements.items() if old in original}
    assert len(used) == (5 if name.startswith('test-') else 1)
    proposed = original
    for old, new in used.items():
        assert original.count(old) == 1
        proposed = proposed.replace(old, new)
    before = ast.parse(original)
    for node in ast.walk(before):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in used:
            node.value = used[node.value]
    assert ast.dump(before, include_attributes=False) == ast.dump(ast.parse(proposed), include_attributes=False)
    module = types.ModuleType('proposed_' + name.replace('-', '_').replace('.', '_'))
    module.__file__ = str(ROOT / relative)
    sys.modules[module.__name__] = module
    exec(compile(proposed, module.__file__, 'exec'), module.__dict__)
    if name.startswith('test-'):
        result = unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(module.SourceControls))
        assert result.wasSuccessful()
    else:
        rows, _ = module.checked()
        assert len(rows) == 89
    patch.append('*** Update File: ' + str(ROOT / relative) + '\n')
    patch.extend(list(difflib.unified_diff(original.splitlines(True), proposed.splitlines(True), n=3))[2:])
    changes.append(dict(path=str(relative), original_sha256=sha(original.encode()),
                        proposed_sha256=sha(proposed.encode()), replacements=used))
patch.append('*** End Patch\n')
(OUT / 'metadata-duplicate-pins.patch').write_text(''.join(patch))
(OUT / 'metadata-duplicate-pins-report.json').write_text(json.dumps(dict(changes=changes,
    proof_closure_unchanged=True, unchanged_proof_files=len(proof_files),
    ast_identical_except_hash_constants=True, counts_and_contracts_unchanged=True,
    test_preflight_passed=True, mutation_roster_count=89, solver_executed=False,
    formal_qualification=False), indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(changed_files=len(changes), changed_constants=sum(len(row['replacements']) for row in changes),
                     unchanged_proof_files=len(proof_files), preflight_passed=True)))
