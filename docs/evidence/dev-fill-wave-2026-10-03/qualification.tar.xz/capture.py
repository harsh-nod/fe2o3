"""Capture bounded CPU commands and source identities for closed fill-wave qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
HERE = Path(__file__).resolve().parent
ENV = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin',
           LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='4', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true',
           CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', RUST_TEST_THREADS='1',
           FE2O3_HIP_SYS_DISABLE='1')


def snapshot():
    paths = subprocess.check_output([
        'git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
        'crates', 'scripts', '.github', 'tests/support', 'benchmarks/runtime_gfx942',
        'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'], cwd=ROOT, env=ENV)
    return {os.fsdecode(path): hashlib.sha256((ROOT / os.fsdecode(path)).read_bytes()).hexdigest()
            for path in sorted(set(paths.split(b'\0'))) if path}


def main():
    label, seconds, *command = sys.argv[1:]
    assert label and '/' not in label and label not in ('.', '..') and command
    out = HERE / label
    out.mkdir(mode=0o700)
    before = snapshot()
    row = dict(command=['timeout', '--signal=TERM', '--kill-after=30s', seconds, *command],
               cwd=str(ROOT), environment=ENV,
               base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
               controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               started=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (out / 'source-before.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
    (out / 'command.json').write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    with (out / 'stdout').open('wb') as stdout, (out / 'stderr').open('wb') as stderr:
        result = subprocess.run(row['command'], cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr)
    after = snapshot()
    row.update(exit=result.returncode, source_unchanged=before == after,
               finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for name in ('stdout', 'stderr'):
        row[name + '_sha256'] = hashlib.sha256((out / name).read_bytes()).hexdigest()
    if '--message-format=json' in command and result.returncode == 0:
        artifacts = {}
        for line in (out / 'stdout').read_text().splitlines():
            artifact = json.loads(line)
            path = artifact.get('executable') if artifact.get('reason') == 'compiler-artifact' else None
            if path:
                artifacts[path] = dict(sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                                       bytes=Path(path).stat().st_size, target=artifact['target']['name'])
        row['executables'] = artifacts
    (out / 'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2) + '\n')
    (out / 'receipt.json').write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
    print(json.dumps(dict(label=label, exit=result.returncode, source_unchanged=before == after)), flush=True)
    return result.returncode if before == after else 125


if __name__ == '__main__':
    sys.exit(main())
