"""Replay the final CPU/proof qualification from retained structured receipts."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import capture

ROOT = capture.ROOT
BASE = '44c732318117e5bfb471009a973035e9e59d198c'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def counts(label):
    rows = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',
                      (HERE / label / 'stdout').read_text())
    assert rows
    return [sum(int(row[index]) for row in rows) for index in range(2)]


source = capture.snapshot()
labels = ('cpu-tests', 'clippy-lib', 'default-tests', 'proof-campaign', 'old-proof-controls',
          'format', 'whitespace', 'consumers', 'no-default', 'artifacts', 'roster')
receipts = {}
for label in (*labels, 'clippy'):
    folder = HERE / label
    row = read(folder / 'receipt.json')
    assert row['exit'] == (101 if label == 'clippy' else 0), label
    assert row['source_unchanged'] and row['base'] == BASE and row['environment'] == capture.ENV
    assert row['controller_sha256'] == sha(HERE / 'capture.py')
    assert read(folder / 'source-before.json') == source == read(folder / 'source-after.json'), label
    assert all(row[name + '_sha256'] == sha(folder / name) for name in ('stdout', 'stderr'))
    receipts[label] = row
assert counts('default-tests') == [613, 3]
assert counts('cpu-tests') == [57, 2]
assert counts('no-default') == [8, 0]
roster = Counter(re.findall(r'^(.+): test$', (HERE / 'roster/stdout').read_text(), re.M))
executed = Counter(name.removesuffix(' - compile fail') for name in re.findall(
    r'^test (.+) \.\.\. (?:ok|ignored[^\n]*)$', (HERE / 'default-tests/stdout').read_text(), re.M))
assert roster == executed and sum(roster.values()) == 616
assert 'Ran 17 tests' in (HERE / 'old-proof-controls/stderr').read_text()
for path, identity in receipts['artifacts']['executables'].items():
    assert sha(Path(path)) == identity['sha256'] and Path(path).stat().st_size == identity['bytes']

proof = read(HERE / 'proof/result.json')
assert proof['accepted'] and proof['source_unchanged'] and len(proof['stages']) == 21
assert (proof['verified_obligations'], proof['logical_mutants'], proof['control_tests']) == (30, 16, 14)
proof_before = read(HERE / 'proof/source-before.json')
assert proof_before == read(HERE / 'proof/source-after.json')
for path, digest in proof_before.items():
    assert sha(ROOT / path) == digest == sha(HERE / 'proof/inputs' / path)
for stage in proof['stages']:
    assert stage['accepted']
    record = read(HERE / 'proof' / stage['name'] / 'record.json')
    assert record['group_absent'] is True

# The strict test-Clippy failures are in untouched pre-existing tests/modules.
for path in (
    'crates/fe2o3-kernel-analysis/src/gfx942_integer_semantics_v1/mov_b32/tests.rs',
    'crates/fe2o3-kernel-analysis/src/gfx942_integer_semantics_v1/tests.rs',
    'crates/fe2o3-kernel-analysis/src/gfx942_machine_dataflow.rs',
    'crates/fe2o3-kernel-analysis/tests/pliron_barrier.rs',
    'crates/fe2o3-kernel-analysis/tests/pliron_atomic_legality.rs',
):
    assert (ROOT / path).read_bytes() == subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
failed_clippy = (HERE / 'clippy/stderr').read_text()
assert 'duplicate_mod' in failed_clippy and 'obfuscated_if_else' in failed_clippy
assert 'unresolved imports' in failed_clippy and 'gfx942_fill_wave_v1' not in failed_clippy

patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--', 'Cargo.lock',
                                 'crates/fe2o3-kernel-analysis'], cwd=ROOT)
assert b'gfx942_fill_wave_v1' in patch
(HERE / 'candidate-source.patch').write_bytes(patch)
report = dict(base=BASE, source_files=len(source), accepted_cpu_receipts=len(labels),
              default_tests=[613, 3], authenticated_lib_tests=[57, 2], no_default_lib_tests=[8, 0],
              roster=sum(roster.values()), executable_identities=len(receipts['artifacts']['executables']),
              proof_stages=21, verified_obligations=30, logical_mutants=16, control_tests=14,
              prior_proof_controls=17, code_bit_mutations=544, resource_bit_mutations=96,
              wave_cases=175, new_rust_tests=8, native_gpu_runs=0,
              strict_library_clippy=True, strict_test_clippy=False,
              limitation='Test Clippy hits existing fixture lints and unguarded default-feature integration tests; retained failure is not a pass.',
              grants_launch_authority=False, establishes_compiler_or_isa_refinement=False)
(HERE / 'audit-report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
