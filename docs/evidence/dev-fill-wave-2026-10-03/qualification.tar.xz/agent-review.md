# Read-only Swarm Review

Primary agent owns implementation, integration, solver runs and CPU qualification.
No reviewer edited source, invoked a solver/build, or used a GPU.

- xgmi_integration_review checked all14 instructions against primary CDNA3 ISA
  semantics: capture scalar-load base before overwriting it; inactive VCC bits
  are zero; ordinary inactive VGPR lanes are preserved; save old EXEC before
  narrowing; snapshot aliased address operands; END drain is not host visibility.
  Reviewed implementation found no material blocker. Requested explicit wave-vs-
  grid scope, relative-PC wording, resource/extent negatives and high VGPR-word
  assertions. Those clarifications/tests were added.
- xgmi_source_ci reviewed whole-wave/shared-body contracts. Found no mathematical
  mismatch. Identified two campaign weaknesses: unpinned shared body could accept
  a production-only macro arm, and diagnostics were not tied to exact per-mutant
  obligations. Both were fixed, with14 controls. Final read-only review reported
  no remaining concrete blocker in the scoped model.
- multigpu_host_admission identified the next real integration path: borrow the
  retained ProductionSemanticKirOwnerV1, validate every source/neutral-KIR effect,
  independently validate optimized target KIR, and reuse version-aware ownership.
  Real fill is KIRV9; singleton ValidatedCompilerProofInputsV4 currently retains
  V8. No retagging or protected-provider bypass is acceptable.

Discovery campaigns1/2 rejected qualification before completion because of
diagnostic handling, not because an intended bad model was proved. Discovery3
passed the earlier classifier, and all16 real diagnostics replayed successfully
through the subsequently tightened classifier. Only the fresh final `proof/`
campaign is the qualification record for the final checker.
