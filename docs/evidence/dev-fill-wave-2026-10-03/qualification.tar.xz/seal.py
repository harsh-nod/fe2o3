"""Create a compact deterministic archive of this owned qualification directory."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
DEST = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-fill-wave-2026-10-03')
paths = sorted(path for path in HERE.rglob('*') if path.is_file() and path.name != 'MANIFEST.json')
assert all(not path.is_symlink() for path in paths)
manifest = {str(path.relative_to(HERE)): dict(bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in paths}
(HERE / 'MANIFEST.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
archive = DEST / 'qualification.tar.xz'
assert not archive.exists()
with tarfile.open(archive, 'w:xz', preset=1) as output:
    for path in sorted([*paths, HERE / 'MANIFEST.json']):
        data = path.read_bytes()
        item = tarfile.TarInfo(str(path.relative_to(HERE)))
        item.size = len(data)
        item.mode = 0o644
        output.addfile(item, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as source:
    for name, row in manifest.items():
        data = source.extractfile(name).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps(dict(files=len(manifest), bytes=archive.stat().st_size,
                     sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
