#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-composed-startup-20261004-9klHob4J
destination="$repo/docs/evidence/dev-composed-application-startup-2026-10-04"
mkdir -p "$destination"
cd "$out"
files=(prepare.sh build-launcher.sh qualify.sh run-root.sh audit.sh collect-binaries.sh package-evidence.sh
  allowed-signers source-audit.log source.patch committed-source.patch source-before.sha256 source-after.sha256
  qualified-tests.jsonl qualified-build.log coordinator-build.jsonl coordinator-build.log cargo-build.jsonl
  static-build.log static-issuer.log static-anchor-helper.log static-anchor.log launcher-build.log launcher-final.log
  root-final.log clippy.log clippy-fixtures.log docs.log fmt.log qualification-driver.log
  test-binaries.sha256 selected-binaries.sha256)
sha256sum "${files[@]}" > MANIFEST.sha256
tar -czf "$destination/evidence.tar.gz" MANIFEST.sha256 "${files[@]}"
sha256sum "$destination/evidence.tar.gz"
