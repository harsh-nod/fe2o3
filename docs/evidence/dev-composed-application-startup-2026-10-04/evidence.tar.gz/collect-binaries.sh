#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-composed-startup-20261004-9klHob4J
python3 -I -c '
import json,sys
paths=set()
for path in sys.argv[1:]:
    with open(path) as stream:
        for line in stream:
            try: row=json.loads(line)
            except json.JSONDecodeError: continue
            if isinstance(row,dict) and row.get("reason")=="compiler-artifact" and row.get("profile",{}).get("test") and row.get("executable"):
                paths.add(row["executable"])
print("\n".join(sorted(paths)))
' "$out/qualified-tests.jsonl" "$out/coordinator-build.jsonl" "$out/cargo-build.jsonl" |
  xargs -d '\n' sha256sum > "$out/test-binaries.sha256"
static="$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release"
sha256sum "$out/launcher/fe2o3-static-preexec-launcher" \
  "$static/fe2o3-compiler-execution-issuer" \
  "$static/fe2o3-external-anchor-provisioning-helper" "$static/fe2o3-external-anchor-service" \
  "$out/static-application/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-worker-v3-host-consumer-app-fixture" \
  "$out/static-application/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-runner-app-fixture" \
  "$out/static-application/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-runner-chain-fixture" \
  "$repo/target/debug/cargo-fe2o3" "$repo/target/debug/fe2o3-worker-v3-hsaco-fixture" > "$out/selected-binaries.sha256"
