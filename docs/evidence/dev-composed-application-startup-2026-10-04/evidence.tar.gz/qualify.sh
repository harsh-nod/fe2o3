#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-composed-startup-20261004-9klHob4J
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export RUSTUP_TOOLCHAIN=nightly-2026-04-03
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
export FE2O3_V3_STATIC_FIXTURE_TARGET_DIR="$out/static-application"
packages=(-p fe2o3-compiler-execution-supervisor -p fe2o3-compiler-execution-coordinator -p fe2o3-broker-authority-service -p fe2o3-compiler-execution-client -p cargo-fe2o3)
snapshot() {
  git ls-files --cached --others --exclude-standard -z -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**' |
    LC_ALL=C sort -z | xargs -0 sha256sum
}
snapshot > "$out/source-before.sha256"
cargo test --offline --locked "${packages[@]}" --lib --bins --test client --test child_channel \
  --test inherited_child --test static_image --message-format=json > "$out/qualified-tests.jsonl" 2> "$out/qualified-build.log"
cargo test --offline --locked -p fe2o3-compiler-execution-coordinator --lib --no-run --message-format=json > "$out/coordinator-build.jsonl" 2> "$out/coordinator-build.log"
cargo test --offline --locked -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
  --test worker_v3_load_envelope_vertical --message-format=json strict_v3_ -- --test-threads=1 \
  > "$out/cargo-build.jsonl" 2> "$out/static-build.log"
bash "$out/run-root.sh" > "$out/root-final.log" 2>&1
ctest --test-dir "$out/launcher" --output-on-failure > "$out/launcher-final.log" 2>&1
cargo clippy --offline --locked --no-deps "${packages[@]}" --all-targets -- -D warnings > "$out/clippy.log" 2>&1
cargo clippy --offline --locked --no-deps -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
  --all-targets -- -D warnings > "$out/clippy-fixtures.log" 2>&1
cargo test --offline --locked "${packages[@]}" --doc > "$out/docs.log" 2>&1
rustfmt --edition 2024 --config skip_children=true --check \
  crates/fe2o3-compiler-execution-supervisor/src/process.rs \
  crates/fe2o3-compiler-execution-supervisor/src/tests/clone_compat.rs \
  crates/fe2o3-compiler-execution-coordinator/src/lib.rs \
  crates/fe2o3-compiler-execution-coordinator/src/composed_startup.rs \
  crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs > "$out/fmt.log" 2>&1
bash -n scripts/qualify-composed-application-startup.sh
snapshot > "$out/source-after.sha256"
cmp "$out/source-before.sha256" "$out/source-after.sha256"
sha256sum --quiet --check "$out/source-before.sha256"
git diff --check
git diff --cached --check
printf 'frozen composed qualification complete\n'
