#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-composed-startup-20261004-9klHob4J
cmake -S "$repo/tools/fe2o3-static-preexec-launcher" -B "$out/launcher" -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/usr/bin/cc
cmake --build "$out/launcher" --parallel 4
ctest --test-dir "$out/launcher" --output-on-failure
