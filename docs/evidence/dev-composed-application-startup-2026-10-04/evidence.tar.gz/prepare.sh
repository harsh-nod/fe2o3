#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-composed-startup-20261004-9klHob4J
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export RUSTUP_TOOLCHAIN=nightly-2026-04-03
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo test --offline --locked -p fe2o3-compiler-execution-coordinator --lib --no-run --message-format=json > "$out/coordinator-build.jsonl" 2> "$out/coordinator-build.log"
cargo test --offline --locked -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical --no-run --message-format=json > "$out/cargo-build.jsonl" 2> "$out/cargo-build.log"
FE2O3_V3_STATIC_FIXTURE_TARGET_DIR="$out/static-application" cargo test --offline --locked -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical cargo_supervisor_and_static_host_consumer_complete_strict_v3_handoff -- --exact --test-threads=1 > "$out/static-application.log" 2>&1
FE2O3_STATIC_ISSUER_TARGET_DIR="$repo/target/qualification-static-deployment/cargo" bash scripts/build-static-compiler-execution-issuer.sh > "$out/static-issuer.log" 2>&1
FE2O3_STATIC_ANCHOR_HELPER_TARGET_DIR="$repo/target/qualification-static-deployment/cargo" bash scripts/build-static-external-anchor-provisioning-helper.sh > "$out/static-anchor-helper.log" 2>&1
FE2O3_STATIC_ANCHOR_TARGET_DIR="$repo/target/qualification-static-deployment/cargo" bash scripts/build-static-external-anchor-service.sh > "$out/static-anchor.log" 2>&1
bash "$out/build-launcher.sh" > "$out/launcher-build.log" 2>&1
printf 'composed startup artifacts ready\n'
