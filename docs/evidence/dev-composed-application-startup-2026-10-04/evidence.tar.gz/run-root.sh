#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-composed-startup-20261004-9klHob4J
if [[ $(id -u) != 0 ]]; then
  exec timeout --kill-after=5s 240s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash "$out/run-root.sh"
fi
test_binary() {
  /usr/bin/python3 -I -c '
import json,sys
rows=[]
for line in sys.stdin:
    try: rows.append(json.loads(line))
    except json.JSONDecodeError: pass
matches=[row["executable"] for row in rows if isinstance(row,dict) and row.get("reason")=="compiler-artifact" and row.get("profile",{}).get("test") and row.get("target",{}).get("name")==sys.argv[1]]
assert len(matches)==1
print(matches[0])
' "$1" < "$2"
}
coordinator=$(test_binary fe2o3_compiler_execution_coordinator "$out/coordinator-build.jsonl")
cargo_test=$(test_binary worker_v3_load_envelope_vertical "$out/cargo-build.jsonl")
static="$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release"
test -x "$coordinator"
test -x "$cargo_test"
/usr/bin/env -i PATH=/usr/bin:/bin \
  FE2O3_COMPOSED_COORDINATOR_TEST="$coordinator" \
  FE2O3_COMPOSED_RUST_LIBRARY_DIR=/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib \
  FE2O3_STATIC_PREEXEC_LAUNCHER="$out/launcher/fe2o3-static-preexec-launcher" \
  FE2O3_STATIC_COMPILER_EXECUTION_ISSUER="$static/fe2o3-compiler-execution-issuer" \
  FE2O3_ROOT_ANCHOR_HELPER="$static/fe2o3-external-anchor-provisioning-helper" \
  FE2O3_ROOT_ANCHOR_DAEMON="$static/fe2o3-external-anchor-service" \
  FE2O3_COMPOSED_CARGO_TEST="$cargo_test" \
  FE2O3_COMPOSED_STATIC_CONSUMER="$out/static-application/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-worker-v3-host-consumer-app-fixture" \
  FE2O3_TEST_HSACO_WORKER_FIXTURE="$repo/target/debug/fe2o3-worker-v3-hsaco-fixture" \
  /bin/bash "$repo/scripts/qualify-composed-application-startup.sh"
printf 'composed root namespace exited successfully\n'
