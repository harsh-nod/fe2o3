#!/usr/bin/env bash
set -euo pipefail
printf 'PID_NAMESPACE %s\n' "$(readlink /proc/self/ns/pid)"
id
exec "$@"
