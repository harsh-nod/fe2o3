#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-custodian-handoff-20261004-fjZRUTDU
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
git diff --check
git diff --binary cc6ab8311e445085f6fcc11b777570efd119d897 > "$scratch/source.patch"
git diff --name-only -z cc6ab8311e445085f6fcc11b777570efd119d897 | xargs -0 sha256sum > "$scratch/source.sha256"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service -p fe2o3-runtime-protocol --lib --no-run --message-format=json-render-diagnostics > "$scratch/build.jsonl" 2> "$scratch/build.log"
: > "$scratch/test-binaries.sha256"
for crate in fe2o3_broker_authority_service fe2o3_runtime_protocol; do
  binary=$(jq -r --arg crate "$crate" 'select(.reason == "compiler-artifact" and .target.name == $crate and .profile.test == true) | .executable // empty' "$scratch/build.jsonl")
  test -x "$binary"
  sha256sum "$binary" >> "$scratch/test-binaries.sha256"
  "$binary" --test-threads=1 > "$scratch/$crate.log" 2>&1
  tail -n 3 "$scratch/$crate.log"
done
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service -p fe2o3-runtime-protocol --doc > "$scratch/doc.log" 2>&1
tail -n 3 "$scratch/doc.log"
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-broker-authority-service -p fe2o3-runtime-protocol --all-targets -- -D warnings > "$scratch/clippy.log" 2>&1
sha256sum --check "$scratch/source.sha256"
