#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
env -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u FE2O3_CRATE_BINDING_ID_V1 -u FE2O3_SIMULATION_MODE -u FE2O3_SIMULATION_ATTEMPT CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1 LD_LIBRARY_PATH=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib cargo +nightly-2026-04-03 test --locked --offline \
  -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-coordinator --lib \
  > /home/harsh/.codex-tmp/fe2o3-custodian-handoff-20261004-fjZRUTDU/downstream.log 2>&1
rg 'test result:' /home/harsh/.codex-tmp/fe2o3-custodian-handoff-20261004-fjZRUTDU/downstream.log
