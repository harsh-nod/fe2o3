#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-custodian-handoff-20261004-fjZRUTDU
binary=$(jq -r 'select(.reason == "compiler-artifact" and .target.name == "fe2o3_broker_authority_service" and .profile.test == true) | .executable // empty' "$scratch/build.jsonl")
test -x "$binary"
for test in linux::application_observation::tests::root_application_observation_campaign \
  linux::observer_channel::application::tests::root_application_session_campaign \
  linux::observer_channel::application::tests::root_custodian_handoff_campaign \
  linux::observer_channel::registry::tests::root_application_registry_transitions \
  linux::observer_channel::registry::tests::root_application_registry_transport; do
  timeout --kill-after=5s 180s /mnt/c/Windows/System32/wsl.exe --user root --exec \
    /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
    --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp --cap-drop ALL \
    --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
    --cap-add CAP_CHOWN --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
    /usr/bin/env LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib" \
    /bin/bash "$scratch/namespace-run.sh" "$binary" --exact "$test" --ignored --nocapture --test-threads=1 \
    > "$scratch/${test##*::}.log" 2>&1
  tail -n 4 "$scratch/${test##*::}.log"
  namespace=$(sed -n 's/^PID_NAMESPACE //p' "$scratch/${test##*::}.log")
  test -n "$namespace"
  /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash "$scratch/check-namespace.sh" "$namespace" \
    > "$scratch/${test##*::}-cleanup.log" 2>&1
done
