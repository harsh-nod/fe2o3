#!/usr/bin/env bash
set -euo pipefail
expected=$1
for entry in /proc/[0-9]*/ns/pid; do
  if actual=$(readlink "$entry" 2>/dev/null) && test "$actual" = "$expected"; then
    printf 'Namespace still occupied: %s\n' "$entry" >&2
    exit 1
  fi
done
printf 'Namespace empty: %s\n' "$expected"
