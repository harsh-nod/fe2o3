#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-custodian-handoff-20261004-fjZRUTDU
cd "$repo"
test "$(git rev-parse HEAD)" = aafe2598d986f831550f32da4b51cb131b78923c
sha256sum --check "$scratch/source.sha256" > "$scratch/source-check.log"
sha256sum --check "$scratch/test-binaries.sha256" > "$scratch/binary-check.log"
git diff --binary cc6ab8311e445085f6fcc11b777570efd119d897 HEAD | sha256sum > "$scratch/committed-patch.sha256"
test "$(cut -d' ' -f1 "$scratch/committed-patch.sha256")" = 10e29d24dc224e86e680913d58089a68ea10d48a23aeaa8c8f020e5eac83971c
git diff-tree --no-commit-id --name-only -r HEAD -- '*.rs' | while IFS= read -r file; do
  rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check "$file"
done > "$scratch/fmt.log" 2>&1
rustc +nightly-2026-04-03 -Vv > "$scratch/rustc.txt"
cc --version > "$scratch/cc.txt"
cd "$scratch"
rg --files -0 -g '!SHA256SUMS' | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum --check SHA256SUMS
tar --sort=name --mtime='UTC 2026-10-04' --owner=0 --group=0 --numeric-owner \
  -czf "$repo/docs/evidence/dev-custodian-registered-handoff-2026-10-04/evidence.tar.gz" .
