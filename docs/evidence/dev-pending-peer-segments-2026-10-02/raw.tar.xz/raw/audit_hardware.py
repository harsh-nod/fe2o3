"""Offline replay of both ELF identities, all native receipts and owned cleanup."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

RAW = Path(__file__).resolve().parent
HARDWARE = RAW / 'hardware-01'
BASE = '131569ccac7958d5a45ae6b80902edc31b25b4e7'
REFERENCE_SHA = '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea'
CAMPAIGN_SHA = '2658719047c1ff1b7c06b2624e1c74bc576b1ea9ee2ec1cc0ac324de832b92ad'
ORACLE_SHA = '8dda25ad58578030b3e696280c8343f7d4506410a72190ed51dbfa95f3a5d770'


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2 and sys.argv[1].isdigit()
    generation = sys.argv[1]
    assert sha(HARDWARE / 'reference/audit.py') == REFERENCE_SHA
    assert sha(HARDWARE / 'campaign.py') == CAMPAIGN_SHA
    assert sha(RAW / 'native_oracle.py') == ORACLE_SHA
    audit = load('reference_auditor', HARDWARE / 'reference/audit.py')
    audit.BASE, audit.HARDWARE = BASE, HARDWARE
    campaign = load('candidate_campaign', HARDWARE / 'campaign.py')
    assert sha(HARDWARE / 'reference/campaign.py') == campaign.HELPER_SHA
    assert sha(HARDWARE / 'capture.py') == campaign.TRANSPORT_SHA
    helper = load('reference_campaign', HARDWARE / 'reference/campaign.py')
    helper.ROOT, helper.BASE = HARDWARE, BASE
    oracle = load('candidate_oracle', RAW / 'native_oracle.py')
    source = audit.current_source()
    binaries, builds = {}, {}
    for kind, target in campaign.TARGETS.items():
        audit.BUILD = RAW / ('build-' + kind + '-final-' + generation)
        audit.TARGET = target
        builds[kind], binaries[kind] = audit.build_identity(source)
        assert binaries[kind] == campaign.build_identity(helper, kind, generation)
    outer_folder = RAW / ('hardware-final-' + generation)
    outer = audit.local_receipt(outer_folder, '3600s',
        ['python3', '-I', '-B', str(HARDWARE / 'campaign.py'), generation], source)
    assert all(audit.instant(build['finished']) <= audit.instant(outer['started']) for build in builds.values())
    native = audit.read(HARDWARE / 'campaign.json')
    assert native['accepted'] is True and native['errors'] == []
    assert native['expected_cases'] == len(native['completed']) == len(campaign.CASES) == 14
    assert native['generation'] == generation and native['owned_cleanup_complete'] is True
    assert native['exclusive_reservation'] is native['performance_acceptance'] is native['formal_refinement'] is False
    assert native['native_process_timeout_seconds'] == 300 and native['transport_timeout_seconds'] == 360
    assert native['controller_sha256'] == sha(HARDWARE / 'campaign.py')
    assert native['transport_sha256'] == campaign.TRANSPORT_SHA
    assert native['helper_sha256'] == campaign.HELPER_SHA
    assert native['oracle_sha256'] == sha(RAW / 'native_oracle.py')
    assert native['selected_cards'] == audit.CARDS and native['selected_unique_ids'] == audit.IDS
    assert native['selected_bdfs'] == audit.BDFS
    directory = native['owned_directory']
    assert re.fullmatch(re.escape(campaign.PREFIX) + '[A-Za-z0-9]{6}', directory)
    for kind, binary in binaries.items():
        binary['remote'] = directory + '/' + kind + '-witness'
    assert native['binaries'] == binaries
    lines = (outer_folder / 'stdout').read_text().splitlines()
    assert len(lines) == 15 and lines[:-1] == [name + ' PASS' for name, _, _ in campaign.CASES]
    assert audit.decode_json(lines[-1]) == native
    receipts = audit.NativeReceipts(audit.instant(outer['started']), audit.instant(outer['finished']))
    baseline = audit.decode_json(receipts.remote('initial-availability', audit.AVAILABILITY))
    baseline_sources = receipts.admission('baseline', baseline)
    assert receipts.remote('create-scratch', ['/usr/bin/mktemp', '-d', campaign.PREFIX + 'XXXXXX']).strip() == directory
    receipts.fresh(['initial-availability', *baseline_sources], audit.instant(receipts.events['create-scratch']['started']))
    for kind, binary in binaries.items():
        receipts.event('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
            '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
        assert receipts.remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    for (name, kind, args), accepted in zip(campaign.CASES, native['completed'], strict=True):
        preflight = receipts.admission(name, baseline)
        binary = binaries[kind]
        assert receipts.remote(name + '-hash', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
        output = receipts.remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
            'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', binary['remote'], *args], '300s')
        receipts.fresh(preflight, audit.instant(receipts.events[name]['started']))
        observed = helper.pass_fields(output)
        if kind == 'deferred':
            mode, count, *ids = args
            required = oracle.expected(int(count), mode == '--late-segments-compute', mode == '--segments-readback', ids)
        else:
            required = helper.expected(args[-1], args[:2])
        assert observed == required, (name, observed, required)
        assert accepted == dict(name=name, kind=kind, arguments=args, fields=observed)
        receipts.admission(name + '-post', baseline)
    paths = [binary['remote'] for binary in binaries.values()]
    probe = ('import json,os,sys; from pathlib import Path; '
        'targets=set(sys.argv[1:]); found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe.removesuffix(" (deleted)") in targets: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    assert audit.decode_json(receipts.remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])) == {'owned_executable_pids': []}
    for kind, binary in binaries.items():
        path = binary['remote']
        assert audit.decode_json(receipts.remote('owned-executable-exists-' + kind,
            ['/usr/bin/python3', '-I', '-B', '-c', 'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))', path])) == {'exists': True}
        assert receipts.remote('final-hash-' + kind, ['/usr/bin/sha256sum', path]).split() == [binary['sha256'], path]
        assert receipts.remote('remove-owned-executable-' + kind, ['/usr/bin/rm', '--', path]) == ''
    assert receipts.remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory]) == ''
    assert receipts.remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory]) == ''
    receipts.admission('final', baseline)
    assert len(receipts.events) == 133
    assert set(receipts.events) == {path.parent.name for path in HARDWARE.glob('*/result.json')}
    assert audit.current_source() == source
    for kind, binary in binaries.items():
        assert campaign.build_identity(helper, kind, generation) == {key: value for key, value in binary.items() if key != 'remote'}
    result = dict(accepted=True, base=BASE, cases=14, pending_pipeline_cases=10, settled_regressions=4,
        native_events=receipts.events, binaries=binaries,
        campaign_receipt_sha256=sha(HARDWARE / 'campaign.json'),
        outer_receipt_sha256=sha(outer_folder / 'receipt.json'), auditor_sha256=sha(Path(__file__)),
        reference_auditor_sha256=REFERENCE_SHA, selected_unique_ids=audit.IDS,
        owned_cleanup_complete=True, final_point_baseline_restored=True,
        performance_acceptance=False, formal_refinement=False, general_application_authority=False)
    with (RAW / 'audit-native.json').open('x') as output:
        json.dump(result, output, sort_keys=True, indent=2)
        output.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'native_events'}))


if __name__ == '__main__':
    main()
