"""Reuse the exact baseline workflow runner with a fresh final output directory."""
import hashlib
import importlib.util
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
source = RAW / 'source_controls_baseline.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == \
    'fb5b67b44ad85fd21792a2fe18f9bac60897033c8a37a51ea2fa5c04e0277a5c'
spec = importlib.util.spec_from_file_location('exact_workflow_commands', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.OUT = RAW / ('source-controls-final-' + sys.argv[1] + '-commands')
sys.exit(module.main())
