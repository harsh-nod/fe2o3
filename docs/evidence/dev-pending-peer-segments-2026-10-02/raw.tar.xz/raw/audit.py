"""Close fresh runtime qualification; distinguish unchanged baseline evidence."""
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile

import yaml

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '131569ccac7958d5a45ae6b80902edc31b25b4e7'
CAPTURE = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
PINS = {
    'qualify.py': '0d63ee741a0025a436990db22d6519cf2edbbb36dc4702f158b7d93ce6ff5686',
    'audit_hardware.py': '064ecd4906ad19b7893886e4829acd0a10a32da6f7d13ebf18c1560c694ae43f',
    'hardware-01/campaign.py': '2658719047c1ff1b7c06b2624e1c74bc576b1ea9ee2ec1cc0ac324de832b92ad',
    'native_oracle.py': '8dda25ad58578030b3e696280c8343f7d4506410a72190ed51dbfa95f3a5d770',
    'source_controls_baseline.py': 'fb5b67b44ad85fd21792a2fe18f9bac60897033c8a37a51ea2fa5c04e0277a5c',
    'propose_metadata.py': 'f6d06dc1d9484fe1416f73599822f96444f540592ad610f03e7a89f041d38d08',
}
CONTEXT_TESTS = '''segments_keep_exact_writer_list_snapshot_and_full_readback_frame
segments_feed_full_frame_read_only_compute_aliases_with_final_only_observation
segments_require_opt_in_exact_full_writer_and_event_before_backend
segments_reject_invalid_complete_roster_and_writable_frame_alias_before_effect
segments_refund_cancellation_and_rejection_but_retain_terminal_admission
segments_failed_parent_retains_identity_without_promoting_frame
segments_retained_success_does_not_hide_descended_producer_fault
segments_reject_pending_destination_and_cancelled_list_never_promotes_readback
segments_backend_completion_keeps_logical_source_reserved_and_stale_event_is_only_control
segments_validate_immutable_identity_rank_and_nested_profile_before_observation'''.splitlines()
BACKEND_TESTS = '''pending_segments_compute_full_pipeline_releases_events_and_restores_exact_frame
pending_segments_direct_readback_observes_full_preserved_frame_not_envelope
pending_segments_cancelled_list_does_not_authorize_consumer_or_readback
pending_segments_postpublication_cancel_and_prefix_failure_preserve_custody
pending_segments_plan_substitution_cannot_hide_behind_equal_envelopes
pending_segments_consumer_rejects_wrong_exact_event_writable_alias_and_bounds
pending_segments_physically_completed_native_source_keeps_exact_frame_provenance
pending_segments_completed_deferred_source_retains_one_accounted_original_launch'''.splitlines()


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and sys.argv[1].isdigit() and sys.argv[2].isdigit()
    generation, proposal = sys.argv[1:]
    assert sha(RAW / 'capture.py') == CAPTURE
    for name, digest in PINS.items():
        assert sha(RAW / name) == digest
    capture = module('capture', RAW / 'capture.py')
    source = capture.snapshot()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
    qualify = module('qualification', RAW / 'qualify.py')
    jobs = [(name + '-final-' + generation, bound, argv) for name, bound, argv in qualify.JOBS]
    assert len(jobs) == 15
    summary = read(RAW / ('qualification-summary-' + generation + '.json'))
    assert summary == [dict(label=label, exit=0) for label, _, _ in jobs]
    verifier = RAW / ('proposal-' + proposal) / 'verify-applied.py'
    assert sha(verifier) == '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243'
    jobs += [
        ('metadata-final-before-' + generation, '120s', ['python3', '-I', '-B', str(verifier)]),
        ('metadata-final-after-' + generation, '120s', ['python3', '-I', '-B', str(verifier)]),
        ('source-controls-final-' + generation, '600s', ['python3', '-I', '-B', str(RAW / 'source_controls_final.py'), generation]),
        ('hardware-final-' + generation, '3600s', ['python3', '-I', '-B', str(RAW / 'hardware-01/campaign.py'), generation]),
        ('audit-native-final-' + generation, '120s', ['python3', '-I', '-B', str(RAW / 'audit_hardware.py'), generation]),
    ]
    selected = {}
    for label, bound, argv in jobs:
        folder = RAW / label
        receipt, command = (read(folder / name) for name in ('receipt.json', 'command.json'))
        assert all(receipt[key] == value for key, value in command.items()), label
        assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', bound, *argv], label
        assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, label
        assert receipt['base'] == BASE and receipt['cwd'] == str(REPO), label
        assert receipt['controller_sha256'] == CAPTURE and receipt['environment'] == capture.ENV, label
        assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == source, label
        assert datetime.fromisoformat(receipt['started']) <= datetime.fromisoformat(receipt['finished'])
        for output in ('stdout', 'stderr'):
            assert sha(folder / output) == receipt[output + '_sha256'], label
        selected[label] = dict(receipt_sha256=sha(folder / 'receipt.json'))
    counts = {}
    for kind in ('runtime', 'deferred', 'settled'):
        output = (RAW / (kind + '-tests-final-' + generation) / 'stdout').read_text()
        summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; 0 filtered out;', output, re.M)
        assert len(summaries) == 1 and summaries[0][1] == '0'
        passed, _, ignored = map(int, summaries[0])
        outcomes = re.findall(r'^test (.+?) \.\.\. (ok|ignored(?:, [^\n]*)?)$', output, re.M)
        roster = re.findall(r'^(.+): test$', (RAW / (kind + '-list-final-' + generation) / 'stdout').read_text(), re.M)
        assert len(roster) == len(set(roster)) == passed + ignored
        assert Counter(name for name, _ in outcomes) == Counter(roster)
        assert sum(status == 'ok' for _, status in outcomes) == passed
        assert ignored == (32 if kind == 'runtime' else 0)
        counts[kind] = dict(passed=passed, ignored=ignored)
    archive_path = 'docs/evidence/dev-unified-peer-segments-2026-10-02/raw.tar.xz'
    blob = subprocess.check_output(['git', 'show', BASE + ':' + archive_path], cwd=REPO)
    assert hashlib.sha256(blob).hexdigest() == '6964c627cc0794258fa40ee625bed3dd6cd6f8b30a4825f67aaec9c6c209d184'
    with tarfile.open(fileobj=io.BytesIO(blob), mode='r:xz') as archive:
        old = archive.extractfile('raw/runtime-tests-final-01/stdout').read().decode()
        old_doctests = archive.extractfile('raw/doctests-final-01/stdout').read().decode()
        prior_source = json.loads(archive.extractfile('raw/kfd-build-final-02/source-before.json').read())
    current = (RAW / ('runtime-tests-final-' + generation) / 'stdout').read_text()
    ignored_pattern = r'^test (.+?) \.\.\. ignored(?:, [^\n]*)?$'
    assert len(re.findall(ignored_pattern, old, re.M)) == 32
    assert Counter(re.findall(ignored_pattern, old, re.M)) == Counter(re.findall(ignored_pattern, current, re.M))
    old_roster = set(re.findall(r'^test (.+?) \.\.\. ', old, re.M))
    new_roster = set(re.findall(r'^test (.+?) \.\.\. ', current, re.M))
    assert old_roster <= new_roster
    new_tests = sorted(new_roster - old_roster)
    assert new_tests == sorted([
        *('context::tests::compute_peer_tests::segments::' + name for name in CONTEXT_TESTS),
        *('kfd_backend::tests::compute_peer_tests::segments::' + name for name in BACKEND_TESTS),
    ])
    lower = {name: value for name, value in source.items() if name.startswith('crates/fe2o3-kfd/')}
    assert lower == {name: value for name, value in prior_source.items() if name.startswith('crates/fe2o3-kfd/')}
    for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'):
        assert source[name] == prior_source[name]
    report = read(verifier.parent / 'metadata-report.json')
    assert len(report['proof_files']) == 76
    invocation = read(verifier.parent / 'invocation.json')
    assert invocation['base'] == BASE
    assert invocation['wrapper_sha256'] == PINS['propose_metadata.py']
    assert invocation['solver_executed'] is invocation['build_executed'] is invocation['formal_qualification'] is False
    assert len(invocation['forwarding_methods']) == 4
    for row in report['changes']:
        original = subprocess.check_output(['git', 'show', BASE + ':' + row['path']], cwd=REPO)
        assert hashlib.sha256(original).hexdigest() == row['original_sha256']
        assert (verifier.parent / 'originals' / Path(row['path']).name).read_bytes() == original
        assert sha(REPO / row['path']) == row['proposed_sha256']
    for name, digest in report['proof_files'].items():
        previous = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=REPO)
        assert hashlib.sha256(previous).hexdigest() == digest == sha(REPO / name)
    for phase in ('before', 'after'):
        row = read(RAW / ('metadata-final-' + phase + '-' + generation) / 'stdout')
        assert row['ast_identical_except_recorded_metadata_literals'] and row['applied_guard_hashes_match_proposal']
        assert row['unchanged_proof_files'] == 76 and not row['formal_qualification']
    workflow = yaml.safe_load((REPO / '.github/workflows/runtime-component-source-guards.yml').read_text())
    commands = [(step['name'], shlex.split(line)) for step in workflow['jobs']['source-controls']['steps'] if 'run' in step for line in step['run'].splitlines()]
    assert len(commands) == 32
    baseline_folder = RAW / 'baseline-source-controls'
    baseline = read(baseline_folder / 'receipt.json')
    baseline_command = read(baseline_folder / 'command.json')
    assert all(baseline[key] == value for key, value in baseline_command.items())
    assert baseline['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '600s',
        'python3', '-I', '-B', str(RAW / 'source_controls_baseline.py')]
    assert baseline['exit'] == 0 and baseline['source_unchanged'] is True
    assert baseline['base'] == BASE and baseline['cwd'] == str(REPO)
    assert baseline['controller_sha256'] == CAPTURE and baseline['environment'] == capture.ENV
    for output in ('stdout', 'stderr'):
        assert sha(baseline_folder / output) == baseline[output + '_sha256']
    baseline_source = read(baseline_folder / 'source-before.json')
    assert baseline_source == read(baseline_folder / 'source-after.json')
    names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', BASE,
        '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=REPO).decode().rstrip('\0').split('\0')
    assert sorted(names) == sorted(baseline_source)
    blobs = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
        input=''.join(BASE + ':' + name + '\n' for name in sorted(baseline_source)).encode())
    offset = 0
    for name in sorted(baseline_source):
        end = blobs.index(b'\n', offset)
        _, kind, size = blobs[offset:end].split()
        assert kind == b'blob'
        offset, size = end + 1, int(size)
        assert hashlib.sha256(blobs[offset:offset + size]).hexdigest() == baseline_source[name]
        offset += size
        assert blobs[offset:offset + 1] == b'\n'
        offset += 1
    assert offset == len(blobs)
    for phase in ('baseline', 'final-' + generation):
        folder = RAW / ('source-controls-' + phase + '-commands')
        control = read(folder / 'summary.json')
        assert control['accepted'] is True and control['solver_executed'] is False
        assert [(row['name'], row['command']) for row in control['commands']] == commands
        assert control['workflow_sha256'] == sha(REPO / '.github/workflows/runtime-component-source-guards.yml')
        assert control['controller_sha256'] == sha(RAW / 'source_controls_baseline.py')
        for index, row in enumerate(control['commands']):
            assert row['exit'] == 0 and read(folder / f'{index:02d}' / 'receipt.json') == row
            for output in ('stdout', 'stderr'):
                assert sha(folder / f'{index:02d}' / output) == row[output + '_sha256']
    doctest = (RAW / ('doctests-final-' + generation) / 'stdout').read_text()
    docrows = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', doctest, re.M)
    assert list(map(int, docrows)) == [10, 51]
    doc_pattern = r'^test (crates/fe2o3-runtime/.+?) \.\.\. ok$'
    doc_names = re.findall(doc_pattern, doctest, re.M)
    old_doc_names = re.findall(doc_pattern, old_doctests, re.M)
    assert len(doc_names) == len(old_doc_names) == 61
    normalize_doc = lambda name: re.sub(r' \(line \d+\)', '', name)
    assert Counter(map(normalize_doc, doc_names)) == Counter(map(normalize_doc, old_doc_names))
    native = read(RAW / 'audit-native.json')
    assert native['accepted'] is True and native['cases'] == 14
    assert native['owned_cleanup_complete'] and not native['performance_acceptance'] and not native['formal_refinement']
    assert native['auditor_sha256'] == PINS['audit_hardware.py']
    assert read(RAW / ('audit-native-final-' + generation) / 'stdout') == {
        key: value for key, value in native.items() if key != 'native_events'}
    result = dict(accepted=True, base=BASE, source_files=len(source), counts=counts,
        new_runtime_tests=new_tests, doctests=61, source_controls=32, selected_receipts=selected,
        native_audit_sha256=sha(RAW / 'audit-native.json'), native_cases=14,
        unchanged_proof_files=76, fresh_solver_execution=False, whole_adapter_verified=False,
        lower_kfd_freshly_tested=False, lower_kfd_unchanged_files=len(lower),
        lower_kfd_prior_evidence=archive_path, baseline_archive_sha256=hashlib.sha256(blob).hexdigest(),
        auditor_sha256=sha(Path(__file__)), performance_acceptance=False)
    with (RAW / 'audit-result.json').open('x') as output:
        json.dump(result, output, sort_keys=True, indent=2)
        output.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
