"""Rebind reviewed source identities; never relax guards or execute a solver."""
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '131569ccac7958d5a45ae6b80902edc31b25b4e7'
ARCHIVE = 'docs/evidence/dev-unified-peer-segments-2026-10-02/raw.tar.xz'
REFERENCES = {
    'propose.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    'verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
}
OBSERVER = 'check-producer-journal-observers.py'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2 and sys.argv[1].startswith('proposal-')
    assert sys.argv[1][9:].isdigit()
    destination = RAW / sys.argv[1]
    destination.mkdir(mode=0o700)
    references = destination / 'reference'
    references.mkdir()
    packed = subprocess.check_output(['git', 'show', BASE + ':' + ARCHIVE], cwd=REPO)
    with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
        for name, expected in REFERENCES.items():
            member = archive.getmember('raw/source-ci/reference/' + name)
            assert member.isfile()
            data = archive.extractfile(member).read()
            assert sha(data) == expected
            with (references / name).open('xb') as output:
                output.write(data)
    proposer = load(references / 'propose.py', 'pending_segments_metadata')
    proposer.BASE, proposer.OUT = BASE, destination
    original = (REPO / proposer.V / OBSERVER).read_text()
    assert original == proposer.blobs([proposer.V / OBSERVER])[proposer.V / OBSERVER]
    guard = proposer.load(OBSERVER, original)
    baseline_owner = proposer.blobs([guard.OWNER])[guard.OWNER]
    candidate_owner = (REPO / guard.OWNER).read_text()
    baseline_body = proposer.blobs([guard.BODY])[guard.BODY]
    assert (REPO / guard.BODY).read_text() == baseline_body
    duplicate_name = 'test-producer-input-composition.py'
    duplicate_path = proposer.V / duplicate_name
    duplicate_original = proposer.blobs([duplicate_path])[duplicate_path]
    assert (REPO / duplicate_path).read_text() == duplicate_original
    assert sha(duplicate_original.encode()) == '00121ae8a255de17877c260cede36dd5fd732a6ac2f523bf775acd9c210b07e6'
    duplicate = proposer.load(duplicate_name, duplicate_original)
    owner_before, owner_after = sha(baseline_owner.encode()), sha(candidate_owner.encode())
    assert duplicate.PINS['producer_readers.rs'] == owner_before == 'deaa68a4b596f04f8c30186b92cc350814bdc153417da22b18f114a159d7e343'
    assert owner_after == '005e34043f47acc0f7411d20f00b8f782dea3302ccd8493c79f010c39371abf7'
    for name, digest in duplicate.PINS.items():
        if name == 'producer_readers.rs':
            continue
        path = Path(duplicate.NATIVE) / name
        assert sha((REPO / path).read_bytes()) == digest == sha(proposer.blobs([path])[path].encode())
    methods = []
    for name in guard.ROUTES:
        anchor = 'fn observe_' + name + '('
        def method(text):
            assert text.count(anchor) == 1
            start = text.index(anchor)
            signature = text[start:text.index('{', start)]
            return signature + guard.block(text, anchor)
        before, after = method(baseline_owner), method(candidate_owner)
        assert before == after
        methods.append(dict(name=name, unchanged_sha256=sha(before.encode())))
    include = 'include!("producer_journal_observer_bodies.rs");\n'
    def reconstruct(owner):
        assert owner.count(include) == 1
        result = owner.replace(include, '')
        for name, (_reference, _result, query) in guard.ROUTES.items():
            expression = 'producer_observe_' + name + '_body_v1!(self, reference)'
            assert result.count(expression) == 1
            result = result.replace(expression, 'self.versions.journal.' + query + '(reference)')
        return sha(result.encode())
    assert reconstruct(baseline_owner) == guard.NATIVE_PREEXTRACTION_SHA
    new_pin = reconstruct(candidate_owner)
    original_edits = proposer.MetadataEdits
    class ReviewedOwnerMetadata(original_edits):
        def assignment(self, name, value, category, rationale):
            super().assignment(name, value, category, rationale)
            if self.source == original and name == 'RUNTIME_SHA':
                super().assignment('NATIVE_PREEXTRACTION_SHA', new_pin, 'content-sha256',
                    'reconstructed owner identity after distinct segment adapter additions; '
                    'all four exact forwarding methods and their shared proof bodies unchanged; '
                    'no new adapter refinement claim')
            if self.source == duplicate_original and name == 'NATIVE_TREE_SHA':
                super().pin('PINS', 'producer_readers.rs', owner_after)
                self.edits[-1]['rationale'] = (
                    'duplicate reviewed native-owner identity; unchanged extracted bodies; '
                    'no new refinement')
    proposer.MetadataEdits = ReviewedOwnerMetadata
    invocation = dict(base=BASE, archive_sha256=sha(packed), references=REFERENCES,
        wrapper_sha256=sha(Path(__file__).read_bytes()), solver_executed=False,
        build_executed=False, formal_qualification=False,
        owner_before_sha256=sha(baseline_owner.encode()),
        owner_after_sha256=sha(candidate_owner.encode()), forwarding_methods=methods,
        reconstructed_before=guard.NATIVE_PREEXTRACTION_SHA, reconstructed_after=new_pin,
        extra_metadata_scope='NATIVE_PREEXTRACTION_SHA and exact duplicate producer_readers.rs '
                             'owner pin only; no predicate or proof changes')
    with (destination / 'invocation.json').open('x') as output:
        json.dump(invocation, output, indent=2, sort_keys=True)
        output.write('\n')
    proposer.main()
    report = json.loads((destination / 'metadata-report.json').read_bytes())
    assert len(report['proof_files']) == 76
    duplicate_edits = [(row['path'], edit['selector'], edit['old'], edit['new'], edit['category'])
                       for row in report['changes'] for edit in row['edits']
                       if edit['selector'].startswith('PINS[')]
    assert duplicate_edits == [(str(duplicate_path), "PINS['producer_readers.rs']",
                                owner_before, owner_after, 'content-sha256')]
    extra = [(row['path'], edit) for row in report['changes'] for edit in row['edits']
             if edit['selector'] == 'NATIVE_PREEXTRACTION_SHA']
    assert len(extra) == int(new_pin != guard.NATIVE_PREEXTRACTION_SHA)
    if extra:
        assert extra[0][0] == str(proposer.V / OBSERVER)
        assert extra[0][1]['old'] == guard.NATIVE_PREEXTRACTION_SHA
        assert extra[0][1]['new'] == new_pin
    with (destination / 'verify-applied.py').open('xb') as output:
        output.write((references / 'verify-applied.py').read_bytes())


if __name__ == '__main__':
    main()
