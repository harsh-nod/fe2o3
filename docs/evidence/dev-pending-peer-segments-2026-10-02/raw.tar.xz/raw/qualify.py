"""Complete runtime qualification on a frozen pending-list candidate."""
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
C = ['--locked', '--offline']
R = [*C, '-p', 'fe2o3-runtime']
W = [*R, '--no-default-features', '--features', 'hardware-qualification']
CHANGED = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=ACMR'],
                                 cwd=REPO, text=True).splitlines()
NEW = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'],
                             cwd=REPO, text=True).splitlines()
RUST = sorted(name for name in set(CHANGED + NEW)
              if name.startswith('crates/') and name.endswith('.rs'))
JOBS = [
    ('format', '120s', ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                      '--config', 'skip_children=true', *RUST]),
    ('whitespace', '60s', ['git', 'diff', '--check']),
    ('clippy-runtime', '900s', ['cargo', 'clippy', *R, '--all-features', '--lib', '--tests', '--', '-D', 'warnings']),
    ('runtime-tests', '900s', ['cargo', 'test', *R, '--all-features', '--lib']),
    ('runtime-list', '120s', ['cargo', 'test', *R, '--all-features', '--lib', '--', '--list']),
    ('doctests', '900s', ['cargo', 'test', *R, '--all-features', '--doc']),
    ('check-no-default', '900s', ['cargo', 'check', *R, '--no-default-features', '--lib']),
]
for label, target in (
    ('deferred', 'gfx942-runtime-deferred-peer-chain-smoke'),
    ('settled', 'gfx942-runtime-unified-segments-smoke'),
):
    witness = [*W, '--example', target]
    JOBS.extend([
        ('clippy-' + label, '900s', ['cargo', 'clippy', *witness, '--', '-D', 'warnings']),
        (label + '-tests', '900s', ['cargo', 'test', *witness]),
        (label + '-list', '120s', ['cargo', 'test', *witness, '--', '--list']),
        ('build-' + label, '900s', ['cargo', 'build', *witness, '--profile', 'test', '--message-format=json']),
    ])


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2 and sys.argv[1].isdigit()
    generation = sys.argv[1]
    results = []
    for name, bound, command in JOBS:
        label = name + '-final-' + generation
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'),
                                 label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    with (RAW / ('qualification-summary-' + generation + '.json')).open('x') as output:
        json.dump(results, output, indent=2)
        output.write('\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
