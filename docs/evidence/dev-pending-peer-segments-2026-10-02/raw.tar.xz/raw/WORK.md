# Pending Multi GPU Segments

Baseline: 131569ccac7958d5a45ae6b80902edc31b25b4e7.
Previous goal turn: progress. Unified settled-owner native segment lists were
implemented, independently audited, signed, and pushed to both remotes.

User priority remains working multi-GPU. Next acceptance is fully queued
compute -> ordered overlapping segment list -> compute -> peer/readback,
driven by final streams without a host compute join. Preserve exact immutable
list identity, producer references, initialized destination frame, dependency
ranks, whole-list completion and terminal native custody. No scalar-envelope
relabeling, synthetic application authority, or hidden staged fallback.

Three swarm members are initially reviewing Context integration, native backend
integration, and acceptance fixtures read-only. Root owns integration, review,
qualification, metadata/evidence, and signed dual-remote publication. No Qwen.

The overall parity goal remains active and incomplete. Native hardware work
requires fresh selected-device admission, bounded commands and owned cleanup.
No reset, foreign process termination or broad temporary-directory cleanup.
