# Read-only review and integration

Primary owns source edits, integration, tests and signing. Two native
collaboration agents reviewed source/test behavior read-only, without builds or
permission requests. No Qwen worker was invoked.

Cancellation review required exact Ready/zero-progress/no-window eligibility,
retaining Failed code -2, preserving Published/partial TooLate, allowing interior
SDMA cancellation, and checking indexed ownership before completed-record lookup
could hide an active/completed duplicate. The common release commit removes the
descriptor last; failure seals ingress before any logical release prefix.

The test matrix uses genuine A -> B and A -> B -> C admission before deliberately
corrupting one private prerequisite. Snapshots hold metadata, scalar owner IDs and
backing addresses only. A remains Published; B/C remain in their exact pre-call
state. No terminal fixture repairs/disarms Drop. Scripted same-device submission
received the same read-only pair accessor already available for directional
submission; it does not transfer ownership.

Review then identified a healthy-path stream-ordering bug: B depends first on
failed D and then on published A; releasing completed B cleared the stream tail
while A remained unfinished. The public reproduction checks the missing tail
before any subsequent native step, so a driver mismatch cannot masquerade as the
expected failure. After the fix, disjoint C actually admits behind A and remains
Ready until A completes.

An initial review suggestion to restore terminal records was rejected after
checking the failure-neutral compute ordering tests. It could revive a failed A
after later B succeeds and is released. The final helper selects only unfinished
owners using two FIFO backs and primary/auxiliary lane heads plus pipeline entries,
filtered by exact stream and globally monotone ID. It updates the existing tail
slot without allocation and does not scan the terminal HashMap. Empty pipelines
are skipped by take(live_count); nonempty pipeline traversal remains bounded by
the admitted slot capacity. It is not claimed constant-time for arbitrary
pipeline capacity or a new formal ordering proof.

All four release/cancellation call sites use the helper after removing the old
owner from its live index. The public tests include successive B/C cancellation,
and private compute-roster controls cover all four active/pipeline locations,
foreign-stream exclusion, retained failed/cancelled terminal history, and stable
tail-map capacity. Prepared cancellation no longer restores an already-completed
copy. The profiler fixture now retains an actual pending recipe rather than an
impossible Pending entry in the terminal submissions table.

Final source review found no further concrete bug. Existing monotone FIFO/lane
index invariants remain premises; this is not arbitrary-corruption validation of
every global index. Native GPU execution, complete owner-arena/queued-writer
proofs, lower native unwind boundaries and matched HIP/HSA performance remain
separate gates. Pending/prepared compute cancellation still has its own cleanup
implementation; SDMA checked settlement does not prove those paths.
