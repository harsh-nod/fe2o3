git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit f4506fee60fe580469e20df8feda6832f3d6edce 
