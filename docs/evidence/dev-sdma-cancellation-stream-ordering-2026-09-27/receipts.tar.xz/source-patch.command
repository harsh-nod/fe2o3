git diff --binary 2ba769049798e0453e574aabb905b65dfc23b822 HEAD -- crates 
