"""Serial final-source runtime qualification; native runs are recorded separately."""
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
CARGO = ['cargo', '+nightly-2026-04-03']
RUNTIME = ['-p', 'fe2o3-runtime']
STAGES = [
    ('runtime-artifact-final', 900, CARGO + ['test', *RUNTIME, '--all-features', '--lib', '--no-run', '--message-format=json']),
    ('runtime-roster-final', 900, CARGO + ['test', *RUNTIME, '--all-features', '--lib', '--', '--list']),
    ('runtime-docs-final', 900, CARGO + ['test', *RUNTIME, '--all-features', '--doc']),
    ('examples-tests-final', 900, CARGO + ['test', *RUNTIME, '--all-features', '--examples']),
    ('example-build-final', 900, CARGO + ['build', *RUNTIME, '--no-default-features', '--example', 'gfx942-runtime-multi-preparation-smoke', '--message-format=json']),
    ('clippy-lib-final', 900, CARGO + ['clippy', *RUNTIME, '--all-features', '--lib', '--', '-D', 'warnings']),
    ('clippy-example-final', 900, CARGO + ['clippy', *RUNTIME, '--no-default-features', '--example', 'gfx942-runtime-multi-preparation-smoke', '--', '-D', 'warnings']),
    ('check-no-default-final', 900, CARGO + ['check', *RUNTIME, '--no-default-features', '--lib']),
    ('format-final', 60, CARGO + ['fmt', '-p', 'fe2o3-runtime', '--', '--check']),
    ('whitespace-final', 60, ['git', 'diff', '--check']),
]
for name, seconds, argv in STAGES:
    result = subprocess.run(['python3', '-I', '-B', str(HERE / 'capture.py'), name, f'{seconds}s', *argv])
    if result.returncode:
        sys.exit(result.returncode)
