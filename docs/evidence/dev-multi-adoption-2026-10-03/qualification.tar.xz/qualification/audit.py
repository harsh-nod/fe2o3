"""Replay source/output bindings, test rosters, native observations and cleanup."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from types import ModuleType

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
sys.path.insert(0, str(HERE))
import capture


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def receipt(label):
    folder = HERE / label
    row = read(folder / 'receipt.json')
    assert row['exit'] == 0 and row['source_unchanged']
    assert row['environment'] == capture.ENV
    assert row['base'] == '2ff3e85451e5f1912651d97912f816c147e2af52'
    assert read(folder / 'source-before.json') == source == read(folder / 'source-after.json')
    for name in ('stdout', 'stderr'):
        assert row[name + '_sha256'] == sha(folder / name)
    return row


def counts(label):
    text = (HERE / label / 'stdout').read_text()
    matches = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', text)
    assert matches and 'FAILED' not in text
    return [sum(int(row[index]) for row in matches) for index in range(2)]


def replay_observation(label, device, case, phase, result):
    observer = ModuleType('observer')
    observer.__file__ = str(HERE / 'copy-host-observe.py')
    exec(compile(Path(observer.__file__).read_bytes(), observer.__file__, 'exec'), observer.__dict__)
    observation = read(native / f'{label}.json')
    start, end = (observation[key]['monotonic_ns'] for key in ('started', 'finished'))
    assert result['started']['monotonic_ns'] <= start <= end <= result['finished']['monotonic_ns']
    if phase == 'before':
        assert end <= case['started']['monotonic_ns']
        assert 0 <= case['started']['monotonic_ns'] - start <= 150 * 10**9
    else:
        assert case['finished']['monotonic_ns'] <= start
    commands = [read(native / f'{label}-{index}/receipt.json') for index in range(2)]
    timeline = [observation['sysfs'][0], commands[0], observation['sysfs'][1],
                commands[1], observation['sysfs'][2]]
    previous = start
    for item in timeline:
        assert previous <= item['started']['monotonic_ns'] <= item['finished']['monotonic_ns'] <= end
        previous = item['finished']['monotonic_ns']
    snapshots = iter(observation['sysfs'])

    def sysfs(root, bdf):
        assert bdf == device[1]
        snapshot = next(snapshots)
        assert snapshot['path'] == str(root / bdf)
        return snapshot

    observer.capture_sysfs = sysfs
    ordinal = 0

    def run(argv):
        nonlocal ordinal
        folder = native / f'{label}-{ordinal}'
        command = commands[ordinal]
        ordinal += 1
        assert command['argv'] == argv and command['bound_seconds'] == 35
        return dict(exit=command['exit'], error=command['error'],
                    stdout=(folder / 'stdout').read_text(), stderr=(folder / 'stderr').read_text())

    replay = observer.observe(*device, Path('/opt/rocm/bin/rocm-smi'), run=run)
    assert ordinal == 2 and next(snapshots, None) is None
    assert {k: v for k, v in replay.items() if k not in ('started', 'finished')} == {
        k: v for k, v in observation.items() if k not in ('started', 'finished')}
    assert replay['endpoint_admitted'] and replay['selected_pids'] == [] and replay['reasons'] == []


source = capture.snapshot()
labels = ['runtime-tests-01', 'runtime-artifact-final', 'runtime-roster-final',
          'runtime-docs-final', 'examples-tests-final', 'example-build-final',
          'clippy-lib-final', 'clippy-example-final', 'check-no-default-final',
          'format-final', 'whitespace-final', 'native-create-01',
          'native-tools-upload-final', 'native-binary-upload-final', 'native-hashes-final',
          'native-campaign-final', 'native-retrieve-final', 'native-cleanup-final']
labels += [f'controls-01-{index:02}' for index in range(33)]
receipts = {label: receipt(label) for label in labels}
roster = set(re.findall(r'^(.+): test$', (HERE / 'runtime-roster-final/stdout').read_text(), re.M))
tested = set()
abort_headers = {
    'kfd_backend::tests::runtime_compute_pipeline_drop_aborts_for_every_live_logical_phase': 5,
    'kfd_backend::tests::scripted_sdma_drop_still_aborts_with_live_or_terminal_custody': 2,
}
for line in (HERE / 'runtime-tests-01/stdout').read_text().splitlines():
    if not line.startswith('test ') or line.startswith('test result:'):
        continue
    name, status = line[5:].rsplit(' ... ', 1)
    if not status:
        assert name in abort_headers and abort_headers[name] > 0
        abort_headers[name] -= 1
        continue
    if ' ... test ' in name:
        first, name = name.split(' ... test ')
        assert first == name and ('panic' in name or 'abort' in name), name
    assert status == 'ok' or status.startswith('ignored'), line
    assert name not in tested, name
    tested.add(name)
assert tested == roster
assert not any(abort_headers.values())
assert counts('runtime-tests-01') == [2378, 33]
assert counts('runtime-docs-final') == [71, 0]
for label in ('runtime-artifact-final', 'example-build-final'):
    for path, row in receipts[label]['executables'].items():
        assert sha(Path(path)) == row['sha256']
        assert Path(path).stat().st_size == row['byte_length']
binary = next(iter(receipts['runtime-artifact-final']['executables'].values()))
assert binary['target'] == 'fe2o3_runtime' and binary['test']
native = HERE / 'native-results'
result = read(native / 'result.json')
assert result == json.loads((HERE / 'native-campaign-final/stdout').read_text())
assert result['accepted'] and len(result['cases']) == 2
assert [case['name'] for case in result['cases']] == ['forward', 'reverse']
assert result['binary_identity']['sha256'] == binary['sha256']
assert result['binary_identity']['bytes'] == binary['byte_length']
assert result['devices'] == [[6, '0000:c6:00.0', '0x10a254ce4987e716'],
                             [7, '0000:e5:00.0', '0x53691ef168a0147d']]
expected_commands = []
for name in ('forward', 'reverse'):
    for phase in ('before', 'after'):
        for index in (6, 7):
            expected_commands.extend(f'{name}-{phase}-gpu{index}-{ordinal}' for ordinal in (0, 1))
        if phase == 'before':
            expected_commands.append(name)
assert result['commands'] == expected_commands and len(set(expected_commands)) == 18
previous = result['started']['monotonic_ns']
for name in expected_commands:
    row = read(native / name / 'receipt.json')
    assert row['exit'] == 0 and row['error'] is None and row['group_absent']
    assert row['members_before_reap'] == [row['pid']]
    environment = dict(PATH='/usr/bin:/bin', LANG='C', LC_ALL='C')
    if name in ('forward', 'reverse'):
        selected = result['devices'] if name == 'forward' else result['devices'][::-1]
        environment.update(FE2O3_TEST_NATIVE_ISOLATED='1',
                           FE2O3_TEST_NATIVE_UNIQUE_IDS=','.join(device[2] for device in selected),
                           RUST_TEST_THREADS='1')
    assert row['environment'] == environment
    assert previous <= row['started']['monotonic_ns'] <= row['finished']['monotonic_ns'] <= result['finished']['monotonic_ns']
    previous = row['finished']['monotonic_ns']
    for stream in ('stdout', 'stderr'):
        assert row[stream + '_sha256'] == sha(native / name / stream)
for case in result['cases']:
    assert case['accepted']
    name = case['name']
    selected = result['devices'] if name == 'forward' else result['devices'][::-1]
    expected = ('MULTI DATA PASS: two exact devices, independent retirement, primary rebound, '
                '9 DATA releases, zero publication, shutdown complete\n')
    assert (native / name / 'stderr').read_text() == case['expected'] == expected
    test = ('kfd_backend::generated_adoption::tests::native::multi::'
            'generated_native_multi_data_adopt_rebind_retire_without_publication')
    stdout = (native / name / 'stdout').read_text()
    assert 'running 1 test\n' in stdout and f'test {test} ... ok\n' in stdout
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in stdout
    row = read(native / name / 'receipt.json')
    assert re.fullmatch(r'/proc/self/fd/[0-9]+', row['executable'])
    assert row['argv'][1:] == ['--ignored', '--exact', test, '--nocapture']
    assert row['bound_seconds'] == 180
    for phase in ('before', 'after'):
        for device in result['devices']:
            replay_observation(f'{name}-{phase}-gpu{device[0]}', device, row, phase, result)
cleanup = json.loads((HERE / 'native-cleanup-final/stdout').read_text())
assert cleanup == dict(owned_processes=[], removed='/tmp/fe2o3-multi-adoption-20261003.nh8mSBSZ', absent=True)
assert receipts['native-campaign-final']['finished'] < receipts['native-retrieve-final']['started']
assert receipts['native-retrieve-final']['finished'] < receipts['native-cleanup-final']['started']
uploaded = {}
for line in (HERE / 'native-hashes-final/stdout').read_text().splitlines():
    digest, path = line.split()
    assert Path(path).parent == Path('/tmp/fe2o3-multi-adoption-20261003.nh8mSBSZ')
    assert Path(path).name not in uploaded
    uploaded[Path(path).name] = digest
assert set(uploaded) == {'fe2o3-runtime-multi-adoption-tests', 'native.py', 'cleanup.py', 'selected_pair_smoke.py', 'copy-host-observe.py'}
assert uploaded.pop('fe2o3-runtime-multi-adoption-tests') == binary['sha256']
assert all(sha(HERE / name) == digest for name, digest in uploaded.items())
metadata = read(HERE / 'metadata-02/metadata-report.json')
assert metadata['ast_identical_except_listed_metadata_constants']
report = dict(source_files=len(source), receipts=len(receipts), runtime_tests=counts('runtime-tests-01'),
              runtime_roster=len(roster), doctests=counts('runtime-docs-final'),
              example_tests=counts('examples-tests-final'), native_commands=len(result['commands']),
              native_cases=2, native_binary=binary, cleanup=cleanup,
              proof_boundary='No new solver run or whole-adapter formal refinement')
(HERE / 'audit-report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
