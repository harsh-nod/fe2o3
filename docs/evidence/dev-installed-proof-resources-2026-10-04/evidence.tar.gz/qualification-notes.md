# Installed Proof Resource Campaign

Source commit: 07dae1cbbd705b45f20167a37a9c22e3775fec81.
Base: dac764837296a440edf0fd3c71c37b5af3db8ed8.
Source patch SHA-256: 44632a94430ae31976adead9886fe097070ad9fd359a23410c0764d6f16b8eb7.

The final campaign uses genuine installed Worker/Verus resources and the actual
fixed application controller. Only compiler client-profile/registration facts
are fixtures; this is not authenticated ordinary application or GPU qualification.
The install digest is generated in the test, not independent administrative approval.

Results: final outer test passed in 56.35 seconds, including four nested controller
cases. The prior full campaign passed in 67.87 seconds. Both removed their outer
cgroups; each controller case contained/reaped its original children and retained
an unrelated sibling. The final app-good controller case took 26.58 seconds.
Two inspections in each namespace produced the same 440-byte candidate and the
same SHA-256 e42df3f0e0758e43b413ca8ba24bd076403acb51385c11b89819df5ab62d62ef.
Per-execution proof subjects are not asserted equal across independent sessions.

Negative inspection cases remove the Worker, client profile, protected Verus
runtime and libzstd in turn. All return 98 without a candidate. Missing libzstd
reports ControlHandshake. Restored objects are the same original objects.
Controller negatives are payload length mismatch, duplicate descriptors and a
stale session. Unit tests: 25 passed, 8 ignored. Documentation: 7 passed. Strict
all-target Clippy and formatting passed. Direct prepare/provision script phases
return 1 before writes outside the required private namespace.

The preliminary namespace logs preserve setup failures: missing root-level
host-library mountpoint, hidden awk alternatives, missing setup passwd lookup,
then EACCES when recursive root binds made private /dev/null nodev. Fresh --dev
mounts at each nested stage fixed the actual cause; loader mounts were executable.
The final test asserts /dev/null type/device/open and exact interpreter links.
resource-controller-campaign-1.log ran the prior inspector-only test executable
after a failed test-helper compilation; it is not controller proof evidence.
Only resource-controller-campaign-2.log and resource-controller-campaign-final.log
qualify the composed resource/controller path. Transient Rust helper compile
errors (umask module and digest formatting) were corrected before the final build.

Three native read-only reviewers checked the cached worker/source match, dynamic
dependency closure, pinned local Verus inputs, controller fixture reuse and
namespace/cgroup cleanup. The worker has no libLLVM/RPATH/RUNPATH dependency;
LLVM/LLD are statically linked. Seven external base DSOs suffice. The conditional
machine-analysis mode does not execute the OCML linker/ROCm bitcode-loading branch.
The final namespace contains no home/setup/host-library aliases, cache/preload,
hwcaps alternatives or ROCm tree. The actual proof confirms that layout.

This script is not an immutable distribution packager or hostile-root sandbox.
Trusted root qualification code sees the host cgroup tree, but cleanup addresses
only a fresh owned subtree. The manager unit still needs actual canonical-path
resource deployment; copies stored elsewhere do not establish production behavior.
No systemd unit was started, no MI300X/SSH workload was run, and no host dependency
was replaced. Namespace runtime copies disappear on exit.

Input evidence archive SHA-256:
370b549f82e79bcde61a251f531601dd82bbd1f649aa520cf637c6148d4d960d
(docs/evidence/dev-application-proof-controller-2026-10-04/evidence.tar.gz).
Only its envelope.bin, payload.hsaco and kernel.bin are extracted; the script
pins each hash. Archived config/deployment records are not reused.
