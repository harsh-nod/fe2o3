//! Canonical target-side lineage transcripts for the production V3 pipeline.
//!
//! These records retain exact, bounded inputs and associate identities produced
//! by adjacent compiler stages. They are deliberately inert. In particular,
//! they do not authenticate a producer, prove that AMDGPU lowering refines
//! semantic MIR or Kernel IR, or grant publication, link, load, or launch
//! authority. Those properties require a private join over live, move-only
//! compiler owners.
//!
//! ABI descriptors and export manifests already have canonical codecs and are
//! retained directly by their typed `fe2o3-compiler-lineage` receipts.

use std::{error::Error, fmt, str};

use fe2o3_amd_target::{
    PRODUCTION_AMDHSA_LLVM22_WORKER_DATA_LAYOUT_V1, PRODUCTION_AMDHSA_RUSTC_DATA_LAYOUT_V1,
};
use sha2::{Digest, Sha256};

const TRANSCRIPT_MAGIC_V3: [u8; 8] = *b"F2O3TLV3";
const TRANSCRIPT_VERSION_V3: u16 = 3;
const TRANSCRIPT_HEADER_BYTES_V3: usize = 24;
const FIELD_HEADER_BYTES_V3: usize = 8;
const IDENTITY_BYTES_V3: usize = 32 + 8;

/// Maximum canonical size accepted for any one target-lineage receipt preimage.
pub const MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3: usize = 4 * 1024 * 1024;

const MAX_TARGET_TEXT_BYTES_V3: usize = 256;
const MAX_TARGET_FEATURES_BYTES_V3: usize = 4 * 1024;
const MAX_DATA_LAYOUT_BYTES_V3: usize = 16 * 1024;
const TARGET_BINDING_KIND_V3: u16 = 1;
const DATA_LAYOUT_KIND_V3: u16 = 2;
const SEMANTIC_TO_LLVM_KIND_V3: u16 = 5;

/// Exact-input association policy. It intentionally makes no refinement claim.
pub const ASSOCIATION_ONLY_NO_REFINEMENT_PROOF_POLICY_V3: u16 = 1;

const ASSOCIATION_ONLY_CLAIM_V3: &[u8] = b"association-only/no-refinement-proof";
const TARGET_BINDING_DOMAIN_V3: &[u8] = b"FE2O3/PRODUCTION-TARGET-BINDING-TRANSCRIPT/V3\0";
const DATA_LAYOUT_DOMAIN_V3: &[u8] = b"FE2O3/PRODUCTION-DATA-LAYOUT-TRANSCRIPT/V3\0";
const SEMANTIC_TO_LLVM_DOMAIN_V3: &[u8] = b"FE2O3/PRODUCTION-SEMANTIC-TO-LLVM-ASSOCIATION/V3\0";

const EXACT_GFX942_TARGET_V3: &str = "gfx942:xnack-";
const EXACT_GFX950_TARGET_V3: &str = "gfx950:xnack-";
const EXACT_RUSTC_LLVM_TARGET_V3: &str = "amdgcn-amd-amdhsa";
const EXACT_GFX942_CPU_V3: &str = "gfx942";
const EXACT_GFX950_CPU_V3: &str = "gfx950";
const EXACT_GFX942_FEATURES_V3: &str = "-wavefrontsize32,+wavefrontsize64,-xnack";
const EXACT_CODE_OBJECT_VERSION_V3: u16 = 6;
const EXACT_WAVE_WIDTH_BITS_V3: u16 = 64;
const SEMANTIC_TARGET_LAYOUT_DOMAIN_V1: &[u8] = b"fe2o3/semantic-mir/rustc-target-layout/v1";
const SEMANTIC_TARGET_LAYOUT_FIELD_COUNT_V1: usize = 6;

/// Builds the exact semantic-MIR target-layout digest preimage used by rustc collection.
///
/// The returned bytes are an internal association input. They authenticate neither rustc nor the
/// target facts supplied by the caller.
pub fn canonical_semantic_target_layout_transcript_v1(
    rustc_llvm_target: &str,
    rustc_data_layout: &str,
    default_pointer_width_bits: u16,
    target_cpu: &str,
    target_features: &str,
) -> Result<Box<[u8]>, ProductionTargetLineageErrorV3> {
    let pointer_width = default_pointer_width_bits.to_le_bytes();
    let fields: [&[u8]; SEMANTIC_TARGET_LAYOUT_FIELD_COUNT_V1] = [
        SEMANTIC_TARGET_LAYOUT_DOMAIN_V1,
        rustc_llvm_target.as_bytes(),
        rustc_data_layout.as_bytes(),
        &pointer_width,
        target_cpu.as_bytes(),
        target_features.as_bytes(),
    ];
    let mut exact_length = 0_usize;
    for field in fields {
        exact_length = exact_length
            .checked_add(size_of::<u64>())
            .and_then(|length| length.checked_add(field.len()))
            .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
    }
    if exact_length > MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3 {
        return Err(ProductionTargetLineageErrorV3::TranscriptTooLarge {
            actual: exact_length,
            max: MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3,
        });
    }
    let mut transcript = Vec::new();
    transcript
        .try_reserve_exact(exact_length)
        .map_err(|_| ProductionTargetLineageErrorV3::AllocationFailed)?;
    for field in fields {
        transcript.extend_from_slice(
            &u64::try_from(field.len())
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?
                .to_le_bytes(),
        );
        transcript.extend_from_slice(field);
    }
    debug_assert_eq!(transcript.len(), exact_length);
    Ok(transcript.into_boxed_slice())
}

/// Rederives the semantic-MIR target-layout identity from exact target transcript fields.
pub fn derive_semantic_target_layout_identity_v1(
    rustc_llvm_target: &str,
    rustc_data_layout: &str,
    default_pointer_width_bits: u16,
    target_cpu: &str,
    target_features: &str,
) -> Result<TargetLineageIdentityV3, ProductionTargetLineageErrorV3> {
    let transcript = canonical_semantic_target_layout_transcript_v1(
        rustc_llvm_target,
        rustc_data_layout,
        default_pointer_width_bits,
        target_cpu,
        target_features,
    )?;
    TargetLineageIdentityV3::new(Sha256::digest(&transcript).into(), transcript.len() as u64)
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
/// SHA-256 and byte-length coordinates used by target-side association records.
pub struct TargetLineageIdentityV3 {
    sha256: [u8; 32],
    byte_len: u64,
}

impl TargetLineageIdentityV3 {
    /// Validates and constructs nonzero content-identity coordinates.
    pub fn new(sha256: [u8; 32], byte_len: u64) -> Result<Self, ProductionTargetLineageErrorV3> {
        validate_identity("lineage identity", sha256, byte_len)?;
        Ok(Self { sha256, byte_len })
    }

    /// Returns the retained SHA-256 digest.
    pub const fn sha256(self) -> [u8; 32] {
        self.sha256
    }

    /// Returns the retained byte length.
    pub const fn byte_len(self) -> u64 {
        self.byte_len
    }

    /// Encodes the identity as digest followed by little-endian byte length.
    pub fn encode(self) -> [u8; IDENTITY_BYTES_V3] {
        let mut encoded = [0_u8; IDENTITY_BYTES_V3];
        encoded[..32].copy_from_slice(&self.sha256);
        encoded[32..].copy_from_slice(&self.byte_len.to_le_bytes());
        encoded
    }

    pub(crate) fn decode(
        field: &'static str,
        encoded: &[u8],
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        if encoded.len() != IDENTITY_BYTES_V3 {
            return Err(ProductionTargetLineageErrorV3::InvalidFieldLength {
                field,
                actual: encoded.len(),
                expected: IDENTITY_BYTES_V3,
            });
        }
        let mut sha256 = [0_u8; 32];
        sha256.copy_from_slice(&encoded[..32]);
        let mut byte_len = [0_u8; 8];
        byte_len.copy_from_slice(&encoded[32..]);
        let byte_len = u64::from_le_bytes(byte_len);
        validate_identity(field, sha256, byte_len)?;
        Ok(Self { sha256, byte_len })
    }
}

/// The strongest semantic statement made by records in this module.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TargetLineageClaimV3 {
    /// The record associates exact identities and establishes no semantic refinement.
    AssociationOnlyNoRefinementProof,
}

#[derive(Clone, Copy)]
struct FieldSchemaV3 {
    name: &'static str,
    max_bytes: usize,
    exact_bytes: Option<usize>,
}

impl FieldSchemaV3 {
    const fn bounded(name: &'static str, max_bytes: usize) -> Self {
        Self {
            name,
            max_bytes,
            exact_bytes: None,
        }
    }

    const fn exact(name: &'static str, exact_bytes: usize) -> Self {
        Self {
            name,
            max_bytes: exact_bytes,
            exact_bytes: Some(exact_bytes),
        }
    }
}

struct RecordSchemaV3 {
    name: &'static str,
    kind: u16,
    policy: u16,
    domain: &'static [u8],
    fields: &'static [FieldSchemaV3],
}

const TARGET_BINDING_FIELDS_V3: &[FieldSchemaV3] = &[
    FieldSchemaV3::exact("domain", TARGET_BINDING_DOMAIN_V3.len()),
    FieldSchemaV3::exact("claim", ASSOCIATION_ONLY_CLAIM_V3.len()),
    FieldSchemaV3::exact("protected rustc invocation identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("semantic MIR identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("target-neutral Kernel IR identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("target-bound Kernel IR identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::bounded("configured target", MAX_TARGET_TEXT_BYTES_V3),
    FieldSchemaV3::bounded("rustc LLVM target", MAX_TARGET_TEXT_BYTES_V3),
    FieldSchemaV3::bounded("target CPU", MAX_TARGET_TEXT_BYTES_V3),
    FieldSchemaV3::bounded("target features", MAX_TARGET_FEATURES_BYTES_V3),
    FieldSchemaV3::exact("code object version", 2),
    FieldSchemaV3::exact("wave width", 2),
    FieldSchemaV3::exact("default workgroup", 12),
];

const DATA_LAYOUT_FIELDS_V3: &[FieldSchemaV3] = &[
    FieldSchemaV3::exact("domain", DATA_LAYOUT_DOMAIN_V3.len()),
    FieldSchemaV3::exact("claim", ASSOCIATION_ONLY_CLAIM_V3.len()),
    FieldSchemaV3::exact("semantic MIR identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("target binding identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("semantic layout identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::bounded("rustc LLVM target", MAX_TARGET_TEXT_BYTES_V3),
    FieldSchemaV3::bounded("live rustc data layout", MAX_DATA_LAYOUT_BYTES_V3),
    FieldSchemaV3::bounded("final LLVM target", MAX_TARGET_TEXT_BYTES_V3),
    FieldSchemaV3::bounded("final LLVM data layout", MAX_DATA_LAYOUT_BYTES_V3),
    FieldSchemaV3::exact("default pointer width", 2),
];

const SEMANTIC_TO_LLVM_FIELDS_V3: &[FieldSchemaV3] = &[
    FieldSchemaV3::exact("domain", SEMANTIC_TO_LLVM_DOMAIN_V3.len()),
    FieldSchemaV3::exact("claim", ASSOCIATION_ONLY_CLAIM_V3.len()),
    FieldSchemaV3::exact("semantic MIR identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("middle-end identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("Kernel IR identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("MIR-to-KIR correspondence identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("formal memory identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("proof binding identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("target binding identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("data layout identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("ABI identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("export manifest identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("AMDGPU lowering identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact("final LLVM identity", IDENTITY_BYTES_V3),
    FieldSchemaV3::exact(
        "final compiler module commitment identity",
        IDENTITY_BYTES_V3,
    ),
];

const TARGET_BINDING_SCHEMA_V3: RecordSchemaV3 = RecordSchemaV3 {
    name: "target binding transcript",
    kind: TARGET_BINDING_KIND_V3,
    policy: ASSOCIATION_ONLY_NO_REFINEMENT_PROOF_POLICY_V3,
    domain: TARGET_BINDING_DOMAIN_V3,
    fields: TARGET_BINDING_FIELDS_V3,
};
const DATA_LAYOUT_SCHEMA_V3: RecordSchemaV3 = RecordSchemaV3 {
    name: "data layout transcript",
    kind: DATA_LAYOUT_KIND_V3,
    policy: ASSOCIATION_ONLY_NO_REFINEMENT_PROOF_POLICY_V3,
    domain: DATA_LAYOUT_DOMAIN_V3,
    fields: DATA_LAYOUT_FIELDS_V3,
};
const SEMANTIC_TO_LLVM_SCHEMA_V3: RecordSchemaV3 = RecordSchemaV3 {
    name: "semantic-to-LLVM association",
    kind: SEMANTIC_TO_LLVM_KIND_V3,
    policy: ASSOCIATION_ONLY_NO_REFINEMENT_PROOF_POLICY_V3,
    domain: SEMANTIC_TO_LLVM_DOMAIN_V3,
    fields: SEMANTIC_TO_LLVM_FIELDS_V3,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct FieldRangeV3 {
    start: u32,
    end: u32,
}

#[derive(Eq, PartialEq)]
struct CanonicalRecordV3 {
    canonical_bytes: Box<[u8]>,
    fields: Box<[FieldRangeV3]>,
}

impl fmt::Debug for CanonicalRecordV3 {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("CanonicalRecordV3")
            .field("byte_len", &self.canonical_bytes.len())
            .finish()
    }
}

impl CanonicalRecordV3 {
    fn build(
        schema: &'static RecordSchemaV3,
        fields: &[&[u8]],
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        validate_field_count(schema, fields.len())?;
        validate_fields(schema, fields)?;
        let total_len = preflight_encoded_len(schema, fields)?;
        let total_len_u32 =
            u32::try_from(total_len).map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
        let field_count = u16::try_from(fields.len())
            .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;

        let mut canonical_bytes = Vec::new();
        canonical_bytes
            .try_reserve_exact(total_len)
            .map_err(|_| ProductionTargetLineageErrorV3::AllocationFailed)?;
        canonical_bytes.extend_from_slice(&TRANSCRIPT_MAGIC_V3);
        canonical_bytes.extend_from_slice(&TRANSCRIPT_VERSION_V3.to_le_bytes());
        canonical_bytes.extend_from_slice(&schema.kind.to_le_bytes());
        canonical_bytes.extend_from_slice(&schema.policy.to_le_bytes());
        canonical_bytes.extend_from_slice(&field_count.to_le_bytes());
        canonical_bytes.extend_from_slice(&total_len_u32.to_le_bytes());
        canonical_bytes.extend_from_slice(&0_u32.to_le_bytes());

        let mut ranges = Vec::new();
        ranges
            .try_reserve_exact(fields.len())
            .map_err(|_| ProductionTargetLineageErrorV3::AllocationFailed)?;
        for (index, field) in fields.iter().enumerate() {
            let tag = u16::try_from(index + 1)
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
            let field_len = u32::try_from(field.len())
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
            canonical_bytes.extend_from_slice(&tag.to_le_bytes());
            canonical_bytes.extend_from_slice(&0_u16.to_le_bytes());
            canonical_bytes.extend_from_slice(&field_len.to_le_bytes());
            let start = u32::try_from(canonical_bytes.len())
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
            canonical_bytes.extend_from_slice(field);
            let end = u32::try_from(canonical_bytes.len())
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
            ranges.push(FieldRangeV3 { start, end });
        }
        debug_assert_eq!(canonical_bytes.len(), total_len);
        Ok(Self {
            canonical_bytes: canonical_bytes.into_boxed_slice(),
            fields: ranges.into_boxed_slice(),
        })
    }

    fn decode(
        schema: &'static RecordSchemaV3,
        bytes: &[u8],
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        let parsed = ParsedRecordV3::parse(schema, bytes)?;
        validate_fields(schema, &parsed.field_slices())?;
        parsed.into_owned()
    }

    fn canonical_bytes(&self) -> &[u8] {
        &self.canonical_bytes
    }

    fn field(&self, index: usize) -> &[u8] {
        let range = self.fields[index];
        &self.canonical_bytes[range.start as usize..range.end as usize]
    }
}

struct ParsedRecordV3<'a> {
    bytes: &'a [u8],
    ranges: Vec<FieldRangeV3>,
}

impl<'a> ParsedRecordV3<'a> {
    fn parse(
        schema: &'static RecordSchemaV3,
        bytes: &'a [u8],
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        if bytes.len() > MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3 {
            return Err(ProductionTargetLineageErrorV3::TranscriptTooLarge {
                actual: bytes.len(),
                max: MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3,
            });
        }
        if bytes.len() < TRANSCRIPT_HEADER_BYTES_V3 {
            return Err(ProductionTargetLineageErrorV3::Truncated);
        }
        if bytes[..8] != TRANSCRIPT_MAGIC_V3 {
            return Err(ProductionTargetLineageErrorV3::InvalidMagic);
        }
        let version = read_u16(bytes, 8)?;
        if version != TRANSCRIPT_VERSION_V3 {
            return Err(ProductionTargetLineageErrorV3::UnsupportedVersion { observed: version });
        }
        let kind = read_u16(bytes, 10)?;
        if kind != schema.kind {
            return Err(ProductionTargetLineageErrorV3::WrongRecordKind {
                expected: schema.kind,
                observed: kind,
            });
        }
        let policy = read_u16(bytes, 12)?;
        if policy != schema.policy {
            return Err(ProductionTargetLineageErrorV3::WrongPolicy {
                expected: schema.policy,
                observed: policy,
            });
        }
        let field_count = usize::from(read_u16(bytes, 14)?);
        validate_field_count(schema, field_count)?;
        let declared_len = usize::try_from(read_u32(bytes, 16)?)
            .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
        if declared_len != bytes.len() {
            return Err(ProductionTargetLineageErrorV3::DeclaredLengthMismatch {
                declared: declared_len,
                actual: bytes.len(),
            });
        }
        if read_u32(bytes, 20)? != 0 {
            return Err(ProductionTargetLineageErrorV3::NonZeroReserved);
        }

        let minimum_len = TRANSCRIPT_HEADER_BYTES_V3
            .checked_add(
                field_count
                    .checked_mul(FIELD_HEADER_BYTES_V3)
                    .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?,
            )
            .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
        if declared_len < minimum_len {
            return Err(ProductionTargetLineageErrorV3::Truncated);
        }

        let mut offset = TRANSCRIPT_HEADER_BYTES_V3;
        let mut ranges = Vec::new();
        ranges
            .try_reserve_exact(field_count)
            .map_err(|_| ProductionTargetLineageErrorV3::AllocationFailed)?;
        for (index, field_schema) in schema.fields.iter().enumerate() {
            let expected_tag = u16::try_from(index + 1)
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
            let tag = read_u16(bytes, offset)?;
            if tag != expected_tag {
                return Err(ProductionTargetLineageErrorV3::WrongFieldTag {
                    field: field_schema.name,
                    expected: expected_tag,
                    observed: tag,
                });
            }
            if read_u16(bytes, offset + 2)? != 0 {
                return Err(ProductionTargetLineageErrorV3::NonZeroFieldFlags {
                    field: field_schema.name,
                });
            }
            let field_len = usize::try_from(read_u32(bytes, offset + 4)?)
                .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?;
            validate_field_len(field_schema, field_len)?;
            let start = offset
                .checked_add(FIELD_HEADER_BYTES_V3)
                .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
            let end = start
                .checked_add(field_len)
                .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
            if end > bytes.len() {
                return Err(ProductionTargetLineageErrorV3::Truncated);
            }
            ranges.push(FieldRangeV3 {
                start: u32::try_from(start)
                    .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?,
                end: u32::try_from(end)
                    .map_err(|_| ProductionTargetLineageErrorV3::LengthOverflow)?,
            });
            offset = end;
        }
        if offset != bytes.len() {
            return Err(ProductionTargetLineageErrorV3::TrailingBytes {
                trailing: bytes.len() - offset,
            });
        }
        Ok(Self { bytes, ranges })
    }

    fn field_slices(&self) -> Vec<&[u8]> {
        self.ranges
            .iter()
            .map(|range| &self.bytes[range.start as usize..range.end as usize])
            .collect()
    }

    fn into_owned(self) -> Result<CanonicalRecordV3, ProductionTargetLineageErrorV3> {
        let mut canonical_bytes = Vec::new();
        canonical_bytes
            .try_reserve_exact(self.bytes.len())
            .map_err(|_| ProductionTargetLineageErrorV3::AllocationFailed)?;
        canonical_bytes.extend_from_slice(self.bytes);
        Ok(CanonicalRecordV3 {
            canonical_bytes: canonical_bytes.into_boxed_slice(),
            fields: self.ranges.into_boxed_slice(),
        })
    }
}

fn validate_field_count(
    schema: &RecordSchemaV3,
    actual: usize,
) -> Result<(), ProductionTargetLineageErrorV3> {
    if actual == schema.fields.len() {
        Ok(())
    } else {
        Err(ProductionTargetLineageErrorV3::WrongFieldCount {
            record: schema.name,
            expected: schema.fields.len(),
            observed: actual,
        })
    }
}

fn validate_fields(
    schema: &RecordSchemaV3,
    fields: &[&[u8]],
) -> Result<(), ProductionTargetLineageErrorV3> {
    validate_field_count(schema, fields.len())?;
    for (field_schema, field) in schema.fields.iter().zip(fields) {
        validate_field_len(field_schema, field.len())?;
    }
    if fields[0] != schema.domain {
        return Err(ProductionTargetLineageErrorV3::WrongDomain {
            record: schema.name,
        });
    }
    if fields[1] != ASSOCIATION_ONLY_CLAIM_V3 {
        return Err(ProductionTargetLineageErrorV3::WrongClaim {
            record: schema.name,
        });
    }
    Ok(())
}

fn validate_field_len(
    schema: &FieldSchemaV3,
    actual: usize,
) -> Result<(), ProductionTargetLineageErrorV3> {
    if actual == 0 {
        return Err(ProductionTargetLineageErrorV3::EmptyField { field: schema.name });
    }
    if actual > schema.max_bytes {
        return Err(ProductionTargetLineageErrorV3::FieldTooLarge {
            field: schema.name,
            actual,
            max: schema.max_bytes,
        });
    }
    if let Some(expected) = schema.exact_bytes
        && actual != expected
    {
        return Err(ProductionTargetLineageErrorV3::InvalidFieldLength {
            field: schema.name,
            actual,
            expected,
        });
    }
    Ok(())
}

fn preflight_encoded_len(
    schema: &RecordSchemaV3,
    fields: &[&[u8]],
) -> Result<usize, ProductionTargetLineageErrorV3> {
    let field_headers = FIELD_HEADER_BYTES_V3
        .checked_mul(schema.fields.len())
        .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
    let mut total = TRANSCRIPT_HEADER_BYTES_V3
        .checked_add(field_headers)
        .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
    for field in fields {
        total = total
            .checked_add(field.len())
            .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
    }
    if total > MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3 {
        return Err(ProductionTargetLineageErrorV3::TranscriptTooLarge {
            actual: total,
            max: MAX_PRODUCTION_TARGET_LINEAGE_TRANSCRIPT_BYTES_V3,
        });
    }
    Ok(total)
}

fn read_u16(bytes: &[u8], offset: usize) -> Result<u16, ProductionTargetLineageErrorV3> {
    let end = offset
        .checked_add(2)
        .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
    let encoded = bytes
        .get(offset..end)
        .ok_or(ProductionTargetLineageErrorV3::Truncated)?;
    Ok(u16::from_le_bytes([encoded[0], encoded[1]]))
}

fn read_u32(bytes: &[u8], offset: usize) -> Result<u32, ProductionTargetLineageErrorV3> {
    let end = offset
        .checked_add(4)
        .ok_or(ProductionTargetLineageErrorV3::LengthOverflow)?;
    let encoded = bytes
        .get(offset..end)
        .ok_or(ProductionTargetLineageErrorV3::Truncated)?;
    Ok(u32::from_le_bytes([
        encoded[0], encoded[1], encoded[2], encoded[3],
    ]))
}

fn decode_u16(field: &'static str, bytes: &[u8]) -> Result<u16, ProductionTargetLineageErrorV3> {
    if bytes.len() != 2 {
        return Err(ProductionTargetLineageErrorV3::InvalidFieldLength {
            field,
            actual: bytes.len(),
            expected: 2,
        });
    }
    Ok(u16::from_le_bytes([bytes[0], bytes[1]]))
}

fn validate_identity(
    field: &'static str,
    sha256: [u8; 32],
    byte_len: u64,
) -> Result<(), ProductionTargetLineageErrorV3> {
    if sha256 == [0; 32] {
        return Err(ProductionTargetLineageErrorV3::ZeroIdentity { field });
    }
    if byte_len == 0 {
        return Err(ProductionTargetLineageErrorV3::ZeroIdentityLength { field });
    }
    Ok(())
}

fn validate_ascii_token<'a>(
    field: &'static str,
    bytes: &'a [u8],
) -> Result<&'a str, ProductionTargetLineageErrorV3> {
    let text =
        str::from_utf8(bytes).map_err(|_| ProductionTargetLineageErrorV3::InvalidText { field })?;
    if text.is_empty()
        || !text.is_ascii()
        || text
            .bytes()
            .any(|byte| byte.is_ascii_whitespace() || byte.is_ascii_control())
    {
        return Err(ProductionTargetLineageErrorV3::InvalidText { field });
    }
    Ok(text)
}

fn require_exact_text(
    field: &'static str,
    observed: &str,
    expected: &'static str,
) -> Result<(), ProductionTargetLineageErrorV3> {
    if observed == expected {
        Ok(())
    } else {
        Err(ProductionTargetLineageErrorV3::ExactValueMismatch { field })
    }
}

#[derive(Clone, Copy, Debug)]
/// Borrowed exact inputs for a singleton target-binding transcript.
#[allow(missing_docs)]
pub struct TargetBindingTranscriptInputsV3<'a> {
    pub protected_rustc_invocation: TargetLineageIdentityV3,
    pub semantic_mir: TargetLineageIdentityV3,
    pub target_neutral_kir: TargetLineageIdentityV3,
    pub target_bound_kir: TargetLineageIdentityV3,
    pub configured_target: &'a str,
    pub rustc_llvm_target: &'a str,
    pub target_cpu: &'a str,
    pub target_features: &'a str,
    pub code_object_version: u16,
    pub wave_width_bits: u16,
    pub default_workgroup: [u32; 3],
}

#[derive(Debug, Eq, PartialEq)]
/// Canonical singleton target-binding association transcript.
pub struct TargetBindingTranscriptV3 {
    record: CanonicalRecordV3,
}

impl TargetBindingTranscriptV3 {
    /// Builds and validates a canonical target-binding transcript.
    pub fn new(
        inputs: TargetBindingTranscriptInputsV3<'_>,
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        validate_target_binding_inputs_v3(&inputs)?;

        let invocation = inputs.protected_rustc_invocation.encode();
        let semantic_mir = inputs.semantic_mir.encode();
        let neutral_kir = inputs.target_neutral_kir.encode();
        let bound_kir = inputs.target_bound_kir.encode();
        let code_object_version = inputs.code_object_version.to_le_bytes();
        let wave_width_bits = inputs.wave_width_bits.to_le_bytes();
        let mut default_workgroup = [0_u8; 12];
        for (index, dimension) in inputs.default_workgroup.iter().enumerate() {
            let start = index * 4;
            default_workgroup[start..start + 4].copy_from_slice(&dimension.to_le_bytes());
        }
        let fields: [&[u8]; 13] = [
            TARGET_BINDING_DOMAIN_V3,
            ASSOCIATION_ONLY_CLAIM_V3,
            &invocation,
            &semantic_mir,
            &neutral_kir,
            &bound_kir,
            inputs.configured_target.as_bytes(),
            inputs.rustc_llvm_target.as_bytes(),
            inputs.target_cpu.as_bytes(),
            inputs.target_features.as_bytes(),
            &code_object_version,
            &wave_width_bits,
            &default_workgroup,
        ];
        Ok(Self {
            record: CanonicalRecordV3::build(&TARGET_BINDING_SCHEMA_V3, &fields)?,
        })
    }

    /// Strictly decodes and revalidates a canonical target-binding transcript.
    pub fn decode(bytes: &[u8]) -> Result<Self, ProductionTargetLineageErrorV3> {
        let record = CanonicalRecordV3::decode(&TARGET_BINDING_SCHEMA_V3, bytes)?;
        let value = Self { record };
        validate_target_binding_inputs_v3(&value.inputs()?)?;
        Ok(value)
    }

    /// Returns the exact canonical transcript bytes.
    pub fn canonical_bytes(&self) -> &[u8] {
        self.record.canonical_bytes()
    }

    /// Returns the deliberately limited semantic claim carried by this record.
    pub const fn claim(&self) -> TargetLineageClaimV3 {
        TargetLineageClaimV3::AssociationOnlyNoRefinementProof
    }

    /// Reports that this association transcript is not a refinement proof.
    pub const fn establishes_refinement_proof(&self) -> bool {
        false
    }

    /// Returns all strictly decoded transcript inputs.
    pub fn inputs(
        &self,
    ) -> Result<TargetBindingTranscriptInputsV3<'_>, ProductionTargetLineageErrorV3> {
        let mut default_workgroup = [0_u32; 3];
        for (index, dimension) in default_workgroup.iter_mut().enumerate() {
            let start = index * 4;
            let bytes = &self.record.field(12)[start..start + 4];
            *dimension = u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]);
        }
        Ok(TargetBindingTranscriptInputsV3 {
            protected_rustc_invocation: TargetLineageIdentityV3::decode(
                "protected rustc invocation identity",
                self.record.field(2),
            )?,
            semantic_mir: TargetLineageIdentityV3::decode(
                "semantic MIR identity",
                self.record.field(3),
            )?,
            target_neutral_kir: TargetLineageIdentityV3::decode(
                "target-neutral Kernel IR identity",
                self.record.field(4),
            )?,
            target_bound_kir: TargetLineageIdentityV3::decode(
                "target-bound Kernel IR identity",
                self.record.field(5),
            )?,
            configured_target: validate_ascii_token("configured target", self.record.field(6))?,
            rustc_llvm_target: validate_ascii_token("rustc LLVM target", self.record.field(7))?,
            target_cpu: validate_ascii_token("target CPU", self.record.field(8))?,
            target_features: validate_ascii_token("target features", self.record.field(9))?,
            code_object_version: decode_u16("code object version", self.record.field(10))?,
            wave_width_bits: decode_u16("wave width", self.record.field(11))?,
            default_workgroup,
        })
    }
}

fn validate_target_binding_inputs_v3(
    inputs: &TargetBindingTranscriptInputsV3<'_>,
) -> Result<(), ProductionTargetLineageErrorV3> {
    let configured_target =
        validate_ascii_token("configured target", inputs.configured_target.as_bytes())?;
    require_exact_text(
        "rustc LLVM target",
        validate_ascii_token("rustc LLVM target", inputs.rustc_llvm_target.as_bytes())?,
        EXACT_RUSTC_LLVM_TARGET_V3,
    )?;
    let target_cpu = validate_ascii_token("target CPU", inputs.target_cpu.as_bytes())?;
    if !matches!(
        (configured_target, target_cpu),
        (EXACT_GFX942_TARGET_V3, EXACT_GFX942_CPU_V3)
            | (EXACT_GFX950_TARGET_V3, EXACT_GFX950_CPU_V3)
    ) {
        return Err(ProductionTargetLineageErrorV3::ExactValueMismatch {
            field: "configured target and target CPU",
        });
    }
    require_exact_text(
        "target features",
        validate_ascii_token("target features", inputs.target_features.as_bytes())?,
        EXACT_GFX942_FEATURES_V3,
    )?;
    if inputs.code_object_version != EXACT_CODE_OBJECT_VERSION_V3 {
        return Err(ProductionTargetLineageErrorV3::InvalidInteger {
            field: "code object version",
            observed: u64::from(inputs.code_object_version),
        });
    }
    if inputs.wave_width_bits != EXACT_WAVE_WIDTH_BITS_V3 {
        return Err(ProductionTargetLineageErrorV3::InvalidInteger {
            field: "wave width",
            observed: u64::from(inputs.wave_width_bits),
        });
    }
    if inputs.default_workgroup.contains(&0) {
        return Err(ProductionTargetLineageErrorV3::InvalidInteger {
            field: "default workgroup",
            observed: 0,
        });
    }
    if inputs.target_neutral_kir == inputs.target_bound_kir {
        return Err(ProductionTargetLineageErrorV3::AssociationInvariant {
            detail: "target-neutral and target-bound Kernel IR identities must differ",
        });
    }
    Ok(())
}

#[derive(Clone, Copy, Debug)]
/// Borrowed exact inputs for a production AMDHSA data-layout transcript.
#[allow(missing_docs)]
pub struct DataLayoutTranscriptInputsV3<'a> {
    pub semantic_mir: TargetLineageIdentityV3,
    pub target_binding: TargetLineageIdentityV3,
    pub semantic_layout: TargetLineageIdentityV3,
    pub rustc_llvm_target: &'a str,
    pub live_rustc_data_layout: &'a str,
    pub final_llvm_target: &'a str,
    pub final_llvm_data_layout: &'a str,
    pub default_pointer_width_bits: u16,
}

#[derive(Debug, Eq, PartialEq)]
/// Canonical production AMDHSA data-layout association transcript.
pub struct DataLayoutTranscriptV3 {
    record: CanonicalRecordV3,
}

impl DataLayoutTranscriptV3 {
    /// Builds and validates a canonical data-layout transcript.
    pub fn new(
        inputs: DataLayoutTranscriptInputsV3<'_>,
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        validate_data_layout_inputs_v3(&inputs)?;

        let semantic_mir = inputs.semantic_mir.encode();
        let target_binding = inputs.target_binding.encode();
        let semantic_layout = inputs.semantic_layout.encode();
        let pointer_width = inputs.default_pointer_width_bits.to_le_bytes();
        let fields: [&[u8]; 10] = [
            DATA_LAYOUT_DOMAIN_V3,
            ASSOCIATION_ONLY_CLAIM_V3,
            &semantic_mir,
            &target_binding,
            &semantic_layout,
            inputs.rustc_llvm_target.as_bytes(),
            inputs.live_rustc_data_layout.as_bytes(),
            inputs.final_llvm_target.as_bytes(),
            inputs.final_llvm_data_layout.as_bytes(),
            &pointer_width,
        ];
        Ok(Self {
            record: CanonicalRecordV3::build(&DATA_LAYOUT_SCHEMA_V3, &fields)?,
        })
    }

    /// Strictly decodes and revalidates a canonical data-layout transcript.
    pub fn decode(bytes: &[u8]) -> Result<Self, ProductionTargetLineageErrorV3> {
        let record = CanonicalRecordV3::decode(&DATA_LAYOUT_SCHEMA_V3, bytes)?;
        let value = Self { record };
        validate_data_layout_inputs_v3(&value.inputs()?)?;
        Ok(value)
    }

    /// Returns the exact canonical transcript bytes.
    pub fn canonical_bytes(&self) -> &[u8] {
        self.record.canonical_bytes()
    }

    /// Returns the deliberately limited semantic claim carried by this record.
    pub const fn claim(&self) -> TargetLineageClaimV3 {
        TargetLineageClaimV3::AssociationOnlyNoRefinementProof
    }

    /// Reports that this association transcript is not a refinement proof.
    pub const fn establishes_refinement_proof(&self) -> bool {
        false
    }

    /// Returns all strictly decoded transcript inputs.
    pub fn inputs(
        &self,
    ) -> Result<DataLayoutTranscriptInputsV3<'_>, ProductionTargetLineageErrorV3> {
        Ok(DataLayoutTranscriptInputsV3 {
            semantic_mir: TargetLineageIdentityV3::decode(
                "semantic MIR identity",
                self.record.field(2),
            )?,
            target_binding: TargetLineageIdentityV3::decode(
                "target binding identity",
                self.record.field(3),
            )?,
            semantic_layout: TargetLineageIdentityV3::decode(
                "semantic layout identity",
                self.record.field(4),
            )?,
            rustc_llvm_target: validate_ascii_token("rustc LLVM target", self.record.field(5))?,
            live_rustc_data_layout: validate_ascii_token(
                "live rustc data layout",
                self.record.field(6),
            )?,
            final_llvm_target: validate_ascii_token("final LLVM target", self.record.field(7))?,
            final_llvm_data_layout: validate_ascii_token(
                "final LLVM data layout",
                self.record.field(8),
            )?,
            default_pointer_width_bits: decode_u16("default pointer width", self.record.field(9))?,
        })
    }
}

fn validate_data_layout_inputs_v3(
    inputs: &DataLayoutTranscriptInputsV3<'_>,
) -> Result<(), ProductionTargetLineageErrorV3> {
    let rustc_target =
        validate_ascii_token("rustc LLVM target", inputs.rustc_llvm_target.as_bytes())?;
    let final_target =
        validate_ascii_token("final LLVM target", inputs.final_llvm_target.as_bytes())?;
    require_exact_text(
        "rustc LLVM target",
        rustc_target,
        EXACT_RUSTC_LLVM_TARGET_V3,
    )?;
    if rustc_target != final_target {
        return Err(ProductionTargetLineageErrorV3::AssociationInvariant {
            detail: "live rustc and final LLVM target strings must be byte-identical",
        });
    }
    let live_layout = validate_ascii_token(
        "live rustc data layout",
        inputs.live_rustc_data_layout.as_bytes(),
    )?;
    let final_layout = validate_ascii_token(
        "final LLVM data layout",
        inputs.final_llvm_data_layout.as_bytes(),
    )?;
    require_exact_text(
        "live rustc data layout",
        live_layout,
        PRODUCTION_AMDHSA_RUSTC_DATA_LAYOUT_V1,
    )?;
    if final_layout != PRODUCTION_AMDHSA_RUSTC_DATA_LAYOUT_V1
        && final_layout != PRODUCTION_AMDHSA_LLVM22_WORKER_DATA_LAYOUT_V1
    {
        return Err(ProductionTargetLineageErrorV3::InvalidText {
            field: "final LLVM data layout",
        });
    }
    if inputs.default_pointer_width_bits != 64 {
        return Err(ProductionTargetLineageErrorV3::InvalidInteger {
            field: "default pointer width",
            observed: u64::from(inputs.default_pointer_width_bits),
        });
    }
    Ok(())
}

#[derive(Clone, Copy, Debug)]
/// Exact receipt and LLVM identities in a semantic-to-LLVM association.
#[allow(missing_docs)]
pub struct SemanticToLlvmAssociationInputsV3 {
    pub semantic_mir: TargetLineageIdentityV3,
    pub middle_end: TargetLineageIdentityV3,
    pub kernel_ir: TargetLineageIdentityV3,
    pub mir_to_kir_correspondence: TargetLineageIdentityV3,
    pub formal_memory: TargetLineageIdentityV3,
    pub proof_binding: TargetLineageIdentityV3,
    pub target_binding: TargetLineageIdentityV3,
    pub data_layout: TargetLineageIdentityV3,
    pub abi: TargetLineageIdentityV3,
    pub export_manifest: TargetLineageIdentityV3,
    pub amdgpu_lowering: TargetLineageIdentityV3,
    pub final_llvm: TargetLineageIdentityV3,
    pub final_compiler_module_commitment: TargetLineageIdentityV3,
}

#[derive(Debug, Eq, PartialEq)]
/// Canonical association between semantic receipts and one final LLVM module.
pub struct SemanticToLlvmAssociationTranscriptV3 {
    record: CanonicalRecordV3,
}

impl SemanticToLlvmAssociationTranscriptV3 {
    /// Builds a canonical semantic-to-LLVM association transcript.
    pub fn new(
        inputs: SemanticToLlvmAssociationInputsV3,
    ) -> Result<Self, ProductionTargetLineageErrorV3> {
        let identities = [
            inputs.semantic_mir.encode(),
            inputs.middle_end.encode(),
            inputs.kernel_ir.encode(),
            inputs.mir_to_kir_correspondence.encode(),
            inputs.formal_memory.encode(),
            inputs.proof_binding.encode(),
            inputs.target_binding.encode(),
            inputs.data_layout.encode(),
            inputs.abi.encode(),
            inputs.export_manifest.encode(),
            inputs.amdgpu_lowering.encode(),
            inputs.final_llvm.encode(),
            inputs.final_compiler_module_commitment.encode(),
        ];
        let fields: [&[u8]; 15] = [
            SEMANTIC_TO_LLVM_DOMAIN_V3,
            ASSOCIATION_ONLY_CLAIM_V3,
            &identities[0],
            &identities[1],
            &identities[2],
            &identities[3],
            &identities[4],
            &identities[5],
            &identities[6],
            &identities[7],
            &identities[8],
            &identities[9],
            &identities[10],
            &identities[11],
            &identities[12],
        ];
        Ok(Self {
            record: CanonicalRecordV3::build(&SEMANTIC_TO_LLVM_SCHEMA_V3, &fields)?,
        })
    }

    /// Strictly decodes a canonical semantic-to-LLVM association transcript.
    pub fn decode(bytes: &[u8]) -> Result<Self, ProductionTargetLineageErrorV3> {
        let record = CanonicalRecordV3::decode(&SEMANTIC_TO_LLVM_SCHEMA_V3, bytes)?;
        let value = Self { record };
        let _ = value.inputs()?;
        Ok(value)
    }

    /// Returns the exact canonical transcript bytes.
    pub fn canonical_bytes(&self) -> &[u8] {
        self.record.canonical_bytes()
    }

    /// Returns the deliberately limited semantic claim carried by this record.
    pub const fn claim(&self) -> TargetLineageClaimV3 {
        TargetLineageClaimV3::AssociationOnlyNoRefinementProof
    }

    /// Reports that this association transcript is not a refinement proof.
    pub const fn establishes_refinement_proof(&self) -> bool {
        false
    }

    /// Reports that this inert transcript does not authenticate its producer.
    pub const fn authenticates_producer(&self) -> bool {
        false
    }

    /// Reports that this inert transcript grants no publication authority.
    pub const fn grants_publication_authority(&self) -> bool {
        false
    }

    /// Returns all strictly decoded association inputs.
    pub fn inputs(
        &self,
    ) -> Result<SemanticToLlvmAssociationInputsV3, ProductionTargetLineageErrorV3> {
        Ok(SemanticToLlvmAssociationInputsV3 {
            semantic_mir: self.identity_field(2, "semantic MIR identity")?,
            middle_end: self.identity_field(3, "middle-end identity")?,
            kernel_ir: self.identity_field(4, "Kernel IR identity")?,
            mir_to_kir_correspondence: self
                .identity_field(5, "MIR-to-KIR correspondence identity")?,
            formal_memory: self.identity_field(6, "formal memory identity")?,
            proof_binding: self.identity_field(7, "proof binding identity")?,
            target_binding: self.identity_field(8, "target binding identity")?,
            data_layout: self.identity_field(9, "data layout identity")?,
            abi: self.identity_field(10, "ABI identity")?,
            export_manifest: self.identity_field(11, "export manifest identity")?,
            amdgpu_lowering: self.identity_field(12, "AMDGPU lowering identity")?,
            final_llvm: self.identity_field(13, "final LLVM identity")?,
            final_compiler_module_commitment: self
                .identity_field(14, "final compiler module commitment identity")?,
        })
    }

    fn identity_field(
        &self,
        index: usize,
        field: &'static str,
    ) -> Result<TargetLineageIdentityV3, ProductionTargetLineageErrorV3> {
        TargetLineageIdentityV3::decode(field, self.record.field(index))
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
#[non_exhaustive]
/// Failure while constructing or strictly decoding production target lineage.
#[allow(missing_docs)]
pub enum ProductionTargetLineageErrorV3 {
    AllocationFailed,
    AssociationInvariant {
        detail: &'static str,
    },
    DeclaredLengthMismatch {
        declared: usize,
        actual: usize,
    },
    EmptyField {
        field: &'static str,
    },
    ExactValueMismatch {
        field: &'static str,
    },
    FieldTooLarge {
        field: &'static str,
        actual: usize,
        max: usize,
    },
    InvalidFieldLength {
        field: &'static str,
        actual: usize,
        expected: usize,
    },
    InvalidInteger {
        field: &'static str,
        observed: u64,
    },
    InvalidMagic,
    InvalidText {
        field: &'static str,
    },
    LengthOverflow,
    NonZeroFieldFlags {
        field: &'static str,
    },
    NonZeroReserved,
    TrailingBytes {
        trailing: usize,
    },
    TranscriptTooLarge {
        actual: usize,
        max: usize,
    },
    Truncated,
    UnsupportedVersion {
        observed: u16,
    },
    WrongClaim {
        record: &'static str,
    },
    WrongDomain {
        record: &'static str,
    },
    WrongFieldCount {
        record: &'static str,
        expected: usize,
        observed: usize,
    },
    WrongFieldTag {
        field: &'static str,
        expected: u16,
        observed: u16,
    },
    WrongPolicy {
        expected: u16,
        observed: u16,
    },
    WrongRecordKind {
        expected: u16,
        observed: u16,
    },
    ZeroIdentity {
        field: &'static str,
    },
    ZeroIdentityLength {
        field: &'static str,
    },
}

impl fmt::Display for ProductionTargetLineageErrorV3 {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::AllocationFailed => formatter.write_str("target lineage allocation failed"),
            Self::AssociationInvariant { detail } => {
                write!(formatter, "target lineage association failed: {detail}")
            }
            Self::DeclaredLengthMismatch { declared, actual } => write!(
                formatter,
                "target lineage declared {declared} bytes but received {actual}"
            ),
            Self::EmptyField { field } => write!(formatter, "target lineage {field} is empty"),
            Self::ExactValueMismatch { field } => {
                write!(
                    formatter,
                    "target lineage {field} is not the production V3 value"
                )
            }
            Self::FieldTooLarge { field, actual, max } => write!(
                formatter,
                "target lineage {field} has {actual} bytes; maximum is {max}"
            ),
            Self::InvalidFieldLength {
                field,
                actual,
                expected,
            } => write!(
                formatter,
                "target lineage {field} has {actual} bytes; expected exactly {expected}"
            ),
            Self::InvalidInteger { field, observed } => {
                write!(
                    formatter,
                    "target lineage {field} has invalid value {observed}"
                )
            }
            Self::InvalidMagic => formatter.write_str("invalid target lineage magic"),
            Self::InvalidText { field } => {
                write!(formatter, "target lineage {field} is not canonical text")
            }
            Self::LengthOverflow => formatter.write_str("target lineage length overflow"),
            Self::NonZeroFieldFlags { field } => {
                write!(formatter, "target lineage {field} has nonzero field flags")
            }
            Self::NonZeroReserved => {
                formatter.write_str("target lineage header has nonzero reserved bytes")
            }
            Self::TrailingBytes { trailing } => {
                write!(formatter, "target lineage has {trailing} trailing bytes")
            }
            Self::TranscriptTooLarge { actual, max } => write!(
                formatter,
                "target lineage transcript has {actual} bytes; maximum is {max}"
            ),
            Self::Truncated => formatter.write_str("truncated target lineage transcript"),
            Self::UnsupportedVersion { observed } => {
                write!(formatter, "unsupported target lineage version {observed}")
            }
            Self::WrongClaim { record } => {
                write!(
                    formatter,
                    "{record} does not carry the association-only claim"
                )
            }
            Self::WrongDomain { record } => write!(formatter, "wrong domain for {record}"),
            Self::WrongFieldCount {
                record,
                expected,
                observed,
            } => write!(
                formatter,
                "{record} has {observed} fields; expected {expected}"
            ),
            Self::WrongFieldTag {
                field,
                expected,
                observed,
            } => write!(
                formatter,
                "target lineage {field} has tag {observed}; expected {expected}"
            ),
            Self::WrongPolicy { expected, observed } => write!(
                formatter,
                "target lineage policy {observed} is unsupported; expected {expected}"
            ),
            Self::WrongRecordKind { expected, observed } => write!(
                formatter,
                "target lineage kind {observed} does not match expected kind {expected}"
            ),
            Self::ZeroIdentity { field } => {
                write!(formatter, "target lineage {field} has a zero digest")
            }
            Self::ZeroIdentityLength { field } => {
                write!(formatter, "target lineage {field} has a zero byte length")
            }
        }
    }
}

impl Error for ProductionTargetLineageErrorV3 {}

#[cfg(test)]
mod tests {
    use super::*;

    type DecoderV3 = fn(&[u8]) -> bool;

    const DATA_LAYOUT: &str = PRODUCTION_AMDHSA_RUSTC_DATA_LAYOUT_V1;
    const WORKER_DATA_LAYOUT: &str = PRODUCTION_AMDHSA_LLVM22_WORKER_DATA_LAYOUT_V1;

    fn identity(seed: u8) -> TargetLineageIdentityV3 {
        TargetLineageIdentityV3::new([seed; 32], u64::from(seed) + 1).unwrap()
    }

    fn target_binding() -> TargetBindingTranscriptV3 {
        TargetBindingTranscriptV3::new(TargetBindingTranscriptInputsV3 {
            protected_rustc_invocation: identity(1),
            semantic_mir: identity(2),
            target_neutral_kir: identity(3),
            target_bound_kir: identity(4),
            configured_target: EXACT_GFX942_TARGET_V3,
            rustc_llvm_target: EXACT_RUSTC_LLVM_TARGET_V3,
            target_cpu: EXACT_GFX942_CPU_V3,
            target_features: EXACT_GFX942_FEATURES_V3,
            code_object_version: EXACT_CODE_OBJECT_VERSION_V3,
            wave_width_bits: EXACT_WAVE_WIDTH_BITS_V3,
            default_workgroup: [256, 1, 1],
        })
        .unwrap()
    }

    fn data_layout() -> DataLayoutTranscriptV3 {
        DataLayoutTranscriptV3::new(DataLayoutTranscriptInputsV3 {
            semantic_mir: identity(2),
            target_binding: identity(5),
            semantic_layout: identity(6),
            rustc_llvm_target: EXACT_RUSTC_LLVM_TARGET_V3,
            live_rustc_data_layout: DATA_LAYOUT,
            final_llvm_target: EXACT_RUSTC_LLVM_TARGET_V3,
            final_llvm_data_layout: WORKER_DATA_LAYOUT,
            default_pointer_width_bits: 64,
        })
        .unwrap()
    }

    fn association() -> SemanticToLlvmAssociationTranscriptV3 {
        SemanticToLlvmAssociationTranscriptV3::new(SemanticToLlvmAssociationInputsV3 {
            semantic_mir: identity(2),
            middle_end: identity(3),
            kernel_ir: identity(4),
            mir_to_kir_correspondence: identity(5),
            formal_memory: identity(6),
            proof_binding: identity(7),
            target_binding: identity(8),
            data_layout: identity(9),
            abi: identity(10),
            export_manifest: identity(11),
            amdgpu_lowering: identity(12),
            final_llvm: identity(13),
            final_compiler_module_commitment: identity(14),
        })
        .unwrap()
    }

    #[test]
    fn every_transcript_strictly_round_trips_and_reencodes() {
        let target = target_binding();
        let decoded = TargetBindingTranscriptV3::decode(target.canonical_bytes()).unwrap();
        assert_eq!(decoded.canonical_bytes(), target.canonical_bytes());
        assert_eq!(decoded.inputs().unwrap().default_workgroup, [256, 1, 1]);
        assert_eq!(
            TargetBindingTranscriptV3::new(decoded.inputs().unwrap())
                .unwrap()
                .canonical_bytes(),
            target.canonical_bytes()
        );

        let layout = data_layout();
        let decoded = DataLayoutTranscriptV3::decode(layout.canonical_bytes()).unwrap();
        assert_eq!(decoded.canonical_bytes(), layout.canonical_bytes());
        assert_eq!(
            decoded.inputs().unwrap().final_llvm_data_layout,
            WORKER_DATA_LAYOUT
        );
        assert_eq!(
            DataLayoutTranscriptV3::new(decoded.inputs().unwrap())
                .unwrap()
                .canonical_bytes(),
            layout.canonical_bytes()
        );

        let association = association();
        let decoded =
            SemanticToLlvmAssociationTranscriptV3::decode(association.canonical_bytes()).unwrap();
        assert_eq!(decoded.canonical_bytes(), association.canonical_bytes());
        assert_eq!(decoded.inputs().unwrap().final_llvm, identity(13));
        assert_eq!(
            decoded.inputs().unwrap().final_compiler_module_commitment,
            identity(14)
        );
        assert_eq!(
            SemanticToLlvmAssociationTranscriptV3::new(decoded.inputs().unwrap())
                .unwrap()
                .canonical_bytes(),
            association.canonical_bytes()
        );
    }

    #[test]
    fn all_records_are_explicitly_association_only() {
        let identity = identity(42);
        assert_eq!(identity.sha256(), [42; 32]);
        assert_eq!(identity.byte_len(), 43);
        assert_eq!(
            target_binding().claim(),
            TargetLineageClaimV3::AssociationOnlyNoRefinementProof
        );
        assert!(!target_binding().establishes_refinement_proof());
        let layout = data_layout();
        assert_eq!(
            layout.claim(),
            TargetLineageClaimV3::AssociationOnlyNoRefinementProof
        );
        assert!(!layout.establishes_refinement_proof());
        let association = association();
        assert_eq!(
            association.claim(),
            TargetLineageClaimV3::AssociationOnlyNoRefinementProof
        );
        assert!(!association.establishes_refinement_proof());
        assert!(!association.authenticates_producer());
        assert!(!association.grants_publication_authority());
    }

    #[test]
    fn every_prefix_and_trailing_byte_is_rejected() {
        let target = target_binding();
        let layout = data_layout();
        let association = association();
        let records: Vec<(&[u8], DecoderV3)> = vec![
            (target.canonical_bytes(), |bytes| {
                TargetBindingTranscriptV3::decode(bytes).is_ok()
            }),
            (layout.canonical_bytes(), |bytes| {
                DataLayoutTranscriptV3::decode(bytes).is_ok()
            }),
            (association.canonical_bytes(), |bytes| {
                SemanticToLlvmAssociationTranscriptV3::decode(bytes).is_ok()
            }),
        ];
        for (bytes, decodes) in records {
            for prefix_len in 0..bytes.len() {
                assert!(
                    !decodes(&bytes[..prefix_len]),
                    "accepted prefix {prefix_len}"
                );
            }
            let mut trailing = bytes.to_vec();
            trailing.push(0);
            assert!(!decodes(&trailing));
        }
    }

    #[test]
    fn header_and_field_noncanonical_axes_are_rejected() {
        let canonical = target_binding().canonical_bytes().to_vec();
        for (offset, replacement) in [
            (0, 0_u8),
            (8, 2_u8),
            (10, DATA_LAYOUT_KIND_V3 as u8),
            (12, 2_u8),
            (14, 12_u8),
            (20, 1_u8),
            (TRANSCRIPT_HEADER_BYTES_V3, 2_u8),
            (TRANSCRIPT_HEADER_BYTES_V3 + 2, 1_u8),
        ] {
            let mut hostile = canonical.clone();
            hostile[offset] = replacement;
            assert!(TargetBindingTranscriptV3::decode(&hostile).is_err());
        }
        let mut wrong_domain = canonical.clone();
        wrong_domain[TRANSCRIPT_HEADER_BYTES_V3 + FIELD_HEADER_BYTES_V3] ^= 1;
        assert!(TargetBindingTranscriptV3::decode(&wrong_domain).is_err());
    }

    #[test]
    fn exact_production_target_policy_rejects_substitutions() {
        let base = TargetBindingTranscriptInputsV3 {
            protected_rustc_invocation: identity(1),
            semantic_mir: identity(2),
            target_neutral_kir: identity(3),
            target_bound_kir: identity(4),
            configured_target: EXACT_GFX942_TARGET_V3,
            rustc_llvm_target: EXACT_RUSTC_LLVM_TARGET_V3,
            target_cpu: EXACT_GFX942_CPU_V3,
            target_features: EXACT_GFX942_FEATURES_V3,
            code_object_version: 6,
            wave_width_bits: 64,
            default_workgroup: [256, 1, 1],
        };
        assert!(
            TargetBindingTranscriptV3::new(TargetBindingTranscriptInputsV3 {
                configured_target: "gfx942:xnack+",
                ..base
            })
            .is_err()
        );
        assert!(
            TargetBindingTranscriptV3::new(TargetBindingTranscriptInputsV3 {
                code_object_version: 5,
                ..base
            })
            .is_err()
        );
        assert!(
            TargetBindingTranscriptV3::new(TargetBindingTranscriptInputsV3 {
                target_bound_kir: base.target_neutral_kir,
                ..base
            })
            .is_err()
        );
    }

    #[test]
    fn layout_policy_requires_the_exact_rustc_and_worker_contracts() {
        let base = DataLayoutTranscriptInputsV3 {
            semantic_mir: identity(2),
            target_binding: identity(5),
            semantic_layout: identity(6),
            rustc_llvm_target: EXACT_RUSTC_LLVM_TARGET_V3,
            live_rustc_data_layout: DATA_LAYOUT,
            final_llvm_target: EXACT_RUSTC_LLVM_TARGET_V3,
            final_llvm_data_layout: WORKER_DATA_LAYOUT,
            default_pointer_width_bits: 64,
        };
        assert!(
            DataLayoutTranscriptV3::new(DataLayoutTranscriptInputsV3 {
                final_llvm_target: "spirv64-amd-amdhsa",
                ..base
            })
            .is_err()
        );
        assert!(
            DataLayoutTranscriptV3::new(DataLayoutTranscriptInputsV3 {
                final_llvm_data_layout: "e-p:32:32",
                ..base
            })
            .is_err()
        );
        assert!(
            DataLayoutTranscriptV3::new(DataLayoutTranscriptInputsV3 {
                live_rustc_data_layout: WORKER_DATA_LAYOUT,
                ..base
            })
            .is_err()
        );
        let legacy = DataLayoutTranscriptV3::new(DataLayoutTranscriptInputsV3 {
            final_llvm_data_layout: DATA_LAYOUT,
            ..base
        })
        .unwrap();
        assert_eq!(
            legacy.inputs().unwrap().final_llvm_data_layout,
            PRODUCTION_AMDHSA_RUSTC_DATA_LAYOUT_V1
        );
    }

    #[test]
    fn bounds_are_checked_before_record_allocation() {
        let oversized_features = "x".repeat(MAX_TARGET_FEATURES_BYTES_V3 + 1);
        let target = target_binding();
        let mut fields = (0..TARGET_BINDING_FIELDS_V3.len())
            .map(|index| target.record.field(index))
            .collect::<Vec<_>>();
        fields[9] = oversized_features.as_bytes();
        assert!(matches!(
            CanonicalRecordV3::build(&TARGET_BINDING_SCHEMA_V3, &fields),
            Err(ProductionTargetLineageErrorV3::FieldTooLarge {
                field: "target features",
                ..
            })
        ));
    }

    #[test]
    fn identities_reject_zero_digest_and_zero_length() {
        assert!(matches!(
            TargetLineageIdentityV3::new([0; 32], 1),
            Err(ProductionTargetLineageErrorV3::ZeroIdentity { .. })
        ));
        assert!(matches!(
            TargetLineageIdentityV3::new([1; 32], 0),
            Err(ProductionTargetLineageErrorV3::ZeroIdentityLength { .. })
        ));
    }
}
