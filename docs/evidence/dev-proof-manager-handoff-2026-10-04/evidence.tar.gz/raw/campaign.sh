#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-proof-manager-20261004-qmlEtr8G
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
mapfile -t binaries < <(find "$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/deps" -maxdepth 1 -type f -executable -name 'fe2o3_broker_authority_service-*')
[[ ${#binaries[@]} == 1 ]]
readonly binary=${binaries[0]}
file "$binary"
sha256sum "$binary" "$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-proof-manager" > "$scratch/raw/binaries.sha256"
cases=("$@")
if [[ ${#cases[@]} == 0 ]]; then
    cases=(active before-activate coordinator-copy delayed-listener post-connect-removal)
fi
for case_name in "${cases[@]}"; do
    status=0
    timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /usr/bin/env FE2O3_MANAGER_CASE="$case_name" /bin/bash "$scratch/raw/outer.sh" /bin/bash "$scratch/raw/manager-run.sh" "$binary" > "$scratch/raw/$case_name.log" 2>&1 || status=$?
    if [[ -e "$scratch/captures/$case_name/pid-namespace.txt" ]]; then
        /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash "$scratch/raw/check-namespace.sh" "$scratch/captures/$case_name" > "$scratch/raw/$case_name-namespace.log" 2>&1
    fi
    [[ $status == 0 ]] || { tail -n 60 "$scratch/raw/$case_name.log"; exit "$status"; }
    tail -n 12 "$scratch/raw/$case_name.log"
done
cd "$repo"
sha256sum -c "$scratch/raw/binaries.sha256"
