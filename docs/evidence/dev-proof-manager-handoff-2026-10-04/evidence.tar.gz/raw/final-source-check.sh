#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-proof-manager-20261004-qmlEtr8G
readonly base=a71d254767fbd7d3050ce25fae4df37d7726161c
readonly source=21594d8cebbdeeec72f7237222e859fe8dce108e
cd "$repo"
git diff --exit-code "$source" -- crates Cargo.lock deployment scripts docs/runtime-multi-gpu-critical-path.md docs/runtime-proof-manager-v1.md
git diff --check "$base" "$source"
mapfile -t files < <(git diff --diff-filter=AM --name-only "$base" "$source" -- '*.rs')
[[ ${#files[@]} -gt 0 ]]
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check "${files[@]}"
bash scripts/tests/compiler-execution-systemd.sh
bash scripts/tests/proof-manager-systemd.sh
git -c gpg.ssh.allowedSignersFile="$scratch/raw/allowed_signers" verify-commit "$source"
git diff --binary "$base" "$source" | sha256sum
printf 'PASS: final source, formatting, unit contracts and signature verified\n'
