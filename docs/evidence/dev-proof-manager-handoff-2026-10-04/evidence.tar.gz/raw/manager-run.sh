#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-proof-manager-20261004-qmlEtr8G
readonly binary=${1:?static broker test image}
[[ $EUID == 0 ]]
install -d -m 0700 /run/fe2o3-proof-custodian
install -o root -g root -m 0555 "$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-proof-manager" /usr/libexec/fe2o3/fe2o3-proof-manager
install -o root -g root -m 0555 "$binary" /usr/libexec/fe2o3/fe2o3-compiler-execution-coordinator
readonly case_name=${FE2O3_MANAGER_CASE:-active}
case "$case_name" in active|before-activate|coordinator-copy|delayed-listener|post-connect-removal) ;; *) exit 90 ;; esac
mkdir -p "$scratch/captures/$case_name"
readlink /proc/self/ns/pid > "$scratch/captures/$case_name/pid-namespace.txt"
sha256sum /usr/libexec/fe2o3/fe2o3-proof-manager /usr/libexec/fe2o3/fe2o3-compiler-execution-coordinator /usr/libexec/fe2o3/fe2o3-application-proof-controller
export FE2O3_CUSTODIAN_PRIVATE_INSTALL=1
if [[ ${FE2O3_MANAGER_CASE:-} == coordinator-copy ]]; then
    install -o root -g root -m 0555 "$binary" /usr/libexec/fe2o3/coordinator-copy
    exec /usr/libexec/fe2o3/coordinator-copy --exact linux::observer_channel::application::tests::root_fixed_manager_handoff_campaign --ignored --nocapture --test-threads=1
fi
if [[ $case_name == active ]]; then
    exec /usr/libexec/fe2o3/fe2o3-compiler-execution-coordinator linux::observer_channel::application::tests::root_ --ignored --nocapture --test-threads=1
fi
exec /usr/libexec/fe2o3/fe2o3-compiler-execution-coordinator --exact linux::observer_channel::application::tests::root_fixed_manager_handoff_campaign --ignored --nocapture --test-threads=1
