rustc -vV 
