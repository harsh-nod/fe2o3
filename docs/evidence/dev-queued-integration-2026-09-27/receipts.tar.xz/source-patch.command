git show --format=fuller --stat --patch HEAD 
