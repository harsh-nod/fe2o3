git log -1 --format=fuller --format=%H%n%T%n%P%n%an\ \<%ae\>%n%aI%n%cn\ \<%ce\>%n%cI%n%B 
