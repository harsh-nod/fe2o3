#!/usr/bin/env bash
set -u
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
label=$1
shift
printf '%q ' "$@" > "$root/$label.command"
printf '\n' >> "$root/$label.command"
date -u +%FT%TZ > "$root/$label.start"
"$@" > "$root/$label.log" 2>&1
status=$?
printf '%s\n' "$status" > "$root/$label.status"
date -u +%FT%TZ > "$root/$label.end"
tail -n 45 "$root/$label.log"
exit "$status"
