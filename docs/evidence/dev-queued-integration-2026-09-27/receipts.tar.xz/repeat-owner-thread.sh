#!/usr/bin/env bash
set -eu
for iteration in $(seq 1 50)
do
    printf 'iteration %s\n' "$iteration"
    timeout 30s target/debug/deps/fe2o3_runtime-84865fc0c8221886 --exact async_engine::tests::owned_tests::snapshot_tests::producer_launch::queued_producer_chain_runs_and_releases_on_the_non_send_owner_thread
done
