git diff --exit-code HEAD -- crates/fe2o3-runtime crates/fe2o3-runtime-model docs/runtime-successor-writer-plan-v1.md Cargo.lock rust-toolchain.toml 
