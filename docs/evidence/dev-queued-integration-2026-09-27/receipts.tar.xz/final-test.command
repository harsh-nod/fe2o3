env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime -p fe2o3-runtime-model --all-features --no-fail-fast 
