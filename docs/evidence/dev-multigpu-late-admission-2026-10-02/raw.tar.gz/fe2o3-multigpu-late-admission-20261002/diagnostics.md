# Late Admission Diagnostics

The preliminary all-features runtime library check passed before final test-source
freeze. This diagnostic is not accepted final-source qualification:

```sh
env CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-runtime --all-features --lib
```

It finished with exit 0 in 8.81 seconds. The frozen campaign records its own
complete commands, source manifests, outputs and exit statuses separately.

The preliminary two-example all-features check failed with exit 101: the new
`InitialPeer::release` match returned two distinct marker-typed release errors
before a common `map_err`. Move the existing error mapping into each arm so both
return `ResultV1<()>`. No production custody or authority check needs changing.
The same two-example check passed with exit 0 after that correction; this remains
pre-freeze diagnostic evidence, not the accepted campaign.

`diagnostic-01/precheck` failed strict Clippy on the new blocker predicate's
nonminimal Boolean expression. The equivalent `Option::is_none_or` predicate
replaces the negated `is_some_and`; missing or quiescent transport still fails.
