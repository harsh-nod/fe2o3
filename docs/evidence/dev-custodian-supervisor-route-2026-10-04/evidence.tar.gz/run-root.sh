#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-custodian-route-20261004-DvJzWnmO
coordinator=$(/home/harsh/.local/bin/jq -r 'select(.reason == "compiler-artifact" and .profile.test and .target.name == "fe2o3_compiler_execution_coordinator") | .executable' "$out/coordinator-build.jsonl")
cargo_test=$(/home/harsh/.local/bin/jq -r 'select(.reason == "compiler-artifact" and .profile.test and .target.name == "worker_v3_load_envelope_vertical") | .executable' "$out/cargo-build.jsonl")
static="$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release"
consumer="$out/static-consumer"
test -x "$coordinator"
test -x "$cargo_test"
test -x "$consumer"
/usr/bin/env -i PATH=/usr/bin:/bin \
  FE2O3_COMPOSED_COORDINATOR_TEST="$coordinator" \
  FE2O3_COMPOSED_RUST_LIBRARY_DIR=/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib \
  FE2O3_STATIC_PREEXEC_LAUNCHER="$repo/target/qualification-static-deployment/launcher/fe2o3-static-preexec-launcher" \
  FE2O3_STATIC_COMPILER_EXECUTION_ISSUER="$static/fe2o3-compiler-execution-issuer" \
  FE2O3_ROOT_ANCHOR_HELPER="$static/fe2o3-external-anchor-provisioning-helper" \
  FE2O3_ROOT_ANCHOR_DAEMON="$static/fe2o3-external-anchor-service" \
  FE2O3_COMPOSED_CARGO_TEST="$cargo_test" \
  FE2O3_COMPOSED_STATIC_CONSUMER="$consumer" \
  FE2O3_TEST_HSACO_WORKER_FIXTURE="$repo/target/debug/fe2o3-worker-v3-hsaco-fixture" \
  /bin/bash "$repo/scripts/qualify-composed-application-startup.sh"
