#!/usr/bin/env bash
set -euo pipefail
cd "${1:?repository path}"
out=${2:?evidence directory}
static_target=${3:?owned static target directory}
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:$HOME/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo test --locked --offline -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor --lib
cargo test --locked --offline -p cargo-fe2o3 --bin cargo-fe2o3
cargo test --locked --offline -p fe2o3-broker-authority-service -p fe2o3-compiler-execution-coordinator --lib
cargo clippy --locked --offline --no-deps -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p fe2o3-broker-authority-service -p fe2o3-compiler-execution-coordinator -p cargo-fe2o3 --all-targets -- -D warnings
cargo clippy --locked --offline --no-deps -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical --bin cargo-fe2o3 -- -D warnings
cargo test --locked --offline -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p fe2o3-broker-authority-service -p fe2o3-compiler-execution-coordinator --doc
cargo test --locked --offline -p fe2o3-compiler-execution-coordinator --lib --no-run --message-format=json > "$out/coordinator-build.jsonl"
cargo test --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical --no-run --message-format=json > "$out/cargo-build.jsonl"
CARGO_BUILD_JOBS=2 CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS='-C target-feature=+crt-static -C debuginfo=0' cargo build --locked --offline --target x86_64-unknown-linux-gnu --target-dir "$static_target" -p cargo-fe2o3 --features worker-v3-host-consumer-fixture --bin cargo-fe2o3-worker-v3-host-consumer-app-fixture
cp "$static_target/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-worker-v3-host-consumer-app-fixture" "$out/static-consumer"
cargo fmt -p cargo-fe2o3 -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p fe2o3-compiler-execution-coordinator --check
rustfmt --edition 2024 --check --config skip_children=true crates/fe2o3-broker-authority-service/src/linux/observer_channel/registry.rs
git diff --check
# The isolated root campaign uses the recorded run-root.sh with its exact prebuilt paths:
# timeout --kill-after=15s 240s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash "$out/run-root.sh"
