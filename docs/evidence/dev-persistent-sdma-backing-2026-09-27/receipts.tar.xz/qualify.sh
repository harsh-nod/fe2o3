#!/usr/bin/env bash
set -u
root=/home/harsh/.codex-tmp/fe2o3-backing-20260927-nsBKbNEw
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
git rev-parse HEAD > "$root/source-before.txt"
git diff --exit-code HEAD -- crates Cargo.toml Cargo.lock rust-toolchain.toml .cargo > "$root/source-clean-before.log" || exit 2
run() {
    local name=$1 start rc
    shift
    start=$SECONDS
    printf '%s\t' "$name" >> "$root/commands.tsv"
    printf '%q ' "$@" >> "$root/commands.tsv"
    printf '\n' >> "$root/commands.tsv"
    "$@" > "$root/$name.log" 2>&1
    rc=$?
    printf '%s\t%s\t%s\n' "$name" "$rc" "$((SECONDS - start))" >> "$root/results.tsv"
    printf '%s: exit=%s seconds=%s\n' "$name" "$rc" "$((SECONDS - start))"
}
run focused cargo test --offline -p fe2o3-kfd --lib -- persistent initialized_prefix constructed_sdma compute_sdma --skip constructed_sdma_creation --test-threads=8
run layout cargo test --offline -p fe2o3-kfd --lib persistent_owner_and_queue_layouts -- --nocapture
run runtime cargo test --offline -p fe2o3-runtime --lib -- --test-threads=8
run doctests cargo test --offline -p fe2o3-kfd -p fe2o3-runtime --doc
run clippy cargo clippy --offline -p fe2o3-kfd -p fe2o3-runtime --all-targets --all-features -- -D warnings
run minimal cargo check --offline -p fe2o3-runtime --no-default-features
run prefix-proof python3 -I -B crates/fe2o3-runtime-model/verus/check-initialized-prefix.py --output "$root/prefix-campaign" --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
run format cargo fmt --all -- --check
run whitespace git diff --check
run source-continuity git diff --exit-code "$(<"$root/source-before.txt")" -- crates Cargo.toml Cargo.lock rust-toolchain.toml .cargo
git rev-parse HEAD > "$root/source-after.txt"
