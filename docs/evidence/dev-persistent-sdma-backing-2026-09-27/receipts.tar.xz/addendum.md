# Additional Qualification Receipts

All commands ran in `/home/harsh/.codex-tmp/fe2o3-r61-execution` at signed
`8de35fdaae044498a1ff7455f5ffbb914fa3eed7`.

Additional all-feature runtime command (exit 101):

```sh
CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=8
```

Complete output: `runtime-all-features.log`. Result: 1621 passed, 3 failed,
28 ignored, 31.17 seconds test execution. Failures are the same three telemetry
tests as the default run, at `authorized_execution.rs:1317`, all with
`InspectSocket(PermissionDenied)`. That source was not changed by this commit.

`signature.log` records successful verification with the repository's existing
allowed-signers file. `scalar-source-continuity.log` records an empty successful
diff of the initialized-prefix runtime wrapper/body, Verus root and controller
against `2edf53d4245fe8e720be6d59de64983ebe796e94`.

`mi300x-access.log` records exit 255 for:

```sh
ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname
```

DNS failed before connection. No remote files, processes or GPU work were created.

## Development Attempts

`persistent-development.log`: 152 passed, one failed. The failure caught the
43,584-byte inline queue layout introduced by the first backing representation.
It was fixed without raising the bound or adding another heap allocation.

`focused-development.log`: 243 passed, zero failed, 486.89 seconds. This includes
15 expensive construction tests omitted from the repeated frozen-source filter.
The final filter and its exact output are in `qualify.sh` and `focused.log`;
the final layout log additionally records the heap-overhead assertion and sizes.

The development logs are not presented as frozen-source proof. Final qualified
source identity is recorded separately in source-before/after and proof receipts.

## Proof Audit

All 19 results in `prefix-campaign/results.json` pass. Eleven mutants have
nonzero logical-rejection status, not claimed positive verification. The three
positive stdout JSON records each report 8 verified, 0 errors, entire-crate
success. Before/after inventories are identical at 6079 inputs and the signed
commit above; all 19 process-group receipts report absent. Both pinned closure
checks pass. These are scalar arithmetic proofs only, not native bridge proofs.

All qualification command sessions were observed terminal before this packet
was archived. The existing unrelated owner-inspection directory was untouched.
