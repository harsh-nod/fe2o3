# Persistent SDMA Backing Review

Implementation: `8de35fdaae044498a1ff7455f5ffbb914fa3eed7`.

Root implemented; runtime_next independently reviewed read-only. No remote
execution occurred: MI300X hostname resolution failed before connection.

## Authority And Custody

- Backing retains a mapped lease and private initialization metadata together.
  Nonzero metadata originates only by consuming an SDMA buffer. There is no
  raw-lease-plus-prefix constructor or separately extractable witness.
- Export checks storage identity, exact queue occurrence, pool generation,
  logical extent and physical extent. Raw extraction deliberately discards
  metadata. Logical bytes do not certify physical padding.
- The persistent owner's restore checks local detached storage identity and
  physical extent. The production adapters additionally authenticate queue,
  generation, logical extent, exact offsets and lengths before restoration.
- Single, window, synchronous, legacy and same-device queue paths now transfer
  whole buffers. Pair detach/restore preflights both inputs. Rejection returns
  original buffers rather than rebuilding them from raw leases.
- Compute detachment retains its prior metadata in the hollow backing and
  records the detaching use's slot and generation. Cancellation requires that
  exact prepared use, the exact returned mapping, and an opaque permit minted
  immediately after owner preflight. No callback intervenes in this suffix.
- Completed compute restored through the existing raw-lease path clears the
  coverage. Authenticated returned-data import is intentionally still missing.
  Public reserve/prepare/publish/complete/settle cannot mint initialized bytes.
- A hollow owner with no live ledger use returns WrongState on extraction; it
  no longer reaches the old missing-native expectation panic.

## Memory And Complexity

Development qualification exposed a queue inline-size regression: 43,584 bytes
exceeded the existing 41 KiB bound. The fix co-locates native backing and the
detaching-use stamp in the owner's existing bounded ledger allocation. It adds
no allocation per owner or per transfer. Fixed-size metadata and transfer
checks remain constant time; existing bounded ledger scans remain unchanged.
The old inline limits are retained, with a new heap overhead limit of 1 KiB
above the 64-entry ledger. Final measured layouts are in `layout.log`.

## Evidence Boundaries

The new direct-submission regression uses actual CPU fixture mappings and
production submit/retirement, injecting the exact completion value. It checks
metadata before and after retirement, persistent source round trips, exact
identity, releases and accounting refunds. It does not execute device copying.

The other new owner tests use synthetic native-neutral completion records to
check sequential prefix growth, gaps, pairing, cancellation and resets. They
are not hardware witnesses. Existing constructed driver tests provide broader
CPU failure/custody qualification.

The scalar initialized-prefix arithmetic and Verus root are unchanged from
the preceding packet. Their proof does not refine the new native backing,
concrete resource identity, queue publication, firmware or machine code. Those
adapter checks remain Checked/CPU-tested, with external behavior Contracted.
No new typed compute input, public pending-peer admission, parity or performance
acceptance follows from this change.

## Next Implementation

1. Import original `Gfx942FixedDispatchDataV1` at compute completion rather than
   a raw lease and boolean. Borrow all three data objects before any three-way
   restoration; retain original objects on failure. Keep H2dReady SHA evidence
   independent of byte-definedness.
2. Add opaque quiescent InitializedStorage input and preserve its origin through
   typed bind, replay, cancellation and runtime allocation transitions.
3. Finish native predecessor access and router-driven gate resolution, then
   qualify composed generated graphs, refinement and matched hardware runs.
