#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-refinement-20261003-SBbxgJWA
trap 'printf "%s\n" "$?" > "$scratch/owned.status"' EXIT
mkdir -p "$scratch/owned-captures"
timeout --kill-after=15s 900s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" \
    /usr/bin/env FE2O3_MACHINE_EFFECT_NATIVE_WORKER="$scratch/fe2o3-llvm-link-worker" \
    FE2O3_FILL_ANALYSIS_HSACO="$scratch/native/qualified-final/audit-1/finalized.hsaco" \
    FE2O3_FILL_REFINEMENT_EVIDENCE="$scratch/owned-captures" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-verifier --lib protected_native_owned_conditional_fill \
    -- --ignored --nocapture >"$scratch/owned.log" 2>&1
