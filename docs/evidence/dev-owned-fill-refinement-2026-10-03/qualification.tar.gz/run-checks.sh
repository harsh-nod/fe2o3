#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-refinement-20261003-SBbxgJWA
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/checks.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true
export CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --lib > "$scratch/verifier.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-functional-proof --features internal-proof-staging > "$scratch/import.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --doc conditional_fill > "$scratch/ownership.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib > "$scratch/host.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-verifier --lib -- -D warnings > "$scratch/clippy.log" 2>&1
git diff --check > "$scratch/whitespace.log" 2>&1
