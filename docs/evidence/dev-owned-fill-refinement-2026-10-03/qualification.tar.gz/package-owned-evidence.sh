#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-refinement-20261003-SBbxgJWA
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly archive="$repo/docs/evidence/dev-owned-fill-refinement-2026-10-03/qualification.tar.gz"
test "$(<"$scratch/owned.status")" = 0
test "$(<"$scratch/checks.status")" = 0
cd "$repo"
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check \
    crates/fe2o3-verifier/src/conditional_fill_refinement_v1.rs \
    crates/fe2o3-verifier/src/conditional_fill_refinement_v1/owned.rs \
    crates/fe2o3-verifier/src/conditional_fill_refinement_v1/tests.rs \
    crates/fe2o3-verifier/src/lib.rs > "$scratch/owned-formatting.log" 2>&1
git diff --check > "$scratch/owned-whitespace.log" 2>&1
git diff --binary -- crates/fe2o3-verifier > "$scratch/owned-candidate.patch"
cd "$scratch"
tar -czf "$archive" -- \
    owned-candidate.patch package-owned-evidence.sh run-owned.sh isolated-runtime.sh \
    run-checks.sh owned.log owned.status owned-initial.log owned-captures \
    verifier.log import.log ownership.log host.log clippy.log checks.status \
    owned-formatting.log owned-whitespace.log
sha256sum owned-candidate.patch "$archive"
tar -tzf "$archive" | wc -l
tar -xOzf "$archive" owned-candidate.patch | sha256sum
