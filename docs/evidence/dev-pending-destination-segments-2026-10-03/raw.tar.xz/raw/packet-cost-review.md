# Read-Only Packet Cost Review

The accepted 4096-descriptor native command receipt records 231.024736 seconds.
That interval includes setup, two ordered lists, compute, return transfer,
full-buffer verification and shutdown. It is not an isolated copy benchmark or
a HIP/HSA comparison. The following observations are source-derived, not a
measured attribution of that duration.

No descriptor-count quadratic scan was found in the current unified path.
Context validates and hashes descriptors at admission; custody constructs a
second identity hash there. Gfx942ComputeXgmiSegmentsPlanV1::new checks extents,
counts packets and builds windows once. Later packet_count/total_bytes access
stored fields; frame/producer matching uses exact Arc identities and scalar
extents. Lower transfer indexes windows[current], and both R74 cursor
transitions are constant-time. Repeated ancestor validation depends on dependency
depth and live roots, not the list's descriptor count.

The lower transfer still publishes and fences each packet separately.
crates/fe2o3-kfd/src/queue_live/compute_xgmi/transfer.rs selects publication or
polling per step; src/sdma/compute_xgmi.rs performs full paired route currentness
before and after each publication and poll. The two lists have 8192 one-packet
descriptors, implying at least 16384 such lower actions and about 32768 paired
full-currentness calls, before extra Pending samples and other pipeline work.
Paired model loans/retakes also occur in queue_live/compute_xgmi/persistent.rs.

First add phase/call counters or retained profiling to measure these costs.
Reusing the Context admission identity can remove one initial hash, but cannot
explain away the serial per-packet cost. A meaningful later throughput patch is
a bounded shared-owner packet window, with exact ring tickets, ordered-prefix
failure custody, currentness at each publication/completion boundary and final-
only restoration. It is not another cached descriptor-validity flag.

Required checks include overlapping descriptor order, 63/64/65-slot boundaries,
ring reuse, partial publication/fence failure, stale session/route identity,
unwind and the runtime's one-quantum fairness. Immutable descriptors do not
justify replacing Full currentness with weaker retained/operational checks.
Application-kernel authority remains the first practical multi-GPU priority.
