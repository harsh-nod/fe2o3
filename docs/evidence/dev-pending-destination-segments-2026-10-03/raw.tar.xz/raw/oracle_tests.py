"""Offline controller/schema and independent byte-oracle cross-checks. No SSH."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


oracle = load('offline_oracle', ROOT / 'native_oracle.py')
campaign = load('offline_campaign', ROOT / 'hardware/campaign.py')


def independent_frame(domain, parts):
    return hashlib.sha256(domain + b''.join(len(part).to_bytes(8, 'little') + part for part in parts)).hexdigest()


def independent_compute(count):
    # Float formulas and byte-slice stores intentionally differ from the quarter-integer oracle.
    left = b''.join(struct.pack('<f', (index & 63) * .25 + (index & 31) * .5)
                    for index in range(65536))
    right = b''.join(struct.pack('<f', (index & 63) * .25 + (index & 31))
                     for index in range(65536))
    gathered = bytearray(struct.pack('<f', .25) * 65536)
    for source, contents in enumerate((left, right)):
        for index in range(count):
            if index in (0, 2):
                start, target, length = 4 + source * 36, 64, 128
            elif index == 1:
                start, target, length = 260 + source * 20, 96, 128
            elif index == 3:
                start, target, length = 1028 + source * 28, 192, 68
            else:
                start = 4 + 4 * ((13 * index + 29 * source) % 10000)
                target = 1028 + 4 * ((17 * index + 19 * source) % 40000)
                length = 4 + 4 * (index % 17)
            gathered[target:target + length] = contents[start:start + length]
    computed = b''.join(struct.pack('<f', struct.unpack_from('<f', gathered, 4 * index)[0]
                                    + (index & 31) * .5) for index in range(65536))
    returned = bytearray([165]) * 262913
    returned[131:262211] = computed[20:262100]
    host = bytearray([90]) * 263297
    host[97:263010] = returned
    return independent_frame(b'fe2o3.destination-segments-compute.v1\0',
                             (left, right, gathered, computed, returned, host))


class OracleTests(unittest.TestCase):
    def test_preserved_reference_assets_and_unchanged_control_oracles(self):
        pins = {
            'reference/campaign.py': '3e491a295e74a7e6ae46647312fc24108a8d86100598aeea0136242769b05f01',
            'hardware/capture.py': 'c16f79bbca127cbf698d5fd6a76db3dca708a13fbc5df64e8c164beb93994f08',
            'hardware/reference/campaign.py': '4812c5caa2f80863313c5b2e5d960b756ba246278ceb12ac346e9a45a3d75ba0',
            'hardware/reference/audit.py': '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea',
            'reference/oracle_tests.py': 'a19d9c0053f8e7ce3e90a75f76a4938d22d480da2be5886f039de80127ae4e82',
            'reference/native_oracle.py': '1fe0eaa48d6245aec417385542766dae024779cd748bc3dc8c0e5181fd19b3ed',
        }
        for relative, expected in pins.items():
            self.assertEqual(hashlib.sha256((ROOT / relative).read_bytes()).hexdigest(), expected)
        original = load('offline_previous_campaign', ROOT / 'reference/campaign.py')
        previous_oracle = load('offline_previous_oracle', ROOT / 'reference/native_oracle.py')
        self.assertEqual(campaign.TARGETS, original.TARGETS)
        self.assertEqual(campaign.BUILD_LABELS, original.BUILD_LABELS)
        controls = campaign.CASES[15:]
        self.assertEqual(len(controls), 6)
        for row in controls:
            self.assertIn(row, original.CASES)
            _, kind, args = row
            self.assertEqual(oracle.expected(kind, args), previous_oracle.expected(kind, args))

    def test_rerun_capture_bounds_and_helper_roots(self):
        self.assertEqual(campaign.NATIVE_PROCESS_TIMEOUT_SECONDS, 420)
        self.assertEqual(campaign.TRANSPORT_TIMEOUT_SECONDS, 480)
        helper, audit = campaign.helpers()
        self.assertEqual(campaign.ROOT, ROOT / 'hardware')
        self.assertEqual(helper.ROOT, campaign.ROOT)
        self.assertEqual(audit.HARDWARE, campaign.ROOT)
        self.assertEqual(audit.RAW, ROOT)
        self.assertEqual(helper.BASE, '8191d00810edd6bfd56256368b8ecdcb59a38545')
        self.assertEqual(audit.BASE, helper.BASE)
        self.assertEqual(campaign.PREFIX, '/tmp/fe2o3-pending-destination-20261003-')
        capture = ast.parse((campaign.ROOT / 'capture.py').read_text())
        constants = {node.targets[0].id: node.value.value for node in capture.body
                     if isinstance(node, ast.Assign) and len(node.targets) == 1
                     and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Constant)}
        self.assertEqual(constants['TRANSPORT_TIMEOUT_SECONDS'], 480)
        calls = [node for node in ast.walk(capture) if isinstance(node, ast.Call)]
        timeout_uses = [keyword.value for node in calls
                        if isinstance(node.func, ast.Attribute) and node.func.attr == 'communicate'
                        for keyword in node.keywords if keyword.arg == 'timeout']
        self.assertEqual(sum(isinstance(value, ast.Name) and value.id == 'TRANSPORT_TIMEOUT_SECONDS'
                             for value in timeout_uses), 1)
        receipt_uses = [keyword.value for node in calls for keyword in node.keywords
                        if keyword.arg == 'transport_timeout_seconds']
        self.assertEqual(len(receipt_uses), 1)
        self.assertIsInstance(receipt_uses[0], ast.Name)
        self.assertEqual(receipt_uses[0].id, 'TRANSPORT_TIMEOUT_SECONDS')
        source = (campaign.ROOT / 'campaign.py').read_text()
        self.assertIn("f'{NATIVE_PROCESS_TIMEOUT_SECONDS}s'", source)
        self.assertIn('native_process_timeout_seconds=NATIVE_PROCESS_TIMEOUT_SECONDS', source)
        self.assertIn('transport_timeout_seconds=TRANSPORT_TIMEOUT_SECONDS', source)

    def test_transport_receipt_accepts_only_exact_bound_and_terminal_success(self):
        helper, _ = campaign.helpers()
        argv = ['ssh', 'offline-test-only']
        empty = hashlib.sha256(b'').hexdigest()
        good = dict(argv=argv, started='2026-10-03T00:00:00+00:00',
                    finished='2026-10-03T00:00:01+00:00', elapsed_seconds=1,
                    exit_code=0, timed_out=False, local_process_group_absent=True,
                    transport_timeout_seconds=480, stdout_sha256=empty, stderr_sha256=empty)
        # Generated temporary receipts only; no transport function is called.
        with tempfile.TemporaryDirectory(prefix='fe2o3-pending-destination-controller-test-') as temporary:
            helper.ROOT = Path(temporary)
            folder = helper.ROOT / 'sample'
            folder.mkdir()
            (folder / 'stdout').write_bytes(b'')
            (folder / 'stderr').write_bytes(b'')
            (folder / 'result.json').write_text(json.dumps(good))
            self.assertEqual(helper.read_receipt('sample', argv)[0], good)
            for patch in ({'transport_timeout_seconds': 360}, {'elapsed_seconds': 491},
                          {'timed_out': True}, {'exit_code': 124},
                          {'local_process_group_absent': False}):
                (folder / 'result.json').write_text(json.dumps(good | patch))
                with self.assertRaises(AssertionError):
                    helper.read_receipt('sample', argv)

    def test_exact_matrix_and_receipt_label_mapping(self):
        self.assertEqual(len(campaign.CASES), 21)
        self.assertEqual(len({row[0] for row in campaign.CASES}), 21)
        self.assertEqual(sum(kind == 'copy' for _, kind, _ in campaign.CASES), 3)
        self.assertEqual(sum(kind == 'compute' for _, kind, _ in campaign.CASES), 18)
        self.assertEqual(campaign.BUILD_LABELS, {'copy': 'destination', 'compute': 'deferred'})
        self.assertEqual(campaign.CARDS, ['card1', 'card6', 'card7'])
        actual = {(args[0], args[1], args[2], tuple(args[3:]))
                  for _, kind, args in campaign.CASES[:15] if kind == 'compute'}
        expected = {(mode, selected, '4', tuple(ids))
                    for mode in ('--pending-destination-segments-compute',
                                 '--late-pending-destination-segments-compute')
                    for selected in ('first', 'second', 'both')
                    for ids in (campaign.IDS, campaign.IDS[::-1])}
        expected.update({
            ('--pending-destination-segments-compute', 'both', '65', tuple(campaign.IDS)),
            ('--late-pending-destination-segments-compute', 'both', '65', tuple(campaign.IDS[::-1])),
            ('--pending-destination-segments-compute', 'both', '4096', tuple(campaign.IDS[::-1])),
        })
        self.assertEqual(actual, expected)
        self.assertEqual(sum('4096' in args for _, _, args in campaign.CASES), 1)
        self.assertEqual(campaign.CASES[15:], [
            ('copy-overlap-forward', 'copy', [*campaign.IDS, 'overlap']),
            ('dispose-duplicates-reverse', 'copy', ['--dispose-source', *campaign.IDS[::-1], 'duplicates']),
            ('copy-packets-forward', 'copy', [*campaign.IDS, 'packets']),
            ('compute-4-forward', 'compute', ['--destination-segments-compute', '4', *campaign.IDS]),
            ('late-compute-65-reverse', 'compute', ['--late-destination-segments-compute', '65', *campaign.IDS[::-1]]),
            ('legacy-gather-overlap-reverse', 'compute', ['--gather-compute-overlap', *campaign.IDS[::-1]]),
        ])

    def test_pending_source_profile_counts_and_unchanged_full_byte_digest(self):
        differences = {'schema', 'pipeline', 'pending_sources', 'source_producers',
                       'setup_launches', 'pipeline_launches', 'completion_receipts'}
        for count in (4, 65, 4096):
            for late in (False, True):
                mode = '--late-pending-destination-segments-compute' if late else '--pending-destination-segments-compute'
                settled_mode = '--late-destination-segments-compute' if late else '--destination-segments-compute'
                settled = oracle.expected_compute([settled_mode, str(count), *campaign.IDS])
                for selected, pending_count in (('first', 1), ('second', 1), ('both', 2)):
                    result = oracle.expected('compute', [mode, selected, str(count), *campaign.IDS])
                    self.assertEqual(result['schema'], 'fe2o3.pending-destination-segments-compute.v1')
                    self.assertEqual(result['pipeline'], 'source-compute-list-list-compute-peer-readback')
                    self.assertEqual(result['pending_sources'], selected)
                    self.assertEqual(result['source_producers'], 'selected-pending-others-completed-and-released-at-list-admission')
                    self.assertEqual(result['setup_launches'], str(4 - pending_count))
                    self.assertEqual(result['pipeline_launches'], str(1 + pending_count))
                    self.assertEqual(result['completion_receipts'], str(5 + pending_count))
                    self.assertEqual(len(result), 53 if late else 46)
                    self.assertEqual({key: value for key, value in result.items() if key not in differences},
                                     {key: value for key, value in settled.items() if key not in differences})

    def test_exact_source_report_key_sets(self):
        copy_source = (REPO / 'crates/fe2o3-runtime/examples/gfx942-runtime-destination-segments-smoke.rs').read_text()
        compute_source = (REPO / 'crates/fe2o3-runtime/examples/deferred_peer_chain/gather_compute.rs').read_text()
        def fields(line):
            return set(re.findall(r' ([a-z][a-z0-9_]*)=', line))
        copy_keys = fields(next(line for line in copy_source.splitlines() if 'PASS schema=fe2o3.destination-peer-segments.v1 ' in line))
        compute_keys = fields(next(line for line in compute_source.splitlines() if 'source_payloads=C,D' in line and 'PASS schema=' in line))
        legacy_keys = fields(next(line for line in compute_source.splitlines() if 'pipeline=compute-gather-compute-peer-readback' in line and 'PASS schema=' in line))
        publication = fields(next(line for line in compute_source.splitlines() if ' publication_observed=true publication_identity=' in line))
        pending = fields(next(line for line in compute_source.splitlines() if '" pending_sources={}"' in line))
        self.assertEqual(len(copy_keys), 50)
        self.assertEqual(len(compute_keys), 45)
        self.assertEqual(len(legacy_keys), 41)
        self.assertEqual(len(publication), 7)
        self.assertEqual(pending, {'pending_sources'})
        for _, kind, args in campaign.CASES:
            expected = oracle.expected(kind, args)
            wanted = copy_keys if kind == 'copy' else legacy_keys if args[0].startswith('--gather-') else compute_keys
            if kind == 'compute' and args[0].startswith('--late-'):
                wanted = wanted | publication
            if kind == 'compute' and '-pending-destination-' in args[0]:
                wanted = wanted | pending
            self.assertEqual(set(expected), wanted)
            self.assertEqual(expected['performance_acceptance'], 'false')
            self.assertEqual(expected['formal_refinement'], 'false')

    def test_compute_integer_quarter_matches_independent_float_byte_oracle(self):
        digests = set()
        for count in (4, 65, 4096):
            actual = oracle.compute_digest(count)
            self.assertEqual(actual, independent_compute(count))
            digests.add(actual)
            print(f'compute-{count} {actual}', flush=True)
        self.assertEqual(len(digests), 3)

    def test_copy_scalar_boundaries_and_ordered_holes(self):
        for case in ('disjoint', 'overlap', 'duplicates', 'packets'):
            sizes, destination, source_length, destination_length, lists = oracle.copy_geometry(case)
            self.assertEqual(len(lists), 2)
            for source, base in enumerate((17, 29)):
                self.assertLess(base + source_length, sizes[source])
                for start, target, length in lists[source]:
                    self.assertGreater(length, 0)
                    self.assertLessEqual(start + length, source_length)
                    self.assertLessEqual(target + length, destination_length)
            self.assertLess(53 + destination_length, destination)
        lists = oracle.copy_geometry('duplicates')[4]
        self.assertEqual(lists[0][0], lists[0][2])
        self.assertEqual(lists[1][0], lists[1][2])
        self.assertEqual(sum((length + oracle.PACKET - 1) // oracle.PACKET
                             for parts in oracle.copy_geometry('packets')[4] for _, _, length in parts), 6)

    def test_framing_and_wrong_inputs_fail_closed(self):
        self.assertNotEqual(oracle.framed(b'x', (b'a', b'bc')), oracle.framed(b'x', (b'ab', b'c')))
        self.assertNotEqual(oracle.framed(b'x', (b'a',)), oracle.framed(b'y', (b'a',)))
        for ids in ([campaign.IDS[0]] * 3, ['0x0000000000000000', *campaign.IDS[1:]], ['0x1', *campaign.IDS[1:]]):
            with self.assertRaises(AssertionError):
                oracle.uid_fields(ids)
        for count in (0, 3, 4097):
            with self.assertRaises(AssertionError):
                oracle.compute_descriptors(0, count)
        for args in (
            ['--pending-destination-segments-compute', 'none', '4', *campaign.IDS],
            ['--pending-destination-segments-compute', 'both', '04', *campaign.IDS],
            ['--late-pending-destination-segments-compute', 'second', '4097', *campaign.IDS],
            ['--pending-destination-segments-compute', 'first', '4', *campaign.IDS[:2]],
            ['--pending-destination-segments-compute', 'second', '4', *campaign.IDS, campaign.IDS[0]],
        ):
            with self.assertRaises(AssertionError):
                oracle.expected('compute', args)
        with self.assertRaises(AssertionError):
            oracle.expected('unknown', [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
