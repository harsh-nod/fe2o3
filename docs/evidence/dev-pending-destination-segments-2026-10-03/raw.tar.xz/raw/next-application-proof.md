# Next Practical Multi-GPU Gate

Read-only swarm review, 2026-10-03. No new proof execution is claimed here.

Production multi-device constructors already accept caller authorities, and
ContextArguments supplies ordinary ABI binding. Neither a finite R57 kernel nor
a trusted application Boolean establishes the protected compiler/effects and
machine-refinement contracts required by a general application launch.

Prioritize the first source-owned u32 copy application. Reuse compiler-owned SSA
and physical-copy work from locally available origin/main (40509db14); its inert
handoff is not native authority. Entry values, kernarg ABI, EXEC masks, address
carry/bounds, loaded-to-stored values, memory frames, termination and completion
still need composition. Approved compiler/proof measurements, signer policy and
rollback attestation are separate deployment prerequisites.

## Bounded Next Patch

The actual Gfx942SAddU32V1::execute body in
crates/fe2o3-kernel-analysis/src/gfx942_integer_semantics_v1.rs reads two operands
and writes a destination register and SCC. Existing shared add_u32_body proofs
cover arithmetic only, not register-frame or alias semantics.

Extract the actual transition into a shared expression body. Verify that same
body over the exact 102-register plus SCC schema under valid indices. Both
operands must come from the old state before either write. Prove modulo result,
carry/SCC, returned result, and unchanged non-destination registers, including
destination/source aliasing and incoming-SCC independence. Arbitrary u32
constants are an acceptable superset of the decoded constant domain.

Extend existing arithmetic proof/checker controls rather than introduce another
framework. Bind the exact state/source declarations, register count, forwarding
calls and both shared includes. Reject mutants for alias clobber, wrong
destination, unrelated-register corruption and stale SCC, preserving arithmetic
mutants. Require logical postcondition failure, not parser errors or timeout.

Keep model/shared-body/Rust-test ownership separate from Verus/checker ownership;
root integrates any CI changes. The local main branch has no overlapping
integer-model/proof files, but adjacent exports, dataflow and CI have diverged.

Candidate commands after source freeze:

```sh
python3 -I -B crates/fe2o3-kernel-analysis/verus/gfx942_add_u32_test.py
python3 -I -B crates/fe2o3-kernel-analysis/verus/gfx942_add_u32_check.py \
  --verus /home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus \
  --output /home/harsh/.codex-tmp/fe2o3-gfx942-state-proof-attempt-01
cargo test --offline --locked -p fe2o3-kernel-analysis --lib \
  gfx942_integer_semantics_v1::tests -- --test-threads=1
cargo test --offline --locked -p fe2o3-verifier --lib \
  gfx942_local_checked_u32_add_v1 -- --test-threads=1
```

This is projected execution/frame semantics, not decoder correctness, physical
ISA conformance, source/entry-state correspondence, CFG or memory effects, or
application launch authority. Subsequent bounded decoded MOV/ADD composition
must retain those distinctions.

## Secondary Runtime Work

Pending list-frame-to-list-source composition removes a further prequeueing
gap, but joined copies already support copy-only applications. It needs a
distinct exact source-frame provenance, envelope read lease, latest writer,
cycle rejection and actual success/quiescence/restoration before extraction.
Do not mistake another finite fixture campaign for the application gate.

Packet-window batching is a later measured optimization. Preserve exact ring
tickets, per-window currentness, contiguous completion-prefix custody, bounded
fairness and final-only owner restoration. Existing per-request mapping-pair
batching is not a proof of shared-owner segment batching.
