# Initial Packaging Attempt

The first direct pack.py invocation exited 1 at indexed_sources_match before
writing candidate.patch or an archive. It was mistakenly started while the
preceding git add process was still running; the old index did not match the
accepted source at check-producer-input-composition.py. The staging process
subsequently completed with exit 0. No source, auditor or acceptance predicate
was changed in response. Packaging is retried only after staging completes.

This is a rejected packaging attempt, not a CPU or native test failure. The
successful package must independently recheck the complete source/index mapping,
all selected controller identities, archive contents and source stability.
