"""Pending-source destination-list composition qualification, with offline replay."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
RAW = ROOT.parent
BASE = '8191d00810edd6bfd56256368b8ecdcb59a38545'
PREFIX = '/tmp/fe2o3-pending-destination-20261003-'
IDS = ['0xab83d2ffef0d3cdf', '0x10a254ce4987e716', '0x53691ef168a0147d']
CARDS = ['card1', 'card6', 'card7']
BDFS = ['0000:26:00.0', '0000:C6:00.0', '0000:E5:00.0']
TARGETS = {'copy': 'gfx942-runtime-destination-segments-smoke',
           'compute': 'gfx942-runtime-deferred-peer-chain-smoke'}
BUILD_LABELS = {'copy': 'destination', 'compute': 'deferred'}
NATIVE_PROCESS_TIMEOUT_SECONDS = 420
TRANSPORT_TIMEOUT_SECONDS = 480
CASES = [(f'pending-{selected}-{timing}-4-{direction}', 'compute',
          [mode, selected, '4', *ids])
         for selected in ('first', 'second', 'both')
         for timing, mode in (('prequeued', '--pending-destination-segments-compute'),
                              ('late', '--late-pending-destination-segments-compute'))
         for direction, ids in (('forward', IDS), ('reverse', IDS[::-1]))]
CASES += [
    ('pending-both-prequeued-65-forward', 'compute',
     ['--pending-destination-segments-compute', 'both', '65', *IDS]),
    ('pending-both-late-65-reverse', 'compute',
     ['--late-pending-destination-segments-compute', 'both', '65', *IDS[::-1]]),
    ('pending-both-prequeued-4096-reverse', 'compute',
     ['--pending-destination-segments-compute', 'both', '4096', *IDS[::-1]]),
    ('copy-overlap-forward', 'copy', [*IDS, 'overlap']),
    ('dispose-duplicates-reverse', 'copy', ['--dispose-source', *IDS[::-1], 'duplicates']),
    ('copy-packets-forward', 'copy', [*IDS, 'packets']),
    ('compute-4-forward', 'compute', ['--destination-segments-compute', '4', *IDS]),
    ('late-compute-65-reverse', 'compute', ['--late-destination-segments-compute', '65', *IDS[::-1]]),
    ('legacy-gather-overlap-reverse', 'compute', ['--gather-compute-overlap', *IDS[::-1]]),
]


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def helpers():
    assert sha(ROOT / 'reference/campaign.py') == '4812c5caa2f80863313c5b2e5d960b756ba246278ceb12ac346e9a45a3d75ba0'
    assert sha(ROOT / 'reference/audit.py') == '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea'
    assert sha(ROOT / 'capture.py') == 'c16f79bbca127cbf698d5fd6a76db3dca708a13fbc5df64e8c164beb93994f08'
    assert sha(RAW / 'capture.py') == '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
    helper = load('transport_helpers', ROOT / 'reference/campaign.py')
    helper.ROOT, helper.BASE = ROOT, BASE
    audit = load('receipt_helpers', ROOT / 'reference/audit.py')
    audit.BASE, audit.RAW, audit.HARDWARE = BASE, RAW, ROOT
    return helper, audit


class Transcript:
    def __init__(self, helper, audit, replay, outer=None):
        self.helper, self.audit, self.replay = helper, audit, replay
        self.events = {}
        self.last = audit.instant(outer['started']) if replay else datetime.now(timezone.utc)
        self.end = audit.instant(outer['finished']) if replay else None

    def call(self, name, argv):
        assert name not in self.events
        if not self.replay:
            self.helper.capture(name, argv)
        receipt, stdout, stderr = self.helper.read_receipt(name, argv)
        assert not stderr, (name, stderr)
        start, finish = (self.audit.instant(receipt[key]) for key in ('started', 'finished'))
        assert self.last <= start <= finish
        assert self.end is None or finish <= self.end
        self.last = finish
        self.events[name] = dict(receipt_sha256=sha(ROOT / name / 'result.json'),
                                 started=receipt['started'], finished=receipt['finished'], argv=argv)
        return stdout.decode()

    def remote(self, name, argv, bound='30s'):
        return self.call(name, self.helper.remote_argv(argv, bound))

    def admit(self, name, baseline):
        state = self.audit.decode_json(self.remote(name + '-availability', self.helper.AVAILABILITY))
        for card, uid, bdf in zip(CARDS, IDS, BDFS, strict=True):
            assert state[card]['Unique ID'] == baseline[card]['Unique ID'] == uid
            assert state[card]['PCI Bus'] == baseline[card]['PCI Bus'] == bdf
            assert state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0'
            for field in ('VRAM Total Memory (B)', 'VRAM Total Used Memory (B)'):
                assert state[card][field] == baseline[card][field], (name, card, field)
            assert int(state[card]['VRAM Total Used Memory (B)']) <= 512 * 1024 * 1024
            assert int(state[card]['VRAM Total Memory (B)']) >= 16 * 1024 ** 3
        assert state['system'] == baseline['system'], 'whole-host PID roster drift'
        mapping = self.remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        records = {}
        for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = match.groups()
            devices = [] if devices is None else devices.split()
            assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
            assert pid not in records and not {'1', '6', '7'}.intersection(devices)
            records[pid] = devices
        assert {'PID' + pid for pid in records} == set(state['system'])
        for pid, devices in records.items():
            assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
        memory = self.remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
        names = [name + '-' + suffix for suffix in ('availability', 'attachments', 'host-memory')]
        self.fresh(names, self.last)
        return names

    def fresh(self, names, at):
        for name in names:
            assert 0 <= (at - self.audit.instant(self.events[name]['finished'])).total_seconds() <= 300


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and sys.argv[1] in ('live', 'replay') and sys.argv[2].isdigit()
    replay, generation = sys.argv[1] == 'replay', sys.argv[2]
    helper, audit = helpers()
    source = audit.current_source()
    oracle = load('independent_destination_oracle', RAW / 'native_oracle.py')
    requirements = {}
    for name, kind, args in CASES:
        requirements[name] = oracle.expected(kind, args)
    binaries, builds = {}, {}
    for kind, target in TARGETS.items():
        audit.BUILD, audit.TARGET = RAW / ('build-' + BUILD_LABELS[kind] + '-final-' + generation), target
        builds[kind], binaries[kind] = audit.build_identity(source)
    outer = None
    if replay:
        outer = audit.local_receipt(RAW / ('hardware-final-' + generation), '3600s',
            ['python3', '-I', '-B', str(Path(__file__)), 'live', generation], source)
        assert all(audit.instant(build['finished']) <= audit.instant(outer['started']) for build in builds.values())
    transcript = Transcript(helper, audit, replay, outer)
    completed, errors, directory, cleaned, baseline = [], [], None, False, None
    try:
        baseline = audit.decode_json(transcript.remote('initial-availability', helper.AVAILABILITY))
        names = transcript.admit('baseline', baseline)
        directory = transcript.remote('create-scratch', ['/usr/bin/mktemp', '-d', PREFIX + 'XXXXXX']).strip()
        assert re.fullmatch(re.escape(PREFIX) + '[A-Za-z0-9]{6}', directory)
        transcript.fresh(['initial-availability', *names], audit.instant(transcript.events['create-scratch']['started']))
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
        for kind, binary in binaries.items():
            transcript.call('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            assert transcript.remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
        for name, kind, args in CASES:
            admission = transcript.admit(name, baseline)
            binary = binaries[kind]
            assert transcript.remote(name + '-hash', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
            output = transcript.remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', binary['remote'], *args],
                f'{NATIVE_PROCESS_TIMEOUT_SECONDS}s')
            transcript.fresh(admission, audit.instant(transcript.events[name]['started']))
            fields = helper.pass_fields(output)
            assert fields == requirements[name], (name, fields, requirements[name])
            transcript.admit(name + '-post', baseline)
            completed.append(dict(name=name, kind=kind, arguments=args, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [binary['remote'] for binary in binaries.values()]
                probe = ('import json,os,sys; from pathlib import Path; targets=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe.removesuffix(" (deleted)") in targets: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                assert audit.decode_json(transcript.remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    path = binary['remote']
                    present = audit.decode_json(transcript.remote('owned-executable-exists-' + kind,
                        ['/usr/bin/python3', '-I', '-B', '-c', 'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))', path]))
                    assert present in ({'exists': True}, {'exists': False})
                    if present['exists']:
                        try:
                            assert transcript.remote('final-hash-' + kind, ['/usr/bin/sha256sum', path]).split() == [binary['sha256'], path]
                        except Exception as error:
                            errors.append('final hash: ' + repr(error))
                        transcript.remote('remove-owned-executable-' + kind, ['/usr/bin/rm', '--', path])
                    else:
                        errors.append('owned executable absent: ' + kind)
                transcript.remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                transcript.remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        if baseline is not None:
            try:
                transcript.admit('final', baseline)
            except Exception as error:
                errors.append('final admission: ' + repr(error))
        assert audit.current_source() == source
        for kind, target in TARGETS.items():
            audit.BUILD, audit.TARGET = RAW / ('build-' + BUILD_LABELS[kind] + '-final-' + generation), target
            _, current = audit.build_identity(source)
            assert current == {key: value for key, value in binaries[kind].items() if key != 'remote'}
    result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
        errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
        selected_cards=CARDS, selected_unique_ids=IDS, selected_bdfs=BDFS,
        generation=generation, owned_directory=directory, owned_cleanup_complete=cleaned,
        native_process_timeout_seconds=NATIVE_PROCESS_TIMEOUT_SECONDS,
        transport_timeout_seconds=TRANSPORT_TIMEOUT_SECONDS,
        exclusive_reservation=False, performance_acceptance=False, formal_refinement=False,
        scope='pending first/second/both compute sources into ordered destination lists and preserved-frame consumers; six settled/disposal/packet/gather controls; no fault injection',
        controller_sha256=sha(Path(__file__)), transport_sha256=sha(ROOT / 'capture.py'),
        oracle_sha256=sha(RAW / 'native_oracle.py'), events=transcript.events)
    if replay:
        assert result == audit.read(ROOT / 'campaign.json') and result['accepted']
        assert set(transcript.events) == {path.parent.name for path in ROOT.glob('*/result.json')}
        with (RAW / 'audit-native.json').open('x') as output:
            json.dump(result, output, sort_keys=True, indent=2)
            output.write('\n')
    else:
        with (ROOT / 'campaign.json').open('x') as output:
            json.dump(result, output, sort_keys=True, indent=2)
            output.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'events'}), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
