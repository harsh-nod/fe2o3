# Superseded CPU Generation 02

The runtime check was deliberately stopped before execution completed, after
read-only review found a native witness setup-state defect. This was not an
observation timeout or a test pass. The owned GNU timeout process group 2336984
received SIGTERM; its capture recorded exit -15 with unchanged source, and the
qualification controller exited 241. No foreign process was signaled.

The candidate witness unconditionally read back source C/D during setup,
including future outputs of pending compute gates. Native synchronous readback
normalizes H2dReady into Device; native persistent compute admission does not
accept that ordinary Device variant. Scripted CPU replay can mask this state
distinction. The established pending-list witness already avoids that readback
for pending sources.

The correction skips only the synchronous setup device readback for selected
pending outputs, preserves exact completed H2D uploads and empty-stream checks,
and leaves every post-pipeline full-source byte oracle unchanged. Settled-source
setup readbacks are unchanged. Final qualification must use later source-bound
receipts; this interrupted run is diagnostic only.
