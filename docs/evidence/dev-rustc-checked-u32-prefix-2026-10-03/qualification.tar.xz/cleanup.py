"""Remove only the exact owned remote root after checking all recorded groups and references."""
import json
from pathlib import Path
import subprocess

RAW = Path(__file__).resolve().parent
REMOTE = '/tmp/fe2o3-prefix-extraction-20261003.XEIiudDO'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-o', 'ServerAliveInterval=20', '-o', 'ServerAliveCountMax=3', 'mi300x']
code = r'''
import json,os,shutil
from pathlib import Path
root=Path('/tmp/fe2o3-prefix-extraction-20261003.XEIiudDO')
assert root.is_dir() and not root.is_symlink() and root.stat().st_uid==os.getuid()==1002
groups=[]
for receipt in sorted((root/'results').glob('*/receipt.json')):
    row=json.loads(receipt.read_text())
    assert row['group_absent'] and not row['timed_out']
    group=row['process_group']
    try:
        os.killpg(group,0)
    except ProcessLookupError:
        groups.append(group)
    else:
        raise RuntimeError(f'recorded process group still exists: {group}')
references=[]
for process in Path('/proc').iterdir():
    if not process.name.isdigit() or int(process.name)==os.getpid():
        continue
    try:
        if process.stat().st_uid!=os.getuid():
            continue
        command=(process/'cmdline').read_bytes().decode(errors='replace')
        cwd=os.readlink(process/'cwd')
        if str(root) in command or cwd==str(root) or cwd.startswith(str(root)+'/'):
            references.append(dict(pid=int(process.name),command=command,cwd=cwd))
    except (FileNotFoundError,ProcessLookupError,PermissionError):
        continue
assert not references,references
assert not list((root/'tmp').iterdir())
size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
shutil.rmtree(root)
assert not root.exists()
print(json.dumps(dict(root=str(root),root_absent=True,process_references=references,
                     process_groups_absent=groups,logical_bytes_removed=size)))
'''
out = RAW / 'cleanup'
out.mkdir()
(out / 'remote-code.py').write_text(code)
result = subprocess.run([*SSH, 'python3', '-I', '-B', '-'], input=code.encode(), capture_output=True, timeout=180)
(out / 'stdout').write_bytes(result.stdout)
(out / 'stderr').write_bytes(result.stderr)
absence = subprocess.run([*SSH, 'test', '!', '-e', REMOTE], capture_output=True, timeout=30)
(out / 'absence-stdout').write_bytes(absence.stdout)
(out / 'absence-stderr').write_bytes(absence.stderr)
receipt = dict(command=[*SSH, 'python3', '-I', '-B', '-'], exit=result.returncode,
               absence_command=[*SSH, 'test', '!', '-e', REMOTE], absence_exit=absence.returncode)
(out / 'receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode or absence.returncode)
