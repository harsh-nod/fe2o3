"""Upload changed source or run/retrieve one bounded, source-matched remote CPU command."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
REMOTE = '/tmp/fe2o3-prefix-extraction-20261003.XEIiudDO'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-o', 'ServerAliveInterval=20', '-o', 'ServerAliveCountMax=3', 'mi300x']
SCOPES = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'scripts', '.github', 'tests', 'examples', 'tools', 'toolchains', 'deployment']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def paths(*args):
    return [path.decode() for path in subprocess.check_output(['git', *args, '-z', '--', *SCOPES], cwd=ROOT).split(b'\0') if path]


def snapshot():
    return {path: digest((ROOT / path).read_bytes()) for path in sorted(set(paths('ls-files', '--cached', '--others', '--exclude-standard')))}


mode, label, *command = sys.argv[1:]
out = RAW / label
out.mkdir()
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
if mode == 'stage':
    changed = set(paths('diff', '--name-only', 'HEAD')) | set(paths('ls-files', '--others', '--exclude-standard'))
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode='w') as tar:
        for path in sorted(changed):
            tar.add(ROOT / path, arcname=path, recursive=False)
        tar.add(RAW / 'remote_run.py', arcname='remote_run.py', recursive=False)
    data = payload.getvalue()
    (out / 'payload.tar').write_bytes(data)
    result = subprocess.run([*SSH, 'tar', '-xf', '-', '-C', REMOTE], input=data, capture_output=True, timeout=120)
    receipt = dict(command=[*SSH, 'tar', '-xf', '-', '-C', REMOTE], paths=sorted(changed), payload_sha256=digest(data), exit=result.returncode)
else:
    assert mode == 'run' and command
    request = dict(label=label, sources=before, timeout=2400, command=command,
                   base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip())
    data = json.dumps(request).encode()
    (out / 'request.json').write_bytes(data)
    result = subprocess.run([*SSH, 'python3', '-I', '-B', REMOTE + '/remote_run.py'], input=data, capture_output=True, timeout=2500)
    receipt = dict(exit=result.returncode, command=[*SSH, 'python3', '-I', '-B', REMOTE + '/remote_run.py'])
    retrieved = subprocess.run([*SSH, 'tar', '-czf', '-', '-C', REMOTE + '/results/' + label, '.'], capture_output=True, timeout=120)
    receipt['retrieval_exit'] = retrieved.returncode
    (out / 'result.tar.gz').write_bytes(retrieved.stdout)
    (out / 'retrieval-stderr').write_bytes(retrieved.stderr)
    if retrieved.returncode == 0:
        with tarfile.open(fileobj=io.BytesIO(retrieved.stdout), mode='r:gz') as tar:
            for member in tar.getmembers():
                if member.isdir():
                    continue
                path = Path(member.name)
                assert member.isfile() and not path.is_absolute() and '..' not in path.parts
                selected = out / 'remote' / path
                selected.parent.mkdir(parents=True, exist_ok=True)
                selected.write_bytes(tar.extractfile(member).read())
after = snapshot()
receipt['source_unchanged'] = before == after
(out / 'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2) + '\n')
(out / 'stdout').write_bytes(result.stdout)
(out / 'stderr').write_bytes(result.stderr)
(out / 'receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
accepted_observation = before == after and receipt.get('retrieval_exit', 0) == 0
raise SystemExit(result.returncode if accepted_observation else 125)
