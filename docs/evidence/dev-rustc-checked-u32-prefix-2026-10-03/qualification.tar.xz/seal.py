"""Seal this terminal CPU qualification packet once, without changing earlier evidence."""
import hashlib
import json
from pathlib import Path
import tarfile

RAW = Path(__file__).resolve().parent
OUT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-rustc-checked-u32-prefix-2026-10-03')
archive = OUT / 'qualification.tar.xz'
assert not archive.exists() and not (RAW / 'MANIFEST.sha256').exists()
audit = json.loads((RAW / 'audit-final.json').read_text())
assert audit['remote_cleanup_checked']


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


paths = sorted(path for path in RAW.rglob('*') if path.is_file())
assert all(not path.is_symlink() for path in paths)
manifest = ''.join(f'{digest(path)}  {path.relative_to(RAW).as_posix()}\n' for path in paths)
(RAW / 'MANIFEST.sha256').write_text(manifest)
paths.append(RAW / 'MANIFEST.sha256')
temporary = OUT / 'qualification.tar.xz.tmp'
with tarfile.open(temporary, 'w:xz', preset=6) as tar:
    for path in sorted(paths):
        info = tar.gettarinfo(str(path), arcname=path.relative_to(RAW).as_posix())
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        with path.open('rb') as stream:
            tar.addfile(info, stream)
with tarfile.open(temporary) as tar:
    assert len(tar.getmembers()) == len(paths)
    for line in manifest.splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == expected
temporary.rename(archive)
sha = digest(archive)
(OUT / 'SHA256SUMS').write_text(f'{sha}  qualification.tar.xz\n')
record = dict(archive=str(archive), sha256=sha, bytes=archive.stat().st_size,
              manifest_files=len(paths)-1, source_patch_sha256=audit['source_patch_sha256'])
(RAW.parent / (RAW.name + '-seal.json')).write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record))
