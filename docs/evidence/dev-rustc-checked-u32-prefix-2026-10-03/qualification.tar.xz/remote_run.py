"""Bound one CPU command in this owned build directory and record its source cohort."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
request = json.load(sys.stdin)
label = request['label']
assert label and '/' not in label and label not in ('.', '..')
out = ROOT / 'results' / label
out.mkdir(parents=True, exist_ok=False)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, data):
    (out / name).write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')


def snapshot():
    return {path: digest(ROOT / path) for path in request['sources']}


before = snapshot()
assert before == request['sources'], 'exact uploaded source cohort'
save('source-before.json', before)
env = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8',
           CARGO_BUILD_JOBS='4', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           CARGO_PROFILE_TEST_OPT_LEVEL='0', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
           CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_NET_OFFLINE='true', RUST_TEST_THREADS='1', FE2O3_HIP_SYS_DISABLE='1',
           TMPDIR=str(ROOT / 'tmp'),
           LD_LIBRARY_PATH='/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/lib')
(ROOT / 'tmp').mkdir(exist_ok=True)
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
record = dict(command=request['command'], environment=env, started=time.time(),
              controller_sha256=digest(Path(__file__)), base=request['base'], root=str(ROOT))
save('command.json', record)
with (out / 'stdout').open('xb') as stdout, (out / 'stderr').open('xb') as stderr:
    process = subprocess.Popen(['nice', '-n', '15', *request['command']], cwd=ROOT, env=env,
                               start_new_session=True, stdout=stdout, stderr=stderr)
    record['process_group'] = process.pid
    save('running.json', record)
    timed_out = False
    try:
        code = process.wait(timeout=request['timeout'])
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
    try:
        os.killpg(process.pid, 0)
        group_absent = False
    except ProcessLookupError:
        group_absent = True
    if not group_absent:
        os.killpg(process.pid, signal.SIGTERM)
        time.sleep(2)
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
after = snapshot()
save('source-after.json', after)
record.update(exit=code, timed_out=timed_out, group_absent=group_absent,
              source_unchanged=before == after, finished=time.time(),
              stdout_sha256=digest(out / 'stdout'), stderr_sha256=digest(out / 'stderr'))
record['executables'] = {}
if code == 0 and '--message-format=json' in request['command']:
    for line in (out / 'stdout').read_text().splitlines():
        row = json.loads(line)
        path = row.get('executable') if row.get('reason') == 'compiler-artifact' else None
        if path:
            record['executables'][path] = dict(sha256=digest(Path(path)), bytes=Path(path).stat().st_size,
                                              target=row['target']['name'], test=row['profile']['test'])
save('receipt.json', record)
print(json.dumps(record), flush=True)
raise SystemExit(code if before == after and group_absent else 125)
