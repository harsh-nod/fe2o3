
import json,os,shutil
from pathlib import Path
root=Path('/tmp/fe2o3-prefix-extraction-20261003.XEIiudDO')
assert root.is_dir() and not root.is_symlink() and root.stat().st_uid==os.getuid()==1002
groups=[]
for receipt in sorted((root/'results').glob('*/receipt.json')):
    row=json.loads(receipt.read_text())
    assert row['group_absent'] and not row['timed_out']
    group=row['process_group']
    try:
        os.killpg(group,0)
    except ProcessLookupError:
        groups.append(group)
    else:
        raise RuntimeError(f'recorded process group still exists: {group}')
references=[]
for process in Path('/proc').iterdir():
    if not process.name.isdigit() or int(process.name)==os.getpid():
        continue
    try:
        if process.stat().st_uid!=os.getuid():
            continue
        command=(process/'cmdline').read_bytes().decode(errors='replace')
        cwd=os.readlink(process/'cwd')
        if str(root) in command or cwd==str(root) or cwd.startswith(str(root)+'/'):
            references.append(dict(pid=int(process.name),command=command,cwd=cwd))
    except (FileNotFoundError,ProcessLookupError,PermissionError):
        continue
assert not references,references
assert not list((root/'tmp').iterdir())
size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
shutil.rmtree(root)
assert not root.exists()
print(json.dumps(dict(root=str(root),root_absent=True,process_references=references,
                     process_groups_absent=groups,logical_bytes_removed=size)))
