"""Recheck source continuity, exact terminal receipts, real compiler cases and cleanup."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'f1788c950cfb03404841f47521db75f3fa0b3672'
SCOPES = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'scripts', '.github', 'tests', 'examples', 'tools', 'toolchains', 'deployment']
FINAL = ['build-final', 'tests-final', 'extraction-final', 'clippy-final', 'ci-clean-env', 'default-extraction', 'unsafe-extraction', 'identity-final', 'source-checks']
REMOTE = '/tmp/fe2o3-prefix-extraction-20261003.XEIiudDO'
TOOLCHAIN = '/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu'
TEST = ['cargo', '+nightly-2026-04-03', 'test', '--locked', '--offline', '-p', 'rustc-codegen-fe2o3']
SUITE = ['--lib', '--bin', 'fe2o3-rustc-extract', '--test', 'production_extraction_driver_v1']
INTEGRATION = TEST + ['--test', 'production_extraction_driver_v1']
IGNORED = ['--', '--ignored', '--exact', '--nocapture', '--test-threads=1']
EXPECTED_ARGV = {
    'build-final': TEST + SUITE + ['--no-run', '--message-format=json'],
    'tests-final': TEST + SUITE,
    'extraction-final': INTEGRATION + ['checked_u32_prefix_extraction_v1::genuine_checked_u32_prefix_extraction_uses_actual_sources_and_rejects_unsupported_profiles'] + IGNORED,
    'default-extraction': INTEGRATION + ['attributed_kernel_is_recollected_inside_a_real_amdgcn_dependency_graph'] + IGNORED,
    'unsafe-extraction': INTEGRATION + ['production_collector_rejects_reachable_unsafe_rust_with_rooted_diagnostics'] + IGNORED,
    'clippy-final': ['cargo', '+nightly-2026-04-03', 'clippy', '--locked', '--offline', '-p', 'rustc-codegen-fe2o3', '--lib', '--bin', 'fe2o3-rustc-extract', '--', '-D', 'warnings'],
    'ci-clean-env': ['env', '-u', 'LD_LIBRARY_PATH', 'bash', 'scripts/tests/ci-local-test-gate.sh'],
}
# Exact reviewed Python command bodies are retained in the corresponding request.
EXPECTED_ARGV_SHA = {
    'identity-final': '2f33c904bdc33f8c625d5c94f32e03e131e7174e7263c8be7a5c0caff10647ed',
    'source-checks': 'e2021dd8242310a0babc52828e4af1adfe161f3b05f4084b9f93c99c81b217a4',
}
EXPECTED_ENV = {
    'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '4',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_TEST_OPT_LEVEL': '0', 'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'CARGO_TARGET_DIR': REMOTE + '/target',
    'CARGO_NET_OFFLINE': 'true', 'RUST_TEST_THREADS': '1', 'FE2O3_HIP_SYS_DISABLE': '1',
    'TMPDIR': REMOTE + '/tmp',
    'LD_LIBRARY_PATH': TOOLCHAIN + '/lib:' + TOOLCHAIN + '/lib/rustlib/x86_64-unknown-linux-gnu/lib',
}
CONTROLLER_SHA = '27324e57b6b24ee45aed242f875a5268f0e2103956701880572948a0afeb7e8e'
EXPECTED = [
    'crates/rustc-codegen-fe2o3/src/bin/fe2o3-rustc-extract.rs',
    'crates/rustc-codegen-fe2o3/src/lib.rs',
    'crates/rustc-codegen-fe2o3/src/production_pipeline.rs',
    'crates/rustc-codegen-fe2o3/src/production_pipeline/checked_u32_prefix.rs',
    'crates/rustc-codegen-fe2o3/src/production_rustc_driver_v1.rs',
    'crates/rustc-codegen-fe2o3/src/production_rustc_driver_v1/checked_u32_prefix.rs',
    'crates/rustc-codegen-fe2o3/tests/fixtures/production-extraction-device/Cargo.toml',
    'crates/rustc-codegen-fe2o3/tests/fixtures/production-extraction-device/src/lib.rs',
    'crates/rustc-codegen-fe2o3/tests/production_extraction_driver_v1.rs',
    'crates/rustc-codegen-fe2o3/tests/support/checked_u32_prefix_extraction_v1.rs',
    'scripts/ci-local.sh', 'scripts/tests/ci-local-test-gate.sh',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads((RAW / path).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def names(*args):
    return [p.decode() for p in git(*args, '-z', '--', *SCOPES).split(b'\0') if p]


assert git('rev-parse', 'HEAD').decode().strip() == BASE
current = {p: sha((ROOT / p).read_bytes()) for p in sorted(set(names('ls-files', '--cached', '--others', '--exclude-standard')))}
assert current == read('stage-03/source-before.json')
changed = set(names('diff', '--name-only', BASE))
untracked = set(names('ls-files', '--others', '--exclude-standard'))
assert changed | untracked == set(EXPECTED), changed | untracked
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)

for label in ['stage-01', 'stage-02', 'stage-03']:
    receipt = read(label + '/receipt.json')
    assert receipt['exit'] == 0 and receipt['source_unchanged']
    before = read(label + '/source-before.json')
    assert before == read(label + '/source-after.json')
    payload = RAW / label / 'payload.tar'
    assert receipt['payload_sha256'] == sha(payload.read_bytes())
    with tarfile.open(payload) as tar:
        assert set(tar.getnames()) == set(receipt['paths']) | {'remote_run.py'}
        for path in receipt['paths']:
            assert sha(tar.extractfile(path).read()) == before[path]

all_runs = []
for directory in sorted(RAW.iterdir()):
    if not directory.is_dir() or not (directory / 'request.json').is_file():
        continue
    label = directory.name
    outer = read(label + '/receipt.json')
    remote = read(label + '/remote/receipt.json')
    request = read(label + '/request.json')
    before = read(label + '/source-before.json')
    assert outer['retrieval_exit'] == 0 and outer['source_unchanged']
    assert remote['source_unchanged'] and remote['group_absent'] and not remote['timed_out']
    assert outer['exit'] == remote['exit']
    assert before == read(label + '/source-after.json') == request['sources']
    assert before == read(label + '/remote/source-before.json') == read(label + '/remote/source-after.json')
    assert remote['base'] == request['base'] == BASE
    assert remote['command'] == request['command']
    assert remote['controller_sha256'] == sha((RAW / 'remote_run.py').read_bytes()) == CONTROLLER_SHA
    assert remote['environment'] == EXPECTED_ENV
    assert remote['root'] == REMOTE and request['timeout'] == 2400
    command_record = read(label + '/remote/command.json')
    assert command_record['command'] == remote['command'] and command_record['environment'] == EXPECTED_ENV
    assert read(label + '/stdout') == remote
    for output in ['stdout', 'stderr']:
        assert remote[output + '_sha256'] == sha((directory / 'remote' / output).read_bytes())
    with tarfile.open(directory / 'result.tar.gz') as tar:
        regular = [member for member in tar if member.isfile()]
        assert {Path(member.name).as_posix() for member in regular} == {
            p.relative_to(directory / 'remote').as_posix()
            for p in (directory / 'remote').rglob('*') if p.is_file()
        }
        for member in regular:
            assert tar.extractfile(member).read() == (directory / 'remote' / member.name).read_bytes()
    if label in FINAL:
        assert outer['exit'] == 0 and before == current
        if label in EXPECTED_ARGV:
            assert remote['command'] == EXPECTED_ARGV[label]
        else:
            assert sha(json.dumps(remote['command'], separators=(',', ':')).encode()) == EXPECTED_ARGV_SHA[label]
    elif label == 'build-01':
        assert outer['exit'] == 101 and before == read('stage-01/source-before.json')
    elif label == 'ci-final':
        assert outer['exit'] == 1 and before == current
        assert 'actual:   env -u LD_LIBRARY_PATH' in (directory / 'remote/stderr').read_text()
    else:
        assert label in ['build-02', 'cli-01', 'extraction-01'] and outer['exit'] == 0
        assert before == read('stage-02/source-before.json')
    all_runs.append(label)
assert set(FINAL) <= set(all_runs)

tests = (RAW / 'tests-final/remote/stdout').read_text()
assert re.findall(r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', tests, re.M) == [('517', '0'), ('18', '0'), ('0', '10')]
roster = re.findall(r'^test (\S+) \.\.\. (ok|ignored[^\n]*)$', tests, re.M)
assert sum(status == 'ok' for _, status in roster) == 535
assert sum(status.startswith('ignored') for _, status in roster) == 10

for label in ['extraction-final', 'default-extraction', 'unsafe-extraction']:
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (RAW / label / 'remote/stdout').read_text()
assert 'ci-local test gate regression passed' in (RAW / 'ci-clean-env/remote/stdout').read_text()
assert 'changed-module formatting and both shell syntax checks passed' in (RAW / 'source-checks/remote/stdout').read_text()

stderr = (RAW / 'extraction-final/remote/stderr').read_text()
cases = re.split(r'(?m)^checked-u32 case=', stderr)[1:]
expected = [
    ('checked-u32-prefix', None), ('checked-u32-prefix-second', None),
    ('checked-u32-prefix-none', 'MissingEntryHelperCheckedAdd'),
    ('checked-u32-prefix-ambiguous', 'AmbiguousEntryHelperCheckedAdd'),
    ('checked-u32-prefix,multi-root-ownership', 'RootCount'),
    ('checked-u32-prefix-unsupported', 'unsupported checked-u32 entry prefix: Source'),
]
assert len(cases) == len(expected)
reports = []
for index, (case, (feature, rejection)) in enumerate(zip(cases, expected)):
    assert case.startswith(feature + ' status=exit status: ' + ('101' if rejection else '0') + '\n')
    rows = re.findall(r'^fe2o3 checked-u32-prefix extraction: (.+)$', case, re.M)
    if rejection:
        assert rejection in case and not rows
        continue
    assert len(rows) == 1
    report = json.loads(rows[0])
    assert report['origin'] == {'argument': index}
    assert report['source_prefix_kinds'] == (['copy', 'copy'] if index == 0 else [])
    assert report['source_statement'] == len(report['source_prefix_kinds'])
    assert report['schema'] == 1 and report['canonical_kir_version'] == 8
    assert report['first_entry_only'] and report['root'] != report['function']
    for field in ['continuation_verified', 'normalization_adapters_proved', 'authenticates_compiler_execution', 'artifact_or_launch_authority']:
        assert report[field] is False
    assert report['literal'] == 17 and report['define_event'] == report['use_event'] + 1
    assert [row['argument'] for row in report['arguments']] == [0, 1]
    assert len(report['conditional_evaluations']) == 4
    for row, base in zip(report['conditional_evaluations'], [0, 0xffffffff, 0xffffffef, 0x80000000]):
        assert row['arguments'] == [base, (base + 1) & 0xffffffff]
        total = row['arguments'][index] + 17
        assert row['value'] == total & 0xffffffff
        assert row['overflow'] == (total > 0xffffffff)
    reports.append(report)
for field in ['semantic_mir_sha256', 'kir_identity_sha256']:
    assert all(re.fullmatch('[0-9a-f]{64}', report[field]) for report in reports)
    assert reports[0][field] != reports[1][field]

identity = read('identity-final/remote/stdout')
assert identity['test_scratch_empty']
assert '55e86c996809902e8bbad512cfb4d2c18be446d9' in identity['versions']['rustc']
for path, item in read('build-final/remote/receipt.json')['executables'].items():
    assert identity['files'][path] == {key: item[key] for key in ['sha256', 'bytes']}
assert any('librustc_codegen_fe2o3' in path and path.endswith('.so') for path in identity['files'])

patch = git('diff', '--binary', BASE, '--', *SCOPES)
for path in sorted(untracked):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', path], cwd=ROOT, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    patch += result.stdout
(RAW / 'source.patch').write_bytes(patch)
clean = '--after-cleanup' in sys.argv
if clean:
    cleanup = read('cleanup/receipt.json')
    assert cleanup['exit'] == 0 and cleanup['absence_exit'] == 0
    result = read('cleanup/stdout')
    assert result['root'] == REMOTE and result['root_absent'] and result['process_references'] == []
    assert sorted(result['process_groups_absent']) == sorted(read(label + '/remote/receipt.json')['process_group'] for label in all_runs)
summary = dict(base=BASE, source_files=len(current), changed_source_files=sorted(EXPECTED),
               accepted_runs=FINAL, all_runs=all_runs, library_passed=517, wrapper_passed=18,
               real_compiler_cases=6, existing_integration_tests_passed=2, reports=reports,
               artifact_identities=len(identity['files']), source_patch_sha256=sha(patch),
               proof_and_runtime_sources_unchanged=True, remote_cleanup_checked=clean)
output = 'audit-final.json' if clean else 'audit-preclean.json'
(RAW / output).write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['source_files', 'accepted_runs', 'library_passed', 'wrapper_passed', 'real_compiler_cases', 'source_patch_sha256', 'remote_cleanup_checked']}))
