#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-contract-20261004-cdj3dFci
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-conditional-fill-contract-2026-10-04"
readonly archive="$scratch/archive"
cd "$repo"
test "$(<"$scratch/qualified-1/status")" = 0
test "$(<"$scratch/final.status")" = 0
test "$(<"$scratch/host.status")" = 0
test "$(<"$scratch/regression.status")" = 0
sha256sum --check "$scratch/final-source-files.sha256"
git diff --cached --exit-code
mkdir -m 700 "$archive"
mkdir -p "$evidence"
cp -- "$scratch"/*.sh "$scratch"/*.log "$scratch"/*.sha256 "$scratch"/*.status "$archive/"
cp -a -- "$scratch/qualified-1" "$scratch/initial-host" "$archive/"
git show --format=fuller --stat HEAD > "$archive/source-commit.txt"
git diff HEAD^ HEAD -- crates Cargo.lock > "$archive/source.patch"
git -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers verify-commit HEAD > "$archive/source-signature.log" 2>&1
git diff --check HEAD^ HEAD > "$archive/whitespace.log" 2>&1
rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true \
    crates/fe2o3-host/src/lib.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/pending.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/subject.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/contract.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/contract/tests.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_pending.rs > "$archive/rustfmt.log" 2>&1
test -z "$(ls -A "$scratch/qualified-1/tmp")"
test ! -e /opt/fe2o3/verus-runtime-v2/functional-refinement-0.2026.08.02-b677dd5
/mnt/c/Windows/System32/wsl.exe --user root --exec /bin/rm -r -- "$scratch/root"
test ! -e "$scratch/root"
printf '%s\n' 'Final CPU and protected qualification scripts exited 0.' \
    'The owned test TMPDIR is empty.' \
    'No protected runtime installation exists at the host /opt path.' \
    'The exact owned root library overlay was removed after the namespace exited.' \
    'No MI300X resources were used.' > "$archive/cleanup.log"
cd "$archive"
find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
tar -czf "$evidence/evidence.tar.gz" .
sha256sum "$evidence/evidence.tar.gz" source.patch
