#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-contract-20261004-cdj3dFci
test "$(<"$scratch/host.status")" = 0
mkdir "$scratch/initial-host"
mv -- "$scratch/host-tests.log" "$scratch/host-doc-tests.log" "$scratch/verifier-tests.log" \
    "$scratch/host-clippy.log" "$scratch/host.status" "$scratch/initial-host/"
trap 'printf "%s\n" "$?" > "$scratch/final.status"' EXIT
bash "$scratch/run-host.sh"
bash "$scratch/regression.sh"
