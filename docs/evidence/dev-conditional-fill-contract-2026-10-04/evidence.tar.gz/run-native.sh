#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-contract-20261004-cdj3dFci
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly worker="$repo/target/qualification-native-workers/fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715"
readonly run="$scratch/${1:?fresh run name}"
readonly worker_build_id="$(<"$worker/fe2o3-worker-build-id.txt")"
mkdir -m 700 "$run" "$run/tmp" "$run/captures" "$run/runtime"
trap 'printf "%s\n" "$?" > "$run/status"' EXIT
timeout --kill-after=15s 1500s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" /usr/bin/env \
    TMPDIR="$run/tmp" XDG_RUNTIME_DIR="$run/runtime" \
    FE2O3_TEST_REAL_WORKER="$worker/fe2o3-llvm-link-worker" \
    FE2O3_TEST_REAL_WORKER_BUILD_ID="$worker_build_id" FE2O3_TEST_REAL_LLVM_BUILD_ID=7.2.4 \
    FE2O3_TEST_HSACO_WORKER_FIXTURE="$repo/target/debug/fe2o3-worker-v3-hsaco-fixture" \
    FE2O3_PENDING_FILL_CAPTURE="$run/captures" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
    --test worker_v3_load_envelope_vertical \
    conditional_fill_pending::genuine_fill_pending_retains_original_evidence_and_currentness \
    -- --ignored --exact --nocapture --test-threads=1 > "$run/test.log" 2>&1
test -z "$(ls -A "$run/tmp")"
