#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-contract-20261004-cdj3dFci
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/host.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1
unset RUST_TEST_THREADS
cargo +nightly-2026-04-03 test --locked -p fe2o3-host --lib > "$scratch/host-tests.log" 2>&1
cargo +nightly-2026-04-03 test --locked -p fe2o3-host --doc -- --test-threads=4 > "$scratch/host-doc-tests.log" 2>&1
cargo +nightly-2026-04-03 test --locked -p fe2o3-verifier --lib conditional_fill -- --test-threads=4 > "$scratch/verifier-tests.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked -p fe2o3-host --tests --no-deps -- -D warnings > "$scratch/host-clippy.log" 2>&1
