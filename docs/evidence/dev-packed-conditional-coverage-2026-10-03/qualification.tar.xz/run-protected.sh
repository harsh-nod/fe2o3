#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-packed-coverage-20261003-ig4KcH
if [[ ${1:-all} == all ]]; then
timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-verifier --lib protected_runtime_conditional_coverage \
    -- --ignored --nocapture >"$scratch/protected-conditional.log" 2>&1
tail -n 12 "$scratch/protected-conditional.log"
fi
timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p rustc-codegen-fe2o3 --test production_extraction_driver_v1 write_only_output_genuine \
    -- --ignored --nocapture \
    >"$scratch/protected-fill.log" 2>&1
tail -n 12 "$scratch/protected-fill.log"
