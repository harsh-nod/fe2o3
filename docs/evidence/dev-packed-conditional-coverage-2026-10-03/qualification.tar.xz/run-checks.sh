#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-packed-coverage-20261003-ig4KcH
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib >"$scratch/host.log" 2>&1
tail -n 4 "$scratch/host.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --doc >"$scratch/ownership.log" 2>&1
tail -n 4 "$scratch/ownership.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --test compiler_proof_binding_v4 >"$scratch/import.log" 2>&1
tail -n 4 "$scratch/import.log"
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-host -p rustc-codegen-fe2o3 --lib --no-deps -- -D warnings >"$scratch/clippy.log" 2>&1
tail -n 4 "$scratch/clippy.log"
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check \
    crates/fe2o3-host/src/generated_argument_plan.rs \
    crates/fe2o3-host/src/generated_conditional_coverage.rs \
    crates/fe2o3-host/src/generated_conditional_coverage_tests.rs \
    crates/fe2o3-host/src/generated_kfd_arguments.rs crates/fe2o3-host/src/lib.rs \
    crates/fe2o3-host/src/generated_runtime_arguments.rs \
    crates/fe2o3-host/src/generated_runtime_arguments/charged_tests.rs \
    crates/rustc-codegen-fe2o3/tests/production_extraction_driver_v1.rs \
    crates/rustc-codegen-fe2o3/tests/support/conditional_output_packing_v1.rs >"$scratch/formatting.log" 2>&1
git diff --check >"$scratch/whitespace.log" 2>&1
