# Bound Cancellation Qualification Commands And Scope

Repository: /home/harsh/.codex-tmp/fe2o3-r61-execution
Branch: codex/r65-runtime-drain-versions
Production/CPU/proof commit: b87580f30dc76c3bcda5703fb73ffd23ea3c718a
Final checker-only commit: cb45869762adcd2421da46f2ba6de5c73ea26fa6
Raw root: /home/harsh/.codex-tmp/fe2o3-bound-cancel-20260928-qyK0X5dO

Primary owned edits, integration, builds, solvers and publishing. Native
collaboration agents reviewed proof, production correspondence, tests and the
next composition boundary read-only. No Qwen worker was invoked. No remote
MI300X command, GPU run, resource cleanup or benchmark occurred in this packet.
Unrelated docs/evidence/dev-owner-inspection-2026-09-23/ remains untouched.

## CPU Qualification

Commands ran serially with no competing source edit or agent-owned build.
Build environment: CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2.
Toolchain: nightly-2026-04-03; full rustc -vV is in toolchain.txt.
Test processes ran under prlimit --core=0:0.

The following commands all reached terminal exit status zero:

```sh
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-kfd --all-features --lib \
  queue::completion -- --nocapture
prlimit --core=0:0 -- target/debug/deps/fe2o3_kfd-65695dc23b288bd0 \
  --skip queue::live::construction_primary
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-runtime --all-features --lib
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 clippy -p fe2o3-kfd -p fe2o3-runtime \
  --all-features --all-targets -- -D warnings
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 check -p fe2o3-kfd -p fe2o3-runtime \
  --no-default-features
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-kfd -p fe2o3-runtime \
  -p fe2o3-runtime-model --all-features --doc
cargo +nightly-2026-04-03 fmt --all -- --check
rustfmt +nightly-2026-04-03 --check --edition 2024 \
  crates/fe2o3-kfd/src/queue_completion/bound_cancel_body.rs \
  crates/fe2o3-kfd/src/queue_completion/bound_cancel_tests.rs
git diff --check
```

Logs: completion-tests.log 52/0; kfd-regression.log 1412/0 with 320 excluded
construction-primary tests; runtime-full.log 1828/0 with 30 hardware ignores;
doctests.log 42 KFD + 9 runtime compile-fail + 44 runtime + 29 model = 124/0.
This is not a full KFD rerun. The previous packet's full 1726-test result is not
transferred to this source. clippy.log, production-check.log, fmt.log,
included-fmt.log and diff-check.log contain the static check outputs.
Workspace/included-source formatting and diff checks were repeated after the
documentation edit; the corresponding *-final.log files also exit zero.

The source-files-before.sha256 bracket starts after focused compilation, before
the broad KFD run. source-files-after.log verifies all seven files after the
remaining CPU/static checks. source-files-final.sha256 records the final signed
source: only checker and calibration changed after the CPU bracket.
checker-only-diff.log records that distinction. Both test ELF hashes are
recorded, but binaries and build intermediates are not archived. This does not
claim a hermetic source-to-machine-code proof.

## Verus Qualification

Pinned binary:
/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
Pinned Z3 is its sibling z3. The campaign records the complete tool closure.

Development proof-1 failed frontend trigger inference; proof-2 and proof-3
contain intermediate logical failures while constructing bitmap/frame proofs.
proof-4 passes 23 obligations before constructed witnesses. proof-5 and proof-6
pass 25 obligations; proof-6 includes the late-pinned witness. These are
development evidence, not authenticated negative controls. Their solver form:

```sh
env VERUS_Z3_PATH=/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/z3 \
  /usr/bin/timeout --foreground --signal=TERM --kill-after=5 120 \
  /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus \
  --crate-type lib --triggers-mode silent --no-cheating --output-json \
  --error-format=json --no-report-long-running --num-threads 4 --multiple-errors 2 \
  crates/fe2o3-runtime-model/verus/completion_bound_cancel_v1.rs
```

calibration.log and calibration-final.log each pass four synthetic groups:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/test-completion-bound-cancel.py
```

The first signed campaign (campaign/, campaign.log) stops at its opening proof:
status zero and 25 verified/zero errors, but strict classification rejects an
unknown informational bitvector-enumeration note under --multiple-errors 0.
No mutation qualified in this failed campaign. It is retained without editing.
The checker-only fix recognizes the exact note, not an error message or generic
prefix. Historical SHA-authenticated controller and classifier files are unchanged.
Calibration rejects error-level/unknown/foreign-source/nested-error/resource
variants and note-only negative evidence.

The final campaign (campaign-final/, campaign-final.log) exits zero and passes
31 owned stages, including 23 strictly classified logical mutants. Each stage
has its exact command, exit status, process-group receipt and stdout/stderr.
Opening/relocated/closing positives each report 25 verified obligations, zero
errors. Whole-source before/after and pinned tool closure match. Ten obligations
are derived Clone checks; this is not 25 separate runtime operations.

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-bound-cancel.py \
  --output /home/harsh/.codex-tmp/fe2o3-bound-cancel-20260928-qyK0X5dO/campaign-final \
  --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
```

source-signature.log independently verifies the final signed source commit.
issue-182.json records OPEN, updated 2026-09-27T10:25:24Z.

## Scope

Complete raw host-ledger cancellation only. No input premise authenticates the
roster or requires Ready. Bounds follow executed validation. First pin failure
and exact returned retention are proved. Success has a phase-only frame.
Actual 128-word bitmap, Box arrays and opaque non-Copy ledger are modeled;
identity wrappers project to u64. CPU refusal tests also inspect both actual
Box addresses, which are outside the logical proof.

No allocator, machine-code, native currentness/publication, ledger cardinality,
batch-release composition, device overlap or performance claim. Full source
rollback must preserve the real short-circuit cleanup prefixes and token-discard
adapters: event release can succeed before cancellation fails and terminalizes.
The next work is complete batch release with its two allocation boundaries,
then dispatch cancellation and native callback frames, plus recording freshness
and pin increment proofs. A1/A2, #182 and overall parity remain incomplete.
