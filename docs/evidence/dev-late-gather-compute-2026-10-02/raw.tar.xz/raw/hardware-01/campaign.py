#!/usr/bin/env python3
"""Exact late-gather native campaign; no production authority or overlap claim."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '3c8afa96a2a9f0cb71da500b125054ce08153824'
TARGET = 'gfx942-runtime-deferred-peer-chain-smoke'
PREFIX = '/tmp/fe2o3-late-gather-compute-20261002-'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0xb7baafd0fb173d8e', '0x10a254ce4987e716', '0x53691ef168a0147d']
GATHER4 = ['0x54f88318ca05093d', *IDS]
CARDS = ['card4', 'card5', 'card6', 'card7']
BDFS = ['0000:85:00.0', '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
CASES = [
    ('late-three-disjoint-forward', '--late-gather-compute', IDS),
    ('late-three-disjoint-reverse', '--late-gather-compute', IDS[::-1]),
    ('late-three-overlap-forward', '--late-gather-compute-overlap', IDS),
    ('late-three-overlap-reverse', '--late-gather-compute-overlap', IDS[::-1]),
    ('late-four-disjoint-forward', '--late-gather-compute', GATHER4),
    ('late-four-disjoint-reverse', '--late-gather-compute', GATHER4[::-1]),
    ('late-four-overlap-forward', '--late-gather-compute-overlap', GATHER4),
    ('late-four-overlap-reverse', '--late-gather-compute-overlap', GATHER4[::-1]),
    ('prequeued-three-disjoint-forward', '--gather-compute', IDS),
    ('prequeued-three-disjoint-reverse', '--gather-compute', IDS[::-1]),
    ('prequeued-three-overlap-forward', '--gather-compute-overlap', IDS),
    ('prequeued-three-overlap-reverse', '--gather-compute-overlap', IDS[::-1]),
    ('prequeued-four-disjoint-forward', '--gather-compute', GATHER4),
    ('prequeued-four-disjoint-reverse', '--gather-compute', GATHER4[::-1]),
    ('prequeued-four-overlap-forward', '--gather-compute-overlap', GATHER4),
    ('prequeued-four-overlap-reverse', '--gather-compute-overlap', GATHER4[::-1]),
    ('direct-late-forward', '--late-compute', IDS[1:]),
    ('direct-late-reverse', '--late-compute', IDS[1:][::-1]),
]
LIMITATIONS = [
    'point observations, not continuous attachment census or exclusive reservation',
    'finite unchanged R57 qualification authority, not general kernel authorization',
    'late publication capture is timing-dependent and rejects a missed interval',
    'oldest identity follows ordered-roster inference, not a per-root public observer',
    'paired custody is validated by real consumer admission, not directly exported',
    'retained native ownership does not prove an active GPU fence or physical overlap',
    'one pipeline batch per process; no repeated expired-deadline resumption claim',
    'logical owner byte guards do not cover hidden physical pool padding',
    'native faults, arbitrary graphs, performance and formal refinement are unqualified',
    'direct late controls do not observe full source preservation',
]
BASELINE = None


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_receipt(name, argv):
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout, stderr = ((folder / item).read_bytes() for item in ('stdout', 'stderr'))
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert receipt['exit_code'] == 0 and not receipt['timed_out'], (name, receipt, stderr)
    assert receipt['local_process_group_absent'], (name, receipt)
    return receipt, stdout, stderr


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    receipt, stdout, stderr = read_receipt(name, argv)
    assert process.returncode == receipt['exit_code'], (name, receipt, stderr)
    return stdout.decode()


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def remote(name, argv, bound='30s'):
    return capture(name, remote_argv(argv, bound))


def admit(name):
    state = json.loads(remote(name + '-availability', AVAILABILITY))
    for card, uid, bdf in zip(CARDS, GATHER4, BDFS):
        assert state[card]['Unique ID'] == BASELINE[card]['Unique ID'] == uid
        assert state[card]['PCI Bus'] == BASELINE[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == BASELINE[card]['GPU use (%)'] == '0'
        for field in ('VRAM Total Memory (B)', 'VRAM Total Used Memory (B)'):
            assert state[card][field] == BASELINE[card][field]
    assert state['system'] == BASELINE['system'], 'PID roster changed; reject and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
        assert pid not in records and not {'4', '5', '6', '7'}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024


def expected(flag, ids):
    assert len(ids) == len(set(ids))
    if flag == '--late-compute':
        assert len(ids) == 2
        output = b''.join(struct.pack('<f', (index & 63) / 4 + (index & 31))
                          for index in range(65536))
        fields = dict(schema='fe2o3.late-deferred-peer-chain-smoke.v1',
            authority='qualification-r57-n3-v2', devices='2', unique_ids=','.join(ids),
            elements='65536', bytes='262144', padding_bytes='0', launches='4',
            setup_launches='3', pipeline_launches='1', peer_copies='2',
            dependent_readbacks='1', completion_receipts='4',
            pipeline='peer-deferred-compute-peer-readback',
            admission='consumer-tail-after-first-native-publication',
            compute_admission='deferred-after-first-peer-publication',
            progress='first-peer-until-retained-then-final-readback-only',
            public_events='released-after-dependent-admission', native_transport='NATIVE-XGMI',
            native_counter='0,2', initial_peer_sentinel='full-byte-pass',
            final_peer_sentinel='full-byte-pass', output='full-byte-pass',
            padding='exact-page-extent', output_sha256=sha(output),
            snapshot='settled-host-visible-owner-command', host_output_installations='0',
            journal='enabled', retained_results='4', allocations='12', modules='2',
            streams='5', contexts='1', owners='1', pipeline_host_joins='0',
            results_release='readback-peer-compute-peer', final_drain='completed-only',
            cleanup='owned-shutdown-explicit', source_preservation='unobserved',
            physical_overlap='unmeasured', performance_acceptance='false', formal_refinement='false',
            initial_peer='directed', retained_native_at_compute_admission='1',
            retained_native_counter='0,1,0', publication_observed='true')
        assert len(fields) == 46
        return fields
    assert flag in ('--gather-compute', '--gather-compute-overlap',
                    '--late-gather-compute', '--late-gather-compute-overlap')
    assert len(ids) in (3, 4)
    late, overlap = flag.startswith('--late-'), flag.endswith('-overlap')
    count, extent = len(ids) - 1, 65536 * 4
    windows, end = [], 64
    for index in range(count):
        source = 4 * (1 + 7 * index)
        destination = end if index == 0 else end + (-48 if overlap else 28)
        size = (((extent - 512) // count) & ~3) - 4 * index
        assert source + size <= extent and destination + size < extent
        windows.append((source, destination, size))
        end = destination + size
    source = b''.join(struct.pack('<f', (index & 63) * 0.25 + (index & 31))
                      for index in range(65536))
    gathered = bytearray(struct.pack('<f', 0.25) * 65536)
    for source_offset, destination, size in windows:
        gathered[destination:destination + size] = source[source_offset:source_offset + size]
    computed = b''.join(struct.pack('<f', struct.unpack_from('<f', gathered, 4 * index)[0]
                                   + (index & 31) * 0.5) for index in range(65536))
    returned = bytearray([0xa5]) * (extent + 769)
    returned[131:131 + extent - 64] = computed[20:extent - 44]
    host = bytearray([0x5a]) * (extent + 1153)
    host[97:97 + len(returned)] = returned
    assert len(gathered) == len(computed) == extent
    assert len(returned) == extent + 769 and len(host) == extent + 1153
    framed = b'fe2o3.gather-compute.v1\0' + b''.join(
        struct.pack('<Q', len(data)) + data
        for data in [*[source] * count, gathered, computed, returned, host])
    fields = dict(schema='fe2o3.gather-compute.v1', authority='qualification-r57-n3-v2',
        devices=str(len(ids)), sources=str(count), unique_ids=','.join(ids),
        overlap=str(overlap).lower(), windows=','.join(':'.join(map(str, window)) for window in windows),
        elements='65536', bytes=str(extent), setup_launches=str(len(ids)),
        pipeline_launches=str(count + 1), peer_copies=str(count + 1), dependent_readbacks='1',
        completion_receipts=str(2 * count + 3), pipeline='compute-gather-compute-peer-readback',
        admission='all-before-explicit-progress', progress='final-readback-stream-only',
        public_events='released-after-dependent-admission', consumer_dependencies='latest-gather-only',
        consumer_bindings='full-frame-read-stable-read-full-write', native_transport='NATIVE-XGMI',
        native_counter=f'0,{count + 1}', output='full-byte-pass', source_preservation='full-byte-pass',
        gathered_frame='full-byte-pass', return_guards='full-byte-pass', host_guards='full-byte-pass',
        output_sha256=sha(framed), digest='length-prefixed-sources-C-D-E-host',
        host_output_installations='0', pipeline_host_joins='0', journal='enabled', contexts='1',
        owners='1', batches='1', results_release='reverse-dependencies', final_drain='completed-only',
        cleanup='owned-shutdown-explicit', physical_overlap='unmeasured',
        performance_acceptance='false', formal_refinement='false')
    if late:
        fields.update(schema='fe2o3.late-gather-compute.v1',
            admission='gather-preadmitted-consumer-after-oldest-publication',
            progress='oldest-peer-seed-then-final-readback-stream-only',
            publication_observed='true', publication_identity='ordered-roster-inference',
            paired_custody='validated-by-consumer-admission',
            retained_native_at_consumer_admission='1', retained_native_counter='0,1,0',
            publication_capture='timing-dependent-fail-closed', oldest_seed='bounded-context-drain')
    assert len(fields) == (48 if late else 41)
    return fields


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    result = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in result
        result[key] = value
    return result


def build_witness():
    folder = ROOT.parent / 'build-witness'
    receipt = json.loads((folder / 'receipt.json').read_text())
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO)
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '900s',
        'cargo', 'build', '--locked', '--offline', '-p', 'fe2o3-runtime',
        '--no-default-features', '--features', 'hardware-qualification', '--example', TARGET,
        '--profile', 'test', '--message-format=json']
    for name in ('stdout', 'stderr'):
        assert sha((folder / name).read_bytes()) == receipt[name + '_sha256']
    before = json.loads((folder / 'source-before.json').read_text())
    assert before == json.loads((folder / 'source-after.json').read_text())
    listing = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard',
        '-z', '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=REPO, env=receipt['environment'])
    current = {name: sha((REPO / name).read_bytes())
               for name in sorted(set(os.fsdecode(listing).rstrip('\0').split('\0')))}
    assert current == before, 'complete current inventory differs from witness build'
    local = REPO / 'target/debug/examples' / TARGET
    assert set(receipt['executables']) == {str(local)}
    identity = receipt['executables'][str(local)]
    assert identity['target'] == TARGET and identity['test'] is False
    assert local.is_file() and not local.is_symlink()
    assert len(local.read_bytes()) == identity['byte_length'] and sha(local.read_bytes()) == identity['sha256']
    return dict(local=str(local), sha256=identity['sha256'], byte_length=identity['byte_length'],
                build_receipt_sha256=sha((folder / 'receipt.json').read_bytes()),
                source_manifest_sha256=sha((folder / 'source-before.json').read_bytes()))


def main():
    global BASELINE
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1 and not (ROOT / 'campaign.json').exists()
    assert len(CASES) == len({name for name, _, _ in CASES}) == 18
    binary = build_witness()
    completed, errors, directory, cleaned = [], [], None, False
    try:
        BASELINE = json.loads(remote('initial-availability', AVAILABILITY))
        receipt, _, stderr = read_receipt('initial-availability', remote_argv(AVAILABILITY))
        assert not stderr
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(receipt['finished'])).total_seconds()
        assert 0 <= age <= 300
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', PREFIX + 'XXXXXX']).strip()
        assert re.fullmatch(re.escape(PREFIX) + '[A-Za-z0-9]{6}', candidate)
        directory = candidate
        binary['remote'] = directory + '/deferred-witness'
        capture('upload-witness', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
            '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
        assert remote('initial-hash', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
        for name, flag, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8',
                binary['remote'], flag, *ids], '180s')
            fields = pass_fields(output)
            required = expected(flag, ids)
            assert fields == required, (name, fields, required)
            assert not (ROOT / name / 'stderr').read_bytes()
            admit(name + '-post')
            completed.append(dict(name=name, flag=flag, unique_ids=ids, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                path = binary['remote']
                probe = ('import json,os,sys; from pathlib import Path; '
                    'target=sys.argv[1]; found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe.removesuffix(" (deleted)")==target: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, path])
                assert json.loads(observed) == {'owned_executable_pids': []}
                exists = remote('owned-executable-exists', ['/usr/bin/python3', '-I', '-B', '-c',
                    'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))', path])
                present = json.loads(exists)
                assert present in ({'exists': True}, {'exists': False})
                if present['exists']:
                    try:
                        assert remote('final-hash', ['/usr/bin/sha256sum', path]).split() == [binary['sha256'], path]
                    except Exception as error:
                        errors.append('final hash: ' + repr(error))
                    remote('remove-owned-executable', ['/usr/bin/rm', '--', path])
                else:
                    errors.append('final hash: owned witness absent')
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        if BASELINE is not None:
            try:
                admit('final')
            except Exception as error:
                errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == 18 and cleaned,
            errors=errors, completed=completed, expected_cases=18, new_late_cases=8,
            prequeued_controls=8, direct_late_controls=2, binary=binary,
            owned_directory=directory, owned_cleanup_complete=cleaned,
            exclusive_reservation=False, performance_acceptance=False, formal_refinement=False,
            controller_sha256=sha(Path(__file__).read_bytes()),
            transport_sha256=sha((ROOT / 'capture.py').read_bytes()), limitations=LIMITATIONS)
        with (ROOT / 'campaign.json').open('x') as output:
            json.dump(result, output, indent=2)
            output.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
