# Native Late Gathered-Frame Consumer

Baseline: 3c8afa96a2a9f0cb71da500b125054ce08153824.
Previous goal turn: progress. Generated ordinary Context arguments were
implemented, independently reviewed, CPU-qualified, signed and pushed to both
repositories. The full parity goal remains active and incomplete.

Current priority is actual native late gathered-frame consumer admission.
Preadmit all pending source computes and ordered gather peers, observe the sole
oldest native peer retained after publication with no completed native copies,
then admit the consumer using only the exact latest gather event. After seeding,
drive final readback only and validate complete outputs, guards and owner cleanup.

The ordinary public API has no exact single-step peer progress operation.
Bounded public drain calls may miss a fast publication interval. The witness
must reject such a miss, not infer publication from a duration or step count.
Retained count1/completed0 plus the common-destination predecessor chain identify
the oldest root. The aggregate counter is not a direct inspection of both child
reservation slots; genuine consumer admission validates those internal premises.
Native overlap, general kernel authority, whole-adapter formal refinement and
performance acceptance remain unclaimed.

Agent multigpu_host_admission owns the deferred witness and its gather child.
Agents xgmi_integration_review and xgmi_source_ci review admission semantics and
the independent native matrix. Root owns controller edits, CPU/native execution,
evidence, final integration and Git. No Qwen worker is used.

MI300X was reachable in a preliminary read-only observation. Cards4-7 appeared
idle at ordinary baseline VRAM; GPU0 retained other work. This is not a reservation
or final admission. Every hardware case must check fresh UID/BDF, use, VRAM,
process roster, attachments and host memory. Only owned binaries and a fresh
owned scratch directory may be removed; no resets or foreign process termination.

Implementation is confined to two example files. Independent review found no
remaining witness issue. All thirteen example tests and 2,198 runtime library
tests pass, with 32 existing hardware ignores. Strict example Clippy, selected
Rust formatting and whitespace checks pass. Exact test rosters are captured.

The root delegated new raw controller editing to xgmi_source_ci. The controller
uses eighteen cases: eight late, eight matching prequeued and two direct late
controls. Root and the implementation agent reviewed it. Review repaired a
cleanup edge case: hash/upload failure must not stop exact-owned cleanup after
owned-process absence. The final controller is pinned by the closing audit.

The next bounded native packet can qualify generated encoding under the exact
unchanged R57 gate. Three ordinary f32 slice descriptors match its 48-byte ABI,
but the generated host signature differs from the R57 qualification policy.
A private qualification adapter may delegate encoding and bindings, compare
them exactly against existing R57 arguments for the same handles, and retain
the existing finite policy signature. That would test generated encoding only,
not generated Rust-to-HSACO correctness or a production proof provider. No such
adapter is implemented or claimed in this checkpoint.

Final native campaign and independent closing audit accepted all eighteen cases
without retry, with 136 exact successful callbacks and sixty logical native peer
copies. Local and both remote witness hashes match. Every pre/post admission and
the final shared-host baseline check passes; the owned process is absent and
the exact executable and scratch directory are removed. The late-gather gate
is closed for this finite profile. A3 and the full parity goal remain incomplete.
