"""Independently close source-bound CPU and native qualification receipts."""

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
from datetime import datetime

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '3c8afa96a2a9f0cb71da500b125054ce08153824'
CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
EXAMPLE = 'gfx942-runtime-deferred-peer-chain-smoke'
CARGO = ['cargo']
COMMON = ['--locked', '--offline', '-p', 'fe2o3-runtime']
WITNESS = [*COMMON, '--no-default-features', '--features', 'hardware-qualification', '--example', EXAMPLE]
LIB = [*COMMON, '--all-features', '--lib']


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


assert sha(RAW / 'capture.py') == CAPTURE_SHA
capture = module('capture', RAW / 'capture.py')
source = capture.snapshot()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
subprocess.run(['git', 'diff', '--exit-code', BASE, '--', 'crates/fe2o3-runtime/src',
                'crates/fe2o3-kfd', 'crates/fe2o3-runtime-model', 'Cargo.lock', 'Cargo.toml'],
               cwd=REPO, check=True)
jobs = [
    ('example-tests', '900s', CARGO + ['test', *WITNESS]),
    ('example-list', '120s', CARGO + ['test', *WITNESS, '--', '--list']),
    ('runtime-tests', '900s', CARGO + ['test', *LIB, '--', '--test-threads=1']),
    ('runtime-list', '120s', CARGO + ['test', *LIB, '--', '--list']),
    ('build-witness', '900s', CARGO + ['build', *WITNESS, '--profile', 'test', '--message-format=json']),
    ('clippy', '900s', CARGO + ['clippy', *WITNESS, '--no-deps', '--', '-D', 'warnings']),
    ('format', '120s', ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
        '--config', 'skip_children=true',
        'crates/fe2o3-runtime/examples/deferred_peer_chain/gather_compute.rs',
        'crates/fe2o3-runtime/examples/gfx942-runtime-deferred-peer-chain-smoke.rs']),
    ('whitespace', '60s', ['git', 'diff', 'HEAD', '--check']),
    ('hardware', '1800s', ['python3', '-I', '-B', str(RAW / 'hardware-01/campaign.py')]),
]
selected = {}
for label, seconds, command in jobs:
    folder = RAW / label
    receipt = read(folder / 'receipt.json')
    invocation = read(folder / 'command.json')
    assert all(receipt[key] == value for key, value in invocation.items()), label
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', seconds, *command], label
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, label
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO), label
    assert receipt['controller_sha256'] == CAPTURE_SHA and receipt['environment'] == capture.ENV, label
    assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == source, label
    for output in ['stdout', 'stderr']:
        assert sha(folder / output) == receipt[output + '_sha256'], label
    selected[label] = {'receipt_sha256': sha(folder / 'receipt.json')}

for label, listing, passed, ignored in [
    ('example-tests', 'example-list', 13, 0), ('runtime-tests', 'runtime-list', 2198, 32),
]:
    output = (RAW / label / 'stdout').read_text()
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; 0 filtered out;', output, re.M)
    assert summaries == [(str(passed), '0', str(ignored))], label
    outcomes = re.findall(r'^test (.+?) \.\.\. (ok|ignored(?:, [^\n]*)?)$', output, re.M)
    roster = re.findall(r'^(.+): test$', (RAW / listing / 'stdout').read_text(), re.M)
    assert len(roster) == len(set(roster)) == passed + ignored, label
    assert sorted(name for name, _ in outcomes) == sorted(roster), label
    assert sum(result == 'ok' for _, result in outcomes) == passed, label
    selected[label]['passed'] = passed
    selected[label]['ignored'] = ignored

binary = REPO / 'target/debug/examples' / EXAMPLE
artifact = read(RAW / 'build-witness/receipt.json')['executables']
assert artifact == {str(binary): {'byte_length': binary.stat().st_size, 'sha256': sha(binary),
                                  'target': EXAMPLE, 'test': False}}

HARDWARE = RAW / 'hardware-01'
CONTROLLER_SHA = 'b2cd8630d136d415ec5ac4809b7df43d67960a5dde733c38e94ea93d81cd7a01'
TRANSPORT_SHA = 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f'
assert sha(HARDWARE / 'campaign.py') == CONTROLLER_SHA
assert sha(HARDWARE / 'capture.py') == TRANSPORT_SHA
campaign = module('campaign', HARDWARE / 'campaign.py')
native = read(HARDWARE / 'campaign.json')
assert native['accepted'] is True and native['errors'] == []
assert native['expected_cases'] == 18 and len(native['completed']) == 18
assert (native['new_late_cases'], native['prequeued_controls'], native['direct_late_controls']) == (8, 8, 2)
assert native['owned_cleanup_complete'] is True
assert not native['exclusive_reservation'] and not native['performance_acceptance'] and not native['formal_refinement']
assert native['controller_sha256'] == CONTROLLER_SHA and native['transport_sha256'] == TRANSPORT_SHA
assert native['binary']['local'] == str(binary) and native['binary']['sha256'] == sha(binary)
assert native['binary']['byte_length'] == binary.stat().st_size
assert native['binary']['build_receipt_sha256'] == sha(RAW / 'build-witness/receipt.json')
assert native['binary']['source_manifest_sha256'] == sha(RAW / 'build-witness/source-before.json')
directory = native['owned_directory']
assert re.fullmatch(r'/tmp/fe2o3-late-gather-compute-20261002-[A-Za-z0-9]{6}', directory)
remote_binary = directory + '/deferred-witness'
assert native['binary']['remote'] == remote_binary
outer = read(RAW / 'hardware/receipt.json')
last = datetime.fromisoformat(outer['started'])
assert datetime.fromisoformat(read(RAW / 'build-witness/receipt.json')['finished']) <= last
events = {}


def event(name, argv=None):
    global last
    folder = HARDWARE / name
    receipt = read(folder / 'result.json')
    if argv is not None:
        assert receipt['argv'] == argv, name
    assert receipt['exit_code'] == 0 and not receipt['timed_out'] and receipt['local_process_group_absent'], name
    started, finished = (datetime.fromisoformat(receipt[key]) for key in ('started', 'finished'))
    assert last <= started <= finished, name
    last = finished
    for output in ['stdout', 'stderr']:
        assert sha(folder / output) == receipt[output + '_sha256'], name
    assert not (folder / 'stderr').read_bytes(), name
    events[name] = {'receipt_sha256': sha(folder / 'result.json'), 'started': receipt['started'], 'finished': receipt['finished']}
    return (folder / 'stdout').read_text()


baseline = json.loads(event('initial-availability', campaign.remote_argv(campaign.AVAILABILITY)))


def admission(name):
    state = json.loads(event(name + '-availability', campaign.remote_argv(campaign.AVAILABILITY)))
    for card, uid, bdf in zip(campaign.CARDS, campaign.GATHER4, campaign.BDFS):
        assert state[card]['Unique ID'] == baseline[card]['Unique ID'] == uid
        assert state[card]['PCI Bus'] == baseline[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0'
        for field in ('VRAM Total Memory (B)', 'VRAM Total Used Memory (B)'):
            assert state[card][field] == baseline[card][field]
    assert state['system'] == baseline['system']
    mapping = event(name + '-attachments', campaign.remote_argv(['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus']))
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
        assert pid not in records and not {'4', '5', '6', '7'}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = event(name + '-host-memory', campaign.remote_argv(['/usr/bin/cat', '/proc/meminfo']))
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024


admission('baseline')
assert event('create-scratch', campaign.remote_argv(['/usr/bin/mktemp', '-d', campaign.PREFIX + 'XXXXXX'])).strip() == directory
event('upload-witness', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o',
                        'StrictHostKeyChecking=yes', str(binary), 'mi300x:' + remote_binary])
assert event('initial-hash', campaign.remote_argv(['/usr/bin/sha256sum', remote_binary])).split() == [sha(binary), remote_binary]
callbacks, copies = 0, 0
assert len(campaign.CASES) == len({name for name, _, _ in campaign.CASES}) == 18
for (name, flag, ids), accepted in zip(campaign.CASES, native['completed']):
    admission(name)
    output = event(name, campaign.remote_argv(['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
        'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', remote_binary, flag, *ids], '180s'))
    assert (datetime.fromisoformat(events[name]['started']) - datetime.fromisoformat(events[name + '-availability']['finished'])).total_seconds() <= 300
    fields = campaign.pass_fields(output)
    assert fields == campaign.expected(flag, ids), name
    assert accepted == {'name': name, 'flag': flag, 'unique_ids': ids, 'fields': fields}
    callbacks += int(fields['completion_receipts'])
    copies += int(fields['peer_copies'])
    admission(name + '-post')
assert callbacks == 136 and copies == 60
probe = ('import json,os,sys; from pathlib import Path; '
    'target=sys.argv[1]; found=[]\n'
    'for item in Path("/proc").iterdir():\n'
    ' if item.name.isdigit():\n'
    '  try:\n'
    '   exe=os.readlink(item/"exe")\n'
    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
    '   continue\n'
    '  if exe.removesuffix(" (deleted)")==target: found.append(int(item.name))\n'
    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
assert json.loads(event('final-owned-processes', campaign.remote_argv(
    ['/usr/bin/python3', '-I', '-B', '-c', probe, remote_binary]))) == {'owned_executable_pids': []}
assert json.loads(event('owned-executable-exists', campaign.remote_argv(
    ['/usr/bin/python3', '-I', '-B', '-c',
     'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))',
     remote_binary]))) == {'exists': True}
assert event('final-hash', campaign.remote_argv(['/usr/bin/sha256sum', remote_binary])).split() == [sha(binary), remote_binary]
event('remove-owned-executable', campaign.remote_argv(['/usr/bin/rm', '--', remote_binary]))
event('remove-owned-directory', campaign.remote_argv(['/usr/bin/rmdir', '--', directory]))
event('confirm-owned-directory-absent', campaign.remote_argv(['/usr/bin/test', '!', '-e', directory]))
admission('final')
assert last <= datetime.fromisoformat(outer['finished'])
assert set(events) == {path.parent.name for path in HARDWARE.glob('*/result.json')}
assert capture.snapshot() == source and sha(binary) == native['binary']['sha256']
result = {'accepted': True, 'base': BASE, 'source_files': len(source), 'selected': selected,
          'native_events': events, 'campaign_sha256': sha(HARDWARE / 'campaign.json'),
          'example_passes': 13, 'runtime_passes': 2198, 'runtime_ignores': 32,
          'native_cases': 18, 'native_callbacks': callbacks, 'native_peer_copies': copies,
          'owned_cleanup_complete': True, 'solver_run': False, 'performance_acceptance': False,
          'formal_refinement': False}
with (RAW / 'audit-01.json').open('x') as output:
    json.dump(result, output, indent=2, sort_keys=True)
    output.write('\n')
print(json.dumps({key: value for key, value in result.items() if key not in ('selected', 'native_events')}, sort_keys=True))
