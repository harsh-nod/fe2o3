"""Seal independently audited raw evidence and verify its archive round trip."""

import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
DEST = ROOT / 'docs/evidence/dev-gfx942-mov-composition-2026-10-03'
SCOPE = ['crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']
audit = json.loads((RAW / 'audit-final-01/stdout').read_text())
receipt = json.loads((RAW / 'audit-final-01/receipt.json').read_text())
assert audit['accepted'] is True and receipt['exit'] == 0 and receipt['source_unchanged'] is True
patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', 'HEAD', '--', *SCOPE], cwd=ROOT)
assert patch == (RAW / 'candidate.patch').read_bytes()
assert (DEST / 'README.md').is_file()
rows = {}
with (DEST / 'raw.tar.xz').open('xb') as archive:
    with lzma.LZMAFile(archive, mode='w', preset=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as output:
            for path in sorted(RAW.rglob('*')):
                assert not path.is_symlink(), path
                if path.is_dir():
                    continue
                assert path.is_file(), path
                data = path.read_bytes()
                assert not data.startswith(b'\x7fELF'), path
                name = path.relative_to(RAW).as_posix()
                rows[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
                info = tarfile.TarInfo('raw/' + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                output.addfile(info, io.BytesIO(data))
with tarfile.open(DEST / 'raw.tar.xz', 'r:xz') as archive:
    members = archive.getmembers()
    assert [item.name for item in members] == ['raw/' + name for name in rows]
    for item in members:
        assert item.isfile() and item.mode == 0o644 and item.mtime == 0
        data = archive.extractfile(item).read()
        row = rows[item.name.removeprefix('raw/')]
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
assert sorted(rows) == sorted(p.relative_to(RAW).as_posix() for p in RAW.rglob('*') if p.is_file())
for name, row in rows.items():
    data = (RAW / name).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
with (DEST / 'raw-manifest.json').open('x') as output:
    json.dump(rows, output, sort_keys=True, indent=2)
    output.write('\n')
with (DEST / 'SHA256SUMS').open('x') as output:
    for name in ['README.md', 'raw-manifest.json', 'raw.tar.xz']:
        output.write(hashlib.sha256((DEST / name).read_bytes()).hexdigest() + '  ' + name + '\n')
print(json.dumps({'files': len(rows), 'uncompressed_bytes': sum(row['bytes'] for row in rows.values()),
                  'archive_bytes': (DEST / 'raw.tar.xz').stat().st_size,
                  'archive_sha256': hashlib.sha256((DEST / 'raw.tar.xz').read_bytes()).hexdigest()},
                 sort_keys=True))
