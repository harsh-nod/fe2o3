"""Run the bounded MOV-prefix composition qualification matrix sequentially."""

import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
PACKAGES = ['-p', 'fe2o3-kernel-analysis', '-p', 'fe2o3-verifier']
CARGO = ['cargo', '+nightly-2026-04-03']
COMMON = ['--locked', '--offline', *PACKAGES, '--all-features']
TEST = [*CARGO, 'test', *COMMON, '--lib', '--tests']
VERUS = '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus'
V = 'crates/fe2o3-kernel-analysis/verus/'
S = 'crates/fe2o3-kernel-analysis/src/gfx942_integer_semantics_v1'
NATIVE = 'native_llvm_mc_s_'

COMMANDS = {
    'build-01': ['2400s', *TEST, '--no-run', '--message-format=json'],
    'roster-01': ['600s', *TEST, '--', '--list'],
    'cpu-01': ['2400s', *TEST, '--', '--test-threads=1'],
    'doc-01': ['1200s', *CARGO, 'test', *COMMON, '--doc'],
    'llvm18-01': ['600s', 'env', 'FE2O3_GFX942_LLVM_MC=/usr/lib/llvm-18/bin/llvm-mc',
                  *CARGO, 'test', *COMMON, '--lib', NATIVE, '--', '--ignored'],
    'llvm22-01': ['600s', 'env', 'FE2O3_GFX942_LLVM_MC=/opt/rocm/llvm/bin/llvm-mc',
                  *CARGO, 'test', *COMMON, '--lib', NATIVE, '--', '--ignored'],
    'clippy-01': ['2400s', *CARGO, 'clippy', *COMMON, '--lib', '--bins', '--test',
                  'gfx942_local_checked_u32_add_v1', '--no-deps', '--', '-D', 'warnings'],
    'check-no-default-01': ['1200s', *CARGO, 'check', '--locked', '--offline',
                           '-p', 'fe2o3-kernel-analysis', '--no-default-features', '--lib'],
    'check-host-01': ['1200s', *CARGO, 'check', '--locked', '--offline',
                     '-p', 'fe2o3-host', '--all-features', '--lib'],
    'ci-gate-01': ['600s', 'env',
                   'PATH=/home/harsh/.cargo/bin:/usr/bin:/bin:/home/harsh/.codex-openai/packages/standalone/releases/0.160.0-x86_64-unknown-linux-musl/codex-path',
                   'bash', 'scripts/tests/ci-local-test-gate.sh'],
    'proof-controls-01': ['300s', 'python3', '-I', '-B', V + 'gfx942_add_u32_test.py'],
    'proof-01': ['1800s', 'python3', '-I', '-B', V + 'gfx942_add_u32_check.py',
                 '--verus', VERUS, '--output', str(OUT / 'proof-final-01')],
    'source-controls-01': ['1800s', 'python3', '-I', '-B', str(OUT / 'source-controls.py'),
                           'source-01'],
    'format-01': ['300s', 'rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                  '--config', 'skip_children=true', S + '.rs', S + '/execute_body.rs',
                  S + '/tests.rs', S + '/mov_b32.rs', S + '/mov_b32_body.rs',
                  S + '/mov_b32/tests.rs', S + '/mov_prefix_add.rs', S + '/mov_prefix_add_body.rs',
                  S + '/mov_prefix_add/tests.rs', S + '/mov_prefix_add/trace_fixture.rs',
                  V + 'gfx942_add_u32_v1.rs',
                  'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1.rs',
                  'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/mov_prefix.rs',
                  'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/mov_prefix/tests.rs',
                  'crates/fe2o3-verifier/tests/gfx942_local_checked_u32_add_v1.rs'],
    'whitespace-01': ['300s', 'git', 'diff', '--check'],
}


def main():
    selected = sys.argv[1:] or list(COMMANDS)
    if any(label not in COMMANDS for label in selected):
        raise SystemExit('unknown qualification label')
    for label in selected:
        print(json.dumps({'starting': label, 'command': COMMANDS[label]}), flush=True)
        result = subprocess.run([sys.executable, '-I', '-B', str(OUT / 'capture.py'),
                                 label, *COMMANDS[label]], check=False)
        if result.returncode:
            return result.returncode
    return 0


if __name__ == '__main__':
    sys.exit(main())
