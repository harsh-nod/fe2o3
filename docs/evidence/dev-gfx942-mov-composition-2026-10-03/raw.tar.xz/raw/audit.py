"""Independent, fail-closed audit of the selected MOV-prefix qualification."""

import argparse
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

import yaml


ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = 'f7f360004c223d182a75214322ed17925751fdb4'
CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
ENV = {
    'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '4',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
    'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUST_TEST_THREADS': '1',
    'FE2O3_HIP_SYS_DISABLE': '1',
}
SCOPE = ['crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']
PACKAGES = ['-p', 'fe2o3-kernel-analysis', '-p', 'fe2o3-verifier']
NATIVE_FILTER = 'native_llvm_mc_s_'
ADD_NATIVE_TEST = 'gfx942_integer_semantics_v1::tests::native_llvm_mc_s_add_u32_compatibility_v1'
MOV_NATIVE_TEST = 'gfx942_integer_semantics_v1::mov_b32::tests::native_llvm_mc_s_mov_b32_compatibility_v1'
NATIVE_TESTS = {ADD_NATIVE_TEST, MOV_NATIVE_TEST}
ADDED_TESTS = {
    *('gfx942_integer_semantics_v1::mov_b32::tests::' + name for name in [
        'mov_closed_destination_and_source_encodings_are_exhaustive',
        'mov_inline_and_literal_values_preserve_exact_u32_bits',
        'mov_opcode_bits_and_exact_literal_extent_are_required',
        'mov_trace_opcode_operands_and_implicit_effects_fail_closed',
        'mov_immediates_cannot_truncate_or_change_operand_kind',
        'mov_branch_memory_scheduling_and_trap_effects_are_rejected',
        'mov_register_execution_preserves_full_frame_and_scc_for_all_aliases',
        'mov_literal_execution_preserves_full_frame_and_scc_for_every_destination',
        'mov_native_disassembly_annotations_do_not_become_operands',
    ]),
    MOV_NATIVE_TEST,
    *('gfx942_integer_semantics_v1::mov_prefix_add::tests::' + name for name in [
        'zero_and_maximal_prefix_execute_actual_moves_then_add',
        'prefix_origins_snapshot_aliases_order_and_literal_words',
        'span_boundaries_and_block_membership_fail_closed',
        'unsupported_or_extra_prefix_operations_are_never_skipped',
    ]),
    *('gfx942_local_checked_u32_add_v1::mov_prefix::tests::' + name for name in [
        'borrowed_prefix_coordinates_derive_original_entry_and_real_machine_result',
        'exact_literal_and_single_entry_origin_are_required_after_the_whole_prefix',
        'entry_definition_is_checked_before_prefix_not_before_terminal_add',
        'ambiguous_loop_entry_and_foreign_request_fail_closed',
    ]),
    'public_mov_prefix_entry_retains_owners_and_composes_actual_state',
    'public_mov_prefix_entry_rejects_substituted_intervals_and_trace_disagreement',
}
BASELINE_CPU = {
    'stdout': '/home/harsh/.codex-tmp/fe2o3-gfx942-state-20261003/cpu-01/stdout',
    'sha256': '180d7baaf68662751340568c2b78b6d6ed6c717aec28f004332e0564af4db201',
}
SUMMARY = re.compile(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                     r'(\d+) measured; (\d+) filtered out; finished in [0-9.]+s$', re.M)
RESULT = re.compile(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$', re.M)
V = Path('crates/fe2o3-kernel-analysis/verus')
SRC = Path('crates/fe2o3-kernel-analysis/src')
MODEL = SRC / 'gfx942_integer_semantics_v1.rs'
ADD = SRC / 'gfx942_integer_semantics_v1/add_u32_body.rs'
EXECUTE = SRC / 'gfx942_integer_semantics_v1/execute_body.rs'
MOV_MODEL = SRC / 'gfx942_integer_semantics_v1/mov_b32.rs'
MOV_BODY = SRC / 'gfx942_integer_semantics_v1/mov_b32_body.rs'
PREFIX_MODEL = SRC / 'gfx942_integer_semantics_v1/mov_prefix_add.rs'
PREFIX_BODY = SRC / 'gfx942_integer_semantics_v1/mov_prefix_add_body.rs'
PROOF = V / 'gfx942_add_u32_v1.rs'
CHECKER = V / 'gfx942_add_u32_check.py'
CONTROL = V / 'gfx942_add_u32_test.py'
WRAPPER = V / 'run-gfx942-add-u32.sh'
SUPPORT = Path('crates/fe2o3-runtime-model/verus/compute_xgmi_packet_plan_check.py')
OWNER = Path('crates/fe2o3-runtime-model/verus/check-journal-issuance.py')
CLOSURE = Path('examples/row_softmax_v1/verify-verus-closure.sh')
MANIFEST = Path('crates/fe2o3-runtime-model/verus/pins/VERUS_CLOSURE_MANIFEST')
SUPPORT_PINS = {
    SUPPORT: '61074f6cdbfde1df24bff3d1e56e04398f2850dd00518c233d847f13a29e0db4',
    OWNER: '36d5e0641300bf2568884ec4c440c668477a4b24a07ee95273a91eab34659480',
    CLOSURE: 'c0f5f201dca9ea6b3fa953884cdfaca8ca38413ad2a9de7700b3aaeb3a610d0c',
    MANIFEST: 'f06883e4ce463bcb9a3c8f911064ac85054c7822dc331db1a79f75f9e8878b01',
}
VERUS = Path('/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus')
VERUS_SHA = 'd97501a883931d1d173b1bf4b6cf4d973f16d105dbcb468e177b52b2331612d2'
VERIFIER = {'profile': 'release', 'version': '0.2026.08.09.92f466f',
            'platform': {'os': 'linux', 'arch': 'x86_64'},
            'toolchain': '1.97.1-x86_64-unknown-linux-gnu',
            'commit': '92f466f247f45128c630d1c843fd6e27d2115587'}
MUTATIONS = {
    'discarded-carry': (ADD, b'scc: sum >= 0x1_0000_0000_u64', b'scc: false'),
    'wrong-width': (ADD, b'value: (sum % 0x1_0000_0000_u64) as u32', b'value: (sum % 0x1_0000_u64) as u32'),
    'wrong-result': (ADD, b'value: (sum % 0x1_0000_0000_u64) as u32', b'value: $a'),
    'early-alias-write': (EXECUTE, b'let right = match',
        b'$state.registers[$instruction.destination as usize] = left;\n        let right = match'),
    'wrong-destination': (EXECUTE, b'$state.registers[$instruction.destination as usize] = result.value;',
        b'$state.registers[($instruction.destination as usize + 1) % 102] = result.value;'),
    'clobbered-frame': (EXECUTE, b'$state.scc = result.scc;',
        b'$state.scc = result.scc;\n        $state.registers[($instruction.destination as usize + 1) % 102] =\n'
        b'            $state.registers[($instruction.destination as usize + 1) % 102] ^ 1;'),
    'stale-scc': (EXECUTE, b'$state.scc = result.scc;', b''),
    'wrong-return': (EXECUTE, b'        result\n',
        b'        Gfx942U32AddResultV1 { value: result.value ^ 1, scc: result.scc }\n'),
    'mov-wrong-return': (MOV_BODY, b'        value\n', b'        value ^ 1\n'),
    'mov-early-alias-write': (MOV_BODY, b'let value = match',
        b'$state.registers[$instruction.destination as usize] = 0;\n        let value = match'),
    'mov-wrong-destination': (MOV_BODY, b'$state.registers[$instruction.destination as usize] = value;',
        b'$state.registers[($instruction.destination as usize + 1) % 102] = value;'),
    'mov-clobbered-frame': (MOV_BODY, b'        value\n',
        b'        $state.registers[($instruction.destination as usize + 1) % 102] ^= 1;\n        value\n'),
    'mov-changed-scc': (MOV_BODY, b'        value\n', b'        $state.scc = !$state.scc;\n        value\n'),
    'origin-initialization': (PREFIX_BODY, b'Gfx942U32OriginV1::EntrySgpr($index as u8)',
        b'Gfx942U32OriginV1::EntrySgpr((($index + 1) % 102) as u8)'),
    'origin-transitive-source': (PREFIX_BODY,
        b'Gfx942U32SourceV1::Sgpr(register) => $origins[register as usize],',
        b'Gfx942U32SourceV1::Sgpr(register) => Gfx942U32OriginV1::EntrySgpr(register),'),
    'origin-destination': (PREFIX_BODY, b'$origins[$moves[$index].destination() as usize] = origin;',
        b'$origins[($moves[$index].destination() as usize + 1) % 102] = origin;'),
    'origin-terminal-right': (PREFIX_BODY, b'[left, right]', b'{ let _ = right; [left, left] }'),
    'execute-skipped-move': (PREFIX_BODY, b'$moves[$index].execute($state);', b'();'),
    'execute-reordered-moves': (PREFIX_BODY, b'$moves[$index].execute($state);',
        b'$moves[$moves.len() - 1 - $index].execute($state);'),
    'execute-skipped-add': (PREFIX_BODY, b'$add.execute($state)',
        b'let _ = $add; Gfx942U32AddResultV1 { value: 0, scc: false }'),
    'execute-changed-final-scc': (PREFIX_BODY, b'$add.execute($state)',
        b'let result = $add.execute($state); $state.scc = !result.scc; result'),
}
INVARIANTS = {
    'origin-initialization': 'forall|register: int| 0 <= register < index',
    'origin-transitive-source': 'origins@ == origins_after(moves@, index as nat),',
    'origin-destination': 'origins@ == origins_after(moves@, index as nat),',
    'execute-skipped-move': 'forall|register: int| 0 <= register < 102 ==> #[trigger] state.registers@[register]',
    'execute-reordered-moves': 'forall|register: int| 0 <= register < 102 ==> #[trigger] state.registers@[register]',
}
TARGETS = {
    ADD: ('gfx942_add_u32_v1', 'gfx942_add_u32_body_v1'),
    EXECUTE: ('Gfx942SAddU32V1::execute', 'gfx942_s_add_u32_execute_body_v1'),
    MOV_BODY: ('Gfx942SMovB32V1::execute', 'gfx942_s_mov_b32_execute_body_v1'),
}
PROOF_OBLIGATIONS = 16
PROOF_CONTROLS = 17
PROOF_STAGES = [('controls', 0), ('release-before', 0), ('positive-before', 0),
                *[('negative-' + name, 1) for name in MUTATIONS],
                ('positive-after', 0), ('release-after', 0)]
PROOF_REVIEW_COMPLETE = True

# Frozen only after all selected captures and the actual complete rosters existed.
FINAL = {
    'captures': {
        'build': 'build-01', 'roster': 'roster-01', 'cpu': 'cpu-01', 'doc': 'doc-01',
        'llvm18': 'llvm18-01', 'llvm22': 'llvm22-01', 'clippy': 'clippy-01',
        'nodefault': 'check-no-default-01', 'host': 'check-host-01', 'ci': 'ci-gate-01',
        'proof_controls': 'proof-controls-01', 'proof': 'proof-01',
        'source_controls': 'source-controls-01', 'format': 'format-01', 'whitespace': 'whitespace-01',
    },
    'pins': {
        'capture.py': CAPTURE_SHA,
        'qualify.py': 'e4ee083c5520d379dc35db8e7890cab306bcf5cbbcd30b9099755ae30fef9fc7',
        'source-controls.py': '71b8877979380358197bb5f9f013c41c7030f4dd587fe68ca2805502e314101d',
        'freeze.py': '09dfe173eb113ace824d64e4b21bf438a361c858ea5b304d3c8ed4602df2967a',
        'llvm-tools.py': '7b11eee23a0bc8d0e17351604b6c6e3dd3b303e23ad0896ffe82a4c9db81ec29',
    },
    'cpu_counts': {'passed': 832, 'ignored': 13, 'listed': 845, 'targets': 40, 'doc_passed': 30},
    'source_controls': {'result': 'source-01.json', 'prefix': 'source-01'},
    'candidate_sha256': 'f7e2375d2d0e39e041c301be4818596f74a31bb607123bc41d4b305f9301b395',
    'proof': {
        'output': 'proof-final-01',
        'pins': {
            str(MODEL): '17d81e807d82fc9acf4669f5f930cbeda6c414904033c8c9f542c1ec38f76f0b',
            str(ADD): 'ee13767a20c0bcfb69b34ac590f22a219f4014b245ab8b47eb5fbe2693e7c793',
            str(EXECUTE): '62f15f8e859a4af362b67cf504b64d3891b8c524db7fd9d06ca2c9348fd7a524',
            str(MOV_MODEL): 'eb52069f253f2b011e41f457533efb142c015f9bde7081bd6a056d48a12591cb',
            str(MOV_BODY): 'ad9b7343ad44f003830cbeb1b900cf8efc966f644ebb14a5a321b377fdb3f7ae',
            str(PREFIX_MODEL): '507b5994a6dc832fed2be7d5773a004a34fe1a1f78dc0a4c4669346c896d7879',
            str(PREFIX_BODY): 'f184a2a15ab6b3aca5170aacc7ed770cd7b8b6ab9b73a53be93597c3c9e18b4a',
            str(PROOF): 'b0ed299417f9b5498ed8667852d0afd919e875a6d2fbac501c6b689f5713d5f4',
            str(CHECKER): 'a0f1ebfcbb1467c323658450e75811de861efb1d317a716f7b43014fb9207950',
            str(CONTROL): '4b80be4b5a32fe7e4a4a88c5bf2d1a3fa2d69fdec3610cb04160bb9e7dfb0d37',
            str(WRAPPER): '8b760957b15578d4bc821a060b8a2fc0bbb0988f12bba2a466e93d14e1e5b51f',
        },
    },
}


def mutation_target(name):
    body = MUTATIONS[name][0]
    if body == PREFIX_BODY:
        return ('prefix_origins', 'gfx942_mov_prefix_origins_body_v1') if name.startswith('origin-') else (
            'Gfx942MovPrefixAddU32V1::execute', 'gfx942_mov_prefix_execute_body_v1')
    return TARGETS[body]


def proof_stage_rows():
    rows = []
    for name, status in PROOF_STAGES:
        row = {'name': name, 'status': status, 'accepted': True}
        if name.startswith('positive-'):
            row['verified_obligations'] = PROOF_OBLIGATIONS
        elif name.startswith('negative-'):
            mutant = name.removeprefix('negative-')
            invariant = INVARIANTS.get(mutant)
            row.update(target=mutation_target(mutant)[0], invariant=invariant,
                       logical_rejection='invariant not satisfied at end of loop body' if invariant else
                       'postcondition not satisfied')
        rows.append(row)
    return rows


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse(data):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    def constant(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(data, object_pairs_hook=pairs, parse_constant=constant)


def regular(path):
    need(path.is_file() and not path.is_symlink() and path.resolve() == path,
         'canonical regular file: ' + str(path))
    return path.read_bytes()


def read(path):
    return parse(regular(path))


def child(base, name):
    need(isinstance(name, str) and name and '\\' not in name, 'relative path')
    path = base / name
    need(not Path(name).is_absolute() and '..' not in Path(name).parts
         and path.resolve() == path and path.is_relative_to(base), 'contained path: ' + name)
    return path


def git(*args, allowed=(0,)):
    result = subprocess.run(['git', *args], cwd=ROOT, env=ENV, capture_output=True, check=False)
    need(result.returncode in allowed and not result.stderr, 'read-only git command: ' + repr(args))
    return result.stdout


def source_inventory():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', *SCOPE)
    return {name: sha(regular(child(ROOT, name)))
            for name in sorted({os.fsdecode(name) for name in names.split(b'\0') if name})}


def utc(value):
    timestamp = datetime.datetime.fromisoformat(value)
    need(timestamp.utcoffset() == datetime.timedelta(0), 'UTC receipt timestamp')
    return timestamp


def expected_commands(proof_output, source_prefix):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', *PACKAGES, '--all-features']
    tests = [*cargo, 'test', *common, '--lib', '--tests']
    return {
        'build': (2400, [*tests, '--no-run', '--message-format=json']),
        'roster': (600, [*tests, '--', '--list']),
        'cpu': (2400, [*tests, '--', '--test-threads=1']),
        'doc': (1200, [*cargo, 'test', *common, '--doc']),
        'llvm18': (600, ['env', 'FE2O3_GFX942_LLVM_MC=/usr/lib/llvm-18/bin/llvm-mc',
                         *cargo, 'test', *common, '--lib', NATIVE_FILTER, '--', '--ignored']),
        'llvm22': (600, ['env', 'FE2O3_GFX942_LLVM_MC=/opt/rocm/llvm/bin/llvm-mc',
                         *cargo, 'test', *common, '--lib', NATIVE_FILTER, '--', '--ignored']),
        'clippy': (2400, [*cargo, 'clippy', *common, '--lib', '--bins', '--test',
                          'gfx942_local_checked_u32_add_v1', '--no-deps', '--', '-D', 'warnings']),
        'nodefault': (1200, [*cargo, 'check', '--locked', '--offline',
                            '-p', 'fe2o3-kernel-analysis', '--no-default-features', '--lib']),
        'host': (1200, [*cargo, 'check', '--locked', '--offline',
                       '-p', 'fe2o3-host', '--all-features', '--lib']),
        'ci': (600, ['env',
                    'PATH=/home/harsh/.cargo/bin:/usr/bin:/bin:/home/harsh/.codex-openai/packages/standalone/releases/0.160.0-x86_64-unknown-linux-musl/codex-path',
                    'bash', 'scripts/tests/ci-local-test-gate.sh']),
        'proof_controls': (300, ['python3', '-I', '-B', str(CONTROL)]),
        'proof': (1800, ['python3', '-I', '-B', str(CHECKER), '--verus', str(VERUS),
                         '--output', str(OUT / proof_output)]),
        'source_controls': (1800, ['python3', '-I', '-B', str(OUT / 'source-controls.py'), source_prefix]),
        'format': (300, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                         '--config', 'skip_children=true', str(MODEL), str(EXECUTE),
                         str(SRC / 'gfx942_integer_semantics_v1/tests.rs'),
                         str(MOV_MODEL), str(MOV_BODY),
                         str(SRC / 'gfx942_integer_semantics_v1/mov_b32/tests.rs'),
                         str(PREFIX_MODEL), str(PREFIX_BODY),
                         str(SRC / 'gfx942_integer_semantics_v1/mov_prefix_add/tests.rs'),
                         str(SRC / 'gfx942_integer_semantics_v1/mov_prefix_add/trace_fixture.rs'),
                         str(PROOF),
                         'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1.rs',
                         'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/mov_prefix.rs',
                         'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/mov_prefix/tests.rs',
                         'crates/fe2o3-verifier/tests/gfx942_local_checked_u32_add_v1.rs']),
        'whitespace': (300, ['git', 'diff', '--check']),
    }


def capture(label, command, seconds, sources):
    need(re.fullmatch(r'[a-z][a-z0-9-]*-\d\d(?:-[a-z0-9]+)?', label), 'selected capture label')
    directory = child(OUT, label)
    receipt = read(directory / 'receipt.json')
    initial = read(directory / 'command.json')
    need(receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s',
                               str(seconds) + 's', *command], label + ': exact bounded argv')
    need(type(receipt['exit']) is int and receipt['exit'] == 0
         and receipt['source_unchanged'] is True, label + ': successful stable run')
    need(receipt['environment'] == ENV and receipt['cwd'] == str(ROOT)
         and receipt['base'] == BASE and receipt['controller_sha256'] == CAPTURE_SHA,
         label + ': environment/controller/base')
    need(set(initial) == {'command', 'environment', 'cwd', 'base', 'controller_sha256', 'started'}
         and all(receipt[key] == value for key, value in initial.items()), label + ': receipt continuity')
    final_keys = set(initial) | {'exit', 'source_unchanged', 'finished', 'stdout_sha256', 'stderr_sha256'}
    if '--message-format=json' in command:
        final_keys.add('executables')
    need(set(receipt) == final_keys, label + ': exact terminal receipt fields')
    duration = (utc(receipt['finished']) - utc(receipt['started'])).total_seconds()
    need(0 <= duration <= seconds + 45, label + ': bounded measurement window')
    need(read(directory / 'source-before.json') == sources
         and read(directory / 'source-after.json') == sources, label + ': complete source closure')
    for stream in ['stdout', 'stderr']:
        data = regular(directory / stream)
        need(sha(data) == receipt[stream + '_sha256'], label + ': ' + stream + ' hash')
        receipt[stream] = data.decode('utf-8')
    return receipt


def build_roster(receipt):
    rows = [parse(line) for line in receipt['stdout'].splitlines()]
    need([row for row in rows if row.get('reason') == 'build-finished']
         == [{'reason': 'build-finished', 'success': True}], 'exact successful Cargo build footer')
    derived = {}
    for row in rows:
        if row.get('reason') != 'compiler-artifact' or not row.get('executable'):
            continue
        path = Path(row['executable'])
        need(path.is_relative_to(ROOT / 'target'), 'Cargo executable inside target')
        data = regular(path)
        entry = {'sha256': sha(data), 'byte_length': len(data), 'target': row['target']['name'],
                 'test': row['profile']['test']}
        need(type(entry['test']) is bool, 'typed Cargo test flag')
        need(str(path) not in derived or derived[str(path)] == entry, 'no contradictory Cargo artifact')
        derived[str(path)] = entry
    need(derived and derived == receipt['executables'], 'exact current built executable roster')
    return derived


def test_results(stdout, filtered=False):
    summaries = [tuple(map(int, row)) for row in SUMMARY.findall(stdout)]
    need(summaries and all(failed == measured == 0 and (filtered or count == 0)
                          for _, failed, _, measured, count in summaries), 'successful test summaries')
    rows = RESULT.findall(stdout)
    status = Counter(result for _, result in rows)
    need(status['FAILED'] == 0 and status['ok'] == sum(row[0] for row in summaries)
         and status['ignored'] == sum(row[2] for row in summaries), 'row/summary exact counts')
    return Counter(name for name, _ in rows), Counter(name for name, state in rows if state == 'ignored'), summaries


def running_targets(stderr):
    names = re.findall(r'^\s*Running .+ \(([^\n)]+)\)\s*$', stderr, re.M)
    return Counter(str((ROOT / name).resolve()) if not Path(name).is_absolute() else name
                   for name in names)


def cpu_rosters(receipts, executables, baseline):
    listing = receipts['roster']['stdout']
    listed = Counter(re.findall(r'^(.+): test$', listing, re.M))
    footers = re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', listing, re.M)
    need(footers and all(bench == '0' for _, bench in footers)
         and sum(int(count) for count, _ in footers) == sum(listed.values()), 'exact complete test listing')
    observed, ignored, summaries = test_results(receipts['cpu']['stdout'])
    need(observed == listed and listed, 'list/run exact test multiset')
    expected_targets = Counter(path for path, row in executables.items() if row['test'])
    need(running_targets(receipts['roster']['stderr']) == expected_targets
         and running_targets(receipts['cpu']['stderr']) == expected_targets
         and len(footers) == len(summaries) == sum(expected_targets.values()), 'every built test harness ran once')
    baseline_data = regular(Path(baseline['stdout']))
    need(sha(baseline_data) == baseline['sha256'], 'pinned prior CPU roster')
    prior_names, prior_ignored, _ = test_results(baseline_data.decode())
    need(len(ADDED_TESTS) == 20 and observed == prior_names + Counter(ADDED_TESTS)
         and ignored == prior_ignored + Counter({MOV_NATIVE_TEST: 1}),
         'precisely twenty new tests, nineteen ordinary plus one explicit native MC ignore')
    need(all(ignored[name] == 1 for name in NATIVE_TESTS),
         'ordinary suite preserves both explicit LLVM compatibility ignores')
    libraries = Counter(path for path, row in executables.items()
                        if row['test'] and row['target'] in {'fe2o3_kernel_analysis', 'fe2o3_verifier'})
    need(len(libraries) == 2 and {executables[path]['target'] for path in libraries}
         == {'fe2o3_kernel_analysis', 'fe2o3_verifier'}, 'exact selected library harnesses')
    for role in ['llvm18', 'llvm22']:
        names, skip, rows = test_results(receipts[role]['stdout'], filtered=True)
        need(names == Counter(NATIVE_TESTS) and not skip and len(rows) == 2
             and sorted(row[0] for row in rows) == [0, 2]
             and running_targets(receipts[role]['stderr']) == libraries, role + ': exact native MC test/harnesses')
    _, doc_ignored, docs = test_results(receipts['doc']['stdout'])
    need(len(docs) == 2 and not doc_ignored, 'both complete doc suites')
    need(receipts['ci']['stdout'].endswith('ci-local test gate regression passed\n'), 'CI dispatch regression completed')
    return {'passed': sum(row[0] for row in summaries), 'ignored': sum(ignored.values()),
            'listed': sum(listed.values()), 'targets': len(expected_targets),
            'roster': dict(sorted(listed.items())), 'ignored_roster': dict(sorted(ignored.items())),
            'doc_passed': sum(row[0] for row in docs), 'native_llvm18_passed': 2, 'native_llvm22_passed': 2}


def candidate_patch(expected_sha, sources):
    need(not git('diff', '--name-only', '-z', '--', *SCOPE), 'no unstaged qualified source')
    need(not git('ls-files', '--others', '--exclude-standard', '-z', '--', *SCOPE),
         'all new qualified source files explicitly staged')
    changed = git('diff', '--cached', BASE, '--name-only', '-z', '--', *SCOPE)
    paths = sorted(os.fsdecode(name) for name in changed.split(b'\0') if name)
    need({str(path) for path in [MOV_MODEL, MOV_BODY, PREFIX_MODEL, PREFIX_BODY]} <= set(paths),
         'candidate includes actual MOV and prefix models and shared executable bodies')
    need(all(name in sources for name in paths), 'patch files inside qualified closure')
    for name in paths:
        need(sha(git('show', ':' + name)) == sources[name], 'index blob equals qualified current source: ' + name)
    data = git('diff', '--cached', '--binary', 'HEAD', '--', *SCOPE)
    need(data and sha(data) == expected_sha and regular(OUT / 'candidate.patch') == data,
         'exact source-only candidate patch includes staged additions and current index blobs')
    candidate = read(OUT / 'candidate.json')
    need(candidate == {'base': BASE, 'patch_sha256': expected_sha,
                       'sources': {name: {'sha256': sources[name], 'bytes': len(regular(ROOT / name))}
                                   for name in paths}}, 'candidate freeze receipt exactly matches audited patch/index')
    return {'sha256': sha(data), 'paths': paths, 'source_sha256': {name: sources[name] for name in paths}}


def proof_diagnostics(stdout, stderr, staged, mutant):
    negative = mutant is not None
    focus, macro = mutation_target(mutant) if negative else (None, None)
    invariant = INVARIANTS.get(mutant)
    summary = parse(stdout)
    need(summary['verus'] == VERIFIER, 'exact Verus identity')
    negative_verified = 2 if focus == 'prefix_origins' else 1 if focus == 'Gfx942MovPrefixAddU32V1::execute' else 0
    expected = {'encountered-error': negative, 'encountered-vir-error': False,
                'verified': negative_verified if negative else PROOF_OBLIGATIONS, 'errors': 1 if negative else 0,
                'is-verifying-entire-crate': not negative}
    if not negative:
        expected['success'] = True
    actual = summary['verification-results']
    need(actual == expected and all(type(actual[key]) is type(value) for key, value in expected.items()),
         'exact full-positive/selected-negative proof summary')
    diagnostics = [parse(line) for line in stderr.splitlines() if line]
    if not negative:
        need(not diagnostics, 'positive proof has no warnings/errors')
        return
    errors = [row for row in diagnostics if row.get('level') == 'error']
    message = 'invariant not satisfied at end of loop body' if invariant else 'postcondition not satisfied'
    logical = [row for row in errors if row.get('message') == message]
    abort = [row for row in errors if row.get('message') == 'aborting due to 1 previous error'
             and row.get('spans') == []]
    notes = {'verifying root module (selected functions)',
             'function body check: not all errors may have been reported; rerun with a higher value for --multiple-errors to find other potential errors in this function',
             'while loop: not all errors may have been reported; rerun with a higher value for --multiple-errors to find other potential errors in this function'}
    need(len(logical) == len(abort) == 1 and len(errors) == 2
         and all(row.get('level') == 'error' or row.get('level') == 'note'
                 and row.get('message') in notes for row in diagnostics), 'logical rejection, not parse/tool failure')
    proof = staged / PROOF
    lines = regular(proof).decode().splitlines()
    calls = [i + 1 for i, line in enumerate(lines) if line.strip().startswith(macro + '!(')]
    need(len(calls) == 1, 'unique shared target forwarding call')
    call = calls[0]
    method = focus.split('::')[-1]
    first = max(i + 1 for i, line in enumerate(lines[:call - 1])
                if line.strip().startswith('fn ' + method + '('))
    if '::' in focus:
        owners = [line.strip() for line in lines[:first] if line.strip().startswith('impl ')]
        need(owners and owners[-1] == 'impl ' + focus.split('::')[0] + ' {',
             'exact selected impl owner, not another execute method')
    balance = 0
    end = None
    for index in range(call - 1, len(lines)):
        balance += lines[index].count('(') - lines[index].count(')')
        if balance == 0:
            end = index + 1
            break
    need(end is not None, 'closed selected shared invocation')
    body = staged / MUTATIONS[mutant][0]
    definitions = [i + 1 for i, line in enumerate(regular(body).decode().splitlines())
                   if line.startswith('macro_rules! ' + macro + ' {')]
    need(len(definitions) == 1, 'unique exact shared macro definition')
    definition = definitions[0]
    locations = set(range(first + 1, call)) if invariant is None else {
        i + 1 for i in range(call - 1, end) if lines[i].strip() == invariant}
    need(locations, 'declared selected postcondition or loop invariant exists')
    spans = logical[0]['spans']
    need(any(span.get('is_primary') is True and Path(span.get('file_name', '')).resolve() == proof
             and type(span.get('line_start')) is int and span['line_start'] in locations
             for span in spans), 'actual selected contract failure')
    expansion_rows = logical if invariant is None else [row for row in diagnostics
        if row.get('level') == 'note' and row.get('message', '').startswith('while loop:')]

    def reaches_shared_macro(span):
        for _ in range(4):
            expansion = span.get('expansion')
            if not isinstance(expansion, dict):
                return False
            if (Path(span.get('file_name', '')).resolve() == body
                    and expansion.get('macro_decl_name') == macro + '!'
                    and Path(expansion['span']['file_name']).resolve() == proof
                    and expansion['span']['line_start'] == call
                    and Path(expansion['def_site_span']['file_name']).resolve() == body
                    and expansion['def_site_span']['line_start'] == definition):
                return True
            if expansion.get('macro_decl_name') not in {'desugaring of `while` loop', 'verus_exec_expr!'}:
                return False
            span = expansion['span']
        return False

    need(any(reaches_shared_macro(span) for row in expansion_rows for span in row.get('spans', [])),
         'diagnostic reaches exact mutated shared macro and forwarding call')


def proof_campaign(selection, sources, outer):
    need(PROOF_REVIEW_COMPLETE, 'MOV/composition proof adapter is not yet frozen')
    directory = child(OUT, selection['output'])
    result = read(directory / 'result.json')
    need(result['accepted'] is True and result['full_campaign'] is True
         and result['source_unchanged'] is True and result['error'] is None
         and result['establishes_hardware_isa_conformance'] is False
         and result['grants_application_authority'] is False, 'complete narrowly scoped proof campaign')
    need(result['verified_obligations'] == PROOF_OBLIGATIONS and result['arithmetic_mutants'] == 3
         and result['state_mutants'] == 5 and result['mov_mutants'] == 5 and result['fold_mutants'] == 8
         and result['control_tests'] == PROOF_CONTROLS, 'exact proof coverage counts')
    need(result['stages'] == proof_stage_rows(),
         'exact complete proof stage roster')
    prefix = ''.join(name + ': PASS\n' for name, _ in PROOF_STAGES)
    need(outer['stdout'].startswith(prefix) and parse(outer['stdout'][len(prefix):]) == result,
         'outer exact proof stage lines and structured result equal retained result')
    expected_env = {'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
                    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'RUSTUP_HOME': '/home/harsh/.rustup',
                    'CARGO_HOME': '/home/harsh/.cargo', 'VERUS_Z3_PATH': str(VERUS.parent / 'z3'),
                    'TMPDIR': str(directory / 'tmp')}
    need(read(directory / 'environment.json') == expected_env, 'exact minimal solver environment')
    paths = {str(path) for path in [MODEL, ADD, EXECUTE, MOV_MODEL, MOV_BODY, PREFIX_MODEL, PREFIX_BODY,
                                   PROOF, CHECKER, CONTROL, WRAPPER, SUPPORT, OWNER, CLOSURE, MANIFEST]}
    before, after = read(directory / 'source-before.json'), read(directory / 'source-after.json')
    need(set(before) == paths and before == after, 'exact unchanged proof/support input closure')
    for name, digest in before.items():
        data = regular(child(ROOT, name))
        need(sha(data) == digest
             and regular(child(directory / 'inputs', name)) == data, 'retained current proof source: ' + name)
        if name in sources:
            need(sources[name] == digest, 'proof/CPU source identity: ' + name)
        else:
            need(name == str(CLOSURE) and digest == SUPPORT_PINS[CLOSURE],
                 'only separately pinned example closure helper is outside capture scope')
    for path, digest in {**SUPPORT_PINS, **{Path(k): v for k, v in selection['pins'].items()}}.items():
        need(before[str(path)] == digest, 'independent proof/source pin: ' + str(path))
    need(sha(regular(VERUS)) == VERUS_SHA, 'actual pinned Verus executable')
    last_finished = int(utc(outer['started']).timestamp() * 1_000_000_000)
    outer_finished = int(utc(outer['finished']).timestamp() * 1_000_000_000)
    records = {}
    for name, status in PROOF_STAGES:
        stage = directory / name
        receipt = read(stage / 'record.json')
        need(set(receipt) == {'command', 'started_ns', 'finished_ns', 'status', 'process_group', 'group_absent'}
             and type(receipt['status']) is int and receipt['status'] == status
             and receipt['group_absent'] is True and type(receipt['process_group']) is int
             and receipt['process_group'] > 0, name + ': exact terminal owned process')
        start, finish = receipt['started_ns'], receipt['finished_ns']
        need(type(start) is int and type(finish) is int and last_finished <= start <= finish <= outer_finished
             and finish - start <= 140_000_000_000, name + ': ordered bounded stage inside outer capture')
        last_finished = finish
        stdout, stderr = (regular(stage / stream).decode() for stream in ['stdout.log', 'stderr.log'])
        records[name] = {filename: sha(regular(stage / filename))
                         for filename in ['record.json', 'stdout.log', 'stderr.log']}
        if name == 'controls':
            need(receipt['command'][1:] == ['-I', '-B', str(ROOT / CONTROL)]
                 and receipt['command'][0] in ['/usr/bin/python3', '/usr/bin/python3.11']
                 and not stdout and re.findall(r'^Ran (\d+) tests in [0-9.]+s$', stderr, re.M) == [str(PROOF_CONTROLS)]
                 and stderr.endswith('\nOK\n'), 'exact proof parser/source controls')
            continue
        if name.startswith('release-'):
            need(receipt['command'] == ['/bin/sh', str(ROOT / CLOSURE), str(VERUS.parent), str(ROOT / MANIFEST)]
                 and stdout == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n'
                 and not stderr, 'complete pinned Verus release measurement')
            continue
        staged = directory / (name + '-source')
        originals = {path: regular(directory / 'inputs' / path) for path in [ADD, EXECUTE, MOV_BODY, PREFIX_BODY, PROOF]}
        mutant = None
        if name.startswith('negative-'):
            mutant = name.removeprefix('negative-')
            modified, old, new = MUTATIONS[mutant]
            count = 3 if mutant == 'origin-transitive-source' else 1
            need(originals[modified].count(old) == count, 'exact executable mutant replacement sites')
            originals[modified] = originals[modified].replace(old, new, 1)
        need(all(regular(staged / path) == data for path, data in originals.items()),
             name + ': exact contracts/shared body and single mutation')
        command = ['/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5', '120',
                   str(VERUS), '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating',
                   '--output-json', '--error-format=json', '--no-report-long-running',
                   '--num-threads', '1', '--multiple-errors', '1']
        if mutant:
            command += ['--verify-function', '*' + mutation_target(mutant)[0], '--verify-root']
        need(receipt['command'] == [*command, str(staged / PROOF)], 'exact bounded selected solver argv')
        proof_diagnostics(stdout, stderr, staged, mutant)
    return {'positive_runs': 2, 'verified_obligations_per_positive': PROOF_OBLIGATIONS,
            'arithmetic_mutants_rejected': 3, 'state_mutants_rejected': 5,
            'mov_mutants_rejected': 5, 'fold_mutants_rejected': 8,
            'controls': PROOF_CONTROLS, 'release_files': 190, 'source_sha256': before, 'receipts': records,
            'result_sha256': sha(regular(directory / 'result.json'))}


def native_tools(receipts):
    before = read(OUT / 'native-tools-before.json')
    after = read(OUT / 'native-tools-after.json')
    need(before['tools'] == after['tools'] and before['native_loader_closure_authenticated'] is False
         and after['native_loader_closure_authenticated'] is False, 'unchanged native MC identity, not loader custody')
    need(len(before['tools']) == 2, 'exact two native MC executables')
    expected = [('/usr/lib/llvm-18/bin/llvm-mc', 'd2b9ff3e9dd1a2d5ad086cb1047d38ee0da60e62b03d69ef45231c0c6979a27e',
                 'Ubuntu LLVM version 18.1.3\n'),
                ('/opt/rocm/llvm/bin/llvm-mc', '6cdaebe34b2baa811ec098dfd566c39c088d1492ce162e68ecf76f23d8ca4771',
                 'AMD LLVM version 22.0.0git\n')]
    for row, (configured, expected_sha, version) in zip(before['tools'], expected):
        resolved = Path(configured).resolve(strict=True)
        data = regular(resolved)
        need(row['configured'] == configured and row['resolved'] == str(resolved)
             and row['sha256'] == expected_sha == sha(data) and row['bytes'] == len(data)
             and row['version'].startswith(version) and not row['stderr'], 'native MC exact executable identity')
    need(utc(before['measured']) <= min(utc(receipts[role]['started']) for role in ['llvm18', 'llvm22'])
         and utc(after['measured']) >= max(utc(receipts[role]['finished']) for role in ['llvm18', 'llvm22']),
         'native MC identity measurements bracket both compatibility runs')
    return {'tools': before['tools'], 'before_sha256': sha(regular(OUT / 'native-tools-before.json')),
            'after_sha256': sha(regular(OUT / 'native-tools-after.json')),
            'native_loader_closure_authenticated': False}


def source_controls(selection, sources, outer):
    path = child(OUT, selection['result'])
    result = read(path)
    workflow = regular(ROOT / '.github/workflows/runtime-component-source-guards.yml')
    steps = yaml.safe_load(workflow)['jobs']['source-controls']['steps']
    expected = [(step['name'], shlex.split(line)) for step in steps if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    need(len(expected) == 32 and all(command[:3] == ['python3', '-I', '-B'] for _, command in expected),
         'exact 32 source-only workflow commands')
    need(result['accepted'] is True and result['workflow_unchanged'] is True
         and result['workflow_sha256'] == sha(workflow) and len(result['commands']) == 32,
         'complete successful source controls')
    previous = utc(outer['started'])
    for index, ((step, command), row) in enumerate(zip(expected, result['commands']), 1):
        label = selection['prefix'] + '-' + str(index).zfill(2)
        need(row == {'step': step, 'capture': label, 'command': command, 'exit': 0}, 'exact source control row')
        receipt = capture(label, command, 300, sources)
        need(previous <= utc(receipt['started']) <= utc(receipt['finished']) <= utc(outer['finished']),
             'sequential source control contained in selected outer capture')
        previous = utc(receipt['finished'])
    need(parse(outer['stdout'].splitlines()[-1]) == {'accepted': True, 'commands': 32},
         'source controller closing stdout agrees with exact campaign')
    return 32


def main():
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3 -I -B')
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.parse_args()
    need(FINAL is not None, 'final qualification selection has not been frozen')
    need(sha(regular(OUT / 'capture.py')) == CAPTURE_SHA, 'frozen capture controller')
    need(git('rev-parse', 'HEAD').decode().strip() == BASE, 'unchanged qualification baseline')
    sources = source_inventory()
    for name, expected in FINAL['pins'].items():
        need(sha(regular(child(OUT, name))) == expected, 'frozen external controller: ' + name)
    commands = expected_commands(FINAL['proof']['output'], FINAL['source_controls']['prefix'])
    need(set(FINAL['captures']) == set(commands)
         and len(set(FINAL['captures'].values())) == len(commands), 'complete distinct selected command matrix')
    receipts = {role: capture(FINAL['captures'][role], command, seconds, sources)
                for role, (seconds, command) in commands.items()}
    for role in ['roster', 'cpu', 'llvm18', 'llvm22']:
        need(utc(receipts['build']['finished']) <= utc(receipts[role]['started']),
             role + ': final exact executable build precedes execution')
    for role in ['format', 'whitespace']:
        need(not receipts[role]['stdout'] and not receipts[role]['stderr'], role + ': clean output')
    executables = build_roster(receipts['build'])
    cpu = cpu_rosters(receipts, executables, BASELINE_CPU)
    need({key: cpu[key] for key in FINAL['cpu_counts']} == FINAL['cpu_counts'], 'observed frozen CPU totals')
    need(not receipts['proof_controls']['stdout']
         and re.findall(r'^Ran (\d+) tests in [0-9.]+s$', receipts['proof_controls']['stderr'], re.M) == [str(PROOF_CONTROLS)]
         and receipts['proof_controls']['stderr'].endswith('\nOK\n'), 'exact standalone proof controls')
    controls = source_controls(FINAL['source_controls'], sources, receipts['source_controls'])
    proof = proof_campaign(FINAL['proof'], sources, receipts['proof'])
    tools = native_tools(receipts)
    patch = candidate_patch(FINAL['candidate_sha256'], sources)
    need(source_inventory() == sources, 'closing current source identity')
    report = {'accepted': True, 'base': BASE, 'auditor_sha256': sha(regular(Path(__file__).resolve())),
              'source_sha256': sources, 'executables': executables, 'cpu': cpu, 'proof': proof,
              'source_controls': controls, 'candidate': patch, 'controller_pins': FINAL['pins'],
              'native_mc': tools, 'selected_receipts': {
                  role: {'label': label, 'sha256': sha(regular(OUT / label / 'receipt.json'))}
                  for role, label in FINAL['captures'].items()},
              'hardware_qualification': False, 'performance_qualification': False,
              'whole_kernel_refinement': False, 'general_application_authority': False,
              'finished': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, IndexError, StopIteration, OSError,
            subprocess.SubprocessError) as error:
        print(json.dumps({'accepted': False, 'error': type(error).__name__ + ': ' + str(error)}))
        sys.exit(1)
