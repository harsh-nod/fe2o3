#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-host-fill-20261003-9rv3DKsH
readonly output="$scratch/${1:?fresh snapshot name}"
mkdir -m 700 "$output"
git rev-parse HEAD >"$output/parent.txt"
git diff --name-only -- Cargo.lock crates tests >"$output/paths.txt"
printf '%s\n' \
  crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
  crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
  >>"$output/paths.txt"
while IFS= read -r path; do
  sha256sum "$path"
done <"$output/paths.txt" >"$output/sources.sha256"
git diff --binary -- Cargo.lock crates tests >"$output/code.patch"
for path in \
  crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
  crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs; do
  git diff --no-index --binary -- /dev/null "$path" >>"$output/code.patch" || test "$?" = 1
done
sha256sum "$output/code.patch" >"$output/patch.sha256"
