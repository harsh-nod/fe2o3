#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-host-fill-20261003-9rv3DKsH
readonly archive="$PWD/docs/evidence/dev-host-fill-association-2026-10-03/qualification.tar.xz"
test "$(<"$scratch/regression.status")" = 0
test "$(<"$scratch/build.status")" = 0
bash "$scratch/snapshot.sh" source-after
cmp "$scratch/source-before/sources.sha256" "$scratch/source-after/sources.sha256"
cmp "$scratch/source-before/code.patch" "$scratch/source-after/code.patch"
sha256sum --check "$scratch/upload.sha256" >"$scratch/upload-after.log"
diff -r tools/fe2o3-llvm-link-worker "$scratch/native/tools/fe2o3-llvm-link-worker" \
  >"$scratch/worker-source-diff.log"
git diff --check >"$scratch/whitespace.log"
paths=()
while IFS= read -r path; do
  if [[ "$path" == *.rs ]]; then paths+=("$path"); fi
done <"$scratch/source-after/paths.txt"
rustfmt +nightly-2026-04-03 --edition 2024 --check --config skip_children=true \
  "${paths[@]}" >"$scratch/formatting.log" 2>&1
tar -cJf "$archive" --exclude=./inspect-fill --exclude=./native-records.tar.xz \
  -C "$scratch" .
tar -tJf "$archive" >"$scratch/archive-listing.txt"
sha256sum "$archive"
wc -l "$scratch/archive-listing.txt"
