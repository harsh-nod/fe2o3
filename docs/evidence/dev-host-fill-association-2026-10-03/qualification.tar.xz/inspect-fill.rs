fn main() {
    let bytes = std::fs::read(std::env::args().nth(1).unwrap()).unwrap();
    let handoff = fe2o3_compiler_ffi::InertSemanticCompilerModuleHandoffV3::decode(&bytes).unwrap();
    let descriptor = fe2o3_compiler_ffi::CompilerDescriptorSourceV1::decode(
        handoff.capsule().receipts().abi().canonical_preimage(),
    ).unwrap();
    println!("{:#?}", descriptor.table().kernels());
}
