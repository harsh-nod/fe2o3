#!/bin/bash
set -euo pipefail
readonly owned=/tmp/fe2o3-host-fill-20261003-qbLhPWBM
readonly run="$owned/${1:?fresh run name}"
mkdir -m 700 "$run"
mkdir -m 700 "$run/tmp" "$run/finalizer"
readonly worker_build_id="$(<"$owned/build/fe2o3-worker-build-id.txt")"
sha256sum "$owned/worker_v3_load_envelope_vertical-41e62bb0a14e99f3" \
  "$owned/fe2o3-worker-v3-hsaco-fixture" "$owned/build/fe2o3-llvm-link-worker" >"$run/executables.sha256"
env TMPDIR="$run/tmp" FE2O3_TEST_REAL_WORKER="$owned/build/fe2o3-llvm-link-worker" \
  FE2O3_TEST_REAL_WORKER_BUILD_ID="$worker_build_id" FE2O3_TEST_REAL_LLVM_BUILD_ID=7.2.4 \
  FE2O3_TEST_HSACO_WORKER_FIXTURE="$owned/fe2o3-worker-v3-hsaco-fixture" \
  FE2O3_FILL_FINALIZER_CAPTURE="$run/finalizer" FE2O3_FILL_HOST_CAPTURE="$run" \
  timeout --kill-after=15s 300s "$owned/worker_v3_load_envelope_vertical-41e62bb0a14e99f3" \
  conditional_fill_host::genuine_fill_reaches_current_publication_audit_without_authority \
  --ignored --exact --nocapture --test-threads=1 >"$run/test.log" 2>&1
grep -Eq '^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 64 filtered out; finished in [0-9.]+s$' "$run/test.log"
sha256sum --check "$run/executables.sha256" >"$run/executables-after.log"
test -z "$(ls -A "$run/tmp")"
