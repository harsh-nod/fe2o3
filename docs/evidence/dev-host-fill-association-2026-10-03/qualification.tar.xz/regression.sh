#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-host-fill-20261003-9rv3DKsH
trap 'printf "%s\n" "$?" >"$scratch/regression.status"' EXIT
printf '%s\n' "$$" >"$scratch/regression.pid"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --test compiler_proof_binding_v4 \
  >"$scratch/proof-binding-v4.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --lib conditional_fill_program_v1::tests \
  >"$scratch/conditional-program.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib >"$scratch/host-lib.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --doc >"$scratch/host-doc.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
  --test worker_v3_load_envelope_vertical -- --skip strict_v3_ --skip cargo_supervisor_and_static_host_consumer \
  >"$scratch/vertical-regression.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
  --test worker_v3_load_envelope_v2 >"$scratch/v2-regression.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-hsaco-finalize --test worker_v3_hsaco_admission \
  >"$scratch/finalizer-regression.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-host --lib --no-deps -- -D warnings \
  >"$scratch/host-clippy.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only \
  --test worker_v3_load_envelope_vertical --no-deps -- -D warnings >"$scratch/vertical-clippy.log" 2>&1
