#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-root-app-registry-20261004-JdOkcKyH
source=f439ede594745372e3da7221cb0e901fc3a0bcb4
cd "$repo"
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$out/allowed-signers" verify-commit "$source"
git show --no-patch --format=fuller "$source"
git diff --exit-code "$source" -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**'
test -z "$(git ls-files --others --exclude-standard -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**')"
cmp "$out/source-before.sha256" "$out/source-after.sha256"
sha256sum --quiet --check "$out/source-before.sha256"
git show --format= --binary "$source" > "$out/committed-source.patch"
cmp "$out/source.patch" "$out/committed-source.patch"
sha256sum --check "$out/test-binaries.sha256"
wc -l "$out/source-before.sha256" "$out/test-binaries.sha256"
