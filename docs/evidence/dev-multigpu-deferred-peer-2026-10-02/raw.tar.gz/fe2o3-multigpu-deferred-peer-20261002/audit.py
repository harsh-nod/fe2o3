#!/usr/bin/env python3
"""Read-only qualification audit; no build, solver, Git write or remote execution."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy
import shlex
import struct
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '43c70ad45bf14f67a4a04d691a0925e374453589'
PRIOR = REPO / 'docs/evidence/dev-multigpu-live-batches-2026-10-02/raw.tar.gz'
# This identity is independently pinned to the published baseline, not a new run.
PRIOR_SHA = '1a786ff9cbba97c110b1a8b9999f81b6897d9e54604c96e89e2e54f8c9d40b9a'
PRIOR_PREFIX = 'fe2o3-multigpu-live-batches-20261002/'
EXAMPLES = {'example': 9, 'production-example': 3, 'sharded-example': 7,
            'pending-example': 4, 'compute-sharded-example': 11,
            'live-sharded-example': 5}
DEFERRED_TESTS = {
    'data::tests::cli_preserves_two_explicit_device_identities_and_rejects_ambiguity',
    'data::tests::independent_inputs_oracle_and_full_write_extent_match_unchanged_r57_v2',
    'data::tests::full_output_rejects_initial_sentinels_missing_compute_corruption_and_wrong_extent',
    'data::tests::callbacks_require_all_four_original_ids_once_and_success',
}
# Reviewed source-freeze selection; receipts remain mandatory for acceptance.
SELECTION = {
    'campaign_sha256': '25f3889bef431f48287788c68ad5f60e61f1dd69a2628a04c2a36edcf00146a0',
    'metadata': {
        'changed': 10, 'counts': {'content-sha256': 17, 'source-inventory-count': 7},
        'proof_files': 76, 'audited_files': 1046,
        'runtime_files': 365, 'runtime_and_schema_files': 370,
    },
    'added_tests': [
        *['context::tests::compute_peer_tests::deferred_chain::compute_peer_deferred_chain_' + name
          for name in [
            'observes_four_original_roots_and_actual_mock_bytes',
            'cancel_releases_only_each_exact_consumer',
            'nested_launch_journal_drift_precedes_observation',
            'bad_parent_rank_rejects_before_recursive_validation',
            'exact_event_and_retain_capacity_reject_before_issue',
            'ancestor_faults_preserve_disposition_and_custody',
          ]],
        *['kfd_backend::tests::compute_peer_tests::deferred::deferred_compute_peer_' + name
          for name in [
            'final_stream_drives_four_roots_after_event_release',
            'accepts_routed_producer_and_retains_completed_identity',
            'rejection_is_pre_effect_and_no_staged_fallback',
            'cancel_and_failed_parent_refund_only_safe_roots',
            'incoming_cancellation_propagates_without_false_success',
            'exact_depth_boundary_is_checked_before_retains',
            'forged_handoff_and_backward_rank_fail_closed',
            'compute_uncertainty_retains_payload_and_all_ancestors',
          ]],
    ],
    'changed_source_paths': [
        *['crates/fe2o3-runtime-model/verus/' + name for name in [
            'check-request-charge.py', 'check-retained-credit-dispatch.py',
            'check-producer-input-fold.py', 'check-producer-input-validate.py',
            'check-producer-journal-observers.py', 'check-retained-pair-routing.py',
            'check-producer-input-composition.py', 'check-producer-journal-composition.py',
            'test-producer-input-composition.py', 'producer-journal-composition-mutations-v1.py',
        ]],
        *['crates/fe2o3-runtime/' + name for name in [
            'Cargo.toml', 'examples/gfx942-runtime-deferred-peer-chain-smoke.rs',
            'examples/deferred_peer_chain/data.rs',
            'src/context/tests/compute_peer_tests.rs',
            'src/context/tests/compute_peer_tests/deferred_chain.rs',
            'src/kfd_backend.rs', 'src/kfd_backend/compute_peer.rs',
            'src/kfd_backend/compute_peer/tests.rs', 'src/kfd_backend/compute_peer/deferred_tests.rs',
            'src/kfd_backend/deferred_compute.rs', 'src/kfd_backend/deferred_compute/producer.rs',
            'src/kfd_backend/deferred_compute/tests.rs',
            'src/kfd_backend/deferred_compute/tests/completed_results.rs',
        ]],
    ],
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *args], cwd=REPO)


def manifest(raw):
    result = {}
    for line in raw.decode().splitlines():
        digest, name = line.split('  ', 1)
        assert re.fullmatch('[0-9a-f]{64}', digest) and name not in result
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        result[name] = digest
    return result


def test_result(raw):
    text = raw.decode()
    summary = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; 0 filtered out; finished in .+$', text, re.M)
    assert len(summary) == 1
    passed, ignored = map(int, summary[0])
    rows = re.findall(r'^test (\S+) \.\.\. (ok|ignored)(?:, [^\n]*)?$', text, re.M)
    assert len(rows) == passed + ignored and len(dict(rows)) == len(rows)
    assert sum(state == 'ok' for _, state in rows) == passed
    return dict(rows), passed, ignored


def roster(raw):
    text = raw.decode()
    rows = re.findall(r'^(\S+): test$', text, re.M)
    summaries = re.findall(r'^(\d+) tests, 0 benchmarks$', text, re.M)
    assert len(summaries) == 1 and int(summaries[0]) == len(set(rows)) == len(rows)
    return set(rows)


def reference():
    path = ROOT / 'reference-audit.py'
    assert sha(path.read_bytes()) == 'f6bc8f780a880d1c30aca555a6455202390346f004f117e133ae2f426124dacc'
    namespace = runpy.run_path(str(path), run_name='reused_read_only_audit')
    shared = namespace['audit_metadata'].__globals__
    shared.update(ROOT=ROOT, REPO=REPO, BASE=BASE, FINAL=SELECTION,
                  SUPPORT_SHA=sha((ROOT / 'source-ci/support.py').read_bytes()))
    return namespace


def exact_commands(ref, mode, selected):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', '-p', 'fe2o3-runtime']
    runtime = (selected / 'build/fe2o3_runtime.path').read_text().strip()
    kfd = (selected / 'build/fe2o3_kfd.path').read_text().strip()
    if mode == 'precheck':
        return {'clippy': (1200, cargo + ['clippy', '--locked', '--offline', '-p',
            'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--tests',
            '--no-deps', '--', '-D', 'warnings'])}
    if mode == 'format':
        return {name: value for name, value in ref['stage_commands']('checks', runtime, kfd).items()
                if name in ['formatting', 'whitespace']}
    commands = ref['stage_commands'](mode, runtime, kfd)
    if mode == 'checks':
        name = 'gfx942-runtime-deferred-peer-chain-smoke'
        commands.update({
            'deferred-clippy': (1200, cargo + ['clippy', *common, '--all-features', '--example', name, '--no-deps', '--', '-D', 'warnings']),
            'deferred-example': (1200, cargo + ['test', *common, '--all-features', '--example', name, '--', '--test-threads=1']),
            'deferred-witness-build': (1200, cargo + ['build', *common, '--all-features', '--profile', 'test', '--example', name]),
        })
    return commands


def audit_hardware(ref, hardware, selected):
    hw = ROOT / hardware
    data = read_json(hw / 'campaign.json')
    assert data['accepted'] and data['owned_cleanup_complete'] and not data['errors']
    assert data['selected_build_attempt'] == selected.name
    assert not any(data[key] for key in ['performance_acceptance', 'formal_refinement', 'exclusive_reservation'])
    assert sha((hw / 'campaign.py').read_bytes()) == SELECTION['campaign_sha256']
    campaign = runpy.run_path(str(hw / 'campaign.py'), run_name='offline_campaign_schema')
    assert data['limitations'] == campaign['LIMITATIONS']
    assert sha((hw / 'capture.py').read_bytes()) == 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f'
    ids = ['0x10a254ce4987e716', '0x53691ef168a0147d']
    cases = [('deferred-chain-forward', 'deferred', [], ids),
             ('deferred-chain-reverse', 'deferred', [], ids[::-1]),
             ('live-sharded-2', 'live-sharded', [], ids),
             ('compute-sharded-2-queued-round-0', 'compute-sharded', ['--queued-compute', '--round', '0'], ids)]
    assert campaign['CASES'] == cases
    assert len(data['completed']) == data['expected_cases'] == 4
    assert [row['name'] for row in data['completed']] == [case[0] for case in cases]
    directory = data['owned_directory']
    assert re.fullmatch('/tmp/fe2o3-multigpu-deferred-peer-20261002-[A-Za-z0-9]{6}', directory)
    binaries = data['binaries']
    kinds = {'deferred': 'gfx942-runtime-deferred-peer-chain-smoke',
             'live-sharded': 'gfx942-runtime-live-sharded-vecadd-smoke',
             'compute-sharded': 'gfx942-runtime-sharded-vecadd-capture-smoke'}
    assert set(binaries) == set(kinds)
    for kind, name in kinds.items():
        binary = binaries[kind]
        path = 'target/debug/examples/' + name
        assert binary['local'] == str(REPO / path) and binary['remote'] == directory + '/' + kind + '-witness'
        assert (selected / 'checks' / (kind + '-witness.sha256')).read_text().strip() == binary['sha256'] + '  ' + path
        assert sha((REPO / path).read_bytes()) == binary['sha256']
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
    seen = set()
    previous = None
    def receipt(name, argv, bound='30s', local=False):
        nonlocal previous
        folder = hw / name
        row = read_json(folder / 'result.json')
        assert row['argv'] == (argv if local else ssh + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]), name
        assert row['exit_code'] == 0 and not row['timed_out'] and row['local_process_group_absent'], name
        start, end = map(datetime.fromisoformat, [row['started'], row['finished']])
        assert 0 <= (end - start).total_seconds() <= 245 and (previous is None or start >= previous)
        previous = end
        for channel in ['stdout', 'stderr']:
            assert sha((folder / channel).read_bytes()) == row[channel + '_sha256']
        assert name not in seen
        seen.add(name)
        return (folder / 'stdout').read_text()
    availability = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']
    baseline = json.loads(receipt('initial-availability', availability))
    def admit(name):
        state = json.loads(receipt(name + '-availability', availability))
        for card, uid, bus in zip(['card6', 'card7'], ids, ['0000:C6:00.0', '0000:E5:00.0']):
            assert state[card]['Unique ID'] == baseline[card]['Unique ID'] == uid
            assert state[card]['PCI Bus'] == baseline[card]['PCI Bus'] == bus
            assert state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0'
            for key in ['VRAM Total Memory (B)', 'VRAM Total Used Memory (B)']:
                assert state[card][key] == baseline[card][key]
        assert state['system'] == baseline['system']
        mapping = receipt(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        pids = {}
        for pid, count, colon, attached in re.findall(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            attached = attached.split()
            assert 'PID' + pid not in pids and int(count) == len(attached) == len(set(attached))
            assert bool(colon) == bool(attached) and not {'6', '7'}.intersection(attached)
            pids['PID' + pid] = attached
        assert set(pids) == set(state['system'])
        assert all(int(state['system'][pid].split(',')[1]) == len(attached) for pid, attached in pids.items())
        memory = receipt(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        matches = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(matches) == 1 and int(matches[0]) >= 8 * 1024 * 1024
    admit('baseline')
    start = datetime.fromisoformat(read_json(hw / 'baseline-availability/result.json')['started'])
    end = datetime.fromisoformat(read_json(hw / 'initial-availability/result.json')['finished'])
    assert 0 <= (start - end).total_seconds() <= 300
    assert receipt('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-deferred-peer-20261002-XXXXXX']).strip() == directory
    for kind in kinds:
        binary = binaries[kind]
        receipt('upload-' + kind, ['scp', *ssh[1:-1], binary['local'], 'mi300x:' + binary['remote']], local=True)
        assert receipt('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    output = b''.join(struct.pack('<f', ((index & 63) + 4 * (index & 31)) / 4) for index in range(65536))
    totals = dict(launches=0, peer_copies=0, dependent_readbacks=0, completion_receipts=0)
    for report, (name, kind, flags, roster_ids) in zip(data['completed'], cases):
        admit(name)
        lines = receipt(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
            'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', binaries[kind]['remote'], *flags, *roster_ids], '180s').splitlines()
        assert len(lines) == 1 and lines[0].startswith('PASS ')
        pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
        fields = dict(pairs)
        expected = campaign['expected'](kind, flags, roster_ids)
        if kind == 'deferred':
            assert expected['output_sha256'] == sha(output) and len(output) == 262144
        else:
            assert expected == ref['hardware_expected'](kind, flags, roster_ids, ref['independent_vecadd_digests']())
        assert len(pairs) == len(fields) and fields == report['fields'] == expected
        assert not (hw / name / 'stderr').read_bytes()
        for key in totals:
            totals[key] += int(fields[key])
        admit(name + '-post')
    assert totals == dict(launches=14, peer_copies=10, dependent_readbacks=8, completion_receipts=26)
    paths = [binaries[kind]['remote'] for kind in kinds]
    process_row = read_json(hw / 'final-owned-processes/result.json')
    outer = process_row['argv']
    assert outer[:-1] == ssh
    process_argv = shlex.split(outer[-1])
    assert process_argv[:7] == ['/usr/bin/timeout', '--kill-after=5s', '30s', '/usr/bin/python3', '-I', '-B', '-c']
    assert process_argv[8:] == paths
    probe = ('import json,os,sys; from pathlib import Path; '
        'paths=set(sys.argv[1:]); found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    assert process_argv[7] == probe
    assert json.loads(receipt('final-owned-processes', process_argv[3:])) == {'owned_executable_pids': []}
    for kind in kinds:
        binary = binaries[kind]
        assert receipt('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    assert not receipt('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    assert not receipt('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    assert not receipt('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    admit('final')
    assert {folder.name for folder in hw.iterdir() if folder.is_dir()} == seen
    return data


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert SELECTION is not None, 'final source and test selection must be reviewed'
    ref = reference()
    attempt, proposal, workflow, hardware = sys.argv[1:]
    assert re.fullmatch(r'attempt-\d+', attempt)
    assert re.fullmatch(r'proposal-\d+', proposal)
    assert re.fullmatch(r'attempt-\d+-after', workflow)
    assert re.fullmatch(r'hardware-\d+', hardware)
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert not (ROOT / 'qualification.json').exists()
    assert sha(PRIOR.read_bytes()) == PRIOR_SHA
    with tarfile.open(PRIOR, 'r:gz') as archive:
        def prior(name):
            member = archive.getmember(PRIOR_PREFIX + name)
            assert member.isfile()
            return archive.extractfile(member).read()
        accepted = json.loads(prior('qualification.json'))
        assert accepted['accepted'] and accepted['runtime']['passed'] == 2082
        old_tests, _, old_ignored = test_result(prior('attempt-03/tests/fe2o3_runtime-full.stdout'))
        assert old_ignored == 32
        old_sources = manifest(prior('attempt-03/build/source-before.sha256'))
        old_kfd_roster = prior('attempt-03/build/kfd-full-list.stdout')
        old_example_tests = {name: test_result(prior('attempt-03/checks/' + name + '.stdout'))[0]
                             for name in EXAMPLES}
    selected = ROOT / attempt
    source_raw = (selected / 'build/source-before.sha256').read_bytes()
    sources = manifest(source_raw)
    roster_raw = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
                     'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo')
    assert set(sources) == {name.decode() for name in roster_raw.split(b'\0') if name}
    selectors = ['crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo']
    changed = set(git('diff', BASE, '--name-only', '--', *selectors).decode().splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard', '--', *selectors).decode().splitlines())
    assert changed == set(SELECTION['changed_source_paths'])
    for name, digest in sources.items():
        assert sha((REPO / name).read_bytes()) == digest, name
    expected_env = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin',
        LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
        CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1',
        CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
        RUST_TEST_THREADS='1', PWD=str(REPO))
    modes = ['format', 'precheck', 'build', 'tests', 'checks']
    for mode in modes:
        folder = selected / mode
        assert (folder / 'overall.exit').read_text() == '0\n', mode
        assert (folder / 'controller.sh').read_bytes() == (ROOT / 'verify.sh').read_bytes()
        assert (folder / 'source-before.sha256').read_bytes() == source_raw
        assert (folder / 'source-after.sha256').read_bytes() == source_raw
        assert (folder / 'base.txt').read_text().strip() == BASE
        environment = dict(line.split('=', 1) for line in (folder / 'environment.txt').read_text().splitlines())
        assert all(environment.get(key) == value for key, value in expected_env.items())
        assert set(environment) <= set(expected_env) | {'OLDPWD', 'SHLVL', '_'}
        stages = list(folder.glob('*.command'))
        commands = exact_commands(ref, mode, selected)
        assert {command.stem for command in stages} == set(commands)
        assert {path.stem for path in folder.glob('*.exit')} == set(commands) | {'overall'}
        for suffix in ['started', 'finished', 'stdout', 'stderr']:
            assert {path.stem for path in folder.glob('*.' + suffix)} == set(commands)
        for command in stages:
            name = command.stem
            assert (folder / (name + '.exit')).read_text() == '0\n', (mode, name)
            assert (folder / (name + '.stdout')).is_file()
            assert (folder / (name + '.stderr')).is_file()
            seconds, argv = commands[name]
            assert shlex.split(command.read_text()) == argv, (mode, name)
            start, end = [datetime.fromisoformat((folder / (name + '.' + phase)).read_text().strip())
                          for phase in ['started', 'finished']]
            assert 0 <= (end - start).total_seconds() <= seconds + 35
    rows, passed, ignored = test_result((selected / 'tests/fe2o3_runtime-full.stdout').read_bytes())
    assert passed > 2082 and ignored == 32
    assert set(rows) == roster((selected / 'tests/fe2o3_runtime-full-list.stdout').read_bytes())
    assert all(rows.get(name) == result for name, result in old_tests.items())
    added = sorted(set(rows) - set(old_tests))
    assert added == sorted(SELECTION['added_tests'])
    artifacts = [json.loads(line) for line in (selected / 'build/runtime.stdout').read_text().splitlines()]
    assert artifacts[-1].get('reason') == 'build-finished' and artifacts[-1]['success']
    for target in ['fe2o3_kfd', 'fe2o3_runtime']:
        digest, path = (selected / 'build' / (target + '.sha256')).read_text().strip().split(maxsplit=1)
        assert path == (selected / 'build' / (target + '.path')).read_text().strip()
        emitted = {item['executable'] for item in artifacts if item.get('reason') == 'compiler-artifact'
                   and item.get('target', {}).get('name') == target and item.get('profile', {}).get('test')
                   and item.get('executable')}
        assert emitted == {path} and Path(path).parent == REPO / 'target/debug/deps'
        assert sha(Path(path).read_bytes()) == digest
        if target == 'fe2o3_kfd':
            assert digest == accepted['kfd']['executable_sha256']
            assert (selected / 'build/kfd-full-list.stdout').read_bytes() == old_kfd_roster
        else:
            runtime_sha = digest
            for phase in ['before', 'after']:
                assert (selected / 'tests' / (target + '-' + phase + '.sha256')).read_bytes() == (selected / 'build' / (target + '.sha256')).read_bytes()
    kfd_sources = {name: digest for name, digest in old_sources.items() if name.startswith('crates/fe2o3-kfd/')}
    assert {name: digest for name, digest in sources.items() if name.startswith('crates/fe2o3-kfd/')} == kfd_sources
    examples = {}
    for name in [*EXAMPLES, 'deferred-example']:
        current, count, skipped = test_result((selected / 'checks' / (name + '.stdout')).read_bytes())
        assert count > 0 and skipped == 0
        if name in EXAMPLES:
            assert current == old_example_tests[name] and count == EXAMPLES[name]
        else:
            assert set(current) == DEFERRED_TESTS and count == 4
        examples[name] = count
    report = ref['audit_metadata'](proposal)
    ref['audit_workflow'](workflow, proposal, report)
    assert report['baseline'] == BASE
    for key in ['all_baseline_audits_passed', 'all_proposed_source_audits_passed',
                'ast_identical_except_listed_metadata_constants',
                'predicates_contracts_and_proof_counts_unchanged']:
        assert report[key], key
    assert len(report['proof_files']) == 76
    for name in report['proof_files']:
        assert (REPO / name).read_bytes() == git('show', BASE + ':' + name)
    controls = read_json(ROOT / 'source-ci' / workflow / 'result.json')
    assert controls['accepted'] and controls['command_count'] == 32 and controls['source_unchanged'] and not controls['failed']
    inputs = read_json(ROOT / 'source-ci' / workflow / 'inputs.json')
    assert inputs['head'] == BASE
    assert inputs['commands'] == read_json(ROOT / 'source-ci/reference/inputs.json')['commands']
    hardware_result = audit_hardware(ref, hardware, selected)
    result = dict(accepted=True, baseline=BASE, attempt=attempt, proposal=proposal,
        workflow=workflow, hardware=hardware, audited_at=datetime.now(timezone.utc).isoformat(),
        runtime=dict(passed=passed, ignored=ignored, failed=0, executable_sha256=runtime_sha),
        added_tests=added, examples=examples, source_files=len(sources),
        source_snapshot_sha256=sha(source_raw), controller_sha256=sha((ROOT / 'verify.sh').read_bytes()),
        source_controls=32, unchanged_proof_files=76, kfd=dict(passed=1925, fresh_run=False,
            executable_sha256=accepted['kfd']['executable_sha256'], unchanged_sources=len(kfd_sources),
            accepted_baseline_archive_sha256=PRIOR_SHA),
        hardware_receipt=hardware_result, formal_refinement=False, performance_acceptance=False,
        audit_sha256=sha(Path(__file__).read_bytes()))
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', *selectors) == roster_raw
    for name, digest in sources.items():
        assert sha((REPO / name).read_bytes()) == digest
    for target in ['fe2o3_kfd', 'fe2o3_runtime']:
        digest, path = (selected / 'build' / (target + '.sha256')).read_text().strip().split(maxsplit=1)
        assert sha(Path(path).read_bytes()) == digest
    with (ROOT / 'qualification.json').open('x') as target:
        json.dump(result, target, indent=2, sort_keys=True)
        target.write('\n')
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
