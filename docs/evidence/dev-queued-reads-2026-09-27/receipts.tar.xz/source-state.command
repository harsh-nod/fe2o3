git show --stat --format=fuller HEAD 
