git show --format=fuller --no-ext-diff HEAD 
