git -c gpg.format=ssh -c user.signingkey=/home/harsh/.ssh/id_ed25519 commit -q -S -s -m runtime:\ retain\ exact\ queued-producer\ read\ custody\ through\ completion 
