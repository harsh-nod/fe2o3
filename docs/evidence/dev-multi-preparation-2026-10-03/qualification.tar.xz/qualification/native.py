"""Bounded selected-pair no-queue witness using the reviewed process controller."""
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
from types import ModuleType

HERE = Path(__file__).resolve().parent
SHARED = 'd586fd438e6bb4c399b9dc73bfea3475365c33cd3802defa186e10e81f859f65'


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode
    raw = (HERE / 'selected_pair_smoke.py').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SHARED
    shared = ModuleType('selected_pair_smoke')
    shared.__file__ = str(HERE / 'selected_pair_smoke.py')
    exec(compile(raw, shared.__file__, 'exec'), shared.__dict__)
    binary_text, digest, first, second = sys.argv[1:]
    binary = Path(binary_text)
    assert binary.resolve(strict=True) == binary
    assert binary.name == 'gfx942-runtime-multi-preparation-smoke'
    pair = shared.endpoints([first, second])
    helper = shared.load_observer()
    output = HERE / 'native-results'
    output.mkdir()
    recorder = shared.Recorder(output)
    for number in shared.MANAGED:
        signal.signal(number, shared.interrupted)
    fd = os.open(binary, os.O_RDONLY | os.O_NOFOLLOW)
    result = dict(accepted=False, devices=pair, cases=[], started=shared.stamp())
    try:
        identity = shared.fingerprint(fd)
        assert identity['sha256'] == digest
        result['binary_identity'] = identity
        for name, selected in [('forward', pair), ('reverse', tuple(reversed(pair)))]:
            shared.observe_pair(recorder, helper, pair, Path('/opt/rocm/bin/rocm-smi'), name + '-before')
            assert shared.fingerprint(fd) == identity
            try:
                receipt = recorder.run(name, [str(binary), selected[0][2], selected[1][2]], 60,
                                       executable=f'/proc/self/fd/{fd}', pass_fds=(fd,))
                actual = shared.command_text(recorder, name, receipt)
                ids = ', '.join(f'{int(row[2], 16):x}' for row in selected)
                expected = (f'multi-preparation PASS devices=[{ids}] direct=2 reverse_validation=2 '
                            'callback_errors=2 async=2 reservation_rejected=1 discarded=1 '
                            'shutdown_dropped=1 released=true\n')
                assert actual == expected, (actual, expected)
                assert shared.fingerprint(fd) == identity
                metadata = binary.stat()
                assert (metadata.st_dev, metadata.st_ino) == (identity['device'], identity['inode'])
            finally:
                shared.observe_pair(recorder, helper, pair, Path('/opt/rocm/bin/rocm-smi'), name + '-after')
            result['cases'].append(dict(name=name, accepted=True, expected=expected))
        result['accepted'] = True
    finally:
        os.close(fd)
        result.update(commands=recorder.commands, finished=shared.stamp())
        shared.save(output / 'result.json', result)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
