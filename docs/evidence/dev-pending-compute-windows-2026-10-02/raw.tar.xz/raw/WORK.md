# Pending Compute Windows

Baseline: 090beb6f8eda93e68c43726e0be594ae20c014c2.

Scope: retain a pending producer's sole full-allocation Write while admitting a
checked contained ordinary peer-copy window into an independently bounded public
DeviceLocal destination, followed by a dependent D2H window. Preserve whole-owner
custody and exact event, producer and retained window identities. No KFD transfer
algorithm, compute authority, partial Write or concurrent-slice extension.

Context and backend agents own disjoint Rust modules. Root owns the existing
deferred-peer example, integration, tests, shared-host admission/cleanup and Git.
The review agent owns read-only invariant review and minimal source-CI proposals.

Native witness uses unchanged R57 V2 authority, both GPU orders, full D/E/Host
byte checks with guards, and explicit cleanup. No performance, physical overlap,
general application authority or whole-adapter formal refinement claim.
