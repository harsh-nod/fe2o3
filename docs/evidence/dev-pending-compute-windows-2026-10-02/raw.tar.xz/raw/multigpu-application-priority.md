# Application Multi-GPU: Next Priority

Read-only source assessment, 2026-10-02, during pending-compute-window
qualification. Paths below are relative to the repository. No repository source
changes, builds, proof runs or hardware executions accompanied this assessment.

## What Is Already Usable

`crates/fe2o3-runtime/src/kfd_backend/multi_open.rs:24,37` already opens PUBLIC
multi-device Contexts with the caller's retained production or semantic launch
authorities. Ordinary typed allocations/launches, producer events, native peer
windows, deferred consumers and dependent D2H do not need another constructor.
A deployment with a genuine reviewed authority can use these APIs now; the
repository's finite qualification gates do not supply that authority.

The exact ordinary authority request is in `kfd_backend.rs:531`; the unsafe
`KfdRuntimeLaunchAuthorityV1` contract at `:572` requires authenticated compiler
lineage plus invocation-specific ABI, effects, bounds, alias, initialization and
completion/quiescence evidence. A valid HSACO, matching digest, successful GPU
test, or caller returning `true` is not sufficient.

## Concrete Missing Provider

The existing Worker V3 artifact path already carries the inputs needed to join
an actual proof: compiler-generated marker/packing, retained semantic MIR/KIR,
final LLVM, selected machine range, linked HSACO and publication/currentness.
It deliberately does not infer the missing theorem from those identities.

- `crates/fe2o3-host/src/worker_v3_verification_admission.rs:1068` defines the
  external protected-verifier backend: independent policy, protected Worker
  ledger, rollback/currentness, finalizer and compiler/proof evidence checks.
- Its `WorkerV3SemanticMachineRefinementBackendV1` at `:1102` additionally requires
  an authenticated proof covering the exact source-to-final-machine relation,
  ABI, CFG, addresses, executable memory effects and required numerical semantics.
  `WorkerV3ProtectedSemanticMachineRefinementEvidenceV1::new` validates artifact
  representation only; it is not that provider or a theorem checker.
- `WorkerV3RefiningProtectedVerifierAdapterV1` at `:1167-1260` already joins these
  outputs, catches backend unwind, checks protected prerequisites and seals the
  exact receipt. Search of current implementations found test providers, not a
  shipped production implementation of these external contracts.
- `generated_kfd_invocation.rs:306-327,455` explicitly confirms no concrete
  production proof backend/authenticated artifact ships. The application binding
  is move-only, retains the admitted receipt and cannot be extracted into an
  ordinary runtime permit.

Thus the missing deliverable is one real, reviewed producer/checker of the exact
compiled kernel's protected semantic-to-machine/effects evidence, together with
the actual protected verification provider. It is not a new boolean authority
adapter, generic orchestration API, or another finite workload gate. The local
S_ADD_U32 arithmetic/conditional correspondence component does not close the
LLVM/CFG/ABI/memory-effect and source/register correspondence obligations.

## Shortest Existing Integration Route

1. Select one small application kernel already representable by the production
   compiler, with a bounded slice interface and no atomics, collectives or
   cross-workgroup communication. First require an identified genuine evidence
   provider and an exact produced artifact. Do not spend another increment on a
   wrapper whose only positive path is a synthetic verifier.
2. Reuse the existing compiler/Cargo Worker V3 handoff:
   `rustc-codegen-fe2o3/src/production_pipeline.rs`,
   `production_worker_handoff.rs:68`, and
   `cargo-fe2o3/src/main.rs:2242`. Feed the real providers through the existing
   refining adapter and `fe2o3-host/src/production_application.rs:88` inherited
   authentication. Qualify one actual artifact through this existing chain before
   changing multi-device plumbing. The current-thread runner at
   `production_application/current_thread.rs:226` is already present but expressly
   requires those providers; it does not implement them.
3. For a deployment already supplying an independently reviewed ordinary
   `KfdRuntimeLaunchAuthorityV1`, use the existing native-peer constructor
   directly. This is the shortest multi-GPU route and requires no host-wrapper
   change. For the repository's generated Worker route, a separate ownership
   bridge remains: `generated_runtime_invocation.rs:340` targets only
   `RuntimeContextV1<KfdRuntimeBackendV1>` and private generated persistent storage.
   Its generated execution authority is the distinct private
   `WorkerV3Gfx942ExecutionAuthorityV1` implementation at
   `generated_kfd_invocation.rs:611`, not an ordinary Context authority. Only after
   real evidence exists should an exact request projection retain that original
   owner/receipt/currentness across ordinary PUBLIC allocation bindings. Do not
   clone/extract a permit, retag private storage PUBLIC, or merely genericize the
   Context type. Device and actual invocation/address-free binding validation
   must remain part of each authorized publication.

## Prerequisite Tests and Exit Criterion

- Real compiler/artifact positive: authenticate the produced proof and exact
  source/KIR/LLVM/ISA/HSACO ownership through the refining adapter. Test provider
  fixtures may verify rejection plumbing but cannot satisfy this positive gate.
- Substitution negatives: changed artifact, machine effects, source operand or
  result mapping, ABI/layout, kernel/signature, geometry, range, alias and
  initialization; stale publication/rollback/device generation; missing proof,
  provider error and unwind. Denial must precede allocation extraction/publication
  and preserve or conclusively release the original owners.
- Preserve `require_runtime_evidence` (`generated_runtime_invocation.rs:371`):
  protected-only and synthetic evidence must still fail before argument callbacks
  or Context work. Keep move-only/no-extraction and generated-only separation
  compile-fail tests. Existing scaffolds include
  `cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs` and
  `fe2o3-host/tests/production_application_handoff_ui.rs`; their synthetic success
  paths are not production proof acceptance.
- Once the authority is real, run the modest application workload on two GPUs:
  ordinary PUBLIC input/output allocations, actual compute -> native window ->
  pending D2H, exact events released before final-only progress, complete guard
  and independently computed output checks, then a changed-input second batch
  in the same live Context where the admitted theorem permits it. Require exact
  completion/result custody, finite deadlines and owned cleanup; claim neither
  arbitrary kernels nor speedup from this one integration.

Decision: do not schedule another conditional wrapper or isolated instruction
proof as an application unlock. Either integrate a concrete evidence provider
through these existing boundaries, or keep application admission explicitly open
while shipping useful, independently testable runtime routing improvements.
