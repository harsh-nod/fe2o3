# Next Step: Ordered Gather into One Device Allocation

Read-only design from the pending-compute-window candidate based on
`090beb6f8eda93e68c43726e0be594ae20c014c2`. This is not implemented or qualified.

## What Works Without a Runtime Change

One Context can already gather serially: allocate and initialize one destination,
copy each independently bounded source shard into its disjoint destination
window, observe that original peer Succeeded, then admit the next peer. Pending
compute sources use their exact producer events. Keep the current-thread owner
open between steps; do not call begin_drain until all admissions are finished.
After the last peer has logically settled, one ordinary full-allocation D2H copy
can read the assembled output. This needs an example/application loop and tests,
not weaker allocation exclusion or a new gather API. It is a genuinely gathered
buffer but is not an all-prequeued gather or an overlap demonstration.

## Exact All-Prequeued Blockers

For `P0: S0 -> D[a..b]` and `P1: S1 -> D[c..d]`, disjoint intervals alone do not
authorize simultaneous access to D. Even an explicit P0 event does not currently
enable P1 while P0 is pending:

- `context/peer_custody/compute_peer.rs::prepare_compute_peer_custody_v1` accepts
  the exact pending source compute writer, but requires every other dependency
  already Succeeded and quiescent. A pending destination predecessor is rejected.
- `context/versions/submissions.rs::submit_context_operation_v1` supplies a
  queued-writer profile only for typed launches. For peers, its
  `prepare_submission_writer_profile_v1` rejects an existing/latest destination
  writer with ContextReserved. The launch-only queued profile deliberately
  requires full overwrite; do not remove that rule to admit partial peers.
- `kfd_backend/compute_peer.rs::require_compute_peer_controls_v1` likewise
  rejects a noncompute dependency that is not already successful. The ordinary
  native selector cannot select through a destination owner already extracted
  by another ordinary peer. Pre-admitting every gather edge before any progress
  avoids that latter boundary for a first increment.
- The cooperative allocation index already permits same-stream serial owners;
  cross-stream admission requires each indexed owner in the explicit dependency
  set. Use one destination stream initially, rather than changing that policy.

## Smallest Queued Production Slice

Keep the public `peer_copy` API. Initially permit only compute-backed ordinary
native peers, already covered by the opt-in success-dependency contract. Each
source remains one exact full-allocation compute Write; each transfer retains a
checked source window and disjoint destination interval in the same initialized
allocation D. P0 carries its compute event; Pi carries its compute event and the
exact event for Pi-1, the current/latest writer of D. All Pi use one destination
stream and are admitted before driving any peer. Start with two sources and a
dedicated sink on three devices; same-device contribution from the sink is a
separate unsupported profile, not an implicit peer copy.

Retain the destination predecessor independently of public events, including its
exact writer reference, allocation record, interval, stream and bounded rank.
Validate the full ordered chain for interval disjointness; checking only the
immediate predecessor does not exclude overlap with P0 when admitting P2. Keep
one physical destination owner. Pi may acquire it only after Pi-1 actually
succeeded, retired its queue and restored both original owners. No access is
granted merely because byte intervals do not overlap.

Narrow ownership split for implementation:

1. Context lane: new ordered-peer helper under `context/peer_custody`, selected
   through `compute_peer.rs`; narrow `versions/submissions.rs` profile handling
   for a whole-allocation queued writer tied to this exact predecessor. Reuse
   `ContextQueuedWriterJournalV1` admission/activation/settlement rather than
   implementing a second writer queue. Extend retained pending-peer validation,
   parent reconciliation and disposal only for this explicit profile. Preserve
   queued launch restrictions and current producer-read input validation.
2. Backend lane: `kfd_backend/compute_peer.rs` retains/authenticates the exact
   pending gather predecessor as an additional success dependency, not an
   unrelated resource blocker. Reuse cooperative oldest-ancestor progress,
   existing same-stream ordering, immutable windows and whole-owner extraction.
   Keep late ordinary admission, unrelated controls and staged fallback rules
   unchanged; add a narrow call-site/profile hook only if required.
3. Test/witness lane: dedicated Context and backend child test modules, plus a
   separate bounded gather example or optional mode without changing old schemas.
   No KFD transfer, arithmetic body, new finite kernel gate or evidence framework.

## Final Readback Boundary

Do not attach a pending full-buffer D2H to only the last partial peer. Current
`copy_custody.rs` and `ScalarPeerCopyRootV1::covers_input_v1` correctly require
the selected peer to cover the complete requested read. The last gather writer
covers only its own interval, even though earlier writes are ordered ancestors.

The first queued-gather increment should drive the final peer, logically settle
all gather ancestors, and only then admit the full D2H while the owner remains
open. This requires a host control-plane join, not a host data round trip. A
fully preadmitted aggregate readback needs a separate authenticated interval-union
and lineage contract; do not silently pretend the last partial writer wrote D.

## Required Tests

- Two and three unequal source shards, one initialized larger destination,
  nonzero offsets, exact end bounds, holes/guards preserved and full byte oracle.
- All peers admitted before progress, exact source and destination predecessor
  events released afterward, final-peer-only bounded progress, immutable owner
  identity restoration, zero staging, native counters only after final restore.
- Reject missing/wrong/stale predecessor, wrong destination or stream, older-but-
  not-latest writer, overlap with any ancestor, partial/aliased compute writers,
  invalid bounds, duplicate events, rank overflow and exhausted journal capacity.
- Failure/cancellation/Unknown at every chain position: no descendant copying,
  no automatic reparenting, retained uncertain owners, exact queued-writer and
  source-read refunds. Check logical lineage and callbacks in ancestor order.
- Expired/resumed drain preserves the same roots; pending full-buffer D2H remains
  rejected until the explicit join. Successful settled D2H checks every byte.

These are adapter changes, not a new proof of the journal or DMA implementation.
Require real native qualification and exact cleanup before claiming working
queued gather; do not infer concurrency, arbitrary graph support or performance.
