#!/usr/bin/env python3
"""Read retained qualification receipts; never run Cargo, hardware or a solver."""
import ast
from contextlib import redirect_stdout
from datetime import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shlex
import sys
import tarfile

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
BASE = '090beb6f8eda93e68c43726e0be594ae20c014c2'
# Root-reviewed frozen-source selection; every selected receipt must still pass.
ATTEMPT = 'attempt-02'
PROPOSAL = 'proposal-03'
SOURCE_CONTROLS = 'attempt-03-after'
HARDWARE_CAPTURE = {'label': 'hardware-campaign-01', 'seconds': '2400s'}
EXPECTED = {
    'runtime_passed': 2160,
    'examples': {'directed': 11, 'deferred': 8, 'live-sharded': 5},
    'new_deferred_example_tests': [
        'data::tests::return_window_checks_all_three_full_extents_and_guard_boundaries',
        'tests::return_window_cli_combines_with_late_compute_without_changing_authority',
    ],
    'metadata': [9, 16, 7, 76, 1061, 377, 382],
    'new_runtime_tests': sorted([
        'context::tests::compute_peer_tests::windows::compute_peer_windows_cancellation_refunds_only_the_exact_consumer',
        'context::tests::compute_peer_tests::windows::compute_peer_windows_exact_active_read_bounds_preserve_full_writer_ownership',
        'context::tests::compute_peer_tests::windows::compute_peer_windows_nested_readback_observes_original_parent_before_any_commit',
        'context::tests::compute_peer_tests::windows::compute_peer_windows_preissue_errors_keep_disposition_specific_custody',
        'context::tests::compute_peer_tests::windows::compute_peer_windows_reject_bounds_access_and_event_errors_before_effects',
        'context::tests::compute_peer_tests::windows::compute_peer_windows_reject_partial_or_aliased_writer_even_when_it_covers_read',
        'context::tests::compute_peer_tests::windows::compute_peer_windows_retained_endpoint_drift_fails_before_observation',
        'kfd_backend::tests::compute_peer_tests::deferred::deferred_compute_peer_window_final_readback_preserves_full_unequal_owner_guards',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_cancel_and_producer_failure_refund_without_copying',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_final_readback_drives_queued_compute_after_event_release',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_full_writer_guard_rejects_partial_and_aliased_bindings',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_identity_drift_poison_pair_before_and_after_publication',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_native_errors_and_unwinds_keep_window_and_original_owners',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_queued_and_eager_preserve_unequal_owners_and_all_guard_bytes',
        'kfd_backend::tests::compute_peer_tests::window::compute_peer_window_rejects_invalid_bounds_and_destination_before_any_effect',
    ]),
}
PINS = {
    'cpu.py': '338058b42657e49f53851da317d60b9f3049c667347d599b45527f7c0d71aedf',
    'capture.py': '84b5f1e88a891c42562613d3fdf178ea41ef1228324f0d2d2f09c0b621f1eac1',
    'reuse-check.py': '0fe18482af9ef9d2a049ec231e5409d1bca2fb7965caea20a7a1a4d91e402d91',
    'hardware-01/campaign.py': 'db337f0877f1bc5cb7039c8b4f38c280966935352b6f4e57b1bc85bb0c6f96f9',
    'hardware-01/capture.py': 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f',
    'source-ci/support.py': '3955029c587a735d4f4f4a27a200c0e6242c02c25d91b6ba9418258b47e58c4e',
    'source-ci/propose-current.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    'source-ci/reference/inputs.json': '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e',
    'source-ci/proposal-03/metadata-report.json': '70ea7a406672af239e26436c7ff26d0d16ba45f6fd60d7b5415f00486c0802cd',
    'source-ci/proposal-03/metadata.patch': 'cad3e9f971a1801b7f879df1c0ae6a604bea2395e8e06cdead299d81f6180602',
}
PRIOR = ROOT / 'docs/evidence/dev-native-peer-subranges-2026-10-02/raw.tar.xz'
PRIOR_SHA = '27d84a8e8f168c92c8220f0bd641b8b2d5ca7669c12f564288ecee620c72c734'
PRIOR_PREFIX = 'raw/'


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def raw(path):
    need(path.is_file() and not path.is_symlink(), 'ordinary input: ' + str(path))
    return path.read_bytes()


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def read(path):
    return json.loads(raw(path), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def sources(manifest):
    need(manifest and all(not Path(name).is_absolute() and '..' not in Path(name).parts
                          for name in manifest), 'relative source roster')
    for name, digest in manifest.items():
        need(sha(raw(ROOT / name)) == digest, 'current source identity: ' + name)


def outputs(folder, record, names=('stdout', 'stderr')):
    for name in names:
        need(record[name + '_sha256'] == sha(raw(folder / name)), 'raw output identity: ' + str(folder / name))


def owned(folder, argv, env, controller):
    result = read(folder / 'result.json')
    command = read(folder / 'command.json')
    need(all(result[key] == value for key, value in command.items()), 'immutable owned invocation')
    need(result['command'] == argv and result['environment'] == env and result['cwd'] == str(ROOT)
         and result['controller_sha256'] == controller, 'exact owned command/environment/controller')
    need(result['accepted'] is True and result['exit'] == 0 and result['error'] is None
         and not result['timed_out'] and not result['interrupted']
         and not result['retained_session_members'] and result['group_absent'] is True
         and result['session_absent'] is True, 'complete owned success')
    need(datetime.fromisoformat(result['finished']) >= datetime.fromisoformat(result['started']), 'receipt times')
    outputs(folder, result)
    return result


def captured(step, expected, seconds, manifest, env, controller):
    folder = RAW / step['capture']
    receipt = read(folder / 'receipt.json')
    invocation = read(folder / 'command.json')
    need(all(receipt[key] == value for key, value in invocation.items()), 'capture invocation retained')
    need(sha(raw(folder / 'receipt.json')) == step['receipt_sha256'], 'capture receipt binding')
    need(receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', str(seconds) + 's', *expected]
         and receipt['exit'] == 0 and receipt['environment'] == env and receipt['cwd'] == str(ROOT)
         and receipt['base'] == BASE and receipt['controller_sha256'] == PINS['capture.py']
         and receipt['source_unchanged'] is True, 'exact successful source capture')
    need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == manifest,
         'capture source continuity')
    outputs(folder, receipt)
    outer = RAW / step['controller']
    invocation = read(outer / 'command.json')['command']
    need(invocation[1:] == ['-I', '-B', str(RAW / 'capture.py'), step['capture'], str(seconds) + 's', *expected]
         and Path(invocation[0]).name.startswith('python3'), 'exact capture wrapper')
    result = owned(outer, invocation, env, controller)
    need(result['timeout_seconds'] == seconds + 45, 'owned outer bound')
    return folder, receipt


def prior_outputs():
    need(sha(raw(PRIOR)) == PRIOR_SHA, 'authenticated prior archive')
    with tarfile.open(PRIOR, 'r:xz') as archive:
        names = archive.getnames()
        need(len(names) == len(set(names)), 'unique prior archive members')
        def member(name):
            item = archive.getmember(PRIOR_PREFIX + name)
            need(item.isfile(), 'ordinary prior result member')
            return archive.extractfile(item).read().decode()
        audit = json.loads(member('audit-02.json'))
        need(audit['accepted'] and audit['cpu']['runtime_passed'] == 2145
             and audit['cpu']['runtime_ignored'] == 32, 'accepted prior runtime roster')
        runtime = member('attempt-01/tests/runtime-full/run/stdout')
        ignored = sorted(re.findall(r'^test (.+?) \.\.\. ignored(?:, [^\n]*)?$', runtime, re.M))
        need(len(ignored) == len(set(ignored)) == 32, 'historical exact ignore roster')
        examples = {name: sorted(re.findall(r'^test (.+?) \.\.\. ok$',
                    member('attempt-01-checks-' + name + '-tests/stdout'), re.M))
                    for name in ['directed', 'deferred', 'live-sharded']}
        roster = json.loads(member('attempt-01/build/build.json'))['executables']['fe2o3_runtime']['list']
    return ignored, examples, roster


def audit_cpu():
    cpu = module(RAW / 'cpu.py', 'audited_cpu')
    capture = module(RAW / 'capture.py', 'audited_capture')
    modes = {mode: read(RAW / ATTEMPT / mode / 'result.json') for mode in ['build', 'runtime', 'checks']}
    manifest = read(RAW / ATTEMPT / 'build/source-before.json')
    sources(manifest)
    # Fresh inventory, not just a subset of files that happen to remain present.
    need(capture.snapshot() == manifest, 'complete current source inventory')
    for mode, result in modes.items():
        folder = RAW / ATTEMPT / mode
        script = 'cpu.py'
        need(result['accepted'] is True and result['error'] is None and result['source_unchanged'] is True
             and result['mode'] == mode and result['attempt'] == ATTEMPT and result['base'] == BASE
             and result['controller_sha256'] == PINS[script] and result['capture_sha256'] == PINS['capture.py']
             and result['argv'] == [str(RAW / script), mode, ATTEMPT]
             and result['environment'] == capture.ENV and result['cwd'] == str(ROOT), 'selected successful CPU mode')
        need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == manifest, 'mode source identity')
        command = read(folder / 'command.json')
        need(all(result[key] == value for key, value in command.items()), 'mode invocation retained')
    build = read(RAW / ATTEMPT / 'build/build.json')
    need(build['executables'] == modes['build']['results']['executables']
         and build['steps'] == modes['build']['results']['steps'] and len(build['steps']) == 5, 'complete build stages')
    build_folder, build_receipt = captured(build['steps'][0], cpu.cargo('test', *cpu.PACKAGES, '--all-features', '--lib', '--no-run',
                                          '--message-format=json'), 2400, manifest, capture.ENV, PINS['cpu.py'])
    messages = [json.loads(line) for line in raw(build_folder / 'stdout').decode().splitlines()]
    need([row for row in messages if row.get('reason') == 'build-finished']
         == [{'reason': 'build-finished', 'success': True}], 'actual Cargo build success')
    built = build['executables']
    old_ignored, old_examples, old_runtime = prior_outputs()
    for index, (target, total) in enumerate([('fe2o3_kfd', 1934), ('fe2o3_runtime', EXPECTED['runtime_passed'] + 32)]):
        identity = built[target]
        paths = {row['executable'] for row in messages if row.get('reason') == 'compiler-artifact'
                 and row.get('executable') and row['target']['name'] == target and row['profile']['test'] is True}
        need(paths == {identity['path']} and build_receipt['executables'][identity['path']]
             == {key: identity[key] for key in ['sha256', 'byte_length']} | {'target': target, 'test': True},
             'exact library artifact captured at build')
        need(cpu.executable(identity['path']) == {k: identity[k] for k in ['path', 'sha256', 'byte_length']}, 'final library ELF')
        need(len(identity['list']) == len(set(identity['list'])) == total
             and identity['list'] == sorted(identity['list']), 'reviewed complete suite count')
        need(identity['ignored'] == ([] if target == 'fe2o3_kfd' else old_ignored), 'no newly ignored tests')
        for offset, ignored in enumerate([False, True]):
            argv = [identity['path'], '--list', '--test-threads=1', *(['--ignored'] if ignored else [])]
            folder, _ = captured(build['steps'][1 + 2 * index + offset], argv, 60, manifest, capture.ENV, PINS['cpu.py'])
            need(cpu.roster(raw(folder / 'stdout').decode()) == identity['ignored' if ignored else 'list'], 'retained full discovery')
    kfd, runtime = built['fe2o3_kfd'], built['fe2o3_runtime']
    new_runtime = sorted(set(runtime['list']) - set(old_runtime))
    need(set(old_runtime).issubset(runtime['list'])
         and new_runtime == EXPECTED['new_runtime_tests'], 'exact added runtime tests and no removed baseline tests')
    folder = RAW / ATTEMPT / 'runtime/runtime-full'
    selection = read(folder / 'selection.json')
    need(selection == dict(selected=runtime['list'], ignored=old_ignored, full_roster=runtime['list'],
                           executable={k: runtime[k] for k in ['path', 'sha256', 'byte_length']}),
         'complete unfiltered runtime selection')
    argv = [runtime['path'], '--test-threads=1']
    listed = owned(folder / 'list', [*argv, '--list'], capture.ENV, PINS['cpu.py'])
    need(listed['timeout_seconds'] == 60 and cpu.roster(raw(folder / 'list/stdout').decode()) == runtime['list'],
         'exact runtime discovery')
    run = owned(folder / 'run', argv, capture.ENV, PINS['cpu.py'])
    need(run['timeout_seconds'] == 1200, 'full runtime bound')
    counts = cpu.test_results(raw(folder / 'run/stdout').decode(), runtime['list'], old_ignored, len(runtime['list']))
    result = read(folder / 'result.json')
    need(result['accepted'] is True and result['error'] is None and result['source_unchanged'] is True
         and result['executable_unchanged'] is True and result['counts'] == counts and result['run'] == run
         and result['selection_sha256'] == sha(raw(folder / 'selection.json')), 'exact runtime receipt')
    need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == manifest, 'runtime source binding')
    aggregate = modes['runtime']['results']
    need(aggregate['runtime'] == result and aggregate['build_attempt'] == ATTEMPT
         and aggregate['runtime_passed'] == EXPECTED['runtime_passed']
         and aggregate['runtime_ignored'] == 32 and aggregate['kfd_tests_executed'] == 0
         and aggregate['kfd_historical_passes_reused'] == 1934, 'honest current and historical execution totals')
    reuse_step = aggregate['reuse']
    need(reuse_step['capture'] == ATTEMPT + '-runtime-kfd-proof-reuse', 'exact reuse stage')
    invocation = read(RAW / reuse_step['capture'] / 'receipt.json')['command'][4:]
    need(len(invocation) == 4 and Path(invocation[0]).name.startswith('python3')
         and invocation[1:] == ['-I', '-B', str(RAW / 'reuse-check.py')], 'read-only reuse checker invocation')
    reuse_folder, _ = captured(reuse_step, invocation, 120, manifest, capture.ENV, PINS['cpu.py'])
    retained_reuse = read(reuse_folder / 'stdout')
    fresh_stdout = io.StringIO()
    with redirect_stdout(fresh_stdout):
        module(RAW / 'reuse-check.py', 'pinned_reuse_checker').main()
    fresh_reuse = json.loads(fresh_stdout.getvalue(), object_pairs_hook=pairs)
    need(retained_reuse == fresh_reuse and fresh_reuse['historical_reuse_valid'] is True
         and fresh_reuse['controller_sha256'] == PINS['reuse-check.py']
         and fresh_reuse['kfd_executable'] == {k: kfd[k] for k in ['path', 'sha256', 'byte_length']},
         'current identity and exact authenticated historical reuse')
    checks = modes['checks']['results']
    need(len(checks['steps']) == 18, 'complete checks stage count')
    expected = {}
    def stage(name, seconds, argv):
        expected[name] = (seconds, argv)
    examples = [item for name in cpu.EXAMPLES.values() for item in ['--example', name]]
    stage('clippy', 1800, cpu.cargo('clippy', *cpu.PACKAGES, '--all-features', '--lib', '--tests', *examples, '--no-deps', '--', '-D', 'warnings'))
    stage('directed-clippy', 1200, cpu.cargo('clippy', '-p', 'fe2o3-runtime', '--no-default-features', '--example', cpu.EXAMPLES['directed'], '--no-deps', '--', '-D', 'warnings'))
    stage('no-default', 600, cpu.cargo('check', *cpu.PACKAGES, '--no-default-features', '--lib', '--example', cpu.EXAMPLES['directed']))
    stage('hardware-feature', 600, cpu.cargo('check', '-p', 'fe2o3-runtime', '--no-default-features', '--features', 'hardware-qualification', '--lib', '--example', cpu.EXAMPLES['deferred'], '--example', cpu.EXAMPLES['live-sharded']))
    for kind, name in cpu.EXAMPLES.items():
        args = ['-p', 'fe2o3-runtime', '--no-default-features' if kind == 'directed' else '--all-features', '--example', name]
        stage(kind + '-list', 1200, cpu.cargo('test', *args, '--', '--list', '--test-threads=1'))
        stage(kind + '-tests', 1200, cpu.cargo('test', *args, '--', '--test-threads=1'))
        stage(kind + '-build', 1200, cpu.cargo('build', *args, '--profile', 'test', '--message-format=json'))
    stage('rustc', 60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose'])
    stage('cargo', 60, ['cargo', '+nightly-2026-04-03', '--version'])
    stage('uname', 60, ['uname', '-a'])
    stage('format', 120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *cpu.changed_rust()])
    stage('whitespace', 60, ['git', 'diff', 'HEAD', '--check'])
    records = {}
    for step, (name, (seconds, argv)) in zip(checks['steps'], expected.items()):
        need(step['capture'] == ATTEMPT + '-checks-' + name, 'exact ordered check stages')
        records[name] = captured(step, argv, seconds, manifest, capture.ENV, PINS['cpu.py'])
    for kind, count in EXPECTED['examples'].items():
        listed = cpu.roster(raw(records[kind + '-list'][0] / 'stdout').decode())
        expected_roster = sorted(old_examples[kind] + (
            EXPECTED['new_deferred_example_tests'] if kind == 'deferred' else []))
        need(len(listed) == count and listed == expected_roster, 'reviewed exact example roster')
        result = cpu.test_results(raw(records[kind + '-tests'][0] / 'stdout').decode(), listed, [], count)
        witness = checks['witnesses'][kind]
        need(witness['tests'] == result and cpu.executable(witness['executable']['path']) == witness['executable'], 'final example identity/results')
        identity = witness['executable']
        receipt = records[kind + '-build'][1]
        need(receipt['executables'][identity['path']] == {k: identity[k] for k in ['sha256', 'byte_length']} | {'target': cpu.EXAMPLES[kind], 'test': False}, 'witness from exact build')
    return dict(kfd_historical_passes_reused=1934, kfd_tests_executed=0,
                runtime_passed=EXPECTED['runtime_passed'], runtime_ignored=32,
                examples_passed=sum(EXPECTED['examples'].values()), reuse=fresh_reuse,
                new_runtime_tests=new_runtime, runtime_counts=counts,
                library_executables={name: {k: row[k] for k in ['path', 'sha256', 'byte_length']} for name, row in built.items()},
                witnesses=checks['witnesses'], source_manifest_sha256=sha(raw(RAW / ATTEMPT / 'build/source-before.json')))


def audit_source_controls():
    folder = RAW / 'source-ci' / SOURCE_CONTROLS
    result, inputs = read(folder / 'result.json'), read(folder / 'inputs.json')
    need(result['accepted'] is True and result['source_unchanged'] is True and not result['failed']
         and result['command_count'] == len(result['commands']) == 32 and inputs['head'] == BASE, 'exact32 success')
    sources(inputs['source_sha256'])
    need(read(folder / 'closing-source.json') == inputs['source_sha256'], 'source controls closing identity')
    prior = read(RAW / 'source-ci/reference/inputs.json')
    need(len(inputs['commands']) == len(prior['commands']) == 32
         and inputs['commands'] == prior['commands'] and sha(raw(ROOT / '.github/workflows/runtime-component-source-guards.yml'))
         == inputs['workflow_sha256'] == prior['workflow_sha256'], 'unchanged exact workflow commands')
    for index, (entry, (step, literal, argv)) in enumerate(zip(result['commands'], inputs['commands']), 1):
        stage = folder / f'{index:02}'
        need(read(stage / 'receipt.json') == entry and entry['step'] == step and entry['literal'] == literal
             and entry['argv'] == argv and entry['exit'] == 0 and entry['group_absent'] is True
             and not entry['timed_out'], 'actual source-control receipt')
        outputs(stage, entry)
    proposal = RAW / 'source-ci' / PROPOSAL
    report = read(proposal / 'metadata-report.json')
    need(report['baseline'] == BASE and report['predicates_contracts_and_proof_counts_unchanged'] is True
         and report['proof_closures_unchanged'] is True, 'reviewed metadata scope')
    sources(report['audited_source_sha256'])
    sources(report['proof_files'])
    changed, hashes, counts = 0, 0, 0
    for row in report['changes']:
        source = raw(proposal / 'originals' / Path(row['path']).name)
        need(sha(source) == row['original_sha256'], 'metadata preimage')
        tree = ast.parse(source)
        nodes = {(node.lineno, node.col_offset): node for node in ast.walk(tree) if isinstance(node, ast.Constant)}
        for edit in row['edits']:
            node = nodes[edit['line'], edit['column']]
            need(node.value == edit['old'], 'exact metadata old literal')
            if edit['category'] == 'content-sha256':
                need(all(re.fullmatch(r'[0-9a-f]{64}', value) for value in [edit['old'], edit['new']]), 'SHA-only metadata')
                hashes += 1
            else:
                need(edit['category'] == 'source-inventory-count' and type(edit['old']) is type(edit['new']) is int, 'inventory-only metadata')
                counts += 1
            node.value = edit['new']
        actual = raw(ROOT / row['path'])
        need(sha(actual) == row['proposed_sha256'] and ast.dump(tree, include_attributes=False)
             == ast.dump(ast.parse(actual), include_attributes=False), 'exact applied AST metadata only')
        changed += bool(row['edits'])
    need((changed, hashes, counts, len(report['proof_files']), len(report['audited_source_sha256']),
          report['runtime_source_files'], report['runtime_and_schema_files']) == tuple(EXPECTED['metadata']), 'fixed metadata inventory')
    return dict(commands=32, changed_files=changed, hash_literals=hashes, inventory_literals=counts,
                unchanged_proof_files=76, result_sha256=sha(raw(folder / 'result.json')))


def audit_hardware(cpu):
    folder = RAW / 'hardware-01'
    hw = module(folder / 'campaign.py', 'reviewed_hardware_campaign')
    outer = RAW / HARDWARE_CAPTURE['label']
    outer_record = read(outer / 'receipt.json')
    outer_command = read(outer / 'command.json')
    need(all(outer_record[key] == value for key, value in outer_command.items()), 'hardware outer invocation retained')
    need(outer_record['command'] == [
        'timeout', '--signal=TERM', '--kill-after=30s', HARDWARE_CAPTURE['seconds'],
        'python3', '-I', '-B', str(folder / 'campaign.py'), ATTEMPT,
    ] and outer_record['exit'] == 0 and outer_record['source_unchanged'] is True
         and outer_record['controller_sha256'] == PINS['capture.py']
         and outer_record['base'] == BASE and outer_record['cwd'] == str(ROOT),
         'exact source-bound successful hardware controller capture')
    capture = module(RAW / 'capture.py', 'hardware_outer_capture')
    need(outer_record['environment'] == capture.ENV, 'clean hardware controller environment')
    manifest = read(RAW / ATTEMPT / 'build/source-before.json')
    need(read(outer / 'source-before.json') == read(outer / 'source-after.json') == manifest,
         'hardware execution bound to selected source')
    outputs(outer, outer_record)
    outer_started = datetime.fromisoformat(outer_record['started'])
    outer_finished = datetime.fromisoformat(outer_record['finished'])
    need(outer_started <= outer_finished, 'ordered source-bound hardware capture')
    result = read(folder / 'campaign.json')
    need(result['accepted'] is True and result['errors'] == [] and result['expected_cases'] == 12
         and result['owned_cleanup_complete'] is True and result['selected_build_attempt'] == ATTEMPT
         and not result['formal_refinement'] and not result['performance_acceptance'], 'complete hardware campaign')
    need(len(hw.CASES) == 12 and [row['name'] for row in result['completed']] == [row[0] for row in hw.CASES], 'exact reviewed hardware roster')
    need(set(result['binaries']) == {'directed', 'deferred', 'live-sharded'}, 'exact three hardware witnesses')
    def receipt(name, argv):
        stage = folder / name
        row = read(stage / 'result.json')
        need(row['argv'] == argv and row['exit_code'] == 0 and not row['timed_out']
             and row['local_process_group_absent'] is True, 'actual hardware transport receipt: ' + name)
        need(datetime.fromisoformat(row['finished']) >= datetime.fromisoformat(row['started'])
             and 0 <= row['elapsed_seconds'] <= 245, 'bounded hardware receipt times: ' + name)
        if name == 'initial-availability':
            need(datetime.fromisoformat(row['finished']) <= outer_started,
                 'initial admission retained before campaign start')
        else:
            need(outer_started <= datetime.fromisoformat(row['started'])
                 <= datetime.fromisoformat(row['finished']) <= outer_finished,
                 'hardware child belongs to source-bound campaign interval: ' + name)
        outputs(stage, row)
        return raw(stage / 'stdout').decode()
    def chronology(names):
        for first, second in zip(names, names[1:]):
            finished = datetime.fromisoformat(read(folder / first / 'result.json')['finished'])
            started = datetime.fromisoformat(read(folder / second / 'result.json')['started'])
            need(0 <= (started - finished).total_seconds() <= 300,
                 'fresh ordered hardware observations: ' + first + ' -> ' + second)
    def admission_names(name):
        return [name + '-' + suffix for suffix in ['availability', 'attachments', 'host-memory']]
    def remote(name, argv, bound='30s'):
        return receipt(name, hw.SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])])
    baseline = json.loads(remote('initial-availability', hw.AVAILABILITY))
    def admission(name):
        state = json.loads(remote(name + '-availability', hw.AVAILABILITY))
        for card, uid, bdf in zip(hw.CARDS, hw.IDS, hw.BD):
            need(state[card]['Unique ID'] == baseline[card]['Unique ID'] == uid
                 and state[card]['PCI Bus'] == baseline[card]['PCI Bus'] == bdf
                 and state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0', 'exact idle admitted GPU')
            for field in ['VRAM Total Memory (B)', 'VRAM Total Used Memory (B)']:
                need(state[card][field] == baseline[card][field], 'unchanged memory baseline')
        need(state['system'] == baseline['system'], 'same PID census')
        mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        records = {}
        for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = match.groups()
            devices = [] if devices is None else devices.split()
            need(int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
                 and pid not in records and not {card.removeprefix('card') for card in hw.CARDS}.intersection(devices), 'attachment exclusion')
            records[pid] = devices
        need({'PID' + pid for pid in records} == set(state['system']), 'complete mapped PID roster')
        for pid, devices in records.items():
            need(int(state['system']['PID' + pid].split(',')[1]) == len(devices), 'attachment count agreement')
        memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        need(len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024, 'host memory floor')
        chronology(admission_names(name))
    admission('baseline')
    first = read(folder / 'initial-availability/result.json')
    baseline_start = read(folder / 'baseline-availability/result.json')['started']
    age = (datetime.fromisoformat(baseline_start) - datetime.fromisoformat(first['finished'])).total_seconds()
    need(0 <= age <= 300, 'fresh initial hardware admission')
    directory = result['owned_directory']
    need(re.fullmatch(r'/tmp/fe2o3-pending-compute-windows-20261002-[A-Za-z0-9]{6}', directory), 'exact owned remote directory')
    need(remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-pending-compute-windows-20261002-XXXXXX']).strip() == directory, 'actual allocated owned directory')
    for kind, binary in result['binaries'].items():
        expected = cpu['witnesses'][kind]['executable']
        need(binary == dict(local=expected['path'], sha256=expected['sha256'], remote=directory + '/' + kind + '-witness'), 'exact uploaded CPU-built witness')
        receipt('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
        for prefix in ['initial', 'final']:
            need(remote(prefix + '-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']], 'remote binary identity')
    for actual, (name, kind, flags, ids) in zip(result['completed'], hw.CASES):
        admission(name)
        argv = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', result['binaries'][kind]['remote'], *flags, *ids]
        fields = hw.pass_fields(remote(name, argv, '180s'))
        need(not raw(folder / name / 'stderr') and fields == actual['fields'] == hw.expected(kind, flags, ids), 'exact reviewed PASS schema/oracle: ' + name)
        admission(name + '-post')
        chronology([*admission_names(name), name, *admission_names(name + '-post')])
    for first, second in zip(hw.CASES, hw.CASES[1:]):
        chronology([first[0] + '-post-host-memory', second[0] + '-availability'])
    chronology([*admission_names('baseline'), 'create-scratch',
                *[name for kind in ['directed', 'deferred', 'live-sharded']
                  for name in ['upload-' + kind, 'initial-hash-' + kind]],
                hw.CASES[0][0] + '-availability'])
    paths = [result['binaries'][kind]['remote'] for kind in ['directed', 'deferred', 'live-sharded']]
    tree = ast.parse(raw(folder / 'campaign.py'))
    probes = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == 'probe' for target in node.targets)]
    need(len(probes) == 1, 'one reviewed exact owned process probe')
    probe = ast.literal_eval(probes[0])
    need(json.loads(remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths]))
         == {'owned_executable_pids': []}, 'no owned remote processes')
    remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    admission('final')
    chronology([hw.CASES[-1][0] + '-post-host-memory', 'final-owned-processes',
                *['final-hash-' + kind for kind in ['directed', 'deferred', 'live-sharded']],
                'remove-owned-executables', 'remove-owned-directory', 'confirm-owned-directory-absent',
                *admission_names('final')])
    return dict(cases=12, pending_compute_window_cases=4, controls=8, owned_cleanup=True,
                oracle='reuses pinned reviewed campaign pure expected(); independently implemented from Rust witness',
                performance_acceptance=False, formal_refinement=False)


def main():
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'python3 -I -B required')
    need(len(sys.argv) == 2 and re.fullmatch(r'audit-[0-9]+\.json', sys.argv[1]), 'fresh audit output name')
    output = RAW / sys.argv[1]
    need(not output.exists(), 'never overwrite an audit')
    result = {'accepted': False, 'error': None, 'baseline': BASE, 'build_attempt': ATTEMPT,
              'controller_sha256': sha(raw(Path(__file__))), 'pins': PINS,
              'executed_builds': 0, 'executed_hardware_commands': 0, 'executed_solvers': 0}
    try:
        need(ATTEMPT is not None and PROPOSAL is not None and SOURCE_CONTROLS is not None
             and HARDWARE_CAPTURE is not None
             and EXPECTED is not None and all(digest is not None for digest in PINS.values()),
             'root-reviewed final selection and controller pins are required')
        need('source-ci/' + PROPOSAL + '/metadata-report.json' in PINS
             and 'source-ci/' + PROPOSAL + '/metadata.patch' in PINS, 'selected proposal bytes pinned')
        for name, digest in PINS.items():
            need(sha(raw(RAW / name)) == digest, 'pinned reviewed input: ' + name)
        result['cpu'] = audit_cpu()
        result['source_controls'] = audit_source_controls()
        result['proof'] = dict(result['cpu']['reuse']['arithmetic'], historical_reuse=True,
                               archive_sha256=PRIOR_SHA, new_solver_executions=0)
        result['hardware'] = audit_hardware(result['cpu'])
        result['accepted'] = True
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    with output.open('x') as target:
        json.dump(result, target, indent=2, sort_keys=True)
        target.write('\n')
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
