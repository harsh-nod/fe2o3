#!/usr/bin/env bash
set -euo pipefail

cd "${1:?repository checkout required}"
logs="${2:?absolute output directory required}"
mkdir -p "$logs"
export CARGO_BUILD_JOBS=4 CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true
export CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1 FE2O3_HIP_SYS_DISABLE=1

cargo test -p fe2o3-kfd -p fe2o3-runtime -p fe2o3-amdhsa-loader \
  --lib --no-fail-fast -- --test-threads=4 > "$logs/library-tests-qualified.log" 2>&1
cargo test -p fe2o3-kernel-analysis --no-default-features \
  --features gfx942-fill-model --lib > "$logs/fill-model-feature-tests.log" 2>&1
cargo test -p fe2o3-runtime --lib -- --test-threads=4 \
  > "$logs/runtime-tests-qualified.log" 2>&1
cargo clippy -p fe2o3-kfd --tests --no-deps -- -D warnings \
  > "$logs/kfd-clippy.log" 2>&1
cargo clippy -p fe2o3-runtime -p fe2o3-amdhsa-loader --lib --no-deps -- -D warnings \
  > "$logs/runtime-loader-clippy.log" 2>&1
cargo tree -p fe2o3-kfd -e normal --no-default-features --depth 2 \
  > "$logs/kfd-normal-dependencies.log" 2>&1
rustfmt --edition 2024 --config skip_children=true --check \
  crates/fe2o3-amdhsa-loader/src/lib.rs \
  crates/fe2o3-kernel-analysis/src/lib.rs \
  crates/fe2o3-kfd/src/queue_dispatch_binding.rs \
  crates/fe2o3-kfd/src/queue_dispatch_binding/conditional_fill.rs \
  crates/fe2o3-kfd/src/queue_dispatch_binding/conditional_fill_tests.rs \
  crates/fe2o3-kfd/src/queue_dispatch_binding/preparation.rs \
  crates/fe2o3-kfd/src/queue_dispatch_binding/preparation_tests.rs \
  crates/fe2o3-kfd/src/queue_dispatch_binding/pristine_abort.rs \
  crates/fe2o3-kfd/src/shared_memory.rs \
  crates/fe2o3-runtime/src/persistent_projection.rs \
  crates/fe2o3-runtime/src/persistent_projection/tests.rs \
  > "$logs/format.log" 2>&1
git diff --check > "$logs/whitespace.log" 2>&1
