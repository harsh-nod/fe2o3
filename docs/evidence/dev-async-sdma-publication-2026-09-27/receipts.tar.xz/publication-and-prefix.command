env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib sdma_publication_custody_tests -- --nocapture 
