# Read-only review and integration notes

Two native collaboration reviewers inspected the runtime publication/settlement
changes and scripted tests. Neither built, edited, invoked Qwen, or requested
permissions. Primary owns implementation, test runs and integration.

Resolved findings:

- Keep the descriptor indexed across normalization, native storage extraction,
  submission, restoration and failure classification. Terminal after a completed
  prefix must not be downgraded to quiescence or refunded.
- A clean later-window planning failure must mark the partial result quiescent.
- Root returned ProcessTeardown custody before formatting diagnostics. Scripted
  submit-panic hooks root the exact pair before raising the original panic.
- Shared release preflight must reject missing endpoints and unsupported retained
  kind pairs. Post-admission kind lookup failure is Terminal, not InvalidLaunch.
- Do not reject all foreign storage ownership indiscriminately: an unstarted
  Ready copy can fail its first explicit dependency while its FIFO predecessor
  remains active. A new public D0 -> D dependency chain tests that case without
  fabricated completion state. Quarantined settlement rejects in-flight storage.
- Test exact original owner IDs and storage markers, not just owner counts;
  inspect actual scripted destination bytes with nonzero data and sentinels;
  check exact window coordinates and the teardown diagnostic so request mismatch
  cannot accidentally satisfy the expected terminal test result.
- Preserve the publication-history source guard over the original parent module
  as well as the extracted publication/observation modules.

Final production review reported no further concrete blocker. These checks are
local release prerequisites under existing private sorted-index/count invariants,
not a global owner-arena proof or arbitrary corruption verifier. Lower-layer
opaque native panic custody remains a separate contract. Clean scripted fixture
helpers bypass production device scrub-on-release by clearing sdma_backed before
release; the tests establish explicit scripted retirement/recycling only.

The expanded test fixture initially used HashMap-style insert return handling on
the repository's indexed allocation table; that compile failure is retained.
The stronger kind check then exposed an old private fixture inserting unsupported
HostVisible -> HostVisible SDMA. It now uses a supported H2D kind pair with
unavailable Synthetic backing, preserving its clean preparation-failure purpose.
The separate missing-record/kind-corruption cases inspect terminal custody and
drop the unrepaired backend with core dumps disabled.

Next inspected gap: cancel_v1 still removes an unpublished SDMA descriptor before
releasing dependencies/allocation/stream retains and uses separate unvalidated
settlement logic. This is not changed or declared closed by this checkpoint.

Read-only cancellation follow-up recommends an indexed Cancelled settlement
preserving Failed code -2 and existing stream-tail restoration. Keep interior
SDMA cancellation legal with retained successors, and published/partial copies
TooLate. A proposed negative regression genuinely admits A -> B -> C, removes
only B's destination allocation-custody entry, then cancels B: the current path
would partially release after removing B, whereas checked settlement should seal
before any further mutation. This scenario has been inspected, not executed or
implemented in the signed publication checkpoint.
