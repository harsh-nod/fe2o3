#!/usr/bin/env bash
set -u
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
status=0
run() {
    bash "$root/run.sh" "$@" || status=1
}
run final-identity git show -s --format=fuller HEAD
run final-tree git rev-parse HEAD HEAD^{tree}
run final-signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run final-fmt cargo fmt --all -- --check
run final-no-default env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo check -p fe2o3-runtime -p fe2o3-runtime-model --no-default-features
run final-clippy env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo clippy -p fe2o3-runtime -p fe2o3-runtime-model --all-features --all-targets -- -D warnings
run final-test env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime -p fe2o3-runtime-model --all-features --no-fail-fast
run final-continuity git diff --exit-code HEAD -- crates
exit "$status"
