#!/usr/bin/env bash
set -euo pipefail
out=/home/harsh/.codex-tmp/fe2o3-application-activation-20261004-BRBd6PjB
destination=/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-application-startup-activation-2026-10-04
cd "$out"
files=(
    qualify.sh audit.sh package-evidence.sh allowed-signers source-audit.log
    source.patch committed-source.patch source-before.sha256 source-after.sha256
    qualified-tests.jsonl qualified-build.log host-feature-tests.jsonl host-feature-build.log
    static-tests.jsonl static-build.log clippy-selected.log clippy-fixtures.log docs.log fmt.log
    root_application_session_campaign.log root_application_registry_transitions.log
    root_application_registry_transport.log root_application_observation_campaign.log
    root_registration_transport_campaign.log qualification-driver.log
    test-binaries.sha256 static-binaries.sha256
)
sha256sum "${files[@]}" > MANIFEST.sha256
sha256sum --quiet --check MANIFEST.sha256
mkdir -p "$destination"
tar -czf "$destination/evidence.tar.gz" MANIFEST.sha256 "${files[@]}"
sha256sum source.patch "$destination/evidence.tar.gz"
