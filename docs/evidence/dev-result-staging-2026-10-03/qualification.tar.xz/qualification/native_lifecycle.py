"""Record upload, bounded selected-pair execution, retrieval and owned cleanup."""
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'mi300x']
SCP = ['scp', '-q', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10']

def run(label, seconds, command):
    subprocess.run(['python3', '-I', '-B', str(HERE / 'capture.py'), label, f'{seconds}s', *command], check=True)
    return (HERE / label / 'stdout').read_text().strip()

artifact = json.loads((HERE / 'host-artifact/receipt.json').read_text())
assert artifact['exit'] == 0 and artifact['source_unchanged']
binary, identity = next(iter(artifact['executables'].items()))
assert identity['target'] == 'fe2o3_host' and identity['test']
remote = run('native-create', 40, SSH + ['mktemp', '-d', '/tmp/fe2o3-result-staging-20261003.XXXXXXXX'])
assert re.fullmatch(r'/tmp/fe2o3-result-staging-20261003\.[a-zA-Z0-9]+', remote)
files = ['native.py', 'cleanup.py', 'selected_pair_smoke.py', 'copy-host-observe.py']
run('native-tools-upload', 90, SCP + [str(HERE / name) for name in files] + ['mi300x:' + remote + '/'])
try:
    native = remote + '/fe2o3-host-result-staging-tests'
    run('native-binary-upload', 90, SCP + [binary, 'mi300x:' + native])
    run('native-hashes', 40, SSH + ['sha256sum', native, *[remote + '/' + name for name in files]])
    run('native-campaign', 480, SSH + ['python3', '-I', '-B', remote + '/native.py', native,
        identity['sha256'], '6,0000:c6:00.0,0x10a254ce4987e716', '7,0000:e5:00.0,0x53691ef168a0147d'])
finally:
    try:
        run('native-retrieve', 90, SCP + ['-r', 'mi300x:' + remote + '/native-results', str(HERE) + '/'])
    finally:
        run('native-cleanup', 60, SSH + ['python3', '-I', '-B', remote + '/cleanup.py'])
