"""Remove this exact owned campaign directory only after process closure."""
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
assert ROOT.parent == Path('/tmp') and ROOT.name.startswith('fe2o3-result-staging-20261003.')
assert ROOT.is_dir() and not ROOT.is_symlink()
assert ROOT.stat().st_uid == os.getuid()
assert Path(__file__).resolve().parent == ROOT
owned = []
for process in Path('/proc').iterdir():
    if not process.name.isdecimal() or int(process.name) == os.getpid():
        continue
    try:
        argv = (process / 'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError, ProcessLookupError):
        continue
    if any(arg.startswith(os.fsencode(ROOT) + b'/') for arg in argv):
        owned.append(int(process.name))
assert not owned, owned
shutil.rmtree(ROOT)
assert not ROOT.exists()
print(json.dumps(dict(owned_processes=owned, removed=str(ROOT), absent=True), sort_keys=True))
