"""Execute exact CPU-only workflow commands without a shell or a solver."""
import json
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent


def main():
    label = sys.argv[1]
    assert label.startswith('controls-') and '/' not in label
    workflow = yaml.safe_load((ROOT / '.github/workflows/runtime-component-source-guards.yml').read_text())
    commands = []
    for step in workflow['jobs']['source-controls']['steps']:
        for line in step.get('run', '').strip().splitlines():
            command = shlex.split(line)
            assert command[:3] == ['python3', '-I', '-B']
            commands.append(command)
    assert len(commands) == 33
    results = []
    for index, command in enumerate(commands):
        name = f'{label}-{index:02}'
        result = subprocess.run(['python3', '-I', '-B', str(OUT / 'capture.py'), name, '180s', *command], check=False)
        results.append(dict(command=command, label=name, exit=result.returncode))
    with (OUT / f'{label}.json').open('x') as output:
        json.dump(results, output, indent=2)
        output.write('\n')
    return int(any(row['exit'] for row in results))


if __name__ == '__main__':
    sys.exit(main())

