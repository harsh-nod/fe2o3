"""Serial final-source host/runtime qualification, hardware explicitly excluded."""
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
CARGO = ['cargo', '+nightly-2026-04-03']
STAGES = []
for package in ('fe2o3-host', 'fe2o3-runtime'):
    name = package.removeprefix('fe2o3-')
    args = ['-p', package, '--all-features']
    for label, command in (
        ('artifact', ['test', *args, '--lib', '--no-run', '--message-format=json']),
        ('roster', ['test', *args, '--lib', '--', '--list']),
        ('tests', ['test', *args, '--lib']),
        ('docs', ['test', *args, '--doc']),
        ('clippy', ['clippy', *args, '--lib', '--', '-D', 'warnings']),
        ('check-no-default', ['check', '-p', package, '--no-default-features', '--lib']),
    ):
        STAGES.append((name + '-' + label, 1800, CARGO + command))
STAGES += [
    ('runtime-examples', 900, CARGO + ['test', '-p', 'fe2o3-runtime', '--all-features', '--examples']),
    ('format', 60, CARGO + ['fmt', '-p', 'fe2o3-host', '-p', 'fe2o3-runtime', '--', '--check']),
    ('whitespace', 60, ['git', 'diff', '--check']),
]
for name, seconds, argv in STAGES:
    result = subprocess.run(['python3', '-I', '-B', str(HERE / 'capture.py'), name, f'{seconds}s', *argv])
    if result.returncode:
        sys.exit(result.returncode)
