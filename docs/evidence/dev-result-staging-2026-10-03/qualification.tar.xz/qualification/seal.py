"""Archive the reviewed campaign, excluding binaries and unrelated artifacts."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = ROOT / 'docs/evidence/dev-result-staging-2026-10-03'
patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--', 'crates'], cwd=ROOT)
(HERE / 'candidate-source.patch').write_bytes(patch)
files = sorted(path for path in HERE.rglob('*') if path.is_file() and path.name != 'MANIFEST.json')
assert all(not path.is_symlink() for path in files)
manifest = {str(path.relative_to(HERE)): {
    'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()
} for path in files}
(HERE / 'MANIFEST.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
archive = OUT / 'qualification.tar.xz'
with tarfile.open(archive, 'w:xz') as tar:
    for path in files + [HERE / 'MANIFEST.json']:
        tar.add(path, arcname='qualification/' + str(path.relative_to(HERE)), recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    for name, identity in manifest.items():
        data = tar.extractfile('qualification/' + name).read()
        assert len(data) == identity['bytes'] and hashlib.sha256(data).hexdigest() == identity['sha256']
checksums = ''.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name + '\n'
                    for path in [OUT / 'README.md', archive])
(OUT / 'SHA256SUMS').write_text(checksums)
print(json.dumps(dict(files=len(manifest), bytes=archive.stat().st_size,
                     sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
