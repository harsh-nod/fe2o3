# Next Increment: Pending Compute Producer to Native Peer

Read-only design against the shared source at the 76dbbb03d-based sharded-compute
candidate, 2026-10-02. No repository edits, builds, hardware calls, or validation
claims are part of this note. References below are repository-relative; line
numbers describe the inspected working source and may move during integration.

## Recommended First Contract

Keep the public workflow `launch_producer_aware_v1` -> exact event -> `peer_copy`
-> exact peer event -> `copy_async` D2H -> group capture. Add no orchestration API
and no launch authority. The first compute launch may have an empty dependency
list, so this closes the current sharded witness's host-join gap without also
implementing arbitrary pending DeferredCompute chains.

Initially require a version journal, one exact source-writing producer admitted
through `launch_producer_aware_v1`, an ordinary native child compute route, and a
complete equal-sized DeviceLocal Read -> DeviceLocal Write transfer on a verified
PUBLIC/XGMI pair. Require the producer's retained writable binding coverage to
cover the complete copied source. Keep pending queued writers, pending
DeferredCompute routes, graph/profile launches, ambiguous aliases, and partial
native ranges outside this first profile. Already-supported ready copies retain
their existing behavior; unsupported pending inputs must not quietly become
ordinary initialized reads or bypass another backend's contract.

Use an additive default-false backend support hook for this authenticated pending
profile, analogous to `supports_pending_peer_readback_v1`. Only the multi-KFD
backend opts in. This is needed because the existing common `peer_copy_v1` SPI
accepts event handles but does not promise this new success/custody contract for
every backend. Keep the existing operation method and Worker wire behavior.

## What Already Exists and What Blocks It

- `context.rs:3307` prepares an ordinary scalar root and submits through the
  common operation/journal path. `peer_custody.rs:54,99` already captures exact
  Context event/submission/stream/device identities and retains producers
  independently of live public events.
- `ProducerLaunchRootV1::covers_input_v1` in `context/producer_launch.rs:64`
  authenticates writable interval coverage. The producer-aware launch profile
  retains the original bindings and module, including with zero dependencies.
  Ordinary `launch` does not retain this Context producer root; do not silently
  pretend it has one. Supporting ordinary launch as a pending source would need
  a separately reviewed retained-output provenance extension.
- `versions/producer_readers.rs:684` admits peer producer-read leases only for
  directed peers, and its pending-input branch currently requires a directed
  peer producer. Ordinary pending compute output therefore reaches the ordinary
  reader guard and rejects. The existing launch profile already supports exact
  compute producers, and the same-device Copy domain demonstrates a narrow new
  adapter around unchanged journal acquisition/release/fold operations.
- `cooperative_sdma.rs:971` accepts overlapping native custody only when it is
  the exact ordered cooperative SDMA leaf. Compute custody is rejected even
  when its event is supplied. This is an important guard, not a general bypass
  to delete.
- `kfd_backend.rs:9172` chooses native versus staging at admission.
  `compute_xgmi.rs:458` requires normalizable initialized storage immediately.
  An in-flight compute owner need not be in that form yet.
- Cooperative dependencies already retain global producer results and gate
  copying on success (`kfd_backend.rs:8605,8769`). However, observing a queued
  native compute does not publish it: the leaf's explicit publication entry is
  `flush_stream_v1` at `kfd_backend.rs:13029`. A new pending admission without an
  explicit bounded producer-progress action can deadlock when only the peer or
  dependent readback stream is driven.

## Minimal Context Boundary

Add a private pending-compute input profile to the scalar peer root, separate
from its directed-peer state. Store the selected `ScalarPeerDependencyV1` and a
success-reconciliation state with checked depth. Keep `scalar_peer_copy=true`
and `directed_peer_copy=false`; do not label compute ancestry as directed peer
ancestry or make every ordinary peer dependency success-gated by implication.

Admission must verify the current exact latest submission writer, pending live
producer root, original allocation record/incarnation, full written source
coverage, explicit event, device, and backend submission. Prepare all storage
and checked dependency retains before effect. Reserve one active producer-read
lease bound to the current attempt epoch/content lineage and exact writer
reference. Do not predict the producer's future version. The destination gets
the existing ordinary submission writer. The initial profile can reject queued
writer reservations and additional pending producers to keep this finite.

Reuse `prepare_producer_batch_v1`, real journal acquire/release/fold operations,
and the bounded completion planner. Add a narrow `ComputePeer` observation and
root-validation adapter, as the existing Copy domain does, rather than changing
the old shared proof bodies or treating their prior correspondence as covering
the new adapter. Integrate root validation and settlement in:

- `context/peer_custody.rs` and a small child module if useful;
- `context/versions/producer_readers.rs` and `versions/submissions.rs`;
- `context/peer_reconciliation.rs`, especially its immutable/mutable state
  selectors and `require_directed_success_v1` ordinary-peer early return;
- `context/copy_custody.rs` and `producer_launch.rs` parent-depth adapters, so
  existing downstream readback/compute consumers recognize this new scalar peer
  profile without claiming it is a directed peer;
- Context pending-root validation, cancellation, release, and cleanup accounting.

The existing completion planner at `completion_reconciliation_body.rs:54` can
descend into a producer-aware launch because it has real retained state. Before
committing the peer's logical success, it must actually observe/reconcile that
producer and require its producer-read lease to be successful. A backend success
callback is not a Context version commit. Later failure must not retroactively
pretend the parent was logically observed.

There is a concrete downstream depth dependency: `copy_custody.rs` currently
constructs and validates readback depth exactly 2, and `launch_parent_depth_v1`
returns 1 for every nondirected scalar peer. A compute-backed peer has a real
parent depth, so compute -> peer -> readback must use checked parent-depth + 1
and validate the corresponding bound. Keep old observation-only peers at depth
1. Also ensure pending journal validation runs for every traversed new-profile
root, not only the originally requested readback. The old planner's embedded
pending-root checks recognize directed peers and producer launches only; a new
adapter must close that distinction without claiming old proof coverage.

Important distinction: backend DMA publication can safely follow exact backend
compute success/quiescence and restored ownership before the parent has been
polled through Context. Context must reconcile the parent before exposing peer
logical success, as existing producer-aware operations do. Requiring a separate
Context success notification before DMA would need a new handshake and is not
the minimal reuse design proposed here.

## Minimal Router Boundary and Retained Identity

Extend the existing `CooperativeCopySubmissionV1`, not `DeferredComputeV1`, with
an optional private compute-producer snapshot. Reuse cooperative allocation,
stream, dependency-retain, FIFO, submission-limit, and staging-account indexes.
No global scan and no second execution queue are needed.

The snapshot must bind:

- exact public backend event authenticated at admission and its global producer
  submission; original producer global stream and child/local submission route;
- original peer stream/global source and destination handles, child/local
  allocation routes, device identities, kinds, immutable logical extents, full
  regions, and the admitted directed XGMI route/packet plan;
- the actual producer's retained writable binding coverage and child record
  identity/depth, plus exact existing compute custody owners on the source;
- independently retained producer completion state until the copy conclusively
  settles, not merely until public event release or compute publication.

At admission inspect real `pending_compute[id].launch` or the actual active
lane's `ordinary_recipe`; both retain the admitted compute launch. Do not assume
every launch is still pending: clean launches can eagerly materialize. No bare
`allocation_is_active` bit or event-on-the-same-device proves source ownership
or write coverage. Require all conflicting source compute owners to match the
admitted exact producer in the initial profile, and no unrelated destination
custody. Existing completed-result receipt checks are a useful precedent for
identity validation, not permission to fabricate a child event or directed gate.

Prepare the native root's route/packet metadata and allocation storage at
admission, but acquire neither physical DATA owner nor child occupancy yet.
`compute_xgmi::Root::prepare` is metadata-only; it can be reused behind a new
strict pending-producer preflight while the old ready-storage preflight remains
unchanged. Keeping an actual planned root also lets the existing pending-peer
D2H admission recognize this peer before any native publication.

Do not allocate a full host-staging fallback for this admitted native candidate.
Before first native effect revalidate the entire snapshot, all dependencies'
exact successful/quiescent child results, current route and full extents, and
the actual initialized PUBLIC/VM/owner conditions. Failure of final eligibility
must settle or terminally retain according to actual custody; it must not read a
stale host shadow or silently exceed staging budgets. Ordinary noncandidate
copies retain the existing staged fallback.

After dependencies succeed, reuse `progress_compute_xgmi_v1` unchanged in
substance: wait for both children to be available, retire retained primary and
auxiliary compute caches, normalize source/destination storage, extract the
original persistent owners, then create/map/publish. Retained producer result
records must not prevent cache retirement and must not be released to achieve
it. Original physical extent, identity, generation, and ownership stay intact.

Likely production files: new `kfd_backend/compute_peer.rs`, small additions to
the cooperative root/admission/dependency phase in `kfd_backend.rs`, an exact
compute-custody observer beside `cooperative_sdma.rs`, and narrow metadata-only
preflight reuse in `compute_xgmi.rs`. No lower SDMA transfer changes are needed.

## Progress, Cancellation, and Failure Rules

1. Public submit/poll/wait remain observational for this cooperative path.
   Admission does not flush the producer, create a peer queue, map buffers, or
   claim endpoint occupancy.
2. Flush/drain of only the peer or dependent D2H stream must make progress on
   its exact retained compute producer. Reuse the child FIFO head flush and
   retained-prefix helpers; select one bounded dependency action, then yield.
   Do not recursively drain a foreign stream or publish work after the selected
   producer merely because it shares a stream. A needed preceding FIFO head is
   legitimate; unrelated later work is not.
3. Preserve directed/native ancestry servicing when a supported ordinary native
   producer carries existing peer launch retains. If the first increment cannot
   authenticate and bound that prefix, reject it before admission rather than
   ignoring the gate. Pending router DeferredCompute and queued-writer chains
   remain explicitly unsupported in this first increment.
4. Quiescent errors from a flushed predecessor cannot be attributed to the exact
   producer or peer unless that target's own quiescence is established. Preserve
   original diagnostics; Pending is not successful quiescence. Terminal/unwind
   during producer progress retains all existing roots and latches the router
   and the affected child. Do not refund a live producer's resources.
5. Consumer cancellation before physical peer custody is acquired is conclusive
   for the never-dispatched peer only. Release its router indexes and journal
   leases exactly once; do not cancel or release the compute producer itself.
   Producer failure/cancellation never starts DMA. Once peer extraction begins,
   existing `Root::is_quiescent`/TooLate and pair-poisoning rules remain in force.
6. Deadlines are absolute and checked between bounded actions; Pending can
   resume without resetting them. Native ioctl and compute normalization calls
   remain synchronous, not hard wall-clock bounded.
7. Logical native-copy count advances only after final queue retirement and
   both restorations. Downstream D2H and capture keep their existing exact event,
   restoration, quiescence, and result-credit requirements.

## Focused Qualification Matrix

- Context: zero-dependency producer-aware Write -> pending peer Read; backend
  success while parent Context Pending; parent observation before output version
  commit; released public event; retained producer release blocked; epoch,
  lineage, writer, incarnation, range, device, duplicate/alias and missing-event
  rejection. Ordinary pending-reader guard and unsupported backend stay closed.
- Backend: both truly queued and eagerly materialized compute at admission;
  source/destination roots untouched and occupancy empty; only dependent-stream
  drive completes producer, starts native transfer, restores both once, and
  releases all indexes. A real pending compute fixture, not assigned success,
  must exercise the handoff.
- Progress: observer and expired deadline no effects; repeated Pending; resumed
  deadline; prior FIFO head; later unrelated same-stream launch not published;
  opposite-direction/shared-child copies serialize without stranding producers;
  dependency depth/capacity and retain overflow reject before effects.
- Lifetime/error: pre-start consumer cancellation, producer cancellation/failure,
  producer flush predecessor-origin Quiescent, exact target Quiescent,
  post-effect Terminal/panic, cache retirement failure, all existing native peer
  fault boundaries, event release, repeated cancellation, and no result-retain
  leak. Uncertain custody must remain rooted through shutdown rejection.
- Composition: pre-admit compute -> peer -> pending D2H on distinct streams,
  register all needed final streams before group cutoff, release public events,
  drive only final owner/drain, and check exact callbacks and journal results.
  Ensure new success-gated peer state is traversed by the existing D2H Context
  reconciliation instead of treated as an ordinary observation-only leaf.
- Hardware: adapt the current fixed-65,537 sharded witness to omit the compute
  join, use the existing producer-aware launch profile, and pre-admit the exact
  compute/peer/readback event chain. Preserve full padded buffers, logical kernel
  lengths, C=-1 initialization, no host-installed computed output, independent
  every-element/padding/digest checks, one Context per process, explicit cleanup,
  and no physical-overlap/performance/formal claim. No broader kernel authority
  is required for this scheduling change.

## Reuse Verdict and Non-Goals

Reuse the existing generic producer journal/reconciliation bridge and cooperative
copy retain indexes. They supply most lifetime and version mechanics; they do
not already authenticate a pending compute-to-peer edge. Add the narrow Context
adapter and backend producer snapshot/progress admission, rather than weakening
ordinary reads, retagging directed roots, or creating a generic scheduler.

Do not combine this with arbitrary kernels, atomic/collective authority, pending
DeferredCompute chaining, partial native copies, persistent peer mappings across
logical copies, same-process device reopen, or performance parity. Existing
shared model/proof bodies can remain unchanged, but the new adapters require
their own reviewed source controls/tests and are not covered by old whole-adapter
formal correspondence automatically.
