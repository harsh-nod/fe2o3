# Next A3 Gate: Two Batches in One Live Context

Design only against the in-progress compute-shards checkpoint. No repository
source, authority, native admission rule, or qualification evidence is changed.
Round numbering below is zero-based: the first batch is round 0, the second is
round 1. Both must be observed successfully before shutdown.

## Smallest Useful Increment

Run the same fixed 65,537-element sharded problem twice with the existing two
changed datasets, in one process and one Context. Reuse the same device roster,
module/kernel handles, streams, A/B/C allocations, incoming peer allocations,
HostVisible upload/readback allocations, and existing current-thread owner.
This establishes reusable multi-GPU batch execution, not an output-dependent
recurrence, physical overlap, or a performance improvement.

For batch r in {0,1}, retain the current finite formulas:
`A[g]=g+131072*r`, `B[g]=3+r`, `C[g]=g+3+131073*r` as exact f32 integers.
Partition and padded extents stay fixed across both batches. Upload every byte
of A/B/C again, with existing padding A=-7, B=-11 and C=-1. Reset incoming peer
storage to a distinct full sentinel as well. Do not install expected computed
output from the host. Full refresh costs transfers but avoids weakening input
authentication or making a new device-output lineage assumption.

## Separate Finite Authority

Add a new hardware-qualification-only module and policy, for example
`qualification_gfx942_sharded_vecadd_rounds_v1.rs` and
`fixtures/trusted-gfx942-sharded-vecadd-rounds-v1/policy-v1.txt`, with its own
typed signature and argument type. Keep original vecadd, repeat, R57 V1/V2,
and the current one-shot shard policies byte-for-byte unchanged.

Each indexed child gate admits precisely two final requests using state
`First -> Second { exact_a, exact_b, exact_c } -> Exhausted`. Serialize the
identity latch and phase update together, such as with the existing R57-style
Mutex pattern; poisoned state denies. In each phase recheck the complete exact
artifact/ABI/geometry/Ordinary profile, three distinct full padded DeviceLocal
bindings, and all three expected whole-allocation digests plus current staged
bytes. Phase 1 additionally requires the identical three child-local allocation
IDs captured at phase 0. Rejection leaves the phase unchanged; acceptance is
never rolled back after publication error, uncertainty, cancellation, or panic.
There is no reset API and no third acceptance.

The existing repeat gate is unsuitable: it admits arbitrarily many requests,
has fixed unsharded inputs, and allows arbitrary output contents from its first
invocation. Its full-output-overwrite assumption must not be silently extended
to shard padding. A two-phase gate counts accepted authorizations, not successful
GPU completions; the witness must independently require each exact completion
before proceeding. This remains a finite trusted-artifact boundary, not general
production authority, authenticated compiler lineage, or machine refinement.

Minimal backend additions are a new exact gate variant/Debug/dispatch and an
indexed `open_gfx942_sharded_vecadd_rounds_peer_qualification_v1(unique_ids)`
constructor in `kfd_backend/multi_qualification.rs`. Validate the full UID
roster and both phase recipes before native opening; retain the existing
`open_default_with_gate_policy_v1(gates, true)` path and process-lifetime VM
admission. No Context reopen, model-history retirement, or scheduler change.

## Observe Without Closing Admission

Do not call `begin_drain` or `begin_drain_with_capture_group` between batches:
their admission cutoff is permanent. Do not stop and recreate the owner, which
would dispose or retain its Context rather than yield a reusable native one.

The existing `RuntimeAsyncEngineHandleV1::enqueue_with_context` is sufficient.
Use bounded Context commands with the current-thread owner's
`drive_until_ready`, never `try_with_context` on that owner thread. Register
progress streams once; enqueue all N peer submissions and exact-event D2H
continuations in one command before the scheduler can flush any of them.
Use exact submission receipts/callbacks and bounded poll commands to require
all N peer and N D2H operations Succeeded, not merely quiescent. Keep the same
original futures and handles across deadline expiry; never turn Pending into
success or enqueue a replacement copy. Joining compute before peer admission
remains mandatory for native route selection.

After exact completion/reconciliation, enqueue one bounded command that reads
only the N completed HostVisible outputs into a caller-preallocated buffer
(at most 286,720 bytes). It uses ordinary `Context::read_allocation`, which
still validates journal availability and backend access; return the complete
buffer only if every read succeeds. Discard any partially read prefix on error.
Verify every logical element and padding byte and gather the 262,148 meaningful
bytes in source-shard order. Because Context commands are serialized and no
next-batch writers have been admitted, this is a live, settled-output snapshot.
It is not the drain-capture API's quiescence/capture-credit contract or protection
against external writers. Bound the temporary buffer explicitly; an arbitrary
Context-command return value does not acquire drain-capture byte credits.

This also permits a live, read-only command to inspect the existing qualified
native-copy counter after each joined batch: require 0 -> N -> 2N before any
final cutoff. No new production introspection API is required. Callback records
must authenticate each original submission and exactly one delivery.

## Handoff and Reuse

1. For each batch, settle all 4N setup uploads before releasing any; release
   reverse dependency/stream order. Reuse the original upload allocations.
2. Admit all N exact typed computes, require each actual Context Succeeded and
   restored custody, then release their results. Preserve module/kernel handles.
3. Admit all N native peer copies and their exact-event D2H continuations before
   progress. Release public peer events after dependent admission; do not retain
   observation events accidentally through the reuse boundary.
4. Settle all transfers, read and verify the complete HostVisible result, and
   check the native counter. Release D2H results before peer producer results,
   reversing any additional same-stream dependencies. Do not ignore Busy.
5. Only then refresh the same A/B/C/incoming allocations for the next batch.
   Keep streams, modules and native allocation owners alive. Authenticated read
   A/B owners may be H2dReady; written C is replay-ready. Normal upload paths
   perform the required normalization/promotion; do not force enum variants.
6. After round 1 is observed and all results/events released, perform one final
   drain and explicit owned shutdown. If final capture is retained as an extra
   check, pre-register its tokens before the one final cutoff. Check native
   cleanup and retained reply/result bytes explicitly.

CPU tests can inspect exact physical scripted owner identities across both
batches. A hardware witness without a new owner-inspection API should claim
stable logical allocation handles, not independently observed physical mapping
identity. It can nevertheless verify both changed full outputs and exact native
logical-copy counter deltas on the same live Context.

## Qualification Tests

- All N=2..8 recipes and two phases; wrong phase/order/data/offset/access/padding,
  changed allocation identities, old/foreign signatures, concurrent phase
  attempts, rejection without consumption, no third acceptance, no reset after
  failure/uncertainty. Preserve all existing one-shot/repeat/R57 tests.
- Real Context/router/scripted lifecycle for N=2/3/5/8: unequal padded extents,
  exact A/B-ready and C-replay restoration, all peers admitted before progress,
  ordinary exact-event D2H, full source-global ordering, stable owner identities,
  normal cleanup without clearing native flags, and no fabricated compute bytes.
- Live owner snapshot before cutoff, new admission after the first snapshot,
  deadline expiry/resumption, bounded command/reply capacity and partial-read
  failure disposal. Early host write/release while compute/peer/D2H retains an
  allocation must still reject. Test stale/released prior-batch events.
- Failure/cancellation in either batch must not start the next batch or reset
  authority. Stop on Failed/Unknown or native uncertainty and report retained
  custody honestly. Final drain is quiescence, not a substitute for exact success.
- Hardware uses one process per selected roster, not per batch: N2/3/5/largest
  genuinely free and reversed roster. Verify both full output digests, padding,
  exact 2N compute + 2N peer + 2N readback receipts, native counter 2N, and shared
  host cleanup. No timing speedup, overlap, or formal execution claim.

## Deferred Output-Dependent Iteration

`C_previous + B -> A_next` would avoid re-uploading inputs and is a useful later
step, but it is not required for the first live-Context reuse checkpoint. The
current authority request carries neither an exact producing submission nor
its committed output version. Matching a prior allocation ID and observing
`content_sha256=None` is not by itself authenticated output provenance: partial
host mutation can also invalidate that digest. Do not relabel the old R57
qualification assumption as a new producer-lineage proof. A strict recurrence
requires an explicit exact-output-version/producer contract (or a separately
declared finite qualification trust boundary), plus pending-reader and stale-
version negative tests. No changes to existing policy predicates are justified
by this next-step design.
