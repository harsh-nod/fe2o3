#!/usr/bin/env python3
"""Rebuild the unchanged pinned fixture on MI300X without opening a GPU."""
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '76dbbb03d65529d28bb6d15d2970d020cc7ef48b'
FIXTURE = Path('crates/fe2o3-runtime/fixtures/trusted-gfx942-vecadd-v1')
NAMES = ['build-and-verify.sh', 'policy-v1.txt', 'vecadd.ll', 'vecadd.hsaco']
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
OBJECT_SHA = '3a25e364dd1e1931d1a16c24b37aa998df2c6ef1cbcf0ec2afb6372cbc878bab'
COMPILER = 'AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.4 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def capture(name, argv):
    child = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    folder = ROOT / name
    result = json.loads((folder / 'result.json').read_bytes())
    stdout, stderr = [(folder / part).read_bytes() for part in ('stdout', 'stderr')]
    assert result['argv'] == argv
    assert result['stdout_sha256'] == sha(stdout) and result['stderr_sha256'] == sha(stderr)
    assert child.returncode == result['exit_code'] == 0, (name, result, stderr)
    assert not result['timed_out'] and result['local_process_group_absent']
    return stdout.decode()


def remote(name, argv, bound='30s'):
    return capture(name, SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])])


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1 and not (ROOT / 'rebuild.json').exists()
    expected = {}
    for name in NAMES:
        relative = FIXTURE / name
        original = subprocess.check_output(['git', 'show', BASE + ':' + str(relative)], cwd=REPO)
        assert (REPO / relative).read_bytes() == original
        expected[name] = sha(original)
    assert expected['vecadd.hsaco'] == OBJECT_SHA
    directory, verified, cleaned, errors = None, False, False, []
    try:
        observed = remote('compiler', ['/opt/rocm/llvm/bin/clang', '--version'])
        assert observed.splitlines()[0] == COMPILER
        directory = remote('create-scratch', ['/usr/bin/mktemp', '-d',
            '/tmp/fe2o3-sharded-vecadd-build-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-sharded-vecadd-build-20261002-[A-Za-z0-9]{6}', directory)
        capture('upload-inputs', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
            '-o', 'StrictHostKeyChecking=yes', *[str(REPO / FIXTURE / name) for name in NAMES],
            'mi300x:' + directory + '/'])
        paths = [directory + '/' + name for name in NAMES]
        hashes = remote('initial-input-hashes', ['/usr/bin/sha256sum', *paths])
        assert hashes.splitlines() == [expected[name] + '  ' + path for name, path in zip(NAMES, paths)]
        output = remote('rebuild', ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
            'ROCM_PATH=/opt/rocm', 'TMPDIR=' + directory,
            '/bin/bash', directory + '/build-and-verify.sh'], '120s')
        assert output == 'verified trusted-gfx942-vecadd-v1 ' + OBJECT_SHA + '\n'
        hashes = remote('final-input-hashes', ['/usr/bin/sha256sum', *paths])
        assert hashes.splitlines() == [expected[name] + '  ' + path for name, path in zip(NAMES, paths)]
        verified = True
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                remote('remove-owned-inputs', ['/usr/bin/rm', '-f', '--',
                    *[directory + '/' + name for name in NAMES]])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        result = dict(accepted=verified and cleaned and not errors, baseline=BASE,
                      input_sha256=expected, compiler=COMPILER, object_sha256=OBJECT_SHA,
                      owned_directory=directory, owned_cleanup_complete=cleaned,
                      gpu_execution=False, compiler_correctness_proof=False, errors=errors)
        with (ROOT / 'rebuild.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result))
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
