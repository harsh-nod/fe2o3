git remote -v 
