git diff --exit-code 4e7c98c065eb3ea2714bc0cdc79067673607b260 -- crates/fe2o3-runtime crates/fe2o3-kfd 
