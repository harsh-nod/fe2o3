pwd 
