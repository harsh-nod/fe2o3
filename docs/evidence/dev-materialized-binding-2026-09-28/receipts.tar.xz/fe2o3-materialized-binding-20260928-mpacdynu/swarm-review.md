# Read-only Swarm Review

Both reviewers were instructed not to edit, build, run tests, request permissions
or use escalation. The primary owned edits, integration and qualification.

`binding_custody_review` confirmed the initial ownership gap and existing
one-time Pending handoff. It required a distinct Binding phase, captured prior
generation before overwrite, retained recycled metadata and callback-rooted
returned outcomes. It caught omitted preflight costs in native_binding timing;
the original timing boundary was restored before final qualification. It found
no further production-path regression in its review, not a proof of absence.

`binding_tests_review` caught a weak immediate-success oracle and distinguished
scripted origin assignment from actual recycled metadata retention. Exact
execution states, owner/event identities, publication counts and a shared
metadata helper test were added. It reviewed the old detach-oracle corrections
and found no weakening: repeated rejection now retains malformed fixture
metadata; explicit fixture removal does not dispose a native owner.

Next-boundary review identified ordinary Prepared retry's temporary Active
removal and ambiguous phase restoration. Existing terminal gating means this
is not a demonstrated healthy-path reuse exploit. Proposed repair: intercept
Prepared before Active removal, transfer profile/origin into Binding, share a
submit-only callback-rooted reducer and finish transition, poison/resume unwind,
and consolidate the scripted retry path. Do not rebind or repeat Pending retains.

New scripts do not fabricate native batch authority. The detach wiring check
only verifies source ordering. Neither these reviews nor CPU test passes prove
native execution, formal correspondence, protected Worker behavior or parity.

The first development test invocation began while rustfmt was still running;
it is not qualification evidence. It failed in profiler fixture setup. All
subsequent qualification builds/tests/static checks were serialized, without
source edits during those jobs. Original failures remain in this campaign.
