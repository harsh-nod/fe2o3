git show -s --format=%H%n%T%n%s HEAD 
