#!/usr/bin/env python3
"""Fresh signed successor qualification; preserved153 and observations are not promoted."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import types

BASE = Path(__file__).resolve().parent
BINDER = BASE / 'bind_argument_candidate.py'
BINDER_SHA = 'd56501af6ef7c81052d387182a79b5fab6c9bca6c057f83a18db5ea09d9710dc'
SOURCE_SHA = '3b3703e23920000784de73cbd2e8f59fbadb8847e9fdda823acd84ffc3cbeaa3'
BINDING_SHA = '970baf9fa1ff4954daa177e70ff079b1c973e8d29641e787ca14fe3e37e479e8'
SIGNED_COMMIT = 'e02b7229ab6b85c2c1697d239d6f82e96ff04d45'
PREPARED = BASE / 'signed-primitive-prepared-2.json'
PLAN = BASE / 'signed-primitive-plan-2.json'
SOURCE_CONTROL_OK = ('PASS: codec primitive source calibration (13 groups; 11 actual diagnostic fixtures replayed; '
                     '31 mutants constructed; no verifier execution)\n')


def need(value, message):
    if not value:
        raise ValueError(message)


def binding(require_signed):
    data = BINDER.read_bytes()
    need(BINDER.resolve() == BINDER and not BINDER.is_symlink()
         and hashlib.sha256(data).hexdigest() == BINDER_SHA, 'exact reviewed successor binder')
    b = types.ModuleType('primitive_signed_argument_binding')
    b.__file__ = str(BINDER)
    sys.modules[b.__name__] = b
    exec(compile(data, str(BINDER), 'exec'), b.__dict__)
    need((type(SIGNED_COMMIT) is str and len(SIGNED_COMMIT) == 40) if require_signed
         else SIGNED_COMMIT is None, 'signed execution or unsigned planning, never mixed')
    a, values, source, blobs, check, references, static, paths, commands = b.binding(SIGNED_COMMIT)
    old_b, cap, q, v4, v3, parts, old_source, old_candidate, old_check, old_blobs, previous = values
    c, f, cpu, h, s, loader, d, diagnostics, model, prior, classifier = parts
    need(h.sha(b.SOURCE) == SOURCE_SHA and h.sha(b.BINDING) == BINDING_SHA
         and json.loads(h.raw(b.SOURCE)) == source, 'exact reviewed successor source binding')
    candidate = json.loads(h.raw(b.BINDING))
    need(candidate['parent'] == b.PARENT and candidate['base'] == f.HEAD
         and candidate['source_signed'] is False and candidate['source_sha256'] == SOURCE_SHA
         and candidate['proof_or_native_source_changed_since_cpu'] is False
         and candidate['prior_signed_attempt_accepted'] is False
         and candidate['observations_promoted_to_kills'] is False
         and candidate['self_contained_evidence'] is False
         and candidate['paths'] == paths and candidate['metadata_replacements'] == b.METADATA
         and candidate['references'] == references and candidate['static_reuse'] == static
         and candidate['cpu_reuse'] == old_candidate['cpu_reuse'] and candidate['tools'] == old_candidate['tools']
         and candidate['proof_closure'] == old_candidate['proof_closure']
         and candidate['commands'] == commands
         and all(h.sha(b.CANDIDATE / path) == digest == source[path]['sha256'] for path, digest in paths.items()),
         'same nine-path archive, exact four-path metadata delta and explicit immutable CPU/static reuse')
    return b, a, values, source, candidate, check, blobs


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize, 'python3 -I -B required')
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--plan', action='store_true')
    modes.add_argument('--prepare', action='store_true')
    modes.add_argument('--execute', action='store_true')
    parser.add_argument('--prepared-sha256')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    b, a, values, source, candidate, check, blobs = binding(not args.plan)
    old_b, cap, q, v4, v3, parts, old_source, old_candidate, old_check, old_blobs, previous = values
    c, f, cpu, h, s, loader, d, diagnostics, model, prior, classifier = parts
    mutations = check.mutations(h.raw(b.REPO / check.BODY).decode())
    cases = {name: {'selector': selector, 'body_sha256': hashlib.sha256(body.encode()).hexdigest()}
             for name, (body, selector) in mutations.items()}
    phases = a.phase_names(cases)
    signature = cpu.plan(s, [])['signature']
    signature[-1] = SIGNED_COMMIT
    commands = dict(candidate['commands'], signature=signature,
                    controls=['/usr/bin/python3.12', '-I', '-B', str(b.REPO / v3.CONTROL)])
    need(cap.command(commands['positive'], b.REPO, check.PROOF) == commands['positive'], 'same unfiltered reporting-one argv')
    pins = {str(path): h.sha(path) for path in (Path(__file__).resolve(), BASE / 'test_signed_primitive_campaign_v2.py',
        BINDER, BASE / 'test_bind_argument_candidate.py', b.SOURCE, b.BINDING,
        BASE / 'extend_argument_fixtures.py',
        *(b.CANDIDATE / path for path in candidate['paths']))}
    frozen = {'commit': SIGNED_COMMIT, 'parent': b.PARENT, 'base': f.HEAD, 'source': source, 'signed_blobs': blobs,
        'candidate_binding_sha256': BINDING_SHA, 'tools': candidate['tools'], 'new_raw_pins': pins,
        'references': candidate['references'], 'cpu_reuse': candidate['cpu_reuse'], 'static_reuse': candidate['static_reuse'],
        'proof_closure': candidate['proof_closure'], 'cases': cases, 'commands': commands, 'phases': phases,
        'fresh_full_proofs': 3, 'expected_full_verified': 54, 'fresh_logical_negatives': 31,
        'fresh_cpu_execution': False, 'fresh_static_execution': False, 'prior_signed_attempt_accepted': False,
        'self_contained_evidence': False, 'historical_pid_probes': False,
        'scope': 'signed model-only eight primitive bodies and exact byte-bound V3 CPU reuse; no complete-wire, native, performance, parity, portable evidence publication or milestone exit'}
    if args.plan or args.prepare:
        path = PLAN if args.plan else PREPARED
        need(args.output is None and args.prepared_sha256 is None and not path.exists(), 'fresh plan/preparation only')
        h.save(path, frozen)
        print(json.dumps({'file': str(path), 'sha256': h.sha(path), 'signature_pending': args.plan,
                          'stages': len(phases), 'solver_runs': 34, 'new_raw_bytes_before_prepared': sum(Path(p).stat().st_size for p in pins)}))
        return
    need(args.prepared_sha256 == h.sha(PREPARED) and json.loads(h.raw(PREPARED)) == frozen, 'exact reviewed signed preparation')
    out = args.output
    need(out is not None and out == out.resolve() and out.parent == BASE and not out.exists(), 'fresh canonical output only')
    out.mkdir()
    (out / 'tmp').mkdir()
    pins[str(PREPARED)] = h.sha(PREPARED)
    archive = h.archive_raw_buffers(out, pins)
    namespace, env = s.process_namespace_identity(), d.environment(out)
    h.save(out / 'inputs.json', dict(frozen, namespace=namespace, environment=env))
    managed = loader.load()
    loader.archive(out)
    bounded = check.primitive_classifier(classifier)
    rows, errors, trees, negatives = [], [], {}, {}

    def current():
        b.current(a, values, source, SIGNED_COMMIT, blobs, candidate['references'])
        need(d.tool_inventory(s) == candidate['tools'] and s.process_namespace_identity() == namespace
             and all(h.sha(Path(path)) == digest for path, digest in pins.items())
             and all(cap.tree(h, Path(root)) == inventory for root, inventory in trees.items())
             and {str(path): h.sha(b.REPO / path) for path in check.FILES} == candidate['proof_closure'],
             'signed source/tool/new-record/namespace/seven-file tree continuity')
        q.elf_modes_current(candidate['cpu_reuse'])

    def stage(name, argv, accept, timeout=130):
        current()
        folder = out / name
        folder.mkdir()
        row = {'name': name, 'accepted': False, 'owned_launch_attempted': False}
        rows.append(row)
        h.save(folder / 'command.json', {'argv': argv, 'cwd': str(b.REPO), 'environment': env, 'timeout_seconds': timeout})
        print('START ' + name, flush=True)
        try:
            cwd = Path.cwd()
            try:
                os.chdir(b.REPO)
                row['owned_launch_attempted'] = True
                rc, stdout, stderr = managed.run_owned(argv, timeout, folder / 'owned', env)
            finally:
                os.chdir(cwd)
            c.receipt(json.loads(h.raw(folder / 'owned/record.json')), argv, rc, stdout, stderr,
                      h.raw(folder / 'owned/stdout.log'), h.raw(folder / 'owned/stderr.log'))
            row['classification'] = accept(rc, stdout, stderr)
            current()
            row['accepted'] = True
        finally:
            h.save(folder / 'result.json', row)
            print('END ' + name + ' accepted=' + str(row['accepted']), flush=True)

    def release(rc, stdout, stderr):
        need(type(rc) is int and rc == 0 and stdout == d.CLOSURE_OK and not stderr, 'exact pinned release bracket')

    def positive(root, rc, stdout, stderr):
        need(bounded.proof_positive(rc, stdout, stderr, prior.VERIFIER,
             dict(d.EXPECTED_WITHOUT_COUNT, verified=54), {str(root / p) for p in check.FILES}),
             'fresh strict unfiltered whole-crate 54/0 with empty stderr')
        return {'verified': 54, 'errors': 0, 'whole_crate': True, 'stderr_empty': True}

    def source_tree(name, body=None):
        root = out / name
        inventory = dict(candidate['proof_closure'])
        for path in check.FILES:
            data = body.encode() if path == check.BODY and body is not None else h.raw(b.REPO / path)
            destination = root / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(data)
            inventory[str(path)] = hashlib.sha256(data).hexdigest()
        need(cap.tree(h, root) == inventory, 'independent exact seven-file tree readback')
        trees[str(root)] = inventory
        return root, inventory

    try:
        stage(phases[0], commands['signature'], lambda rc, stdout, stderr:
              need(type(rc) is int and rc == 0 and not stdout and stderr == s.SIGNATURE, 'fresh exact SSH signed identity'), 60)
        stage(phases[1], commands['controls'], lambda rc, stdout, stderr:
              need(type(rc) is int and rc == 0 and stdout == SOURCE_CONTROL_OK and not stderr, 'fresh portable source calibration'), 120)
        stage(phases[2], commands['release'], release)
        stage(phases[3], commands['positive'], lambda rc, stdout, stderr: positive(b.REPO, rc, stdout, stderr))
        root, inventory = source_tree('relocated-source')
        need(inventory == candidate['proof_closure'], 'relocated positive source is byte-identical')
        h.save(out / 'relocated-inputs.json', inventory)
        stage(phases[4], cap.command(commands['positive'], root, check.PROOF),
              lambda rc, stdout, stderr: positive(root, rc, stdout, stderr))
        for phase, (name, (body, focus)) in zip(phases[5:-2], mutations.items(), strict=True):
            root, inventory = source_tree(name + '-source', body)
            need(inventory == dict(candidate['proof_closure'], **{str(check.BODY): cases[name]['body_sha256']})
                 and {p for p in inventory if inventory[p] != candidate['proof_closure'][p]} == {str(check.BODY)},
                 'exact one-file actual-body mutant, unchanged contracts and closure')
            h.save(out / (name + '-mutation.json'), {'root': str(root), 'inputs': inventory, **cases[name]})

            def negative(rc, stdout, stderr, root=root, focus=focus, name=name):
                need(bounded.logical_negative(check.selection_notes(types.SimpleNamespace(LOGICAL_ERRORS=set()), focus),
                     rc, stdout, stderr, prior.VERIFIER, {str(root / p) for p in check.FILES}),
                     'fresh bounded actual-family postcondition logical failure, not frontend or notes-only')
                value = {'selector': focus, 'verified': 0, 'errors': 1, 'logical_negative': True,
                         'actual_body_sha256': cases[name]['body_sha256']}
                negatives[name] = value
                return value

            stage(phase, cap.command(commands['positive'], root, check.PROOF, focus), negative)
        stage(phases[-2], commands['positive'], lambda rc, stdout, stderr: positive(b.REPO, rc, stdout, stderr))
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
    finally:
        try:
            stage(phases[-1], commands['release'], release)
        except BaseException as error:
            errors.append('closing release: ' + type(error).__name__ + ': ' + str(error))
        try:
            current()
            h.validate_raw_archive(out, archive)
            h.save(out / 'fresh-census-inputs.json', h.census_input_roster(out, rows))
            closure = s.independent_absence(out, namespace)
            h.save(out / 'fresh-process-closure.json', closure)
            need(closure['all_recorded_groups_absent'] and len(closure['recorded_groups'])
                 == sum(row['owned_launch_attempted'] for row in rows), 'every fresh owned group closed')
            h.save(out / 'closing-inputs.json', {'source': source, 'signed_blobs': b.inventory(h, cpu, old_source, SIGNED_COMMIT)[1],
                'tools': d.tool_inventory(s), 'proof_closure': candidate['proof_closure'],
                'namespace': s.process_namespace_identity(), 'external_references_revalidated': True,
                'self_contained_evidence': False})
        except BaseException as error:
            errors.append('closing continuity: ' + type(error).__name__ + ': ' + str(error))
        accepted = [row['name'] for row in rows] == phases and all(row['accepted'] for row in rows) and not errors and set(negatives) == set(cases)
        h.save(out / 'results.json', {'signed_primitive_campaign_pass': accepted, 'stages': rows, 'errors': errors,
            'negatives': negatives, 'source_signed': bool(rows and rows[0]['accepted']), 'fresh_cpu_execution': False,
            'self_contained_evidence': False, 'selector_observations_relabelled': False,
            'prior_signed_attempt_accepted': False, 'fresh_static_execution': False,
            'next_phase_executed': False, 'scope': frozen['scope']})
        print(json.dumps({'signed_primitive_campaign_pass': accepted, 'errors': errors}), flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
