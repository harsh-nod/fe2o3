#!/usr/bin/env python3
"""Light draft/signed campaign controls; no signature, CPU or solver execution."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import types

assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
path = Path(__file__).with_name('signed_primitive_campaign_v2.py')
spec = importlib.util.spec_from_file_location('signed_primitive_controls', path)
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def refused(call):
    try:
        call()
    except (ValueError, AssertionError, KeyError):
        return
    raise AssertionError('expected strict refusal')


def main():
    unsigned = a.SIGNED_COMMIT is None
    b, old_a, values, source, candidate, check, blobs = a.binding(not unsigned)
    old_b, cap, q, v4, v3, parts, old_source, old_candidate, old_check, old_blobs, previous = values
    c, f, cpu, h, s, loader, d, diagnostics, model, prior, classifier = parts
    assert len(source) == 6500 and len(candidate['paths']) == 9
    assert (blobs is None) == unsigned
    assert candidate['cpu_reuse']['cpu_executed_by_this_packet'] is False
    assert candidate['cpu_reuse']['native_source_unchanged'] is True
    assert candidate['observations_promoted_to_kills'] is False
    assert candidate['self_contained_evidence'] is False
    cases = check.mutations(h.raw(b.REPO / check.BODY).decode())
    phases = old_a.phase_names(cases)
    assert len(phases) == len(set(phases)) == 38
    assert phases[:5] == ['01-source-signature', '02-portable-source-controls', '03-release-before',
                          '04-positive-before', '05-positive-relocated']
    assert phases[-2:] == ['37-positive-after', '38-release-after']
    assert phases[5:-2] == [f'{i:02d}-' + name for i, name in enumerate(cases, 6)]
    refused(lambda: old_a.phase_names(list(cases)[:-1]))
    refused(lambda: old_a.phase_names(list(cases) + ['unknown']))
    refused(lambda: old_a.phase_names([next(iter(cases))] * 31))
    positive = candidate['commands']['positive']
    assert cap.command(positive, b.REPO, check.PROOF) == positive
    relocated = a.BASE / 'hypothetical-only-source'
    assert cap.command(positive, relocated, check.PROOF) == [*positive[:-1], str(relocated / check.PROOF)]
    for _, focus in cases.values():
        assert cap.command(positive, relocated, check.PROOF, focus) == [
            *positive[:-1], '--verify-function', focus, '--verify-root', str(relocated / check.PROOF)]
    for bad in (positive + ['--verify-root'], positive + ['--multiple-errors', '1']):
        refused(lambda argv=bad: cap.command(argv, b.REPO, check.PROOF))
    for value in ('0', '2'):
        bad = list(positive)
        bad[bad.index('--multiple-errors') + 1] = value
        refused(lambda argv=bad: cap.command(argv, b.REPO, check.PROOF))
    assert a.SOURCE_CONTROL_OK == ('PASS: codec primitive source calibration (13 groups; '
        '11 actual diagnostic fixtures replayed; 31 mutants constructed; no verifier execution)\n')
    original_git = b.git
    try:
        for value in ('', 'a' * 39, 'A' * 40, 0, True):
            refused(lambda value=value: b.inventory(h, cpu, old_source, value))
        commit = 'a' * 40
        for parent, status, fmt in (
            ('wrong\n', b'', b'sha1\n'),
            (commit + ' ' + b.PARENT + '\n', b' M altered\n', b'sha1\n'),
            (commit + ' ' + b.PARENT + '\n', b'', b'sha256\n')):
            responses = {'rev-list': parent.encode(), 'status': status, 'rev-parse': fmt}
            b.git = lambda *args: responses[args[0]]
            refused(lambda: b.inventory(h, cpu, old_source, commit))
        for names in ([], list(b.METADATA)[:-1], [*b.METADATA, 'extra']):
            responses = {'rev-list': (commit + ' ' + b.PARENT + '\n').encode(),
                         'status': b'', 'rev-parse': b'sha1\n', 'diff': b'\0'.join(p.encode() for p in names)}
            b.git = lambda *args: responses[args[0]]
            refused(lambda: b.inventory(h, cpu, old_source, commit))
    finally:
        b.git = original_git
    for key in ('self_contained', 'archived_again', 'historical_pid_probes'):
        changed = copy.deepcopy(candidate['references'])
        changed[0][key] = True
        refused(lambda value=changed: old_b.references_current(q, h, f, value, previous, old_source))
    assert candidate['proof_closure'] == previous['proof_closure']
    assert candidate['static_reuse']['fresh_execution'] is False
    assert candidate['prior_signed_attempt_accepted'] is False
    assert len(candidate['references']) == 6 and len(candidate['metadata_replacements']) == 4
    expected_elf = {'debug': 'c8601dcba24981c1af478999c85101fd47af541703d72af1d29ab538478d7591',
                    'release': '2aaf09868c1ffd106895d56a967b6b6cabc34e616e5058c2d34b23a37641a73e'}
    assert set(candidate['cpu_reuse']['artifacts']) == set(expected_elf)
    for name, row in candidate['cpu_reuse']['artifacts'].items():
        assert h.sha(Path(row['source'])) == h.sha(Path(row['retained'])) == row['sha256'] == expected_elf[name]
        assert row['artifact']['features'] == [] and row['artifact']['profile']['test'] is True
        assert row['artifact']['profile']['debug_assertions'] is (name == 'debug')
    print('PASS: signed primitive campaign controls (7 groups; signature pin ' + ('pending' if unsigned else 'bound') + '; read-only Git metadata only; no solver/test child execution)')


if __name__ == '__main__':
    main()

