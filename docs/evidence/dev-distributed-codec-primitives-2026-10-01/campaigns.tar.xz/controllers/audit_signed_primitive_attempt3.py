#!/usr/bin/env python3
"""Accepted successor replay; read-only Git metadata, no new solver or test execution."""
import hashlib
import json
from pathlib import Path
import sys
import types

BASE = Path(__file__).resolve().parent
RUNNER = BASE / 'signed_primitive_campaign_v2.py'
RUNNER_SHA = 'e9b5c76261602fb189207eb410c0b1107f11fed021fd7210f62cbf4e546a4435'
PACKET = BASE / 'signed-primitive-campaign-attempt-3'
OUTPUT = BASE / 'signed-primitive-post-audit-3.json'


def need(value, message):
    if not value:
        raise ValueError(message)


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize, 'python3 -I -B required')
    raw = RUNNER.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == RUNNER_SHA, 'exact reviewed executed runner')
    a = types.ModuleType('primitive_terminal_audit_helpers')
    a.__file__ = str(RUNNER)
    sys.modules[a.__name__] = a
    exec(compile(raw, str(RUNNER), 'exec'), a.__dict__)
    b, old_a, values, source, candidate, check, blobs = a.binding(True)
    old_b, cap, q, v4, v3, parts, old_source, old_candidate, old_check, old_blobs, previous = values
    c, f, cpu, h, s, loader, d, diagnostics, model, prior, classifier = parts
    result = json.loads(h.raw(PACKET / 'results.json'), object_pairs_hook=classifier.strict_object)
    opened = json.loads(h.raw(PACKET / 'inputs.json'), object_pairs_hook=classifier.strict_object)
    closed = json.loads(h.raw(PACKET / 'closing-inputs.json'), object_pairs_hook=classifier.strict_object)
    closure = json.loads(h.raw(PACKET / 'fresh-process-closure.json'), object_pairs_hook=classifier.strict_object)
    need(result['signed_primitive_campaign_pass'] is True and result['source_signed'] is True
         and result['errors'] == [] and result['fresh_cpu_execution'] is False
         and result['selector_observations_relabelled'] is False and result['next_phase_executed'] is False
         and result['prior_signed_attempt_accepted'] is False and result['fresh_static_execution'] is False,
         'complete terminal acceptance only; no partial or old-observation promotion')
    signature = cpu.plan(s, [])['signature']
    signature[-1] = a.SIGNED_COMMIT
    expected_commands = dict(candidate['commands'], signature=signature,
        controls=['/usr/bin/python3.12', '-I', '-B', str(b.REPO / v3.CONTROL)])
    need(opened['commands'] == expected_commands and opened['parent'] == b.PARENT and opened['base'] == f.HEAD
         and opened['references'] == candidate['references'] and opened['cpu_reuse'] == candidate['cpu_reuse']
         and opened['static_reuse'] == candidate['static_reuse']
         and opened['prior_signed_attempt_accepted'] is False and opened['fresh_static_execution'] is False,
         'independently reconstructed successor commands and explicit unchanged evidence reuse')
    need(opened['commit'] == a.SIGNED_COMMIT and opened['source'] == closed['source'] == source
         and opened['signed_blobs'] == closed['signed_blobs'] == blobs
         and opened['proof_closure'] == closed['proof_closure'] == candidate['proof_closure']
         and opened['tools'] == closed['tools'] == candidate['tools']
         and opened['namespace'] == closed['namespace'] == closure['namespace']
         and closed['external_references_revalidated'] is True
         and opened['self_contained_evidence'] is closed['self_contained_evidence'] is False,
         'complete signed-source/tool/namespace/reference continuity joins')
    need(all(h.sha(Path(path)) == digest for path, digest in opened['new_raw_pins'].items()), 'all new executed helper/prepared bytes unchanged')
    index = json.loads(h.raw(PACKET / 'raw-archive-index.json'))
    q.archive_readback(h, PACKET, index)
    mutations = check.mutations(h.raw(b.REPO / check.BODY).decode())
    phases = old_a.phase_names(mutations)
    need([row['name'] for row in result['stages']] == opened['phases'] == phases
         and len(phases) == 38 and set(result['negatives']) == set(mutations), 'all 38 stages and 31 actual mutants')
    bounded = check.primitive_classifier(classifier)
    groups, audit, family_counts = [], [], {}
    for position, row in enumerate(result['stages']):
        folder = PACKET / row['name']
        recorded = json.loads(h.raw(folder / 'command.json'))
        record = json.loads(h.raw(folder / 'owned/record.json'))
        stdout, stderr = [h.raw(folder / ('owned/' + name + '.log')).decode() for name in ('stdout', 'stderr')]
        rc = 1 if 5 <= position < 36 else 0
        need(row['accepted'] is True and row['owned_launch_attempted'] is True
             and json.loads(h.raw(folder / 'result.json')) == row
             and recorded['cwd'] == str(b.REPO) and recorded['environment'] == opened['environment'], 'exact accepted stage/raw command join')
        if position == 0:
            argv, timeout = opened['commands']['signature'], 60
            need(not stdout and stderr == s.SIGNATURE, 'exact actual signed identity')
        elif position == 1:
            argv, timeout = opened['commands']['controls'], 120
            need(stdout == a.SOURCE_CONTROL_OK and not stderr, 'actual portable calibration passed')
        elif position in (2, 37):
            argv, timeout = opened['commands']['release'], 130
            need(stdout == d.CLOSURE_OK and not stderr, 'actual pinned release brackets')
        elif position in (3, 4, 36):
            root = PACKET / 'relocated-source' if position == 4 else b.REPO
            argv, timeout = cap.command(opened['commands']['positive'], root, check.PROOF), 130
            if position == 4:
                need(cap.tree(h, root) == candidate['proof_closure']
                     == json.loads(h.raw(PACKET / 'relocated-inputs.json')), 'exact relocated seven-file positive')
            need(bounded.proof_positive(rc, stdout, stderr, prior.VERIFIER,
                 dict(d.EXPECTED_WITHOUT_COUNT, verified=54), {str(root / p) for p in check.FILES})
                 and row['classification'] == {'verified': 54, 'errors': 0, 'whole_crate': True, 'stderr_empty': True},
                 'actual unfiltered 54/0 positive and empty stderr')
        else:
            name = row['name'][3:]
            body, focus = mutations[name]
            root = PACKET / (name + '-source')
            argv, timeout = cap.command(opened['commands']['positive'], root, check.PROOF, focus), 130
            inventory = dict(candidate['proof_closure'], **{str(check.BODY): hashlib.sha256(body.encode()).hexdigest()})
            need(cap.tree(h, root) == inventory and json.loads(h.raw(PACKET / (name + '-mutation.json'))) == {
                'root': str(root), 'inputs': inventory, **opened['cases'][name]}, 'exact source-bound one-body mutant')
            need(bounded.logical_negative(check.selection_notes(types.SimpleNamespace(LOGICAL_ERRORS=set()), focus),
                 rc, stdout, stderr, prior.VERIFIER, {str(root / p) for p in check.FILES}), 'same strict bounded real logical-negative predicate')
            need(row['classification'] == result['negatives'][name] == {'selector': focus, 'verified': 0,
                'errors': 1, 'logical_negative': True, 'actual_body_sha256': inventory[str(check.BODY)]}, 'exact selected result/body classification')
            family_counts[focus] = family_counts.get(focus, 0) + 1
        need(recorded['argv'] == argv and recorded['timeout_seconds'] == timeout, 'exact planned unmodified argv and timeout')
        c.receipt(record, argv, rc, stdout, stderr, h.raw(folder / 'owned/stdout.log'), h.raw(folder / 'owned/stderr.log'))
        groups.append(record['process_group'])
        audit.append({'name': row['name'], 'status': rc, 'group': record['process_group'],
                      **{name: h.sha(folder / name) for name in ('command.json', 'result.json', 'owned/record.json', 'owned/stdout.log', 'owned/stderr.log')}})
    need(closure['recorded_groups'] == groups and len(set(groups)) == 38
         and closure['all_recorded_groups_absent'] is True and closure['members'] == closure['uncertain'] == []
         and closure['host_wide_absence_claimed'] is False, '38 distinct attributed closed owned groups, no historical/host-wide probe')
    need(not OUTPUT.exists(), 'fresh independent read-only audit output')
    h.save(OUTPUT, {'signed_commit': a.SIGNED_COMMIT, 'stages': audit, 'full_proofs': 3, 'verified_each': 54,
        'logical_negatives': 31, 'families': family_counts, 'fresh_groups_closed': groups,
        'packet_pins': {name: h.sha(PACKET / name) for name in ('inputs.json', 'closing-inputs.json', 'results.json',
            'fresh-process-closure.json', 'raw-archive-index.json')}, 'source_inputs': len(source),
        'cpu_reused_not_executed': True, 'self_contained_evidence': False, 'historical_pid_probes': False,
        'static_reused_not_executed': True, 'prior_signed_attempt_accepted': False,
        'new_solver_or_test_commands_executed': False,
        'metadata_commands': 'read-only Git object/status/diff/whitespace inspection', 'scope': opened['scope']})
    print(json.dumps({'audit_sha256': h.sha(OUTPUT), 'full_proofs': 3, 'verified_each': 54,
                      'logical_negatives': 31, 'closed_owned_groups': len(groups), 'families': family_counts}))


if __name__ == '__main__':
    main()
