#!/usr/bin/env python3
"""Read back exact primitive integration and narrowly reviewed guard refreshes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SOURCE = Path('/home/harsh/.codex-tmp/fe2o3-distributed-codec-primitives-20260930-argument')
RECORDS = Path('/home/harsh/.codex-tmp/fe2o3-distributed-codec-primitives-records-20260930-cursor')
OUTPUT = Path('/home/harsh/.codex-tmp/fe2o3-codec-integration-audit-20261001.json')
PREVIOUS = 'a26dbebb57f948439a2e813c7a17c1142014ba1e'
HEAD = '8fd3b7ddb66d47578020ee6fcdf1b54f7916733f'
SIGNED = 'e02b7229ab6b85c2c1697d239d6f82e96ff04d45'
OLD = '38d8499e6aed5d061932bbc3fae3b7fdc5d7d6afa1e9170e6d2b46c1bbe7a77a'
NEW = 'e49f3ace340708e3dc33d72d73efc308062cf50c881c8ead2fde2a71ef0717f3'
V = Path('crates/fe2o3-runtime-model/verus')
SRC = Path('crates/fe2o3-runtime-model/src')

def need(value, message):
    if not value:
        raise ValueError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', *args], cwd=ROOT)

def raw(path):
    need(path.resolve() == path and path.is_file() and not path.is_symlink(), 'ordinary canonical file')
    return path.read_bytes()

need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize, 'python -I -B required')
need(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'exact cherry-picked integration HEAD')
impact_raw = raw(RECORDS / 'integration-guard-audit-1.json')
need(digest(impact_raw) == 'f5e053721692790b408f2baa71733780dee2b6f2db94d5d1c7043ccd6166b2fb', 'original impact audit')
impact = json.loads(impact_raw)
integrated = [Path(p) for p in git('diff', '--name-only', PREVIOUS, HEAD).decode().splitlines()]
need(len(integrated) == 9, 'exact nine original primitive paths')
for path in integrated:
    need(git('show', HEAD + ':' + str(path)) == git('show', SIGNED + ':' + str(path)) == raw(SOURCE / path),
         'byte-exact signed primitive integration: ' + str(path))
leaves = {str(p.relative_to(ROOT)): digest(raw(p)) for p in (ROOT / SRC).rglob('*.rs')}
need(len(leaves) == 302 and digest(json.dumps(leaves, sort_keys=True, separators=(',', ':')).encode()) == NEW,
     'exact new 302-file model implementation')
guards = {}
bridge = V / 'check-distributed-publication-contract.py'
old_bridge = digest(git('show', PREVIOUS + ':' + str(bridge)))
new_bridge = digest(raw(ROOT / bridge))
for path_text, record in impact['guards'].items():
    path = Path(path_text)
    old = git('show', PREVIOUS + ':' + str(path))
    need(digest(old) == record['checker_sha256'], 'unchanged previous checker')
    expected = old.replace(OLD.encode(), NEW.encode()).replace(b'SOURCE_FILES = 299', b'SOURCE_FILES = 302')
    if path.name == 'check-distributed-publication-construction.py':
        expected = expected.replace(old_bridge.encode(), new_bridge.encode())
    need(raw(ROOT / path) == expected, 'only reviewed source-count/tree/helper pins changed')
    for closure_path, pin in record['closure'].items():
        need(digest(raw(ROOT / closure_path)) == pin == digest(git('show', PREVIOUS + ':' + closure_path)),
             'unchanged actual executable proof closure')
    module = types.ModuleType('root_guard_' + path.stem.replace('-', '_'))
    module.__file__ = str(ROOT / path)
    exec(compile(expected, module.__file__, 'exec'), module.__dict__)
    module.audit(module.snapshot())
    guards[path_text] = {'old_sha256': digest(old), 'new_sha256': digest(expected),
                         'unchanged_proof_closure': record['closure'], 'source_audit_passed': True}
primitive = V / 'check-distributed-codec-primitives.py'
old = git('show', SIGNED + ':' + str(primitive))
need(raw(ROOT / primitive) == old.replace(old_bridge.encode(), new_bridge.encode()), 'primitive helper pin only')
workflow = Path('.github/workflows/runtime-component-source-guards.yml')
old_workflow = git('show', PREVIOUS + ':' + str(workflow))
anchor = b'          python3 -I -B crates/fe2o3-runtime-model/verus/test-distributed-publication-construction.py\n'
addition = b'          python3 -I -B crates/fe2o3-runtime-model/verus/test-distributed-codec-primitives.py\n'
need(old_workflow.count(anchor) == 1 and raw(ROOT / workflow) == old_workflow.replace(anchor, anchor + addition),
     'exact one CI source-control addition')
expected_dirty = set(guards) | {str(primitive), str(workflow)}
need(set(git('diff', '--name-only').decode().splitlines()) == expected_dirty, 'no unrelated tracked edits')
result = {'head': HEAD, 'signed_candidate': SIGNED, 'source_files': len(leaves), 'source_tree_sha256': NEW,
          'integrated_paths': {str(p): digest(git('show', HEAD + ':' + str(p))) for p in integrated},
          'guards': guards, 'primitive_checker_sha256': digest(raw(ROOT / primitive)),
          'workflow_sha256': digest(raw(ROOT / workflow)),
          'scope': 'Source integration readback only. No new solver, CPU test, GPU or performance acceptance.'}
with OUTPUT.open('x') as stream:
    stream.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'audit_sha256': digest(raw(OUTPUT)), 'integrated_paths': len(integrated), 'guards': len(guards)}))
