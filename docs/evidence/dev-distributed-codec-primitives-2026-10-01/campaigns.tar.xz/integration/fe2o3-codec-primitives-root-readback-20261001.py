#!/usr/bin/env python3
"""Replay the reviewed primitive audit without executing tests or solvers."""
import hashlib
import json
from pathlib import Path
import sys
import types

BASE = Path('/home/harsh/.codex-tmp/fe2o3-distributed-codec-primitives-records-20260930-cursor')
AUDITOR = BASE / 'audit_signed_primitive_attempt3.py'
OUTPUT = Path('/home/harsh/.codex-tmp/fe2o3-codec-primitives-root-readback-20261001.json')

if not (sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize):
    raise ValueError('python3 -I -B required')
raw = AUDITOR.read_bytes()
if hashlib.sha256(raw).hexdigest() != 'daf258a53ea8cb499537ca91bba40fd2f096f6f786dfde38c8cc5991086d2122':
    raise ValueError('reviewed auditor changed')
old = (BASE / 'signed-primitive-post-audit-3.json').read_bytes()
if hashlib.sha256(old).hexdigest() != 'ba066fac656b875ef7138db35b8832f655dd755e03e2f4eafdca545dc6b46e31':
    raise ValueError('agent audit changed')
module = types.ModuleType('root_primitive_readback')
module.__file__ = str(AUDITOR)
sys.modules[module.__name__] = module
exec(compile(raw, str(AUDITOR), 'exec'), module.__dict__)
module.OUTPUT = OUTPUT
module.main()
if json.loads(OUTPUT.read_bytes()) != json.loads(old):
    raise ValueError('root replay disagrees with agent readback')
print('Root replay agrees with all 38 stages and all 31 logical negatives.')
