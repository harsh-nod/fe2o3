#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <unistd.h>
#include <linux/kfd_ioctl.h>
#include <amdgpu_drm.h>
#include <drm.h>

static void fail(const char *operation) {
    perror(operation);
    exit(EXIT_FAILURE);
}

static void info(int fd, uint32_t query, void *result, uint32_t size) {
    struct drm_amdgpu_info request = {0};
    request.return_pointer = (uint64_t)(uintptr_t)result;
    request.return_size = size;
    request.query = query;
    if (ioctl(fd, DRM_IOCTL_AMDGPU_INFO, &request) != 0)
        fail("AMDGPU_INFO");
}

int main(int argc, char **argv) {
    if (argc < 2 || argc > 9) return EXIT_FAILURE;
    int kfd = open("/dev/kfd", O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (kfd < 0) fail("open kfd");
    struct stat status;
    if (fstat(kfd, &status) != 0) fail("fstat kfd");
    if (!S_ISCHR(status.st_mode)) return EXIT_FAILURE;
    struct kfd_ioctl_get_version_args version = {0};
    if (ioctl(kfd, AMDKFD_IOC_GET_VERSION, &version) != 0)
        fail("KFD_GET_VERSION");
    if (close(kfd) != 0) fail("close kfd");
    printf("{\"kind\":\"kfd-version\",\"major\":%u,\"minor\":%u}\n",
           version.major_version, version.minor_version);

    for (int i = 1; i < argc; ++i) {
        char *end;
        errno = 0;
        unsigned long render_minor = strtoul(argv[i], &end, 10);
        if (errno || !*argv[i] || *end || render_minor < 128 || render_minor > 255)
            return EXIT_FAILURE;
        char path[64];
        int count = snprintf(path, sizeof(path), "/dev/dri/renderD%lu", render_minor);
        if (count < 0 || (size_t)count >= sizeof(path)) return EXIT_FAILURE;
        int fd = open(path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
        if (fd < 0) fail("open render");
        if (fstat(fd, &status) != 0) fail("fstat render");
        if (!S_ISCHR(status.st_mode) || major(status.st_rdev) != 226 ||
            minor(status.st_rdev) != render_minor) return EXIT_FAILURE;
        char name[32] = {0};
        struct drm_version drm_version = {0};
        drm_version.name = name;
        drm_version.name_len = sizeof(name) - 1;
        if (ioctl(fd, DRM_IOCTL_VERSION, &drm_version) != 0)
            fail("DRM_VERSION");
        if (drm_version.name_len != 6 || memcmp(name, "amdgpu", 6) != 0)
            return EXIT_FAILURE;
        uint32_t acceleration = 0;
        struct drm_amdgpu_info_device device = {0};
        info(fd, AMDGPU_INFO_ACCEL_WORKING, &acceleration, sizeof(acceleration));
        info(fd, AMDGPU_INFO_DEV_INFO, &device, sizeof(device));
        if (close(fd) != 0) fail("close render");
        printf("{\"kind\":\"drm-device\",\"render_minor\":%lu,"
               "\"driver\":\"amdgpu\",\"major\":%d,\"minor\":%d,\"patch\":%d,"
               "\"acceleration\":%u,\"device_id\":%u,\"chip_rev\":%u,"
               "\"external_rev\":%u,\"pci_rev\":%u,\"family\":%u,"
               "\"info_bytes\":%zu}\n",
               render_minor, drm_version.version_major, drm_version.version_minor,
               drm_version.version_patchlevel, acceleration, device.device_id,
               device.chip_rev, device.external_rev, device.pci_rev,
               device.family, sizeof(device));
    }
    return ferror(stdout) ? EXIT_FAILURE : EXIT_SUCCESS;
}
