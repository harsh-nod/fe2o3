import hashlib
import importlib.util
from pathlib import Path
import re
import subprocess

repo = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
directory = repo / 'crates/fe2o3-runtime-model/verus'
spec = importlib.util.spec_from_file_location('audit', directory / 'check-negative-quality.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
runner = audit.read_runner(directory / 'verify-verus.sh')
roots = {'script_dir': directory, 'repo_root': repo, 'pin_dir': directory / 'pins'}
paths = {name: roots[root] / suffix for name, root, suffix in re.findall(
    r'^([A-Za-z_][A-Za-z0-9_]*)="\$(script_dir|repo_root|pin_dir)/([^"\n]+)"$', runner, re.M)}
pins = {name: directory / 'pins' / pin for name, pin in re.findall(
    r'^([A-Za-z_][A-Za-z0-9_]*)=\$\(read_pin "\$pin_dir/([A-Z0-9_]+)"\)$', runner, re.M)}
checks = re.findall(r'^    check_digest "\$(\w+)" "\$(\w+)"$',
    audit.runner_function_source(runner, 'check_sources'), re.M)
checked = 0
mismatched = 0
for expected_name, source_name in checks:
    assert expected_name in pins, expected_name
    assert source_name in paths, source_name
    source = paths[source_name]
    pin = pins[expected_name]
    expected = pin.read_text().strip()
    actual = hashlib.sha256(source.read_bytes()).hexdigest()
    checked += 1
    if expected == actual:
        continue
    mismatched += 1
    source_relative = str(source.relative_to(repo))
    pin_relative = str(pin.relative_to(repo))
    head_source = subprocess.check_output(['git', 'show', 'HEAD:' + source_relative], cwd=repo)
    head_pin = subprocess.check_output(['git', 'show', 'HEAD:' + pin_relative], cwd=repo)
    print(f'MISMATCH {source_relative}\n expected={expected}\n actual={actual}\n '
        f'source_matches_HEAD={source.read_bytes() == head_source}\n '
        f'pin_matches_HEAD={pin.read_bytes() == head_pin}', flush=True)
print(f'SOURCE_PIN_AUDIT checked={checked} mismatches={mismatched}', flush=True)
