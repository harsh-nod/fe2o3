#!/bin/bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
timeout --kill-after=10s 120s /mnt/c/Windows/System32/wsl.exe --user root --exec /usr/bin/bwrap \
  --unshare-pid --unshare-net --unshare-ipc --unshare-uts --die-with-parent \
  --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
  --ro-bind "$repo/target/debug/deps/fe2o3_compiler_execution_client-266c06c04643c3c6" /tmp/client-test \
  --chdir /tmp /tmp/client-test root_ --ignored --nocapture --test-threads=1
