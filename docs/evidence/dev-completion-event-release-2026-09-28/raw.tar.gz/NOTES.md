# Event Release Qualification Notes

Source: f70bd5af95e37cc7850975bd8c30c83a11d5ff69.
Repository: /home/harsh/.codex-tmp/fe2o3-r61-execution.
Branch: codex/r65-runtime-drain-versions.

All commands below returned status 0 unless explicitly labeled development failures.
Cargo commands used CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 and nightly-2026-04-03.
Test commands used prlimit --core=0:0. No remote commands or GPU jobs were run.

- kfd-full.log: cargo test -p fe2o3-kfd --all-features --lib; 1726 passed,
  zero failures/ignores, 1241.75 seconds test time.
- runtime-full.log: cargo test -p fe2o3-runtime --all-features --lib; 1828 passed,
  zero failures, 30 existing hardware ignores, 92.36 seconds test time.
- doctests.log: cargo test -p fe2o3-kfd -p fe2o3-runtime --all-features --doc;
  42 + 9 + 44 passed.
- clippy.log: cargo clippy -p fe2o3-kfd -p fe2o3-runtime --all-features
  --all-targets -- -D warnings.
- production-check.log: cargo check -p fe2o3-kfd -p fe2o3-runtime --no-default-features.
- fmt.log: cargo fmt --all --check.
- included-tests-fmt.log: rustfmt --edition 2024 --check
  crates/fe2o3-kfd/src/queue_completion/event_release_tests.rs.
- diff-check.log: git diff --check before source commit.
- calibration.log: python3 -I -B
  crates/fe2o3-runtime-model/verus/test-completion-event-release.py;
  four synthetic/wiring calibration groups, executed after source commit.
- campaign.log: python3 -I -B
  crates/fe2o3-runtime-model/verus/check-completion-event-release.py
  --output /home/harsh/.codex-tmp/fe2o3-event-release-dev-20260928-sfy4tTE0/campaign
  --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus.
  All 23 inherited owned stages pass. The new calibration runs before the
  inherited source bracket, and is separately captured in calibration.log;
  it is not an additional owned stage in campaign/results.json.

CPU commands are ordinary shell invocations, not the proof controller's owned
stages. Source hashes were captured during the full KFD execution, after all
edits/formatting, then checked before signing and again after qualification.
The two tested ELF hashes are retained, not the ELFs. This is not a hermetic build
or an authenticated compiler/ELF-to-machine-code refinement claim.

Development artifacts retained:
- proof-1: status 1, frontend missing Debug requirement from debug_assert_eq.
- proof-2: status 1, Verus unsupported guarded or-pattern.
- proof-3: status 0, 15 verified before the explicit constructed witness.
- proof-4: status 0, 16 verified including the witness.
  These were bounded 120-second development invocations with --no-cheating,
  --output-json, --error-format=json, --num-threads 4, --multiple-errors 0,
  --triggers-mode silent and --no-report-long-running. The signed campaign,
  not these preliminary invocations, supplies final solver qualification.
- cpu-1.log: preliminary focused run passed four tests (three new release tests
  plus an unrelated doorbell release test). Its initial compilation overlapped
  the formatter and it predates the fourth release test; it is not the final
  source qualification. Final full suites ran after all formatting/edits finished.

Three read-only native agents reviewed the proof boundary, executable mutations,
source correspondence and hostile CPU cases. Primary owned all edits, integration,
builds, solvers, test runs and publication. No Qwen worker was invoked.

Next production proof: batch recording, native no-effect ledger frame, batch
event release and bound cancellation. The actual source rollback creates one
event per distinct slot. Generic aliasing batch release additionally depends on
pin cardinality or an aggregate preflight; this packet proves neither.
