# Next Multi-GPU Increment

Read-only swarm triage, not implemented or qualified by this packet.

1. Add a default-feature fixed-total-byte sharded peer-copy witness over an
   explicit freshly admitted 2..8 UID roster. Balanced contiguous ranges of a
   global 64 MiB + 37 payload, with absolute-offset bytes, distinguish true
   partitioning from identical replicated work. Each device sends one exact-size
   shard to the next device. Enqueue all N copies through the existing current-
   thread owned async engine before driving futures, verify every range and
   exactly N native completions, release results and explicitly shut down.
   Start with a private partition helper, not a new orchestration API.
2. Exercise 2/3/5/8-device group behavior, neighbors sharing a reserved child,
   disjoint routes, expired/resumed observation, dropped futures, failed and
   cancelled shards, and global success requiring every shard's checked output.
   Freshly admitted means every safely selected GPU, never automatically all
   physical GPUs. Current strict constructor admits all directed routes.
3. Keep outstanding group-drain qualification separate: begin_drain closes
   enqueue admission. Existing single-range HostVisible capture is not forwarded
   by the multi-device backend, and does not support multiple shard captures.
   Do not read from raw Context after owner cutoff or pretend DeviceLocal capture.
4. True compute sharding needs a new finite qualification policy. Reuse vecadd
   machine code/ABI but pin a fixed global set of eight distinct 4 MiB tiles,
   assign tiles across the selected roster with exactly-once global coverage,
   and retain the existing geometry and old authorities unchanged. Existing
   vecadd/R57 fixtures pin identical input digests and are replication only.

No physical overlap, native partial-failure recovery, HIP/HSA scaling or performance
claim follows from copy sharding alone. The current occupied-child reservation
can serialize neighboring routes and is part of the measured next-stage scope.
