# Working Multi-GPU: Production Opt-In and Result Reuse

Base: 7256bcfafc54cd5997507773debf94c4677b2682.
Previous goal turn: progress, with signed dual-remote publication and accepted
CPU, arithmetic and five-mode MI300X correctness evidence.

This turn prioritizes A3 without shrinking the overall HIP/HSA parity goal:

- Constructor owner: additive native peer opt-in for existing production and
  semantic authorities, fresh admission only, unchanged private defaults,
  complete route admission and preserved allocation/pool/launch policies.
- Result owner: successful exact deferred-consumer output reuse, with independent
  global result custody until the next consumer settles. Directed ancestry and
  pending downstream chains remain separate contracts.
- Witness owner: actual 65-packet ring reuse and repeated changed payloads with
  full byte checks, final-only logical counters and explicit cleanup. No broader
  kernel authority, physical overlap or performance claim.
- Primary: integration, serialized Cargo, source-control audits, hardware
  admission/execution/cleanup, evidence, signed publication to both remotes.

No source receipt is accepted before source freeze. All rejected attempts are
retained. The KFD implementation and existing arithmetic proof are unchanged
unless explicitly recorded otherwise; retained evidence is reused only within
its exact unchanged-source scope. This does not prove new runtime integration.
The original Context completion-refinement gap remains open.

Do not edit, stage or remove docs/evidence/dev-owner-inspection-2026-09-23.
No permission questions or external-model workers are needed. Agents do not
run Cargo, SSH, Git writers or source-guard metadata updates. Primary-session
network access is required; worker namespace DNS failures do not diagnose the
remote host. Shared MI300X occupancy must be freshly checked before each run.
