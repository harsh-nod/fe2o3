# Review Scope

Primary owns integration, compilation, source-guard refresh, native execution,
packaging and publication. Native agents reviewed independent areas; no Qwen
worker was requested or invoked. Agents did not run concurrent Cargo or SSH work.

- Constructor policy: complete roster/device/route admission precedes PUBLIC
  enablement; private defaults and supplied kernel/semantic authorities remain.
- Completed results: exact receipt authentication, depth/preflight bounds and
  separate result custody were cross-reviewed. CPU fixtures start at an admitted
  child handoff. Write-to-Read checks journal metadata, not GPU-produced bytes.
- Ring witness: actual 65-packet per-copy plan through the single 64-slot queue;
  repeated changed bytes, full byte comparison and exact logical copy counts.
  Queue telemetry and cross-copy queue caching are not claimed.
- Production witness: default-feature copy-only constructors with deny-all
  production/semantic authorities, native/staged controls and explicit cleanup.
- Source metadata: final proposal-04 AST reconstruction found exactly 11 changed guard
  files, 18 SHA literals and 7 roster counts; all 1,025 source hashes and 76 proof
  files match the proposal. No predicate, proof count or mutant count changed.
- Hardware controller: read-only parser tests covered archived outputs, malformed
  and duplicate PASS fields, all seven expected schemas and admission mutations.
  Review caught cleanup authority assignment before path validation and hash-error
  cleanup skipping; primary corrected both before any upload. Timeout cleanup
  catches the process-exit race without losing terminal receipts.

The first two compiler attempts are retained as failures: non-Debug test unwraps,
then a forget_non_drop lint. Attempt 03 compiled but its new authentication test
aborted because the fixture assumed a clean launch remained pending after eager
preparation. Exact uncaptured diagnostics and the failed fixture source are
retained. The correction reads the actual retained pending/active recipe and
uses the existing scripted unpublished retry for cancellation/publication-fault
cases. Early ManuallyDrop preserves fixture-failure diagnostics; no native DATA
cache cleanup is claimed when discarding descriptor-only scripted metadata.
Independent cross-review confirmed these boundaries against the actual eager
preparation and retry implementation. These corrections changed tests only.

No whole-adapter formal verification, pending downstream chaining, overlap,
performance or full parity claim follows from these reviews.

The first hardware campaign and two owned diagnostics are rejected, preserved
under hardware-primary, and explicitly cleaned. The production copy-only path
exposed a real cold-session admission bug: the shared auxiliary predicate rejects
a primary with neither an attached nor a detached dispatch. The narrow fix keeps
that shared predicate unchanged and adds a primary-only initial-state branch:
Ready AQL owner, zero write/read history, releasable completion, clear unpublished
state, empty detach ledgers and initial persistent generation. No warm-up kernel
or forged detached receipt is used. Seven new KFD tests include actual constructed
owners, publication/fault history and 2,304 fact combinations.

The new shared-executable cold-predicate proof accepted all 14 stages in
cold-proof-attempt-01. An independent agent rechecked raw receipts, all 11 source
hashes, two contracts in each positive, nine exact logical negative mutations,
six controller controls and the complete 190-file pinned Verus closure. This
proves only the Boolean admission predicate and preservation of established
acceptance; source binding is not proof of native observer authenticity.

Attempt-04's remaining test failure was also confined to a scripted fixture:
flush does not republish an already prepared launch. The corrected test drives
the actual typed poll path, where retry publication and the armed fault occur.
Attempt-05 passed all focused runtime filters before the cold KFD change.

Hardware-final-01 passed all four production/semantic native/staged controls,
then rejected queued-ring during the large upload. Its helper assumed one
directional window, but 65 packets need 63+2 windows; completion of the first
window correctly returns Pending with custody retained. The example now drives
explicit flush/poll steps until success under one absolute deadline, rejects
non-Pending/non-Succeeded statuses with their actual diagnostic, and tests the
two-window boundary. No runtime completion semantics were changed. Exact owned
files were removed and GPU6/7/process baselines restored for the rejected run.

Build attempt-07 compiled and listed both CPU binaries, but its outer controller
rejected with exit125 because the example edit occurred between source snapshots.
Only that example hash differs. Attempt-08 reselects the unchanged library test
ELFs under the final immutable source manifest; no rejected outer run is counted
as final qualification. Final checks and the exact32 workflow are rerun too.

Independent final review checked all 46 hardware-final-02 capture receipts
against raw stdout/stderr hashes: seven selected cases passed, both executable
hashes matched before/after, owned process census was empty, exact removals passed,
and GPU6/7 memory plus the full process roster returned to baseline. The example
continuation loop retains one absolute deadline, never retries Failed, and its
readback totals count complete buffer verifications rather than chunk calls.
Two stale guide labels were corrected: the native counter is default-feature,
and only ring-reuse copies are described as 65-packet transfers.
