#!/bin/bash
set -u
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
artifact=/home/harsh/.codex-tmp/fe2o3-multigpu-production-peers-20261002
mode=${1:?mode required}
attempt=${2:?fresh attempt label required}
out="$artifact/$attempt/$mode"
mkdir -p "$out" || exit 125
test ! -e "$out/environment.txt" || exit 125
if [ "$0" != "$out/controller.sh" ]; then
    test ! -e "$out/controller.sh" || exit 125
    cp -- "$0" "$out/controller.sh" || exit 125
    exec bash "$out/controller.sh" "$@"
fi
cd "$root" || exit 125
export HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8
export CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1
ulimit -c 0
env | sort > "$out/environment.txt"
printf '%s\n' "$PWD" > "$out/cwd.txt"
git rev-parse HEAD > "$out/base.txt"
failed=0
stage() {
    name=$1
    seconds=$2
    shift 2
    printf '%q ' "$@" > "$out/$name.command"
    printf '\n' >> "$out/$name.command"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$out/$name.started"
    timeout --signal=TERM --kill-after=30s "$seconds" "$@" > "$out/$name.stdout" 2> "$out/$name.stderr"
    status=$?
    printf '%s\n' "$status" > "$out/$name.exit"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$out/$name.finished"
    printf '%s exit=%s\n' "$name" "$status"
    if [ "$status" -ne 0 ]; then failed=1; fi
}
case "$mode" in
    diagnostic)
        selected=${3:?selected build attempt required}
        executable=$(< "$artifact/$selected/build/fe2o3_runtime.path")
        sha256sum -c "$artifact/$selected/build/fe2o3_runtime.sha256" || exit 125
        stage authentication 60s prlimit --core=0 -- "$executable" --exact kfd_backend::deferred_compute::tests::completed_results::completed_deferred_result_authentication_rejects_pending_failed_and_wrong_child --test-threads=1 --nocapture
        ;;
    precheck)
        stage clippy 1200s cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --tests --example gfx942-runtime-compute-xgmi-smoke --example gfx942-runtime-peer-copy-smoke --no-deps -- -D warnings
        ;;
    build)
        stage runtime 2400s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --no-run --message-format=json
        if [ "$failed" -eq 0 ]; then
            for target in fe2o3_kfd fe2o3_runtime; do
                python3 -I -B -c 'import json,sys
rows=[json.loads(line) for line in open(sys.argv[1])]
paths={row["executable"] for row in rows if row.get("reason")=="compiler-artifact" and row.get("target",{}).get("name")==sys.argv[2] and row.get("profile",{}).get("test") and row.get("executable")}
assert len(paths)==1, paths
print(paths.pop())' "$out/runtime.stdout" "$target" > "$out/$target.path" || exit 125
                executable=$(< "$out/$target.path")
                sha256sum "$executable" > "$out/$target.sha256"
            done
        fi
        ;;
    focused)
        selected=${3:?selected build attempt required}
        executable=$(< "$artifact/$selected/build/fe2o3_runtime.path")
        sha256sum -c "$artifact/$selected/build/fe2o3_runtime.sha256" || exit 125
        for filter in compute_xgmi packetized deferred_compute producer_peers multi_open; do
            stage "$filter-list" 60s "$executable" "$filter" --list --test-threads=1
            grep -Eq '^[1-9][0-9]* tests?, 0 benchmarks$' "$out/$filter-list.stdout" || exit 125
            stage "$filter" 600s "$executable" "$filter" --test-threads=1
        done
        sha256sum -c "$artifact/$selected/build/fe2o3_runtime.sha256" || exit 125
        ;;
    tests)
        selected=${3:?selected build attempt required}
        for target in fe2o3_runtime; do
            executable=$(< "$artifact/$selected/build/$target.path")
            sha256sum -c "$artifact/$selected/build/$target.sha256" || exit 125
            sha256sum "$executable" > "$out/$target-before.sha256"
            stage "$target-compute_xgmi-list" 60s "$executable" compute_xgmi --list --test-threads=1
            grep -Eq '^[1-9][0-9]* tests?, 0 benchmarks$' "$out/$target-compute_xgmi-list.stdout" || exit 125
            stage "$target-compute_xgmi" 600s "$executable" compute_xgmi --test-threads=1
            stage "$target-packetized-list" 60s "$executable" packetized --list --test-threads=1
            grep -Eq '^[1-9][0-9]* tests?, 0 benchmarks$' "$out/$target-packetized-list.stdout" || exit 125
            stage "$target-packetized" 600s "$executable" packetized --test-threads=1
            stage "$target-full-list" 60s "$executable" --list --test-threads=1
            stage "$target-full" 1200s "$executable" --test-threads=1
            sha256sum "$executable" > "$out/$target-after.sha256"
            cmp "$out/$target-before.sha256" "$out/$target-after.sha256" || exit 125
        done
        ;;
    checks)
        stage rustc 60s rustc +nightly-2026-04-03 --version --verbose
        stage cargo 60s cargo +nightly-2026-04-03 --version
        stage uname 60s uname -a
        stage clippy 1200s cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --tests --example gfx942-runtime-compute-xgmi-smoke --example gfx942-runtime-peer-copy-smoke --no-deps -- -D warnings
        stage no-default 300s cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-runtime --no-default-features --lib --example gfx942-runtime-peer-copy-smoke
        stage example 1200s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --all-features --example gfx942-runtime-compute-xgmi-smoke -- --test-threads=1
        stage production-example 1200s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --no-default-features --example gfx942-runtime-peer-copy-smoke -- --test-threads=1
        stage witness-build 1200s cargo +nightly-2026-04-03 build --locked --offline -p fe2o3-runtime --all-features --profile test --example gfx942-runtime-compute-xgmi-smoke
        sha256sum target/debug/examples/gfx942-runtime-compute-xgmi-smoke > "$out/witness.sha256"
        stage production-witness-build 1200s cargo +nightly-2026-04-03 build --locked --offline -p fe2o3-runtime --no-default-features --profile test --example gfx942-runtime-peer-copy-smoke
        sha256sum target/debug/examples/gfx942-runtime-peer-copy-smoke > "$out/production-witness.sha256"
        mapfile -t changed < <({ git diff HEAD --name-only -- 'crates/fe2o3-kfd/**/*.rs' 'crates/fe2o3-runtime/**/*.rs'; git ls-files --others --exclude-standard -- 'crates/fe2o3-kfd/**/*.rs' 'crates/fe2o3-runtime/**/*.rs'; } | sort -u)
        stage formatting 120s rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true "${changed[@]}"
        stage whitespace 60s git diff HEAD --check
        ;;
    *) exit 125 ;;
esac
printf '%s\n' "$failed" > "$out/overall.exit"
exit "$failed"
