#!/usr/bin/env python3
"""Audit terminal CPU/hardware records and explicitly scoped historical reuse."""
from datetime import datetime, timezone
import argparse
import ast
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
PREVIOUS = ROOT.parent / 'fe2o3-multigpu-packetized-20261002'
PROOF = PREVIOUS / 'arithmetic-proof/proof-attempt-05'
BASE = '7256bcfafc54cd5997507773debf94c4677b2682'
CONTROLLER_SHA = '133627d469198f973e4a3f3b84a37842c003b9e5724ad5581e6dfbe590772377'
SHARD_CONTROLLER_SHA = 'c28b801126020a9aadd8a521c3dbd11514775da8ad0ed346e00b92e0347e45e3'
COLD_CHECKER_SHA = 'bd6b966bd5fa7186daacf0f7e15fece28beee951ca98b9169efa1550cdf4e9c8'
ARCHIVE_SHA = '4b3aa78e5f53bf8e9d7d7cb436397bd45c23ff53246197eba395469faf865148'
WORKFLOW_SHA = '33c8eb8b3bac347669f15e36aadbc736062a635812a95b908dbaba43ef5fae08'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('build_attempt')
parser.add_argument('checks_attempt')
parser.add_argument('source_attempt')
parser.add_argument('hardware_folder')
parser.add_argument('--proposal', default='proposal-04')
parser.add_argument('--reuse-kfd', action='store_true')
parser.add_argument('--kfd-shards', help='Fresh five-shard directory, relative to this raw packet')
args = parser.parse_args()
attempt, source_attempt = args.build_attempt, args.source_attempt
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert re.fullmatch(r'attempt-[0-9]+', attempt)
assert re.fullmatch(r'attempt-[0-9]+', args.checks_attempt)
assert re.fullmatch(r'attempt-[0-9]+-after', source_attempt)
assert re.fullmatch(r'hardware-[a-z0-9-]+', args.hardware_folder)
assert re.fullmatch(r'proposal-[0-9]+', args.proposal)
ATTEMPT = ROOT / attempt
CHECKS = ROOT / args.checks_attempt / 'checks'
HARDWARE = ROOT / args.hardware_folder


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def roster(path):
    names = sorted(line.removesuffix(': test') for line in path.read_text().splitlines()
                   if line.endswith(': test'))
    assert names and len(names) == len(set(names))
    return names


def test_result(path, passed, ignored=0, filtered=0):
    output = path.read_text()
    summaries = [line for line in output.splitlines() if line.startswith('test result:')]
    assert len(summaries) == 1
    assert re.fullmatch(re.escape(f'test result: ok. {passed} passed; 0 failed; {ignored} ignored; 0 measured; {filtered} filtered out; finished in ') + r'[0-9.]+s', summaries[0])
    observed = []
    statuses = {'ok': 0, 'ignored': 0}
    for line in output.splitlines():
        match = re.fullmatch(r'test (\S+) \.\.\. (ok|ignored)(?:, .*)?', line)
        if match:
            observed.append(match.group(1))
            statuses[match.group(2)] += 1
    assert len(observed) == len(set(observed)) == passed + ignored
    assert statuses == {'ok': passed, 'ignored': ignored}
    return sorted(observed), summaries[0]


def manifest(path):
    records = {}
    for line in path.read_text().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        assert match, (path, line)
        digest, name = match.groups()
        assert name not in records and '..' not in Path(name).parts
        records[name] = digest
    assert records
    return records


def check_sources(records):
    for name, digest in records.items():
        path = REPO / name
        assert path.is_relative_to(REPO) and path.is_file() and not path.is_symlink()
        assert path.resolve() == path and sha(path) == digest, ('source mismatch', name)


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=REPO)


def stamp(value):
    parsed = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    assert parsed.tzinfo is not None
    return parsed


def stage_commands(mode, executable):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', '-p', 'fe2o3-runtime']
    compute, production = 'gfx942-runtime-compute-xgmi-smoke', 'gfx942-runtime-peer-copy-smoke'
    if mode == 'build':
        kfd = (ATTEMPT / 'build/fe2o3_kfd.path').read_text().strip()
        return {'runtime': (2400, cargo + ['test', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--no-run', '--message-format=json']), 'kfd-full-list': (60, [kfd, '--list', '--test-threads=1'])}
    if mode in ('focused', 'tests'):
        filters = ('compute_xgmi', 'packetized', 'deferred_compute', 'producer_peers', 'multi_open') if mode == 'focused' else ('compute_xgmi', 'packetized', 'full')
        stages = {}
        for selected in filters:
            name = selected if mode == 'focused' else 'fe2o3_runtime-' + selected
            argv = [executable] + ([] if selected == 'full' else [selected])
            stages[name + '-list'] = (60, argv + ['--list', '--test-threads=1'])
            stages[name] = (1200 if selected == 'full' else 600, argv + ['--test-threads=1'])
        return stages
    assert mode == 'checks'
    patterns = ('crates/fe2o3-kfd/**/*.rs', 'crates/fe2o3-runtime/**/*.rs')
    changed = sorted(set(git('diff', 'HEAD', '--name-only', '--', *patterns).decode().splitlines()) |
                     set(git('ls-files', '--others', '--exclude-standard', '--', *patterns).decode().splitlines()))
    assert changed
    return {
        'rustc': (60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose']),
        'cargo': (60, cargo + ['--version']),
        'uname': (60, ['uname', '-a']),
        'clippy': (1200, cargo + ['clippy', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--tests', '--example', compute, '--example', production, '--no-deps', '--', '-D', 'warnings']),
        'no-default': (300, cargo + ['check', *common, '--no-default-features', '--lib', '--example', production]),
        'example': (1200, cargo + ['test', *common, '--all-features', '--example', compute, '--', '--test-threads=1']),
        'production-example': (1200, cargo + ['test', *common, '--no-default-features', '--example', production, '--', '--test-threads=1']),
        'witness-build': (1200, cargo + ['build', *common, '--all-features', '--profile', 'test', '--example', compute]),
        'production-witness-build': (1200, cargo + ['build', *common, '--no-default-features', '--profile', 'test', '--example', production]),
        'formatting': (120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *changed]),
        'whitespace': (60, ['git', 'diff', 'HEAD', '--check']),
    }


def audit_stages(folder, mode, executable, sources):
    assert sha(folder / 'controller.sh') == CONTROLLER_SHA
    assert (folder / 'base.txt').read_text().strip() == BASE
    assert (folder / 'cwd.txt').read_text().strip() == str(REPO)
    env = dict(line.split('=', 1) for line in (folder / 'environment.txt').read_text().splitlines())
    expected = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', RUST_TEST_THREADS='1', PWD=str(REPO))
    assert all(env.get(key) == value for key, value in expected.items())
    assert set(env) <= set(expected) | {'OLDPWD', 'SHLVL', '_'}
    assert manifest(folder / 'source-before.sha256') == manifest(folder / 'source-after.sha256') == sources
    stages = stage_commands(mode, executable)
    assert {path.stem for path in folder.glob('*.exit')} == set(stages) | {'overall'}
    assert (folder / 'overall.exit').read_text().strip() == '0'
    prior = None
    for name, (seconds, argv) in stages.items():
        assert (folder / (name + '.exit')).read_text().strip() == '0'
        assert shlex.split((folder / (name + '.command')).read_text()) == argv
        assert (folder / (name + '.stdout')).is_file() and (folder / (name + '.stderr')).is_file()
        started = stamp((folder / (name + '.started')).read_text())
        finished = stamp((folder / (name + '.finished')).read_text())
        assert 0 <= (finished - started).total_seconds() <= seconds + 35
        assert prior is None or started >= prior
        prior = finished


def audit_metadata():
    folder = ROOT / 'source-ci' / args.proposal
    report = read_json(folder / 'metadata-report.json')
    assert report['baseline'] == BASE and report['proof_closures_unchanged']
    assert report['all_baseline_audits_passed'] and report['all_proposed_source_audits_passed']
    assert not report['solver_executed'] and not report['build_executed'] and not report['formal_qualification']
    counts, changed, patch = {'content-sha256': 0, 'source-inventory-count': 0}, 0, ['*** Begin Patch\n']
    for change in report['changes']:
        path = change['path']
        old = (folder / 'originals' / Path(path).name).read_text()
        assert hashlib.sha256(old.encode()).hexdigest() == change['original_sha256']
        assert git('show', BASE + ':' + path) == old.encode()
        tree = ast.parse(old)
        nodes = {(n.lineno, n.col_offset, n.end_lineno, n.end_col_offset): n for n in ast.walk(tree) if isinstance(n, ast.Constant)}
        offsets = [0]
        for line in old.splitlines(keepends=True):
            offsets.append(offsets[-1] + len(line))
        edits = []
        for edit in change['edits']:
            node = nodes[(edit['line'], edit['column'], edit['end_line'], edit['end_column'])]
            assert node.value == edit['old']
            category = edit['category']
            counts[category] += 1
            if category == 'content-sha256':
                assert all(isinstance(edit[key], str) and re.fullmatch('[0-9a-f]{64}', edit[key]) for key in ('old', 'new'))
                assert edit['selector'] in {'SOURCE_TREE_SHA', 'RUNTIME_SHA', 'NATIVE_TREE_SHA', 'SCHEMA_TREE_SHA', 'GUARD_SHA'} or re.fullmatch(r"(?:CHECKER_PINS|HELPERS)\['[a-z-]+\.py'\]", edit['selector'])
            else:
                assert category == 'source-inventory-count'
                assert edit['selector'] in {'SOURCE_FILES', 'RUNTIME_FILES', 'len(implementation) == literal', 'assertEqual(len(native), literal)', 'assertEqual(len(with_schemas), literal)'}
                assert type(edit['old']) is int and type(edit['new']) is int and edit['new'] > 0
            start, end = offsets[edit['line'] - 1] + edit['column'], offsets[edit['end_line'] - 1] + edit['end_column']
            assert ast.literal_eval(old[start:end]) == edit['old']
            edits.append((start, end, json.dumps(edit['new'])))
            node.value = edit['new']
        new = old
        for start, end, value in sorted(edits, reverse=True):
            new = new[:start] + value + new[end:]
        assert hashlib.sha256(new.encode()).hexdigest() == change['proposed_sha256']
        assert ast.dump(tree) == ast.dump(ast.parse(new))
        assert (REPO / path).read_bytes() == new.encode()
        if old != new:
            changed += 1
            patch.append('*** Update File: ' + str(REPO / path) + '\n')
            patch.extend(list(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True)))[2:])
    assert ''.join(patch) + '*** End Patch\n' == (folder / 'metadata.patch').read_text()
    assert changed == 11 and counts == {'content-sha256': 18, 'source-inventory-count': 7}
    assert len(report['audited_source_sha256']) == 1025
    assert len(report['proof_files']) == 76
    check_sources(report['audited_source_sha256'])
    check_sources(report['proof_files'])
    return report


def audit_guards(report):
    folder = ROOT / 'source-ci' / source_attempt
    result, inputs = read_json(folder / 'result.json'), read_json(folder / 'inputs.json')
    assert result['accepted'] and result['command_count'] == 32 and result['source_unchanged'] and not result['failed']
    assert not result['solver_invocations'] and not result['build_invocations'] and not result['gpu_invocations']
    assert inputs['head'] == BASE and inputs['workflow_sha256'] == WORKFLOW_SHA
    assert sha(REPO / '.github/workflows/runtime-component-source-guards.yml') == WORKFLOW_SHA
    reference_inputs = ROOT / 'source-ci/reference/inputs.json'
    assert sha(reference_inputs) == '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e'
    assert inputs['commands'] == read_json(reference_inputs)['commands']
    assert inputs['source_sha256'] == read_json(folder / 'closing-source.json')
    check_sources(inputs['source_sha256'])
    assert all(inputs['source_sha256'].get(path) == digest for path, digest in report['audited_source_sha256'].items())
    assert len(inputs['commands']) == len(result['commands']) == 32
    for index, (command, record) in enumerate(zip(inputs['commands'], result['commands']), 1):
        subfolder = folder / f'{index:02}'
        assert record == read_json(subfolder / 'receipt.json')
        assert [record['step'], record['literal'], record['argv']] == command
        assert record['argv'] == shlex.split(record['literal']) and record['cwd'] == str(REPO)
        assert record['exit'] == 0 and record['group_absent'] and not record['timed_out']
        assert record['finished_ns'] >= record['started_ns']
        assert sha(subfolder / 'stdout') == record['stdout_sha256'] and sha(subfolder / 'stderr') == record['stderr_sha256']
    return result


def fresh_kfd(build, folder):
    executable = (build / 'fe2o3_kfd.path').read_text().strip()
    digest = manifest(build / 'fe2o3_kfd.sha256')
    assert set(digest) == {executable} and sha(Path(executable)) == digest[executable]
    assert sha(ROOT / 'kfd_shard.py') == SHARD_CONTROLLER_SHA
    full, seen, receipts = roster(build / 'kfd-full-list.stdout'), set(), []
    heavy = [name for name in full if name.startswith('queue::live::construction_primary::')]
    assert len(heavy) >= 324
    for mode in ('0', '1', '2', '3', 'rest'):
        part = folder / ('kfd-shard-' + mode)
        inputs, result = read_json(part / 'inputs.json'), read_json(part / 'result.json')
        listed = roster(part / 'list.stdout')
        selected = inputs['selected']
        expected = [name for name in full if not name.startswith('queue::live::construction_primary::')] if mode == 'rest' else heavy[int(mode)::4]
        assert selected == listed == expected
        assert inputs['controller_sha256'] == SHARD_CONTROLLER_SHA
        assert inputs['full_roster_sha256'] == sha(build / 'kfd-full-list.stdout')
        assert inputs['source_manifest_sha256'] == sha(build / 'source-after.sha256')
        assert selected and len(selected) == len(set(selected)) and not seen.intersection(selected)
        assert set(selected) <= set(full) and inputs['total_roster'] == len(full)
        assert inputs['argv'] == [executable, '--test-threads=1', '--exact', *selected]
        assert inputs['executable_sha256'] == digest[executable] and inputs['cwd'] == str(REPO)
        assert inputs['environment'] == dict(HOME='/home/harsh', PATH='/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', RUST_TEST_THREADS='1')
        assert result['accepted'] and result['exit_code'] == 0 and result['group_absent']
        assert result['executable_unchanged'] and not result['timed_out']
        assert 0 <= result['elapsed_seconds'] <= 1235 and stamp(result['finished']) >= stamp(result['started'])
        assert sha(part / 'run.stdout') == result['stdout_sha256'] and sha(part / 'run.stderr') == result['stderr_sha256']
        actual, summary = test_result(part / 'run.stdout', len(selected), filtered=len(full) - len(selected))
        assert actual == sorted(selected) and result['summary'] == [summary]
        assert not (part / 'list.stderr').read_bytes() and not (part / 'run.stderr').read_bytes()
        seen.update(selected)
        receipts.append(dict(mode=mode, passed=len(selected), result_sha256=sha(part / 'result.json')))
    assert len(full) >= 1918 and seen == set(full)
    return dict(passed=len(full), failed=0, ignored=0, fresh_full_run=True,
                single_unfiltered_run=False, execution_mode='disjoint-exact-filter-shards',
                exact_executable_sha256=digest[executable], disjoint_roster_coverage=True, shards=receipts)


def audit_cold_proof(build_sources):
    folder = ROOT / 'cold-proof-attempt-01'
    checker_path = REPO / 'crates/fe2o3-runtime-model/verus/compute_xgmi_cold_endpoint_check.py'
    assert sha(checker_path) == COLD_CHECKER_SHA
    assert sha(folder / 'inputs' / checker_path.relative_to(REPO)) == COLD_CHECKER_SHA
    # Loading the frozen controller defines its source checks and classifier.
    # Its __main__ block, solver runner, controls and shell verifier are not run.
    spec = importlib.util.spec_from_file_location('cold_endpoint_acceptance_audit', checker_path)
    cold = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cold)
    strict_read = lambda path: cold.strict_json(path.read_text())
    result = strict_read(folder / 'result.json')
    pins = strict_read(folder / 'source-before.json')
    assert result['accepted'] and result['full_campaign'] and result['source_unchanged']
    assert result['error'] is None and result['whole_adapter_verified'] is False
    assert result['scope'] == cold.SCOPE and len(pins) == 11
    check_sources(pins)
    assert {str(path.relative_to(folder / 'inputs')) for path in (folder / 'inputs').rglob('*') if path.is_file()} == set(pins)
    for path, digest in pins.items():
        archived = folder / 'inputs' / path
        assert not archived.is_symlink() and archived.resolve() == archived and sha(archived) == digest
        if path.startswith('crates/'):
            assert build_sources[path] == digest
    frozen = {path: (folder / 'inputs' / path).read_bytes() for path in pins}
    assert cold.source_snapshot() == frozen
    original = frozen[str(cold.BODY)].decode('ascii')
    mutations = cold.mutations(original)
    expected_mutations = ['omit-completion', 'omit-submission', 'omit-dispatch', 'omit-unpublished', 'omit-data', 'omit-generation', 'omit-identities', 'omit-insertion', 'omit-persistent-generation']
    assert list(mutations) == expected_mutations and len(set(mutations.values())) == 9
    names = ['controls', 'release-before', 'positive-before', *['negative-' + name for name in expected_mutations], 'positive-after', 'release-after']
    assert len(names) == 14
    assert result['stages'] == [dict(name=name, status=1 if name.startswith('negative-') else 0, accepted=True) for name in names]
    verifier = Path('/home/harsh/.local/opt/verus-0.2026.08.09.92f466f')
    assert verifier.resolve() == verifier and not verifier.is_symlink()
    assert strict_read(folder / 'environment.json') == dict(HOME='/home/harsh', PATH='/usr/bin:/bin:/home/harsh/.cargo/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', RUSTUP_HOME='/home/harsh/.rustup', VERUS_Z3_PATH=str(verifier / 'z3'), TMPDIR=str(folder / 'tmp'))

    def measure_closure():
        rows, total, sizes = [], 0, {}
        for path in sorted(verifier.rglob('*'), key=str):
            assert not path.is_symlink() and (path.is_dir() or path.is_file())
            if path.is_dir():
                continue
            relative = str(path.relative_to(verifier))
            assert re.fullmatch(r'[A-Za-z0-9._/-]+', relative)
            data = path.read_bytes()
            sizes[relative] = len(data)
            total += len(data)
            rows.append(f'{relative}|{stat.S_IMODE(path.stat().st_mode):o}|{len(data)}|{hashlib.sha256(data).hexdigest()}\n')
        digest = hashlib.sha256(''.join(rows).encode()).hexdigest()
        assert len(rows) == 190 and total == 129019839
        assert digest == 'b316002910faf893a094684179398d3a66c30440cd6c707a0fef9b0d2e2f4092'
        manifest_lines = frozen[str(cold.support.MANIFEST)].decode().splitlines()
        assert 'file-count=190' in manifest_lines and 'total-bytes=129019839' in manifest_lines
        assert 'closure-sha256=' + digest in manifest_lines
        required = [line.removeprefix('required=') + '\n' for line in manifest_lines if line.startswith('required=')]
        assert len(required) == 3 and all(line in rows for line in required)
        subset = [line for line in rows if line.startswith('vstd/')]
        subset_bytes = sum(size for name, size in sizes.items() if name.startswith('vstd/'))
        subset_sha = hashlib.sha256(''.join(subset).encode()).hexdigest()
        assert len(subset) == 130 and subset_bytes == 1837099
        assert f'subtree=vstd|130|1837099|{subset_sha}' in manifest_lines
        return dict(files=len(rows), bytes=total, sha256=digest, vstd_files=len(subset), vstd_sha256=subset_sha)

    closure_before = measure_closure()
    records, prior_finish, groups = {}, None, set()
    closure_command = ['/bin/sh', str(REPO / cold.support.CLOSURE), str(verifier), str(REPO / cold.support.MANIFEST)]
    for name in names:
        stage = folder / name
        record = strict_read(stage / 'record.json')
        stdout, stderr = (stage / 'stdout.log').read_text(), (stage / 'stderr.log').read_text()
        negative = name.startswith('negative-')
        assert record['status'] == (1 if negative else 0) and record['group_absent'] is True
        assert type(record['process_group']) is int and record['process_group'] > 0 and record['process_group'] not in groups
        groups.add(record['process_group'])
        assert 0 <= record['finished_ns'] - record['started_ns'] <= 135_000_000_000
        assert prior_finish is None or record['started_ns'] >= prior_finish
        prior_finish = record['finished_ns']
        if name == 'controls':
            expected_command = ['/usr/bin/python3', '-I', '-B', str(REPO / cold.TEST)]
            assert not stdout and re.findall(r'^Ran (\d+) tests in [0-9.]+s$', stderr, re.M) == ['6']
            assert stderr.endswith('\nOK\n')
        elif name.startswith('release-'):
            expected_command = closure_command
            assert stdout == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n' and not stderr
        else:
            staged = folder / (name + '-source')
            assert {str(path.relative_to(staged)) for path in staged.rglob('*') if path.is_file()} == {str(cold.BODY), str(cold.PROOF)}
            assert all((staged / path).resolve() == staged / path and not (staged / path).is_symlink() for path in (cold.BODY, cold.PROOF))
            body = mutations[name.removeprefix('negative-')] if negative else original
            assert (staged / cold.BODY).read_bytes() == body.encode('ascii')
            assert (staged / cold.PROOF).read_bytes() == frozen[str(cold.PROOF)]
            proof = (staged / cold.PROOF).resolve()
            expected_command = ['/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5', '120', str(verifier / 'verus'), '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating', '--output-json', '--error-format=json', '--no-report-long-running', '--num-threads', '1', '--multiple-errors', '1', *(['--verify-function', '*' + cold.FOCUS, '--verify-root'] if negative else []), str(proof)]
            assert cold.classify(record['status'], stdout, stderr, proof, negative)
        assert record['command'] == expected_command
        records[name] = dict(record_sha256=sha(stage / 'record.json'), stdout_sha256=sha(stage / 'stdout.log'), stderr_sha256=sha(stage / 'stderr.log'))
    assert measure_closure() == closure_before
    assert cold.source_snapshot() == frozen
    return dict(accepted=True, packet='cold-proof-attempt-01', result_sha256=sha(folder / 'result.json'),
                source_before_sha256=sha(folder / 'source-before.json'), exact_source_pins=pins,
                replay_source_before_and_after_match=True, recorded_source_unchanged=True,
                stages=14, positive_contracts=2, logical_negatives=9, controls=6,
                verifier_closure=closure_before, receipts=records, scope=cold.SCOPE,
                fresh_full_campaign=True, audit_solver_rerun=False, whole_adapter_verified=False)


def hardware_expected(kind, flags, ids):
    fields = dict(devices='2', source_unique_id=ids[0], destination_unique_id=ids[1], pre_flush_observers='pending', expired_drain='rejected', source_unchanged='full-byte-pass', destination_sentinel='full-byte-pass', output='full-byte-pass', cleanup='logical-and-native-explicit', performance_acceptance='false', formal_refinement='false')
    if kind == 'production':
        staged = '--staged-default' in flags
        fields.update(schema='fe2o3.production-peer-copy-smoke.v1', authority='semantic-deny-all' if '--semantic-authority' in flags else 'production-deny-all', transport='HOST-STAGED' if staged else 'NATIVE-XGMI', launches='0', peer_copies='2', bytes_per_copy='8388581', native_packets='0' if staged else '6', observed_native_copies='0' if staged else '2', allocations='4', streams='2', readbacks='8', rounds_changed='true', logical_counter='final-only')
    else:
        queued, packetized = '--queued-consumer' in flags, '--packetized-copy' in flags
        fields.update(schema='fe2o3.compute-xgmi-smoke.v1', fixture='fe2o3.runtime.gfx942-r57-n3-qualification.v2', launches='4', launches_per_device='2', peer_copies='5' if packetized else '3', bytes='262144', transport='NATIVE-XGMI', observed_native_copies='5' if packetized else '3', copy_progress='consumer-drain' if queued else 'explicit-drain', consumer_admission='before-copy-progress' if queued else 'after-copy-drain', readbacks='29' if packetized else '21', modules='2', allocations='22' if packetized else '14', packetized_copies='2' if packetized else '0', packetized_packets='5' if packetized else '0', packetized_bytes='12582854' if packetized else '0', ring_reuse_copies='2', ring_reuse_packets='130', ring_reuse_bytes='536866818', ring_reuse_extent='268433409', ring_slots='64', ring_reuse_evidence='single-native-queue-full-extent')
    return fields


def audit_hardware():
    campaign = read_json(HARDWARE / 'campaign.json')
    ids = ['0x10a254ce4987e716', '0x53691ef168a0147d']
    cases = [('production-native', 'production', [], ids), ('production-staged', 'production', ['--staged-default'], ids), ('semantic-native-reverse', 'production', ['--semantic-authority'], ids[::-1]), ('semantic-staged-reverse', 'production', ['--semantic-authority', '--staged-default'], ids[::-1]), ('queued-ring', 'compute', ['--queued-consumer', '--ring-reuse'], ids), ('reverse-ring', 'compute', ['--ring-reuse'], ids[::-1]), ('combined-ring-packetized', 'compute', ['--queued-consumer', '--packetized-copy', '--ring-reuse'], ids)]
    assert campaign['accepted'] and campaign['owned_cleanup_complete'] and not campaign['errors']
    assert not campaign['performance_acceptance'] and not campaign['formal_refinement']
    assert not campaign['exclusive_reservation']
    assert len(campaign['completed']) == campaign['expected_cases'] == 7
    assert [item['name'] for item in campaign['completed']] == [item[0] for item in cases]
    directory = campaign['owned_directory']
    assert re.fullmatch(r'/tmp/fe2o3-multigpu-production-peers-20261002-[A-Za-z0-9]{6}', directory)
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
    receipts = {}

    def capture(name, argv=None, bound='30s'):
        folder = HARDWARE / name
        record = read_json(folder / 'result.json')
        assert record['exit_code'] == 0 and not record['timed_out'] and record['local_process_group_absent']
        assert 0 <= record['elapsed_seconds'] <= 245 and stamp(record['finished']) >= stamp(record['started'])
        assert sha(folder / 'stdout') == record['stdout_sha256'] and sha(folder / 'stderr') == record['stderr_sha256']
        if argv is not None:
            assert record['argv'] == ssh + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]
        receipts[name] = sha(folder / 'result.json')
        return (folder / 'stdout').read_text()

    binaries = campaign['binaries']
    assert set(binaries) == {'compute', 'production'}
    assert capture('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-production-peers-20261002-XXXXXX']).strip() == directory
    for kind, receipt, basename in [('compute', 'witness.sha256', 'gfx942-runtime-compute-xgmi-smoke'), ('production', 'production-witness.sha256', 'gfx942-runtime-peer-copy-smoke')]:
        path = 'target/debug/examples/' + basename
        hashes = manifest(CHECKS / receipt)
        assert set(hashes) == {path}
        digest = hashes[path]
        assert sha(REPO / path) == digest == binaries[kind]['sha256']
        assert binaries[kind]['local'] == str(REPO / path) and binaries[kind]['remote'] == directory + '/' + kind + '-witness'
        capture('upload-' + kind)
        assert read_json(HARDWARE / ('upload-' + kind) / 'result.json')['argv'] == ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', binaries[kind]['local'], 'mi300x:' + binaries[kind]['remote']]
        for phase in ('initial', 'final'):
            assert capture(phase + '-hash-' + kind, ['/usr/bin/sha256sum', binaries[kind]['remote']]).split() == [digest, binaries[kind]['remote']]
    for reported, (name, kind, flags, selected_ids) in zip(campaign['completed'], cases):
        argv = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-u', 'HIP_VISIBLE_DEVICES', '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES', '-u', 'GPU_DEVICE_ORDINAL', binaries[kind]['remote'], *flags, *selected_ids]
        lines = capture(name, argv, '180s').splitlines()
        assert len(lines) == 1 and lines[0].startswith('PASS ')
        pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
        assert all(len(pair) == 2 and all(pair) for pair in pairs)
        fields = dict(pairs)
        assert len(fields) == len(pairs) and fields == reported['fields'] == hardware_expected(kind, flags, selected_ids)
        assert not (HARDWARE / name / 'stderr').read_bytes()
    baseline = read_json(HARDWARE / 'initial-availability/stdout')
    for name in ['baseline', *[case[0] for case in cases], 'final']:
        state = json.loads(capture(name + '-availability', ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']))
        for card, uid, bus in zip(('card6', 'card7'), ids, ('0000:C6:00.0', '0000:E5:00.0')):
            assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bus
            assert state[card]['GPU use (%)'] == '0'
            assert state[card]['VRAM Total Used Memory (B)'] == baseline[card]['VRAM Total Used Memory (B)']
        assert state['system'] == baseline['system']
        mapping = capture(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        pids = {}
        for item in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = item.groups()
            devices = [] if devices is None else devices.split()
            assert pid not in pids and int(count) == len(devices) and bool(colon) == bool(devices)
            assert not {'6', '7'}.intersection(devices)
            pids[pid] = devices
        assert {'PID' + pid for pid in pids} == set(state['system'])
        assert all(int(state['system']['PID' + pid].split(',')[1]) == len(devices) for pid, devices in pids.items())
        memory = capture(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    paths = [directory + '/compute-witness', directory + '/production-witness']
    assert json.loads(capture('final-owned-processes')) == {'owned_executable_pids': []}
    probe = ('import json,os,sys; from pathlib import Path; '
        'paths=set(sys.argv[1:]); found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    capture('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
    capture('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    capture('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    capture('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    return campaign, receipts


assert not (ROOT / 'qualification.json').exists()
assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert sha(ROOT / 'verify.sh') == CONTROLLER_SHA
assert bool(args.reuse_kfd) != bool(args.kfd_shards), 'Select exactly one KFD evidence mode'
assert (ROOT / 'attempt-03/precheck/overall.exit').read_text().strip() == '0'
for earlier in ('attempt-01', 'attempt-02'):
    assert (ROOT / earlier / 'precheck/clippy.exit').read_text().strip() == '101'
    assert (ROOT / earlier / 'precheck/overall.exit').read_text().strip() == '1'
assert (ROOT / 'attempt-03/focused/deferred_compute.exit').read_text().strip() == '134'
assert (ROOT / 'attempt-03/diagnostic/authentication.exit').read_text().strip() == '134'
assert (ROOT / 'attempt-04/focused/deferred_compute.exit').read_text().strip() == '101'
build, tests, checks = ATTEMPT / 'build', ATTEMPT / 'tests', CHECKS
executable = (build / 'fe2o3_runtime.path').read_text().strip()
assert Path(executable).parent == REPO / 'target/debug/deps' and Path(executable).name.startswith('fe2o3_runtime-')
hashes = manifest(build / 'fe2o3_runtime.sha256')
assert set(hashes) == {executable}
runtime_hash = hashes[executable]
assert sha(Path(executable)) == runtime_hash
sources = manifest(build / 'source-before.sha256')
source_names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', 'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo')
assert set(sources) == {name.decode() for name in source_names.split(b'\0') if name}
check_sources(sources)
for mode, folder in [('build', build), ('focused', ATTEMPT / 'focused'), ('tests', tests), ('checks', checks)]:
    audit_stages(folder, mode, executable, sources)
artifacts = [json.loads(line) for line in (build / 'runtime.stdout').read_text().splitlines()]
for target in ('fe2o3_runtime', 'fe2o3_kfd'):
    emitted = {item['executable'] for item in artifacts if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == target and item.get('profile', {}).get('test') and item.get('executable')}
    assert emitted == {(build / (target + '.path')).read_text().strip()}
for phase in ('before', 'after'):
    assert manifest(tests / f'fe2o3_runtime-{phase}.sha256') == hashes
observed, summary = test_result(tests / 'fe2o3_runtime-full.stdout', 2001, 32)
assert observed == roster(tests / 'fe2o3_runtime-full-list.stdout')
test_result(checks / 'example.stdout', 9)
test_result(checks / 'production-example.stdout', 3)
for folder, prefix, filters in [(ATTEMPT / 'focused', '', ('compute_xgmi', 'packetized', 'deferred_compute', 'producer_peers', 'multi_open')), (tests, 'fe2o3_runtime-', ('compute_xgmi', 'packetized'))]:
    for name in filters:
        selected = roster(folder / (prefix + name + '-list.stdout'))
        actual, _ = test_result(folder / (prefix + name + '.stdout'), len(selected), filtered=len(observed) - len(selected))
        assert actual == selected and set(actual) <= set(observed)

proposal = audit_metadata()
guards = audit_guards(proposal)
cold_proof = audit_cold_proof(sources)
prior_archive = REPO / 'docs/evidence/dev-multigpu-packetized-2026-10-02/raw.tar.gz'
assert sha(prior_archive) == ARCHIVE_SHA
authenticated = {}
with tarfile.open(prior_archive, 'r:gz') as archive:
    members = archive.getmembers()
    assert len({member.name for member in members}) == len(members)
    by_name = {member.name: member for member in members}

    def bind(relative):
        member = by_name[str(Path(PREVIOUS.name) / relative)]
        assert member.isfile() and not member.issym() and not member.islnk()
        data = archive.extractfile(member).read()
        assert (PREVIOUS / relative).read_bytes() == data, ('prior archive mismatch', relative)
        authenticated[str(relative)] = hashlib.sha256(data).hexdigest()
        return data

    prior_report = json.loads(bind(Path('source-ci/proposal-04/metadata-report.json')))
    assert proposal['proof_files'] == prior_report['proof_files']
    for member in members:
        relative = Path(member.name).relative_to(PREVIOUS.name)
        if member.isfile() and relative.is_relative_to('arithmetic-proof/proof-attempt-05'):
            bind(relative)
    proof = json.loads(bind(Path('arithmetic-proof/proof-attempt-05/result.json')))
    proof_inputs = json.loads(bind(Path('arithmetic-proof/proof-attempt-05/source-before.json')))
    prior_cpu = json.loads(bind(Path('cpu-qualification.json')))
    for shard in prior_cpu['kfd']['shards']:
        receipt = bind(Path('kfd-shard-' + shard['mode']) / 'result.json')
        assert hashlib.sha256(receipt).hexdigest() == shard['result_sha256']
    prior_list = Path('attempt-03/tests/fe2o3_kfd-full-list')
    assert bind(Path(str(prior_list) + '.exit')).decode().strip() == '0'
    prior_roster = sorted(line.removesuffix(': test') for line in bind(Path(str(prior_list) + '.stdout')).decode().splitlines() if line.endswith(': test'))
    assert len(prior_roster) == len(set(prior_roster)) == 1918
    assert set(prior_roster) <= set(roster(build / 'kfd-full-list.stdout'))
assert proof['accepted'] and proof['full_campaign'] and proof['source_unchanged']
assert not proof['whole_adapter_verified'] and len(proof['stages']) == 13
assert all(stage['accepted'] for stage in proof['stages'])
assert len(proof_inputs) == 10
for path, digest in proof_inputs.items():
    assert sha(REPO / path) == digest and sha(PROOF / 'inputs' / path) == digest
if args.reuse_kfd:
    assert prior_cpu['accepted'] and prior_cpu['kfd']['passed'] == 1918
    assert prior_cpu['kfd']['failed'] == prior_cpu['kfd']['ignored'] == 0
    assert prior_cpu['kfd']['disjoint_roster_coverage'] and not prior_cpu['kfd']['serial_run_accepted']
    assert not git('diff', BASE, '--', 'crates/fe2o3-kfd')
    assert not git('ls-files', '--others', '--exclude-standard', '--', 'crates/fe2o3-kfd')
    kfd_hash = (build / 'fe2o3_kfd.sha256').read_text().split()[0]
    assert kfd_hash == prior_cpu['kfd']['executable_sha256']
    assert sha(Path((build / 'fe2o3_kfd.path').read_text().strip())) == kfd_hash
    kfd = dict(passed=1918, fresh_full_run=False, exact_executable_sha256=kfd_hash, accepted_prior_archive_sha256=ARCHIVE_SHA)
else:
    shard_folder = (ROOT / args.kfd_shards).resolve()
    assert shard_folder.is_relative_to(ROOT)
    kfd = fresh_kfd(build, shard_folder)
hardware, hardware_receipts = audit_hardware()
check_sources(sources)
assert sha(Path(executable)) == runtime_hash

result = dict(accepted=True, audited_at=datetime.now(timezone.utc).isoformat(),
    accepted_build_attempt=attempt, accepted_checks_attempt=args.checks_attempt,
    accepted_source_attempt=source_attempt, accepted_proposal=args.proposal,
    accepted_hardware_folder=args.hardware_folder, controller_sha256=CONTROLLER_SHA,
    source_snapshot_sha256=sha(build / 'source-before.sha256'), source_files=len(sources),
    runtime=dict(passed=2001, ignored=32, failed=0, filtered=0,
                 executable_sha256=runtime_hash, exact_roster=True, summary=summary),
    examples=dict(compute_tests=9, production_no_default_tests=3),
    strict_clippy=True, no_default_build=True, source_controls=32,
    hardware=dict(cases=7, owned_cleanup_complete=True, executable_hashes=hardware['binaries'], receipt_sha256=hardware_receipts),
    kfd=kfd, cold_endpoint_proof=cold_proof, prior_archive_member_sha256=authenticated,
    reused_arithmetic=dict(fresh_solver_run=False, exact_input_pins=proof_inputs,
                           result_sha256=sha(PROOF / 'result.json'), scope=proof['scope']),
    full_parity=False, whole_adapter_formal_refinement=False, performance_acceptance=False)
with (ROOT / 'qualification.json').open('x') as target:
    json.dump(result, target, indent=2)
    target.write('\n')
print(json.dumps(result))
