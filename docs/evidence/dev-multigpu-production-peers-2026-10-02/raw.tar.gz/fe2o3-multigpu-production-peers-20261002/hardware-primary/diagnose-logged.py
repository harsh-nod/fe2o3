#!/usr/bin/env python3
"""Capture a mapped failure stage before fail-closed teardown; never acceptance."""
import json
from pathlib import Path
import re
import runpy
import sys

root = Path(__file__).resolve().parent
helpers = runpy.run_path(str(root / 'campaign.py'))
admit, remote, capture = [helpers[name] for name in ('admit', 'remote', 'capture')]
digest, relative = (root.parent / 'attempt-06/production-witness/production-witness.sha256').read_text().split()
local = helpers['REPO'] / relative
assert helpers['sha'](local.read_bytes()) == digest
directory = None
cleaned = False
errors = []
try:
    admit('logged-baseline')
    candidate = remote('logged-create', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-peers-logged-20261002-XXXXXX']).strip()
    assert re.fullmatch(r'/tmp/fe2o3-peers-logged-20261002-[A-Za-z0-9]{6}', candidate)
    directory = candidate
    path = directory + '/production-witness'
    capture('logged-upload', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
        '-o', 'StrictHostKeyChecking=yes', str(local), 'mi300x:' + path])
    assert remote('logged-hash', ['/usr/bin/sha256sum', path]).split() == [digest, path]
    admit('logged-run')
    remote('logged-witness', ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
        '-u', 'HIP_VISIBLE_DEVICES', '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES',
        '-u', 'GPU_DEVICE_ORDINAL', path, *helpers['IDS']], '180s')
except Exception as error:
    errors.append(repr(error))
finally:
    if directory is not None:
        try:
            probe = ('import json,os,sys; from pathlib import Path; found=[]\n'
                'for item in Path("/proc").iterdir():\n'
                ' if item.name.isdigit():\n'
                '  try: exe=os.readlink(item/"exe")\n'
                '  except (FileNotFoundError,PermissionError,ProcessLookupError): continue\n'
                '  if exe.removesuffix(" (deleted)")==sys.argv[1]: found.append(int(item.name))\n'
                'print(json.dumps(found)); sys.exit(bool(found))')
            assert json.loads(remote('logged-process-absence', ['/usr/bin/python3', '-I', '-B', '-c', probe, directory + '/production-witness'])) == []
            remote('logged-remove-file', ['/usr/bin/rm', '-f', '--', directory + '/production-witness'])
            remote('logged-remove-directory', ['/usr/bin/rmdir', '--', directory])
            remote('logged-confirm-absence', ['/usr/bin/test', '!', '-e', directory])
            cleaned = True
        except Exception as error:
            errors.append('cleanup: ' + repr(error))
    try:
        admit('logged-final')
    except Exception as error:
        errors.append('final state: ' + repr(error))
    result = dict(diagnostic_only=True, errors=errors, owned_cleanup_complete=cleaned,
        owned_directory=directory, executable_sha256=digest, qualification_accepted=False)
    with (root / 'logged-diagnostic.json').open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    print(json.dumps(result), flush=True)
sys.exit(0 if cleaned else 1)
