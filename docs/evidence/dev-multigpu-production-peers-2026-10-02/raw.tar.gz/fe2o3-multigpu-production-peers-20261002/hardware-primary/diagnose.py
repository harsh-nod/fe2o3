#!/usr/bin/env python3
"""One bounded owned-process debugger run, not qualification or fault recovery."""
import json
from pathlib import Path
import re
import runpy
import sys

root = Path(__file__).resolve().parent
helpers = runpy.run_path(str(root / 'campaign.py'))
admit, remote, capture = [helpers[name] for name in ('admit', 'remote', 'capture')]
prior = json.loads((root / 'campaign.json').read_text())
assert not prior['accepted'] and prior['owned_cleanup_complete']
binary = prior['binaries']['production']
assert helpers['sha'](Path(binary['local']).read_bytes()) == binary['sha256']
directory = None
cleaned = False
errors = []
observed_abort = False
try:
    admit('debug-baseline')
    candidate = remote('debug-create', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-peers-debug-20261002-XXXXXX']).strip()
    assert re.fullmatch(r'/tmp/fe2o3-peers-debug-20261002-[A-Za-z0-9]{6}', candidate)
    directory = candidate
    path = directory + '/production-witness'
    capture('debug-upload', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
        '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + path])
    assert remote('debug-hash', ['/usr/bin/sha256sum', path]).split() == [binary['sha256'], path]
    admit('debug-run')
    output = remote('debug-backtrace', ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
        '-u', 'HIP_VISIBLE_DEVICES', '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES',
        '-u', 'GPU_DEVICE_ORDINAL', '/usr/bin/gdb', '-nx', '-nh', '--batch',
        '-ex', 'set pagination off', '-ex', 'set confirm off', '-ex', 'set print thread-events off',
        '-ex', 'run', '-ex', 'bt 30', '--args', path, *helpers['IDS']], '180s')
    observed_abort = 'SIGABRT' in output
    print(output, flush=True)
except Exception as error:
    errors.append(repr(error))
finally:
    if directory is not None:
        try:
            probe = ('import json,os,sys; from pathlib import Path; found=[]\n'
                'for item in Path("/proc").iterdir():\n'
                ' if item.name.isdigit():\n'
                '  try: exe=os.readlink(item/"exe")\n'
                '  except (FileNotFoundError,PermissionError,ProcessLookupError): continue\n'
                '  if exe.removesuffix(" (deleted)")==sys.argv[1]: found.append(int(item.name))\n'
                'print(json.dumps(found)); sys.exit(bool(found))')
            assert json.loads(remote('debug-process-absence', ['/usr/bin/python3', '-I', '-B', '-c', probe, directory + '/production-witness'])) == []
            remote('debug-remove-file', ['/usr/bin/rm', '-f', '--', directory + '/production-witness'])
            remote('debug-remove-directory', ['/usr/bin/rmdir', '--', directory])
            remote('debug-confirm-absence', ['/usr/bin/test', '!', '-e', directory])
            cleaned = True
        except Exception as error:
            errors.append('cleanup: ' + repr(error))
    try:
        admit('debug-final')
    except Exception as error:
        errors.append('final state: ' + repr(error))
    result = dict(diagnostic_only=True, observed_abort=observed_abort, errors=errors,
        owned_cleanup_complete=cleaned, owned_directory=directory, executable_sha256=binary['sha256'],
        qualification_accepted=False)
    with (root / 'diagnostic.json').open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    print(json.dumps(result), flush=True)
sys.exit(0 if cleaned and not errors else 1)
