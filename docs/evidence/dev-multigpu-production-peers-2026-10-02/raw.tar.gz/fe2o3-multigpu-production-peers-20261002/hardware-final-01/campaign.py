#!/usr/bin/env python3
"""Finite, sequential correctness checks on freshly idle GPUs, never a benchmark."""
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0x10a254ce4987e716', '0x53691ef168a0147d']
CARDS = ['card6', 'card7']
BD = ['0000:C6:00.0', '0000:E5:00.0']
BASELINE = json.loads((ROOT / 'initial-availability/stdout').read_text())
CASES = [
    ('production-native', 'production', [], IDS),
    ('production-staged', 'production', ['--staged-default'], IDS),
    ('semantic-native-reverse', 'production', ['--semantic-authority'], IDS[::-1]),
    ('semantic-staged-reverse', 'production', ['--semantic-authority', '--staged-default'], IDS[::-1]),
    ('queued-ring', 'compute', ['--queued-consumer', '--ring-reuse'], IDS),
    ('reverse-ring', 'compute', ['--ring-reuse'], IDS[::-1]),
    ('combined-ring-packetized', 'compute', ['--queued-consumer', '--packetized-copy', '--ring-reuse'], IDS),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout = (folder / 'stdout').read_bytes()
    stderr = (folder / 'stderr').read_bytes()
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert process.returncode == receipt['exit_code'] == 0, (name, receipt, stderr)
    assert not receipt['timed_out'] and receipt['local_process_group_absent'], (name, receipt)
    return stdout.decode()


def remote(name, argv, bound='30s'):
    return capture(name, SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])])


def admit(name):
    state = json.loads(remote(name + '-availability', ['/opt/rocm/bin/rocm-smi', '--showuse',
        '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']))
    for card, uid, bdf in zip(CARDS, IDS, BD):
        assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == '0'
        assert state[card]['VRAM Total Used Memory (B)'] == BASELINE[card]['VRAM Total Used Memory (B)']
    assert state['system'] == BASELINE['system'], 'changed PID roster; stop and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    # rocm-smi omits the PID->GPU map in JSON mode; accept only its counted text records.
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) and bool(colon) == bool(devices)
        assert pid not in records and not {'6', '7'}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system']), (records, state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    return state


def expected(kind, flags, ids):
    result = dict(devices='2', source_unique_id=ids[0], destination_unique_id=ids[1],
        pre_flush_observers='pending', expired_drain='rejected', source_unchanged='full-byte-pass',
        destination_sentinel='full-byte-pass', output='full-byte-pass',
        cleanup='logical-and-native-explicit', performance_acceptance='false', formal_refinement='false')
    if kind == 'production':
        staged = '--staged-default' in flags
        result.update(schema='fe2o3.production-peer-copy-smoke.v1',
            authority='semantic-deny-all' if '--semantic-authority' in flags else 'production-deny-all',
            transport='HOST-STAGED' if staged else 'NATIVE-XGMI', launches='0', peer_copies='2',
            bytes_per_copy='8388581', native_packets='0' if staged else '6',
            observed_native_copies='0' if staged else '2', allocations='4', streams='2', readbacks='8',
            rounds_changed='true', logical_counter='final-only')
    else:
        queued = '--queued-consumer' in flags
        packetized = '--packetized-copy' in flags
        result.update(schema='fe2o3.compute-xgmi-smoke.v1',
            fixture='fe2o3.runtime.gfx942-r57-n3-qualification.v2', launches='4', launches_per_device='2',
            peer_copies='5' if packetized else '3', bytes='262144', transport='NATIVE-XGMI',
            observed_native_copies='5' if packetized else '3',
            copy_progress='consumer-drain' if queued else 'explicit-drain',
            consumer_admission='before-copy-progress' if queued else 'after-copy-drain',
            readbacks='29' if packetized else '21', modules='2', allocations='22' if packetized else '14',
            packetized_copies='2' if packetized else '0', packetized_packets='5' if packetized else '0',
            packetized_bytes='12582854' if packetized else '0', ring_reuse_copies='2',
            ring_reuse_packets='130', ring_reuse_bytes='536866818', ring_reuse_extent='268433409',
            ring_slots='64', ring_reuse_evidence='single-native-queue-full-extent')
    return result


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in fields
        fields[key] = value
    return fields


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    attempt = sys.argv[1]
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert not (ROOT / 'campaign.json').exists()
    checks = ROOT.parent / attempt / 'checks'
    binaries = {}
    for kind, receipt, basename in [
        ('compute', 'witness.sha256', 'gfx942-runtime-compute-xgmi-smoke'),
        ('production', 'production-witness.sha256', 'gfx942-runtime-peer-copy-smoke')]:
        digest, path = (checks / receipt).read_text().strip().split(maxsplit=1)
        local = REPO / path
        assert local == REPO / 'target/debug/examples' / basename
        assert sha(local.read_bytes()) == digest
        binaries[kind] = dict(local=str(local), sha256=digest)
    completed, errors = [], []
    directory = None
    cleaned = False
    try:
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-production-peers-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-multigpu-production-peers-20261002-[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
            capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            hashed = remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
            assert hashed.split() == [binary['sha256'], binary['remote']]
        for name, kind, flags, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
                '-u', 'HIP_VISIBLE_DEVICES', '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES',
                '-u', 'GPU_DEVICE_ORDINAL', binaries[kind]['remote'], *flags, *ids], '180s')
            fields = pass_fields(output)
            assert fields == expected(kind, flags, ids), (name, fields, expected(kind, flags, ids))
            assert not (ROOT / name / 'stderr').read_bytes()
            completed.append(dict(name=name, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [directory + '/compute-witness', directory + '/production-witness']
                probe = ('import json,os,sys; from pathlib import Path; '
                    'paths=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    if 'remote' in binary:
                        try:
                            hashed = remote('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
                            assert hashed.split() == [binary['sha256'], binary['remote']]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        try:
            admit('final')
        except Exception as error:
            errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            owned_directory=directory, owned_cleanup_complete=cleaned, exclusive_reservation=False,
            performance_acceptance=False, formal_refinement=False,
            limitations=['point observations, not continuous attachment census',
                        'packet totals are source-bound plans, not raw queue telemetry'])
        with (ROOT / 'campaign.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
