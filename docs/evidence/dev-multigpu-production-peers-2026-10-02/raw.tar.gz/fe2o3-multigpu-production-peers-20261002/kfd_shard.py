#!/usr/bin/env python3
"""Four disjoint construction shards and the remainder of the exact KFD roster."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
attempt, mode = sys.argv[1:]
assert re.fullmatch(r'attempt-[0-9]+', attempt) and mode in {'0', '1', '2', '3', 'rest'}
out = root / ('kfd-shard-' + mode)
out.mkdir()
build = root / attempt / 'build'
binary = Path((build / 'fe2o3_kfd.path').read_text().strip())
digest = (build / 'fe2o3_kfd.sha256').read_text().split()[0]
assert hashlib.sha256(binary.read_bytes()).hexdigest() == digest
listed = (build / 'kfd-full-list.stdout').read_text().splitlines()
all_tests = sorted(line.removesuffix(': test') for line in listed if line.endswith(': test'))
assert len(all_tests) == len(set(all_tests)) >= 1918
prefix = 'queue::live::construction_primary::'
heavy = [name for name in all_tests if name.startswith(prefix)]
assert len(heavy) >= 324
selected = [name for name in all_tests if not name.startswith(prefix)] if mode == 'rest' else heavy[int(mode)::4]
assert selected
environment = dict(HOME='/home/harsh', PATH='/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', RUST_TEST_THREADS='1')
cwd = '/home/harsh/.codex-tmp/fe2o3-r61-execution'
argv = [str(binary), '--test-threads=1', '--exact', *selected]
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
(out / 'inputs.json').write_text(json.dumps(dict(argv=argv, environment=environment,
    executable_sha256=digest, controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    selected=selected, total_roster=len(all_tests), cwd=cwd,
    full_roster_sha256=hashlib.sha256((build / 'kfd-full-list.stdout').read_bytes()).hexdigest(),
    source_manifest_sha256=hashlib.sha256((build / 'source-after.sha256').read_bytes()).hexdigest()), indent=2) + '\n')
discovery = subprocess.run([*argv, '--list'], cwd=cwd, env=environment, text=True, capture_output=True, timeout=60, check=False)
(out / 'list.stdout').write_text(discovery.stdout)
(out / 'list.stderr').write_text(discovery.stderr)
observed = sorted(line.removesuffix(': test') for line in discovery.stdout.splitlines() if line.endswith(': test'))
assert discovery.returncode == 0 and observed == selected
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
timed_out = False
with (out / 'run.stdout').open('wb') as stdout, (out / 'run.stderr').open('wb') as stderr:
    process = subprocess.Popen(argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
        stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        status = process.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
        status = 124
try:
    os.killpg(process.pid, 0)
    absent = False
except ProcessLookupError:
    absent = True
unchanged = hashlib.sha256(binary.read_bytes()).hexdigest() == digest
output = (out / 'run.stdout').read_text()
summary = [line for line in output.splitlines() if line.startswith('test result:')]
expected = f'test result: ok. {len(selected)} passed; 0 failed; 0 ignored; 0 measured; {len(all_tests) - len(selected)} filtered out;'
passed = sorted(re.findall(r'^test (\S+) \.\.\. ok$', output, re.M))
accepted = (status == 0 and absent and unchanged and passed == selected
            and len(summary) == 1 and summary[0].startswith(expected))
result = dict(accepted=accepted, exit_code=status, timed_out=timed_out, started=started,
    finished=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - clock,
    group_absent=absent, executable_unchanged=unchanged, summary=summary,
    stdout_sha256=hashlib.sha256((out / 'run.stdout').read_bytes()).hexdigest(),
    stderr_sha256=hashlib.sha256((out / 'run.stderr').read_bytes()).hexdigest())
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
sys.exit(0 if accepted else 1)
