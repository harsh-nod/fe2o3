# Rejected Proposal Attempt

`support.py propose --source-frozen --name proposal-02` exited 1 before producing
a metadata patch: `ValueError: unchanged accepted guard: check-retained-credit-dispatch.py`.
The historical proposer requires baseline guard bytes; proposal-01's applied
metadata was still present. Primary reversed exactly its own nine-file metadata
patch, checked that no guard diff remained, and will use a fresh proposal label.
This is a rejected controller invocation, not a passed source workflow or solver.
