# Existing Source Controls

Reuse the pinned exact 32-command workflow and metadata-only AST verifier from
the preceding accepted packet. Configure the new accepted baseline only. The
previous one-off KFD cadence registration hook is unnecessary when KFD source
is unchanged; do not carry it forward as permission for unrelated deltas.

Proposals require explicit source freeze. Review all changed guarded source
premises before applying metadata, keep executable proof bodies unchanged, and
distinguish source-control acceptance from formal refinement of changed code.
Every attempt and audit label must be fresh. No script applies its own patch.
