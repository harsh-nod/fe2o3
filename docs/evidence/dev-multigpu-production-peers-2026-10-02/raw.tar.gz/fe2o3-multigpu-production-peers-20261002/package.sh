#!/bin/bash
set -eu
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-multigpu-production-peers-20261002
evidence="$root/docs/evidence/dev-multigpu-production-peers-2026-10-02"
cd "$root"
test -f "$raw/qualification.json"
test ! -e "$raw/source.patch"
git rev-parse HEAD > "$raw/base-commit.txt"
paths=(crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model/verus docs/runtime-a1-a2-swarm-current.md docs/runtime-multi-device-qualification-v1.md)
git diff HEAD --binary -- "${paths[@]}" > "$raw/source.patch"
git diff HEAD --name-only -- "${paths[@]}" > "$raw/source-paths.txt"
for path in \
    crates/fe2o3-kfd/src/queue_live/compute_xgmi_cold_body.rs \
    crates/fe2o3-runtime-model/verus/compute_xgmi_cold_endpoint_check.py \
    crates/fe2o3-runtime-model/verus/compute_xgmi_cold_endpoint_test.py \
    crates/fe2o3-runtime-model/verus/compute_xgmi_cold_endpoint_v1.rs \
    crates/fe2o3-runtime/examples/gfx942-runtime-peer-copy-smoke.rs \
    crates/fe2o3-runtime/src/kfd_backend/multi_open.rs \
    crates/fe2o3-runtime/src/kfd_backend/multi_open/tests.rs \
    crates/fe2o3-runtime/src/kfd_backend/deferred_compute/tests/completed_results.rs; do
    test -f "$path"
    test -z "$(git ls-files -- "$path")"
    git diff --no-index --binary -- /dev/null "$path" >> "$raw/source.patch" || test "$?" = 1
    printf '%s\n' "$path" >> "$raw/source-paths.txt"
done
sort -u "$raw/source-paths.txt" -o "$raw/source-paths.txt"
while IFS= read -r path; do sha256sum "$path"; done < "$raw/source-paths.txt" > "$raw/source.sha256"
sha256sum "$raw/source.patch" > "$raw/source-patch.sha256"
git apply --reverse --check "$raw/source.patch"
mkdir -p "$evidence"
test ! -e "$evidence/raw.tar.gz"
tar -C "$(dirname "$raw")" -czf "$evidence/raw.tar.gz" "$(basename "$raw")"
cd "$evidence"
sha256sum raw.tar.gz > SHA256SUMS
