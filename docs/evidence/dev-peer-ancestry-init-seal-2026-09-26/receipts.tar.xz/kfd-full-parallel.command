timeout --kill-after=30s 3600s target/debug/deps/fe2o3_kfd-0a982ce424b91297 --test-threads=8
