cargo clippy --offline -p fe2o3-kfd -p fe2o3-runtime -p fe2o3-runtime-model --all-targets --all-features -- -D warnings 
