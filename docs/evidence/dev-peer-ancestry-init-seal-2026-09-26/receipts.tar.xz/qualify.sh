#!/usr/bin/env bash
set -u
set -o pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
out=/home/harsh/.codex-tmp/fe2o3-ancestry-seal-20260926-lU2MZ5CF
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
git rev-parse HEAD > "$out/source-commit.txt"
git ls-files -z crates Cargo.toml Cargo.lock rust-toolchain.toml .cargo | xargs -0 sha256sum > "$out/sources.before.sha256"
run() {
    local name=$1
    shift
    printf '%q ' "$@" > "$out/$name.command"
    printf '\n' >> "$out/$name.command"
    timeout --kill-after=30s 1200s "$@" > "$out/$name.log" 2>&1
    local status=$?
    printf '%s\t%s\n' "$name" "$status" >> "$out/status.tsv"
    printf '%s: exit %s\n' "$name" "$status"
    tail -5 "$out/$name.log"
}
run focused-final cargo test --offline -p fe2o3-runtime --all-features --lib peer_ -- --test-threads=1
run runtime cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=1
run kfd cargo test --offline -p fe2o3-kfd --all-features --lib -- --test-threads=1
run model cargo test --offline -p fe2o3-runtime-model --all-features --lib -- --test-threads=1
run doctests cargo test --offline -p fe2o3-kfd -p fe2o3-runtime -p fe2o3-runtime-model --all-features --doc
run clippy cargo clippy --offline -p fe2o3-kfd -p fe2o3-runtime -p fe2o3-runtime-model --all-targets --all-features -- -D warnings
run minimal cargo check --offline -p fe2o3-runtime --no-default-features
run formatting cargo fmt --all -- --check
run whitespace git diff --check
run continuity sha256sum --check "$out/sources.before.sha256"
