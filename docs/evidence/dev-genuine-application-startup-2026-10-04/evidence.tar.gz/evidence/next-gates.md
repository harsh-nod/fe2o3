# Reviewed next steps, not implemented or qualified

## Compiler-time proof execution

The application custodian is not a direct replacement: it requires finalized
HSACO and a committed envelope, whereas these compiler proofs precede both.
Candidate: an unfiltered execution owner in the existing top-level Cargo broker,
created outside the filtered Cargo process tree. Preserve the current proof
preflight and Cargo exec-notification filter unchanged.

- Extend the already authenticated invocation session in capability_broker.rs;
  no caller-selected service address and no reuse of FD195.
- Delegate the original selected rustc child, not the wrapper identity. Retain
  its original pidfd, invocation and fresh nonce. Reuse the existing retained
  compiler-child channel rather than reopen a PID as custody.
- Release a dedicated endpoint only after wrapper image, one-use Cargo permit,
  closure/config/session and child delegation agree. Check requesting rustc's
  credentials and original live process for every request.
- Keep source generation and receipt construction private to fe2o3-verifier.
  A concrete opaque executor owner, not a public implementable proof trait,
  carries the exact sealed generated source, binding, profile, runtime identity,
  nonce and bounded deadline to the retained runtime outside filtered Cargo.
- Compare returned identity and result with the original request and locally
  admitted runtime. No constructor from arbitrary receipt bytes/status/output.
- Cover both SafeReferenceMirToKernelMir (production_reference_effect_join_v2)
  and conditional output verification (production_mir_pliron_verus_join_v1).
- Retain execution/delegation custody through semantic lineage and publication.
  Any EOF, timeout, malformed reply or owner loss poisons the session, with no
  reconnect/local fallback. Existing broker deadlines must cover proof bounds.
- Tests must reject wrong pidfd, wrapper/sibling credentials, replay, input/
  runtime/profile/result changes and owner death; then run both real proof stages
  through the genuine selected-rustc campaign before claiming completion.

## Device-to-host marker projection

After device commit, retain the current generation's PinnedApplicationEnvelope
and source owners. Its replay outer handoff retains the original rustc argv,
working directory and compile environment. Derive the device binding using the
existing ordered Cargo metadata algorithm and check its recorded binding.
Check the independently retained compiler policy/closure and receipt subject;
self-contained carriage signature checks alone do not establish provenance.

Extend the sealed binding projection/wrapper with a distinct production-host
profile, leaving check/clippy/test behavior unchanged. Match the exact source,
package/version, manifest, crate/library type, edition, feature cfgs and expected
host target. Host Cargo metadata must be present but need not equal device
metadata. Scrub binding for every unselected unit/query.

The current projection proves immutability, not its creator. The existing Cargo
boundary must check the original sealed projection object in the inherited fixed
slot at the direct pinned-Cargo-child -> pinned-wrapper transition and reject
wrong ancestry/substitution. Marker metadata still grants no load authority.
Do not hold a temporary publication token across host cargo run; retain the
envelope/lease and preserve the application's original currentness/FD195 checks.

## Two-device qualification

Retain one Arc<RemoteConditionalFillArtifactV1<Marker>>. Use the generated-only
native-peer multi-device backend with two distinct nonzero device unique IDs and
RuntimeAsyncCurrentThreadOwnedEngineV1. On each GPU: prepare generated invocation,
reserve, activate, collect charged typed completion, validate N=65 exact u32 index
output with G=128, WG=64, LDS=0 and exactly 260 output bytes at offset zero.

Stage those actual completed bytes in separate guarded frames. Settle H2D copies
into DeviceLocal/PUBLIC sources, then do native peer copies in both directions
into sentinel destinations. Validate entire readbacks and unchanged sources;
require the native compute-XGMI counter to increase once per transfer. Consume
reply handles between stages, destroy streams, drain to Quiescent, and require
native shutdown Released. No qualification kernel or host-staged backend may
substitute for this admitted application path.
