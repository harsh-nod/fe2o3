unsafe extern "C" { fn dlsym(h: *mut u8, n: *const u8) -> *mut u8; }
fn main() { unsafe { std::hint::black_box(dlsym(std::ptr::null_mut(), c"deliberately_prohibited".as_ptr().cast())); } }
