#include <dlfcn.h>
int main(int n, char **v) {
  return dlsym((void *)0, v[n - 1]) == 0;
}
