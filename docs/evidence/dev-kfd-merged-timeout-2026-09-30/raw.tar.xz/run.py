#!/usr/bin/env python3
"""Owned development regression receipts, not formal or native qualification."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import types

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = Path(__file__).resolve().parent
TOOLCHAIN = Path('/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin')
TARGET = Path('/home/harsh/.codex-tmp/fe2o3-owned-extraction-qualification-20260929-root1/target-v2')
CONTROLLER = ROOT / 'crates/fe2o3-runtime-model/verus/check-journal-issuance.py'
CONTROLLER_SHA = '36d5e0641300bf2568884ec4c440c668477a4b24a07ee95273a91eab34659480'


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def inventory():
    names = subprocess.check_output(
        ['/usr/bin/git', '-c', 'gc.auto=0', 'ls-files', '-z', '--', 'crates', 'examples',
         '.cargo', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'], cwd=ROOT, timeout=30)
    result = {}
    for name in names.split(b'\0'):
        if not name:
            continue
        path = ROOT / os.fsdecode(name)
        need(path.is_file() and not path.is_symlink() and path.resolve() == path,
             'ordinary build input: ' + str(path))
        result[str(path.relative_to(ROOT))] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    return result


def main():
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize,
         'use python3 -I -B')
    name, seconds, *argv = sys.argv[1:]
    need(name.isascii() and name and all(c.isalnum() or c == '-' for c in name), 'stage name')
    seconds = int(seconds)
    need(0 < seconds <= 1800 and argv, 'bounded invocation')
    folder = BASE / name
    folder.mkdir()
    (folder / 'tmp').mkdir()
    raw = CONTROLLER.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == CONTROLLER_SHA, 'pinned process owner')
    owner = types.ModuleType('merged_regression_owner')
    owner.__file__ = str(CONTROLLER)
    sys.modules[owner.__name__] = owner
    exec(compile(raw, str(CONTROLLER), 'exec'), owner.__dict__)
    env = {'HOME': '/home/harsh', 'PATH': str(TOOLCHAIN) + ':/usr/bin:/bin',
           'RUSTUP_TOOLCHAIN': 'nightly-2026-04-03-x86_64-unknown-linux-gnu',
           'RUSTC': str(TOOLCHAIN / 'rustc'), 'RUSTDOC': str(TOOLCHAIN / 'rustdoc'),
           'CARGO_HOME': '/home/harsh/.cargo', 'RUSTUP_HOME': '/home/harsh/.rustup',
           'CARGO_NET_OFFLINE': 'true', 'CARGO_INCREMENTAL': '0', 'CARGO_BUILD_JOBS': '2',
           'CARGO_TARGET_DIR': str(TARGET), 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
           'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TMPDIR': str(folder / 'tmp')}
    before = inventory()
    tools = {name: digest(TOOLCHAIN / name) for name in ('cargo', 'rustc', 'rustdoc')}
    namespace = os.readlink('/proc/self/ns/pid')
    head = subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=30).decode().strip()
    save(folder / 'inputs.json', {'head': head, 'source': before, 'tools': tools,
         'argv': argv, 'cwd': str(ROOT), 'environment': env, 'namespace': namespace,
         'timeout_seconds': seconds, 'mutable_target_reuse': True})
    (folder / 'run.py').write_bytes(Path(__file__).read_bytes())
    (folder / 'owner.py').write_bytes(raw)
    previous_cwd = Path.cwd()
    handlers = {number: signal.signal(number, owner.interrupted) for number in owner.SIGNALS}
    status = None
    errors = []
    try:
        os.chdir(ROOT)
        status, stdout, stderr = owner.run_owned(argv, seconds, folder / 'owned', env)
        print('\n'.join(stdout.splitlines()[-24:]), flush=True)
        print('\n'.join(stderr.splitlines()[-24:]), file=sys.stderr, flush=True)
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
    finally:
        try:
            after = inventory()
            record = json.loads((folder / 'owned/record.json').read_text())
            result = {'status': status, 'source_unchanged': before == after,
                      'tools_unchanged': tools == {name: digest(TOOLCHAIN / name) for name in tools},
                      'namespace_unchanged': namespace == os.readlink('/proc/self/ns/pid'),
                      'recorded_group_closed': record.get('group_absent') is True,
                      'errors': errors, 'scope': 'Development command only; no formal, native, '
                      'independent qualification or historical process-absence claim.'}
            save(folder / 'source-after.json', after)
            save(folder / 'result.json', result)
            print(json.dumps(result, sort_keys=True), flush=True)
            need(not errors and all(result[key] is True for key in (
                'source_unchanged', 'tools_unchanged', 'namespace_unchanged', 'recorded_group_closed')),
                'failed development continuity or process closure')
        finally:
            os.chdir(previous_cwd)
            for number, handler in handlers.items():
                signal.signal(number, handler)
    return status if type(status) is int and 0 <= status <= 255 else 1


if __name__ == '__main__':
    raise SystemExit(main())
