# Shared Disposal Group Developer Receipts

Source: aa8b5070e76cf662dfc94a7c042b4285ddc792a8
Parent: d291588cd99f75409ee9f0b82222436fdb9d14a2
Working directory: /home/harsh/.codex-tmp/fe2o3-r61-execution
Date: 2026-09-27

The final full suites and lint checks ran against the committed implementation.
The integration plan changed after testing; no behavioral code changed afterward.
Exit statuses below were observed through the execution tools.

| Log | Command | Exit | Result |
| --- | --- | --- | --- |
| model-final.log | `cargo test -p fe2o3-runtime-model --all-features` | 0 | 1070 passed, 19 ignored; 29 doctests passed |
| runtime-disposal-03.log | `cargo test -p fe2o3-runtime --all-features --lib context::tests::allocation_outcome_tests::disposal_tests` | 0 | 20 passed |
| clippy.log | `cargo clippy -p fe2o3-runtime-model -p fe2o3-runtime --all-features --all-targets -- -D warnings` | 0 | Passed |
| runtime-final.log | `cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1` | 101 | 1685 passed, 3 failed, 28 ignored |
| runtime-doc.log | `cargo test -p fe2o3-runtime --all-features --doc` | 0 | 52 doctests passed (8 merged, 44 separate) |
| model-minimal.log | `cargo check -p fe2o3-runtime-model --no-default-features` | 0 | Passed |
| fmt.log | `cargo fmt -p fe2o3-runtime-model -p fe2o3-runtime -- --check` | 0 | Passed |
| diff-check.log | `git diff --check` | 0 | Passed |
| source-signature.log | `git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD` | 0 | Source SSH signature verified |
| mi300x-probe.log | `ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x true` | 255 | DNS resolution failed |
| origin-probe.log | `git ls-remote origin refs/heads/codex/r65-runtime-drain-versions` | 128 | DNS resolution failed |
| upstream-probe.log | `git ls-remote upstream refs/heads/codex/r65-runtime-drain-versions` | 128 | DNS resolution failed |

The three runtime failures remain authorized_execution tests:
cooperative_debug_telemetry_emits_only_bounded_logical_records,
failed_session_end_is_explicit_and_terminal, and
pre_native_telemetry_failure_is_returned_and_poisoned.
All fail at authorized_execution.rs:1317 with InspectSocket(PermissionDenied).
They are not skipped, waived or counted as passing. Worker timing tests passed
in this serial run. Only the suites' existing ignored tests were ignored.

Development logs are retained but do not identify the final source:
model-focused.log passed 36 tests before two added flat-bound assertions.
runtime-disposal-01.log passed the original 13 tests with an unused_must_use
warning. runtime-disposal-02.log passed 13 and failed six new group tests because
their fixture supplied three seeds to a two-writer-capacity journal. The fixture
was corrected to two distinct seeds, and must_use warnings were fixed before
runtime-disposal-03.log. The third focused run precedes only comment/documentation
changes subsequently included in the full runtime and lint checks.

Two read-only agents reviewed flat evidence equivalence and Context group custody.
Both reported no correctness blocker. The frozen-root immutability invariant is
documented: root rosters and quiescence markers cannot change during a group;
public submission metadata may be released. Finalization rechecks every root.
This review is not machine-checked proof.

Runtime multi-root tests use genuine disjoint Unknown writers through private
multi-seed freeze. They qualify shared receipt accounting, not overlapping queued
Context admission. One deliberate missing-model-root injection tests retained
diagnostics and fail-stop handling, not actual native completion authority.

No Verus, mutation, relocation or authenticated proof campaign ran. No GPU or
matched HIP/HSA measurement ran. Failed host probes created no remote jobs/files.
The new group composition remains unproved and full parity remains open.
