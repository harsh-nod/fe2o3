# Diagnostic Builds

- Initial strict Clippy for the runtime library and tests passed before the final
  ordinary-readback resource-blocker regression was added. It is not the accepted
  final-source check.
- `diagnostic-01/build` began before the witness and the ordinary selected-copy
  blocker dispatch were frozen. Its source-continuity check is expected to reject
  that attempt; any tests using it are diagnostic only. The final qualification
  uses a fresh source-continuous build and complete suite.
- Its focused run passed the peer/compute continuation and native readback
  groups, but one new MockBackend test incorrectly expected unconditional stream
  destruction rejection. The mock legitimately supports conclusive cancellation
  on destruction. The repaired test explicitly selects `RejectStreamOnce` and
  checks all original pending operations, read leases, retains and versions.
  No production guard was weakened. `attempt-01/precheck` and all 32
  `attempt-01-after` source-control commands passed on the superseded test source.
- `attempt-02/precheck` passed after the test repair but before final metadata
  refresh. Proposal 02 correctly refused to regenerate over the already-applied
  proposal 01. Only our recorded proposal-01 metadata delta was reversed before
  preparing proposal 03 against the unchanged accepted baseline. These are not
  final-source acceptance artifacts.
- Attempt 03 focused tests exposed a second test snapshot error: readback
  admission correctly installs a pending writer and advances attempt epoch,
  so observations must preserve the post-admission state, not the prior state.
  The test now independently checks both that admission transition and final
  lineage advancement.
- The same run caught an existing native-owner corruption regression: generic
  resource-blocker selection intercepted corrupt native reservations outside
  their paired poison envelope. The new selector is now limited to staged legs;
  native XGMI owners continue through their existing paired failure envelope.
  All new backend readback and compute-prefix cases passed in that diagnostic
  run, including the independent sibling Read-phase case. Attempt 03 is rejected.
