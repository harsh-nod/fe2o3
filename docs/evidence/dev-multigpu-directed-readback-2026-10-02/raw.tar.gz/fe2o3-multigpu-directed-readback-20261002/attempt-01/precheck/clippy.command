cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --tests --no-deps -- -D warnings 
