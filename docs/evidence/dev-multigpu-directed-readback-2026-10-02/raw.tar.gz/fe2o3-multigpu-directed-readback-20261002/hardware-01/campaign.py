#!/usr/bin/env python3
"""Directed native readback pipelines in both orders plus matched source controls."""
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0xb7baafd0fb173d8e', '0x10a254ce4987e716', '0x53691ef168a0147d']
CARDS = ['card5', 'card6', 'card7']
BD = ['0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
BASELINE = None
CASES = [
    ('readback-chain-forward', 'directed', ['--readback'], IDS),
    ('readback-chain-reverse', 'directed', ['--readback'], IDS[::-1]),
    ('readback-fanout-forward', 'directed', ['--fanout', '--readback'], IDS),
    ('readback-fanout-reverse', 'directed', ['--fanout', '--readback'], IDS[::-1]),
    ('directed-chain-forward', 'directed', [], IDS),
    ('directed-chain-reverse', 'directed', [], IDS[::-1]),
    ('directed-fanout-forward', 'directed', ['--fanout'], IDS),
    ('directed-fanout-reverse', 'directed', ['--fanout'], IDS[::-1]),
    ('deferred-chain-forward', 'deferred', [], IDS[1:]),
    ('live-sharded-2', 'live-sharded', [], IDS[1:]),
]
LIMITATIONS = [
    'point observations, not continuous attachment census',
    'finite trusted-artifact qualification, not general kernel authority',
    'finite ordinary producer chain, not arbitrary dependency graph support',
    'compute may eagerly publish before explicit progress; physical overlap is unmeasured',
    'native completion counter is observed for directed, deferred and live cases',
    'live cases reuse logical handles; physical mapping identity is not independently observed',
    'live snapshots use serialized settled host reads, not drain-capture byte-credit ownership',
    'ACQUIRE_VM admission lasts until process exit; same-process reopen is unsupported',
    'directed copy cases observe postcopy source preservation; compute controls do not',
    'native faults, general kernel authority and physical overlap are not qualified',
    'directed copies are prequeued before native extraction, not in-flight root admission',
    'readback late admission follows bounded seed; native publication is not independently observed',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_receipt(name, argv):
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout = (folder / 'stdout').read_bytes()
    stderr = (folder / 'stderr').read_bytes()
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert receipt['exit_code'] == 0, (name, receipt, stderr)
    assert not receipt['timed_out'] and receipt['local_process_group_absent'], (name, receipt)
    return receipt, stdout, stderr


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    receipt, stdout, stderr = read_receipt(name, argv)
    assert process.returncode == receipt['exit_code'], (name, receipt, stderr)
    return stdout.decode()


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def remote(name, argv, bound='30s'):
    return capture(name, remote_argv(argv, bound))


def initial_baseline():
    receipt, stdout, stderr = read_receipt('initial-availability', remote_argv(AVAILABILITY))
    assert not stderr
    finished = datetime.fromisoformat(receipt['finished'])
    age = (datetime.now(timezone.utc) - finished).total_seconds()
    assert 0 <= age <= 300, 'initial availability is stale; capture a fresh campaign packet'
    return json.loads(stdout)


def admit(name):
    assert BASELINE is not None
    state = json.loads(remote(name + '-availability', AVAILABILITY))
    for card, uid, bdf in zip(CARDS, IDS, BD):
        assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bdf
        assert BASELINE[card]['Unique ID'] == uid and BASELINE[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == BASELINE[card]['GPU use (%)'] == '0'
        assert state[card]['VRAM Total Memory (B)'] == BASELINE[card]['VRAM Total Memory (B)']
        assert state[card]['VRAM Total Used Memory (B)'] == BASELINE[card]['VRAM Total Used Memory (B)']
    assert state['system'] == BASELINE['system'], 'changed PID roster; stop and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
        assert pid not in records and not {card.removeprefix('card') for card in CARDS}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system']), (records, state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    return state


@lru_cache(maxsize=1)
def global_digests():
    digests = tuple(sha(b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                               for global_index in range(65537)))
                    for round_index in (0, 1))
    assert digests[0] != digests[1]
    return digests


def expected(kind, flags, ids):
    if kind == 'directed':
        assert flags in ([], ['--fanout'], ['--readback'], ['--fanout', '--readback'])
        assert len(ids) == len(set(ids)) == 3
        fanout = '--fanout' in flags
        fields = dict(schema='fe2o3.directed-peer-copy-smoke.v1',
            authority='production-deny-all', transport='NATIVE-XGMI',
            mode='fanout' if fanout else 'chain', devices='3', unique_ids=','.join(ids),
            rounds='2', bytes_per_copy='8388581', peer_copies='4', native_packets='12',
            observed_native_copies='4', native_counter='0,2,4', allocations='6', streams='3',
            launches='0', modules='0', completion_receipts='4', readbacks='12',
            admission='both-before-progress', progress='final-directed-peer-only',
            first_seed='two-bounded-steps' if fanout else 'none',
            public_events='released-before-progress', pre_progress_observers='pending',
            expired_drain='rejected', journal='enabled', source_unchanged='full-byte-pass',
            destination_sentinels='full-byte-pass', output='full-byte-pass',
            round_sha256=','.join(directed_digests()), rounds_changed='true',
            allocation_reuse='true', contexts='1', drain='completed-only',
            cleanup='logical-and-native-explicit', physical_overlap='unmeasured',
            performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 37
        if '--readback' in flags:
            fields.update(schema='fe2o3.directed-peer-readback-smoke.v1',
                streams='4', completion_receipts='6', readbacks='16',
                admission='peers-before-progress', progress='readback-only-after-seed',
                public_events='released-after-readback-admission-before-tail-drive',
                drain='pending-readback-then-completed-peers', d2h_copies='2',
                readback_admission='before-progress,after-bounded-seed',
                readback_admission_native_counts='0,3', tail_seed_steps='2' if fanout else '3',
                publication_observed='false', readback_sentinels='full-byte-pass')
            assert len(fields) == 43
        return fields
    if kind == 'deferred':
        assert flags == [] and len(ids) == len(set(ids)) == 2
        output = b''.join(struct.pack('<f', (index & 63) / 4 + (index & 31))
                          for index in range(65536))
        assert len(output) == 262144
        fields = dict(schema='fe2o3.deferred-peer-chain-smoke.v1',
            authority='qualification-r57-n3-v2', devices='2', unique_ids=','.join(ids),
            elements='65536', bytes='262144', padding_bytes='0', launches='4',
            setup_launches='3', pipeline_launches='1', peer_copies='2',
            dependent_readbacks='1', completion_receipts='4',
            pipeline='peer-deferred-compute-peer-readback',
            admission='all-four-before-explicit-progress',
            compute_admission='deferred-before-first-peer-completion',
            progress='final-readback-stream-only',
            public_events='released-after-dependent-admission',
            native_transport='NATIVE-XGMI', native_counter='0,2',
            initial_peer_sentinel='full-byte-pass', final_peer_sentinel='full-byte-pass',
            output='full-byte-pass', padding='exact-page-extent', output_sha256=sha(output),
            snapshot='settled-host-visible-owner-command', host_output_installations='0',
            journal='enabled', retained_results='4', allocations='12', modules='2',
            streams='5', contexts='1', owners='1', pipeline_host_joins='0',
            results_release='readback-peer-compute-peer', final_drain='completed-only',
            cleanup='owned-shutdown-explicit', source_preservation='unobserved',
            physical_overlap='unmeasured', performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 42
        return fields
    count = len(ids)
    assert 2 <= count <= 8 and len(set(ids)) == count
    quotient, remainder = divmod(65537, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    padded = [((size * 4 + 4095) // 4096) * 4096 for size in sizes]
    assert sum(sizes) == 65537 and offsets[-1] + sizes[-1] == 65537
    assert all(size > 0 for size in sizes) and sum(padded) <= 286720
    ranges = ','.join(f'{offset}:{size}:{physical}'
                      for offset, size, physical in zip(offsets, sizes, padded))
    if kind == 'live-sharded':
        assert flags == []
        # Full source-shard-order snapshots include untouched f32(-1) padding.
        full_digests = []
        for round_index in (0, 1):
            chunks = []
            for offset, size, physical in zip(offsets, sizes, padded):
                logical = b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                                   for global_index in range(offset, offset + size))
                chunks.append(logical + struct.pack('<f', -1) * ((physical - len(logical)) // 4))
            full = b''.join(chunks)
            assert len(full) == sum(padded)
            full_digests.append(sha(full))
        fields = dict(
            schema='fe2o3.live-sharded-vecadd-smoke.v1',
            authority='qualification-sharded-vecadd-rounds-v1', devices=str(count),
            unique_ids=','.join(ids), rounds='2', logical_elements_per_round='65537',
            logical_bytes_per_round='262148', shard_ranges=ranges,
            padded_bytes_per_round=str(sum(padded)), launches=str(2 * count),
            peer_copies=str(2 * count), dependent_readbacks=str(2 * count),
            completion_receipts=str(6 * count), batch_admission='one-owner-command',
            compute_api='producer-aware', compute_dependency='exact-event',
            compute_admission='may-publish-before-progress', compute_progress='dependent-readback-streams',
            journal='enabled', host_output_installations='0', input_refresh='full-padded-per-batch',
            incoming_sentinel='full-byte-pass', output='full-byte-pass', padding='full-byte-pass',
            coverage='exact-contiguous-disjoint', round0_sha256=global_digests()[0],
            round1_sha256=global_digests()[1], round0_padded_sha256=full_digests[0],
            round1_padded_sha256=full_digests[1], native_transport='authenticated-pending-peer',
            native_counter=f'0,{count},{2 * count}', stable_handles='logical-only', contexts='1',
            owners='1', allocation_reuse='true', module_reuse='true', kernel_reuse='true',
            stream_reuse='true', public_events='released-after-admission',
            batch_results='released-before-refresh', intermediate_cutoffs='0',
            snapshot='settled-host-visible-owner-command', snapshot_byte_bound='286720',
            reply_credits_after_batches='0', deadline_resumption='same-command-future',
            final_drain='completed-only', cleanup='owned-shutdown-explicit',
            source_preservation='unobserved', physical_overlap='unmeasured',
            performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 51
        return fields
    assert kind == 'compute-sharded' and flags in (
        ['--queued-compute', '--round', '0'], ['--queued-compute', '--round', '1'])
    round_index = int(flags[2])
    fields = dict(
        schema='fe2o3.sharded-vecadd-queued-capture-smoke.v1',
        authority='qualification-sharded-vecadd-v1', devices=str(count),
        unique_ids=','.join(ids), round=str(round_index), rounds='1',
        logical_elements='65537', logical_bytes='262148', shard_ranges=ranges,
        padded_bytes=str(sum(padded)), launches=str(count), compute_receipts=str(count),
        transfer_receipts=str(2 * count), completion_receipts=str(3 * count),
        compute_admission='may-publish-before-cutoff', compute_join='owned-drain',
        compute_api='producer-aware', compute_dependency='exact-event',
        compute_progress='dependent-readback-streams', retained_submissions=str(3 * count),
        peer_copies=str(count), dependent_readbacks=str(count), capture_ranges=str(count),
        captured_bytes=str(sum(padded)), abi_bytes='48', kernel='vecadd', journal='enabled',
        host_output_installations='0', c_initial='-1', incoming_sentinel='full-byte-pass',
        output='full-byte-pass', padding='full-byte-pass', coverage='exact-contiguous-disjoint',
        global_sha256=global_digests()[round_index],
        admission='all-transfers-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_preservation='unobserved', allocation_reuse='false', contexts='one-per-process',
        drain='pending-group', capture='coherent-host-group', physical_overlap='unmeasured',
        cleanup='owned-shutdown-explicit', performance_acceptance='false', formal_refinement='false')
    assert len(fields) == 49
    return fields


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in fields
        fields[key] = value
    return fields


@lru_cache(maxsize=1)
def directed_digests():
    mask = (1 << 64) - 1
    digests = [hashlib.sha256(), hashlib.sha256()]
    for start in range(0, 8388581, 8192):
        block = bytearray()
        for index in range(start, min(start + 8192, 8388581)):
            value = (index + 0x9e3779b97f4a7c15) & mask
            value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
            value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
            block.append((value ^ (value >> 31)) & 255)
        digests[0].update(block)
        digests[1].update(bytes(byte ^ 73 for byte in block))
    return tuple(digest.hexdigest() for digest in digests)


def main():
    global BASELINE
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) in (1, 2)
    attempt = sys.argv[1] if len(sys.argv) == 2 else 'attempt-01'
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert not (ROOT / 'campaign.json').exists()
    BASELINE = initial_baseline()
    checks = ROOT.parent / attempt / 'checks'
    binaries = {}
    for kind, receipt, basename in [
        ('directed', 'directed-witness.sha256', 'gfx942-runtime-directed-peer-copy-smoke'),
        ('deferred', 'deferred-witness.sha256', 'gfx942-runtime-deferred-peer-chain-smoke'),
        ('live-sharded', 'live-sharded-witness.sha256', 'gfx942-runtime-live-sharded-vecadd-smoke')]:
        digest, path = (checks / receipt).read_text().strip().split(maxsplit=1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest)
        local = REPO / path
        assert local == REPO / 'target/debug/examples' / basename
        assert sha(local.read_bytes()) == digest
        binaries[kind] = dict(local=str(local), sha256=digest)
    completed, errors = [], []
    directory = None
    cleaned = False
    try:
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-directed-readback-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-multigpu-directed-readback-20261002-[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
            capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            hashed = remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
            assert hashed.split() == [binary['sha256'], binary['remote']]
        for name, kind, flags, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8',
                binaries[kind]['remote'], *flags, *ids], '180s')
            fields = pass_fields(output)
            required = expected(kind, flags, ids)
            assert fields == required, (name, fields, required)
            assert not (ROOT / name / 'stderr').read_bytes()
            admit(name + '-post')
            completed.append(dict(name=name, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [directory + '/' + kind + '-witness' for kind in binaries]
                probe = ('import json,os,sys; from pathlib import Path; '
                    'paths=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    if 'remote' in binary:
                        try:
                            hashed = remote('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
                            assert hashed.split() == [binary['sha256'], binary['remote']]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        try:
            admit('final')
        except Exception as error:
            errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            selected_build_attempt=attempt, owned_directory=directory,
            owned_cleanup_complete=cleaned, exclusive_reservation=False,
            performance_acceptance=False, formal_refinement=False, limitations=LIMITATIONS)
        with (ROOT / 'campaign.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
