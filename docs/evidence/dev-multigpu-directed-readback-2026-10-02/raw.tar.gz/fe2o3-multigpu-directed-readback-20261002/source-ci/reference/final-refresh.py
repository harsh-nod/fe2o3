#!/usr/bin/env python3
"""Audit the declared final test/formatting delta and propose three identity refreshes."""
import ast
import copy
import difflib
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
V = Path('crates/fe2o3-runtime-model/verus')
BASE = 'f97257ed84c8a39e82a27955cd3f146df0d16781'
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
report = json.loads((OUT / 'metadata-report.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def once(text, before, after):
    assert text.count(before) == 1
    return text.replace(before, after)


def load(name, text):
    module = types.ModuleType('final_' + name.replace('-', '_').replace('.', '_'))
    module.__file__ = str(ROOT / V / name)
    sys.modules[module.__name__] = module
    exec(compile(text, module.__file__, 'exec'), module.__dict__)
    return module


declared_tests = {
    'crates/fe2o3-kfd/src/queue_live/rebind_tests/insertion.rs',
    'crates/fe2o3-kfd/src/queue_live/construction_primary/integration_sdma_public_allocation_tests.rs',
}
declared_formatting = {
    'crates/fe2o3-kfd/src/queue_live/compute_xgmi.rs',
    'crates/fe2o3-kfd/src/queue_live/compute_xgmi/transfer.rs',
}
current = {path: sha((ROOT / path).read_bytes()) for path in report['audited_source_sha256']}
changed = {path for path, digest in current.items() if digest != report['audited_source_sha256'][path]}
assert changed == declared_tests | declared_formatting, sorted(changed)
for source_root in ('fe2o3-kfd', 'fe2o3-runtime', 'fe2o3-runtime-model', 'fe2o3-resource-accounting'):
    prefix = f'crates/{source_root}/src/'
    assert {str(path.relative_to(ROOT)) for path in (ROOT / prefix).rglob('*.rs')} == {
        path for path in current if path.startswith(prefix) and path.endswith('.rs')}
for path, digest in report['proof_files'].items():
    assert current[path] == digest

delta = []
for path in sorted(changed):
    text = (ROOT / path).read_text()
    if path in declared_tests:
        previous = subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT).decode()
        assert sha(previous.encode()) == report['audited_source_sha256'][path]
        scope = 'declared KFD test-only assertion/fixture change'
    elif path.endswith('/compute_xgmi.rs'):
        previous = once(text,
                        '#[path = "compute_xgmi/persistent.rs"]\nmod persistent;\n#[path = "compute_xgmi/transfer.rs"]\nmod transfer;',
                        '#[path = "compute_xgmi/transfer.rs"]\nmod transfer;\n#[path = "compute_xgmi/persistent.rs"]\nmod persistent;')
        scope = 'rustfmt module declaration ordering only'
    else:
        formatting = (
            ('pub(super) fn exact_extent(\n    source: u64,\n    destination: u64,\n) -> Result<u32, ComputeAqlQueueSessionErrorV1> {',
             'pub(super) fn exact_extent(source: u64, destination: u64) -> Result<u32, ComputeAqlQueueSessionErrorV1> {'),
            ('root.core\n                        .run(source, destination, &mut self.queue, timeout)',
             'root.core.run(source, destination, &mut self.queue, timeout)'),
            ('        })\n    }\n}\n\nfn require_data(',
             '        })\n    }\n\n}\n\nfn require_data('),
        )
        matches = []
        for applied in itertools.product((False, True), repeat=len(formatting)):
            candidate = text
            for selected, (before, after) in zip(applied, formatting):
                if selected:
                    candidate = once(candidate, before, after)
            if sha(candidate.encode()) == report['audited_source_sha256'][path]:
                matches.append(candidate)
        assert len(matches) == 1, 'unique exact whitespace-only attempt01 preimage'
        previous = matches[0]
        scope = 'rustfmt whitespace/line wrapping only'
    assert sha(previous.encode()) == report['audited_source_sha256'][path], path
    delta.append(dict(path=path, old_sha256=sha(previous.encode()), new_sha256=sha(text.encode()),
                      scope=scope, exact_prior_preimage_verified=True,
                      unified_diff=''.join(difflib.unified_diff(previous.splitlines(True), text.splitlines(True),
                                                              fromfile='attempt01/' + path, tofile='final/' + path))))

names = ('check-retained-credit-dispatch.py', 'check-retained-pair-owned-storage.py',
         'check-retained-pair-post-catch.py')
proposals, hash_edits = {}, []
for name in names:
    original = (ROOT / V / name).read_text()
    earlier = next(row for row in report['changes'] if row['path'] == str(V / name))
    assert sha(original.encode()) == earlier['proposed_sha256']
    module = load(name, original)
    sources = module.snapshot()
    implementation = {path: text for path, text in sources.items() if path != module.PROOF}
    new_hash = module.tree_hash(implementation)
    old_hash = module.SOURCE_TREE_SHA
    assert old_hash != new_hash and original.count(old_hash) == 1
    try:
        module.audit(sources)
    except ValueError as error:
        original_failure = str(error)
    else:
        raise AssertionError('changed whole-KFD source identity must be rejected before refresh')
    module.SOURCE_TREE_SHA = new_hash
    module.audit(sources)
    proposed = original.replace(old_hash, new_hash)
    tree = ast.parse(original)
    assignment = [node for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'SOURCE_TREE_SHA'
                          for target in node.targets)]
    assert len(assignment) == 1 and assignment[0].value.value == old_hash
    assignment[0].value.value = new_hash
    assert ast.dump(tree, include_attributes=False) == ast.dump(ast.parse(proposed), include_attributes=False)
    proposals[name] = proposed
    hash_edits.append(dict(path=str(V / name), old=old_hash, new=new_hash,
                           original_sha256=sha(original.encode()), proposed_sha256=sha(proposed.encode()),
                           original_audit_failure=original_failure, refreshed_audit_passed=True))

final_guard_rows = []
for row in report['changes']:
    name = Path(row['path']).name
    original = (OUT / 'originals' / name).read_bytes()
    final = proposals.get(name, (ROOT / row['path']).read_text())
    expected = ast.parse(original)
    constants = {(node.lineno, node.col_offset): node for node in ast.walk(expected)
                 if isinstance(node, ast.Constant)}
    for edit in row['edits']:
        node = constants[edit['line'], edit['column']]
        assert node.value == edit['old']
        later = next((change for change in hash_edits if change['path'] == row['path']), None)
        node.value = later['new'] if later and edit['selector'] == 'SOURCE_TREE_SHA' else edit['new']
    assert ast.dump(expected, include_attributes=False) == ast.dump(ast.parse(final), include_attributes=False)
    final_guard_rows.append(dict(path=row['path'], final_sha256=sha(final.encode()),
                                 ast_identical_except_original_approved_metadata_nodes=True))

assert all(sha((ROOT / path).read_bytes()) == digest for path, digest in current.items())
patch = ['*** Begin Patch\n']
for name, final in proposals.items():
    original = (ROOT / V / name).read_text()
    patch.append('*** Update File: ' + str(ROOT / V / name) + '\n')
    patch.extend('@@\n' if line.startswith('@@ ') else line
                 for line in list(difflib.unified_diff(original.splitlines(True), final.splitlines(True), n=3))[2:])
patch.append('*** End Patch\n')
(OUT / 'final-metadata.patch').write_text(''.join(patch))
result = dict(baseline=BASE, parent_metadata_report_sha256=sha((OUT / 'metadata-report.json').read_bytes()),
              declared_source_delta=delta, audited_source_sha256=current,
              unchanged_executable_proof_files=len(report['proof_files']),
              runtime_source_roster_unchanged=True, hash_refreshes=hash_edits,
              final_guard_rows=final_guard_rows, total_changed_metadata_hash_literals=19,
              total_changed_source_inventory_literals=7, no_other_guard_ast_change=True,
              solver_executed=False, build_executed=False, formal_qualification=False)
(OUT / 'final-metadata-report.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(declared_changed_source_files=len(changed), exact_prior_preimages_verified=True,
                     refreshed_hash_constants=len(hash_edits), total_hash_constants=19,
                     total_inventory_constants=7, unchanged_proof_files=len(report['proof_files']),
                     all_proposed_source_audits_passed=True), sort_keys=True))
