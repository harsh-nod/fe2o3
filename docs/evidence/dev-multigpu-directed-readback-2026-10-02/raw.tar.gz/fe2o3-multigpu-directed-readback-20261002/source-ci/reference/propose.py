#!/usr/bin/env python3
"""Audit source-identity metadata without modifying guards or executing a solver."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = 'f97257ed84c8a39e82a27955cd3f146df0d16781'
V = Path('crates/fe2o3-runtime-model/verus')
RUNTIME = Path('crates/fe2o3-runtime/src')
GUARDS = (
    'check-request-charge.py',
    'check-retained-credit-dispatch.py',
    'check-retained-pair-owned-storage.py',
    'check-retained-pair-post-catch.py',
    'check-retained-pair-cadence.py',
    'check-producer-input-fold.py',
    'check-producer-input-validate.py',
    'check-producer-journal-observers.py',
    'check-retained-pair-routing.py',
    'check-producer-input-composition.py',
    'check-producer-journal-composition.py',
)


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*arguments, input=None):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *arguments], cwd=ROOT, input=input)


def blobs(paths):
    paths = sorted(paths)
    raw = git('cat-file', '--batch', input=''.join(f'{BASE}:{path}\n' for path in paths).encode())
    offset, result = 0, {}
    for path in paths:
        end = raw.index(b'\n', offset)
        _oid, kind, size = raw[offset:end].split()
        need(kind == b'blob', f'ordinary baseline blob: {path}')
        size, offset = int(size), end + 1
        result[path] = raw[offset:offset + size].decode()
        offset += size
        need(raw[offset:offset + 1] == b'\n', 'complete baseline blob delimiter')
        offset += 1
    need(offset == len(raw), 'complete baseline batch')
    return result


def load(name, source):
    module = types.ModuleType('metadata_' + name.replace('-', '_').replace('.', '_'))
    module.__file__ = str(ROOT / V / name)
    sys.modules[module.__name__] = module
    exec(compile(source, module.__file__, 'exec'), module.__dict__)
    return module


class MetadataEdits:
    def __init__(self, source):
        self.source = source
        self.tree = ast.parse(source)
        self.edits = []

    def constant(self, node, value, category, selector, rationale):
        need(isinstance(node, ast.Constant), 'only literal metadata values')
        if node.value == value:
            return
        if category == 'content-sha256':
            need(all(isinstance(item, str) and len(item) == 64
                     and all(letter in '0123456789abcdef' for letter in item)
                     for item in (node.value, value)), 'exact SHA-256 identity values')
        else:
            need(category == 'source-inventory-count'
                 and type(node.value) is type(value) is int and value > 0,
                 'positive exact source-inventory cardinality')
        self.edits.append(dict(line=node.lineno, column=node.col_offset,
                               end_line=node.end_lineno, end_column=node.end_col_offset,
                               old=node.value, new=value, category=category,
                               selector=selector, rationale=rationale))

    def assignment(self, name, value, category, rationale):
        selected = [node.value for node in self.tree.body
                    if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == name
                            for target in node.targets)]
        need(len(selected) == 1, 'unique metadata assignment: ' + name)
        self.constant(selected[0], value, category, name, rationale)

    def pin(self, name, key, value):
        dictionaries = [node.value for node in self.tree.body
                        if isinstance(node, ast.Assign)
                        and any(isinstance(target, ast.Name) and target.id == name
                                for target in node.targets)]
        need(len(dictionaries) == 1 and isinstance(dictionaries[0], ast.Dict), 'exact pin dictionary')
        selected = [node for candidate, node in zip(dictionaries[0].keys, dictionaries[0].values)
                    if isinstance(candidate, ast.Constant) and candidate.value == key]
        need(len(selected) == 1, 'unique helper identity: ' + key)
        self.constant(selected[0], value, 'content-sha256', f'{name}[{key!r}]',
                      'transitive identity of the metadata-only refreshed source guard')

    def compare_count(self, variable, value):
        selected = [node.comparators[0] for node in ast.walk(self.tree)
                    if isinstance(node, ast.Compare) and len(node.ops) == 1
                    and isinstance(node.ops[0], ast.Eq)
                    and isinstance(node.left, ast.Call) and isinstance(node.left.func, ast.Name)
                    and node.left.func.id == 'len' and len(node.left.args) == 1
                    and isinstance(node.left.args[0], ast.Name) and node.left.args[0].id == variable
                    and isinstance(node.comparators[0], ast.Constant)]
        need(len(selected) == 1, 'unique exact inventory comparison: ' + variable)
        self.constant(selected[0], value, 'source-inventory-count', f'len({variable}) == literal',
                      'actual complete runtime Rust roster; equality predicate unchanged')

    def assert_count(self, variable, value):
        selected = [node.args[1] for node in ast.walk(self.tree)
                    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and node.func.attr == 'assertEqual' and len(node.args) == 2
                    and isinstance(node.args[0], ast.Call) and isinstance(node.args[0].func, ast.Name)
                    and node.args[0].func.id == 'len' and len(node.args[0].args) == 1
                    and isinstance(node.args[0].args[0], ast.Name)
                    and node.args[0].args[0].id == variable]
        need(len(selected) == 1, 'unique exact inventory test: ' + variable)
        self.constant(selected[0], value, 'source-inventory-count', f'assertEqual(len({variable}), literal)',
                      'duplicate exact source-inventory cardinality; assertion unchanged')

    def proposed(self):
        source = self.source
        lines = source.splitlines(keepends=True)
        offsets, cursor = [], 0
        for line in lines:
            offsets.append(cursor)
            cursor += len(line)
        for edit in sorted(self.edits, key=lambda row: (row['line'], row['column']), reverse=True):
            start = offsets[edit['line'] - 1] + edit['column']
            end = offsets[edit['end_line'] - 1] + edit['end_column']
            replacement = json.dumps(edit['new'])
            source = source[:start] + replacement + source[end:]
        expected = copy.deepcopy(self.tree)
        nodes = {(node.lineno, node.col_offset): node for node in ast.walk(expected)
                 if isinstance(node, ast.Constant)}
        for edit in self.edits:
            node = nodes[edit['line'], edit['column']]
            need(node.value == edit['old'], 'AST edit exact preimage')
            node.value = edit['new']
        need(ast.dump(expected, include_attributes=False) == ast.dump(ast.parse(source), include_attributes=False),
             'AST identical except individually approved metadata constant nodes')
        return source


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize,
         'run python3 -I -B without optimized assertions')
    need(git('rev-parse', 'HEAD').decode().strip() == BASE, 'exact accepted baseline HEAD')
    baseline_paths = {Path(name) for name in git('ls-tree', '-r', '--name-only', '-z', BASE)
                      .decode().split('\0') if name}
    modules, proposed, changes, proof_files, audited = {}, {}, [], {}, {}
    originals = OUT / 'originals'
    originals.mkdir()

    def record(name, original, edits, extra):
        result = edits.proposed()
        (originals / name).write_text(original)
        proposed[name] = result
        changes.append(dict(path=str(V / name), original_sha256=sha(original.encode()),
                            proposed_sha256=sha(result.encode()), edits=edits.edits, **extra))
        return result

    for name in GUARDS:
        relative = V / name
        original = (ROOT / relative).read_text()
        need(original == blobs([relative])[relative], 'unchanged accepted guard: ' + name)
        old = load(name, original)
        candidate = old.snapshot()
        baseline = blobs(set(candidate) & baseline_paths)
        source_paths = getattr(old, 'source_paths', None)
        if source_paths:
            old.source_paths = lambda: set(baseline)
        old.audit(baseline)
        if source_paths:
            old.source_paths = source_paths
        try:
            old.audit(candidate)
            opening_audit = {'passed': True}
        except Exception as error:
            opening_audit = {'passed': False, 'error': repr(error)}
        files = old.FILES if hasattr(old, 'FILES') else old.files()
        need(all(baseline[path] == candidate[path] for path in files),
             'unchanged complete executable proof closure: ' + name)
        proof_files.update({str(path): sha(candidate[path].encode()) for path in files})
        audited.update({str(path): sha(text.encode()) for path, text in candidate.items()})
        edits = MetadataEdits(original)
        if hasattr(old, 'SOURCE_TREE_SHA'):
            if name in ('check-producer-input-fold.py', 'check-retained-pair-routing.py'):
                implementation = {path: text for path, text in candidate.items() if path.is_relative_to(old.SRC)}
            elif name == 'check-producer-input-validate.py':
                implementation = {path: text for path, text in candidate.items()
                                  if path.is_relative_to(old.SRC) or path in old.DECLARATIONS}
            else:
                implementation = {path: text for path, text in candidate.items() if path != old.PROOF}
            edits.assignment('SOURCE_TREE_SHA', old.tree_hash(implementation), 'content-sha256',
                             'identity of the unchanged complete source roster selection')
            if hasattr(old, 'SOURCE_FILES'):
                edits.assignment('SOURCE_FILES', len(implementation), 'source-inventory-count',
                                 'exact selected Rust source roster, not solver or mutation count')
        elif hasattr(old, 'RUNTIME_SHA'):
            implementation = {path: text for path, text in candidate.items() if path.is_relative_to(old.RUNTIME)}
            edits.assignment('RUNTIME_SHA', old.tree_hash(implementation), 'content-sha256',
                             'identity of complete runtime Rust source roster')
            edits.assignment('RUNTIME_FILES', len(implementation), 'source-inventory-count',
                             'exact complete runtime Rust roster, not solver or mutation count')
        elif hasattr(old, 'PINS'):
            need(all(sha(candidate[path].encode()) == digest for path, digest in old.PINS.items()),
                 'unaffected cadence source pins remain exact')
        for attribute in ('CHECKER_PINS', 'HELPERS'):
            if hasattr(old, attribute):
                for helper in getattr(old, attribute):
                    edits.pin(attribute, helper, sha(proposed[helper].encode()))
        if name == 'check-producer-input-composition.py':
            edits.compare_count('implementation', sum(path.is_relative_to(RUNTIME) for path in candidate))
        text = record(name, original, edits, dict(opening_current_source_audit=opening_audit,
                      baseline_audit_passed=True, proof_closure_unchanged=True,
                      proof_files=[str(path) for path in files],
                      expected_verified=getattr(old, 'EXPECTED_VERIFIED', None),
                      mutant_count=getattr(old, 'MUTANT_COUNT', None)))
        new = load(name, text)
        if hasattr(new, 'load_checker'):
            new.load_checker = lambda helper: modules[helper]
        if hasattr(new, 'helper'):
            new.helper = lambda helper: modules[helper]
        new.audit(candidate)
        modules[name] = new

    name = 'test-producer-input-composition.py'
    original = (ROOT / V / name).read_text()
    need(original == blobs([V / name])[V / name], 'unchanged duplicate identity tests')
    edits = MetadataEdits(original)
    fold, leaf = modules['check-producer-input-fold.py'], modules['check-producer-input-validate.py']
    edits.assignment('NATIVE_TREE_SHA', fold.SOURCE_TREE_SHA, 'content-sha256', 'duplicate complete runtime identity')
    edits.assignment('SCHEMA_TREE_SHA', leaf.SOURCE_TREE_SHA, 'content-sha256', 'duplicate runtime plus five-schema identity')
    for helper in ('check-producer-input-validate.py', 'check-producer-input-fold.py', 'check-producer-input-composition.py'):
        edits.pin('CHECKER_PINS', helper, sha(proposed[helper].encode()))
    edits.assert_count('native', fold.SOURCE_FILES)
    edits.assert_count('with_schemas', leaf.SOURCE_FILES)
    record(name, original, edits, {})

    name = 'producer-journal-composition-mutations-v1.py'
    original = (ROOT / V / name).read_text()
    need(original == blobs([V / name])[V / name], 'unchanged mutation controller')
    edits = MetadataEdits(original)
    edits.assignment('GUARD_SHA', sha(proposed['check-producer-journal-composition.py'].encode()),
                     'content-sha256', 'transitive metadata-only guard identity; mutation roster unchanged')
    record(name, original, edits, {})

    need(all(sha((ROOT / path).read_bytes()) == digest for path, digest in audited.items()),
         'all audited production inputs remained unchanged during proposal')
    need(git('rev-parse', 'HEAD').decode().strip() == BASE, 'baseline HEAD unchanged')
    patch = ['*** Begin Patch\n']
    for name, text in proposed.items():
        original = (originals / name).read_text()
        if original != text:
            patch.append('*** Update File: ' + str(ROOT / V / name) + '\n')
            patch.extend(list(difflib.unified_diff(original.splitlines(True), text.splitlines(True), n=3))[2:])
    patch.append('*** End Patch\n')
    (OUT / 'metadata.patch').write_text(''.join(patch))
    report = dict(baseline=BASE, changes=changes, proof_files=proof_files,
                  audited_source_sha256=audited, all_baseline_audits_passed=True,
                  all_proposed_source_audits_passed=True, proof_closures_unchanged=True,
                  predicates_contracts_and_proof_counts_unchanged=True,
                  ast_identical_except_listed_metadata_constants=True,
                  solver_executed=False, build_executed=False, formal_qualification=False,
                  runtime_source_files=fold.SOURCE_FILES, runtime_and_schema_files=leaf.SOURCE_FILES)
    (OUT / 'metadata-report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(changed_files=sum(bool(row['edits']) for row in changes),
                         hash_constants=sum(edit['category'] == 'content-sha256'
                                            for row in changes for edit in row['edits']),
                         source_inventory_constants=sum(edit['category'] == 'source-inventory-count'
                                                        for row in changes for edit in row['edits']),
                         unchanged_proof_files=len(proof_files), audited_source_files=len(audited),
                         runtime_source_files=fold.SOURCE_FILES, runtime_and_schema_files=leaf.SOURCE_FILES)))


if __name__ == '__main__':
    main()
