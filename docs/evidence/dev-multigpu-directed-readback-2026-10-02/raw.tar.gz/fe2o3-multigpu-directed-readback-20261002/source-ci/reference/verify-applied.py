#!/usr/bin/env python3
"""Check the applied guard edits against exact recorded metadata AST nodes."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
report = json.loads((OUT / 'metadata-report.json').read_bytes())
for row in report['changes']:
    original = (OUT / 'originals' / Path(row['path']).name).read_bytes()
    current = (ROOT / row['path']).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row['original_sha256']
    assert hashlib.sha256(current).hexdigest() == row['proposed_sha256']
    expected = ast.parse(original)
    nodes = {(node.lineno, node.col_offset): node for node in ast.walk(expected)
             if isinstance(node, ast.Constant)}
    for edit in row['edits']:
        node = nodes[edit['line'], edit['column']]
        assert node.value == edit['old']
        assert edit['category'] in ('content-sha256', 'source-inventory-count')
        node.value = edit['new']
    assert ast.dump(expected, include_attributes=False) == ast.dump(ast.parse(current), include_attributes=False)
for path, digest in report['proof_files'].items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
for path, digest in report['audited_source_sha256'].items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
assert len(list((ROOT / 'crates/fe2o3-runtime/src').rglob('*.rs'))) == report['runtime_source_files']
result = dict(recorded_utc_ns=time.time_ns(),
              applied_guard_hashes_match_proposal=True,
              ast_identical_except_recorded_metadata_literals=True,
              unchanged_proof_files=len(report['proof_files']),
              unchanged_audited_source_files=len(report['audited_source_sha256']),
              changed_files=sum(bool(row['edits']) for row in report['changes']),
              hash_constants=sum(edit['category'] == 'content-sha256'
                                 for row in report['changes'] for edit in row['edits']),
              source_inventory_constants=sum(edit['category'] == 'source-inventory-count'
                                             for row in report['changes'] for edit in row['edits']),
              solver_executed=False, build_executed=False, formal_qualification=False)
(OUT / 'applied-audit.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
