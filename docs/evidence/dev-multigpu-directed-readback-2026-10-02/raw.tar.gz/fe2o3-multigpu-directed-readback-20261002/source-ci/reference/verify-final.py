#!/usr/bin/env python3
"""Verify applied final identities without rewriting any earlier audit record."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
raw_parent = (OUT / 'metadata-report.json').read_bytes()
parent = json.loads(raw_parent)
final = json.loads((OUT / 'final-metadata-report.json').read_bytes())
assert hashlib.sha256(raw_parent).hexdigest() == final['parent_metadata_report_sha256']
for row in final['final_guard_rows']:
    assert hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() == row['final_sha256']
for path, digest in final['audited_source_sha256'].items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
for path, digest in parent['proof_files'].items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
print(json.dumps(dict(recorded_utc_ns=time.time_ns(), exact_final_applied_guard_bytes=True,
                      audited_source_files=len(final['audited_source_sha256']),
                      unchanged_proof_files=len(parent['proof_files']),
                      historical_metadata_report_unchanged=True,
                      total_metadata_hash_literals=19, total_source_inventory_literals=7,
                      solver_executed=False, build_executed=False,
                      formal_qualification=False), sort_keys=True))
