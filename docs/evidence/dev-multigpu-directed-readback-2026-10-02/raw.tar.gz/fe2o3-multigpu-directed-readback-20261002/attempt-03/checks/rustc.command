rustc +nightly-2026-04-03 --version --verbose 
