cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --example gfx942-runtime-pending-peer-capture-smoke -- --test-threads=1 
