uname -a 
