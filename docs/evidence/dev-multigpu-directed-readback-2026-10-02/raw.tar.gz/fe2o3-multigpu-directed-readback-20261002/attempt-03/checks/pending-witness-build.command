cargo +nightly-2026-04-03 build --locked --offline -p fe2o3-runtime --profile test --example gfx942-runtime-pending-peer-capture-smoke 
