cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-runtime --no-default-features --example gfx942-runtime-directed-peer-copy-smoke --no-deps -- -D warnings 
