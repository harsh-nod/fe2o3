cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --no-default-features --example gfx942-runtime-directed-peer-copy-smoke -- --test-threads=1 
