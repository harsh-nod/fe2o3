cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --all-features --example gfx942-runtime-deferred-peer-chain-smoke -- --test-threads=1 
