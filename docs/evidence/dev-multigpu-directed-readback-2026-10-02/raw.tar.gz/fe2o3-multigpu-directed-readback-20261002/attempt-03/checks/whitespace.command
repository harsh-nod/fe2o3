git diff HEAD --check 
