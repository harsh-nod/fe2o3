cargo +nightly-2026-04-03 build --locked --offline -p fe2o3-runtime --no-default-features --profile test --example gfx942-runtime-peer-copy-smoke 
