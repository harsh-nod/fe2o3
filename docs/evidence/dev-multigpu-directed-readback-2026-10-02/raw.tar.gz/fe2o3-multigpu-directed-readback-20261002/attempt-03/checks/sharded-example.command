cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --example gfx942-runtime-sharded-peer-copy-smoke -- --test-threads=1 
