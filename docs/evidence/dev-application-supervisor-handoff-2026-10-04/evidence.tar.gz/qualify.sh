#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-application-transfer-20261004-LaSGitdl
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
run() {
    local label=$1
    shift
    timeout --kill-after=15s 900s "$@" 2>&1 | tee "$out/$label.log"
}
git ls-files --cached --others --exclude-standard -z -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**' |
    LC_ALL=C sort -z | xargs -0 sha256sum > "$out/source-before.sha256"
run runtime-tests cargo +nightly-2026-04-03 test --offline --locked -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p fe2o3-broker-authority-service --tests -- --test-threads=1
run cargo-tests cargo +nightly-2026-04-03 test --offline --locked -p cargo-fe2o3 --bins -- --test-threads=1
run doc-tests cargo +nightly-2026-04-03 test --offline --locked -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p fe2o3-broker-authority-service --doc
run clippy cargo +nightly-2026-04-03 clippy --offline --locked -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p fe2o3-broker-authority-service -p cargo-fe2o3 --all-targets --no-deps -- -D warnings
run format cargo +nightly-2026-04-03 fmt -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -- --check
run whitespace git diff --check
git ls-files --cached --others --exclude-standard -z -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**' |
    LC_ALL=C sort -z | xargs -0 sha256sum > "$out/source-after.sha256"
cmp "$out/source-before.sha256" "$out/source-after.sha256"
run frozen-source sha256sum --check "$out/source-before.sha256"
