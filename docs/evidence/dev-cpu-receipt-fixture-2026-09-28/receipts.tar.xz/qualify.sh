#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-cpu-receipt-fixture-20260928-Cmarc9Mt
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
failed=0
run() {
    local name=$1
    shift
    printf '%s ' "$name" >> "$raw/qualification.status"
    printf '%q ' "$@" > "$raw/$name.command"
    printf '\n' >> "$raw/$name.command"
    date -u +%FT%TZ > "$raw/$name.started"
    "$@" > "$raw/$name.log" 2>&1
    local status=$?
    printf '%s\n' "$status" >> "$raw/qualification.status"
    date -u +%FT%TZ > "$raw/$name.finished"
    printf '%s exit=%s\n' "$name" "$status"
    if (( status != 0 )); then failed=1; fi
}
head=$(git rev-parse HEAD)
run source git show --no-patch --format=fuller HEAD
run tree git rev-parse HEAD HEAD^{tree}
run signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run initial-status git status --short
run rustc rustc -Vv
run cargo cargo -V
run disk df -h .
run fixture cargo test --locked -p fe2o3-kfd --all-features --test cpu_runtime_fixtures
run kfd-library cargo test --locked -p fe2o3-kfd --all-features --lib
run kfd-doc cargo test --locked -p fe2o3-kfd --all-features --doc
run clippy cargo clippy --locked -p fe2o3-kfd --all-features --all-targets -- -D warnings
run default-kfd cargo check --locked -p fe2o3-kfd --no-default-features
run default-runtime cargo check --locked -p fe2o3-runtime --no-default-features
run format cargo fmt --all -- --check
run unchanged git diff --exit-code HEAD -- crates
run final-status git status --short
run final-head git rev-parse HEAD HEAD^{tree}
if [[ $(git rev-parse HEAD) != "$head" ]]; then failed=1; fi
printf 'aggregate %s\n' "$failed" >> "$raw/qualification.status"
exit "$failed"
