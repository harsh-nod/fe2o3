cargo check --locked -p fe2o3-kfd --no-default-features 
