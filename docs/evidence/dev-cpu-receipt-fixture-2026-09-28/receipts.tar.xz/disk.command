df -h . 
