git show --no-patch --format=fuller HEAD 
