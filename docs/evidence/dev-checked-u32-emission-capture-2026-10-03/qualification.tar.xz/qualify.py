"""Bounded CPU qualification for actual checked-add emission capture."""

import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
NAMES = ['fe2o3-kernel-ir', 'fe2o3-pliron', 'fe2o3-lower-mir-kernel',
         'fe2o3-kernel-analysis', 'fe2o3-verifier']
PACKAGES = [part for name in NAMES for part in ('-p', name)]
CARGO = ['cargo', '+nightly-2026-04-03']
COMMON = ['--locked', '--offline', *PACKAGES, '--all-features']
TEST = [*CARGO, 'test', *COMMON, '--lib', '--tests']

def changed_rust():
    modified = subprocess.check_output(['git', 'diff', '--name-only', '-z', 'HEAD'], cwd=ROOT)
    added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT)
    return sorted({name for name in (modified + added).decode().split('\0')
                   if name.endswith('.rs') and name.startswith(('crates/', 'tests/support/'))})

COMMANDS = {
    'build-02': ['2400s', *TEST, '--no-run', '--message-format=json'],
    'roster-02': ['600s', *TEST, '--', '--list'],
    'cpu-02': ['2400s', *TEST, '--', '--test-threads=1'],
    'doc-02': ['1200s', *CARGO, 'test', *COMMON, '--doc'],
    'clippy-02': ['2400s', *CARGO, 'clippy', *COMMON, '--lib', '--bins',
                  '--test', 'gfx942_local_checked_u32_add_v1', '--no-deps', '--', '-D', 'warnings'],
    'check-no-default-02': ['1200s', *CARGO, 'check', '--locked', '--offline',
                           *PACKAGES, '--no-default-features', '--lib'],
    'check-host-02': ['1200s', *CARGO, 'check', '--locked', '--offline',
                     '-p', 'fe2o3-host', '--all-features', '--lib'],
    'source-controls-02': ['1800s', 'python3', '-I', '-B', str(OUT / 'source-controls.py'), 'source-02'],
    'format-02': ['300s', 'rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                  '--config', 'skip_children=true', *changed_rust()],
    'whitespace-02': ['300s', 'git', 'diff', '--check'],
}

def main():
    labels = sys.argv[1:] or list(COMMANDS)
    if any(label not in COMMANDS for label in labels):
        raise SystemExit('unknown label')
    for label in labels:
        print(json.dumps({'starting': label, 'command': COMMANDS[label]}), flush=True)
        result = subprocess.run([sys.executable, '-I', '-B', str(OUT / 'capture.py'),
                                 label, *COMMANDS[label]], check=False)
        if result.returncode:
            return result.returncode
    return 0

if __name__ == '__main__':
    sys.exit(main())
