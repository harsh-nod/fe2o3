"""Independent offline audit of genuine checked-u32 emission capture, not a proof."""

from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess

import yaml


ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = '8eb0ebcb954c5cf795f08ba4265da54681bf40c9'
PINS = {
    'capture.py': 'a97634ad6f8c5f4d3323fd7319fed5d6766eee8f98575626c4ef6f5896c6d208',
    'qualify.py': '212f5002858a982f088393e51d55f8ec8599b3213b0393eff06488cdf54d1ba0',
    'source-controls.py': '71b8877979380358197bb5f9f013c41c7030f4dd587fe68ca2805502e314101d',
}
ENV = {
    'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '4',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
    'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUST_TEST_THREADS': '1',
    'FE2O3_HIP_SYS_DISABLE': '1',
}
SCOPE = ['crates', 'scripts', '.github', 'tests/support',
         'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']
NAMES = ['fe2o3-kernel-ir', 'fe2o3-pliron', 'fe2o3-lower-mir-kernel',
         'fe2o3-kernel-analysis', 'fe2o3-verifier']
PACKAGES = [part for name in NAMES for part in ('-p', name)]
SUMMARY = re.compile(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                     r'(\d+) measured; (\d+) filtered out; finished in [0-9.]+s$', re.M)
RESULT = re.compile(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$', re.M)
REQUIRED_PUBLIC = {
    'captured_public_entry_retains_same_compiler_owner_through_formal_admission',
    'captured_public_entry_rejects_substitutions_without_consuming_owners',
    'equal_content_compiler_captures_keep_their_distinct_owner_borrows',
}
PLIRON_CHILDREN = [
    'adapter_emission_v1_tests.rs', 'prepared_driver_v1_tests.rs',
    'occurrence_capture_v1_tests.rs', 'statement_capture_v1_tests.rs',
    'typed_elision_capture_v1_tests.rs', 'occurrence_payload_resource_v1_tests.rs',
    'streaming_replay_tests.rs', 'occurrence_resource_v1_tests.rs',
    'capture_prepass_v1_tests.rs',
]
LOWER_TEST = 'crates/fe2o3-lower-mir-kernel/src/production_checked_u32_add_capture_v1_tests.rs'
PRIOR_CPU = Path('/home/harsh/.codex-tmp/fe2o3-gfx942-mov-composition-20261003/cpu-01/stdout')
PRIOR_CPU_SHA = 'f7c28e066cc373e055a8ea0a8c61fc2b975f86ca4fa82049598f2f085eeb01c6'

# Frozen from the complete generation02 receipts, never the superseded diagnostics.
FINAL = {
    'generation': '02',
    'counts': {'passed': 1895, 'ignored': 14, 'listed': 1909,
               'targets': 94, 'doc_passed': 49},
    'ignored_roster': {
        'failed_ack_delivery_terminates_and_reaps_worker_30_repeat_stress': 1,
        'fresh_challenges_make_separate_receipts_distinct': 1,
        'gfx942_integer_semantics_v1::mov_b32::tests::native_llvm_mc_s_mov_b32_compatibility_v1': 1,
        'gfx942_integer_semantics_v1::tests::native_llvm_mc_s_add_u32_compatibility_v1': 1,
        'immutable_result_rejects_mutation_after_done': 1,
        'live_executable_page_and_alias_mutations_fail_closed': 1,
        'persistent_freshness::linux::tests::subprocess_consume_same_identity': 1,
        'persistent_freshness::linux::tests::subprocess_hold_lock': 1,
        'persistent_freshness::linux::tests::subprocess_rejects_fork_inherited_transaction': 1,
        'policy_must_pin_the_initial_executable_baseline': 1,
        'process_creation_timeout_substitution_and_malformed_protocol_all_fail': 1,
        'receipt_binds_real_process_occurrences_inputs_outputs_and_opaque_results': 1,
        'retained_functional_refinement_runtime_v1::linux::functional_refinement_process_tree_v1::tests::pinned_functional_refinement_runtime_executes_a_real_verus_proof': 1,
        'sparse_wire_maximum_block_count_is_bounded_and_admitted': 1,
    },
    'roster_sha256': 'caf673a194ddf5119500936b17a98fee94728e5c8662443d241040e42cc4cf10',
    'source_inventory_sha256': 'b85fba5c7422935743528d89bfb5e2969f01e09e8cec07d900586a21e60306cc',
    'source_delta_sha256': '277ef2665f35e98641db4803aa758d0d9abaf6ed020d3f1b29a6274fc6ea07f7',
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse(data):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result

    def constant(value):
        raise ValueError('nonfinite JSON: ' + value)

    return json.loads(data, object_pairs_hook=pairs, parse_constant=constant)


def regular(path):
    need(path.is_file() and not path.is_symlink() and path.resolve() == path,
         'canonical regular file: ' + str(path))
    return path.read_bytes()


def read(path):
    return parse(regular(path))


def child(base, name):
    need(isinstance(name, str) and name and '\\' not in name, 'relative path')
    path = base / name
    need(not Path(name).is_absolute() and '..' not in Path(name).parts
         and path.resolve() == path and path.is_relative_to(base), 'contained path: ' + name)
    return path


def git(*args):
    result = subprocess.run(['git', *args], cwd=ROOT, env=ENV,
                            capture_output=True, check=False)
    need(result.returncode == 0 and not result.stderr, 'read-only git: ' + repr(args))
    return result.stdout


def source_inventory():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', *SCOPE)
    return {name: sha(regular(child(ROOT, name)))
            for name in sorted({os.fsdecode(name) for name in names.split(b'\0') if name})}


def utc(value):
    timestamp = datetime.datetime.fromisoformat(value)
    need(timestamp.utcoffset() == datetime.timedelta(0), 'UTC timestamp')
    return timestamp


def changed_sources(sources):
    names = {os.fsdecode(name) for name in git('ls-tree', '-r', '--name-only', '-z', BASE,
                                              '--', *SCOPE).split(b'\0') if name}
    need(names <= set(sources), 'no removed qualification source')
    changed = {}
    for name in sorted(set(sources) | names):
        before = sha(git('show', BASE + ':' + name)) if name in names else None
        if before != sources[name]:
            changed[name] = {'before': before, 'after': sources[name]}
    need(changed, 'nonempty implementation delta')
    diff = git('diff', '--unified=0', BASE, '--', *SCOPE).decode()
    need(not re.search(r'^\+\s*#\[\s*ignore(?:\s|\]|=|\()', diff, re.M),
         'no newly ignored existing tests')
    for name, row in changed.items():
        if row['before'] is None and name.endswith('.rs'):
            need(not re.search(r'^\s*#\[\s*ignore(?:\s|\]|=|\()',
                               regular(ROOT / name).decode(), re.M),
                 'no ignored added tests: ' + name)
    return changed


def expected_commands(changed):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', *PACKAGES, '--all-features']
    tests = [*cargo, 'test', *common, '--lib', '--tests']
    rust = sorted(name for name in changed if name.endswith('.rs')
                  and name.startswith(('crates/', 'tests/support/')))
    return {
        'build': (2400, [*tests, '--no-run', '--message-format=json']),
        'roster': (600, [*tests, '--', '--list']),
        'cpu': (2400, [*tests, '--', '--test-threads=1']),
        'doc': (1200, [*cargo, 'test', *common, '--doc']),
        'clippy': (2400, [*cargo, 'clippy', *common, '--lib', '--bins',
                            '--test', 'gfx942_local_checked_u32_add_v1', '--no-deps',
                            '--', '-D', 'warnings']),
        'check-no-default': (1200, [*cargo, 'check', '--locked', '--offline',
                                      *PACKAGES, '--no-default-features', '--lib']),
        'check-host': (1200, [*cargo, 'check', '--locked', '--offline',
                                '-p', 'fe2o3-host', '--all-features', '--lib']),
        'source-controls': (1800, ['python3', '-I', '-B', str(OUT / 'source-controls.py'),
                                   'source-' + FINAL['generation']]),
        'format': (300, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                            '--config', 'skip_children=true', *rust]),
        'whitespace': (300, ['git', 'diff', '--check']),
    }


def capture(label, seconds, command, sources):
    need(re.fullmatch(r'[a-z][a-z0-9-]*-\d\d', label), 'selected capture label')
    directory = child(OUT, label)
    row = read(directory / 'receipt.json')
    initial = read(directory / 'command.json')
    need(row['command'] == ['timeout', '--signal=TERM', '--kill-after=30s',
                           str(seconds) + 's', *command], label + ': exact bounded argv')
    need(type(row['exit']) is int and row['exit'] == 0 and row['source_unchanged'] is True,
         label + ': successful stable command')
    need(row['environment'] == ENV and row['cwd'] == str(ROOT)
         and row['base'] == BASE and row['controller_sha256'] == PINS['capture.py'],
         label + ': exact environment/base/controller')
    initial_keys = {'command', 'environment', 'cwd', 'base', 'controller_sha256', 'started'}
    need(set(initial) == initial_keys and all(row[key] == value for key, value in initial.items()),
         label + ': initial/terminal continuity')
    terminal_keys = initial_keys | {'exit', 'source_unchanged', 'finished',
                                    'stdout_sha256', 'stderr_sha256'}
    if '--message-format=json' in command:
        terminal_keys.add('executables')
    need(set(row) == terminal_keys, label + ': complete terminal schema')
    duration = (utc(row['finished']) - utc(row['started'])).total_seconds()
    need(0 <= duration <= seconds + 45, label + ': bounded elapsed time')
    need(read(directory / 'source-before.json') == sources
         and read(directory / 'source-after.json') == sources, label + ': exact source closure')
    for stream in ('stdout', 'stderr'):
        data = regular(directory / stream)
        need(sha(data) == row[stream + '_sha256'], label + ': ' + stream + ' bytes')
        row[stream] = data.decode('utf-8')
    return row


def build_artifacts(receipt):
    rows = [parse(line) for line in receipt['stdout'].splitlines()]
    need([row for row in rows if row.get('reason') == 'build-finished']
         == [{'reason': 'build-finished', 'success': True}], 'successful Cargo build footer')
    artifacts = {}
    for row in rows:
        if row.get('reason') != 'compiler-artifact' or not row.get('executable'):
            continue
        path = Path(row['executable'])
        need(path.is_relative_to(ROOT / 'target'), 'built executable inside target')
        data = regular(path)
        item = {'sha256': sha(data), 'byte_length': len(data), 'target': row['target']['name'],
                'test': row['profile']['test']}
        need(type(item['test']) is bool, 'typed executable test flag')
        need(str(path) not in artifacts or artifacts[str(path)] == item, 'consistent artifact')
        artifacts[str(path)] = item
    need(artifacts and artifacts == receipt['executables'], 'exact executable hash roster')
    return artifacts


def test_results(stdout):
    summaries = [tuple(map(int, row)) for row in SUMMARY.findall(stdout)]
    need(summaries and all(failed == measured == filtered == 0
                          for _, failed, _, measured, filtered in summaries),
         'complete successful test summaries')
    rows = RESULT.findall(stdout)
    statuses = Counter(state for _, state in rows)
    need(statuses['FAILED'] == 0 and statuses['ok'] == sum(row[0] for row in summaries)
         and statuses['ignored'] == sum(row[2] for row in summaries), 'test rows match summaries')
    return (Counter(name for name, _ in rows),
            Counter(name for name, state in rows if state == 'ignored'), summaries)


def running_targets(stderr):
    names = re.findall(r'^\s*Running .+ \(([^\n)]+)\)\s*$', stderr, re.M)
    return Counter(str((ROOT / name).resolve()) if not Path(name).is_absolute() else name
                   for name in names)


def required_tests(observed, ignored):
    required = set(REQUIRED_PUBLIC)
    base = 'crates/fe2o3-pliron/src/production/semantic_ssa/'
    groups = {}
    for path in [*(base + name for name in PLIRON_CHILDREN), LOWER_TEST]:
        data = regular(ROOT / path).decode()
        names = re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(', data)
        need(names and len(names) == len(set(names)), 'explicit new test source: ' + path)
        groups[path] = names
        required.update(names)
    need(sum(len(names) for path, names in groups.items() if path.startswith(base)) == 56,
         'all 56 added PLIRON tests accounted')
    need(len(groups[LOWER_TEST]) == 4, 'four lower capture tests accounted')
    selected = []
    for name in sorted(required):
        matches = [full for full in observed if full == name or full.endswith('::' + name)]
        need(len(matches) == 1 and observed[matches[0]] == 1 and not ignored[matches[0]],
             'required test ran and passed exactly once: ' + name)
        selected.extend(matches)
    return selected


def cpu_evidence(receipts, artifacts):
    listed = Counter(re.findall(r'^(.+): test$', receipts['roster']['stdout'], re.M))
    footers = re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', receipts['roster']['stdout'], re.M)
    need(footers and all(bench == '0' for _, bench in footers)
         and sum(int(count) for count, _ in footers) == sum(listed.values()), 'complete test listing')
    observed, ignored, summaries = test_results(receipts['cpu']['stdout'])
    targets = Counter(path for path, row in artifacts.items() if row['test'])
    need(observed == listed and listed, 'exact list/run multiset including ignores')
    need(running_targets(receipts['roster']['stderr']) == targets
         and running_targets(receipts['cpu']['stderr']) == targets
         and len(summaries) == len(footers) == sum(targets.values()), 'every built harness ran once')
    library_names = {row['target'] for row in artifacts.values() if row['test']}
    need({name.replace('-', '_') for name in NAMES} <= library_names, 'all five library harnesses')
    docs, doc_ignored, doc_summaries = test_results(receipts['doc']['stdout'])
    need(len(doc_summaries) == 5 and not doc_ignored, 'five complete nonignored doctest suites')
    required = required_tests(observed, ignored)
    counts = {'passed': sum(row[0] for row in summaries), 'ignored': sum(ignored.values()),
              'listed': sum(listed.values()), 'targets': len(targets),
              'doc_passed': sum(row[0] for row in doc_summaries)}
    need(counts == FINAL['counts'], 'observed frozen final counts')
    need(dict(sorted(ignored.items())) == FINAL['ignored_roster'], 'exact unchanged ignore roster')
    prior = regular(PRIOR_CPU)
    need(sha(prior) == PRIOR_CPU_SHA, 'accepted previous two-package CPU receipt')
    _, prior_ignored, _ = test_results(prior.decode())
    extra_ignore = 'sparse_wire_maximum_block_count_is_bounded_and_admitted'
    baseline = git('show', BASE + ':crates/fe2o3-kernel-ir/tests/control_flow_bounds.rs').decode()
    need('#[ignore = "exercises the full V1 block-count boundary"]\nfn ' + extra_ignore in baseline,
         'additional selected package ignore existed at parent HEAD')
    need(sum(prior_ignored.values()) == 13
         and ignored == prior_ignored + Counter({extra_ignore: 1}),
         'thirteen prior package ignores plus one existing kernel-ir boundary ignore')
    need(sha(json.dumps(dict(sorted(listed.items())), sort_keys=True).encode())
         == FINAL['roster_sha256'], 'frozen complete ordinary test roster')
    return {'counts': counts, 'roster': dict(sorted(listed.items())),
            'ignored_roster': dict(sorted(ignored.items())), 'required_passed': required,
            'doc_roster': dict(sorted(docs.items()))}


def source_controls(sources, outer):
    workflow = regular(ROOT / '.github/workflows/runtime-component-source-guards.yml')
    steps = yaml.safe_load(workflow)['jobs']['source-controls']['steps']
    commands = [(step['name'], shlex.split(line)) for step in steps if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    need(len(commands) == 32 and all(command[:3] == ['python3', '-I', '-B']
                                    for _, command in commands), 'exact source-only workflow')
    prefix = 'source-' + FINAL['generation']
    result = read(OUT / (prefix + '.json'))
    need(set(result) == {'workflow_sha256', 'workflow_unchanged', 'commands', 'accepted'}
         and result['accepted'] is True and result['workflow_unchanged'] is True
         and result['workflow_sha256'] == sha(workflow) and len(result['commands']) == 32,
         'complete source-control result')
    previous = utc(outer['started'])
    for index, ((step, command), row) in enumerate(zip(commands, result['commands']), 1):
        label = prefix + '-' + str(index).zfill(2)
        need(row == {'step': step, 'capture': label, 'command': command, 'exit': 0},
             'exact source-control command row')
        receipt = capture(label, 300, command, sources)
        need(previous <= utc(receipt['started']) <= utc(receipt['finished']) <= utc(outer['finished']),
             'ordered child source-control chronology')
        previous = utc(receipt['finished'])
    need(parse(outer['stdout'].splitlines()[-1]) == {'accepted': True, 'commands': 32},
         'source-control closing stdout')
    return {'commands': 32, 'workflow_sha256': sha(workflow),
            'result_sha256': sha(regular(OUT / (prefix + '.json')))}


def unchanged_proofs(sources):
    names = {os.fsdecode(name) for name in git('ls-tree', '-r', '--name-only', '-z', BASE,
                                              '--', *SCOPE).split(b'\0') if name}
    selected = {name for name in names | set(sources)
                if '/verus/' in name or name.endswith('_body.rs')}
    need(selected and selected <= names and selected <= set(sources), 'unchanged proof/body roster')
    hashes = {}
    for name in sorted(selected):
        digest = sha(git('show', BASE + ':' + name))
        need(sources[name] == digest, 'unchanged retained proof/body bytes: ' + name)
        hashes[name] = digest
    return hashes


def main():
    need(FINAL is not None, 'final selection not frozen; diagnostic receipts cannot be accepted')
    need(re.fullmatch(r'\d\d', FINAL['generation']), 'exact selected generation')
    need(git('rev-parse', 'HEAD').decode().strip() == BASE, 'exact accepted parent HEAD')
    for name, digest in PINS.items():
        need(sha(regular(OUT / name)) == digest, 'frozen controller: ' + name)
    sources = source_inventory()
    need(sha(json.dumps(sources, sort_keys=True).encode()) == FINAL['source_inventory_sha256'],
         'frozen complete final source inventory')
    changed = changed_sources(sources)
    need(sha(json.dumps(changed, sort_keys=True).encode()) == FINAL['source_delta_sha256'],
         'exact accepted source delta')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    labels = {role: role + '-' + FINAL['generation'] for role in expected_commands(changed)}
    receipts = {role: capture(labels[role], seconds, command, sources)
                for role, (seconds, command) in expected_commands(changed).items()}
    artifacts = build_artifacts(receipts['build'])
    for role in ('roster', 'cpu'):
        need(utc(receipts['build']['finished']) <= utc(receipts[role]['started']),
             role + ': uses the completed selected build')
    cpu = cpu_evidence(receipts, artifacts)
    controls = source_controls(sources, receipts['source-controls'])
    proofs = unchanged_proofs(sources)
    need(source_inventory() == sources, 'source still frozen after audit')
    report = {
        'schema': 'fe2o3.checked-u32-capture.audit.v1', 'accepted': True, 'base': BASE,
        'started': started, 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'auditor_sha256': sha(regular(Path(__file__).resolve())), 'controller_pins': PINS,
        'source_sha256': sources, 'changed_sources': changed, 'cpu': cpu,
        'prior_cpu_roster': {'path': str(PRIOR_CPU), 'sha256': PRIOR_CPU_SHA,
                             'usage': 'unchanged ignored-test identities only'},
        'executables': artifacts, 'source_controls': controls, 'unchanged_proof_sources': proofs,
        'selected_receipts': {labels[role]: sha(regular(OUT / labels[role] / 'receipt.json'))
                              for role in receipts},
        'diagnostics_accepted': False, 'solver_executed': False, 'native_executed': False,
        'new_formal_theorem': False, 'application_authority_established': False,
        'source_value_equivalence_established': False, 'performance_qualification': False,
    }
    with (OUT / 'audit-final.json').open('x') as stream:
        stream.write(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'accepted': True, 'counts': cpu['counts'], 'source_controls': 32,
                      'solver_executed': False, 'native_executed': False}), flush=True)


if __name__ == '__main__':
    main()
