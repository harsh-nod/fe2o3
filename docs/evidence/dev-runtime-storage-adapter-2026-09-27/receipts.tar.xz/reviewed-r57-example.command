cargo test --offline -p fe2o3-runtime --all-features --example gfx942-runtime-r57-n3-qualification 
