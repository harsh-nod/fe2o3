# Development Qualification History

Base: e4b4ca75dd3065a7b01029e52a7054e2c988c758.

The first recorded campaign passed all ten new scripted runtime groups and
sixteen native initialized-storage-filter tests. The full runtime suite aborted
at public_three_binding_candidate_rejection_preserves_custody_and_retries:
its old synchronous-rejection expectation did not allow the new deferred
conversion candidate. An isolated --nocapture rerun confirms that assertion.
Runtime Clippy rejected the conversion closure's inline custody error size;
KFD Clippy passed. All initial source hashes matched at campaign end.

The second source revision changes only kfd_backend.rs tests and
kfd_backend/initialized_storage.rs: candidate tests now assert failed-before-
publication settlement, unchanged storage snapshots, zero launch-performance
record, zero qualification authorization, and normal submission release. Shape,
alias and uninitialized-roster rejection checks remain. The conversion function
gets the same narrowly scoped result_large_err allowance used by the existing
SDMA promotion adapter: custody remains inline so recovery needs no allocation.

Earlier unrecorded development runs exposed fixture timing mistakes: submit can
progress immediately, dirty-shadow candidates require flush, and pending poll
does not publish. Gates are now installed before submission. Those preliminary
failures are not represented as passing qualification or as native execution.

Native coverage uses CPU-injected completion, not GPU execution. The newly
guarded foundation_in_engine=false branch has no new direct public-session
fixture; missing engine, terminal and existing root do. Corrupt initialization
prefix is injected inside the SDMA test module and checked through the shared
persistent-owner preflight. It does not add a production forging API.

An MI300X SSH probe failed DNS resolution before connection. No remote files or
jobs were created. Issue #182 was read as OPEN with updatedAt
2026-09-27T06:47:37Z; a later attempt to archive its JSON failed connecting to
api.github.com, leaving issue-182.json empty, not an authoritative snapshot.

## Reviewed Revision

The second frozen campaign completed: runtime 1631 passed, three existing
socket failures and 28 ignored; KFD 1676 passed and one existing SocketAdmission
failure. Runtime Clippy, KFD/runtime doctests (42/52), minimal check, formatting,
whitespace and all source-continuity checks passed.

After that campaign was terminal, three files changed: kfd_backend.rs gained
restoration-state occupancy in its refusal snapshot; initialized_storage_tests.rs
gained zero-authority observations across the partial-roster fault matrix and
explicit empty restoration/performance/reservation checks; the R57 example
replaced its obsolete fresh-output negative with an invalid mixed-memory roster.
The latter preserves both successful phases and the exact authority policy.
Native KFD sources and runtime production behavior are unchanged by this revision.
The reviewed campaign records the expected three-file hash delta and reruns
the full runtime suite, strict all-target lint, example build/test, formatting,
whitespace and final source hashes. Its results are not implied by the prior run.
