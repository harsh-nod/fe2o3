#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
raw=/home/harsh/.codex-tmp/fe2o3-runtime-storage-adapter-20260927-KSppBZIk
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
run() {
    local name=$1
    shift
    printf '%s START %s\n' "$(date -u +%FT%TZ)" "$name"
    printf '%q ' "$@" > "$raw/$name.command"
    printf '\n' >> "$raw/$name.command"
    "$@" > "$raw/$name.log" 2>&1
    local rc=$?
    printf '%s\n' "$rc" > "$raw/$name.exit"
    printf '%s END %s exit=%s\n' "$(date -u +%FT%TZ)" "$name" "$rc"
    tail -n 12 "$raw/$name.log"
}
git rev-parse HEAD > "$raw/base-commit.txt"
git status --short > "$raw/status-before.txt"
git diff > "$raw/initial-tracked.patch"
git ls-files -z crates Cargo.toml Cargo.lock rust-toolchain.toml | xargs -0 sha256sum > "$raw/initial-inputs.sha256"
sha256sum crates/fe2o3-runtime/src/kfd_backend/initialized_storage.rs crates/fe2o3-runtime/src/kfd_backend/tests/initialized_storage_tests.rs >> "$raw/initial-inputs.sha256"
run runtime-focused cargo test --offline -p fe2o3-runtime --all-features --lib initialized_storage_runtime -- --test-threads=1
run runtime-all-features cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=1
run native-conversion cargo test --offline -p fe2o3-kfd --lib initialized_storage -- --test-threads=1
run runtime-clippy cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
run kfd-clippy cargo clippy --offline -p fe2o3-kfd --all-features --all-targets -- -D warnings
run source-continuity sha256sum -c "$raw/initial-inputs.sha256"
