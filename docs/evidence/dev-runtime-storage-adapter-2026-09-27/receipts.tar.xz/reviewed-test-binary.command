sha256sum target/debug/deps/fe2o3_runtime-e03b9552edb097b6 
