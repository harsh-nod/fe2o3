# Hardware Qualification Boundary

Read-only harness review; no hardware, build or benchmark was executed by the
reviewing agent. MI300X connection failed before any remote artifacts existed.

Reusable infrastructure:

- benchmarks/runtime_gfx942/run-r26-inplace-mi300x.sh and
  gfx942-runtime-r26-inplace-benchmark.rs: matched 1 MiB HBM ReadWrite workload,
  alternating inputs, complete output validation, H2D/compute/D2H/E2E host-clock
  timing, HIP/HSA comparators and three Latin-square slots. R26 requires initial
  SHA authority and ready_promotion(), so it remains an H2dReady baseline.
- gfx942-runtime-r57-n3-qualification.rs: DeviceLocal R/R/W A+B->C, C+B->D,
  all four readbacks and explicit cleanup. It is correctness qualification,
  not a matched benchmark. Its first phase requires all three initial hashes.
- run-r60-pipeline-mi300x.py and r60_pipeline_{hip,hsa}.cpp: provenance,
  interference monitoring, teardown and repeated comparisons, but HostVisible
  buffers. The runner pins GPU index 1 and an exact unique ID; it cannot be run
  unchanged on an arbitrary idle GPU.
- gfx942-runtime-r66-coexistence.rs: disjoint copy/compute custody in both
  publication orders, not producer-copy->compute conversion or physical overlap.

InitializedStorage intentionally has no content digest. Add a separate bounded
qualification policy and workload/schema rather than weakening existing R26/R57
authority. Cover multipart H2D, partial overwrite, fresh zeroed output, repeated
launch and produced output reused as Read. Never manufacture H2dReady provenance.

The old R57 example negative mislabeled fresh zeroed C as uninitialized. The
implemented harness correction uses its distinct HostVisible upload buffer as C,
which passes typed argument construction but must fail mixed-memory structural
admission before authority. The successful original digest-authorized R57 phases
stay unchanged. A compiled harness correction is not a new native qualification.

For new matched rows, use identical memory placement, copy segmentation, kernel
bytes, geometry, warmups, repetitions and timing boundaries in KFD/HIP/HSA.
Separate first conversion from steady replay. Capture NUMA placement, selected-
GPU queue census, source/binary hashes, interference and rejected-run receipts;
clean only owned artifacts/processes. Zero materializations and PersistentDeviceReused
are path counters, not speed measurements or unique storage-origin evidence.
