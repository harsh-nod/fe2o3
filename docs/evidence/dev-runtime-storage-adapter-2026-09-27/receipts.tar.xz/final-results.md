# Final Results

Implementation: 04a3b5cc5df28f909810efcfea8f0b9335d9c990, SSH-signed and verified.

- Reviewed runtime all-feature library: 1631 passed, 3 existing socket failures,
  28 ignored. The ten new groups passed, including the strengthened R57
  zero-authority partial-roster matrix.
- Full KFD library: 1676 passed, 1 existing SocketAdmission failure. No KFD
  source changed after this campaign; the reviewed delta identifies exactly
  two runtime test files and one example.
- Focused initialized-storage native filter: 16 passed (13 conversion tests,
  two existing restore/cancellation tests, and one corrupted-prefix test).
- KFD/runtime doctests: 42/52 passed (runtime 8 merged plus 44 compile-fail).
- Strict all-feature/all-target runtime and KFD Clippy: passed.
- Minimal runtime check and no-default-feature runtime test compilation: passed.
- R57 example compilation/test command: passed with ZERO tests; not GPU evidence.
- Formatting, whitespace, final source continuity: passed.
- Production metadata audit: 43-package closure passed. No new ELF audit or
  authenticated Verus campaign was run.

The two additional commands outside the campaign scripts returned exit zero:

    env CARGO_NET_OFFLINE=true python3 scripts/runtime_pure_rust_audit.py metadata --cargo --root fe2o3-runtime
    env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1 cargo check --offline -p fe2o3-runtime --tests --no-default-features

Their output is in production-metadata-audit.log and default-test-check.log.
Native test binary identity is in kfd-test-binary.sha256; reviewed runtime test
identity is in reviewed-test-binary.log. runtime-test-binary.sha256 refers to the
earlier second campaign, before the last test-only revision.

The four baseline failures remain explicit; wrapper-script exit zero is not a
claim that every contained command passed. Per-command exit files, logs and
source-revision.md preserve rejected preliminary runs and intentional hash deltas.

MI300X DNS failed before connection; no remote files/processes were created.
No full parity, milestone closure, native adapter execution, copy/launch speedup
or concrete formal-refinement result is claimed.
