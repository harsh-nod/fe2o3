cargo clippy --offline -p fe2o3-kfd --all-features --all-targets -- -D warnings 
