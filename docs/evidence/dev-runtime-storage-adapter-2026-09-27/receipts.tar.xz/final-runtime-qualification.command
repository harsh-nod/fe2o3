cargo test --offline -p fe2o3-runtime --all-features --lib r57_n3_qualification_ -- --test-threads=1 --nocapture 
