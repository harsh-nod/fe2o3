cargo test --offline -p fe2o3-kfd --doc 
