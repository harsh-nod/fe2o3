sha256sum -c /home/harsh/.codex-tmp/fe2o3-runtime-storage-adapter-20260927-KSppBZIk/reviewed-inputs.sha256 
