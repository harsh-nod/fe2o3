#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
raw=/home/harsh/.codex-tmp/fe2o3-runtime-storage-adapter-20260927-KSppBZIk
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
ulimit -c 0
run() {
    local name=$1
    shift
    printf '%s START %s\n' "$(date -u +%FT%TZ)" "$name"
    printf '%q ' "$@" > "$raw/$name.command"
    printf '\n' >> "$raw/$name.command"
    "$@" > "$raw/$name.log" 2>&1
    local rc=$?
    printf '%s\n' "$rc" > "$raw/$name.exit"
    printf '%s END %s exit=%s\n' "$(date -u +%FT%TZ)" "$name" "$rc"
    tail -n 12 "$raw/$name.log"
}
git diff > "$raw/final-tracked.patch"
git ls-files -z crates Cargo.toml Cargo.lock rust-toolchain.toml | xargs -0 sha256sum > "$raw/final-inputs.sha256"
sha256sum crates/fe2o3-runtime/src/kfd_backend/initialized_storage.rs crates/fe2o3-runtime/src/kfd_backend/tests/initialized_storage_tests.rs >> "$raw/final-inputs.sha256"
run final-runtime-candidate cargo test --offline -p fe2o3-runtime --all-features --lib public_three_binding_candidate -- --test-threads=1 --nocapture
run final-runtime-qualification cargo test --offline -p fe2o3-runtime --all-features --lib r57_n3_qualification_ -- --test-threads=1 --nocapture
run final-runtime-all-features cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=1
run final-runtime-clippy cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
run final-kfd-all cargo test --offline -p fe2o3-kfd --lib -- --test-threads=4
run final-kfd-doc cargo test --offline -p fe2o3-kfd --doc
run final-runtime-doc cargo test --offline -p fe2o3-runtime --all-features --doc
run final-runtime-minimal cargo check --offline -p fe2o3-runtime --no-default-features
run final-format cargo fmt --all -- --check
run final-whitespace git diff --check
run final-continuity sha256sum -c "$raw/final-inputs.sha256"
