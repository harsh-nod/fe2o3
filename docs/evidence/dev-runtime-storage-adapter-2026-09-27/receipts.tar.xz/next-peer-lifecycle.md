# Next Runtime Integration

Read-only agent handoff, not implementation or acceptance evidence.

Open pending directed cooperative-peer producers through the existing
RuntimeProducerAwareLaunchBackendV1 implementation on KfdMultiDeviceRuntimeBackendV1.
The current adapter only supplies post-settlement storage readiness. Child-gate
tests do not qualify public router admission. Ordinary pending peers and native
XGMI compute composition remain separate unsupported paths.

- Replace blanket pending-producer, pending-stream-tail and retained-allocation
  rejections with exact captured ancestry; install the waiting gate before child
  submission. An ordered-only pending tail needs a gate even with no explicit
  peer roots.
- Explicit roots require success; an ordered-only FIFO predecessor requires
  quiescence, not success. Capture its identity before later tails can change.
- Authenticate existing Ready/Published private child DMA by exact submission,
  immutable producer origin, endpoint, scratch, stream, leg and chunk range.
  Allocation overlap or a manufactured child event cannot grant access.
- Defer structural R/R/W readiness while gated; after settlement use native
  initialized-storage conversion and recompute actual backing admission.
- Poll/wait observe but do not advance peer copies. Flush/drain progress only
  captured directed roots, including cross-stream ancestors, then child work.
- Retain ancestry before child entry. Refund conclusive admission rejection
  only; terminal failure/unwind retains ancestry, child owners and scratch.
  Consumer cancellation must never cancel producer DMA.
- Preserve exact mixed explicit dependency depth after child settlement.

Public-router qualification must cover early submission, live DMA, transitive
ancestors, fan-out, R/R/W, partial Read fallback, explicit-failure vs ordered-only
failure, changed later tails, released events, wrong origin/scratch/range,
rollback, cancellation, terminal and unwind custody. Existing component tests
are prerequisites, not substitutes for this lifecycle.
