# Dispatch Cancellation Qualification Commands

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Final qualified source: `e31f26eddfd82332e12890ab14fc35b65c4fbb11`.
CPU commands use `prlimit --core=0:0`, `CARGO_INCREMENTAL=0`,
`CARGO_BUILD_JOBS=2`, and `cargo +nightly-2026-04-03`.
No MI300X commands or GPU execution occur in this packet.

## Solver

`proof-1` and `proof-2` use the pinned Verus binary with:

```
--crate-type lib --triggers-mode silent --no-cheating --output-json
--error-format=json --no-report-long-running --num-threads 4 --multiple-errors 2
crates/fe2o3-runtime-model/verus/dispatch_epoch_cancel_v1.rs
```

They run under a foreground 120-second timeout with TERM then a 5-second KILL
grace, and `VERUS_Z3_PATH` points at the pinned sibling `z3`.
The first stops on missing `final(self)` syntax; the second passes 16/0.

All three signed campaigns use:

```
python3 -I -B crates/fe2o3-runtime-model/verus/check-dispatch-epoch-cancel.py
  --output <this-root>/<campaign-directory>
  --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
```

Every exact command, status, process group, start/finish time, stdout and stderr
is in each stage directory. `campaign` rejects a foreign-primary Vec-precondition
diagnostic. `campaign-final` rejects a mixed postcondition/recommendation
diagnostic. `campaign-qualified` is the complete accepted run; earlier directories
are retained failures, despite the intermediate directory name `campaign-final`.
The classifier was not relaxed. The final control returns a safely wrong success
for out-of-bounds identities; the proof's roster result explicitly states its
bounds. Four synthetic calibration groups run before the 30 owned stages.

## CPU and Static Checks

- `kfd-build.log`: `test -p fe2o3-kfd --all-features --lib --no-run`; fails on two
  test-only QueueGenerationV1 assignments, fixed by accessing the `.0` payload.
- `kfd-build-2.log`: same command after the fix.
- `source-tests.log`: resulting KFD test ELF, filter
  `dependency_source_publication_tests --test-threads=2`.
- `cancel-tests.log`: same ELF, filter `epoch_cancel_tests --test-threads=2`.
- `kfd-regression.log`: same ELF, `--skip construction_primary --test-threads=2`.
- `kfd-final.log`: `test -p fe2o3-kfd --all-features --lib --
  --skip construction_primary --test-threads=2`, after the final dependency-owner
  tuple assertion. This is the final CPU result, not the earlier ELF runs.
- `runtime-final.log`: `test -p fe2o3-runtime --all-features --lib -- --test-threads=2`.
- `doctests.log`: `test -p fe2o3-kfd -p fe2o3-runtime -p fe2o3-runtime-model
  --all-features --doc`.
- `clippy.log`: `clippy -p fe2o3-kfd -p fe2o3-runtime --all-features --all-targets
  -- -D warnings`.
- `no-default.log`: `check -p fe2o3-kfd -p fe2o3-runtime --no-default-features --lib`.
- `fmt.log`: `cargo +nightly-2026-04-03 fmt --all -- --check`.
- `included-fmt.log`: `rustfmt +nightly-2026-04-03 --edition 2024 --check
  --config skip_children=true crates/fe2o3-kfd/src/queue_dispatch_binding/epoch_cancel_body.rs`.
- `diff-check.log`: `git diff --check`.

`source-files-before.sha256` is an earlier development snapshot, superseded by
`source-files-qualified.sha256` and its closing check. Final ELF hashes are
recorded separately. `live-groups.json` is an independent process-group snapshot;
`group-audit.json` compares it with all 56 owned group receipts.
