"""Run the frozen qualification matrix sequentially; retain every attempt."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys


OUT = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
suffix = sys.argv[1] if len(sys.argv) == 2 else '03'
if len(suffix) != 2 or not suffix.isdecimal():
    raise SystemExit('A two-digit attempt number is required')
spec = importlib.util.spec_from_file_location('qualification_audit', OUT / 'audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
commands = audit.commands(
    OUT / ('proof-final-' + suffix),
    Path('/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus'),
)
labels = {key: 'final-' + key.replace('_', '-') + '-' + suffix for key in commands}
if suffix == '04':
    labels['ci'] = 'final-ci-04-rg'
for key in ['build', 'list', 'tests', 'clippy', 'nodefault', 'host', 'doc',
            'native_llvm18', 'native_llvm22', 'ci', 'proof', 'format', 'whitespace']:
    label = labels[key]
    receipt = OUT / label / 'receipt.json'
    if receipt.exists():
        result = json.loads(receipt.read_text())
        if result['exit'] != 0 or not result['source_unchanged']:
            raise SystemExit('Existing failed attempt requires investigation: ' + label)
        continue
    print('START ' + label, flush=True)
    result = subprocess.run([
        sys.executable, '-I', '-B', str(OUT / 'capture.py'), label, '2400s',
        *commands[key],
    ], cwd=ROOT)
    if result.returncode:
        raise SystemExit(result.returncode)
controls_label = 'final-source-controls-' + suffix
controls = OUT / (controls_label + '.json')
if not controls.exists():
    result = subprocess.run([
        sys.executable, '-I', '-B', str(OUT / 'source-controls.py'),
        controls_label,
    ], cwd=ROOT)
    if result.returncode:
        raise SystemExit(result.returncode)
selection = {
    'schema': 'fe2o3.gfx942-integer-qualification-selection.v1',
    'base': audit.BASE,
    'captures': labels,
    'source_controls': controls.name,
    'proof_output': 'proof-final-' + suffix,
}
with (OUT / 'selection.json').open('x') as output:
    json.dump(selection, output, indent=2, sort_keys=True)
    output.write('\n')
print('All commands finished; independent audit required.', flush=True)
