"""Independently audit the selected CPU/arithmetic qualification receipts."""

import argparse
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

import yaml


ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
BASE = '05457de5db1ec371cfe3d893e925a04f052d8295'
CAPTURE_SHA = '84b5f1e88a891c42562613d3fdf178ea41ef1228324f0d2d2f09c0b621f1eac1'
CONTROLS_SHA = '71b8877979380358197bb5f9f013c41c7030f4dd587fe68ca2805502e314101d'
ENV = {
    'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '1',
    'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_TEST_OPT_LEVEL': '1', 'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUST_TEST_THREADS': '1',
    'FE2O3_HIP_SYS_DISABLE': '1',
}
PACKAGES = ['-p', 'fe2o3-kernel-analysis', '-p', 'fe2o3-verifier']
NATIVE_TEST = 'gfx942_integer_semantics_v1::tests::native_llvm_mc_s_add_u32_compatibility_v1'
FORMAT_EXCEPTION = 'crates/fe2o3-kernel-analysis/tests/fixtures/machine_effect_worker_fixture_common.rs'
V = Path('crates/fe2o3-kernel-analysis/verus')
SRC = Path('crates/fe2o3-kernel-analysis/src')
BODY = SRC / 'gfx942_integer_semantics_v1/add_u32_body.rs'
MODEL = SRC / 'gfx942_integer_semantics_v1.rs'
PROOF = V / 'gfx942_add_u32_v1.rs'
RUNNER = V / 'gfx942_add_u32_check.py'
SUPPORT = Path('crates/fe2o3-runtime-model/verus/compute_xgmi_packet_plan_check.py')
OWNER = Path('crates/fe2o3-runtime-model/verus/check-journal-issuance.py')
CLOSURE = Path('examples/row_softmax_v1/verify-verus-closure.sh')
MANIFEST = Path('crates/fe2o3-runtime-model/verus/pins/VERUS_CLOSURE_MANIFEST')
PINS = {
    SUPPORT: '61074f6cdbfde1df24bff3d1e56e04398f2850dd00518c233d847f13a29e0db4',
    OWNER: '36d5e0641300bf2568884ec4c440c668477a4b24a07ee95273a91eab34659480',
    CLOSURE: 'c0f5f201dca9ea6b3fa953884cdfaca8ca38413ad2a9de7700b3aaeb3a610d0c',
    MANIFEST: 'f06883e4ce463bcb9a3c8f911064ac85054c7822dc331db1a79f75f9e8878b01',
    PROOF: '9ad0024978b57190f262a45b1842a0c18b025b86be3057e5a9fd8eea6919b6cd',
    RUNNER: '45db0f0dafa5fe29e7895cacdf3a9644186086fd38fef9316b38e6eb85961275',
    V / 'gfx942_add_u32_test.py': '5adb2af4f2d1f70125b0eaf2a9c6eb3f086f6f52b0f7c90564a6c9dc0ca57fea',
    V / 'run-gfx942-add-u32.sh': '5ab7c889a58c56e83b1bf562850fc7b95f30decfb7ccdf9a22555dfeb6216e86',
}
VERIFIER = {
    'profile': 'release', 'version': '0.2026.08.09.92f466f',
    'platform': {'os': 'linux', 'arch': 'x86_64'},
    'toolchain': '1.97.1-x86_64-unknown-linux-gnu',
    'commit': '92f466f247f45128c630d1c843fd6e27d2115587',
}
VERUS_SHA = 'd97501a883931d1d173b1bf4b6cf4d973f16d105dbcb468e177b52b2331612d2'
FOCUS = 'gfx942_add_u32_v1'
MACRO = 'gfx942_add_u32_body_v1'
STAGES = [
    ('controls', 0), ('release-before', 0), ('positive-before', 0),
    ('negative-discarded-carry', 1), ('negative-wrong-width', 1),
    ('negative-wrong-result', 1), ('positive-after', 0), ('release-after', 0),
]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pairs(rows):
    result = {}
    for key, value in rows:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def parse(data):
    return json.loads(data, object_pairs_hook=pairs)


def regular(path):
    require(path.is_file() and not path.is_symlink() and path.resolve() == path,
            'ordinary canonical file: ' + str(path))
    return path.read_bytes()


def read(path):
    return parse(regular(path))


def safe_child(base, name):
    require(isinstance(name, str) and name and '\\' not in name, 'relative evidence path')
    candidate = base / name
    require(not Path(name).is_absolute() and '..' not in Path(name).parts
            and candidate.resolve() == candidate and candidate.is_relative_to(base),
            'contained canonical evidence path: ' + name)
    return candidate


def source_inventory():
    names = subprocess.check_output([
        'git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
        'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml',
    ], cwd=ROOT, env=ENV).split(b'\0')
    return {name: digest(regular(safe_child(ROOT, name)))
            for name in sorted({os.fsdecode(name) for name in names if name})}


def cargo(command, *args):
    return ['cargo', '+nightly-2026-04-03', command, '--locked', '--offline', *args]


def changed_rust():
    changed = subprocess.check_output(
        ['git', 'diff', 'HEAD', '--name-only', '-z', '--', '*.rs'], cwd=ROOT, env=ENV)
    added = subprocess.check_output(
        ['git', 'ls-files', '--others', '--exclude-standard', '-z', '--', '*.rs'],
        cwd=ROOT, env=ENV)
    names = {os.fsdecode(name) for data in [changed, added] for name in data.split(b'\0') if name}
    require(FORMAT_EXCEPTION in names, 'the sole existing formatting exception remains explicit')
    names.remove(FORMAT_EXCEPTION)
    require(names and all(name.endswith('.rs') for name in names), 'nonempty exact Rust change roster')
    for name in names:
        regular(safe_child(ROOT, name))
    return sorted(names)


def commands(proof_output, verus):
    shared = [*PACKAGES, '--all-features', '--lib', '--tests']
    result = {
        'build': cargo('test', *shared, '--no-run', '--message-format=json'),
        'list': cargo('test', *shared, '--', '--list'),
        'tests': cargo('test', *shared),
        'clippy': cargo('clippy', *PACKAGES, '--all-features', '--lib', '--bins',
                        '--test', 'gfx942_local_checked_u32_add_v1', '--no-deps',
                        '--', '-D', 'warnings'),
        'nodefault': cargo('check', '-p', 'fe2o3-kernel-analysis', '--no-default-features', '--lib'),
        'host': cargo('check', '-p', 'fe2o3-host', '--all-features', '--lib'),
        'doc': cargo('test', *PACKAGES, '--all-features', '--doc'),
        'ci': ['env', 'PATH=/home/harsh/.cargo/bin:/usr/bin:/bin:/home/harsh/.codex-openai/packages/standalone/releases/0.160.0-x86_64-unknown-linux-musl/codex-path',
               'bash', 'scripts/tests/ci-local-test-gate.sh'],
        'format': ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                   '--config', 'skip_children=true', *changed_rust()],
        'whitespace': ['git', 'diff', 'HEAD', '--check'],
        'proof': ['python3', '-I', '-B', str(RUNNER), '--verus', str(verus),
                  '--output', str(proof_output)],
    }
    for version, executable in [('18', '/usr/lib/llvm-18/bin/llvm-mc'),
                                ('22', '/opt/rocm/llvm/bin/llvm-mc')]:
        result['native_llvm' + version] = [
            'env', 'FE2O3_GFX942_LLVM_MC=' + executable,
            *cargo('test', *PACKAGES, '--all-features', '--lib',
                   NATIVE_TEST, '--', '--exact', '--ignored', '--test-threads=1', '--nocapture'),
        ]
    return result


def capture(label, expected, sources):
    require(re.fullmatch(r'final-[a-z0-9-]+', label) is not None, 'final-only capture label')
    directory = safe_child(OUT, label)
    receipt, initial = read(directory / 'receipt.json'), read(directory / 'command.json')
    command = receipt['command']
    require(command[:3] == ['timeout', '--signal=TERM', '--kill-after=30s']
            and re.fullmatch(r'[1-9][0-9]*s', command[3]) is not None
            and 1 <= int(command[3][:-1]) <= 3600 and command[4:] == expected,
            label + ': exact bounded command')
    require(type(receipt['exit']) is int and receipt['exit'] == 0
            and receipt['source_unchanged'] is True, label + ': successful unchanged run')
    require(receipt['environment'] == ENV and receipt['cwd'] == str(ROOT)
            and receipt['base'] == BASE and receipt['controller_sha256'] == CAPTURE_SHA,
            label + ': execution identity')
    require(set(initial) == {'command', 'environment', 'cwd', 'base', 'controller_sha256', 'started'}
            and all(receipt[key] == value for key, value in initial.items()),
            label + ': initial/final receipt agreement')
    start = datetime.datetime.fromisoformat(receipt['started'])
    finish = datetime.datetime.fromisoformat(receipt['finished'])
    require(start.utcoffset() == datetime.timedelta(0) and finish.utcoffset() == datetime.timedelta(0)
            and finish >= start, label + ': UTC measurement window')
    require(read(directory / 'source-before.json') == sources
            and read(directory / 'source-after.json') == sources, label + ': exact source closure')
    for name in ['stdout', 'stderr']:
        data = regular(directory / name)
        require(receipt[name + '_sha256'] == digest(data), label + ': output hash ' + name)
        receipt[name] = data.decode('utf-8')
    return receipt


def build_roster(receipt):
    derived = {}
    rows = [parse(line) for line in receipt['stdout'].splitlines()]
    require([row for row in rows if row.get('reason') == 'build-finished']
            == [{'reason': 'build-finished', 'success': True}], 'one successful Cargo build result')
    for row in rows:
        if row.get('reason') != 'compiler-artifact' or not row.get('executable'):
            continue
        path = Path(row['executable'])
        require(path.is_relative_to(ROOT / 'target'), 'built executable inside target')
        data = regular(path)
        derived[str(path)] = {
            'sha256': digest(data), 'byte_length': len(data),
            'target': row['target']['name'], 'test': row['profile']['test'],
        }
    require(derived and derived == receipt['executables'], 'exact current executable roster')
    require(all(type(row['test']) is bool for row in derived.values()), 'typed test profile')
    require({'fe2o3_kernel_analysis', 'fe2o3_verifier'}.issubset(
        {row['target'] for row in derived.values() if row['test']}), 'both requested library targets')
    return derived


SUMMARY = re.compile(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                     r'(\d+) measured; (\d+) filtered out; finished in [0-9.]+s$', re.M)
RESULT = re.compile(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$', re.M)


def results(stdout, allow_filtered=False):
    summaries = [tuple(map(int, row)) for row in SUMMARY.findall(stdout)]
    require(summaries and all(failed == measured == 0 and (allow_filtered or filtered == 0)
                             for _, failed, _, measured, filtered in summaries),
            'successful unfiltered test summaries')
    observed = RESULT.findall(stdout)
    categories = Counter(status for _, status in observed)
    require(categories['FAILED'] == 0 and categories['ok'] == sum(row[0] for row in summaries)
            and categories['ignored'] == sum(row[2] for row in summaries),
            'test rows independently match every category summary')
    return Counter(name for name, _ in observed), categories, summaries


def running_targets(stderr):
    names = re.findall(r'^\s*Running .+ \(([^\n)]+)\)\s*$', stderr, re.M)
    return Counter(str((ROOT / name).resolve()) if not Path(name).is_absolute() else name
                   for name in names)


def cpu_rosters(receipts, executables):
    listing = receipts['list']['stdout']
    listed = Counter(re.findall(r'^(.+): test$', listing, re.M))
    footers = re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', listing, re.M)
    require(footers and all(bench == '0' for _, bench in footers)
            and sum(int(count) for count, _ in footers) == sum(listed.values()),
            'complete listed CPU multiset')
    observed, categories, summaries = results(receipts['tests']['stdout'])
    require(observed == listed and listed, 'full CPU list/run exact multiset equality')
    targets = Counter(path for path, row in executables.items() if row['test'])
    require(running_targets(receipts['list']['stderr']) == targets
            and running_targets(receipts['tests']['stderr']) == targets
            and len(footers) == len(summaries) == sum(targets.values()),
            'every built test target listed and executed exactly once')
    require((NATIVE_TEST, 'ignored') in RESULT.findall(receipts['tests']['stdout']),
            'native LLVM test is explicitly ignored in ordinary suite')
    libraries = Counter(path for path, row in executables.items()
                        if row['test'] and row['target'] in {'fe2o3_kernel_analysis', 'fe2o3_verifier'})
    require(len(libraries) == 2, 'exact two final built library harnesses')
    for role in ['native_llvm18', 'native_llvm22']:
        names, counts, native_summaries = results(receipts[role]['stdout'], allow_filtered=True)
        require(names == Counter({NATIVE_TEST: 1}) and counts == Counter({'ok': 1})
                and len(native_summaries) == 2
                and sorted(row[0] for row in native_summaries) == [0, 1],
                role + ': exactly one native compatibility test across two libraries')
        native_targets = running_targets(receipts[role]['stderr'])
        require(native_targets == libraries, role + ': exact final compiled library executables')
    doc_names, doc_counts, doc_summaries = results(receipts['doc']['stdout'])
    require(len(doc_summaries) == 2, 'both selected package doc suites executed')
    require(receipts['ci']['stdout'].endswith('ci-local test gate regression passed\n'),
            'completed CI dispatch regression')
    return {'passed': categories['ok'], 'ignored': categories['ignored'],
            'targets': len(targets), 'listed': sum(listed.values()),
            'native_llvm18_passed': 1, 'native_llvm22_passed': 1,
            'doc_passed': doc_counts['ok'], 'doc_ignored': doc_counts['ignored']}


def source_controls(name, sources):
    require(isinstance(name, str)
            and re.fullmatch(r'final-source-controls(?:-[0-9]{2})?\.json', name) is not None,
            'selected final source-control roster')
    result = read(safe_child(OUT, name))
    prefix = name.removesuffix('.json')
    workflow = regular(ROOT / '.github/workflows/runtime-component-source-guards.yml')
    steps = yaml.safe_load(workflow)['jobs']['source-controls']['steps']
    expected = [(step['name'], shlex.split(line)) for step in steps if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    require(len(expected) == 32 and all(command[:3] == ['python3', '-I', '-B']
                                       for _, command in expected), 'exact 32 workflow controls')
    require(result['accepted'] is True and result['workflow_unchanged'] is True
            and result['workflow_sha256'] == digest(workflow)
            and len(result['commands']) == 32, 'successful source-control campaign')
    for index, ((step, command), row) in enumerate(zip(expected, result['commands']), 1):
        label = f'{prefix}-{index:02d}'
        require(row == {'step': step, 'capture': label, 'command': command, 'exit': 0},
                'exact source-control entry ' + label)
        receipt = capture(label, command, sources)
        require(receipt['command'][3] == '300s', 'source-control bound')
    return len(expected)


def proof_diagnostics(stdout, stderr, proof, negative):
    data = parse(stdout)
    require(data['verus'] == VERIFIER, 'exact solver release identity')
    expected = {'encountered-error': negative, 'encountered-vir-error': False,
                'errors': int(negative), 'verified': int(not negative),
                'is-verifying-entire-crate': not negative}
    if not negative:
        expected['success'] = True
    actual = data['verification-results']
    require(actual == expected and all(type(actual[key]) is type(value)
                                      for key, value in expected.items()),
            'exact structured arithmetic solver result')
    diagnostics = [parse(line) for line in stderr.splitlines() if line]
    if not negative:
        require(not diagnostics, 'positive proof has no diagnostics')
        return
    require(all(row.get('level') in {'error', 'note'} for row in diagnostics),
            'no mutant compiler/tool warnings')
    errors = [row for row in diagnostics if row['level'] == 'error']
    logical = [row for row in errors if row.get('message') == 'postcondition not satisfied']
    abort = [row for row in errors if row.get('message') == 'aborting due to 1 previous error'
             and row.get('spans') == []]
    require(len(errors) == 2 and len(logical) == len(abort) == 1,
            'mutant fails a proof obligation, not decoding/tool invocation')
    notes = {
        'verifying root module (selected functions)',
        'function body check: not all errors may have been reported; rerun with a higher value for --multiple-errors to find other potential errors in this function',
    }
    require(all(row['message'] in notes for row in diagnostics if row['level'] == 'note'),
            'known solver notes only')
    lines = regular(proof).decode().splitlines()
    first = next(index + 1 for index, line in enumerate(lines) if line.startswith('fn ' + FOCUS + '('))
    call = next(index + 1 for index, line in enumerate(lines) if line.strip().startswith(MACRO + '!('))
    body = (proof.parent / '../src/gfx942_integer_semantics_v1/add_u32_body.rs').resolve()
    definition = next(index + 1 for index, line in enumerate(regular(body).decode().splitlines())
                      if line.startswith('macro_rules! ' + MACRO + ' {'))
    spans = logical[0]['spans']
    require(any(span.get('is_primary') is True and Path(span.get('file_name', '')).resolve() == proof
                and first < span.get('line_start', 0) < call for span in spans),
            'mutant primary failure belongs to actual arithmetic contract')
    expansions = [span for span in spans if isinstance(span.get('expansion'), dict)]
    require(any(Path(span.get('file_name', '')).resolve() == body
                and span['expansion'].get('macro_decl_name') == MACRO + '!'
                and Path(span['expansion']['span']['file_name']).resolve() == proof
                and span['expansion']['span']['line_start'] == call
                and Path(span['expansion']['def_site_span']['file_name']).resolve() == body
                and span['expansion']['def_site_span']['line_start'] == definition
                for span in expansions), 'mutant failure reaches actual shared executable body')


def proof_campaign(directory, verus, sources):
    result = read(directory / 'result.json')
    require(result['accepted'] is True and result['full_campaign'] is True
            and result['source_unchanged'] is True and result['error'] is None,
            'complete successful final arithmetic campaign')
    require(result['establishes_hardware_isa_conformance'] is False
            and result['grants_application_authority'] is False, 'proof scope remains arithmetic-only')
    require(result['stages'] == [{'name': name, 'status': status, 'accepted': True}
                                 for name, status in STAGES], 'exact eight-stage proof campaign')
    require(read(directory / 'environment.json') == {
        'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'RUSTUP_HOME': '/home/harsh/.rustup',
        'CARGO_HOME': '/home/harsh/.cargo', 'VERUS_Z3_PATH': str(verus.parent / 'z3'),
        'TMPDIR': str(directory / 'tmp'),
    }, 'exact minimal proof environment')
    before, after = read(directory / 'source-before.json'), read(directory / 'source-after.json')
    paths = {str(path) for path in [BODY, MODEL, PROOF, RUNNER, SUPPORT, OWNER, CLOSURE, MANIFEST,
                                  V / 'gfx942_add_u32_test.py', V / 'run-gfx942-add-u32.sh']}
    require(set(before) == paths and before == after, 'complete unchanged proof/source support closure')
    for name, sha in before.items():
        current = regular(safe_child(ROOT, name))
        require(digest(current) == sha and regular(safe_child(directory / 'inputs', name)) == current,
                'proof retained exact current source: ' + name)
        if name in sources:
            require(sources[name] == sha, 'proof agrees with CPU source closure')
    for path, sha in PINS.items():
        require(before[str(path)] == sha, 'independently pinned proof/controller: ' + str(path))
    require(digest(regular(verus)) == VERUS_SHA, 'actual pinned verifier executable')
    original = regular(directory / 'inputs' / BODY)
    replacements = {
        'negative-discarded-carry': (b'scc: sum >= 0x1_0000_0000_u64', b'scc: false'),
        'negative-wrong-width': (b'value: (sum % 0x1_0000_0000_u64) as u32',
                                 b'value: (sum % 0x1_0000_u64) as u32'),
        'negative-wrong-result': (b'value: (sum % 0x1_0000_0000_u64) as u32', b'value: $a'),
    }
    for name, status in STAGES:
        stage = directory / name
        receipt = read(stage / 'record.json')
        require(type(receipt['status']) is int and receipt['status'] == status
                and receipt['group_absent'] is True
                and type(receipt['process_group']) is int and receipt['process_group'] > 0
                and receipt['finished_ns'] >= receipt['started_ns'], name + ': terminal owned receipt')
        stdout = regular(stage / 'stdout.log').decode()
        stderr = regular(stage / 'stderr.log').decode()
        if name == 'controls':
            require(receipt['command'][1:] == ['-I', '-B', str(ROOT / V / 'gfx942_add_u32_test.py')]
                    and Path(receipt['command'][0]).name.startswith('python3')
                    and not stdout and re.findall(r'^Ran (\d+) tests in [0-9.]+s$', stderr, re.M) == ['5']
                    and stderr.endswith('\nOK\n'), 'five source-only runner controls')
            continue
        if name.startswith('release-'):
            require(receipt['command'] == ['/bin/sh', str(ROOT / CLOSURE), str(verus.parent),
                                           str(ROOT / MANIFEST)]
                    and stdout == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n'
                    and not stderr, 'exact 190-file pinned release measurement')
            continue
        staged = directory / (name + '-source')
        proof = staged / PROOF
        require(regular(proof) == regular(directory / 'inputs' / PROOF), 'unchanged proof contracts')
        body = original
        negative = name in replacements
        if negative:
            old, new = replacements[name]
            require(original.count(old) == 1, 'unique mutant expression')
            body = original.replace(old, new)
        require(regular(staged / BODY) == body, 'exact single executable-body mutation: ' + name)
        command = ['/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5', '120',
                   str(verus), '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating',
                   '--output-json', '--error-format=json', '--no-report-long-running',
                   '--num-threads', '1', '--multiple-errors', '1']
        if negative:
            command += ['--verify-function', '*' + FOCUS, '--verify-root']
        require(receipt['command'] == [*command, str(proof)], 'exact bounded no-cheating solver command')
        proof_diagnostics(stdout, stderr, proof, negative)
    return {'positive_runs': 2, 'verified_functions_per_positive': 1,
            'logical_mutants_rejected': 3, 'runner_controls': 5, 'release_files': 190}


def main():
    require(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3 -I -B')
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--selection', type=Path, default=OUT / 'selection.json')
    args = parser.parse_args()
    require(args.selection.resolve() == args.selection and args.selection.parent == OUT,
            'local explicit selection')
    selection = read(args.selection)
    require(set(selection) == {'schema', 'base', 'captures', 'source_controls', 'proof_output'}
            and selection['schema'] == 'fe2o3.gfx942-integer-qualification-selection.v1'
            and selection['base'] == BASE, 'exact selection schema/base')
    require(digest(regular(OUT / 'capture.py')) == CAPTURE_SHA
            and digest(regular(OUT / 'source-controls.py')) == CONTROLS_SHA, 'pinned capture controllers')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, env=ENV,
                                    text=True).strip() == BASE, 'qualification baseline remains current')
    sources = source_inventory()
    proof_output = safe_child(OUT, selection['proof_output'])
    require(proof_output.name.startswith('proof-final-'), 'final-only solver campaign')
    proof_initial = read(proof_output / 'positive-before' / 'record.json')
    verus = Path(proof_initial['command'][5])
    require(verus.is_absolute() and verus.resolve() == verus, 'canonical verifier path')
    expected = commands(proof_output, verus)
    require(set(selection['captures']) == set(expected)
            and len(set(selection['captures'].values())) == len(expected), 'distinct exact capture roles')
    receipts = {role: capture(selection['captures'][role], command, sources)
                for role, command in expected.items()}
    require(not receipts['format']['stdout'] and not receipts['format']['stderr']
            and not receipts['whitespace']['stdout'] and not receipts['whitespace']['stderr'],
            'clean formatting and whitespace checks')
    executables = build_roster(receipts['build'])
    cpu = cpu_rosters(receipts, executables)
    controls = source_controls(selection['source_controls'], sources)
    arithmetic = proof_campaign(proof_output, verus, sources)
    require(source_inventory() == sources, 'source closure unchanged through independent audit')
    print(json.dumps({
        'accepted': True, 'base': BASE, 'source_files': len(sources),
        'selection_sha256': digest(regular(args.selection)),
        'auditor_sha256': digest(regular(Path(__file__).resolve())),
        'executables': executables, 'cpu': cpu, 'source_controls': controls, 'arithmetic': arithmetic,
        'formatted_rust_files': expected['format'][7:], 'format_exception': FORMAT_EXCEPTION,
        'hardware_qualification': False, 'performance_qualification': False,
        'general_application_authority': False, 'whole_kernel_refinement': False,
    }, sort_keys=True, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (AssertionError, ValueError, KeyError, TypeError, IndexError, StopIteration, OSError,
            subprocess.SubprocessError) as error:
        print(json.dumps({'accepted': False, 'error': type(error).__name__ + ': ' + str(error)}))
        sys.exit(1)
