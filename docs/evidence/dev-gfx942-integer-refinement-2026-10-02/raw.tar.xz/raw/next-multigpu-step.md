# Next Multi-GPU Step: Native Peer Subranges

Read-only design against the late-admission baseline plus the local integer
component, 2026-10-02. No runtime implementation or native qualification is
claimed by this note.

## Priority

Implement native copies between checked subranges of fully initialized PUBLIC
DeviceLocal allocations. Support independent source and destination offsets and
different allocation sizes, while retaining the existing whole-allocation and
whole-child native custody. This lets applications exchange slices of larger
tensors, halo regions and packed buffers without allocating one full buffer per
message or staging the transfer through host storage.

The public production constructors already preserve caller launch authorities:
`crates/fe2o3-runtime/src/kfd_backend/multi_open.rs:24` and `:35`.
The public ordinary/directed copy APIs already describe ranges. The concrete
transport restriction is `compute_xgmi::full_extent` at
`crates/fe2o3-runtime/src/kfd_backend/compute_xgmi.rs:403`, used by selection at
`:522` and again immediately before owner extraction at `:647` and `:695`.
It requires offset zero and the allocation's complete logical length. Valid
partial copies consequently retain host staging today.

This is a production transport improvement independent of a new kernel policy.
It does not solve the missing genuine compiler/effects authority, assert that
the conditional integer obligation provides that authority, or qualify a
performance speedup. Do not extend isolated instruction proofs as a prerequisite
for this transport increment.

## Bounded Contract

- Both original allocations remain completely initialized, PUBLIC, DeviceLocal,
  on the existing authenticated distinct-device route. No uninitialized or
  private allocation conversion.
- Transfer byte length is positive and identical at both ends. Both
  `offset + length` calculations must be checked against the original logical
  extents, never pooled physical extents. The existing packet-count bound stays.
- Map and retain each complete physical owner exactly once. No suballocation
  owner, split initialization certificate, same-VM concurrency or overlapping
  child execution is introduced.
- Each packet uses `source_offset + packet.offset` and
  `destination_offset + packet.offset`; each sum is checked independently.
  Payload outside the destination range and every source byte must be preserved.
- Preserve observer-only poll, bounded explicit progress, cancellation exclusion
  after native custody, exact original owner/generation restoration, both model
  retakes, final-only completion count and terminal quarantine on ambiguity.
- Keep old full-extent APIs as behavior-preserving wrappers. Do not reinterpret
  their extent argument or silently use physical padding as logical storage.

## Minimal Source Boundaries

1. KFD persistent admission:
   `queue_live/compute_xgmi/persistent.rs:430` currently obtains both logical
   lengths and requires their equality at `:463`. Add an admitted immutable copy
   window containing source offset, destination offset and transfer length.
   Validate both ranges before taking either caller owner. Keep the existing
   allocation/attachment/currentness checks intact. Full-extent wrappers use
   offsets zero and retain their equal-logical-length precondition.

2. Shared transfer core:
   `queue_live/compute_xgmi/transfer.rs:44` already retains the packet plan,
   cursor, owners and ticket. Store the two admitted base offsets beside that
   plan and carry them through its existing submit step at `:139`.
   Do not duplicate the mapping/submit/poll/remap algorithms. The packet planner
   still plans relative offsets over the transfer length and needs no new
   generic planning framework.

3. Rooted SDMA adapter:
   `sdma/compute_xgmi.rs:105` currently accepts one offset and checks it against
   both mapped allocations at `:137` and `:142`. Accept independent checked
   offsets there. The underlying `sdma.rs::submit_xgmi` already accepts separately
   computed source/destination GPU addresses. Preserve exact ticket rooting
   before the closing route-currentness check and the existing error order.

4. Runtime native root and selector:
   `kfd_backend/compute_xgmi.rs` must retain the exact admitted copy window,
   propagate it to lower begin, revalidate it before extraction, and preserve
   slot/child identity checks throughout progress. Add a separate checked-region
   helper; do not broadly weaken the existing `full_extent` helper, which the
   pending compute producer profile also relies on. Update the scripted fixture
   to copy the actual slices rather than its current zero-offset prefix.
   Destination whole-shadow/hash invalidation at `:779` remains conservative
   and correct for a partial device update.

5. Directed transport identity:
   `kfd_backend/compute_xgmi/directed.rs:32` currently rechecks `full_extent`.
   Change only the native transport range validation, binding the root window
   exactly to the retained source/destination regions. Keep all directed ranks,
   ancestry, native phase/storage shapes and resource-blocker rules unchanged.

The Context already authenticates and bounds ranges in
`context/peer_custody.rs:38` and `:198`; directed route translation preserves
offsets in `context/peer_directed_context.rs:11`. Pending peer D2H validates
contained ranges in `kfd_backend/peer_readback.rs:25` and `:95`. Deferred compute
checks that every destination read is covered at `deferred_compute.rs:456`.
Revalidate these compositions with tests, not a new Context orchestration API.

## Deliberate First-Increment Limits

Keep pending compute-output -> peer admission full-extent. Both
`kfd_backend/compute_peer.rs:220` and
`context/peer_custody/compute_peer.rs:16` explicitly require it; relaxing that
profile would expand source-writer coverage and version-journal obligations.
Already completed compute output can use the ordinary range path if otherwise
eligible. Existing constructors keep their staged/private defaults.

Do not add vector/scatter-gather requests, concurrent slices of one owner,
persistent peer mappings, new collective kernels or application launch authority
in this increment. Full-extent old callers must remain unchanged.

## Qualification

- Lower composed CPU tests must inspect exact emitted source/destination packet
  addresses with unequal nonzero offsets, different logical/physical extents,
  a packet-boundary crossing and a short tail. Verify original identities,
  tickets, mapping count and one final restoration, plus errors/panics and both
  model-retake boundaries. Zero, overflow, overrun and physical-padding-only
  ranges reject before owner extraction.
- Runtime/Context tests use the existing ordinary and directed APIs, including
  prequeued and truly late directed successors, shared sources, pending D2H and
  a contained deferred-compute read. Exercise event release, final-only drive,
  expired/resumed deadlines, cancellation, capacity/retain failures, terminal
  retention and unchanged full-extent pending-compute rejection boundaries.
- Native witness needs no new compute authority: use the existing production
  copy-only constructor with a deny-all-launch authority. In one live Context,
  run two changed-content rounds over differently sized allocations with
  sentinel guard regions. Transfer a nonzero-offset range longer than one SDMA
  packet, chain or fan out across three GPUs, preadmit exact-event D2H and drive
  only the final readback stream. Compare every source and destination byte,
  including both untouched guards and padding, against an independent host
  oracle. Require exact logical native counts, callbacks and owned cleanup.
- Retain full-extent native controls and existing compute-chain controls. Use
  fresh host/device availability checks before hardware runs; no resets or
  foreign state changes. Any new lower KFD source means historical KFD binary
  reuse is insufficient for that changed source: rebuild and run the relevant
  composed filters plus a fresh exact broad suite before accepting the increment.

The acceptance claim is bounded native subrange correctness and lifecycle
composition. Application compiler authority, native partial-failure isolation,
eight-GPU coverage, physical overlap and matched performance remain separate.
