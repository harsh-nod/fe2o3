#!/usr/bin/env python3
"""Emit, never apply, a strictly lockfile-only runtime-source metadata proposal."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import types

assert sys.flags.isolated and sys.flags.dont_write_bytecode
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '05457de5db1ec371cfe3d893e925a04f052d8295'
RAW = Path(__file__).resolve().parent
OUT = RAW / 'lockfile-metadata-proposal-01'
V = Path('crates/fe2o3-runtime-model/verus')
NAMES = (
    'request-charge', 'retained-credit-record', 'independent-retained-observation',
    'domain-retained-observation', 'retained-credit-dispatch',
)
PREFIXES = tuple(Path('crates') / name for name in (
    'fe2o3-runtime', 'fe2o3-kfd', 'fe2o3-runtime-model', 'fe2o3-resource-accounting',
))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    absolute = ROOT / path
    assert absolute.is_file() and not absolute.is_symlink() and absolute.resolve() == absolute, path
    return absolute.read_bytes()


def baseline(paths):
    paths = sorted(set(paths), key=str)
    result = subprocess.run(
        ['git', 'cat-file', '--batch'], cwd=ROOT,
        input=''.join(f'{BASE}:{path}\n' for path in paths).encode(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True,
    )
    assert not result.stderr
    result_map, cursor = {}, 0
    for path in paths:
        end = result.stdout.index(b'\n', cursor)
        header = result.stdout[cursor:end].split()
        assert len(header) == 3 and header[1] == b'blob', (path, header)
        size = int(header[2])
        cursor = end + 1
        result_map[path] = result.stdout[cursor:cursor + size]
        cursor += size
        assert result.stdout[cursor:cursor + 1] == b'\n'
        cursor += 1
    assert cursor == len(result.stdout)
    return result_map


def load(path):
    module = types.ModuleType('metadata_' + path.stem.replace('-', '_'))
    module.__file__ = str(ROOT / path)
    sys.modules[module.__name__] = module
    exec(compile(read(path), module.__file__, 'exec'), module.__dict__)
    return module


def scalar_edit(path, name, value):
    before = read(path)
    text = before.decode()
    parsed = ast.parse(text)
    targets = [node.value for node in parsed.body
               if isinstance(node, ast.Assign)
               and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
               and node.targets[0].id == name]
    assert len(targets) == 1
    node = targets[0]
    assert isinstance(node, ast.Constant) and isinstance(node.value, str)
    assert re.fullmatch('[0-9a-f]{64}', node.value)
    assert re.fullmatch('[0-9a-f]{64}', value) and value != node.value
    lines = text.splitlines(keepends=True)
    start = sum(map(len, lines[:node.lineno - 1])) + node.col_offset
    end = sum(map(len, lines[:node.end_lineno - 1])) + node.end_col_offset
    token = text[start:end]
    assert token[0] == token[-1] and token[0] in "\"'"
    replacement = token[0] + value + token[-1]
    after = (text[:start] + replacement + text[end:]).encode()
    expected = copy.deepcopy(parsed)
    for item in expected.body:
        if isinstance(item, ast.Assign) and isinstance(item.targets[0], ast.Name) and item.targets[0].id == name:
            item.value.value = value
    assert ast.dump(ast.parse(after), include_attributes=False) == ast.dump(expected, include_attributes=False)
    return before, after, {'path': str(path), 'constant': name, 'before': node.value, 'after': value}


def main():
    assert not OUT.exists(), 'never overwrite a prior proposal'
    listed = subprocess.run(
        ['git', 'ls-tree', '-r', '--name-only', BASE, '--', *map(str, PREFIXES)],
        cwd=ROOT, check=True, capture_output=True,
    )
    assert not listed.stderr
    tracked = {Path(path) for path in listed.stdout.decode().splitlines()
               if path.endswith('.rs') or path.endswith('/Cargo.toml')}
    # Source additions in these runtime domains would invalidate this narrow proposal.
    current_rust = {path.relative_to(ROOT) for prefix in PREFIXES
                    for path in (ROOT / prefix).rglob('*.rs')}
    assert current_rust == {path for path in tracked if path.suffix == '.rs'}
    guard_paths = {V / f'check-{name}.py' for name in NAMES}
    resource = V / 'check-resource-domain.py'
    manifest_path = V / 'pins/R75_DOMAIN_SOURCES_SHA256'
    all_paths = tracked | guard_paths | {resource, manifest_path, Path('Cargo.lock'), Path('Cargo.toml'), Path('rust-toolchain.toml')}
    old = baseline(all_paths)
    changed = {path for path in all_paths if old[path] != read(path)}
    assert changed == {Path('Cargo.lock')}, changed
    before_lock, after_lock = old[Path('Cargo.lock')], read(Path('Cargo.lock'))
    expected_hunk = b' "fe2o3-functional-proof",\n "fe2o3-kernel-ir",\n "fe2o3-lower-mir-kernel",'
    replacement = b' "fe2o3-functional-proof",\n "fe2o3-kernel-analysis",\n "fe2o3-kernel-ir",\n "fe2o3-lower-mir-kernel",'
    assert before_lock.count(expected_hunk) == 1
    assert before_lock.replace(expected_hunk, replacement) == after_lock
    import tomllib
    before_toml, after_toml = tomllib.loads(before_lock.decode()), tomllib.loads(after_lock.decode())
    found = 0
    for package in before_toml['package']:
        if package['name'] == 'fe2o3-verifier':
            assert 'fe2o3-kernel-analysis' not in package['dependencies']
            package['dependencies'] = sorted([*package['dependencies'], 'fe2o3-kernel-analysis'])
            found += 1
    assert found == 1 and before_toml == after_toml
    edits, details, gates, proof_files = {}, [], [], set()
    all_source_hashes = {}
    for name in NAMES:
        path = V / f'check-{name}.py'
        module = load(path)
        current = module.snapshot()
        previous_bytes = baseline(current)
        previous = {path: data.decode() for path, data in previous_bytes.items()}
        assert {path for path in current if current[path] != previous[path]} == {Path('Cargo.lock')}
        module.audit(previous)
        excluded = {module.PROOF}
        if hasattr(module, 'RECORD_PROOF'):
            excluded.add(module.RECORD_PROOF)
        reviewed_tree = {path: text for path, text in current.items() if path not in excluded}
        new_sha = module.tree_hash(reviewed_tree)
        before, after, detail = scalar_edit(path, 'SOURCE_TREE_SHA', new_sha)
        module.SOURCE_TREE_SHA = new_sha
        module.audit(current)
        edits[path] = (before, after)
        details.append(detail)
        proof_files.update(module.FILES)
        assert all(current[item].encode() == previous_bytes[item] for item in module.FILES)
        gates.append({'checker': str(path), 'source_count': len(current),
                      'proof_closure_count': len(module.FILES),
                      'expected_verified': module.EXPECTED_VERIFIED,
                      'mutant_count': module.MUTANT_COUNT,
                      'baseline_audit': True, 'candidate_metadata_audit': True,
                      'changed_sources': ['Cargo.lock']})
        all_source_hashes.update({str(path): {'before': sha(previous_bytes[path]), 'after': sha(text.encode())}
                                  for path, text in current.items()})
    module = load(resource)
    captured = {path: read(path) for path in module.SOURCES}
    previous = baseline(module.SOURCES)
    original_manifest = read(manifest_path)
    module.source_gate(original_manifest, previous)
    target = f'{sha(before_lock)}  Cargo.lock\n'.encode()
    updated = f'{sha(after_lock)}  Cargo.lock\n'.encode()
    assert original_manifest.count(target) == 1
    new_manifest = original_manifest.replace(target, updated)
    edits[manifest_path] = (original_manifest, new_manifest)
    details.append({'path': str(manifest_path), 'manifest_row': 'Cargo.lock', 'before': sha(before_lock), 'after': sha(after_lock)})
    before, after, detail = scalar_edit(resource, 'MANIFEST_SHA', sha(new_manifest))
    edits[resource] = (before, after)
    details.append(detail)
    module.MANIFEST_SHA = sha(new_manifest)
    module.source_gate(new_manifest, captured)
    assert {path for path in captured if captured[path] != previous[path]} == {Path('Cargo.lock')}
    assert len(original_manifest.splitlines()) == len(new_manifest.splitlines()) == len(module.SOURCES)
    proof_files.update(module.PROOF_FILES)
    gates.append({'checker': str(resource), 'source_count': len(captured),
                  'proof_closure_count': len(module.PROOF_FILES),
                  'units': [(name, str(path), count) for name, path, count in module.UNITS],
                  'mutant_count': len(module.mutations(captured)),
                  'baseline_audit': True, 'candidate_metadata_audit': True,
                  'changed_sources': ['Cargo.lock']})
    all_source_hashes.update({str(path): {'before': sha(previous[path]), 'after': sha(data)} for path, data in captured.items()})
    # Detect active transitive identities instead of silently leaving stale helper pins.
    old_script_hashes = {sha(before): str(path) for path, (before, _) in edits.items() if path.suffix == '.py'}
    references = []
    for directory in ('crates', '.github', 'scripts', 'examples'):
        for path in (ROOT / directory).rglob('*'):
            if not path.is_file() or path.suffix not in ('.py', '.sh', '.json', '.yml', '.yaml'):
                continue
            data = path.read_bytes()
            for digest, source in old_script_hashes.items():
                if digest.encode() in data:
                    references.append({'owner': str(path.relative_to(ROOT)), 'referent': source})
    assert not references, references
    assert len(edits) == 7 and len(details) == 7
    assert all(old[path] == before for path, (before, _) in edits.items())
    assert all(read(path) == old[path] for path in tracked)
    proof_base = baseline(proof_files)
    assert all(proof_base[path] == read(path) for path in proof_files)
    patch = ''.join(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
                    after.decode().splitlines(keepends=True), fromfile='a/' + str(path),
                    tofile='b/' + str(path))) for path, (before, after) in sorted(edits.items()))
    OUT.mkdir()
    (OUT / 'metadata.patch').write_text(patch)
    (OUT / 'cargo-lock.patch').write_text(''.join(difflib.unified_diff(before_lock.decode().splitlines(keepends=True), after_lock.decode().splitlines(keepends=True), fromfile='a/Cargo.lock', tofile='b/Cargo.lock')))
    (OUT / 'source-closure.json').write_text(json.dumps(all_source_hashes, sort_keys=True, indent=2) + '\n')
    unchanged = {str(path): sha(old[path]) for path in sorted(tracked)}
    (OUT / 'unchanged-runtime-domains.json').write_text(json.dumps(unchanged, sort_keys=True, indent=2) + '\n')
    (OUT / 'proof-closure.json').write_text(json.dumps({str(path): sha(proof_base[path]) for path in sorted(proof_files)}, sort_keys=True, indent=2) + '\n')
    report = {
        'base': BASE, 'repository_unchanged_by_proposer': True,
        'changed_guard_files': len(edits), 'changed_sha_literals': 6,
        'changed_manifest_hash_rows': 1, 'changed_counts': 0,
        'changed_proof_files': 0, 'changed_predicates': 0,
        'changed_input_sources': ['Cargo.lock'],
        'lockfile_delta': 'one added existing workspace dependency fe2o3-verifier -> fe2o3-kernel-analysis',
        'source_closure_files': len(all_source_hashes), 'proof_closure_files': len(proof_files),
        'unchanged_runtime_domain_files': len(tracked),
        'unchanged_runtime_domain_rust_files': len(current_rust),
        'active_transitive_script_pins': references,
        'gates': gates, 'edits': details, 'metadata_patch_sha256': sha(patch.encode()),
        'limits': 'Identity correspondence maintenance only; no solver run, proof transfer, native/hardware, compiler or application refinement claim.',
    }
    (OUT / 'report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
