#!/bin/bash
set -euo pipefail
chmod 1777 /tmp
mkdir -m 700 /tmp/registry-home /tmp/registry-runtime
export HOME=/tmp/registry-home XDG_RUNTIME_DIR=/tmp/registry-runtime
export RUSTC=/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin/rustc
cp "$1" /tmp/registry-test
chmod 555 /tmp/registry-test
cmp "$1" /tmp/registry-test
exec /tmp/registry-test --exact "compiler_execution_supervision::tests::observer::$2" --ignored --nocapture --test-threads=1
