#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-observer-registry-20261004-VOgg8V4C
binary=$(jq -r 'select(.reason=="compiler-artifact" and .target.name=="fe2o3_broker_authority_service" and .profile.test and .executable != null) | .executable' "$scratch/broker-build.json")
test -x "$binary"
trap 'printf "%s\n" "$?" > "$scratch/root.status"' EXIT
sha256sum "$binary" > "$scratch/root-binary.before.sha256"
for case in cross_uid_owned_occurrence cross_uid_publication_lock_contention cross_uid_registered_observer; do
timeout --kill-after=5s 60s /mnt/c/Windows/System32/wsl.exe --user root --exec \
    /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
    --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
    --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN \
    --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
    /bin/bash "$scratch/inside-root.sh" "$binary" "$case" > "$scratch/$case.log" 2>&1
done
sha256sum "$binary" > "$scratch/root-binary.after.sha256"
cmp "$scratch/root-binary.before.sha256" "$scratch/root-binary.after.sha256"
