#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-observer-registry-20261004-VOgg8V4C
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-observer-registry-2026-10-04"
test "$(cat "$scratch/check.status")" = 0
test "$(cat "$scratch/root.status")" = 0
cd "$repo"
git diff HEAD --binary -- crates/fe2o3-broker-authority-service \
    crates/fe2o3-compiler-execution-coordinator crates/fe2o3-compiler-execution-issuer \
    crates/fe2o3-compiler-execution-supervisor deployment/systemd/fe2o3-compiler-execution.service \
    > "$scratch/code.patch"
git rev-parse HEAD > "$scratch/base-commit.txt"
uname -a > "$scratch/uname.txt"
systemd --version > "$scratch/systemd-version.txt"
sha256sum /usr/lib/x86_64-linux-gnu/systemd/libsystemd-shared-255.so > "$scratch/systemd-library.sha256"
objdump -d --disassemble=seccomp_restrict_namespaces /usr/lib/x86_64-linux-gnu/systemd/libsystemd-shared-255.so > "$scratch/systemd-namespace-filter.txt"
mkdir -p "$evidence"
cd "$scratch"
sha256sum code.patch > code.patch.sha256
tar -czf "$evidence/evidence.tar.gz" \
    check.sh qualify-root.sh inside-root.sh package.sh \
    check.status root.status unit.log doc.log clippy.log deployment.log \
    observer-four-thread.log broker-build.json broker-build.log \
    cross_uid_owned_occurrence.log cross_uid_publication_lock_contention.log \
    cross_uid_registered_observer.log root-binary.before.sha256 root-binary.after.sha256 \
    root-initial-metadata-failure.log format.log whitespace.log \
    base-commit.txt code.patch code.patch.sha256 uname.txt systemd-version.txt \
    systemd-library.sha256 systemd-namespace-filter.txt
sha256sum "$evidence/evidence.tar.gz"
cat code.patch.sha256 root-binary.after.sha256
