# Pending Directed-Peer Compute Router Qualification

Workspace: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Parent: `211026571ea9fd7da1dfba15caf9f4f5456d9c74`.
Cargo commands use `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1` and `--offline`.

Executed development lanes:

```
cargo check --offline -p fe2o3-runtime --all-features
cargo test --offline -p fe2o3-runtime --all-features --lib peer_launch_public -- --nocapture
cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=4
cargo test --offline -p fe2o3-runtime --all-features --lib peer_launch -- --test-threads=4
cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
cargo fmt --all
cargo fmt --all -- --check
cargo check --offline -p fe2o3-runtime --no-default-features
cargo test --offline -p fe2o3-runtime --all-features --doc
git diff --check
```

The first public-path run passed 1 and failed 2 tests. Its 4096-byte full-H2D
fixture incorrectly expected a Retire step, although that shape follows the
existing full-H2D-ready promotion path. The failure was `recycle mismatch:
Retire(Success)`. The fixture now copies a 2048-byte prefix into initialized
4096-byte storage, checks the untouched suffix, and uses full-range compute.
The corrected three public-path groups passed. These initial command outputs
were observed through the execution tool, not saved as raw log files.

`runtime-all-features-1.log` is an intermediate full run: 1634 passed, 3 existing
socket-permission failures, 28 ignored. `peer-launch-2.log` is an intermediate
focused run: 20 passed, including five new test groups. Later source adds the
same-stream later-native-work regression and moves the shared borrowed
publication-blocker predicate into compute_dispatch. Those intermediate logs
are not evidence for the final source; use the final logs and source hashes.

`runtime-all-features-final.log` was superseded: it passed 1635 and failed 4
(28 ignored). The extra failure was the new later-native-work regression's
CPU-only extra buffer, correctly rejected by native binding validation. The
fixture now installs a scripted native host owner and its matching recycle step;
no production admission check changed. Only peer_launch_tests.rs changed between
runtime-sources.sha256 and runtime-sources-final.sha256.

`runtime-all-features-final-v2.log`: 1636 passed, 3 failed, 28 ignored, exit 101.
The three failures are the unchanged authorized_execution.rs:1317 tests with
InspectSocket(PermissionDenied). This is not a fully green qualification.
All five newly added test groups pass, including the later-native-work case.
`runtime-doctests.log`: 8 merged plus 44 other doctests passed (52 total).
`clippy-final.log`: strict all-feature/all-target runtime Clippy passed, exit 0.
`runtime-minimal.log`: no-default-feature runtime check passed, exit 0.
`fmt-check.log`: formatting check passed, exit 0. Whitespace checks passed.
`source-continuity-final.log`: every final runtime source hash matched after
commit. Signed implementation: `2e6f65fab2f70af2a4af533c3fed2a8a1ef525e0`.
`source-commit.patch` contains the complete committed implementation including
the new test file; `implementation.patch` is an earlier tracked-file-only diff.
The SSH signature was verified; see `source-signature.log`.
No native KFD suite, Verus campaign, ELF audit, or GPU benchmark was rerun.

Two read-only native collaboration agents reviewed the lifecycle and DMA
authorization. Root owns all changes and executions. Their findings led to
allocation-scoped opaque admission, actual owner-roster and publication-index
checks, exact route stamps, linear retirement, target failure preservation,
exact-head progression, and polling before publication. No permission request,
escalation, external Qwen process or sandbox bypass was used.

`ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname` returned exit 255:
`Could not resolve hostname sharkmi300x-1: Temporary failure in name resolution`.
No remote job, file, allocation, or GPU reservation was created.

GitHub issue 182 was read through `gh issue view`: OPEN, title
`Runtime: build an asynchronous distributed direct-KFD execution plane`,
updated 2026-09-27T08:31:31Z at observation. This checkpoint does not close it.
