#!/usr/bin/env python3
"""Audit disjoint shard coverage and the independently terminal runtime run."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
output = root / "cpu-qualification.json"
assert not output.exists()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def roster(path):
    names = sorted(line.removesuffix(": test") for line in path.read_text().splitlines()
                   if line.endswith(": test"))
    assert len(names) == len(set(names))
    return names


tests = root / "attempt-03/tests"
build = root / "attempt-03/build"
full_kfd = roster(tests / "fe2o3_kfd-full-list.stdout")
assert len(full_kfd) == 1918
kfd_hash = (build / "fe2o3_kfd.sha256").read_text().split()[0]
assert digest(Path((build / "fe2o3_kfd.path").read_text().strip())) == kfd_hash
coverage = []
packets = []
for mode in ("0", "1", "2", "rest"):
    shard = root / ("kfd-shard-" + mode)
    inputs = json.loads((shard / "inputs.json").read_text())
    result = json.loads((shard / "result.json").read_text())
    selected = inputs["selected"]
    assert inputs["executable_sha256"] == kfd_hash
    assert selected == roster(shard / "list.stdout")
    assert result["accepted"] and result["exit_code"] == 0
    assert result["group_absent"] and result["executable_unchanged"]
    assert not result["timed_out"]
    for stream in ("stdout", "stderr"):
        assert result[stream + "_sha256"] == digest(shard / ("run." + stream))
    passed = []
    for line in (shard / "run.stdout").read_text().splitlines():
        match = re.fullmatch(r"test (\S+) \.\.\. ok", line)
        if match:
            passed.append(match.group(1))
    assert sorted(passed) == selected
    coverage.extend(selected)
    packets.append(dict(mode=mode, tests=len(selected), result_sha256=digest(shard / "result.json")))
assert len(coverage) == len(set(coverage)) == 1918
assert sorted(coverage) == full_kfd
assert (tests / "fe2o3_kfd-full.exit").read_text().strip() == "143"
assert (tests / "overall.exit").read_text().strip() == "1"

runtime_hash = (build / "fe2o3_runtime.sha256").read_text().split()[0]
assert digest(Path((build / "fe2o3_runtime.path").read_text().strip())) == runtime_hash
for phase in ("before", "after"):
    assert (tests / ("fe2o3_runtime-" + phase + ".sha256")).read_text().split()[0] == runtime_hash
assert (tests / "fe2o3_runtime-full.exit").read_text().strip() == "0"
runtime_roster = roster(tests / "fe2o3_runtime-full-list.stdout")
assert len(runtime_roster) == 2018
runtime_output = (tests / "fe2o3_runtime-full.stdout").read_text()
summaries = [line for line in runtime_output.splitlines() if line.startswith("test result:")]
assert len(summaries) == 1
assert summaries[0].startswith("test result: ok. 1986 passed; 0 failed; 32 ignored; 0 measured; 0 filtered out;")
observed = []
statuses = {"ok": 0, "ignored": 0}
for line in runtime_output.splitlines():
    match = re.fullmatch(r"test (\S+) \.\.\. (ok|ignored)(?:, .*)?", line)
    if match:
        observed.append(match.group(1))
        statuses[match.group(2)] += 1
assert sorted(observed) == runtime_roster
assert statuses == {"ok": 1986, "ignored": 32}
result = dict(accepted=True, audited_at=datetime.now(timezone.utc).isoformat(),
    kfd=dict(passed=1918, failed=0, ignored=0, executable_sha256=kfd_hash,
             disjoint_roster_coverage=True, shards=packets, serial_run_exit=143,
             serial_run_accepted=False),
    runtime=dict(passed=1986, failed=0, ignored=32, filtered=0,
                 executable_sha256=runtime_hash, summary=summaries[0],
                 stdout_sha256=digest(tests / "fe2o3_runtime-full.stdout")),
    original_tests_controller_exit=1,
    original_tests_controller_accepted=False)
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
