#!/usr/bin/env python3
"""Capture one bounded read-only host observation and sanitized local context."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "admission"
PRIOR = Path("/home/harsh/.codex-tmp/fe2o3-multigpu-native-recovery-20261001/admission-continuation-20261002/result.json")
BASE = "1327f19b1b0c9481ac5d2cd62c27a6a50ed609aa"
EXPECTED = "ssh -T -o BatchMode=yes -o ConnectTimeout=10 mi300x /usr/bin/timeout --kill-after=5s 30s /usr/bin/env -u HIP_VISIBLE_DEVICES -u ROCR_VISIBLE_DEVICES -u CUDA_VISIBLE_DEVICES -u GPU_DEVICE_ORDINAL /opt/rocm/bin/rocm-smi --showuse --showmeminfo vram --showuniqueid --showbus --showpids --json"


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def capture(argv, timeout):
    started = utc()
    clock = time.monotonic()
    try:
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=timeout, check=False)
        return dict(started_at_utc=started, finished_at_utc=utc(),
                    elapsed_seconds=time.monotonic() - clock, argv=argv,
                    exit_code=result.returncode, timed_out=False), result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        return dict(started_at_utc=started, finished_at_utc=utc(),
                    elapsed_seconds=time.monotonic() - clock, argv=argv,
                    exit_code=124, timed_out=True), error.stdout or b"", error.stderr or b""


def main():
    prior_bytes = PRIOR.read_bytes()
    command = json.loads(prior_bytes)["command"]
    assert command == EXPECTED
    OUT.mkdir()
    config_receipt, config, config_error = capture(["ssh", "-G", "mi300x"], 15)
    safe_keys = {"host", "hostname", "port", "canonicalizehostname", "addressfamily"}
    fields = {}
    for line in config.decode("utf-8", "replace").splitlines():
        key, _, value = line.partition(" ")
        if key in safe_keys:
            fields[key] = value
        elif key in {"proxycommand", "proxyjump"}:
            fields[key + "_configured"] = value not in {"none", ""}
    hostname = fields.get("hostname", "")
    local = dict(observed_at_utc=utc(), ssh_config=config_receipt,
                 effective_destination=fields,
                 config_stderr_sha256=hashlib.sha256(config_error).hexdigest(),
                 config_stderr_bytes=len(config_error))
    local["resolver_path"] = str(Path("/etc/resolv.conf").resolve())
    local["resolver_directives"] = [line for line in Path("/etc/resolv.conf").read_text().splitlines()
                                    if line.split() and line.split()[0] in {"nameserver", "search", "domain", "options"}]
    local["hosts_database"] = [line for line in Path("/etc/nsswitch.conf").read_text().splitlines()
                               if line.startswith("hosts:")]
    local["matching_hosts_entries"] = [line for line in Path("/etc/hosts").read_text().splitlines()
                                       if hostname and hostname in line.split("#", 1)[0].split()[1:]]
    (OUT / "local-context.json").write_text(json.dumps(local, indent=2) + "\n")
    receipt, stdout, stderr = capture(shlex.split(command), 60)
    (OUT / "availability.json").write_bytes(stdout)
    (OUT / "availability.stderr").write_bytes(stderr)
    dns_failed = b"Could not resolve hostname" in stderr
    receipt.update(source_base=BASE, purpose="single fresh bounded read-only shared-host admission",
                   command=command, local_timeout_seconds=60,
                   retained_command_receipt_sha256=hashlib.sha256(prior_bytes).hexdigest(),
                   stdout="availability.json", stderr="availability.stderr",
                   blocker=stderr.decode("utf-8", "replace").strip() if receipt["exit_code"] else None,
                   remote_command_executed=False if dns_failed else (True if receipt["exit_code"] == 0 else None),
                   remote_files_changed=False, gpu_workload_executed=False,
                   fresh_available_pair=None, followup_hardware_attempts=0)
    (OUT / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(dict(local_context=local, admission=receipt), indent=2))


if __name__ == "__main__":
    main()
