#!/usr/bin/env python3
"""Retain only the configured host from a read-only local Tailscale peer map."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time


out = Path(__file__).resolve().parent / "admission" / "same-host-tailscale.json"
assert not out.exists()
argv = ["/usr/bin/tailscale", "status", "--json"]
started = datetime.now(timezone.utc).isoformat(timespec="seconds")
clock = time.monotonic()
timed_out = False
try:
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=15, check=False)
    stdout, stderr, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as error:
    stdout, stderr, code = error.stdout or b"", error.stderr or b"", 124
    timed_out = True
receipt = dict(started_at_utc=started,
               finished_at_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
               elapsed_seconds=time.monotonic() - clock, command=argv, exit_code=code,
               timed_out=timed_out, local_timeout_seconds=15,
               stdout_bytes=len(stdout), stdout_sha256=hashlib.sha256(stdout).hexdigest(),
               stderr=stderr.decode("utf-8", "replace"), configuration_changes=0,
               connection_overrides=0, configured_hostname="sharkmi300x-1", matches=[])
if code == 0:
    status = json.loads(stdout)
    receipt["backend_state"] = status.get("BackendState")
    for peer in (status.get("Peer") or {}).values():
        if peer.get("HostName") != "sharkmi300x-1":
            continue
        fields = {key: peer.get(key) for key in
                  ["HostName", "DNSName", "TailscaleIPs", "Online", "Active", "LastSeen", "LastHandshake"]}
        fields["tailscale_public_identity_sha256"] = hashlib.sha256(
            str(peer.get("PublicKey", "")).encode()).hexdigest()
        receipt["matches"].append(fields)
with out.open("x") as target:
    target.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
