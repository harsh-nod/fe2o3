#!/usr/bin/env python3
"""Read only exact-host SSH control settings and existing socket associations."""

from datetime import datetime, timezone
import hashlib
import ipaddress
import json
from pathlib import Path
import stat
import subprocess
import sys


OUT = Path(__file__).resolve().parent / "admission" / "same-host-control.json"
HOSTS = {"mi300x", "sharkmi300x-1", "sharkmi300x-1.tail00726f.ts.net"}


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def peer_address(encoded):
    address, port = encoded.split(":")
    chunks = [address[index:index + 8] for index in range(0, len(address), 8)]
    raw = b"".join(int(chunk, 16).to_bytes(4, sys.byteorder) for chunk in chunks)
    return {"address": str(ipaddress.ip_address(raw)), "port": int(port, 16)}


def main():
    assert not OUT.exists()
    started = utc()
    command = ["ssh", "-G", "mi300x"]
    result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=15, check=False)
    allowed = {"host", "hostname", "port", "controlmaster", "controlpath",
               "controlpersist", "hostkeyalias"}
    config = {}
    for line in result.stdout.decode("utf-8", "replace").splitlines():
        key, _, value = line.partition(" ")
        if key in allowed:
            config[key] = value
        elif key in {"proxycommand", "proxyjump"}:
            config[key + "_configured"] = value not in {"none", ""}
    socket_record = {"configured": config.get("controlpath", "none") != "none"}
    if socket_record["configured"]:
        path = Path(config["controlpath"]).expanduser()
        try:
            info = path.lstat()
            socket_record.update(exists=True, is_socket=stat.S_ISSOCK(info.st_mode),
                                 uid=info.st_uid, inode=info.st_ino)
        except OSError as error:
            socket_record.update(exists=False, error_type=type(error).__name__, errno=error.errno)

    matching = []
    tailscaled_visible = False
    for directory in Path("/proc").iterdir():
        if not directory.name.isdecimal():
            continue
        try:
            name = (directory / "comm").read_text().strip()
            if name == "tailscaled":
                tailscaled_visible = True
            if name != "ssh":
                continue
            argv = (directory / "cmdline").read_bytes().split(b"\0")
            hosts = [argument.decode("utf-8", "replace").split("@")[-1]
                     for argument in argv if argument]
            hosts = [host for host in hosts if host in HOSTS]
            if not hosts:
                continue
            record = {"pid": int(directory.name), "exact_host_arguments": hosts,
                      "established_socket_peers": [], "socket_errors": []}
            socket_inodes = set()
            try:
                for entry in (directory / "fd").iterdir():
                    try:
                        target = str(entry.readlink())
                        if target.startswith("socket:[") and target.endswith("]"):
                            socket_inodes.add(target[8:-1])
                    except OSError as error:
                        record["socket_errors"].append({"operation": "fd-readlink",
                                                       "errno": error.errno})
            except OSError as error:
                record["socket_errors"].append({"operation": "fd-list", "errno": error.errno})
            record["readable_socket_inodes"] = len(socket_inodes)
            for family in ("tcp", "tcp6"):
                try:
                    rows = (directory / "net" / family).read_text().splitlines()[1:]
                    for row in rows:
                        columns = row.split()
                        if len(columns) > 9 and columns[9] in socket_inodes and columns[3] == "01":
                            peer = peer_address(columns[2])
                            if peer["port"] == int(config.get("port", "22")):
                                record["established_socket_peers"].append(peer)
                except OSError as error:
                    record["socket_errors"].append({"operation": "read-" + family,
                                                   "errno": error.errno})
            matching.append(record)
        except (OSError, ValueError):
            continue
    receipt = dict(started_at_utc=started, finished_at_utc=utc(), command=command,
                   exit_code=result.returncode, effective_control_config=config,
                   config_stderr_bytes=len(result.stderr),
                   config_stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
                   configured_control_socket=socket_record,
                   same_host_processes=matching, tailscaled_process_visible=tailscaled_visible,
                   process_actions=0, control_commands=0, network_connections=0,
                   configuration_changes=0,
                   limitation="Socket association is not host-key authentication or GPU admission.")
    with OUT.open("x") as target:
        target.write(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
