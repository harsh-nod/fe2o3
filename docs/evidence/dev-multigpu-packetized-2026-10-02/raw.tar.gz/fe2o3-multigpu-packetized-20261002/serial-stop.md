# Intentional Serial Test Stop

The primary agent stopped only its owned KFD full-suite child PID 1145658 with
SIGTERM after inspecting its exact executable through `/proc` and using a
pidfd to avoid PID reuse. The unchanged executable was
`/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-408178a9a9b41651`.
The test controller records exit 143 and retains all output, then proceeds to
the runtime checks. The aggregate controller therefore remains nonzero.

The serial run was spending most of its time in the unchanged 324-test primary
queue-construction matrix. It is not accepted as a full-suite result. Four
separate immutable-ELF runs replace it: three disjoint 108-test construction
shards and one 1,594-test remainder. Exact discovery, union coverage, terminal
receipts and unchanged executable hashes are required independently. No other
process was stopped, and no tests were removed from the qualification roster.
