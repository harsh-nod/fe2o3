#!/usr/bin/env python3
"""Exact, disjoint CPU rosters over the already-built immutable KFD executable."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in {"0", "1", "2", "rest"}
out = root / ("kfd-shard-" + mode)
out.mkdir()
binary = Path((root / "attempt-03/build/fe2o3_kfd.path").read_text().strip())
expected_hash = (root / "attempt-03/build/fe2o3_kfd.sha256").read_text().split()[0]
assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_hash
listed = (root / "attempt-03/tests/fe2o3_kfd-full-list.stdout").read_text().splitlines()
all_tests = sorted(line.removesuffix(": test") for line in listed if line.endswith(": test"))
assert len(all_tests) == len(set(all_tests)) == 1918
prefix = "queue::live::construction_primary::"
heavy = [name for name in all_tests if name.startswith(prefix)]
assert len(heavy) == 324
selected = [name for name in all_tests if not name.startswith(prefix)] if mode == "rest" else heavy[int(mode)::3]
assert len(selected) == (1594 if mode == "rest" else 108)
environment = dict(HOME="/home/harsh", PATH="/usr/bin:/bin", LANG="C.UTF-8", LC_ALL="C.UTF-8", RUST_TEST_THREADS="1")
argv = [str(binary), "--test-threads=1", "--exact", *selected]
(out / "inputs.json").write_text(json.dumps(dict(argv=argv, environment=environment,
    executable_sha256=expected_hash, selected=selected, total_roster=1918,
    cwd="/home/harsh/.codex-tmp/fe2o3-r61-execution"), indent=2) + "\n")
discovery = subprocess.run([*argv, "--list"], env=environment, text=True, capture_output=True, check=False)
(out / "list.stdout").write_text(discovery.stdout)
(out / "list.stderr").write_text(discovery.stderr)
observed = sorted(line.removesuffix(": test") for line in discovery.stdout.splitlines() if line.endswith(": test"))
assert discovery.returncode == 0 and observed == selected
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
timed_out = False
with (out / "run.stdout").open("wb") as stdout, (out / "run.stderr").open("wb") as stderr:
    process = subprocess.Popen(argv, cwd="/home/harsh/.codex-tmp/fe2o3-r61-execution",
        env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        status = process.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        status = 124
try:
    os.killpg(process.pid, 0)
    group_absent = False
except ProcessLookupError:
    group_absent = True
unchanged = hashlib.sha256(binary.read_bytes()).hexdigest() == expected_hash
text = (out / "run.stdout").read_text()
summary = [line for line in text.splitlines() if line.startswith("test result:")]
expected = f"test result: ok. {len(selected)} passed; 0 failed; 0 ignored; 0 measured; {1918 - len(selected)} filtered out;"
accepted = status == 0 and group_absent and unchanged and len(summary) == 1 and summary[0].startswith(expected)
receipt = dict(accepted=accepted, exit_code=status, timed_out=timed_out, started=started,
    finished=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - clock,
    group_absent=group_absent, executable_unchanged=unchanged, summary=summary,
    stdout_sha256=hashlib.sha256((out / "run.stdout").read_bytes()).hexdigest(),
    stderr_sha256=hashlib.sha256((out / "run.stderr").read_bytes()).hexdigest())
(out / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
sys.exit(0 if accepted else 1)
