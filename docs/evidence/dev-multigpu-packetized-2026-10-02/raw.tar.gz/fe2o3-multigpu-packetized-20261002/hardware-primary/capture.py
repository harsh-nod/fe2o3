#!/usr/bin/env python3
"""Bounded primary-session transport with fresh, immutable command receipts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

out = Path(__file__).resolve().parent / sys.argv[1]
out.mkdir()
argv = sys.argv[2:]
assert argv and argv[0] in {"ssh", "scp"}
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
try:
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=200, check=False)
    status, stdout, stderr = result.returncode, result.stdout, result.stderr
except subprocess.TimeoutExpired as error:
    status, stdout, stderr = 124, error.stdout or b"", error.stderr or b""
(out / "stdout").write_bytes(stdout)
(out / "stderr").write_bytes(stderr)
receipt = dict(argv=argv, started=started, elapsed_seconds=time.monotonic() - clock,
               finished=datetime.now(timezone.utc).isoformat(), exit_code=status,
               stdout_sha256=hashlib.sha256(stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(stderr).hexdigest())
(out / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
print(stdout.decode("utf-8", "replace"))
print(stderr.decode("utf-8", "replace"), file=sys.stderr)
sys.exit(status)
