#!/usr/bin/env python3
"""Finite correctness campaign on the freshly observed idle pair, not performance."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
baseline = json.loads((root / "admission/availability.json").read_text())
ids = ["0x10a254ce4987e716", "0x53691ef168a0147d"]
ssh = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5", "-o", "StrictHostKeyChecking=yes", "mi300x"]
binary = "/tmp/fe2o3-multigpu-packetized-20261002-hFERwj/candidate-witness"
cases = [
    ("candidate-default", [], ids),
    ("candidate-queued", ["--queued-consumer"], ids),
    ("candidate-packetized", ["--packetized-copy"], ids),
    ("candidate-combined", ["--queued-consumer", "--packetized-copy"], ids),
    ("candidate-reverse-packetized", ["--packetized-copy"], list(reversed(ids))),
]
completed = []
failure = None

def capture(name, argv):
    result = subprocess.run([sys.executable, "-I", "-B", str(root / "capture.py"), name, *argv],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode != 0:
        raise RuntimeError(f"{name} exited {result.returncode}: {result.stderr.decode(errors='replace')}")
    return (root / name / "stdout").read_text()

try:
    for name, flags, selected_ids in cases:
        raw = capture(name + "-admission", ssh + [
            "/usr/bin/timeout", "--kill-after=5s", "30s", "/opt/rocm/bin/rocm-smi",
            "--showuse", "--showmeminfo", "vram", "--showuniqueid", "--showpids", "--json"])
        admission = json.loads(raw)
        for card, expected_id in zip(["card6", "card7"], ids):
            assert admission[card]["Unique ID"] == expected_id
            assert admission[card]["GPU use (%)"] == "0"
            assert admission[card]["VRAM Total Used Memory (B)"] == baseline[card]["VRAM Total Used Memory (B)"]
        assert admission["system"] == baseline["system"], "process roster changed; re-admit before running"
        output = capture(name, ssh + [
            "/usr/bin/timeout", "--kill-after=5s", "180s", "/usr/bin/prlimit", "--core=0", "--",
            "/usr/bin/env", "-u", "HIP_VISIBLE_DEVICES", "-u", "ROCR_VISIBLE_DEVICES",
            "-u", "CUDA_VISIBLE_DEVICES", "-u", "GPU_DEVICE_ORDINAL", binary, *flags, *selected_ids])
        lines = output.splitlines()
        assert len(lines) == 1 and lines[0].startswith("PASS ")
        fields = dict(field.split("=", 1) for field in lines[0].split()[1:])
        packetized = "--packetized-copy" in flags
        expected = dict(devices="2", launches="4", launches_per_device="2",
                        peer_copies="3" if packetized else "1", bytes="262144",
                        transport="NATIVE-XGMI", observed_native_copies="3" if packetized else "1",
                        source_unique_id=selected_ids[0], destination_unique_id=selected_ids[1],
                        readbacks="21" if packetized else "13", allocations="18" if packetized else "10",
                        packetized_copies="2" if packetized else "0",
                        packetized_packets="5" if packetized else "0",
                        packetized_bytes="12582854" if packetized else "0",
                        output="full-byte-pass", source_unchanged="full-byte-pass",
                        destination_sentinel="full-byte-pass", cleanup="logical-and-native-explicit",
                        performance_acceptance="false", formal_refinement="false")
        assert all(fields.get(key) == value for key, value in expected.items()), fields
        completed.append(dict(name=name, fields=fields))
        print(name + " PASS", flush=True)
except Exception as error:
    failure = repr(error)
finally:
    result = dict(accepted=failure is None and len(completed) == len(cases), failure=failure,
                  completed=completed, expected_cases=len(cases), exclusive_reservation=False,
                  witness_sha256="3bdcfc078ccd29eb73d1913ea3a5c591e2ad756dbef4efedb48011df604e90c6",
                  performance_acceptance=False, formal_refinement=False)
    with (root / "candidate-campaign.json").open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(json.dumps(result), flush=True)
sys.exit(0 if result["accepted"] else 1)
