# Native Full-Extent Packetized Peer Copies

Base: 1327f19b1b0c9481ac5d2cd62c27a6a50ed609aa.
Priority: A3 working local multi-GPU, not full HIP/HSA parity.

- Lower owner: reuse one original PUBLIC persistent pair and directional queue;
  one exact packet ticket at a time, map once, restore once, explicit bounded
  progress, terminal retention on uncertainty, both VM model retakes each step.
- Runtime owner: bounded plan eligibility, no host staging for admitted full
  extents, no consumer handoff or native logical completion before restoration.
- Arithmetic owner: immutable allocation-free plan, shared executable Verus
  count/subrange bodies, positive and logical-negative proof campaign.
- Primary: witness, integration, serialized Cargo qualification, evidence and
  signed publication to both configured topic remotes.

The proof covers arithmetic only. Mapping, DMA, syscall currentness, whole
adapter/Context correspondence and physical overlap are not formally qualified
by that proof. Scripted tests do not claim GPU payload execution. Worker-namespace
DNS failures were superseded by successful primary-session SSH and process
discovery at 03:47 UTC. A fresh occupancy check is required before each hardware
run; no matched performance claim is made. Runtime allocation cap remains 256 MiB.

Each controller attempt snapshots its own script before execution. Cargo test
executables are selected from structured compiler-artifact records; focused
rosters must be nonempty. Rejected attempts remain in the raw packet. The
preexisting docs/evidence/dev-owner-inspection-2026-09-23 directory is excluded.
