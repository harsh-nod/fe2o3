#!/bin/bash
set -eu
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-multigpu-packetized-20261002
evidence="$root/docs/evidence/dev-multigpu-packetized-2026-10-02"
cd "$root"
test ! -e "$raw/source.patch"
git rev-parse HEAD > "$raw/base-commit.txt"
git diff HEAD --binary > "$raw/source.patch"
git diff HEAD --name-only > "$raw/source-paths.txt"
for path in \
    crates/fe2o3-kfd/src/sdma/compute_xgmi_plan.rs \
    crates/fe2o3-kfd/src/sdma/compute_xgmi_plan_body.rs \
    crates/fe2o3-runtime-model/verus/compute_xgmi_packet_plan_check.py \
    crates/fe2o3-runtime-model/verus/compute_xgmi_packet_plan_test.py \
    crates/fe2o3-runtime-model/verus/compute_xgmi_packet_plan_v1.rs \
    crates/fe2o3-runtime/src/kfd_backend/compute_xgmi/tests/packetized.rs; do
    test -f "$path"
    git diff --no-index --binary -- /dev/null "$path" >> "$raw/source.patch" || test "$?" = 1
    printf '%s\n' "$path" >> "$raw/source-paths.txt"
done
sort -u "$raw/source-paths.txt" -o "$raw/source-paths.txt"
while IFS= read -r path; do sha256sum "$path"; done < "$raw/source-paths.txt" > "$raw/source.sha256"
sha256sum "$raw/source.patch" > "$raw/source-patch.sha256"
git apply --reverse --check "$raw/source.patch"
cp -a /home/harsh/.codex-tmp/fe2o3-compute-xgmi-packet-plan-20261002 "$raw/arithmetic-proof"
cp -a /home/harsh/.codex-tmp/fe2o3-multigpu-access-recheck-20261002T032147Z-1327f19b1 "$raw/hardware-access"
mkdir -p "$evidence"
test ! -e "$evidence/raw.tar.gz"
tar -C "$(dirname "$raw")" -czf "$evidence/raw.tar.gz" "$(basename "$raw")"
cd "$evidence"
sha256sum raw.tar.gz > SHA256SUMS
