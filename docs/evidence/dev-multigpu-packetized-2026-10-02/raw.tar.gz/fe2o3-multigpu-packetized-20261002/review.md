# Independent Review Receipts

Runtime owner reviewed lower transfer/planner and the hardware witness read-only.
No concrete correctness blocker found. Completed mappings are rooted before the
exact completed ticket is cleared; explicit progress publishes at most one next
packet. Ordinary observations cannot publish. Final restoration and child
handoff remain separate. Auxiliary witness buffers do not expand the four exact
kernel launches; version-journal occupancy peaks at 14 of 16 allocation slots.

Lower owner independently reviewed proof-attempt-05 without rerunning Verus.
All ten captured source hashes match current bytes. Both staged positive sources
use the actual shared production macro bodies and report five verified, zero
errors. All eight mutants are exact declared single-body replacements with
unchanged contracts, rejected by the intended postcondition diagnostic and macro
expansion. All thirteen receipts are terminal with owned process groups absent.
The independently recomputed full tool closure contains 190 files, 129019839
bytes, tree hash b316002910faf893a094684179398d3a66c30440cd6c707a0fef9b0d2e2f4092.
This establishes arithmetic evidence, not Rust wrapper-state, adapter, DMA,
mapping, currentness, runtime, hardware or performance refinement.

Primary reviewed the production diff and the source-control metadata proposal.
The added lower facade exports were fixed after initial compile failure. The
runtime test's private-field and nonexistent-field accesses were replaced with
existing ledger/query checks, not production visibility changes. Metadata-only
updates change twenty SHA literals and seven source counts, not contracts,
predicates, expected solver totals or mutant totals. Cadence's two whole-file
pins are refreshed only after authenticating import/registration-only deltas.
The final source-control workflow and final-source audit are separately retained.

Earlier worker-network failures are not a current host availability claim.
Primary-session SSH succeeded and the authoritative process roster was queried;
hardware outcomes and cleanup must be read from hardware-primary receipts.

Arithmetic/source-control owner independently audited the primary hardware packet
read-only. All 25 capture receipts have matching stdout/stderr hashes and exit
zero. The five candidate PASS lines match campaign fields, including progress
and consumer-admission fields omitted from the controller's asserted subset.
Per-case re-admission finished 60-82 ms before launch. The initial PID-to-GPU
mapping showed work only on GPU 0; this was not a continuous FD census or an
exclusive reservation. Candidate and baseline binaries match their separate
initial/final hashes. Final admission fields equal baseline-admission fields.
Exactly two uploaded executables were removed; rmdir of the owned directory
returned zero at 04:05:27 UTC. Seven total runs mean two baseline plus five
candidate runs, not seven candidate runs. Combined mode queues the fixed
262144-byte R57 consumer, then separately drains auxiliary large copies; it
does not qualify compute consumption of large packetized outputs.

The arithmetic/source-control owner reviewed the CPU aggregator independently.
It requires exact discovery and raw pass-name rosters, disjoint union equality
with all 1,918 KFD tests, matching executable and output hashes, and closed
process groups. Runtime qualification is independently terminal: 1,986 passes,
32 existing ignores, no failures or filtering. The reviewer checked those
categories directly; the primary then added explicit per-category assertions.
The intentionally stopped serial KFD run and original controller remain rejected
with exit 143 and one respectively. Four replacement shards all pass, without
omitting tests or relabeling the serial attempt. No source changes occurred.
