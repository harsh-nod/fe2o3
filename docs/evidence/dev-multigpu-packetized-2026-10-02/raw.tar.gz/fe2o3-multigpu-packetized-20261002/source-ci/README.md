# Packetized Native-Copy Source Controls

The authoritative baseline is `1327f19b1b0c9481ac5d2cd62c27a6a50ed609aa`.
`support.py` reuses the previous minimal wrapper, before the queued-consumer
owner-identity hooks were added. Its original baseline-only version is retained
as `support-before-cadence-pin-review.py`.
The packet-plan increment does not alter that prior owner, so the one-line
observer reconstruction and duplicate-owner-pin hooks are deliberately absent.

The archive-local `reference` directory retains the exact historical proposer,
AST verifier, 32-command runner and accepted workflow input/result pins.
`check` authenticates support and the unchanged workflow only; it does not
snapshot the evolving source, change metadata, execute a solver or invoke Cargo.

After the primary declares all source frozen, `propose --source-frozen` produces
a candidate patch and audit. The primary must independently review changed
source premises, including the retained-cadence guard's SDMA source pin, before
approving any application. Only content SHA-256 literals and exact source-roster
cardinalities are eligible; predicates, contracts, proof files and expected
solver/mutant counts may not change. The existing 76 guarded executable proof
files must remain byte-identical. The new packet-plan arithmetic campaign is
separate and cannot qualify the whole native adapter.

Every proposal and workflow attempt uses a new evidence directory. Historical
records are retained unchanged. No command in this support applies a patch.

Proposal 01 was rejected by the historical proposer's assertion that every
retained-cadence pin remains unchanged. The subsequent narrow scratch hook
authenticates exactly the two-line SDMA module/reexport addition and the three
new library export names, with only import wrapping allowed. It requires every
other cadence source/proof byte unchanged and proposes only those two content
hash literals. The original candidate guard audit and AST verifier still run.
No guarded predicate, cadence algorithm or executable proof is modified.
