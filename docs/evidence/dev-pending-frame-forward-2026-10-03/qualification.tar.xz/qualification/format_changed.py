"""Check the exact changed/new Rust roster without traversing unrelated modules."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z', 'HEAD'], cwd=ROOT)
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT)
paths = sorted({name.decode() for name in (changed + new).split(b'\0') if name.endswith(b'.rs')})
assert paths and all(name.startswith('crates/fe2o3-runtime/') for name in paths)
print(json.dumps({'rust_files': paths}), flush=True)
result = subprocess.run(['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                         '--config', 'skip_children=true', *paths], cwd=ROOT, check=False)
sys.exit(result.returncode)
