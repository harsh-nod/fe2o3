#!/usr/bin/env python3
"""Run the existing YAML source-controls commands, without builds or solvers."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import time
import yaml

REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
WORKFLOW = Path('.github/workflows/runtime-component-source-guards.yml')
SOURCE_RECORD = Path('/home/harsh/.codex-tmp/fe2o3-multigpu-recovery-20261001/extracted/candidate-attempt-1/record.json')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot(paths):
    result = {}
    for name in sorted(paths):
        path = REPO / name
        assert path.is_file() and not path.is_symlink(), name
        result[name] = digest(path.read_bytes())
    return result


def main():
    os.umask(0o077)
    workflow = (REPO / WORKFLOW).read_bytes()
    job = yaml.safe_load(workflow)['jobs']['source-controls']
    commands = [(step['name'], line, shlex.split(line)) for step in job['steps'] if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    assert len(commands) == 32 and all(argv[:3] == ['python3', '-I', '-B'] for _, _, argv in commands)
    record = json.loads(SOURCE_RECORD.read_bytes())
    assert digest(SOURCE_RECORD.read_bytes()) == 'b1ab447c92cb6a7bd51f549f6489c828db304144b41ff79f1665e5c51730689a'
    paths = set(record['candidate_inventory']) | {str(WORKFLOW),
        'crates/fe2o3-kfd/src/queue_live/compute_xgmi.rs', 'crates/fe2o3-kfd/src/queue_live/model_pair_loan.rs'}
    before = snapshot(paths)
    (OUT / 'home').mkdir()
    (OUT / 'tmp').mkdir()
    environment = dict(PATH='/usr/bin:/bin', HOME=str(OUT / 'home'), TMPDIR=str(OUT / 'tmp'),
                       LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1',
                       GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_OPTIONAL_LOCKS='0')
    save(OUT / 'inputs.json', dict(workflow_sha256=digest(workflow), yaml_version=yaml.__version__,
        source_sha256=before, environment=environment, commands=commands,
        scope='existing source-controls run commands; no checkout action, builds, GPU, network, or solver'))
    started = time.monotonic()
    deadline = started + 60 * job['timeout-minutes']
    results = []
    for index, (step, literal, argv) in enumerate(commands, 1):
        seconds = min(120, int(deadline - time.monotonic()))
        if seconds <= 0:
            break
        folder = OUT / f'{index:02d}'
        folder.mkdir()
        receipt = dict(step=step, literal=literal, argv=argv, cwd=str(REPO), timeout_seconds=seconds,
                       started_ns=time.time_ns(), timed_out=False)
        with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr,
                                       stdin=subprocess.DEVNULL, start_new_session=True)
            receipt['pid'] = process.pid
            try:
                receipt['exit'] = process.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                receipt['timed_out'] = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    receipt['exit'] = process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    receipt['exit'] = process.wait(timeout=5)
        receipt['finished_ns'] = time.time_ns()
        try:
            os.killpg(process.pid, 0)
            receipt['group_absent'] = False
        except ProcessLookupError:
            receipt['group_absent'] = True
        receipt.update(stdout_sha256=digest((folder / 'stdout').read_bytes()),
                       stderr_sha256=digest((folder / 'stderr').read_bytes()))
        save(folder / 'receipt.json', receipt)
        results.append(receipt)
        print(f'{index:02d}/32 exit={receipt["exit"]} group_absent={receipt["group_absent"]} {literal}', flush=True)
    after = snapshot(paths)
    save(OUT / 'closing-source.json', after)
    accepted = len(results) == 32 and before == after and all(
        row['exit'] == 0 and row['group_absent'] and not row['timed_out'] for row in results)
    save(OUT / 'result.json', dict(accepted=accepted, command_count=len(results), source_unchanged=before == after,
         source_files=len(before), elapsed_seconds=time.monotonic() - started, commands=results,
         failed=[row['literal'] for row in results if row['exit'] != 0 or not row['group_absent'] or row['timed_out']],
         gpu_invocations=0, solver_invocations=0, build_invocations=0))
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
