#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-subject-20261004-th7cGu3A
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-conditional-fill-subject-2026-10-04"
readonly archive="$scratch/archive"
cd "$repo"
test "$(git rev-parse --short=9 HEAD)" = 3b169f88f
test "$(<"$scratch/qualified-1/status")" = 0
test "$(<"$scratch/regression.status")" = 0
mkdir -m 700 "$archive"
mkdir -p "$evidence"
cp -- "$scratch"/*.sh "$scratch"/*.log "$scratch"/*.sha256 "$scratch/regression.status" "$archive/"
cp -a -- "$scratch/qualified-1" "$archive/"
git show --format=fuller --stat HEAD > "$archive/source-commit.txt"
git diff HEAD^ HEAD -- crates > "$archive/source.patch"
git -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers verify-commit HEAD > "$archive/source-signature.log" 2>&1
git diff --check HEAD^ HEAD > "$archive/whitespace.log" 2>&1
rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true \
    crates/fe2o3-host/src/lib.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/pending.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/subject.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_pending.rs > "$archive/rustfmt.log" 2>&1
git diff-tree --no-commit-id --name-only -r HEAD -z | xargs -0 sha256sum > "$archive/source-files.sha256"
test -z "$(ls -A "$scratch/qualified-1/tmp")"
test ! -e /opt/fe2o3/verus-runtime-v2/functional-refinement-0.2026.08.02-b677dd5
/mnt/c/Windows/System32/wsl.exe --user root --exec /bin/rm -rf -- "$scratch/root"
test ! -e "$scratch/root"
printf '%s\n' 'Both qualification scripts exited 0.' \
    'The owned test TMPDIR is empty.' \
    'No protected runtime installation exists at the host /opt path.' \
    'The exact owned root library overlay was removed after the namespace exited.' \
    'No MI300X resources were used.' > "$archive/cleanup.log"
cd "$archive"
find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
tar -czf "$evidence/evidence.tar.gz" .
sha256sum "$evidence/evidence.tar.gz" source.patch
