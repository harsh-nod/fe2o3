#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-fill-subject-20261004-th7cGu3A
curl --fail --location --cacert /home/harsh/.codex-openai/amd-zscaler-ca.pem --max-time 120 -o rustup-init https://static.rust-lang.org/rustup/archive/1.29.0/x86_64-unknown-linux-gnu/rustup-init
curl --fail --location --cacert /home/harsh/.codex-openai/amd-zscaler-ca.pem --max-time 120 -o libc.deb https://snapshot.ubuntu.com/ubuntu/20260801T000000Z/pool/main/g/glibc/libc6_2.39-0ubuntu8.8_amd64.deb
curl --fail --location --cacert /home/harsh/.codex-openai/amd-zscaler-ca.pem --max-time 120 -o zlib.deb https://snapshot.ubuntu.com/ubuntu/20260801T000000Z/pool/main/z/zlib/zlib1g_1.3.dfsg-3.1ubuntu2.1_amd64.deb
sha256sum -c <<'SUMS'
4acc9acc76d5079515b46346a485974457b5a79893cfb01112423c89aeb5aa10 rustup-init
3b8d5391b6b484a4c81fd000b6064885ad967ec3cb966bc57603f3fb3ebf0ed5 libc.deb
7074b6a2f6367a10d280c00a1cb02e74277709180bab4f2491a2f355ab2d6c20 zlib.deb
SUMS
dpkg-deb -x libc.deb glibc
dpkg-deb -x zlib.deb zlib
