#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
receipts=/home/harsh/.codex-tmp/fe2o3-native-reconcile-20260926-RvINz9Fd
result=0
run() {
    local name=$1
    shift
    printf '%q ' "$@" >> "$receipts/commands.log"
    printf '\n' >> "$receipts/commands.log"
    "$@" > "$receipts/$name.log" 2>&1
    local status=$?
    printf '%s\t%s\n' "$name" "$status" >> "$receipts/statuses.tsv"
    printf '%s: %s\n' "$name" "$status"
    if [ "$status" -ne 0 ]; then
        tail -60 "$receipts/$name.log"
        result=1
    fi
}
run doctests cargo test --offline -p fe2o3-runtime --all-features --doc
run clippy cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
run minimal cargo check --offline -p fe2o3-runtime --no-default-features
run formatting cargo fmt --all -- --check
run whitespace git diff --check
run source-continuity sha256sum --check "$receipts/source.sha256"
exit "$result"
