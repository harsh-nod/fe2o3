# Read-only native-agent review

Two native collaboration agents, release_review and runtime_next, reviewed the
implementation and follow-up corrections. Neither edited code or ran tests.
No Qwen worker, remote build, GPU execution or permission escalation was used.

Findings corrected before final qualification:
- Writable DeviceLocal materialization is rejected by snapshot_bound_data_v1;
  recycled read-into accepts HostVisible authority only. The initial proposed
  internal async upload path was removed, not qualified through fake DeviceLocal
  dirty fixtures. The final root addresses actual HostVisible writebacks.
- Root pins must exclude free-lane selection and cache mutation. The pending
  compute path must defer before staging, which otherwise turns Busy into Failed.
- Whole-allocation synchronous uploads could overwrite previously reconciled
  bytes from a stale shadow. They now upload only exact readback extents and
  preserve prior shadow-dirty state.
- Public host destination writes detach cached data and refresh full shadows.
  The private exact-range writer preserves native descriptors and invalidates
  CPU provenance instead. Ordinary preparation refreshes/overwrites before
  reuse; active ordered-successor reuse is excluded by allocation custody.
- Added cancellation followed by successful retry, later-chunk mapped write
  failure/panic, destination sentinels/no full read, and pinned compute Pending
  controls. Late-installed dirty authority exercises admission scratch reserve.

Final review reported no concrete correctness blocker. This is review evidence,
not formal verification, positive composed-account execution, native execution,
directed-SPI qualification or HIP/HSA performance evidence.

Residual qualification gaps include the complete native adapter, shadow-only
positive reconciliation, mixed resumable/synchronous native readback integration,
multiple dirty extents/native lanes, positive persistent compute blocked by a
pin, and actual disjoint compute publication while another lane is pinned. CPU
tests cover free-lane availability and target/cached-binding Pending behavior,
not GPU overlap.
