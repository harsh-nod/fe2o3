#!/usr/bin/env bash
set -u
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
status=0
run() { bash "$root/run.sh" "$@" || status=1; }
run fmt cargo fmt --all -- --check
run no-default env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo check -p fe2o3-runtime -p fe2o3-runtime-model --no-default-features
run clippy env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo clippy -p fe2o3-runtime -p fe2o3-runtime-model --all-features --all-targets -- -D warnings
run kfd-final env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features kfd_backend:: -- --nocapture
exit "$status"
