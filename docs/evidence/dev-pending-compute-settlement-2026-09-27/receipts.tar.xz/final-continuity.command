git diff --exit-code HEAD -- crates 
