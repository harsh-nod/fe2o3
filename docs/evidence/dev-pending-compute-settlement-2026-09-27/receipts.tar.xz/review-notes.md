# Pending compute settlement review

Two read-only native collaboration agents reviewed the runtime cleanup boundary,
its call sites and fixtures. Neither requested permissions, edited files or built
code. The primary owns edits and integration.

The shared unpublished settlement removed FIFO membership, released dependencies
and allocation/module custody, then decremented the completion reservation with
no complete preflight. Public tail cancellation and progress/observation/peer
failure paths all reached it. The first new subprocess reproduction failed after
removing allocation-custody metadata: cleanup panicked and the accepted recipe was
no longer indexed. This is private invariant-corruption coverage, not a GPU fault.

The revised release authenticates the canonical first-binding allocation roster,
local exact Compute owner memberships/count prerequisites, FIFO membership,
module/kernel association, stream device, dependency uniqueness/disjointness and
retain counts, cursor bounds, peer identity and same-stream ordered predecessor.
It reserves result-map capacity before the callback-free release and removes the
recipe last. Local monotone FIFO/owner-index invariants remain premises; this is
not an exhaustive corruption detector or complete owner/count conservation proof.
Preflight does not scan every unrelated owner or require global retain equality.

Detached progress callers reserve reindex capacity while retaining the local
owner. Collision or allocation error retains it in a dedicated inline terminal
slot instead of overwriting/dropping it. The collision test uses two genuinely
admitted recipes, deliberately moves one under the other's key, and verifies both
independent identities. It does not inject allocator exhaustion. Other detached
publication/observation adapters remain outside this new settlement boundary.

Cancellation validates FIFO membership before applying interior TooLate policy.
The existing healthy interior-node refusal and same-stream failure-neutral
ordering are preserved. This does not add prepared/published cancellation.

Negative tests cover 19 cancellation mutations and 15 corresponding public
failed-dependency settlement mutations, plus one private reindex collision.
The four omitted poll variants (explicit cursor past end, terminal-record
collision, missing FIFO, missing FIFO member) bypass settlement in current public
polling and are not claimed as checked ingress. Cancellation covers all four.
Each child checks retained recipe/boxed-roster addresses, logical accounting,
native pair identities/markers and lack of driver effects, then drops the
unrepaired backend and requires SIGABRT. Snapshots own only metadata and Weak
recipe references, not native owners or strong recipe references.

Two healthy public controls cover Cancelled(-2) and failed explicit dependency(-1)
without advancing a still-published ancestor, then finish native scripted cleanup.
They do not execute kernels or establish GPU memory visibility. Scrub-on-release
is disabled by the existing clean scripted helper, not hardware-qualified here.

Legacy private scheduling fixtures now include resource records and normal API
cleanup instead of referencing absent resources. Module and kernel have distinct
fixed IDs. Their manually assembled scheduling state is not production-origin
admission evidence. Synthetic dependencies with newer numeric IDs than consumers
were corrected; the public-admission tests use normal issued identities.

Prepared cancellation is still separate: it moves the runtime ActiveSubmission
before consuming native cancellation/restoration. Lower KFD cancellation already
roots its own native prefixes, but that does not preserve the outer runtime
descriptor through every error/unwind. The next focused change needs indexed outer
custody and native restoration preflight, with distinct single/three-binding
coverage. Current scripted runtime code has no three-binding Prepared variant.

No new formal refinement, MI300X execution or matched HIP/HSA performance evidence
is claimed. The cached public issue182 remains Open; its distributed and formal
requirements are not closed by this CPU checkpoint. SSH and both requested source
pushes have failed DNS. No remote jobs or files were created.
