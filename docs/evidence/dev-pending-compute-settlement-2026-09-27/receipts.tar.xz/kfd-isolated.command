bash /home/harsh/.codex-tmp/fe2o3-compute-cancellation-20260927-R5b9Ddr1/kfd-isolated.sh 
