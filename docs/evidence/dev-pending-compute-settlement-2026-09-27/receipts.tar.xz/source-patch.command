git diff --binary 7236756c06f0799ea7072a8362dec2fd9f106d34 HEAD -- crates 
