#!/usr/bin/env bash
set -u
ulimit -c 0
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
binary=target/debug/deps/fe2o3_runtime-e03b9552edb097b6
"$binary" --list > "$root/isolated-list.log"
status=0
while IFS= read -r entry; do
    case "$entry" in
        kfd_backend::*': test')
            name=${entry%: test}
            printf '\nTEST %s\n' "$name"
            "$binary" --exact "$name" --nocapture
            result=$?
            printf 'RESULT %s %s\n' "$result" "$name"
            if [ "$result" -ne 0 ]; then status=1; fi
            ;;
    esac
done < "$root/isolated-list.log"
exit "$status"
