# Complete Event Batch Release Qualification

Repository: /home/harsh/.codex-tmp/fe2o3-r61-execution
Branch: codex/r65-runtime-drain-versions
Runtime/test/proof source: c942a0fbfb136a5a30700013b62c3f1febf05ef5
Final checker-only source: 9b59c1236f5055ac490e2f562aa0cf9d2fb45a2b
Raw root: /home/harsh/.codex-tmp/fe2o3-batch-release-20260928-RNm0NSzR

Primary owned all edits, integration, builds, solvers and publication. Three
native collaboration agents reviewed production correspondence/trust packaging,
proof adequacy/evidence and test custody independently, read-only. No Qwen worker,
remote MI300X command, GPU execution or benchmark was used. Unrelated
docs/evidence/dev-owner-inspection-2026-09-23/ remains untouched.

## CPU And Static Commands

Build environment: CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2.
Toolchain: nightly-2026-04-03; exact rustc -vV recorded in toolchain.txt.
Commands ran serially, and each reached terminal status zero:

```sh
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-kfd --all-features --lib \
  queue::completion -- --nocapture
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-kfd --all-features --lib \
  -- --skip queue::live::construction_primary
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-runtime --all-features --lib
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 clippy -p fe2o3-kfd -p fe2o3-runtime \
  --all-features --all-targets -- -D warnings
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 check -p fe2o3-kfd -p fe2o3-runtime --no-default-features
prlimit --core=0:0 -- env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 \
  cargo +nightly-2026-04-03 test -p fe2o3-kfd -p fe2o3-runtime \
  -p fe2o3-runtime-model --all-features --doc
rustfmt +nightly-2026-04-03 --check --edition 2024 \
  crates/fe2o3-kfd/src/queue_completion/batch_event_release_body.rs \
  crates/fe2o3-kfd/src/queue_completion/batch_event_release_tests.rs
cargo +nightly-2026-04-03 fmt --all -- --check
git diff --check
prlimit --core=0:0 -- target/debug/deps/fe2o3_kfd-65695dc23b288bd0 \
  queue::completion --nocapture
```

Initial development completion-tests.log: 55/0. Final completion-final.log:
55/0 from the qualified ELF, after scratch-scope formatting and the additional
backend-reset assertion. Broad kfd-regression.log: 1415/0, 320 explicitly
excluded construction-primary tests, 6.61 seconds. Not a full KFD rerun.
runtime-full.log: 1828/0, 30 hardware ignores, 92.87 seconds.
doctests.log: 42 KFD + 9 runtime compile-fail + 44 runtime + 29 model = 124/0.
Clippy, production checks, formatting and diff check logs all pass.

source-files-before.sha256 brackets the final broad KFD and runtime runs;
source-files-cpu-after.log verifies all eight hashes before checker-only edits.
The closure guardrail was then tightened in checker/calibration before c942a0fb;
source-files-final.sha256 records that source. The bounds-diagnostic extension
changes those same two checker files only; checker-only-diff.log records it.
source-files-qualified.sha256 records final 9b59c123. Runtime, tests, proof and
trusted supplement are identical across the CPU bracket and both signed commits.
Both test ELF hashes are retained, not the binaries. No hermetic-build claim.

## Proof Development And Explicit Trust

Pinned verifier:
/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
VERUS_Z3_PATH is its sibling z3. Commands used a 120-second foreground timeout,
TERM then KILL after five seconds, four verifier threads, JSON result/diagnostics,
silent triggers and no long-running progress reports.

Development proof-1 has a Ghost macro frontend failure. proof-2/proof-3 fail
the initial standard-library specification signature/visibility checks. proof-4
rejects a prophetic ghost observation; the final proof keeps a nonprophetic
ghost sequence tied to the actual Vec iterator. proof-5 includes intermediate
logical failures and rejects local std assumptions under --no-cheating.

contracts.out/err records an unsuccessful initial export syntax. contracts-2
successfully builds an experimental separate contract crate; its .rlib and .vir
are development artifacts only. proof-6 still rejects those imported contracts
under --no-cheating. No final stage imports or relies on those artifacts.

The final architecture includes an explicit 18-line source module containing
exactly two std HashSet/HashMap try_reserve contents-frame declarations. It does
not assume success, capacity, addresses, cost, termination or authenticated
rosters. This is a controlled additional trust boundary, NOT a no-cheating proof.
No pinned-vstd file was modified. The adapter authenticates the original
controller before uniquely removing its --no-cheating argument in memory.
The supplement hash, complete four-file relocation closure and source guardrail
are checked explicitly. The guardrail is not equivalent to verifier enforcement.

proof-7/proof-8 pass 27 obligations. proof-9 adds a constructed alias witness
and passes 28 obligations, zero errors. Its witness covers decision/effects for
either allocation outcome; it does not prove actual allocator success exists.
Ten obligations are derived Clone checks, not independent runtime operations.
Development failures/results are not counted as authenticated negative controls.

Final development solver form (without --no-cheating):

```sh
env VERUS_Z3_PATH=/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/z3 \
  /usr/bin/timeout --foreground --signal=TERM --kill-after=5 120 \
  /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus \
  --crate-type lib --triggers-mode silent --output-json --error-format=json \
  --no-report-long-running --num-threads 4 --multiple-errors 2 \
  crates/fe2o3-runtime-model/verus/completion_event_batch_release_v1.rs
```

## Signed Campaigns

The first campaign at c942a0fb (campaign/, campaign.log) is retained as failed.
It stops at ignores-live: Verus emits the genuine logical diagnostic
"precondition not met: index in bounds for this access", which the inherited
classifier did not recognize. It is not a successful qualification campaign.
The final adapter allows exactly that logical diagnostic, with authenticated
primary paths and ordinary error-level/mixed-failure checks. Calibration rejects
unknown suffixes, warnings, foreign paths, nested internal errors and resource
or frontend mixtures. Historical classifier/controller files remain unchanged.

The final campaign at 9b59c123 (campaign-final/, campaign-final.log) reaches
terminal zero: 32/32 owned stages, eight status-zero infrastructure/positive
stages plus 24 status-one strictly classified executable negative controls.
Opening, relocated and closing positives each report 28 verified, zero errors,
whole-crate. Each owned stage records command, timestamps, exit and group receipt.
Five synthetic calibration groups run before the owned sequence, not as extra
owned stages. Calibration logs retain the successive closure and bounds checks.

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-event-batch-release.py \
  --output /home/harsh/.codex-tmp/fe2o3-batch-release-20260928-RNm0NSzR/campaign-final \
  --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
```

source-signature.log independently verifies the final signed source.
issue-182.json is a fresh OPEN snapshot. A1/A2 and accepted lane checkpoints
are unchanged. Raw-return custody and exact logical effects are proved under
the stated std contracts; Vec addresses/capacity are inspected only by CPU tests.
No allocator/panic/native/machine-code/performance qualification is claimed.
Source rollback still needs composition with cancellation, recording freshness,
pin increments and native callback frames, preserving real terminal prefixes.
