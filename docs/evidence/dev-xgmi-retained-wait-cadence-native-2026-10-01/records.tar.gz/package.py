#!/usr/bin/env python3
"""Compact native36 publication from accepted originals; no workload or deletion."""

import hashlib
import importlib.util
import os
from pathlib import Path
import shutil
import signal
import sys
import time

BASE = Path('/home/harsh/.codex-tmp')
PREP = Path('/run/shm/fe2o3-native36-1cfb7580f-20261001-attempt-1')
OUT = Path('/run/shm/fe2o3-native36-publication-20261001-attempt-1')
PACKET = OUT / 'packet'
DURABLE = Path('/mnt/c/fe2o3-native36-publication-20261001')
ORIGINAL_DURABLE = Path('/mnt/c/fe2o3-native36-evidence-20261001')
OBJECTS = BASE / 'fe2o3-runtime-r9-xgmi-refinement-v1/.git/objects'
COMMIT = '1cfb7580f36090c41cd9f96141c5d6b2952750ab'
PARENT = '6793b910c2aa662df20763fbbd349cec0994677f'
REF = 'refs/heads/native36-candidate'
GIB, BUDGET = 1024**3, 128 * 1024**2
RECORD_RESERVE = 64 * 1024
PINS = {
    'analysis.py': (BASE / 'fe2o3-native36-comparison-20261001.py', 'e8e0d4eb48ba063a5375547f9ed9b747394d9c5651865771a3b216bc16139cfa'),
    'comparison.json': (Path('/mnt/c/fe2o3-native36-analysis-20261001/comparison.json'), 'f02be1e2de6b775d80f3f97f3bf2a2671900587fcb6c28d71f10b784f06d2062'),
    'comparison.py': (BASE / 'fe2o3-xgmi-cadence-native36-helpers-20261001/benchmarks/runtime_gfx942/xgmi_retained_wait_cadence_comparison.py', '0ae04a81cc1239a7c07bb0757372d6506d4b9ccb71072d71d9eec4500ae740a2'),
    'historical-census.py': (BASE / 'fe2o3-native24-analysis-20261001.py', '93bda8d3973aa939fa04dd5ef6b1f9469c813b9ea0cb17e3c833c47559e54ebc'),
    'root-readback.py': (BASE / 'fe2o3-native36-root-result-readback-20261001.py', 'cd66917bad0249cfc8a8fc3f1e17d7dc365d8fdf7addf7150549e5e1cd4bfc4b'),
    'root-readback.json': (BASE / 'fe2o3-native36-root-result-readback-20261001.json', '1b6457a44d67bc87c41d07247815d0f4219b098c1518259c9aeb0451508693ee'),
    'root-preflight.py': (BASE / 'fe2o3-native36-root-prepare-readback-20261001.py', '3547f25f09fa470800458bab0268d6cca6bf03088f5ce7be9d10fe6242f36991'),
    'durable-result.json': (ORIGINAL_DURABLE / 'result.json', '9cacdc0b2d787fda3e2200e9bc134aed4d47cd213eb25791755d7e00cc535f68'),
    'durable-pre-cleanup.manifest.json': (ORIGINAL_DURABLE / 'pre-cleanup.manifest.json', '28764135af6071b55eeb20ba9e97a3f9fa3a9a6506de7e8f307a62d239c263e0'),
    'durable-final.manifest.json': (ORIGINAL_DURABLE / 'final.manifest.json', '467a69a8d819bf67025932c7f6118d8a7c4d0ff08da8675c4fe25a499c40cd3f'),
}
TOP = {'owner.json', 'binding.json', 'allowed-signers', 'prepare-census.json',
    'local-preparation-resources.json', 'root-preparation-readback.json',
    'local-execution-started.json', 'local-execution-pre-cleanup.json', 'pre-cleanup-census.json',
    'durable-pre-cleanup.json', 'local-execution-resources.json', 'transport-census.json',
    'transport-finished.json', 'independent-replay.json'}
PREFIXES = ('commands/', 'local-owner-commands/', 'remote-commands/', 'local-execute-owner/')


def load_module(name, path, digest):
    assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
    os.umask(0o077)
    for path in (OUT, DURABLE):
        assert path.parent.resolve(strict=True) == path.parent and not path.exists() and not path.is_symlink()
    assert OBJECTS.resolve(strict=True) == OBJECTS and OBJECTS.is_dir()
    resources = load_module('publication_resources', BASE / 'fe2o3-native36-tmpfs-prepare-20261001.py',
        'f6a4b5e40c05221545a754f3546886444a3dd4f218db2229928612ece85fdc66')
    archive = load_module('publication_archive', BASE / 'fe2o3-native36-execute-durability-20261001/archive.py',
        '5c042d4e953ec29f949c5a42c72d022473789f2cc067521998faa9da7a82ae08')
    extension = load_module('publication_transport', PREP / 'source/benchmarks/runtime_gfx942/xgmi_retained_wait_cadence_transport.py',
        'ce88934ea1a52f0a4b91324843a7c1bd5d4255668179b703268cf0fe3f53c644')
    transport, native, hot, ordinary, experiment, planner = extension.helpers()
    load = lambda path: transport.parse_json(path.read_bytes())
    observations = []

    def guard(label, startup=False):
        memory = [line.split() for line in Path('/proc/meminfo').read_text('ascii').splitlines() if line.startswith('MemAvailable:')]
        assert len(memory) == 1 and memory[0][2:] == ['kB']
        row = {'label': label, 'monotonic_ns': time.monotonic_ns(),
            'tmpfs_free_bytes': shutil.disk_usage(OUT.parent).free,
            'durable_free_bytes': shutil.disk_usage(DURABLE.parent).free,
            'available_ram_bytes': int(memory[0][1]) * 1024,
            'owned_bytes': resources.owned_bytes(OUT) + resources.owned_bytes(DURABLE), 'startup': startup}
        observations.append(row)
        allowance = BUDGET if startup else 0
        assert min(row['tmpfs_free_bytes'], row['durable_free_bytes']) >= 4 * GIB + allowance
        assert row['available_ram_bytes'] >= 16 * GIB + allowance
        assert row['owned_bytes'] + RECORD_RESERVE <= BUDGET

    guard('startup', True)
    for path, digest in PINS.values():
        assert transport.sha(path) == digest and path.resolve(strict=True) == path and path.stat().st_nlink == 1
    comparison = load(PINS['comparison.json'][0])
    assert load(PINS['root-readback.json'][0])['independent_readback_pass'] is True
    durable = load(PINS['durable-result.json'][0])
    assert durable['accepted'] is True and not durable['failures'] and durable['marker']['commit'] == COMMIT
    final_files = load(PINS['durable-final.manifest.json'][0])['files']
    assert transport.inventory(PREP) == final_files
    final_archive = ORIGINAL_DURABLE / 'final.tar.gz'
    assert transport.sha(final_archive) == durable['final_archive']['archive_sha256']
    transport.validate_archive(final_archive, final_files)
    marker = load(PREP / 'owner.json')
    binding = transport.read_binding(PREP, marker)
    extension.extended_binding(PREP, binding, transport)
    collection = load(PREP / 'remote-commands/collect/stdout')
    assert collection['archive_sha256'] == '1d35d76d22e568f609429f8022b9b22ba5623037abd0a6b48dd4eb32a417006f'
    assert transport.sha(PREP / 'remote-commands/pull/stdout') == collection['archive_sha256']
    transport.validate_archive(PREP / 'remote-commands/pull/stdout', collection['files'])
    assert transport.inventory(PREP / 'readback') == collection['files']
    replay = extension.independent_replay(PREP / 'readback', marker, binding, transport, hot, ordinary, experiment, planner)
    assert replay['accepted'] is True and replay == load(PREP / 'independent-replay.json')
    selected = {name: row for name, row in final_files.items() if name in TOP or name.startswith(PREFIXES)}
    assert len(selected) == 89 and sum(row['bytes'] for row in selected.values()) == 8944754
    archive.public_files(PREP, selected, selected, transport)
    OUT.mkdir(mode=0o700)
    PACKET.mkdir(mode=0o700)
    (OUT / 'tmp').mkdir(mode=0o700)
    DURABLE.mkdir(mode=0o700)
    archive.fsync_directory(DURABLE)
    archive.fsync_directory(DURABLE.parent)
    loose = {}
    for name, (path, _) in PINS.items():
        target = PACKET / name
        shutil.copyfile(path, target)
        target.chmod(0o644)
        loose[name] = {'original_path': str(path), 'original': transport.inventory_row(path),
            'published': transport.inventory_row(target)}
        assert loose[name]['original']['sha256'] == loose[name]['published']['sha256']
    transport.save(PACKET / 'loose-input-index.json', loose)
    shutil.copy2(PREP / 'allowed-signers', PACKET / 'allowed-signers')
    shutil.copy2(Path(__file__).resolve(), PACKET / 'package.py')
    namespace = os.readlink('/proc/self/ns/pid')
    rec = native.FreshRecorder(PACKET / 'signature-records', OUT, hot)
    environment = {'HOME': '/home/harsh', 'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
        'TMPDIR': str(OUT / 'tmp'), 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_TERMINAL_PROMPT': '0', 'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1'}
    git = ['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
        '-c', 'core.hooksPath=/dev/null', '-c', 'gpg.format=ssh',
        '-c', 'gpg.ssh.allowedSignersFile=' + str(PACKET / 'allowed-signers')]
    bare = OUT / 'bundle.git'
    failures, accepted, packet_receipt = [], False, None
    handlers = {number: signal.getsignal(number) for number in hot.B.MANAGED}

    def stage(name, arguments, seconds=60):
        guard(name + '-before')
        try:
            return rec.run(name, git + arguments, seconds, env=environment)
        finally:
            guard(name + '-after')

    try:
        for number in handlers:
            signal.signal(number, hot.B.interrupted)
        stage('init', ['init', '--bare', '--initial-branch=native36-candidate', str(bare)])
        with (bare / 'objects/info/alternates').open('x', encoding='ascii') as stream:
            stream.write(str(OBJECTS) + '\n')
        stage('ref', ['--git-dir=' + str(bare), 'update-ref', REF, COMMIT])
        signature = stage('signature', ['--git-dir=' + str(bare), 'verify-commit', COMMIT])
        text = (signature / 'stderr').read_text('ascii')
        assert 'Good "git" signature for harmenon@amd.com' in text
        assert 'SHA256:q8oGVYZ11904aFzlMkSiEwyeSP+6hbuiZGbNVGRZVCg' in text
        commit = stage('commit', ['--git-dir=' + str(bare), 'cat-file', 'commit', COMMIT])
        raw = (commit / 'stdout').read_bytes()
        assert [line for line in raw.split(b'\n\n', 1)[0].splitlines() if line.startswith(b'parent ')] == [('parent ' + PARENT).encode('ascii')]
        stage('bundle-create', ['--git-dir=' + str(bare), 'bundle', 'create', str(PACKET / 'signed-source.bundle'), REF, '^' + PARENT], 180)
        stage('bundle-verify', ['--git-dir=' + str(bare), 'bundle', 'verify', str(PACKET / 'signed-source.bundle')])
        heads = stage('bundle-heads', ['--git-dir=' + str(bare), 'bundle', 'list-heads', str(PACKET / 'signed-source.bundle')])
        assert (heads / 'stdout').read_bytes() == (COMMIT + ' ' + REF + '\n').encode('ascii')
        transport.save(PACKET / 'signature-census.json', native.fresh_census(rec, hot, namespace))
        guard('raw-archive-before')
        transport.make_archive(PACKET / 'raw.tar.gz', PREP, selected)
        transport.validate_archive(PACKET / 'raw.tar.gz', selected)
        transport.save(PACKET / 'raw-index.json', {name: {**row, 'original_path': str(PREP / name)} for name, row in selected.items()})
        assert {name: transport.inventory_row(PREP / name) for name in selected} == selected
        guard('raw-archive-after')
        campaign = PREP / 'readback/campaign-1'
        tools_before, tools_after = load(campaign / 'tools-before.json'), load(campaign / 'tools-after.json')
        binaries = load(campaign / 'binaries-before.json')
        assert tools_before == tools_after and binaries == load(campaign / 'binaries-after.json')
        assert {name: transport.sha(campaign / 'binaries' / file) for name, file in experiment.BINARIES.items()} == binaries
        transport.save(PACKET / 'identities.json', {'marker': marker, 'source_before_sha256': transport.sha(campaign / 'source-before.json'),
            'source_after_sha256': transport.sha(campaign / 'source-after.json'), 'tools': tools_before, 'four_elf_sha256': binaries,
            'host_before_sha256': transport.sha(campaign / 'host-before.json'), 'host_after_sha256': transport.sha(campaign / 'host-after.json'),
            'cadence_host_before_sha256': transport.sha(campaign / 'host-cadence-before.json'),
            'cadence_host_after_sha256': transport.sha(campaign / 'host-cadence-after.json')})
        availability = []
        for name, digest, accepted_point_snapshot in (
            ('fe2o3-native36-availability-20261001', '506686bd8224359498e4dcf5ca0179bc770e9c9ecaecab8e0e1415175b1e06a4', False),
            ('fe2o3-native36-availability-20261001-revision-2', 'b51a37e1e6cc30502987aa25b5115d143ef0b7e4d91e0434588b980ae40ceca5', True)):
            path = BASE / name / 'result.json'
            assert transport.sha(path) == digest
            availability.append({'retained_original': str(path), 'sha256': digest,
                'point_snapshot_accepted': accepted_point_snapshot, 'campaign_admission_substitute': False})
        transport.save(PACKET / 'summary.json', {'schema': 'fe2o3.native36-compact-publication.v1', 'marker': marker,
            'source_commit': COMMIT, 'bundle_prerequisite': PARENT, 'bundle_sha256': transport.sha(PACKET / 'signed-source.bundle'),
            'source_payload_sha256': binding['payload_sha256'], 'source_payload_bytes': binding['payload_bytes'],
            'selected_objects': len(binding['selected_objects']), 'payload_files': len(binding['files']),
            'raw_files': len(selected), 'raw_logical_bytes': sum(row['bytes'] for row in selected.values()),
            'raw_archive': transport.inventory_row(PACKET / 'raw.tar.gz'),
            'native_collection': {'archive_member': 'remote-commands/pull/stdout', 'files': len(collection['files']),
                'bytes': collection['archive_bytes'], 'sha256': collection['archive_sha256'], 'four_elf_sha256': binaries},
            'censuses': comparison['censuses'], 'independent_replay': replay,
            'external_durable_source_archives': {key: durable[key] for key in ('pre_cleanup', 'final_archive')},
            'availability_histories': availability, 'originals_deleted': False, 'full_replay_self_contained': False,
            'new_gpu_execution': False, 'default_promotion': False, 'hip_hsa_parity': False})
        rows = ['# MI300X Native36 Wait-Cadence Evidence', '',
            'Signed source: `' + COMMIT + '`. Original owner 31070 and offline comparison 32793 completed with exit 0.',
            'All 36 trials (24 ordinary, 12 profiled), 471 native groups, 14 preparation groups, four local HEAD/status brackets and six transport groups closed. Root independently recomputed all six ordinary cells and all 12 diagnostic distributions. The exact owned remote directory was collected, removed and verified absent.', '',
            '## Ordinary Latency', '',
            'Microseconds per batch, arithmetic mean of two invocation p50s; one MiB per copy. These are the experiment APIs, including the 1 ms control, not the old kfd-series timing path.', '',
            '| Depth | Direction | KFD 1 ms | KFD 25 us | HSA | HIP |', '| --- | --- | ---: | ---: | ---: | ---: |']
        for row in comparison['comparison']['ordinary']:
            values = [row['cells'][key]['mean_of_two_invocation_p50_ns'] / 1000 for key in ('ordinary-1ms', 'ceiling-25us', 'hsa', 'hip')]
            rows.append('| ' + str(row['depth']) + ' | ' + row['direction'] + ' | ' + ' | '.join(f'{value:.3f}' for value in values) + ' |')
        rows += ['', 'The 25 us experiment reduced measured depth-16/32 latency but raised scan CPU use. Depth 1 remained slower than HSA/HIP. This single nonexclusive, point-admitted campaign does not establish general performance parity, engine equivalence or orders-of-magnitude gains. No default change is made.', '',
            '## Diagnostics and Proof Scope', '',
            '`comparison.json` keeps ordinary invocations separate from 240 profiled samples, with per-policy/depth/direction distributions, histograms and explicit zero missing observations. Do not sum independent medians or treat requested sleep or wall-minus-thread-CPU as avoidable latency. Instrumentation changes timing/readiness.',
            'The prior selector proof covers ceiling selection only. Concrete Duration/Instant cursor execution, scheduler behavior, device timing and hardware refinement are outside that proof.', '',
            '## Contents and Prerequisites', '',
            '`raw.tar.gz` contains the exact 89-file preparation/transport/controller roster in `raw-index.json`, including the byte-identical native collection archive once at `remote-commands/pull/stdout`. That nested archive retains all 1,484 native files and four original ELFs. `identities.json` summarizes source/tool/ELF joins; raw identities, admission, currentness observations and cleanup records remain available inside the archives.',
            '`signed-source.bundle` exports only `' + REF + '` at the signed source commit over public prerequisite `' + PARENT + '`. Fresh bounded signature/bundle records and their census are retained. The included allowed-signers file records the reviewed project key, not an independent trust anchor. The private bundle metadata uses a read-only alternate; no main ref or Git object was changed.',
            '`root-readback.*`, `root-preflight.py`, comparison/controller sources, durable manifests and `durable-result.json` retain the independent checks and exact external archive identities. Both preliminary availability captures remain at the paths/hashes in `summary.json`; the first was rejected for enumeration mismatch. Neither replaces fresh campaign admission.',
            'Loose source/JSON copies are published with mode 0644; the NTFS-mounted JSON inputs report mode 0777. `loose-input-index.json` records original and published metadata and identical byte hashes. No original mode is changed, and all 89 raw archive member modes, including the nested ELF modes, remain exact.',
            'This compact packet is not self-contained for original-controller replay. The original selected source/Git closure and source.tar.gz are retained in the full durable archives named in `summary.json`, alongside all tmpfs originals. Exact full replay additionally requires those original byte identities or a verified reconstruction. Repacking equivalent source does not reproduce the gzip payload or receive-stdin hashes. Controllers retain absolute original paths. No original, ELF, prior rejection or proof history was deleted.', '']
        with (PACKET / 'README.md').open('x', encoding='ascii') as stream:
            stream.write('\n'.join(rows))
        assert transport.inventory(PREP) == final_files
        assert all(transport.sha(path) == digest for path, digest in PINS.values())
        guard('packet-index-before')
        transport.save(PACKET / 'publication-index.json', transport.inventory(PACKET))
        files = transport.inventory(PACKET)
        assert sum(row['bytes'] for row in files.values()) < BUDGET // 2
        packet_receipt = archive.archive_once(PACKET, DURABLE, 'final', files, files, marker, transport)
        guard('packet-durable-after')
        accepted = True
    except BaseException as error:
        failures.append(repr(error))
    finally:
        try:
            census = native.fresh_census(rec, hot, namespace)
            transport.save(OUT / 'fresh-census.json', census)
        except BaseException as error:
            failures.append('fresh package closure: ' + repr(error))
            accepted = False
        result = {'accepted': accepted and not failures, 'failures': failures, 'packet': str(PACKET),
            'controller_sha256': transport.sha(Path(__file__).resolve()), 'durable_packet': packet_receipt,
            'observations': observations, 'checks': 'stage boundaries, not continuous monitoring',
            'combined_budget_bytes': BUDGET, 'originals_deleted': False, 'new_gpu_execution': False}
        try:
            archive.save_durable(DURABLE / 'result.json', result, transport)
            transport.save(OUT / 'result.json', result)
            print(transport.encoded(result).decode('ascii'), flush=True)
        finally:
            for number, handler in handlers.items():
                signal.signal(number, handler)
    assert result['accepted'], 'publication attempt rejected; all originals and partial output retained'


if __name__ == '__main__':
    main()
