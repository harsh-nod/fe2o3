#!/usr/bin/env python3
"""Read back the prepared payload without executing hardware commands."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/run/shm/fe2o3-native36-1cfb7580f-20261001-attempt-1')
MAIN = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
COMMIT = '1cfb7580f36090c41cd9f96141c5d6b2952750ab'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def main():
    assert ROOT.resolve(strict=True) == ROOT
    path = ROOT / 'source/benchmarks/runtime_gfx942/xgmi_peer_series_transport.py'
    assert sha(path) == 'b0f6f3be586f91261889d1a22aa38470da52f8072820827f017b70e84bbdc675'
    spec = importlib.util.spec_from_file_location('transport', path)
    transport = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transport)
    marker = load(ROOT / 'owner.json')
    assert marker['commit'] == COMMIT
    binding = transport.read_binding(ROOT, marker)
    assert len(binding['selected_objects']) == 6529
    assert len(binding['files']) == 6544
    assert sha(ROOT / 'source.tar.gz') == binding['payload_sha256']
    assert (ROOT / 'source.tar.gz').stat().st_size == binding['payload_bytes']
    transport.validate_archive(ROOT / 'source.tar.gz', binding['files'])
    transport.verify_source(ROOT, binding)
    for relative, oid in binding['selected_objects'].items():
        data = (ROOT / 'source' / relative).read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()
        assert actual == oid, relative
    resource = load(ROOT / 'local-preparation-resources.json')
    assert resource['accepted'] is True and resource['error'] is None
    assert resource['commit'] == COMMIT
    assert len(resource['helper_pins']) == 13
    for relative, digest in resource['helper_pins'].items():
        assert sha(ROOT / 'source' / relative) == digest == sha(MAIN / relative)
        assert binding['files']['source/' + relative]['sha256'] == digest
    assert len(resource['observations']) == 38
    for row in resource['observations']:
        assert row['free_bytes'] >= resource['disk_floor_bytes']
        assert row['available_memory_bytes'] >= resource['ram_floor_bytes']
        assert row['owned_bytes'] <= resource['owned_output_budget_bytes']
    pids = set()
    for kind, folder, count in (('prepare', 'commands', 14), ('preflight', 'local-owner-commands', 4)):
        census = resource['censuses'][kind]
        assert len(census['attempt_order']) == len(set(census['attempt_order'])) == count
        assert set(census['attempt_order']) == set(census['raw_sha256'])
        assert {p.name for p in (ROOT / folder).iterdir()} == set(census['attempt_order'])
        rows = {row['name']: row for row in census['records']}
        assert len(rows) == count
        for name in census['attempt_order']:
            record = ROOT / folder / name
            raw = census['raw_sha256'][name]
            assert set(raw) == {'receipt.json', 'stdout', 'stderr'}
            for member, digest in raw.items():
                assert sha(record / member) == digest
            receipt = load(record / 'receipt.json')
            assert receipt['exit'] == 0 and receipt['error'] is None
            assert receipt['group_absent'] is True
            assert receipt['stdout_sha256'] == raw['stdout']
            assert receipt['stderr_sha256'] == raw['stderr']
            assert rows[name]['receipt_sha256'] == raw['receipt.json']
            assert rows[name]['pid'] == receipt['pid'] not in pids
            pids.add(receipt['pid'])
    assert load(ROOT / 'prepare-census.json') == resource['censuses']['prepare']
    expected = binding['selected_objects']
    for name in ('selected-tree', 'relocated-tree'):
        assert transport.selected_blobs((ROOT / 'commands' / name / 'stdout').read_bytes()) == expected
    for name in ('head-before', 'head-after'):
        assert (ROOT / 'local-owner-commands' / name / 'stdout').read_text() == COMMIT + '\n'
    for name in ('status-before', 'status-after'):
        assert not (ROOT / 'local-owner-commands' / name / 'stdout').read_bytes()
    result = {'accepted': True, 'commit': COMMIT, 'selected_objects': len(expected),
              'payload_files': len(binding['files']), 'payload_sha256': binding['payload_sha256'],
              'binding_sha256': sha(ROOT / 'binding.json'), 'closed_groups': len(pids),
              'preparation_resources_sha256': sha(ROOT / 'local-preparation-resources.json'),
              'controller_sha256': sha(Path(__file__)), 'hardware_execution': False,
              'scope': 'Independent source/archive/blob/helper and historical receipt readback; no PID reprobes, no GPU or performance qualification.'}
    with (ROOT / 'root-preparation-readback.json').open('x') as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
