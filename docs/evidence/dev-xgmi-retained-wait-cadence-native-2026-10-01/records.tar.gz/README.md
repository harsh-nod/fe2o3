# MI300X Native36 Wait-Cadence Evidence

Signed source: `1cfb7580f36090c41cd9f96141c5d6b2952750ab`. Original owner 31070 and offline comparison 32793 completed with exit 0.
All 36 trials (24 ordinary, 12 profiled), 471 native groups, 14 preparation groups, four local HEAD/status brackets and six transport groups closed. Root independently recomputed all six ordinary cells and all 12 diagnostic distributions. The exact owned remote directory was collected, removed and verified absent.

## Ordinary Latency

Microseconds per batch, arithmetic mean of two invocation p50s; one MiB per copy. These are the experiment APIs, including the 1 ms control, not the old kfd-series timing path.

| Depth | Direction | KFD 1 ms | KFD 25 us | HSA | HIP |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | forward | 40.291 | 40.300 | 33.566 | 38.402 |
| 1 | reverse | 40.275 | 39.850 | 33.715 | 38.307 |
| 16 | forward | 673.717 | 471.986 | 530.813 | 494.955 |
| 16 | reverse | 673.157 | 461.050 | 530.599 | 510.789 |
| 32 | forward | 1169.728 | 916.415 | 1065.002 | 973.139 |
| 32 | reverse | 1167.891 | 916.625 | 1064.993 | 988.683 |

The 25 us experiment reduced measured depth-16/32 latency but raised scan CPU use. Depth 1 remained slower than HSA/HIP. This single nonexclusive, point-admitted campaign does not establish general performance parity, engine equivalence or orders-of-magnitude gains. No default change is made.

## Diagnostics and Proof Scope

`comparison.json` keeps ordinary invocations separate from 240 profiled samples, with per-policy/depth/direction distributions, histograms and explicit zero missing observations. Do not sum independent medians or treat requested sleep or wall-minus-thread-CPU as avoidable latency. Instrumentation changes timing/readiness.
The prior selector proof covers ceiling selection only. Concrete Duration/Instant cursor execution, scheduler behavior, device timing and hardware refinement are outside that proof.

## Contents and Prerequisites

`raw.tar.gz` contains the exact 89-file preparation/transport/controller roster in `raw-index.json`, including the byte-identical native collection archive once at `remote-commands/pull/stdout`. That nested archive retains all 1,484 native files and four original ELFs. `identities.json` summarizes source/tool/ELF joins; raw identities, admission, currentness observations and cleanup records remain available inside the archives.
`signed-source.bundle` exports only `refs/heads/native36-candidate` at the signed source commit over public prerequisite `6793b910c2aa662df20763fbbd349cec0994677f`. Fresh bounded signature/bundle records and their census are retained. The included allowed-signers file records the reviewed project key, not an independent trust anchor. The private bundle metadata uses a read-only alternate; no main ref or Git object was changed.
`root-readback.*`, `root-preflight.py`, comparison/controller sources, durable manifests and `durable-result.json` retain the independent checks and exact external archive identities. Both preliminary availability captures remain at the paths/hashes in `summary.json`; the first was rejected for enumeration mismatch. Neither replaces fresh campaign admission.
Loose source/JSON copies are published with mode 0644; the NTFS-mounted JSON inputs report mode 0777. `loose-input-index.json` records original and published metadata and identical byte hashes. No original mode is changed, and all 89 raw archive member modes, including the nested ELF modes, remain exact.
This compact packet is not self-contained for original-controller replay. The original selected source/Git closure and source.tar.gz are retained in the full durable archives named in `summary.json`, alongside all tmpfs originals. Exact full replay additionally requires those original byte identities or a verified reconstruction. Repacking equivalent source does not reproduce the gzip payload or receive-stdin hashes. Controllers retain absolute original paths. No original, ELF, prior rejection or proof history was deleted.
