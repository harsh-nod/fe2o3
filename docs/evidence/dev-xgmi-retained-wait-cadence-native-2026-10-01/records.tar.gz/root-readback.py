#!/usr/bin/env python3
"""Independent native36 archive, raw-receipt and descriptive-statistics readback."""
import base64
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import runpy
import statistics

INVOKER = Path('/home/harsh/.codex-tmp/fe2o3-native36-comparison-20261001.py')
ANALYSIS = Path('/mnt/c/fe2o3-native36-analysis-20261001/comparison.json')
REPORT = Path('/home/harsh/.codex-tmp/fe2o3-native36-root-result-readback-20261001.json')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def distribution(values):
    present = sorted(value for value in values if value is not None)
    n = len(present)
    return {'samples': len(values), 'available': n, 'missing': len(values) - n,
        'min': present[0] if n else None, 'max': present[-1] if n else None,
        'median': statistics.median(present) if n else None,
        'p95_nearest_rank': present[math.ceil(0.95 * n) - 1] if n else None,
        'mean': statistics.mean(present) if n else None}


def main():
    assert sha(INVOKER) == 'e8e0d4eb48ba063a5375547f9ed9b747394d9c5651865771a3b216bc16139cfa'
    assert sha(ANALYSIS) == 'f02be1e2de6b775d80f3f97f3bf2a2671900587fcb6c28d71f10b784f06d2062'
    api = runpy.run_path(str(INVOKER), run_name='root_native36_readback')
    module = api['module']
    extension = module('root_native36_transport', api['EXTENSION'], api['EXTENSION_SHA'])
    transport, native, hot, ordinary, experiment, planner = extension.helpers()
    comparator = module('root_native36_comparison', api['COMPARISON'], api['COMPARISON_SHA'])
    historical = module('root_native36_census', api['HISTORICAL'], api['HISTORICAL_SHA'])
    owner = module('root_native36_owner', api['OWNER'], api['OWNER_SHA'])
    prep, durable = api['PREP'], api['DURABLE']
    result = load(ANALYSIS)
    completed = load(durable / 'result.json')
    assert completed == result['durable_archives'] and completed['accepted'] is True
    assert not completed['failures'] and completed['marker'] == owner.MARKER
    assert completed['stage_order'] == [name for name, _ in owner.STAGES]
    assert sha(durable / 'result.json') == result['durable_result_sha256']
    manifests = {}
    for phase, key in (('pre-cleanup', 'pre_cleanup'), ('final', 'final_archive')):
        receipt = completed[key]
        archive, manifest_path = durable / (phase + '.tar.gz'), durable / (phase + '.manifest.json')
        assert sha(archive) == receipt['archive_sha256'] and sha(manifest_path) == receipt['manifest_sha256']
        manifest = load(manifest_path)
        assert manifest['marker'] == owner.MARKER and manifest['archive_sha256'] == sha(archive)
        transport.validate_archive(archive, manifest['files'])
        assert {name: transport.inventory_row(prep / name) for name in manifest['files']} == manifest['files']
        manifests[phase] = {'files': len(manifest['files']), 'archive_sha256': sha(archive)}
    assert manifests['pre-cleanup']['files'] == 8108 and manifests['final']['files'] == 8118
    marker = load(prep / 'owner.json')
    assert marker == result['marker'] == owner.MARKER
    binding = transport.read_binding(prep, marker)
    extension.extended_binding(prep, binding, transport)
    collection = load(prep / 'remote-commands/collect/stdout')
    assert collection['marker'] == marker and len(collection['files']) == result['collection_files'] == 1484
    archive = prep / 'remote-commands/pull/stdout'
    assert sha(archive) == collection['archive_sha256'] == result['collection_sha256']
    assert archive.stat().st_size == collection['archive_bytes']
    transport.validate_archive(archive, collection['files'])
    readback = prep / 'readback'
    assert transport.inventory(readback) == collection['files']
    replay = extension.independent_replay(readback, marker, binding, transport, hot, ordinary, experiment, planner)
    assert replay == load(prep / 'independent-replay.json') == result['independent_replay']
    assert replay['accepted'] is True
    assert load(prep / 'remote-commands/cleanup/stdout') == {'removed': marker['path'], 'archive_sha256': sha(archive)}
    assert load(prep / 'remote-commands/absence/stdout') == {'path_absent': marker['path']}
    campaign = readback / 'campaign-1'
    census = {name: historical.census(folder, load(path)) for name, folder, path in (
        ('prepare', prep / 'commands', prep / 'prepare-census.json'),
        ('transport', prep / 'remote-commands', prep / 'transport-census.json'),
        ('native', campaign / 'commands', campaign / 'fresh-census.json'))}
    resources = load(prep / 'local-preparation-resources.json')
    census['preparation-owner'] = historical.census(prep / 'local-owner-commands', resources['censuses']['preflight'])
    assert census == result['censuses']
    assert {name: row['count'] for name, row in census.items()} == {
        'prepare': 14, 'preparation-owner': 4, 'native': 471, 'transport': 6}
    rows = []
    for row in load(campaign / 'records.json'):
        decoded = {key: value for key, value in row.items() if key not in ('stdout_base64', 'stderr_base64')}
        decoded.update({key: base64.b64decode(row[key + '_base64'], validate=True) for key in ('stdout', 'stderr')})
        rows.append(decoded)
    plan = load(campaign / 'plan.json')
    kwargs = {key: plan[key] for key in ('physical_indices', 'unique_ids', 'copy_bytes', 'warmups', 'samples')}
    kwargs.update(admission=load(campaign / 'admission.json'),
        environment_before=load(campaign / 'host-before.json')['environment'],
        environment_after=load(campaign / 'host-after.json')['environment'])
    assert comparator.compare(rows, **kwargs) == result['comparison']
    parsed = planner.replay_campaign(rows, **kwargs)
    measured = result['comparison']
    cells = []
    for cell in measured['ordinary']:
        depth, direction = cell['depth'], cell['direction']
        means = {}
        for label, values in cell['cells'].items():
            source = [row for row in parsed['ordinary'] if row['depth'] == depth
                      and (row['cadence'] if row['backend'] == planner.BACKEND else row['backend']) == label]
            assert len(source) == 2
            medians = []
            for row, invocation in zip(source, values['invocations'], strict=True):
                if row['backend'] == planner.BACKEND:
                    samples = sorted(sample['elapsed_ns'] for sample in row['fields']['samples'] if sample['direction'] == direction)
                    assert len(samples) == 10
                    value = samples[4]
                else:
                    value = int(row['fields'][direction + '_p50_ns'])
                assert value == invocation['p50_ns'] and row['name'] == invocation['name']
                medians.append(value)
            means[label] = sum(medians) / 2
            assert means[label] == values['mean_of_two_invocation_p50_ns']
        expected_ratios = {'ceiling-25us_over_ordinary-1ms': means['ceiling-25us'] / means['ordinary-1ms']}
        expected_ratios.update({policy + '_over_' + backend: means[policy] / means[backend]
                               for policy in ('ordinary-1ms', 'ceiling-25us') for backend in ('hsa', 'hip')})
        assert expected_ratios == cell['latency_ratios']
        cells.append({'depth': depth, 'direction': direction, 'mean_of_two_p50_ns': means,
                      'latency_ratios': expected_ratios})
    sample_count = 0
    for cell in measured['profiled']:
        samples = [sample for row in parsed['profiled'] if row['depth'] == cell['depth'] and row['cadence'] == cell['cadence']
                   for sample in row['fields']['samples'] if sample['direction'] == cell['direction']]
        assert len(samples) == 20
        sample_count += len(samples)
        assert {key: distribution([sample[key] for sample in samples]) for key in comparator.METRICS} == cell['distributions']
        for key, histogram in cell['counter_histograms'].items():
            assert dict(Counter(str(sample[key]) for sample in samples)) == histogram
    assert len(cells) == 6 and len(measured['profiled']) == 12 and sample_count == 240
    assert all(value == 0 for value in measured['profiled_missing_by_field'].values())
    assert all(measured[key] is False for key in ('performance_acceptance', 'aggregate_parity_assertion',
        'aggregate_speedup_assertion', 'device_completion_timing', 'formal_refinement', 'engine_matching',
        'exclusive_reservation', 'unchanged_kfd_series_timed'))
    report = {'independent_readback_pass': True, 'analysis_sha256': sha(ANALYSIS), 'controller_sha256': sha(INVOKER),
        'archives': manifests, 'censuses': census, 'ordinary': cells, 'profiled_samples': sample_count,
        'remote_owned_cleanup_verified': True, 'fresh_gpu_or_cpu_execution': False,
        'historical_pid_probes': False, 'tmpfs_cleanup_performed': False,
        'default_promotion': False, 'hip_hsa_parity': False}
    with REPORT.open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps({'accepted': True, 'report': str(REPORT), 'report_sha256': sha(REPORT),
                      'native_groups': 471, 'transport_groups': 6, 'ordinary_cells': 6, 'profiled_samples': 240}))


if __name__ == '__main__':
    main()
