#!/usr/bin/env python3
"""Offline invocation of reviewed native36 replay/comparison; no GPU execution."""

import argparse
import base64
import hashlib
import importlib.util
from pathlib import Path
import sys

PREP = Path('/run/shm/fe2o3-native36-1cfb7580f-20261001-attempt-1')
DURABLE = Path('/mnt/c/fe2o3-native36-evidence-20261001')
COMPARISON = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-cadence-native36-helpers-20261001/benchmarks/runtime_gfx942/xgmi_retained_wait_cadence_comparison.py')
COMPARISON_SHA = '0ae04a81cc1239a7c07bb0757372d6506d4b9ccb71072d71d9eec4500ae740a2'
HISTORICAL = Path('/home/harsh/.codex-tmp/fe2o3-native24-analysis-20261001.py')
HISTORICAL_SHA = '93bda8d3973aa939fa04dd5ef6b1f9469c813b9ea0cb17e3c833c47559e54ebc'
OWNER = Path('/home/harsh/.codex-tmp/fe2o3-native36-execute-durability-20261001/owner.py')
OWNER_SHA = '69e516c9302152de18cd8600e56f4748025c6b3ebfaf33f13cfde8208ca5d7fd'
EXTENSION = PREP / 'source/benchmarks/runtime_gfx942/xgmi_retained_wait_cadence_transport.py'
EXTENSION_SHA = 'ce88934ea1a52f0a4b91324843a7c1bd5d4255668179b703268cf0fe3f53c644'


def module(name, path, expected):
    assert path.resolve(strict=True) == path and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    output = parser.parse_args().output
    assert output.is_absolute() and output.parent.resolve(strict=True) == output.parent
    assert not output.exists() and not output.is_symlink()
    extension = module('native36_analysis_transport', EXTENSION, EXTENSION_SHA)
    transport, native, hot, ordinary, experiment, planner = extension.helpers()
    comparator = module('native36_comparison', COMPARISON, COMPARISON_SHA)
    historical = module('native24_retained_census', HISTORICAL, HISTORICAL_SHA)
    owner = module('native36_execution_binding', OWNER, OWNER_SHA)
    assert comparator.campaign is planner
    load = lambda path: transport.parse_json(path.read_bytes())
    completed = load(DURABLE / 'result.json')
    assert completed['accepted'] is True and completed['marker'] == owner.MARKER and not completed['failures']
    assert completed['stage_order'] == [name for name, _ in owner.STAGES]
    for phase, key in (('pre-cleanup', 'pre_cleanup'), ('final', 'final_archive')):
        receipt = completed[key]
        archive = DURABLE / (phase + '.tar.gz')
        manifest_path = DURABLE / (phase + '.manifest.json')
        assert receipt['archive'] == str(archive) and receipt['manifest'] == str(manifest_path)
        assert transport.sha(archive) == receipt['archive_sha256']
        assert transport.sha(manifest_path) == receipt['manifest_sha256']
        manifest = load(manifest_path)
        assert manifest['marker'] == owner.MARKER and manifest['archive_sha256'] == receipt['archive_sha256']
        transport.validate_archive(archive, manifest['files'])
        assert {name: transport.inventory_row(PREP / name) for name in manifest['files']} == manifest['files']
    marker = load(PREP / 'owner.json')
    assert marker == owner.MARKER
    binding = transport.read_binding(PREP, marker)
    extension.extended_binding(PREP, binding, transport)
    collection = load(PREP / 'remote-commands/collect/stdout')
    assert collection['marker'] == marker
    raw_archive = PREP / 'remote-commands/pull/stdout'
    assert transport.sha(raw_archive) == collection['archive_sha256'] and raw_archive.stat().st_size == collection['archive_bytes']
    transport.validate_archive(raw_archive, collection['files'])
    readback = PREP / 'readback'
    assert transport.inventory(readback) == collection['files']
    replay = extension.independent_replay(readback, marker, binding, transport, hot, ordinary, experiment, planner)
    assert replay['accepted'] is True and replay == load(PREP / 'independent-replay.json')
    assert load(PREP / 'remote-commands/cleanup/stdout') == {'removed': marker['path'], 'archive_sha256': collection['archive_sha256']}
    assert load(PREP / 'remote-commands/absence/stdout') == {'path_absent': marker['path']}
    campaign = readback / 'campaign-1'
    censuses = {name: historical.census(folder, load(path)) for name, folder, path in (
        ('prepare', PREP / 'commands', PREP / 'prepare-census.json'),
        ('transport', PREP / 'remote-commands', PREP / 'transport-census.json'),
        ('native', campaign / 'commands', campaign / 'fresh-census.json'))}
    local = load(PREP / 'local-preparation-resources.json')
    censuses['preparation-owner'] = historical.census(PREP / 'local-owner-commands', local['censuses']['preflight'])
    records = []
    for row in load(campaign / 'records.json'):
        value = {key: item for key, item in row.items() if key not in ('stdout_base64', 'stderr_base64')}
        value.update({stream: base64.b64decode(row[stream + '_base64'], validate=True) for stream in ('stdout', 'stderr')})
        records.append(value)
    plan = load(campaign / 'plan.json')
    comparison = comparator.compare(records, environment_after=load(campaign / 'host-after.json')['environment'],
        physical_indices=plan['physical_indices'], unique_ids=plan['unique_ids'], admission=load(campaign / 'admission.json'),
        environment_before=load(campaign / 'host-before.json')['environment'],
        copy_bytes=plan['copy_bytes'], warmups=plan['warmups'], samples=plan['samples'])
    result = {'schema': 'fe2o3.native36-offline-comparison-invocation.v1', 'marker': marker,
        'controller_sha256': transport.sha(Path(__file__).resolve()), 'comparison_sha256': COMPARISON_SHA,
        'historical_census_helper_sha256': HISTORICAL_SHA, 'original_owner_session': 31070,
        'durable_result_sha256': transport.sha(DURABLE / 'result.json'), 'durable_archives': completed,
        'collection_sha256': collection['archive_sha256'], 'collection_files': len(collection['files']),
        'binaries_sha256': load(campaign / 'binaries-before.json'), 'censuses': censuses,
        'independent_replay': replay, 'comparison': comparison, 'gpu_execution': False, 'historical_pid_probes': False}
    assert len(transport.encoded(result)) <= 1024**2, 'bounded offline comparison output'
    output.mkdir(mode=0o700)
    transport.save(output / 'comparison.json', result)
    print(transport.encoded({'output': str(output), 'comparison_sha256': transport.sha(output / 'comparison.json'),
        'closed_groups': {name: value['count'] for name, value in censuses.items()},
        'trials': len(comparison['trials']), 'profiled_samples': comparison['profiled_sample_count']}).decode('ascii'))


if __name__ == '__main__':
    main()
