git show -s --format=%H%n%T%n%P%n%s HEAD 
