# Frozen campaign

Final source: 2816b6caf62047015a80cfcc4575988050f0f448.
Runtime production source: d512b0310f1407d3afc9328864e9cf6908df6f0e, unchanged
through the final source revision. The final commit is a test-only lint fix.

Final completed lower selections are `resumed-final-recycled-detach` and
`resumed-final-rebind`; the earlier `final-recycled-detach` run is incomplete as
recorded in its separate note. Do not infer a pass from its partial output.

Full runtime: 1766 passed, 3 unwaived socket-inspection failures, 28 ignored.
Serial backend: 869 passed, 28 ignored. Final lower selections: 20 and 64 passes
with overlap. Strict Clippy, no-default check, format, signatures and source
continuity passed. No native hardware, formal correspondence or performance
qualification is claimed.

Do not append to this directory after archiving. Documentation/publication
receipts belong in a separate directory.
