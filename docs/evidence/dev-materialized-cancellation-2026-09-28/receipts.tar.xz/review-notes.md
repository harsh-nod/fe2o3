# Read-only swarm review

Two existing agents reviewed; primary owned edits, integration and all tests.
No worker requested permissions or escalation. No concurrent builds/tests or
source edits during a build were permitted.

## Findings incorporated

- Ordinary Prepared must retain explicit newly bound versus still-attached
  recycled provenance. ResidentReused performance classification is insufficient:
  DATA detached then rebound is a newly bound recipe too.
- Capture the real recycled generation at the existing overwrite query. Detach
  authenticates and returns this prior generation; it is not completion of the
  cancelled launch. Use current Active descriptors after any host overwrites.
- Keep Active indexed and allocate its cancellation root before native effects.
  Install returned native DATA in that root before the outer lane callback closes.
- Authenticate exact recipe/module/allocation retains, reservation and selected
  lane ownership; settle only this submission, not successor dependency retains.
- Host native DATA alignment is 4096, whereas logical requested alignment may be
  1/8/64/etc. Validate canonical native layout and logical descriptor separately.
- Reconstruct first-unique-binding descriptor order and aligned merged ranges;
  checking only cardinality and layout permits equal-layout alias substitution.
- Require returned native DATA to be fully initialized.
- Nonempty pipeline must prevent recipe retirement. Final review corrected an
  earlier reachability concern: normal successor publication requires a
  Materialized/Completed predecessor, not Prepared. The pipeline test is explicitly
  a malformed-state defensive check, not healthy production coexistence evidence.
- Exercise terminal/inert progression and actual unrepaired Drop in subprocesses,
  including primary and auxiliary lane restoration.

## Evidence boundaries

Runtime scripts retain real admitted logical ownership and DataSpec bytes; they
do not mint native buffers or completion receipts. Manually supplied recycled
generation 7 is a scripted classification only. Queue/allocation profile setup
events are fixture-owned because its scripted constructor does not create queues.

Lower DetachFixture uses genuinely recycled owners, real reserve/cancel and
retirement/rebind sequencers with injected native memory operations. Its direct
evidence is separate from runtime scripts. No protected Worker, runtime-to-native
hardware execution, native cache reuse, formal correspondence or performance
claim follows from these checks.

## Next aligned implementation boundary

Ordinary initial binding/reuse/first-submit still precedes Active installation.
The outer progress catch preserves Pending recipe and logical retains, but newly
prepared descriptors/profile can leave the unwind stack; attached reuse takes
recycled metadata before overwrite succeeds. Introduce a distinct indexed
MaterializedBinding/Publishing phase before the first mutating native action.
Do not label a never-reserved owner MaterializedPrepared: its cancellation route
requires genuine cancelled reservation history. Preserve the existing one-time
Pending-to-Active handoff and all queued successor retains.

Current contract docs, not frozen R83/R125 artifacts, now describe ordinary
cancellation. Poll/wait may retry an already bound Prepared recipe; they do not
perform deferred preparation of queued compute work.
