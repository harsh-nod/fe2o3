git diff --exit-code d512b0310f1407d3afc9328864e9cf6908df6f0e HEAD -- crates/fe2o3-runtime 
