env GIT_TERMINAL_PROMPT=0 git push origin HEAD 
