# Incomplete observation

The goal continuation interrupted orchestration cell 128. Re-polling that exact
cell returned `exec cell 128 not found`. Its `final-recycled-detach` run has no
`.status` or `.finished` receipt and no complete test summary. The last output
ends during the native-fault fixture. A later `stat` still reported the same
2427-byte log, last modified 2026-09-28 06:55:50 UTC.

This run is incomplete, not a pass. `ps` from a later tool call sees only that
call's isolated process namespace and is not evidence about the lost session.
No replacement was started solely on an observation timeout: the exact
orchestration handle was missing. The replacement uses a new receipt label and
explicitly stores/notifies its process handle. Completed earlier qualification
receipts remain unchanged.
