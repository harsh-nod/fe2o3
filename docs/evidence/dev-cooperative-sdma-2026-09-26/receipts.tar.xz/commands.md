# Command Manifest

Working directory: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Cargo commands used `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1`.
Exit statuses and counts are in `qualification.json`; intermediate development
logs are retained but are not exact-source final qualification.

- `focused-1.log`, `focused-2.log`:
  `cargo test --offline -p fe2o3-runtime --all-features --lib cooperative_sdma -- --test-threads=1`
- `focused-2-diagnostic.log`:
  `target/debug/deps/fe2o3_runtime-e03b9552edb097b6 cooperative_sdma_live_leaf --nocapture --test-threads=1`
- `focused-3.log`, `focused-4.log`, `focused-5.log`:
  `cargo test --offline -p fe2o3-runtime --all-features --lib cooperative_sdma -- --nocapture --test-threads=1`
- `runtime-full.log`, `runtime-final.log`:
  `cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=1`
- `focused-final.log`, rerunning the final broad-run binary:
  `target/debug/deps/fe2o3_runtime-e03b9552edb097b6 cooperative_sdma --test-threads=1`
- `clippy-1.log`, `clippy-2.log`:
  `cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings`
- `doctests.log`: `cargo test --offline -p fe2o3-runtime --all-features --doc`
- `minimal-check.log`: `cargo check --offline -p fe2o3-runtime --no-default-features`
- `fmt.log`: `cargo fmt --all --check`
- `whitespace.log`: `git diff --check`
- `signature.log`:
  `git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD`

`source.patch` is the staged implementation patch against the parent in
`qualification.json`, including the two new source files and composition notes.
`source-sha256.txt` binds the final three Rust files. Tool identities are retained
in `rustc.txt` and `cargo.txt`. `commit.txt` identifies the signed implementation.
The failed hardware and issue-access attempts are documented in `access-errors.md`.
