# Read-Only Review Notes

These notes summarize native collaboration-agent reviews. Reviewers did not
edit files, run tests, invoke Qwen, or execute remote GPU work. Tests were run by
the primary agent. This is review evidence, not formal verification.

## Lifecycle Review

Findings incorporated before final qualification:

- Reuse exact child async submission custody; do not create an independent raw
  ticket ownership machine or invent completion events.
- Authenticate every active native allocation owner against an allowed outer
  predecessor, including its exact child endpoint, stream and submission.
- Published D2H and H2D are not cancellable, including H2D at outer cursor zero.
- Child-local recovered cleanup cannot escape as conclusive outer quiescence
  while the copy could subsequently resume Write. Freeze the copy as Failed,
  retain quiescent residual scratch, and retry disposal only at submission release.
- Propagating an ancestor's cleanup error must settle the entire selected
  dependency path, not only the oldest and requested records.
- Cancellation after a prepublication operational failure must report that
  conclusive failure, not claim publication via TooLate.
- Unchanged Pending observations must not advance the progress generation.

The final production review found no remaining correctness blocker. The selected
clean-native path has no GPU completion wait, but allocation, CPU and driver
costs prevent a hard latency claim. Native-dirty fallback remains blocking.

## Accounting Review

- Authenticate the selected child's existing request binding before backing
  effects. Reserve and retain that exact account's bytes in Required mode.
- Rejected allocation refunds via rejection. SettledNoOwner refunds via disposal.
  Generic Quiescent, Terminal and unwind cannot refund uncertain backing custody.
- Release child submission, then allocation, then private stream. Keep each
  handle installed until its corresponding disposal succeeds.
- Quarantine request credit before potentially panicking poison work. Preserve
  the original unwind payload using the existing guarded poison helper.
- One phase-local scratch window suffices; source and destination scratch are
  not concurrent. Include it in the cooperative aggregate reservation.

No public CPU-only constructor exists for an authentic positive composed
request-account/runtime-binding fixture. The final runtime tests exercise
scripted legacy children and accounting of their staging resources, not a
positive composed-account adapter. No fake checked-device or native authority
was added to close that evidence gap.
