# Access Attempts

`ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x 'hostname; df -h /tmp'`
returned exit 255. The exact diagnostic is retained in `ssh-check.log`.
No remote process or artifact was created.

`gh issue view 182 --repo harsh-nod/fe2o3 --json number,title,state,body`
returned exit 1. The redirected `issue-182.json` is empty; stderr was reported by
the command tool as:

```text
error connecting to api.github.com
check your internet connection or https://githubstatus.com
```

This attempt did not refresh issue state. No approval request or network-policy
bypass was attempted.
