#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly logs=/home/harsh/.codex-tmp/fe2o3-proof-runtime-20261003-boEtFq/qualification
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true
export CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
run() {
    local label=$1
    shift
    printf 'RUN %s\n' "$label"
    if "$@" >"$logs/$label.log" 2>&1; then
        printf 'PASS %s\n' "$label"
    else
        cat "$logs/$label.log"
        return 1
    fi
}
run libraries cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier -p rustc-codegen-fe2o3 --lib
run clippy cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-verifier -p rustc-codegen-fe2o3 --lib --no-deps -- -D warnings
run reference-binding cargo +nightly-2026-04-03 test --locked --offline -p rustc-codegen-fe2o3 --test reference_binding_v1 -- --ignored --nocapture
run aggregate-formulas env VERUS=/home/harsh/factory/.tools/verus-0.2026.08.02.b677dd5/verus-x86-linux/verus bash scripts/test-mir-pliron-per-compilation-verus.sh
run whitespace git diff --check
run formatting rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true \
    crates/fe2o3-verifier/src/functional_refinement_process_tree_v1_linux.rs \
    crates/fe2o3-verifier/src/functional_refinement_receipt_v2.rs \
    crates/fe2o3-verifier/src/mir_pliron_per_compilation_verus_v1.rs \
    crates/rustc-codegen-fe2o3/src/production_ranked_projection_v1.rs \
    crates/rustc-codegen-fe2o3/src/production_ranked_projection_v1/reference_write_only_v2_tests.rs \
    crates/rustc-codegen-fe2o3/src/reference_effect_v1.rs \
    crates/rustc-codegen-fe2o3/tests/production_extraction_driver_v1.rs \
    crates/rustc-codegen-fe2o3/tests/reference_binding_v1.rs
