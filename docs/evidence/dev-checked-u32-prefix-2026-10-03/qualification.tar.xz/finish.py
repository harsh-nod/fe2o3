"""Run bounded final-source checks sequentially in the existing target tree."""
from pathlib import Path
import subprocess
import sys

root = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
capture = Path(__file__).with_name('capture.py')
cargo = ['cargo', '+nightly-2026-04-03']
common = ['--locked', '--offline', '-p', 'fe2o3-verifier']
commands = [
    ('build-final', cargo + ['test', *common, '--all-features', '--lib', '--no-run', '--message-format=json']),
    ('tests-final', cargo + ['test', *common, '--all-features', '--lib']),
    ('public-final', cargo + ['test', *common, '--all-features', '--test', 'gfx942_local_checked_u32_add_v1']),
    ('docs-final', cargo + ['test', *common, '--all-features', '--doc']),
    ('no-default-final', cargo + ['check', *common, '--no-default-features', '--lib']),
    ('format-final', ['rustfmt', '+nightly-2026-04-03', '--edition', '2024', '--check',
        'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/source_prefix.rs']),
]
for name, command in commands:
    result = subprocess.run([sys.executable, '-I', '-B', str(capture), name, '900s', *command], cwd=root)
    if result.returncode:
        raise SystemExit(result.returncode)
