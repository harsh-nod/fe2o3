"""Seal an already audited candidate; never overwrite an evidence archive."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
OUT = ROOT / 'docs/evidence/dev-checked-u32-prefix-2026-10-03'
archive = OUT / 'qualification.tar.xz'
if archive.exists():
    raise SystemExit('archive already exists; do not overwrite a sealed packet')
subprocess.run([sys.executable, '-I', '-B', str(RAW / 'audit.py')], check=True)
patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--', 'crates', 'scripts', '.github'], cwd=ROOT)
if not patch:
    raise SystemExit('missing staged candidate patch')
(RAW / 'source.patch').write_bytes(patch)
files = sorted(path for path in RAW.rglob('*') if path.is_file())
if any(path.is_symlink() for path in RAW.rglob('*')):
    raise SystemExit('no symlinks in evidence')
manifest = {str(path.relative_to(RAW)): dict(bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in files
            if path.name != 'archive-manifest.json'}
(RAW / 'archive-manifest.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for name in [*manifest, 'archive-manifest.json']:
        tar.add(RAW / name, arcname=name, recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    if set(tar.getnames()) != {*manifest, 'archive-manifest.json'} or len(tar.getmembers()) != len(manifest) + 1:
        raise SystemExit('archive inventory mismatch')
    for member in tar.getmembers():
        if not member.isfile():
            raise SystemExit('archive must contain only regular files')
        data = tar.extractfile(member).read()
        if member.name == 'archive-manifest.json':
            if json.loads(data) != manifest:
                raise SystemExit('embedded manifest mismatch')
        elif manifest[member.name] != dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()):
            raise SystemExit('archive member mismatch: ' + member.name)
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
(OUT / 'SHA256SUMS').write_text(sha + '  qualification.tar.xz\n')
print(json.dumps(dict(archive_sha256=sha, bytes=archive.stat().st_size, manifest_files=len(manifest),
                     source_patch_sha256=hashlib.sha256(patch).hexdigest()), indent=2))
