"""Record one bounded command against exact candidate source identities."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
ENV = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin',
           LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='4',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1',
           CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true',
           CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', RUST_TEST_THREADS='1',
           FE2O3_HIP_SYS_DISABLE='1')


def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
        '--exclude-standard', '-z', '--', 'crates', 'scripts', '.github',
        'tests/support', 'benchmarks/runtime_gfx942', 'Cargo.toml', 'Cargo.lock',
        'rust-toolchain.toml'], cwd=ROOT, env=ENV)
    return {os.fsdecode(path): hashlib.sha256((ROOT / os.fsdecode(path)).read_bytes()).hexdigest()
            for path in sorted(set(paths.split(b'\0'))) if path}


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def main():
    label, seconds, *command = sys.argv[1:]
    assert label and '/' not in label and label not in ('.', '..') and command
    folder = OUT / label
    folder.mkdir(mode=0o700)
    before = snapshot()
    receipt = dict(command=['timeout', '--signal=TERM', '--kill-after=30s', seconds, *command],
                   environment=ENV, cwd=str(ROOT),
                   base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, env=ENV, text=True).strip(),
                   controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   started=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(folder / 'source-before.json', before)
    save(folder / 'command.json', receipt)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    with (folder / 'stdout').open('xb') as stdout, (folder / 'stderr').open('xb') as stderr:
        result = subprocess.run(receipt['command'], cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr, check=False)
    after = snapshot()
    receipt.update(exit=result.returncode, source_unchanged=before == after,
                   finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for name in ('stdout', 'stderr'):
        receipt[name + '_sha256'] = hashlib.sha256((folder / name).read_bytes()).hexdigest()
    if '--message-format=json' in command and result.returncode == 0:
        receipt['executables'] = {}
        for line in (folder / 'stdout').read_text().splitlines():
            row = json.loads(line)
            path = row.get('executable') if row.get('reason') == 'compiler-artifact' else None
            if path:
                receipt['executables'][path] = dict(sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                    byte_length=Path(path).stat().st_size, target=row['target']['name'], test=row['profile']['test'])
    save(folder / 'source-after.json', after)
    save(folder / 'receipt.json', receipt)
    print(json.dumps(dict(label=label, exit=result.returncode, source_unchanged=before == after)), flush=True)
    return result.returncode if before == after else 125


if __name__ == '__main__':
    sys.exit(main())
