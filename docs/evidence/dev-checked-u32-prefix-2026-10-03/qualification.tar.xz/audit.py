"""Recheck final command/source receipts and solver diagnostics before publication."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
BASE = '802cac8cb8ff8ae3ecf483fe8bd536fbd319caa8'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def need(condition, label):
    if not condition:
        raise ValueError(label)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


capture = load('capture', RAW / 'capture.py')
current = capture.snapshot()
need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE, 'candidate base')
labels = ['build-final', 'tests-final', 'public-final', 'docs-final', 'no-default-final',
          'format-final', 'clippy-lib-final', 'ci-dispatch-02', 'proof-final', 'wrapper-final']
for label in labels:
    folder = RAW / label
    receipt = read(folder / 'receipt.json')
    need(receipt['base'] == BASE and receipt['cwd'] == str(ROOT), label + ': original candidate')
    need(receipt['environment'] == capture.ENV and receipt['controller_sha256'] == digest(RAW / 'capture.py'), label + ': command environment/controller')
    need(receipt['exit'] == 0 and receipt['source_unchanged'] is True, label + ': successful unchanged source')
    need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == current, label + ': exact current source cohort')
    for stream in ('stdout', 'stderr'):
        need(digest(folder / stream) == receipt[stream + '_sha256'], label + ': ' + stream)
    need(read(folder / 'command.json')['command'] == receipt['command'], label + ': original command')

for label, passed, ignored in [('tests-final', 114, 4), ('public-final', 7, 0), ('docs-final', 30, 0)]:
    text = (RAW / label / 'stdout').read_text()
    need(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
         == [(str(passed), '0', str(ignored))], label + ': exact totals')
    names = re.findall(r'^test (.*?) \.\.\. (ok|ignored(?:,.*)?)$', text, re.M)
    need(len(names) == passed + ignored and len({name for name, _ in names}) == len(names), label + ': complete unique roster')
    (RAW / (label + '-roster.json')).write_text(json.dumps(names, indent=2) + '\n')
text = (RAW / 'tests-final/stdout').read_text()
need(len(re.findall(r'^test gfx942_local_checked_u32_add_v1::source_prefix::tests::.* \.\.\. ok$', text, re.M)) == 7, 'seven new passing tests')
need(len(re.findall(r'^test .*source_prefix\.rs .*compile fail \.\.\. ok$', (RAW / 'docs-final/stdout').read_text(), re.M)) == 2, 'two borrowed-owner compile failures')
executables = read(RAW / 'build-final/receipt.json')['executables']
need(len(executables) == 1, 'one final unit executable')
for path, row in executables.items():
    need(row['test'] is True and row['target'] == 'fe2o3_verifier'
         and Path(path).stat().st_size == row['byte_length'] and digest(Path(path)) == row['sha256'], 'unit executable identity')
    need(Path(path).name in (RAW / 'tests-final/stderr').read_text(), 'executed final unit binary')

checker = load('final_prefix_checker', ROOT / 'crates/fe2o3-verifier/verus/checked_u32_prefix_check.py')
campaign = RAW / 'campaign-final'
manifest = read(campaign / 'source-before.json')
need(manifest == read(campaign / 'source-after.json'), 'proof source continuity')
for path, expected in manifest.items():
    need(digest(ROOT / path) == expected and digest(campaign / 'inputs' / path) == expected,
         'proof input: ' + path)
    if path in current:
        need(current[path] == expected, 'proof/full-source cohort agreement: ' + path)
result = read(campaign / 'result.json')
need(result['accepted'] is True and result['source_unchanged'] is True and result['error'] is None, 'proof acceptance')
mutants = checker.mutants((ROOT / checker.BODY).read_text())
expected = ['controls', 'release-before', 'positive-before', *['negative-' + name for name in mutants], 'positive-after', 'release-after']
need([row['name'] for row in result['stages']] == expected, 'exact proof stage roster')
last = 0
for row in result['stages']:
    name = row['name']
    record = read(campaign / name / 'record.json')
    need(row['accepted'] is True and record['group_absent'] is True and record.get('exception') is None
         and record['status'] == row['status'] and last < record['started_ns'] < record['finished_ns'], 'proof process: ' + name)
    last = record['finished_ns']
    if name.startswith(('positive-', 'negative-')):
        negative = name.startswith('negative-')
        invariant = mutants[name.removeprefix('negative-')][1] if negative else False
        staged = campaign / (name + '-source')
        proof = staged / checker.PROOF
        need(checker.classify(record['status'], (campaign / name / 'stdout.log').read_text(),
             (campaign / name / 'stderr.log').read_text(), proof, negative, invariant), 'reclassified proof: ' + name)
        for path in (checker.PROOF, checker.BODY, checker.base.BODY):
            data = mutants[name.removeprefix('negative-')][0].encode('ascii') if negative and path == checker.BODY else (ROOT / path).read_bytes()
            need((staged / path).read_bytes() == data, 'exact staged proof: ' + name)
need(not list(RAW.glob('fe2o3-checked-u32-prefix.*')), 'wrapper removed its owned directory')
summary = dict(accepted=True, base=BASE, source_paths=len(current), accepted_commands=labels,
               library_passed=114, library_ignored=4, public_passed=7, docs_passed=30,
               proof_stages=13, verified_obligations=11, logical_mutants=8, source_controls=6,
               application_authority=False, genuine_rustc_extraction=False, native_gpu_run=False)
(RAW / 'audit-result.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
