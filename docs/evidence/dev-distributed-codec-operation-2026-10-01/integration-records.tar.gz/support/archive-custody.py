#!/usr/bin/env python3
"""Retain W16 source, signed incremental bundle and records without moving originals."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
NAMES = ("fe2o3-distributed-codec-operation-20261001-signed", "records", "candidate.bundle")
DEST = Path("/mnt/c/fe2o3-codec-header-view-evidence-20261001/w16-signed-operation")
CAP = 256 * 1024 * 1024
FLOOR = 4 * 1024 * 1024 * 1024


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def inventory():
    entries = []
    for name in NAMES:
        base = ROOT / name
        for path in [base, *sorted(base.rglob("*"))]:
            if path.is_relative_to(ROOT / NAMES[0] / '.git'):
                continue
            info = path.lstat()
            kind = "dir" if stat.S_ISDIR(info.st_mode) else "file"
            if kind == "file" and not stat.S_ISREG(info.st_mode):
                raise RuntimeError(f"unsupported source kind: {path}")
            item = {"path": path.relative_to(ROOT).as_posix(), "kind": kind,
                    "mode": stat.S_IMODE(info.st_mode)}
            if kind == "file":
                item.update(size=info.st_size, sha256=digest(path))
            entries.append(item)
    if sum(item.get("size", 0) for item in entries) > CAP:
        raise RuntimeError("logical source capture exceeds cap")
    return entries


def verify_archive(path, entries):
    with tarfile.open(path, "r:gz") as archive:
        actual = archive.getmembers()
        if len(actual) != len(entries):
            raise RuntimeError("archive member count mismatch")
        for member, expected in zip(actual, entries):
            if member.name != expected["path"] or member.mode != expected["mode"]:
                raise RuntimeError("archive path/mode mismatch")
            if expected["kind"] == "dir":
                if not member.isdir():
                    raise RuntimeError("archive directory kind mismatch")
            else:
                if not member.isfile() or member.size != expected["size"]:
                    raise RuntimeError("archive regular-file shape mismatch")
                stream = archive.extractfile(member)
                with stream:
                    actual_sha = hashlib.file_digest(stream, "sha256").hexdigest()
                if actual_sha != expected["sha256"]:
                    raise RuntimeError("archive member byte mismatch")


def durable_json(path, value):
    encoded = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    if path.read_bytes() != encoded:
        raise RuntimeError("JSON readback mismatch")


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def main():
    if DEST.exists():
        raise RuntimeError("durable namespace already exists")
    for path in (ROOT, DEST.parent):
        if shutil.disk_usage(path).free < FLOOR + CAP:
            raise RuntimeError(f"startup reserve missing: {path}")
    before = inventory()
    staging = ROOT / "archive-staging-1"
    staging.mkdir(mode=0o700)
    archive_path = staging / "w16-source-records.tar.gz"
    with tarfile.open(archive_path, "x:gz", dereference=False) as archive:
        for item in before:
            archive.add(ROOT / item["path"], arcname=item["path"], recursive=False)
    with archive_path.open("rb") as stream:
        os.fsync(stream.fileno())
    if archive_path.stat().st_size > CAP:
        raise RuntimeError("archive size exceeds cap")
    verify_archive(archive_path, before)
    if inventory() != before:
        raise RuntimeError("original source/record drift")
    if shutil.disk_usage(DEST.parent).free < FLOOR + archive_path.stat().st_size + 16 * 1024 * 1024:
        raise RuntimeError("durable destination reserve missing")
    DEST.mkdir(mode=0o700)
    destination = DEST / archive_path.name
    with archive_path.open("rb") as source, destination.open("xb") as output:
        shutil.copyfileobj(source, output, 1024 * 1024)
        output.flush()
        os.fsync(output.fileno())
    if digest(destination) != digest(archive_path):
        raise RuntimeError("durable archive copy mismatch")
    verify_archive(destination, before)
    if inventory() != before:
        raise RuntimeError("original drift after durable readback")
    durable_json(DEST / "members.json", before)
    receipt = {"schema": "fe2o3-codec-w16-custody-v1", "original_root": str(ROOT),
               "archive": str(destination), "archive_sha256": digest(destination),
               "archive_bytes": destination.stat().st_size,
               "members_sha256": digest(DEST / "members.json"),
               "members": len(before), "regular_files": sum(i["kind"] == "file" for i in before),
               "logical_bytes": sum(i.get("size", 0) for i in before),
               "controller_sha256": digest(Path(__file__)),
               "originals_preserved": True, "per_member_readback": True,
               "signed_commit": "d0d24274c69043ae1205376489cf41179740a564",
               "incremental_bundle_sha256": digest(ROOT / "candidate.bundle"),
               "bundle_prerequisite": "da4ff4019ebad1aecde1bdff3942f7f4e0383e33",
               "private_git_directory_excluded": True,
               "qualification": False, "full_git_or_inherited_dependency_archive": False}
    durable_json(DEST / "custody.json", receipt)
    sync_directory(DEST)
    sync_directory(DEST.parent)
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
