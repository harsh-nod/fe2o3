#!/usr/bin/env python3
"""Run source controls with an explicit environment and unconditional closure."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path('/run/shm/fe2o3-runtime-integration-20261001-99c07511e')
OUTPUT = Path('/run/shm/fe2o3-operation-integration-checks-20261001-attempt-3')
WORKFLOW = ROOT / '.github/workflows/runtime-component-source-guards.yml'
NATIVE = ROOT / 'benchmarks/runtime_gfx942/xgmi_peer_series_native.py'


def environment(tmp):
    return {
        'PATH': '/usr/bin:/bin:/home/harsh/.cargo/bin',
        'HOME': '/home/harsh', 'USER': 'harsh', 'LOGNAME': 'harsh',
        'CARGO_HOME': '/home/harsh/.cargo', 'RUSTUP_HOME': '/home/harsh/.rustup',
        'CARGO_NET_OFFLINE': 'true', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
        'TZ': 'UTC', 'TMPDIR': str(tmp), 'PYTHONDONTWRITEBYTECODE': '1',
        'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_GLOBAL': '/dev/null',
        'GIT_CONFIG_NOSYSTEM': '1',
    }


def snapshot(env):
    def git(*argv):
        result = subprocess.run(
            ['git', '--no-replace-objects', '-c', 'gc.auto=0', *argv],
            cwd=ROOT, capture_output=True, check=True, timeout=30, env=env,
        )
        if result.stderr:
            raise ValueError('unexpected Git diagnostics')
        return result.stdout
    paths = git('ls-files', '--modified', '--others', '--exclude-standard', '-z').split(b'\0')
    sources = {}
    for raw in sorted(set(paths) - {b''}):
        name = os.fsdecode(raw)
        path = ROOT / name
        if not path.is_file() or path.is_symlink():
            raise ValueError('ordinary integration input required')
        sources[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {'commit': git('rev-parse', 'HEAD').decode().strip(),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'changed_sources': sources}


def close(source, rows, commands, env, recorder, native, hot, namespace, output):
    errors = []
    closing_source = None
    census = None
    try:
        closing_source = snapshot(env)
        hot.B.write_json(output / 'closing-source.json', closing_source)
        if source != closing_source:
            errors.append('source continuity failed')
    except Exception as error:
        errors.append('continuity: ' + type(error).__name__)
    try:
        census = native.fresh_census(recorder, hot, namespace)
        hot.B.write_json(output / 'fresh-census.json', census)
    except Exception as error:
        errors.append('closure: ' + type(error).__name__)
    accepted = (not errors and source == closing_source
                and len(rows) == len(commands) and all(row['accepted'] for row in rows)
                and census is not None and len(census['records']) == len(commands))
    result = {'accepted': accepted, 'rows': rows, 'errors': errors}
    hot.B.write_json(output / 'result.json', result)
    return accepted


def main():
    if not sys.flags.isolated or not sys.dont_write_bytecode:
        raise ValueError('python3 -I -B required')
    spec = importlib.util.spec_from_file_location('integration_owned_runner', NATIVE)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    hot, _, _ = native.load_helpers()
    output = native.fresh_output(OUTPUT)
    os.chmod(output, 0o700)
    (output / 'tmp').mkdir(mode=0o700)
    env = environment(output / 'tmp')
    document = yaml.safe_load(WORKFLOW.read_bytes())
    commands = []
    for step in document['jobs']['source-controls']['steps']:
        for line in step.get('run', '').strip().splitlines():
            argv = shlex.split(line)
            if argv[:3] != ['python3', '-I', '-B']:
                raise ValueError('unexpected workflow command')
            commands.append({'step': step['name'], 'argv': argv})
    source = snapshot(env)
    hot.B.write_json(output / 'inputs.json', {
        'source': source, 'environment': env,
        'workflow_sha256': hashlib.sha256(WORKFLOW.read_bytes()).hexdigest(),
        'owner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'commands': commands, 'proof_or_cpu_campaign': False,
        'prior_local_attempts': {'count': 2, 'public_raw_records': False,
                                'reason': 'inherited authentication environment'},
    })
    recorder = native.FreshRecorder(output / 'commands', ROOT, hot)
    namespace = os.readlink('/proc/self/ns/pid')
    rows = []
    accepted = False
    try:
        for index, command in enumerate(commands, 1):
            row = dict(command, name=f'{index:02d}', accepted=False)
            rows.append(row)
            try:
                recorder.run(row['name'], row['argv'], 120, env=env)
                row['accepted'] = True
            except Exception as error:
                row['error'] = type(error).__name__
            hot.B.write_json(output / (row['name'] + '-result.json'), row)
            print(json.dumps(row), flush=True)
    finally:
        accepted = close(source, rows, commands, env, recorder, native, hot, namespace, output)
    return 0 if accepted else 1


if __name__ == '__main__':
    raise SystemExit(main())
