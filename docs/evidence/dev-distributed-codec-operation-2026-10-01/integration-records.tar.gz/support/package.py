#!/usr/bin/env python3
"""Publish accepted immutable evidence without replaying archived commands."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tarfile

ROOT = Path('/run/shm/fe2o3-runtime-integration-20261001-99c07511e')
W16 = Path('/run/shm/fe2o3-codec-operation-qualified-20261001-uZkEy7tj')
DURABLE = Path('/mnt/c/fe2o3-codec-header-view-evidence-20261001/w16-signed-operation')
DEST = ROOT / 'docs/evidence/dev-distributed-codec-operation-2026-10-01'
CHECKS = Path('/run/shm/fe2o3-operation-integration-checks-20261001-attempt-3')
SCANNER = Path('/run/shm/fe2o3-evidence-sensitive-scan-20261001-v2.py')
SCAN = Path('/run/shm/fe2o3-sensitive-proposed-packet-scan-20261001.json')
COMMIT = 'd0d24274c69043ae1205376489cf41179740a564'
# Already-published test-only issuer keys, checked against GitHub's blob IDs.
PUBLIC_TEST_KEYS = {
    'fe2o3-distributed-codec-operation-20261001-signed/crates/fe2o3-protected-publisher/tests/fixtures/github-test-rsa.pem': {
        'sha256': '5c495a1cde42589e4f68081bdae57b0be82d332e3593c1b1c08f1a995643ab05',
        'git_blob': '13c638a0748533aee9d594be1c80acb803b00822',
    },
    'fe2o3-distributed-codec-operation-20261001-signed/crates/fe2o3-protected-publisher/tests/fixtures/mock-issuer-key.pem': {
        'sha256': 'b1d18d83c3ace2bfc3b04dd28c01bc8f495938600e3375f930cf4ada374cb1dd',
        'git_blob': '566eaea6fbfa72f6fa4e516c28e41c3cd6f15500',
    },
}
PINS = {
    W16 / 'candidate.bundle': '5bcbb71585c1c5af1a326454cfdb1ef1194bbff9b8834edf8d718631bf665ce9',
}


def raw(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and path.resolve() == path and info.st_nlink == 1
    return path.read_bytes()


def sha(path):
    return hashlib.sha256(raw(path)).hexdigest()


def write(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    assert raw(path) == data


def private_key(data):
    return re.search(br'-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=\r\n]+-----END (?:[A-Z]+ )?PRIVATE KEY-----', data)


def reviewed_key(name, data):
    expected = PUBLIC_TEST_KEYS.get(name)
    return expected is not None and hashlib.sha256(data).hexdigest() == expected['sha256'] \
        and hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == expected['git_blob']


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--audit-sha', required=True)
    parser.add_argument('--custody-sha', required=True)
    parser.add_argument('--result-sha', required=True)
    parser.add_argument('--inputs-sha', required=True)
    parser.add_argument('--census-sha', required=True)
    args = parser.parse_args()
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert shutil.disk_usage(ROOT).free > 4 * 1024**3 + 512 * 1024**2
    audit_path = W16 / 'records/qualification-post-audit-1.json'
    assert sha(audit_path) == args.audit_sha
    audit = json.loads(raw(audit_path))
    assert audit['signed_operation_post_audit_pass'] is True and audit['commit'] == COMMIT
    assert audit['recorded_groups_closed'] == 47 and len(audit['fresh_qualified_negatives']) == 40
    assert len(audit['positives']) == 3 and audit['historical_qualified_kills'] == 0
    assert sha(DURABLE / 'custody.json') == args.custody_sha
    custody = json.loads(raw(DURABLE / 'custody.json'))
    assert custody['signed_commit'] == COMMIT and custody['originals_preserved'] is True
    assert custody['per_member_readback'] is True and custody['private_git_directory_excluded'] is True
    archive = DURABLE / 'w16-source-records.tar.gz'
    PINS.update({
        audit_path: args.audit_sha,
        DURABLE / 'custody.json': args.custody_sha,
        archive: custody['archive_sha256'],
        DURABLE / 'members.json': custody['members_sha256'],
        CHECKS / 'result.json': args.result_sha,
        CHECKS / 'inputs.json': args.inputs_sha,
        CHECKS / 'fresh-census.json': args.census_sha,
    })
    report = json.loads(raw(SCAN))
    assert report['accepted'] is True and report['hits'] == report['errors'] == []
    assert str(archive) in report['scope']
    assert sha(SCANNER) == report['scanner_sha256']
    spec = importlib.util.spec_from_file_location('publication_sensitive_scan', SCANNER)
    scanner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scanner)
    patterns = scanner.needles()
    assert patterns

    def clean(data):
        assert not any(value in data for value in patterns), 'known sensitive value in proposed evidence'
        for match in scanner.JSON_FIELD.finditer(data):
            value = json.loads(match[2])
            assert len(value) < 12 or any(word in value.lower() for word in
                ('redacted', 'placeholder', 'dummy', 'not-a-real', '${')), 'sensitive JSON field in proposed evidence'

    assert sha(archive) == custody['archive_sha256']
    assert sha(DURABLE / 'members.json') == custody['members_sha256']
    members = json.loads(raw(DURABLE / 'members.json'))
    assert archive.stat().st_size < 90 * 1024**2
    seen = set()
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar:
            assert member.name not in seen and not member.name.startswith('/')
            assert '..' not in Path(member.name).parts
            expected = members[len(seen)]
            assert member.name == expected['path'] and member.mode == expected['mode']
            original = W16 / member.name
            assert original.resolve() == original
            assert stat.S_IMODE(original.lstat().st_mode) == member.mode
            if member.isdir():
                assert expected['kind'] == 'dir' and original.is_dir()
            else:
                assert member.isfile() and expected['kind'] == 'file'
                data = tar.extractfile(member).read()
                assert len(data) == expected['size'] and hashlib.sha256(data).hexdigest() == expected['sha256']
                assert data == raw(original)
                assert not private_key(data) or reviewed_key(member.name, data), member.name
                clean(data)
            seen.add(member.name)
    assert len(seen) == len(members) == custody['members']
    assert all(sha(path) == digest for path, digest in PINS.items())
    checks = json.loads(raw(CHECKS / 'result.json'))
    assert checks['accepted'] is True and len(checks['rows']) == 27
    assert all(row['accepted'] is True for row in checks['rows'])
    closure = json.loads(raw(CHECKS / 'fresh-census.json'))
    inputs = json.loads(raw(CHECKS / 'inputs.json'))
    assert inputs['source'] == json.loads(raw(CHECKS / 'closing-source.json'))
    PINS[CHECKS / 'closing-source.json'] = sha(CHECKS / 'closing-source.json')
    PINS[Path('/run/shm/fe2o3-operation-integration-checks-20261001-v3.py')] = inputs['owner_sha256']
    roster = [f'{index:02d}' for index in range(1, 28)]
    assert closure['scope'] == 'fresh-recorder-closed-groups-no-historical-pid-probes'
    assert closure['attempt_order'] == roster
    assert [row['name'] for row in closure['records']] == roster
    assert sorted(closure['raw_sha256']) == roster
    assert len(inputs['commands']) == 27 and checks['errors'] == []
    for index, name in enumerate(roster):
        directory = CHECKS / 'commands' / name
        receipt = json.loads(raw(directory / 'receipt.json'))
        hashes = closure['raw_sha256'][name]
        assert set(hashes) == {'receipt.json', 'stdout', 'stderr'}
        assert all(sha(directory / part) == digest for part, digest in hashes.items())
        PINS.update({directory / part: digest for part, digest in hashes.items()})
        assert receipt['group_absent'] is True and receipt['exit'] == 0 and receipt['error'] is None
        assert receipt['command'] == inputs['commands'][index]['argv']
        assert receipt['cwd'] == str(ROOT) and receipt['environment'] == inputs['environment']
        assert receipt['timeout_seconds'] == 120 and receipt['finished_ns'] >= receipt['started_ns']
        assert receipt['stdout_sha256'] == hashes['stdout'] and receipt['stderr_sha256'] == hashes['stderr']
        assert closure['records'][index]['receipt_sha256'] == hashes['receipt.json']
        assert closure['records'][index]['pid'] == receipt['pid']
    assert not DEST.exists()
    DEST.mkdir(parents=True, mode=0o755)
    copied = {}
    for path, name in ((archive, 'source-and-campaign.tar.gz'),
                       (DURABLE / 'members.json', 'campaign-members.json'),
                       (DURABLE / 'custody.json', 'custody.json'),
                       (W16 / 'candidate.bundle', 'signed-source.bundle'),
                       (audit_path, 'independent-readback.json')):
        data = raw(path)
        clean(data)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == PINS[path]
        write(DEST / name, data)
        copied[name] = {'original': str(path), 'bytes': len(data), 'sha256': digest}
    entries = {'support/package.py': Path(__file__).resolve(),
        'support/checks.py': Path('/run/shm/fe2o3-operation-integration-checks-20261001-v3.py'),
        'support/sensitive-scan.py': SCANNER,
        'support/proposed-evidence-sensitive-scan.json': SCAN,
        'support/archive-custody.py': W16 / 'archive_custody.py'}
    for number in (3,):
        folder = Path(f'/run/shm/fe2o3-operation-integration-checks-20261001-attempt-{number}')
        for path in sorted(folder.rglob('*')):
            assert not path.is_symlink()
            if path.is_file():
                entries[f'attempt-{number}/' + path.relative_to(folder).as_posix()] = path
    total = sum(path.stat().st_size for path in entries.values())
    assert total < 64 * 1024**2
    for path in entries.values():
        PINS.setdefault(path, sha(path))
    integration = DEST / 'integration-records.tar.gz'
    manifest = {}
    with integration.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for name, path in entries.items():
                    data = raw(path)
                    assert hashlib.sha256(data).hexdigest() == PINS[path]
                    assert not private_key(data), str(path)
                    clean(data)
                    member = tarfile.TarInfo(name)
                    member.size, member.mode, member.mtime = len(data), 0o644, 0
                    tar.addfile(member, io.BytesIO(data))
                    manifest[name] = {'original': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        output.flush()
        os.fsync(output.fileno())
    observed = set()
    with tarfile.open(integration, 'r:gz') as tar:
        for member in tar:
            assert member.isfile() and member.name not in observed and member.name in entries
            data = tar.extractfile(member).read()
            assert data == raw(entries[member.name])
            assert hashlib.sha256(data).hexdigest() == manifest[member.name]['sha256']
            observed.add(member.name)
    assert observed == set(entries)
    value = {'schema': 1, 'signed_candidate': COMMIT, 'files': copied,
        'integration_archive_sha256': sha(integration), 'integration_archive_bytes': integration.stat().st_size,
        'integration_members': manifest, 'integration_uncompressed_bytes': total,
        'existing_public_test_key_fixtures': PUBLIC_TEST_KEYS,
        'test_key_public_source_commit': '99c07511e75ee4b885fb96dbf1a094c045d60754',
        'all_members_readback_verified': True,
        'prior_local_integration_attempts': {'count': 2, 'preserved_privately': True,
            'excluded_from_public_packet': True, 'reason': 'inherited authentication environment'},
        'new_compiler_solver_or_gpu_execution': False, 'self_contained_campaign': False,
        'scope': 'Exact complete durable signed source/campaign packet plus independent audit and fresh clean-environment integration. Two earlier local integration attempts remain private due to captured authentication environment. Prior CPU executables, toolchains and inherited historical helper/source prerequisites remain external. No archived command was replayed and no historical PID was probed.'}
    manifest_data = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    clean(manifest_data)
    write(DEST / 'manifest.json', manifest_data)
    for folder in (DEST, DEST.parent):
        descriptor = os.open(folder, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    assert all(sha(path) == digest for path, digest in PINS.items())
    print(json.dumps({key: item for key, item in value.items() if key != 'integration_members'}, sort_keys=True))


if __name__ == '__main__':
    main()
