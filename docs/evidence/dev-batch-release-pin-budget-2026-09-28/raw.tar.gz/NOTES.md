# Batch Pin Release Development And Qualification

CPU source: 05d858326b36349959de08d9451813a0ea6d954f.
Final signed proof source: c677f1915d1e5efcfdd38e5d60732712e20321c0.
The latter changes only one proof assertion, not production or CPU-test code.
Workspace: /home/harsh/.codex-tmp/fe2o3-r61-execution.
Toolchain: nightly-2026-04-03. Builds use CARGO_INCREMENTAL=0,
CARGO_BUILD_JOBS=2. Tests use `prlimit --core=0:0 --`.

## Commands

- `cargo +nightly-2026-04-03 test -p fe2o3-kfd --all-features --lib queue::completion::dependency_event::tests -- --nocapture`
- `target/debug/deps/fe2o3_kfd-65695dc23b288bd0 --skip queue::live::construction_primary`
- `cargo +nightly-2026-04-03 test -p fe2o3-runtime --all-features --lib`
- `cargo +nightly-2026-04-03 clippy -p fe2o3-kfd -p fe2o3-runtime --all-features --all-targets -- -D warnings`
- `cargo +nightly-2026-04-03 check -p fe2o3-kfd -p fe2o3-runtime --no-default-features`
- `cargo +nightly-2026-04-03 test -p fe2o3-kfd -p fe2o3-runtime -p fe2o3-runtime-model --all-features --doc`
- `cargo +nightly-2026-04-03 fmt --all -- --check`
- `rustfmt +nightly-2026-04-03 --edition 2024 --check crates/fe2o3-kfd/src/queue_completion/event_release_tests.rs crates/fe2o3-kfd/src/queue_completion/release_pin_budget_body.rs`
- `python3 -I -B crates/fe2o3-runtime-model/verus/test-completion-release-pin-budget.py`
- `python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-release-pin-budget.py --output /home/harsh/.codex-tmp/fe2o3-batch-pin-release-20260928-vks1y5hZ/campaign --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus`

The final command was repeated with new output `campaign-final` after the
proof-only correction. That complete 17-stage run is accepted; the first is not.
All final CPU/static commands above exited zero. Completion tests pass 19/0;
broad KFD regressions pass 1409/0 with 320 filtered; runtime passes 1828/0 with
30 hardware ignores. Doctests pass 42 + 9 + 44 + 29 = 124. The runtime rustdoc
suite emits separate 9-test and 44-test groups; model adds another 29.

The KFD broad regression command explicitly excludes 320 construction-primary
tests. The preceding source packet has the full KFD result; it is not relabeled
as a full rerun of this source. Runtime hardware tests remain ignored locally.

## Source And Development Scope

The focused-1 run predates macro extraction and the three inconsistent-budget
CPU controls. It is preliminary only. Proof-1 fails at the frontend on prophetic
ghost control flow; proof-2 through proof-4 have logical failures during proof
development; proof-5 is the first positive (8 verified, no errors). None of
these development runs is a signed campaign negative control. The first signed
campaign stopped at reserved-no-debit: the mutant produced a real assertion
failure plus a cast-range recommendation, which the strict classifier rejected.
An explicit positive-capacity assertion before the proof cast removes that
mixed diagnostic; it does not change executable behavior or relax classification.
The failed campaign and all its original source/receipts remain archived.

The six-file source hash bracket opens after the final completion test and just
after broad KFD start. It does not bracket compilation or the preliminary runs.
No production or CPU-test edits occur after the final completion build. The
six-file before/after bracket matches before the subsequent proof-only edit;
source-files-final.sha256 records the latter. The signed campaign
independently snapshots and binds the complete inherited source scope before
and after every owned phase. Calibration runs before that inherited bracket
and is also separately recorded. Test ELFs are hashed but not archived.
Workspace formatting verification was still running during the first campaign's
opening; it was read-only, exited zero, and did not overlap the final campaign.

## Cleanup

A read-only agent verified tracked archive hashes, full file rosters and contents,
absence of open handles, symlinks, special files and foreign-owned entries for:

- /home/harsh/.codex-tmp/fe2o3-native-depth-budget-20260928-UnAv0P2r
- /home/harsh/.codex-tmp/fe2o3-native-async-20260928-UCHLsVEc
- /home/harsh/.codex-tmp/fe2o3-native-isolated-20260928-9iGimvMY

The primary removed only regular files under these exact owned roots, followed
by empty directories, and verified all three roots absent. Archived counterparts
remain tracked; their measured hashes are in cleanup-archive-hashes.sha256.
This reclaimed 535461888 allocated bytes. No MI300X work, remote cleanup, new GPU
execution or HIP/HSA benchmark was performed in this campaign.
