"""Audit generation 07, reusing only byte-identical generation-06 KFD execution."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
REFERENCE_SHA = 'ee19fecf498af003ec79fb7de79755039058500d99c36b1db7dbebd32fed3cf3'
GENERATION = '07'
PROPOSAL = '03'
KFD_EXECUTION_GENERATION = '06'
WITNESS = 'crates/fe2o3-runtime/examples/gfx942-runtime-xgmi-recovery-smoke.rs'
# Exact witness-only correction; all other 6,139 inventoried files are unchanged.
SOURCE_BRIDGE = {
    WITNESS: {
        'old': '5442e3052141fe99822cc08d8a25f753227b081f68a8be1b0e3796dc0dfb9279',
        'new': '304716a75f32da3057ffd13c5c8f2e881598e77316b1298e1e593f44660b92bd',
    },
}
HARDWARE_CONTROLLER_SHA = '1dd02da638edd06124fe84de5d4e83a36b56e7c6ce7a414e50a128d5c0569ff8'
ORACLE_SHA = '97ed7b9eaa2d1caebc3c1d13a731fc47a1c29cde48a2feabb1ec96ce082bc766'


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(RAW / 'audit.py') == REFERENCE_SHA
spec = importlib.util.spec_from_file_location('recovery_reference_audit_06', RAW / 'audit.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
read, instant = legacy.read, legacy.instant
legacy.GENERATION, legacy.PROPOSAL = GENERATION, PROPOSAL
legacy.PINS = {
    **legacy.PINS,
    'audit.py': REFERENCE_SHA,
    'hardware-02/campaign.py': HARDWARE_CONTROLLER_SHA,
    'hardware-02/capture.py': '507ba3f408a423d698ebaf2ff8b9c83b4c33ba97a3bda16734643da298d7f20f',
    'hardware-02/reference/audit.py': '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea',
    'hardware-02/reference/campaign.py': 'd22d7ee70a41a5e588e8c79455c8be7879928e42e59d80225de9cbd832197895',
    'native_oracle_07.py': ORACLE_SHA,
}


class Audit(legacy.Audit):
    def __init__(self):
        assert SOURCE_BRIDGE is not None and HARDWARE_CONTROLLER_SHA is not None
        assert set(SOURCE_BRIDGE) == {WITNESS}
        super().__init__()
        self.current_source = self.source
        self.kfd_source = read(RAW / 'kfd-build-final-06/source-after.json')
        assert set(self.current_source) == set(self.kfd_source)
        actual = {path: {'old': self.kfd_source[path], 'new': digest}
                  for path, digest in self.current_source.items()
                  if self.kfd_source[path] != digest}
        assert actual == SOURCE_BRIDGE
        assert all(set(pair) == {'old', 'new'} and pair['old'] != pair['new']
                   for pair in SOURCE_BRIDGE.values())
        # Only these seven original receipts may use the old full source manifest.
        self.reused_labels = {'kfd-build-final-06', 'kfd-list-final-06'} | {
            'kfd-shard-final-06-' + mode for mode in ('0', '1', '2', '3', 'rest')}

    def receipt(self, label, bound, argv, expected_exit=0):
        if label not in self.reused_labels:
            assert legacy.GENERATION == GENERATION
            return super().receipt(label, bound, argv, expected_exit)
        assert expected_exit == 0
        prior = self.source
        try:
            self.source = self.kfd_source
            row = super().receipt(label, bound, argv, expected_exit)
            self.selected[label]['source_generation'] = KFD_EXECUTION_GENERATION
            self.selected[label]['reused_kfd_evidence'] = True
            return row
        finally:
            self.source = prior

    def ordinary_jobs(self):
        qualify = legacy.module('recovery_qualification_07', RAW / 'qualify.py')
        for stage, count in [('cpu', 19), ('build', 2), ('kfd', 2)]:
            jobs = qualify.jobs(stage)
            assert len(jobs) == count
            expected = []
            for name, bound, argv in jobs:
                label = name + '-final-' + GENERATION
                self.receipt(label, bound, argv)
                expected.append({'label': label, 'exit': 0})
            assert read(RAW / f'qualification-{stage}-{GENERATION}.json') == expected
        old = []
        for name, bound, argv in qualify.jobs('kfd'):
            label = name + '-final-06'
            self.receipt(label, bound, argv)
            old.append({'label': label, 'exit': 0})
        assert read(RAW / 'qualification-kfd-06.json') == old
        for phase in ('before', 'after'):
            self.receipt(f'metadata-final-{phase}-{GENERATION}', '120s',
                         ['python3', '-I', '-B', str(RAW / 'verify_metadata.py'), PROPOSAL])
        self.receipt('source-controls-final-' + GENERATION, '600s',
                     ['python3', '-I', '-B', str(RAW / 'source_controls_final.py'), GENERATION])
        self.receipt('hardware-final-' + GENERATION, '3600s',
                     ['python3', '-I', '-B', str(RAW / 'hardware-02/campaign.py'), 'live', GENERATION])
        self.receipt('audit-native-final-' + GENERATION, '120s',
                     ['python3', '-I', '-B', str(RAW / 'hardware-02/campaign.py'), 'replay', GENERATION])
        self.receipt('api-probe-final-' + GENERATION, '2700s',
                     ['python3', '-I', '-B', str(RAW / 'run_api_probe.py'), GENERATION])

    def shards(self, baseline):
        current_binary, current_identity = self.binary('kfd-build-final-07', 'fe2o3_kfd', True, 'lib')
        old_binary, old_identity = self.binary('kfd-build-final-06', 'fe2o3_kfd', True, 'lib')
        assert current_binary == old_binary and current_identity == old_identity
        assert (RAW / 'kfd-list-final-07/stdout').read_bytes() == (RAW / 'kfd-list-final-06/stdout').read_bytes()
        try:
            legacy.GENERATION = KFD_EXECUTION_GENERATION
            identity, shards = super().shards(baseline)
        finally:
            legacy.GENERATION = GENERATION
        assert identity == current_identity
        last_old = max(instant(self.receipts[label]['finished']) for label in self.reused_labels)
        first_new = min(instant(row['started']) for label, row in self.receipts.items()
                        if label not in self.reused_labels)
        assert last_old <= first_new
        assert set(self.reused_labels) <= set(self.selected)
        return identity, shards

    def native(self):
        folder = RAW / 'hardware-02'
        campaign, audit = read(folder / 'campaign.json'), read(RAW / 'audit-native.json')
        assert audit == campaign and audit['accepted'] is True and audit['errors'] == []
        assert audit['generation'] == GENERATION and audit['expected_cases'] == len(audit['completed']) == 10
        assert audit['owned_cleanup_complete'] is True
        assert audit['performance_acceptance'] is audit['formal_refinement'] is audit['exclusive_reservation'] is False
        assert audit['controller_sha256'] == sha(folder / 'campaign.py')
        assert audit['transport_sha256'] == sha(folder / 'capture.py')
        assert audit['oracle_sha256'] == sha(RAW / 'native_oracle_07.py')
        controller = legacy.module('recovery_native_roster_07', folder / 'campaign.py')
        oracle = legacy.module('recovery_native_oracle_07', RAW / 'native_oracle_07.py')
        prior = legacy.module('recovery_packet_oracle_07', folder / 'reference/campaign.py')
        ids = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33',
               '0x10a254ce4987e716', '0x53691ef168a0147d']
        cases = [(f'{mode}-{kind}-{direction}', 'recovery', ['--' + mode, kind, *uids])
                 for mode in ('no-journal', 'journal') for kind in ('scalar', 'segments')
                 for direction, uids in (('forward', ids), ('reverse', [ids[1], ids[0], ids[3], ids[2]]))]
        cases += [(f'packets-{direction}', 'settled', [*uids, 'packets'])
                  for direction, uids in (('forward', ids[2:]), ('reverse', ids[2:][::-1]))]
        assert controller.CASES == cases and len(cases) == 10
        assert audit['selected_unique_ids'] == ids
        assert audit['selected_cards'] == ['card1', 'card2', 'card6', 'card7']
        assert audit['selected_bdfs'] == ['0000:26:00.0', '0000:46:00.0', '0000:C6:00.0', '0000:E5:00.0']
        for item, (name, kind, args) in zip(audit['completed'], cases, strict=True):
            expected = oracle.expected(args[0], args[1], args[2:]) if kind == 'recovery' else prior.expected(args[-1], args[:2])
            assert item == {'name': name, 'kind': kind, 'arguments': args, 'fields': expected}
        for kind, target in controller.TARGETS.items():
            binary, identity = self.binary(f'build-{kind}-final-{GENERATION}', target, False, 'example')
            item = audit['binaries'][kind]
            assert item['local'] == str(binary) and item['sha256'] == identity['sha256']
            assert item['byte_length'] == identity['byte_length']
        outer = self.receipts['hardware-final-' + GENERATION]
        replay = self.receipts['audit-native-final-' + GENERATION]
        assert instant(outer['finished']) <= instant(replay['started'])
        assert all(instant(self.receipts[f'build-{kind}-final-{GENERATION}']['finished'])
                   <= instant(outer['started']) for kind in controller.TARGETS)
        last = instant(outer['started'])
        assert set(audit['events']) == {path.parent.name for path in folder.glob('*/result.json')}
        for name, event in sorted(audit['events'].items(), key=lambda pair: instant(pair[1]['started'])):
            event_folder = folder / name
            row = read(event_folder / 'result.json')
            assert sha(event_folder / 'result.json') == event['receipt_sha256']
            assert row['argv'] == event['argv']
            assert row['started'] == event['started'] and row['finished'] == event['finished']
            assert row['exit_code'] == 0 and row['timed_out'] is False
            assert row['local_process_group_absent'] is True and row['transport_timeout_seconds'] == 360
            assert 0 <= row['elapsed_seconds'] <= 370
            assert (instant(row['finished']) - instant(row['started'])).total_seconds() <= 370
            assert (event_folder / 'stderr').read_bytes() == b''
            assert last <= instant(event['started']) <= instant(event['finished']) <= instant(outer['finished'])
            last = instant(event['finished'])
            for stream in ('stdout', 'stderr'):
                assert sha(event_folder / stream) == row[stream + '_sha256']
        printed = [json.loads(line) for line in (RAW / f'audit-native-final-{GENERATION}/stdout').read_text().splitlines()
                   if line.startswith('{')]
        assert printed == [{key: value for key, value in audit.items() if key != 'events'}]
        diagnostic = read(RAW / 'hardware-01/campaign.json')
        assert diagnostic['accepted'] is False and diagnostic['errors']
        assert diagnostic['generation'] == '06' and diagnostic['owned_cleanup_complete'] is True
        assert len(diagnostic['completed']) == 4
        return audit


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1
    started = datetime.now(timezone.utc).isoformat()
    audit = Audit()
    baseline, lower = legacy.archive(legacy.BASELINE), legacy.archive(legacy.KFD_BASELINE)
    assert json.loads(legacy.archived(baseline, 'audit-result.json'))['accepted'] is True
    assert json.loads(legacy.archived(lower, 'audit-final.json'))['accepted'] is True
    audit.ordinary_jobs()
    counts = audit.tests(baseline, lower)
    kfd, shards = audit.shards(lower)
    audit.metadata(baseline)
    audit.controls()
    audit.api()
    native = audit.native()
    assert audit.capture.snapshot() == audit.current_source
    diagnostics = {}
    for path in RAW.glob('*/receipt.json'):
        if path.parent.name not in audit.selected:
            receipt = read(path)
            diagnostics[path.parent.name] = dict(receipt_sha256=sha(path),
                exit=receipt['exit'], source_unchanged=receipt['source_unchanged'], selected=False)
    result = dict(accepted=True, started=started, finished=datetime.now(timezone.utc).isoformat(),
        base=legacy.BASE, generation=GENERATION, auditor_sha256=sha(Path(__file__)),
        reference_auditor_sha256=REFERENCE_SHA, controller_pins=legacy.PINS,
        source_files=len(audit.current_source), source_sha256=audit.current_source, counts=counts,
        doctests={'kfd': 53, 'runtime': 61}, kfd_tests=1950,
        kfd_fresh=False, kfd_fresh_build=True, kfd_reused=True,
        kfd_execution_generation=KFD_EXECUTION_GENERATION, kfd_source_bridge=SOURCE_BRIDGE,
        kfd_source_manifest_sha256=sha(RAW / 'kfd-build-final-06/source-after.json'),
        kfd_executable=kfd, kfd_shard_receipt_sha256=shards,
        source_controls=32, metadata_files=13, metadata_literals=28,
        unchanged_proof_files=76, metadata_report_sha256=sha(RAW / ('proposal-' + PROPOSAL) / 'metadata-report.json'),
        selected_receipts=audit.selected, native_cases=10, native_recovery_cases=8,
        native_packet_controls=2, native_events=len(native['events']),
        native_audit_sha256=sha(RAW / 'audit-native.json'), owned_cleanup_complete=True,
        diagnostic_native_01_sha256=sha(RAW / 'hardware-01/campaign.json'),
        api_probe_sha256=sha(RAW / f'api-probe-run-{GENERATION}/result.json'),
        baseline_archive_sha256=legacy.BASELINE[1], kfd_roster_baseline_archive_sha256=legacy.KFD_BASELINE[1],
        nonselected_receipts=diagnostics,
        fresh_solver_execution=False, recovery_refinement_proved=False,
        performance_acceptance=False, exclusive_reservation=False,
        fault_scope='actual pre-arm host capacity denial; not OOM, GPU or driver fault')
    with (RAW / 'audit-final.json').open('x') as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'source_sha256'}, sort_keys=True))


if __name__ == '__main__':
    main()
