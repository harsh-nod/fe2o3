"""Replay the unchanged literal-only verifier at this candidate proposal."""
import hashlib
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
source = RAW / 'reference/verify-applied.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243'
scope = {'__file__': str(RAW / ('proposal-' + sys.argv[1]) / 'verify-applied.py'), '__name__': '__main__'}
exec(compile(data, str(source), 'exec'), scope)
