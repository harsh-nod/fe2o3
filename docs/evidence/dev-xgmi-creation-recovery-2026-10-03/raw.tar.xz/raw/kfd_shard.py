"""Run the accepted exact-roster shard controller on the freshly built candidate."""
import hashlib
from pathlib import Path
import sys
import types

RAW = Path(__file__).resolve().parent
source = RAW / 'reference/kfd_shard_final.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'f6262d5575843228388e3909a4718cc6946390e3332bf63ae1f0ef5e9d34d01b'
module = types.ModuleType('exact_kfd_shards')
module.__file__ = str(source)
text = data.decode().replace('kfd-build-final-02', 'kfd-build-final-06')
text = text.replace('kfd-list-final-02', 'kfd-list-final-06').replace('kfd-shard-02-', 'kfd-shard-06-')
exec(compile(text, str(source), 'exec'), module.__dict__)
module.ROOT = RAW
module.BASE = '009e06610d0f45e81ff8b1306886ff534c6671f9'
sys.exit(module.main())
