"""Independent byte oracle and exact receipt schema for four-device recovery."""
import hashlib
import struct


def expected(mode, shape, ids):
    assert mode in ('--journal', '--no-journal') and shape in ('scalar', 'segments')
    assert len(ids) == len(set(ids)) == 4 and all(int(uid, 16) > 0 for uid in ids)
    journal = mode == '--journal'
    source_size, destination_size = 65633, 65857
    descriptors = ([(0, 0, 32769)] if shape == 'scalar' else
                   [(0, 0, 128), (128, 64, 128), (0, 0, 128), (512, 96, 68)])
    source_length, destination_length = ((32769, 32769) if shape == 'scalar' else (32768, 49152))
    mask = (1 << 64) - 1
    parts = []
    for pair, round_number, sentinel in ((0, 1, 0xa5), (1, 0, 0x6c)):
        source = bytearray()
        for index in range(source_size):
            value = (index + 0x9e3779b97f4a7c15) & mask
            value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
            value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
            value ^= value >> 31
            source.append((value & 255) ^ ((pair * 53) & 255) ^ ((round_number * 73) & 255))
        destination = bytearray([sentinel]) * destination_size
        for source_offset, destination_offset, length in descriptors:
            assert source_offset + length <= source_length
            assert destination_offset + length <= destination_length
            destination[53 + destination_offset:53 + destination_offset + length] = \
                source[17 + source_offset:17 + source_offset + length]
        parts.extend((source, destination))
    digest = hashlib.sha256(b'fe2o3.native-xgmi-recovery.full-bytes.v1\0')
    for part in parts:
        digest.update(struct.pack('<Q', len(part)))
        digest.update(part)
    return dict(schema='fe2o3.native-xgmi-recovery.v1', authority='production-deny-all',
        transport='NATIVE-XGMI', devices='4', unique_ids=','.join(ids), mode=mode[2:], shape=shape,
        source_bytes=str(source_size), destination_bytes=str(destination_size),
        source_offset='17', destination_offset='53', descriptors=str(len(descriptors)),
        copied_bytes=str(sum(length for _, _, length in descriptors)),
        source_envelope=str(source_length), destination_envelope=str(destination_length),
        kernels='0', modules='0', contexts='1', attempts='3', injected_failures='1',
        successful_peers='2', completion_receipts='3', native_counter='0,1,2',
        b_publication='retained1-completed0-exact-only-root',
        a_failure='certified-host-preparation-capacity-before-native-arm',
        a_owners='certified-originals-restored', b_during_a_failure='pending-retained-unarmed',
        terminal='false', rearm='rejected', source_retry='changed-full-payload-same-allocation',
        destination_retry=('disposed-and-fresh-initialized-allocation' if journal else 'same-original-allocation'),
        failed_destination_bytes='full-byte-unchanged',
        journal_unknown_read=('rejected-before-effect' if journal else 'not-applicable'),
        journal_unknown_retry=('rejected-before-effect' if journal else 'not-applicable'),
        source_preservation='full-byte-pass', output='full-byte-pass', guards='full-byte-pass',
        digest='domain-and-u64le-length-prefixed-A-source-A-destination-B-source-B-destination',
        sha256=digest.hexdigest(),
        descriptor_snapshot=('caller-overwritten-after-admission' if shape == 'segments' else 'not-applicable'),
        callbacks='exact-once-per-original-submission', events='none', drain='completed-only',
        cleanup='logical-and-native-explicit', gpu_fault_injected='false',
        physical_overlap='unmeasured', performance_acceptance='false', formal_refinement='false')
