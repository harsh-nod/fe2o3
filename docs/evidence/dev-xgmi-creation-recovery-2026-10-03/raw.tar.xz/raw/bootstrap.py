"""Extract byte-identical accepted qualification helpers, never old results."""
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '009e06610d0f45e81ff8b1306886ff534c6671f9'
ARCHIVE = 'docs/evidence/dev-settled-peer-frames-2026-10-02/raw.tar.xz'
SHA = 'f144a06833528cd3953d38289c4d635b8f0ce7b61d03ac330407dc8e83b1cad4'
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
blob = subprocess.check_output(['git', 'show', BASE + ':' + ARCHIVE], cwd=REPO)
assert hashlib.sha256(blob).hexdigest() == SHA
references = {
    'capture.py': 'capture.py',
    'source_controls_baseline.py': 'source_controls_baseline.py',
    'source_controls_final.py': 'source_controls_final.py',
    'reference/propose.py': 'proposal-03/reference/propose.py',
    'reference/verify-applied.py': 'proposal-03/reference/verify-applied.py',
    'hardware-01/reference/campaign.py': 'hardware-01/reference/campaign.py',
    'hardware-01/reference/audit.py': 'hardware-01/reference/audit.py',
    'hardware-01/capture.py': 'hardware-01/capture.py',
}
with tarfile.open(fileobj=io.BytesIO(blob), mode='r:xz') as archive:
    for destination, member_name in references.items():
        member = archive.getmember('raw/' + member_name)
        assert member.isfile()
        data = archive.extractfile(member).read()
        path = RAW / destination
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            assert path.is_file() and not path.is_symlink() and path.read_bytes() == data
        else:
            with path.open('xb') as output:
                output.write(data)
        print(destination, hashlib.sha256(data).hexdigest())
