"""Closed identity refresh for unrelated XGMI creation edits, not a new proof."""
import ast
import difflib
from pathlib import Path

GUARD = 'check-retained-pair-cadence.py'
GUARD_SHA = 'db05615ebfe77f11823830ada47009c37f849ac6e09e40184711288831f0bcd5'
BLOCK_HELPER = 'check-producer-input-validate.py'
BLOCK_HELPER_SHA = '9471532847388e97750dcab25e7df795471aef8cfea538ddb08d670ab684ce82'
SRC = Path('crates/fe2o3-kfd/src')
APPROVED = {
    SRC / 'lib.rs': (
        '05f29da3e49e9354a8380419fd8a40129d4c6ad4158ed1927e1dda2a9d144cc6',
        '507c8a7ac5bdee14da36e5d825e4c1934404acbd37eddc68954c575d45d668f2'),
    SRC / 'sdma.rs': (
        '98e9784aeb3f1a93d51a844ca14085caf6bd9999a629d6c297e2a93a074fd10a',
        'b9fbeb93aa28a11e6bc81ad0d94ff396a459fb65613d281039774dab70c3e7b9'),
}
METHODS = (
    '    fn wait_many_xgmi_with_timer<const DIAGNOSTIC: bool>(',
    '    fn wait_batch_with_timer<const DIAGNOSTIC: bool>(',
    '    fn wait_for_with_currentness(',
)
OWNER = Path('crates/fe2o3-runtime/src/context/versions/producer_readers.rs')
OWNER_SHA = '14e371b7edc10ff97e675dd3e954ef17bf9dea6e6ee7b521298b9adc0d8faac7'


def rebind(module, name, old, candidate, baseline, edits):
    need, sha = module.need, module.sha
    need(name == GUARD, 'only the reviewed cadence source-pin exception')
    need(sha(edits.source.encode()) == GUARD_SHA, 'exact accepted cadence guard')
    need(set(candidate) == set(baseline) == set(old.PINS), 'unchanged cadence source roster')
    helper_path = module.V / BLOCK_HELPER
    helper_source = (module.ROOT / helper_path).read_text()
    need(sha(helper_source.encode()) == BLOCK_HELPER_SHA and
         helper_source == module.blobs([helper_path])[helper_path],
         'unchanged accepted balanced-block helper')
    helper = module.load(BLOCK_HELPER, helper_source)
    owner = (module.ROOT / OWNER).read_bytes()
    need(sha(owner) == OWNER_SHA and owner.decode() == module.blobs([OWNER])[OWNER],
         'producer reader owner and all observer methods remain byte-identical')
    for path, pin in old.PINS.items():
        need(sha(baseline[path].encode()) == pin, 'original accepted source pin')
        if path in APPROVED:
            before, after = APPROVED[path]
            need(pin == before and sha(candidate[path].encode()) == after,
                 'fixed reviewed preimage and postimage: ' + str(path))
        else:
            need(candidate[path] == baseline[path] and sha(candidate[path].encode()) == pin,
                 'every other selector/cadence source remains exact: ' + str(path))

    export = '    Gfx942ComputeXgmiQueueCreationDispositionV1, Gfx942ComputeXgmiQueueCreationOutcomeV1,\n'
    library = candidate[SRC / 'lib.rs']
    need(library.count(export) == 1 and library.replace(export, '', 1) == baseline[SRC / 'lib.rs'],
         'lib.rs contains only the two additive outcome exports')
    spans = {}
    for anchor in METHODS:
        complete = []
        for sources in (baseline, candidate):
            source = sources[SRC / 'sdma.rs']
            body = helper.block(source, anchor)
            start = source.index(anchor)
            brace = source.index('{', start)
            complete.append(source[start:brace] + body)
        need(complete[0] == complete[1], 'unchanged cadence signature and complete body: ' + anchor)
        spans[anchor.strip()] = sha(complete[0].encode())

    dictionaries = [node.value for node in edits.tree.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == 'PINS'
                            for target in node.targets)]
    need(len(dictionaries) == 1 and isinstance(dictionaries[0], ast.Dict), 'exact source-pin dictionary')
    for path, (_, after) in APPROVED.items():
        matches = [value for key, value in zip(dictionaries[0].keys, dictionaries[0].values)
                   if isinstance(key, ast.BinOp) and isinstance(key.op, ast.Div)
                   and isinstance(key.left, ast.Name) and key.left.id == 'SRC'
                   and isinstance(key.right, ast.Constant) and key.right.value == path.name]
        need(len(matches) == 1, 'one literal pin for exact approved source path')
        edits.constant(matches[0], after, 'content-sha256', f'PINS[SRC / {path.name!r}]',
                       'reviewed unrelated creation API changes; complete cadence methods and selector closure unchanged')

    diff = ''.join(difflib.unified_diff(baseline[SRC / 'sdma.rs'].splitlines(True),
                                      candidate[SRC / 'sdma.rs'].splitlines(True),
                                      fromfile='accepted/sdma.rs', tofile='candidate/sdma.rs'))
    (module.OUT / 'reviewed-sdma-creation.patch').write_text(diff)
    return dict(guard=GUARD, guard_original_sha256=GUARD_SHA,
                approved_source_pins={str(path): dict(before=before, after=after)
                                      for path, (before, after) in APPROVED.items()},
                structured_block_helper_sha256=BLOCK_HELPER_SHA,
                unchanged_cadence_signature_and_body_sha256=spans,
                unchanged_other_source_pins={str(path): pin for path, pin in old.PINS.items()
                                             if path not in APPROVED},
                unchanged_producer_readers_sha256=OWNER_SHA,
                substantive_creation_changes=True,
                creation_changes='typed private host-preparation marker, explicit one-attempt mode, additive creation forwarding, false marker fixtures',
                sdma_diff_sha256=sha(diff.encode()),
                metadata_nodes_only=True, solver_executed=False,
                fresh_formal_qualification=False, recovery_refinement_proved=False,
                packet_window_whole_source_reuse=False)
