"""Run fresh source-bound recovery qualification in independently schedulable stages."""
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
C = ['--locked', '--offline']
R = [*C, '-p', 'fe2o3-runtime']
K = [*C, '-p', 'fe2o3-kfd']
W = [*R, '--no-default-features', '--features', 'hardware-qualification']
TARGETS = {'recovery': 'gfx942-runtime-xgmi-recovery-smoke',
           'settled': 'gfx942-runtime-unified-segments-smoke',
           'deferred': 'gfx942-runtime-deferred-peer-chain-smoke'}


def jobs(stage):
    if stage == 'build':
        return [(f'build-{name}', '900s', ['cargo', 'build', *W, '--example', target,
                 '--profile', 'test', '--message-format=json'])
                for name, target in TARGETS.items() if name != 'deferred']
    if stage == 'kfd':
        return [
            ('kfd-build', '900s', ['cargo', 'test', *K, '--all-features', '--lib', '--no-run', '--message-format=json']),
            ('kfd-list', '120s', ['cargo', 'test', *K, '--all-features', '--lib', '--', '--list']),
        ]
    assert stage == 'cpu'
    changed = subprocess.check_output(['git', 'diff', 'HEAD', '--name-only', '--diff-filter=ACMR'], cwd=REPO, text=True).splitlines()
    new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
    rust = sorted(name for name in set(changed + new) if name.startswith('crates/') and name.endswith('.rs'))
    result = [
        ('format', '120s', ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *rust]),
        ('whitespace', '60s', ['git', 'diff', '--check']),
        ('clippy-kfd', '900s', ['cargo', 'clippy', *K, '--all-features', '--lib', '--tests', '--', '-D', 'warnings']),
        ('clippy-runtime', '900s', ['cargo', 'clippy', *R, '--all-features', '--lib', '--tests', '--', '-D', 'warnings']),
        ('runtime-tests', '900s', ['cargo', 'test', *R, '--all-features', '--lib']),
        ('runtime-list', '120s', ['cargo', 'test', *R, '--all-features', '--lib', '--', '--list']),
        ('doctests', '900s', ['cargo', 'test', *C, '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--doc']),
        ('check-no-default', '900s', ['cargo', 'check', *C, '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--no-default-features', '--lib']),
        ('check-default', '900s', ['cargo', 'check', *C, '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--lib']),
        ('features-no-default', '120s', ['cargo', 'tree', *R, '--no-default-features', '-e', 'features']),
    ]
    for name, target in TARGETS.items():
        witness = [*W, '--example', target]
        result.extend([
            ('clippy-' + name, '900s', ['cargo', 'clippy', *witness, '--', '-D', 'warnings']),
            (name + '-tests', '900s', ['cargo', 'test', *witness]),
            (name + '-list', '120s', ['cargo', 'test', *witness, '--', '--list']),
        ])
    return result


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and sys.argv[1] in ('build', 'cpu', 'kfd') and sys.argv[2].isdigit()
    stage, generation = sys.argv[1:]
    results = []
    for name, bound, command in jobs(stage):
        label = name + '-final-' + generation
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'), label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    with (RAW / ('qualification-' + stage + '-' + generation + '.json')).open('x') as output:
        json.dump(results, output, indent=2)
        output.write('\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
