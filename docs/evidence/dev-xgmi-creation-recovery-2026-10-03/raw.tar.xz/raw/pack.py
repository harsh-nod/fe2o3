"""Seal accepted generation-06 receipts and staged source without executable files."""
import hashlib
import importlib.util
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
DEST = REPO / 'docs/evidence/dev-xgmi-creation-recovery-2026-10-03'
BASE = '009e06610d0f45e81ff8b1306886ff534c6671f9'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1
    accepted = json.loads((RAW / 'audit-final.json').read_text())
    assert accepted['accepted'] is True
    assert accepted['base'] == BASE and accepted['generation'] == '06'
    assert accepted['auditor_sha256'] == sha(RAW / 'audit.py')
    for name, digest in accepted['controller_pins'].items():
        assert sha(RAW / name) == digest, name
    assert accepted['counts'] == {
        'runtime': {'passed': 2276, 'ignored': 32},
        'recovery': {'passed': 7, 'ignored': 0},
        'deferred': {'passed': 20, 'ignored': 0},
        'settled': {'passed': 3, 'ignored': 0},
    }
    assert accepted['doctests'] == {'kfd': 53, 'runtime': 61}
    assert accepted['kfd_tests'] == 1950 and accepted['kfd_fresh'] is True
    assert accepted['source_controls'] == 32
    assert accepted['metadata_files'] == 13 and accepted['metadata_literals'] == 28
    assert accepted['unchanged_proof_files'] == 76
    assert accepted['metadata_report_sha256'] == sha(RAW / 'proposal-03/metadata-report.json')
    assert accepted['native_cases'] == 10 and accepted['native_recovery_cases'] == 8
    assert accepted['native_packet_controls'] == 2 and accepted['owned_cleanup_complete'] is True
    for key in ('fresh_solver_execution', 'recovery_refinement_proved',
                'performance_acceptance', 'exclusive_reservation'):
        assert accepted[key] is False
    assert accepted['native_audit_sha256'] == sha(RAW / 'audit-native.json')
    native = json.loads((RAW / 'audit-native.json').read_text())
    assert native['accepted'] is True and native['errors'] == []
    assert native['generation'] == '06' and len(native['completed']) == 10
    assert native['owned_cleanup_complete'] is True
    assert accepted['api_probe_sha256'] == sha(RAW / 'api-probe-run-06/result.json')
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                   text=True).strip() == BASE
    assert sha(RAW / 'capture.py') == \
        '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
    spec = importlib.util.spec_from_file_location('recovery_package_capture', RAW / 'capture.py')
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    assert capture.snapshot() == accepted['source_sha256']
    assert (DEST / 'README.md').is_file()
    staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=REPO)
    assert staged and not any(name.startswith(b'docs/evidence/') for name in staged.split(b'\0'))
    patch = subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=REPO)
    with (RAW / 'candidate.patch').open('xb') as output:
        output.write(patch)
    rows = {}
    with (DEST / 'raw.tar.xz').open('xb') as archive:
        with lzma.LZMAFile(archive, mode='w', preset=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as output:
                for path in sorted(RAW.rglob('*')):
                    assert not path.is_symlink(), path
                    if path.is_dir():
                        continue
                    assert path.is_file(), path
                    data = path.read_bytes()
                    assert not data.startswith(b'\x7fELF'), path
                    name = path.relative_to(RAW).as_posix()
                    rows[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
                    info = tarfile.TarInfo('raw/' + name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    output.addfile(info, io.BytesIO(data))
    with (DEST / 'raw-manifest.json').open('x') as output:
        json.dump(rows, output, indent=2, sort_keys=True)
        output.write('\n')
    for name, row in rows.items():
        data = (RAW / name).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert sorted(rows) == sorted(path.relative_to(RAW).as_posix()
                                  for path in RAW.rglob('*') if path.is_file())
    with tarfile.open(DEST / 'raw.tar.xz', 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert {member.name for member in members} == {'raw/' + name for name in rows}
        for member in members:
            assert member.isfile()
            row = rows[member.name.removeprefix('raw/')]
            data = archive.extractfile(member).read()
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    with (DEST / 'SHA256SUMS').open('x') as output:
        for name in ('README.md', 'raw-manifest.json', 'raw.tar.xz'):
            output.write(sha(DEST / name) + '  ' + name + '\n')
    print(json.dumps(dict(files=len(rows),
                         uncompressed_bytes=sum(row['bytes'] for row in rows.values()),
                         archive_bytes=(DEST / 'raw.tar.xz').stat().st_size), sort_keys=True))


if __name__ == '__main__':
    main()
