"""Use the accepted proposer with one closed, reviewed cadence-pin exception."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import types

RAW = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
source = RAW / 'reference/propose.py'
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() == '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50'
before = """        elif hasattr(old, 'PINS'):
            need(all(sha(candidate[path].encode()) == digest for path, digest in old.PINS.items()),
                 'unaffected cadence source pins remain exact')
"""
after = """        elif hasattr(old, 'PINS'):
            recovery_cadence_rebind(name, old, candidate, baseline, edits)
"""
text = original.decode()
assert text.count(before) == 1
adapted = text.replace(before, after, 1)
spec = importlib.util.spec_from_file_location('recovery_cadence', RAW / 'cadence_rebind.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
module = types.ModuleType('strict_metadata')
module.__file__ = str(source)
exec(compile(adapted, str(source), 'exec'), module.__dict__)
module.BASE = '009e06610d0f45e81ff8b1306886ff534c6671f9'
module.OUT = RAW / ('proposal-' + sys.argv[1])
module.OUT.mkdir(mode=0o700)
review = []


def rebind(name, old, candidate, baseline, edits):
    assert not review
    review.append(helper.rebind(module, name, old, candidate, baseline, edits))


module.recovery_cadence_rebind = rebind
(module.OUT / 'adapted-proposer.py').write_text(adapted)
module.main()
assert len(review) == 1
review[0].update(reference_proposer_sha256=hashlib.sha256(original).hexdigest(),
                 adapted_proposer_sha256=hashlib.sha256(adapted.encode()).hexdigest(),
                 wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 helper_sha256=hashlib.sha256((RAW / 'cadence_rebind.py').read_bytes()).hexdigest())
(module.OUT / 'cadence-rebind-review.json').write_text(json.dumps(review[0], indent=2, sort_keys=True) + '\n')
