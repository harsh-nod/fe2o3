"""Execute all five exact-roster shards with four bounded CPU workers."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert len(sys.argv) == 1


def run(mode):
    label = 'kfd-shard-final-06-' + mode
    command = [sys.executable, '-I', '-B', str(RAW / 'capture.py'), label, '1320s',
               'python3', '-I', '-B', str(RAW / 'kfd_shard.py'), mode]
    result = subprocess.run(command, check=False)
    return dict(mode=mode, label=label, exit=result.returncode)


with ThreadPoolExecutor(max_workers=4) as workers:
    results = list(workers.map(run, ('0', '1', '2', '3', 'rest')))
with (RAW / 'kfd-suite-06.json').open('x') as output:
    json.dump(results, output, indent=2)
    output.write('\n')
sys.exit(0 if all(row['exit'] == 0 for row in results) else 1)
