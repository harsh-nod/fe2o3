//! Compile-only feature-surface probe. No runtime or native operation is executed.

use fe2o3_kfd::{ComputeAqlQueueSessionV1, Gfx942ComputeXgmiQueueCreationRootV1};
use fe2o3_kfd::topology::Gfx942XgmiRouteV1;
use fe2o3_runtime::{
    KfdMultiDeviceRuntimeBackendV1, RuntimeContextV1, RuntimePeerCopyV1, RuntimeSubmissionV1,
};

pub fn context_surface(
    context: &mut RuntimeContextV1<KfdMultiDeviceRuntimeBackendV1>,
    submission: &RuntimeSubmissionV1<RuntimePeerCopyV1>,
) {
    let _ = context.reject_native_xgmi_host_preparation_once_for_qualification_v1(submission);
    let _ = context.native_xgmi_host_preparation_rejected_for_qualification_v1(submission);
}

pub fn lower_surface(
    source: &mut ComputeAqlQueueSessionV1,
    destination: &mut ComputeAqlQueueSessionV1,
    route: Gfx942XgmiRouteV1,
    root: &mut Gfx942ComputeXgmiQueueCreationRootV1,
) {
    let _ = source.create_native_xgmi_queue_with_peer_host_preparation_denial_v1(destination, route, root);
}
