"""Offline closure of the fresh source-bound recovery checkpoint. No test execution."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile
import types

import yaml

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '009e06610d0f45e81ff8b1306886ff534c6671f9'
GENERATION = None
PROPOSAL = None
CAPTURE = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
# Reviewed frozen controllers; all commands still require matching source receipts.
PINS = {
    'qualify.py': '45cafca7a8348dede7f2276d0c486755423f25d0625e6493feddcd668f028af2',
    'kfd_shard.py': '6979ac7fd64cd012cebfef7d391ecfc22faa6dc26a864488781ad6dbd1067c75',
    'run_kfd_suite.py': 'e10e37b0119070fb9e51968265337685c4d0647009799b44beba7a16f13aaa1a',
    'propose_metadata.py': 'e7d72762a85d831a9a97977f2b506275667910d7c486812fc7409a7dea3591e3',
    'cadence_rebind.py': '6fbb486f82fd7f333b1168416ea791cc557dd5e8b5c1c56720cbb709604af5fa',
    'verify_metadata.py': '47ffb2385d95f1e21caecb1f42dff2f6287465f00a835a3a5838431e5977ae21',
    'source_controls_baseline.py': 'fb5b67b44ad85fd21792a2fe18f9bac60897033c8a37a51ea2fa5c04e0277a5c',
    'source_controls_final.py': '57b0d19228fd95ee5001b5d82759588277df1ea3c1c1d128f54573ee1a835112',
    'run_api_probe.py': 'd9af66d70db8aefbe0c4a3a6c87eb19b3a0323d9bcdf423dec8dc6c6566b25a4',
    'native_oracle.py': '61309dda8c3d36df90686098bef5ab725a39cc28eed2fa442e79615ffbfe537d',
    'reference/kfd_shard_final.py': 'f6262d5575843228388e3909a4718cc6946390e3332bf63ae1f0ef5e9d34d01b',
    'reference/propose.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    'reference/verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
    'hardware-01/campaign.py': '0ff338d573582e1470d7c3452089a34b761fbdce0e8810c968a510ff406d7c5b',
    'hardware-01/capture.py': '507ba3f408a423d698ebaf2ff8b9c83b4c33ba97a3bda16734643da298d7f20f',
    'hardware-01/reference/audit.py': '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea',
    'hardware-01/reference/campaign.py': 'd22d7ee70a41a5e588e8c79455c8be7879928e42e59d80225de9cbd832197895',
    'api-probe/Cargo.toml': 'e050e5b131ad6ab1fe1c69a3586e0c6c794d1c5aa10b7212cb94bda5865b214a',
    'api-probe/src/lib.rs': '6f81724c759cfa5a95d858b23ce0e334269377ca08035b7457119d8659c57e1a',
}
BASELINE = ('docs/evidence/dev-settled-peer-frames-2026-10-02/raw.tar.xz',
            'f144a06833528cd3953d38289c4d635b8f0ce7b61d03ac330407dc8e83b1cad4')
KFD_BASELINE = ('docs/evidence/dev-unified-peer-segments-2026-10-02/raw.tar.xz',
                '6964c627cc0794258fa40ee625bed3dd6cd6f8b30a4825f67aaec9c6c209d184')
NEW_CONTEXT = '''qualification_xgmi_context_rejects_nonnative_without_progress_or_journal_change
qualification_xgmi_context_authenticates_handle_and_reservation_before_backend
qualification_xgmi_context_requires_live_stream_and_exact_operation_custody'''.splitlines()
NEW_BACKEND = '''qualification_denial_rejects_scripted_missing_and_wrong_submissions_without_progress
qualification_denial_cannot_certify_scripted_rejection_or_unused_cancel_request
no_effect_creation_restores_metadata_refunds_retains_and_allows_fresh_retry
no_effect_creation_does_not_poison_published_disjoint_pair_or_quantum
cancellation_before_creation_never_consumes_the_host_rejection_or_changes_bytes
no_effect_recovery_validates_both_outputs_before_restoring_either
unclassified_creation_and_postpublication_faults_keep_fail_stop_custody'''.splitlines()
NEW_KFD_PAIR = '''compute_xgmi_host_rejection_certification_follows_both_model_retakes
compute_xgmi_vacancy_and_retryable_diagnostics_do_not_certify_no_effect
compute_xgmi_additive_outcome_rejects_missing_live_engine_and_occupied_root
compute_xgmi_consuming_classification_preserves_only_its_enclosed_error
qualified_capacity_denial_cannot_bypass_creation_endpoint_preflight'''.splitlines()
NEW_KFD_NATIVE = '''actual_fallible_host_preparation_is_one_shot_and_not_an_arm_failure
explicit_capacity_denial_never_arms_and_does_not_change_the_next_attempt'''.splitlines()
NEW_EXAMPLE = '''exact_cli_accepts_four_modes_and_preserves_uid_order
invalid_cli_rosters_and_flags_are_rejected
changed_sources_have_full_extent_and_every_byte_changes
ordered_descriptor_oracle_preserves_holes_and_observes_overlap_order
scalar_oracle_checks_both_sentinels_and_exact_tail
length_framed_digest_distinguishes_order_lengths_and_full_guards
reports_distinguish_unknown_destination_from_observed_unchanged_bytes'''.splitlines()


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return sha_bytes(path.read_bytes())


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            assert key not in result, ('duplicate JSON key', key)
            result[key] = value
        return result
    return json.loads(path.read_bytes(), object_pairs_hook=unique)


def instant(text):
    result = datetime.fromisoformat(text)
    assert result.tzinfo is not None
    return result


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def baseline_blob(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=REPO)


def archive(identity):
    data = baseline_blob(identity[0])
    assert sha_bytes(data) == identity[1]
    result = tarfile.open(fileobj=io.BytesIO(data), mode='r:xz')
    names = [member.name for member in result.getmembers()]
    assert len(names) == len(set(names))
    return result


def archived(archive, name):
    member = archive.getmember('raw/' + name)
    assert member.isfile() and not member.issym()
    return archive.extractfile(member).read()


def roster(text):
    names = re.findall(r'^(\S+): test$', text, re.M)
    assert names and len(names) == len(set(names))
    assert re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', text, re.M) == [(str(len(names)), '0')]
    assert all(not line or re.fullmatch(r'\S+: test|\d+ tests?, \d+ benchmarks?', line)
               for line in text.splitlines())
    return sorted(names)


def outcomes(text, expected, passed, ignored):
    # Exactly these two preexisting abort tests emit repeated child headers.
    # Require their complete known block, never discard arbitrary non-ok rows.
    for name, count in {
        'kfd_backend::tests::runtime_compute_pipeline_drop_aborts_for_every_live_logical_phase': 5,
        'kfd_backend::tests::scripted_sdma_drop_still_aborts_with_live_or_terminal_custody': 2,
    }.items():
        if name in expected:
            prefix = f'test {name} ... \nrunning 1 test\n'
            block = prefix * count + f'test {name} ... ok'
            assert text.count(block) == 1
            text = text.replace(block, f'test {name} ... ok', 1)
    rows = re.findall(r'^test (\S+) \.\.\. (ok|ignored(?:, [^\n]*)?)$', text, re.M)
    assert Counter(name for name, _ in rows) == Counter(expected)
    assert sum(status == 'ok' for _, status in rows) == passed
    assert sum(status.startswith('ignored') for _, status in rows) == ignored
    summaries = [line for line in text.splitlines() if line.startswith('test result:')]
    assert len(summaries) == 1 and summaries[0].startswith(
        f'test result: ok. {passed} passed; 0 failed; {ignored} ignored; 0 measured; 0 filtered out;')
    # Do not silently ignore malformed, failed, or extra test outcomes.
    assert len([line for line in text.splitlines()
                if line.startswith('test ') and not line.startswith('test result:')]) == len(rows)
    return sorted(name for name, status in rows if status.startswith('ignored'))


class Audit:
    def __init__(self):
        assert PINS is not None, 'controllers not frozen'
        assert sha(RAW / 'capture.py') == CAPTURE
        for name, digest in PINS.items():
            assert sha(RAW / name) == digest, name
        self.capture = module('recovery_capture', RAW / 'capture.py')
        self.source = self.capture.snapshot()
        assert all(sha(REPO / name) == digest for name, digest in self.source.items())
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                       text=True).strip() == BASE
        self.selected = {}
        self.receipts = {}

    def receipt(self, label, bound, argv, expected_exit=0):
        folder = RAW / label
        row, command = read(folder / 'receipt.json'), read(folder / 'command.json')
        assert all(row[key] == value for key, value in command.items()), label
        assert row['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', bound, *argv], label
        assert row['exit'] == expected_exit and row['source_unchanged'] is True, label
        assert row['base'] == BASE and row['cwd'] == str(REPO), label
        assert row['controller_sha256'] == CAPTURE and row['environment'] == self.capture.ENV, label
        assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == self.source, label
        assert instant(row['started']) <= instant(row['finished']), label
        for output in ('stdout', 'stderr'):
            assert sha(folder / output) == row[output + '_sha256'], label
        self.selected[label] = {'receipt_sha256': sha(folder / 'receipt.json')}
        self.receipts[label] = row
        return row

    def ordinary_jobs(self):
        qualify = module('recovery_qualification', RAW / 'qualify.py')
        for stage, count in [('cpu', 19), ('build', 2), ('kfd', 2)]:
            jobs = qualify.jobs(stage)
            assert len(jobs) == count
            expected = []
            for name, bound, argv in jobs:
                label = name + '-final-' + GENERATION
                self.receipt(label, bound, argv)
                expected.append({'label': label, 'exit': 0})
            assert read(RAW / f'qualification-{stage}-{GENERATION}.json') == expected
        for phase in ('before', 'after'):
            self.receipt(f'metadata-final-{phase}-{GENERATION}', '120s',
                         ['python3', '-I', '-B', str(RAW / 'verify_metadata.py'), PROPOSAL])
        self.receipt('source-controls-final-' + GENERATION, '600s',
                     ['python3', '-I', '-B', str(RAW / 'source_controls_final.py'), GENERATION])
        self.receipt('hardware-final-' + GENERATION, '3600s',
                     ['python3', '-I', '-B', str(RAW / 'hardware-01/campaign.py'), 'live', GENERATION])
        self.receipt('audit-native-final-' + GENERATION, '120s',
                     ['python3', '-I', '-B', str(RAW / 'hardware-01/campaign.py'), 'replay', GENERATION])
        self.receipt('api-probe-final-' + GENERATION, '2700s',
                     ['python3', '-I', '-B', str(RAW / 'run_api_probe.py'), GENERATION])

    def tests(self, baseline, lower):
        counts = {'runtime': (2276, 32), 'recovery': (7, 0), 'deferred': (20, 0), 'settled': (3, 0)}
        rosters = {}
        for kind, (passed, ignored) in counts.items():
            rosters[kind] = roster((RAW / f'{kind}-list-final-{GENERATION}/stdout').read_text())
            ignored_names = outcomes((RAW / f'{kind}-tests-final-{GENERATION}/stdout').read_text(),
                                     rosters[kind], passed, ignored)
            if kind == 'runtime':
                old_text = archived(baseline, 'runtime-tests-final-01/stdout').decode()
                old = roster(archived(baseline, 'runtime-list-final-01/stdout').decode())
                assert outcomes(old_text, old, 2266, 32) == ignored_names
                additions = {'context::qualification_xgmi::tests::' + name for name in NEW_CONTEXT}
                additions |= {'kfd_backend::compute_xgmi::tests::no_effect::' + name for name in NEW_BACKEND}
                assert not set(old) & additions and set(rosters[kind]) == set(old) | additions
            elif kind != 'recovery':
                assert rosters[kind] == roster(archived(baseline, kind + '-list-final-01/stdout').decode())
        assert rosters['recovery'] == sorted('tests::' + name for name in NEW_EXAMPLE)
        docs = (RAW / f'doctests-final-{GENERATION}/stdout').read_text()
        assert not re.search(r'^test result: (?!ok\.)', docs, re.M)
        totals = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', docs, re.M)
        assert sum(map(int, totals)) == 114
        for crate, old_archive, old_path, expected in [
            ('fe2o3-kfd', lower, 'doctests-final-01/stdout', 53),
            ('fe2o3-runtime', baseline, 'doctests-final-01/stdout', 61),
        ]:
            pattern = r'^test (crates/' + crate + r'/.+?) \.\.\. ok$'
            current = re.findall(pattern, docs, re.M)
            old = re.findall(pattern, archived(old_archive, old_path).decode(), re.M)
            normalize = lambda name: re.sub(r' \(line \d+\)', '', name)
            assert len(current) == len(old) == expected
            assert Counter(map(normalize, current)) == Counter(map(normalize, old))
        features = (RAW / f'features-no-default-final-{GENERATION}/stdout').read_text()
        assert 'hardware-qualification' not in features
        return {kind: {'passed': values[0], 'ignored': values[1]} for kind, values in counts.items()}

    def binary(self, label, target, test, kind):
        row = self.receipts[label]
        messages = [json.loads(line) for line in (RAW / label / 'stdout').read_text().splitlines()]
        assert [m['success'] for m in messages if m.get('reason') == 'build-finished'] == [True]
        artifacts = [m for m in messages if m.get('reason') == 'compiler-artifact' and m.get('executable')]
        assert len(artifacts) == 1
        item = artifacts[0]
        assert item['target']['name'] == target and item['target']['kind'] == [kind]
        assert item['profile']['test'] is test
        executable = Path(item['executable'])
        assert executable.is_relative_to(REPO / 'target/debug')
        assert set(row['executables']) == {str(executable)}
        identity = row['executables'][str(executable)]
        assert identity == {'target': target, 'test': test, 'sha256': sha(executable),
                            'byte_length': executable.stat().st_size}
        assert executable.read_bytes()[:4] == b'\x7fELF'
        return executable, identity

    def shards(self, lower):
        binary, identity = self.binary('kfd-build-final-' + GENERATION, 'fe2o3_kfd', True, 'lib')
        full = roster((RAW / f'kfd-list-final-{GENERATION}/stdout').read_text())
        old = roster(archived(lower, 'kfd-list-final-02/stdout').decode())
        additions = {'queue::live::compute_xgmi::no_effect_tests::' + name for name in NEW_KFD_PAIR}
        additions |= {'sdma::xgmi_creation::tests::' + name for name in NEW_KFD_NATIVE}
        assert len(old) == 1943 and len(full) == 1950
        assert not set(old) & additions and set(full) == set(old) | additions
        helper = module('recovery_shard_parser', RAW / 'reference/kfd_shard_final.py')
        heavy = [name for name in full if name.startswith(helper.PREFIX)]
        partitions = {str(i): heavy[i::4] for i in range(4)}
        partitions['rest'] = [name for name in full if not name.startswith(helper.PREFIX)]
        assert Counter(n for names in partitions.values() for n in names) == Counter(full)
        selected_receipts = {}
        for mode, selected in partitions.items():
            outer_label = f'kfd-shard-final-{GENERATION}-{mode}'
            outer = self.receipt(outer_label, '1320s',
                ['python3', '-I', '-B', str(RAW / 'kfd_shard.py'), mode])
            folder = RAW / f'kfd-shard-{GENERATION}-{mode}'
            inputs, result = read(folder / 'inputs.json'), read(folder / 'result.json')
            argv = [str(binary), '--test-threads=1', '--exact', *selected]
            assert inputs['argv'] == argv and inputs['selected'] == selected
            assert inputs['environment'] == helper.ENV and inputs['cwd'] == str(REPO)
            assert inputs['partitions'] == partitions and inputs['partition_union_exact'] is True
            assert inputs['total_roster'] == 1950 and inputs['construction_roster'] == len(heavy)
            assert inputs['executable'] == str(binary) and inputs['executable_identity'] == identity
            assert inputs['core_limit_bytes'] == 0 and inputs['native_opt_in_environment'] == {}
            assert inputs['controller_sha256'] == sha(RAW / 'reference/kfd_shard_final.py')
            assert inputs['build_receipt_sha256'] == sha(RAW / f'kfd-build-final-{GENERATION}/receipt.json')
            assert inputs['list_receipt_sha256'] == sha(RAW / f'kfd-list-final-{GENERATION}/receipt.json')
            assert inputs['full_roster_sha256'] == sha(RAW / f'kfd-list-final-{GENERATION}/stdout')
            assert inputs['source_manifest_sha256'] == sha(RAW / f'kfd-build-final-{GENERATION}/source-after.json')
            assert inputs['build_command'] == self.receipts[f'kfd-build-final-{GENERATION}']['command']
            assert inputs['list_command'] == self.receipts[f'kfd-list-final-{GENERATION}']['command']
            last = max(instant(self.receipts[f'kfd-{stage}-final-{GENERATION}']['finished'])
                       for stage in ('build', 'list'))
            for name, command in [('full-list', [str(binary), '--test-threads=1', '--list']),
                                  ('list', [*argv, '--list']), ('run', argv)]:
                row = read(folder / (name + '.json'))
                assert row['argv'] == command and row['environment'] == helper.ENV and row['cwd'] == str(REPO)
                assert helper.clean_run(row) and 0 < row['timeout_seconds'] <= (1200 if name == 'run' else 60)
                assert last <= instant(row['started']) <= instant(row['finished'])
                assert instant(outer['started']) <= instant(row['started'])
                assert instant(row['finished']) <= instant(outer['finished'])
                last = instant(row['finished'])
                for stream in ('stdout', 'stderr'):
                    assert sha(folder / (name + '.' + stream)) == row[stream + '_sha256']
            assert roster((folder / 'full-list.stdout').read_text()) == full
            assert roster((folder / 'list.stdout').read_text()) == selected
            parsed = helper.parse_outcomes((folder / 'run.stdout').read_text(), selected, len(full))
            assert parsed['accepted'] and result['accepted'] is True and result['error'] is None
            assert result['mode'] == mode and result['scope'] == 'selected-partition-only'
            assert result['controller_sha256'] == inputs['controller_sha256']
            assert result['passed'] == sorted(selected) and result['selected_count'] == len(selected)
            assert result['total_roster'] == 1950 and result['executable_sha256'] == identity['sha256']
            assert result['executable_unchanged'] and result['source_unchanged'] and result['group_absent']
            assert result['timed_out'] is False and result['exit_code'] == 0
            for key in ('summary', 'empty_progress', 'progress_problems', 'other_outcomes'):
                assert result[key] == parsed[key]
            for key, path in [('execution_receipt_sha256', 'run.json'), ('inputs_sha256', 'inputs.json'),
                              ('stdout_sha256', 'run.stdout'), ('stderr_sha256', 'run.stderr')]:
                assert result[key] == sha(folder / path)
            selected_receipts[mode] = sha(folder / 'result.json')
        assert read(RAW / f'kfd-suite-{GENERATION}.json') == [
            dict(mode=mode, label=f'kfd-shard-final-{GENERATION}-{mode}', exit=0)
            for mode in ('0', '1', '2', '3', 'rest')]
        return identity, selected_receipts

    def metadata(self, baseline):
        folder = RAW / ('proposal-' + PROPOSAL)
        report = read(folder / 'metadata-report.json')
        previous = json.loads(archived(baseline, 'proposal-03/metadata-report.json'))
        assert report['baseline'] == BASE and report['proof_files'] == previous['proof_files']
        assert len(report['changes']) == 13 and len(report['proof_files']) == 76
        edits = [edit for row in report['changes'] for edit in row['edits']]
        assert Counter(edit['category'] for edit in edits) == {'content-sha256': 21, 'source-inventory-count': 7}
        for key in ('all_baseline_audits_passed', 'all_proposed_source_audits_passed',
                    'ast_identical_except_listed_metadata_constants',
                    'predicates_contracts_and_proof_counts_unchanged', 'proof_closures_unchanged'):
            assert report[key] is True
        for key in ('solver_executed', 'build_executed', 'formal_qualification'):
            assert report[key] is False
        for row in report['changes']:
            original = baseline_blob(row['path'])
            assert original == (folder / 'originals' / Path(row['path']).name).read_bytes()
            assert sha_bytes(original) == row['original_sha256']
            assert sha(REPO / row['path']) == row['proposed_sha256']
            expected = ast.parse(original)
            nodes = {(node.lineno, node.col_offset): node for node in ast.walk(expected)
                     if isinstance(node, ast.Constant)}
            seen = set()
            for edit in row['edits']:
                pos = (edit['line'], edit['column'])
                assert pos not in seen and nodes[pos].value == edit['old']
                seen.add(pos)
                nodes[pos].value = edit['new']
            assert ast.dump(expected) == ast.dump(ast.parse((REPO / row['path']).read_bytes()))
        for path, digest in report['proof_files'].items():
            assert sha_bytes(baseline_blob(path)) == digest == sha(REPO / path)
        for path, digest in report['audited_source_sha256'].items():
            assert sha(REPO / path) == digest
        assert report['runtime_source_files'] == len(list((REPO / 'crates/fe2o3-runtime/src').rglob('*.rs')))
        assert report['runtime_and_schema_files'] == report['runtime_source_files'] + 5
        cadence = read(folder / 'cadence-rebind-review.json')
        helper = module('recovery_cadence_identity', RAW / 'cadence_rebind.py')
        assert cadence['metadata_nodes_only'] is True
        assert cadence['solver_executed'] is cadence['fresh_formal_qualification'] is cadence['recovery_refinement_proved'] is False
        assert cadence['helper_sha256'] == sha(RAW / 'cadence_rebind.py')
        assert cadence['wrapper_sha256'] == sha(RAW / 'propose_metadata.py')
        assert cadence['reference_proposer_sha256'] == sha(RAW / 'reference/propose.py')
        assert cadence['adapted_proposer_sha256'] == sha(folder / 'adapted-proposer.py')
        assert cadence['sdma_diff_sha256'] == sha(folder / 'reviewed-sdma-creation.patch')
        assert cadence['guard_original_sha256'] == helper.GUARD_SHA
        assert cadence['unchanged_producer_readers_sha256'] == helper.OWNER_SHA
        assert sha(REPO / helper.OWNER) == sha_bytes(baseline_blob(str(helper.OWNER))) == helper.OWNER_SHA
        block_path = 'crates/fe2o3-runtime-model/verus/check-producer-input-validate.py'
        block_source = baseline_blob(block_path)
        assert sha_bytes(block_source) == helper.BLOCK_HELPER_SHA
        blocks = types.ModuleType('recovery_balanced_block')
        blocks.__file__ = str(REPO / block_path)
        exec(compile(block_source, blocks.__file__, 'exec'), blocks.__dict__)
        old_sdma = baseline_blob(str(helper.SRC / 'sdma.rs')).decode()
        new_sdma = (REPO / helper.SRC / 'sdma.rs').read_text()
        spans = {}
        for anchor in helper.METHODS:
            values = []
            for source in (old_sdma, new_sdma):
                start = source.index(anchor)
                brace = source.index('{', start)
                values.append(source[start:brace] + blocks.block(source, anchor))
            assert values[0] == values[1]
            spans[anchor.strip()] = sha_bytes(values[0].encode())
        assert cadence['unchanged_cadence_signature_and_body_sha256'] == spans
        for path, pair in helper.APPROVED.items():
            assert sha_bytes(baseline_blob(str(path))) == pair[0] and sha(REPO / path) == pair[1]
        for path, digest in cadence['unchanged_other_source_pins'].items():
            assert sha_bytes(baseline_blob(path)) == digest == sha(REPO / path)
        for phase in ('before', 'after'):
            row = read(RAW / f'metadata-final-{phase}-{GENERATION}/stdout')
            assert row['applied_guard_hashes_match_proposal'] and row['ast_identical_except_recorded_metadata_literals']
            assert (row['unchanged_proof_files'], row['changed_files'], row['hash_constants'], row['source_inventory_constants']) == (76, 13, 21, 7)
            assert row['solver_executed'] is row['build_executed'] is row['formal_qualification'] is False
        return report

    def controls(self):
        workflow = yaml.safe_load((REPO / '.github/workflows/runtime-component-source-guards.yml').read_text())
        commands = [(step['name'], shlex.split(line)) for step in workflow['jobs']['source-controls']['steps']
                    if 'run' in step for line in step['run'].splitlines()]
        assert len(commands) == 32 and all(command[:3] == ['python3', '-I', '-B'] for _, command in commands)
        folder = RAW / f'source-controls-final-{GENERATION}-commands'
        summary = read(folder / 'summary.json')
        assert summary['accepted'] and summary['solver_executed'] is False
        assert summary['workflow_sha256'] == sha(REPO / '.github/workflows/runtime-component-source-guards.yml')
        assert summary['controller_sha256'] == sha(RAW / 'source_controls_baseline.py')
        assert [(row['name'], row['command']) for row in summary['commands']] == commands
        for index, row in enumerate(summary['commands']):
            assert read(folder / f'{index:02d}/receipt.json') == row and row['exit'] == 0
            for stream in ('stdout', 'stderr'):
                assert sha(folder / f'{index:02d}' / stream) == row[stream + '_sha256']

    def api(self):
        result = read(RAW / f'api-probe-run-{GENERATION}/result.json')
        assert result['accepted'] and result['execution'] is result['native_execution'] is False
        assert result['controller_sha256'] == sha(RAW / 'run_api_probe.py')
        assert result['environment'] == self.capture.ENV and result['repository_source_sha256'] == self.source
        assert result['exactly_three_e0599_without_feature'] and result['feature_enabled_compile'] and result['probe_source_unchanged']
        printed = [json.loads(line) for line in (RAW / f'api-probe-final-{GENERATION}/stdout').read_text().splitlines()]
        assert printed[-1] == result
        assert printed[:-1] == [dict(label=f'api-probe-{name}-{GENERATION}', exit=code, source_unchanged=True)
                                for name, code in [('lock', 0), ('disabled', 101), ('enabled', 0)]]
        for path, digest in result['probe_source_sha256'].items():
            assert sha(RAW / path) == digest
        assert set(result['probe_source_sha256']) == {'api-probe/Cargo.toml', 'api-probe/Cargo.lock', 'api-probe/src/lib.rs'}
        assert result['probe_sources_before_lock'] == {k: v for k, v in result['probe_source_sha256'].items() if not k.endswith('Cargo.lock')}
        assert all(not Path(path).exists() for path in result['absent_cargo_configs'])
        prefix = ['env', 'CARGO_TARGET_DIR=' + str(REPO / 'target'), 'cargo']
        manifest = ['--manifest-path', str(RAW / 'api-probe/Cargo.toml')]
        check = [*prefix, 'check', '--locked', '--offline', *manifest, '--no-default-features', '--lib', '--message-format=json']
        jobs = [('lock', [*prefix, 'generate-lockfile', '--offline', *manifest], 0),
                ('disabled', check, 101), ('enabled', [*check, '--features', 'hardware-qualification'], 0)]
        assert len(result['stages']) == 3
        methods = {'reject_native_xgmi_host_preparation_once_for_qualification_v1',
                   'native_xgmi_host_preparation_rejected_for_qualification_v1',
                   'create_native_xgmi_queue_with_peer_host_preparation_denial_v1'}
        for recorded, (name, command, status) in zip(result['stages'], jobs, strict=True):
            label = f'api-probe-{name}-{GENERATION}'
            self.receipt(label, '900s', command, status)
            assert recorded == {'label': label, 'receipt_sha256': sha(RAW / label / 'receipt.json'), 'expected_exit': status}
            if name != 'lock':
                rows = [json.loads(line) for line in (RAW / label / 'stdout').read_text().splitlines()]
                assert [r['success'] for r in rows if r.get('reason') == 'build-finished'] == [status == 0]
                errors = [r for r in rows if r.get('reason') == 'compiler-message' and r['message']['level'] == 'error']
                if name == 'enabled':
                    assert not errors
                else:
                    found = []
                    for error in errors:
                        assert error['target']['name'] == 'fe2o3_xgmi_recovery_api_probe'
                        assert error['message']['code']['code'] == 'E0599'
                        spans = [span for span in error['message']['spans'] if span['is_primary']]
                        assert spans
                        for span in spans:
                            path = Path(span['file_name'])
                            if not path.is_absolute():
                                path = RAW / 'api-probe' / path
                            assert path.resolve() == RAW / 'api-probe/src/lib.rs'
                        found.extend(m for m in methods if error['message']['message'].startswith('no method named `' + m + '` found'))
                    assert len(errors) == len(found) == 3 and set(found) == methods

    def native(self):
        campaign = read(RAW / 'hardware-01/campaign.json')
        audit = read(RAW / 'audit-native.json')
        assert audit == campaign and audit['accepted'] and audit['errors'] == []
        assert audit['generation'] == GENERATION and audit['expected_cases'] == len(audit['completed']) == 10
        assert audit['owned_cleanup_complete'] and audit['performance_acceptance'] is audit['formal_refinement'] is audit['exclusive_reservation'] is False
        assert audit['controller_sha256'] == sha(RAW / 'hardware-01/campaign.py')
        assert audit['transport_sha256'] == sha(RAW / 'hardware-01/capture.py')
        assert audit['oracle_sha256'] == sha(RAW / 'native_oracle.py')
        controller = module('recovery_native_roster', RAW / 'hardware-01/campaign.py')
        oracle = module('recovery_native_oracle', RAW / 'native_oracle.py')
        prior = module('recovery_packet_oracle', RAW / 'hardware-01/reference/campaign.py')
        ids = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33',
               '0x10a254ce4987e716', '0x53691ef168a0147d']
        cases = [(f'{mode}-{kind}-{direction}', 'recovery', ['--' + mode, kind, *uids])
                 for mode in ('no-journal', 'journal') for kind in ('scalar', 'segments')
                 for direction, uids in (('forward', ids), ('reverse', [ids[1], ids[0], ids[3], ids[2]]))]
        cases += [(f'packets-{direction}', 'settled', [*uids, 'packets'])
                  for direction, uids in (('forward', ids[2:]), ('reverse', ids[2:][::-1]))]
        assert controller.CASES == cases and len(cases) == 10
        assert audit['selected_unique_ids'] == ids
        assert audit['selected_cards'] == ['card1', 'card2', 'card6', 'card7']
        assert audit['selected_bdfs'] == ['0000:26:00.0', '0000:46:00.0', '0000:C6:00.0', '0000:E5:00.0']
        for item, (name, kind, args) in zip(audit['completed'], controller.CASES, strict=True):
            expected = oracle.expected(args[0], args[1], args[2:]) if kind == 'recovery' else prior.expected(args[-1], args[:2])
            assert item == {'name': name, 'kind': kind, 'arguments': args, 'fields': expected}
        for kind, target in controller.TARGETS.items():
            binary, identity = self.binary(f'build-{kind}-final-{GENERATION}', target, False, 'example')
            item = audit['binaries'][kind]
            assert item['local'] == str(binary) and item['sha256'] == identity['sha256']
            assert item['byte_length'] == identity['byte_length']
        outer = self.receipts['hardware-final-' + GENERATION]
        replay = self.receipts['audit-native-final-' + GENERATION]
        assert instant(outer['finished']) <= instant(replay['started'])
        assert all(instant(self.receipts[f'build-{kind}-final-{GENERATION}']['finished'])
                   <= instant(outer['started']) for kind in controller.TARGETS)
        last = instant(outer['started'])
        assert set(audit['events']) == {path.parent.name for path in (RAW / 'hardware-01').glob('*/result.json')}
        for name, event in sorted(audit['events'].items(), key=lambda pair: instant(pair[1]['started'])):
            folder = RAW / 'hardware-01' / name
            row = read(folder / 'result.json')
            assert sha(folder / 'result.json') == event['receipt_sha256']
            assert row['argv'] == event['argv']
            assert row['started'] == event['started'] and row['finished'] == event['finished']
            assert row['exit_code'] == 0 and row['timed_out'] is False
            assert row['local_process_group_absent'] is True and row['transport_timeout_seconds'] == 360
            assert 0 <= row['elapsed_seconds'] <= 370
            assert (instant(row['finished']) - instant(row['started'])).total_seconds() <= 370
            assert (folder / 'stderr').read_bytes() == b''
            assert last <= instant(event['started']) <= instant(event['finished']) <= instant(outer['finished'])
            last = instant(event['finished'])
            for stream in ('stdout', 'stderr'):
                assert sha(folder / stream) == row[stream + '_sha256']
        printed = [json.loads(line) for line in (RAW / f'audit-native-final-{GENERATION}/stdout').read_text().splitlines() if line.startswith('{')]
        assert printed == [{key: value for key, value in audit.items() if key != 'events'}]
        return audit


def main():
    global GENERATION, PROPOSAL
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and all(arg.isdigit() for arg in sys.argv[1:])
    GENERATION, PROPOSAL = sys.argv[1:]
    started = datetime.now(timezone.utc).isoformat()
    audit = Audit()
    baseline, lower = archive(BASELINE), archive(KFD_BASELINE)
    assert json.loads(archived(baseline, 'audit-result.json'))['accepted'] is True
    assert json.loads(archived(lower, 'audit-final.json'))['accepted'] is True
    audit.ordinary_jobs()
    counts = audit.tests(baseline, lower)
    kfd, shards = audit.shards(lower)
    audit.metadata(baseline)
    audit.controls()
    audit.api()
    native = audit.native()
    assert audit.capture.snapshot() == audit.source
    diagnostics = {}
    for path in RAW.glob('*/receipt.json'):
        if path.parent.name not in audit.selected:
            receipt = read(path)
            diagnostics[path.parent.name] = dict(receipt_sha256=sha(path),
                exit=receipt['exit'], source_unchanged=receipt['source_unchanged'], selected=False)
    result = dict(accepted=True, started=started, finished=datetime.now(timezone.utc).isoformat(),
        base=BASE, generation=GENERATION, auditor_sha256=sha(Path(__file__)), controller_pins=PINS,
        source_files=len(audit.source), source_sha256=audit.source, counts=counts,
        doctests={'kfd': 53, 'runtime': 61}, kfd_tests=1950, kfd_fresh=True,
        kfd_executable=kfd, kfd_shard_receipt_sha256=shards,
        source_controls=32, metadata_files=13, metadata_literals=28,
        unchanged_proof_files=76, metadata_report_sha256=sha(RAW / ('proposal-' + PROPOSAL) / 'metadata-report.json'),
        selected_receipts=audit.selected, native_cases=10, native_recovery_cases=8,
        native_packet_controls=2, native_events=len(native['events']),
        native_audit_sha256=sha(RAW / 'audit-native.json'), owned_cleanup_complete=True,
        api_probe_sha256=sha(RAW / f'api-probe-run-{GENERATION}/result.json'),
        baseline_archive_sha256=BASELINE[1], kfd_roster_baseline_archive_sha256=KFD_BASELINE[1],
        nonselected_receipts=diagnostics,
        fresh_solver_execution=False, recovery_refinement_proved=False,
        performance_acceptance=False, exclusive_reservation=False,
        fault_scope='actual pre-arm host capacity denial; not OOM, GPU or driver fault')
    with (RAW / 'audit-final.json').open('x') as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'source_sha256'}, sort_keys=True))


if __name__ == '__main__':
    main()
