"""Capture exact absent/present public APIs. Never execute the compiled probe."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tomllib

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '009e06610d0f45e81ff8b1306886ff534c6671f9'
PROBE = RAW / 'api-probe'
CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
METHODS = {
    'reject_native_xgmi_host_preparation_once_for_qualification_v1',
    'native_xgmi_host_preparation_rejected_for_qualification_v1',
    'create_native_xgmi_queue_with_peer_host_preparation_denial_v1',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    need(path.is_file() and not path.is_symlink(), 'ordinary input: ' + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(lock=True):
    paths = [PROBE / 'Cargo.toml', PROBE / 'src/lib.rs']
    if lock:
        paths.append(PROBE / 'Cargo.lock')
    return {str(path.relative_to(RAW)): sha(path) for path in paths}


def main():
    need(sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize,
         'python3 -I -B without optimized assertions')
    need(len(sys.argv) == 2 and sys.argv[1].isdigit(), 'fresh numeric generation')
    generation = sys.argv[1]
    output = RAW / ('api-probe-run-' + generation)
    output.mkdir(mode=0o700)
    result = dict(accepted=False, execution=False, native_execution=False,
                  controller_sha256=sha(Path(__file__)), stages=[])
    try:
        need(sha(RAW / 'capture.py') == CAPTURE_SHA, 'pinned source-bound capture')
        spec = importlib.util.spec_from_file_location('api_probe_capture', RAW / 'capture.py')
        capture = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(capture)
        need(capture.ROOT == REPO and capture.OUT == RAW, 'capture location')
        forbidden = {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_BOOTSTRAP',
                     'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_HOME', 'CARGO_TARGET_DIR'}
        need(not forbidden.intersection(capture.ENV) and
             not any(key.startswith('CARGO_CFG_') or key.startswith('CARGO_FEATURE_')
                     or key.endswith('_RUSTFLAGS') for key in capture.ENV),
             'sanitized capture environment has no ambient compiler cfg/features')
        config_roots = set(REPO.parents) | {REPO} | set(PROBE.parents) | {PROBE}
        config_paths = sorted({parent / '.cargo' / name for parent in config_roots
                               for name in ('config', 'config.toml')})
        need(all(not path.exists() for path in config_paths), 'no unrecorded Cargo configuration')
        manifest = tomllib.loads((PROBE / 'Cargo.toml').read_text())
        need(manifest['workspace'] == {} and manifest['features'] == {
            'default': [], 'hardware-qualification': [
                'fe2o3-runtime/hardware-qualification', 'fe2o3-kfd/hardware-qualification']},
             'standalone workspace and explicit two-dependency feature propagation')
        need(manifest['dependencies'] == {
            name: {'path': str(REPO / 'crates' / name), 'default-features': False}
            for name in ('fe2o3-runtime', 'fe2o3-kfd')}, 'exact no-default path dependencies')
        sources = snapshot(False)
        repo_sources = capture.snapshot()
        result.update(probe_sources_before_lock=sources, absent_cargo_configs=[str(p) for p in config_paths],
                      environment=capture.ENV, capture_sha256=CAPTURE_SHA,
                      repository_source_sha256=repo_sources)
        prefix = ['env', 'CARGO_TARGET_DIR=' + str(REPO / 'target'), 'cargo']
        manifest_args = ['--manifest-path', str(PROBE / 'Cargo.toml')]

        def run(name, command, expected_exit):
            label = 'api-probe-' + name + '-' + generation
            completed = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'),
                                        label, '900s', *command], check=False)
            folder = RAW / label
            receipt = json.loads((folder / 'receipt.json').read_bytes())
            result['stages'].append(dict(label=label, receipt_sha256=sha(folder / 'receipt.json'),
                                         expected_exit=expected_exit))
            need(completed.returncode == receipt['exit'] == expected_exit, 'exact process exit: ' + label)
            need(receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '900s', *command]
                 and receipt['environment'] == capture.ENV and receipt['cwd'] == str(REPO)
                 and receipt['base'] == BASE and receipt['controller_sha256'] == CAPTURE_SHA
                 and receipt['source_unchanged'], 'source-bound exact command: ' + label)
            need((folder / 'source-before.json').read_bytes() == (folder / 'source-after.json').read_bytes(),
                 'exact command source continuity: ' + label)
            need(json.loads((folder / 'source-before.json').read_bytes()) == repo_sources,
                 'same repository source for lock generation and both feature profiles')
            for stream in ('stdout', 'stderr'):
                need(sha(folder / stream) == receipt[stream + '_sha256'], 'raw stream identity')
            need(snapshot(False) == sources, 'immutable probe manifest and code')
            return folder

        run('lock', [*prefix, 'generate-lockfile', '--offline', *manifest_args], 0)
        locked = snapshot()
        result['probe_source_sha256'] = locked
        command = [*prefix, 'check', '--locked', '--offline', *manifest_args,
                   '--no-default-features', '--lib', '--message-format=json']
        for name, flags, expected in [('disabled', [], 101),
                                      ('enabled', ['--features', 'hardware-qualification'], 0)]:
            folder = run(name, [*command, *flags], expected)
            need(snapshot() == locked, 'same three locked probe inputs for both profiles')
            rows = [json.loads(line) for line in (folder / 'stdout').read_text().splitlines()]
            finished = [row['success'] for row in rows if row.get('reason') == 'build-finished']
            need(finished == [expected == 0], 'one exact Cargo build-finished record')
            errors = [row for row in rows if row.get('reason') == 'compiler-message'
                      and row['message']['level'] == 'error']
            if expected == 0:
                need(not errors, 'feature-enabled probe compiles without errors')
            else:
                need(len(errors) == 3, 'exactly three feature-excluded method errors')
                observed = []
                for row in errors:
                    need(row['target']['name'] == 'fe2o3_xgmi_recovery_api_probe',
                         'only the intended probe target reports errors')
                    error = row['message']
                    need(error.get('code', {}).get('code') == 'E0599', 'method-not-found only')
                    names = [method for method in METHODS
                             if error['message'].startswith('no method named `' + method + '` found')]
                    need(len(names) == 1, 'exact excluded public method')
                    primary = [span for span in error['spans'] if span['is_primary']]
                    def probe_path(span):
                        path = Path(span['file_name'])
                        return (path if path.is_absolute() else PROBE / path).resolve()
                    need(primary and all(probe_path(span) == PROBE / 'src/lib.rs' for span in primary),
                         'diagnostics belong to probe calls')
                    observed.extend(names)
                need(len(set(observed)) == 3 and set(observed) == METHODS, 'all and only three excluded APIs')
        need(capture.snapshot() == repo_sources, 'final repository source continuity')
        result.update(accepted=True, exactly_three_e0599_without_feature=True,
                      feature_enabled_compile=True, probe_source_unchanged=True)
    except Exception as error:
        result['error'] = repr(error)
    (output / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, sort_keys=True), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
