"""Capture one bounded qualification command without reusing evidence paths."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent
ENV = {
    'HOME': '/home/harsh',
    'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8',
    'LC_ALL': 'C.UTF-8',
    'CARGO_BUILD_JOBS': '4',
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
    'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true',
    'RUST_TEST_THREADS': '1',
    'FE2O3_HIP_SYS_DISABLE': '1',
}


def snapshot():
    listing = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z',
         '--', 'crates', 'scripts', '.github', 'tests/support',
         'benchmarks/runtime_gfx942/selected_pair_smoke.py',
         'benchmarks/runtime_gfx942/test_selected_pair_smoke.py',
         'benchmarks/runtime_gfx942/copy-host-observe.py',
         'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=ROOT, env=ENV,
    )
    return {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in sorted(set(os.fsdecode(listing).rstrip('\0').split('\0')))
    }


def main():
    label, seconds, *command = sys.argv[1:]
    if not label or '/' in label or label in ('.', '..') or not command:
        raise SystemExit('expected fresh label, timeout seconds, command')
    destination = OUT / label
    destination.mkdir(mode=0o700)
    before = snapshot()
    receipt = {
        'command': ['timeout', '--signal=TERM', '--kill-after=30s', seconds, *command],
        'environment': ENV,
        'cwd': str(ROOT),
        'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                        env=ENV, text=True).strip(),
        'controller_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    (destination / 'source-before.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
    (destination / 'command.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    with (destination / 'stdout').open('wb') as stdout, (destination / 'stderr').open('wb') as stderr:
        result = subprocess.run(receipt['command'], cwd=ROOT, env=ENV, stdout=stdout,
                                stderr=stderr, check=False)
    after = snapshot()
    receipt.update(exit=result.returncode, source_unchanged=before == after,
                   finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for name in ('stdout', 'stderr'):
        receipt[name + '_sha256'] = hashlib.sha256((destination / name).read_bytes()).hexdigest()
    if '--message-format=json' in command and result.returncode == 0:
        artifacts = {}
        for line in (destination / 'stdout').read_text().splitlines():
            row = json.loads(line)
            executable = row.get('executable') if row.get('reason') == 'compiler-artifact' else None
            if executable:
                path = Path(executable)
                artifacts[executable] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                         'byte_length': path.stat().st_size,
                                         'target': row['target']['name'],
                                         'test': row['profile']['test']}
        receipt['executables'] = artifacts
    (destination / 'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2) + '\n')
    (destination / 'receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'label': label, 'exit': result.returncode,
                      'source_unchanged': before == after}), flush=True)
    return result.returncode if before == after else 125


if __name__ == '__main__':
    sys.exit(main())
