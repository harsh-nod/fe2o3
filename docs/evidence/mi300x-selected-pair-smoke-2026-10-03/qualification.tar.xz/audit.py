#!/usr/bin/env python3
"""Offline replay of one selected-pair copy campaign, not kernel authority."""

import ast
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
REMOTE = '/tmp/fe2o3-selected-pair-20261003.TBigkqRN'
BASE = '8eb0ebcb954c5cf795f08ba4265da54681bf40c9'
EXAMPLE = 'gfx942-runtime-peer-copy-smoke'
RUNNER = 'benchmarks/runtime_gfx942/selected_pair_smoke.py'
TESTS = 'benchmarks/runtime_gfx942/test_selected_pair_smoke.py'
OBSERVER = 'benchmarks/runtime_gfx942/copy-host-observe.py'
PINS = {
    RUNNER: 'd586fd438e6bb4c399b9dc73bfea3475365c33cd3802defa186e10e81f859f65',
    TESTS: '9b7e12e1ec89a094bee4de3188b79d1a8211d934a56b7b320febd3790ac31b80',
    OBSERVER: '5d37b09bf0823854c6a45b914d866c042c1e65486cd96c6301285a0147ae6c51',
}
BINARY = '19f00a1067363ea95e59e0da0074e001fd0237f68a527100d2c909d71413d9fd'
CAPTURE = 'ae69f342d597e12ba436dc4a486a1f07647c104553ae0cc2b5b9bef05d5b94b1'
PAIR = [(6, '0000:c6:00.0', '0x10a254ce4987e716'),
        (7, '0000:e5:00.0', '0x53691ef168a0147d')]
CASES = [('native-forward', False, False), ('native-reverse', False, True),
         ('staged-forward', True, False), ('staged-reverse', True, True)]
ENV = {'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '4',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
       'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
       'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
       'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUST_TEST_THREADS': '1',
       'FE2O3_HIP_SYS_DISABLE': '1'}
CHILD_ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'mi300x']
SCP = ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10']


def require(value, message):
    if not value:
        raise ValueError(message)


def data(path):
    require(path.is_file() and not path.is_symlink(), f'ordinary file required: {path}')
    return path.read_bytes()


def sha(path):
    return hashlib.sha256(data(path)).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f'duplicate JSON key: {key}')
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return decode(data(path))


def epoch(value):
    return datetime.fromisoformat(value).timestamp()


def number(value, maximum=(1 << 64) - 1):
    require(isinstance(value, str) and re.fullmatch(r'0|[1-9][0-9]*', value), 'decimal syntax')
    result = int(value)
    require(result <= maximum, 'decimal bound')
    return result


def stamp(value):
    require(type(value['monotonic_ns']) is int and value['monotonic_ns'] > 0, 'monotonic stamp')
    return value['monotonic_ns']


def current_sources():
    command = ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
               'crates', 'scripts', '.github', 'tests/support', RUNNER, TESTS, OBSERVER,
               'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']
    names = subprocess.check_output(command, cwd=REPO, env=ENV).decode().rstrip('\0').split('\0')
    return {name: sha(REPO / name) for name in sorted(set(names))}


def outer(label, command, sources, limit):
    folder = RAW / label
    receipt = load(folder / 'receipt.json')
    initial = load(folder / 'command.json')
    require(all(receipt.get(key) == value for key, value in initial.items()), f'{label}: command mutation')
    vector = receipt['command']
    require(vector[:3] == ['timeout', '--signal=TERM', '--kill-after=30s']
            and re.fullmatch(r'[1-9][0-9]*s', vector[3])
            and int(vector[3][:-1]) <= limit and vector[4:] == command, f'{label}: exact argv')
    require(receipt['exit'] == 0 and receipt['source_unchanged'] is True, f'{label}: failed capture')
    require(receipt['base'] == BASE and receipt['cwd'] == str(REPO)
            and receipt['environment'] == ENV and receipt['controller_sha256'] == CAPTURE,
            f'{label}: capture identity')
    require(0 <= epoch(receipt['finished']) - epoch(receipt['started']) <= limit + 35,
            f'{label}: chronology/bound')
    require(load(folder / 'source-before.json') == sources == load(folder / 'source-after.json'),
            f'{label}: source continuity')
    for stream in ('stdout', 'stderr'):
        require(sha(folder / stream) == receipt[stream + '_sha256'], f'{label}: {stream} hash')
    return receipt


def raw_text(label, name='stdout'):
    return data(RAW / label / name).decode('utf-8')


def parse_pids(text):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    require(len(lines) >= 4 and re.fullmatch(r'=+ ROCm System Management Interface =+', lines[0])
            and re.fullmatch(r'=+ GPUs Indexed by PID =+', lines[1])
            and re.fullmatch(r'=+', lines[-2]) and re.fullmatch(r'=+ End of ROCm SMI Log =+', lines[-1]),
            'complete PID transcript')
    rows, result, index = lines[2:-2], {}, 0
    while index < len(rows):
        match = re.fullmatch(r'PID ([1-9][0-9]*) is using ([0-9]+) DRM device\(s\)(:?)', rows[index])
        require(match, 'PID record syntax')
        pid, count = number(match[1], (1 << 31) - 1), number(match[2], 64)
        require(pid not in result and bool(count) == bool(match[3]), 'PID duplicate/delimiter')
        index += 1
        devices = []
        if count:
            require(index < len(rows), 'PID missing devices')
            devices = [number(value, 63) for value in rows[index].split()]
            index += 1
            require(len(devices) == len(set(devices)) == count, 'PID device count')
        result[pid] = devices
    require(result, 'empty PID evidence does not establish absence')
    return result


def expected(pair, staged):
    return {'schema': 'fe2o3.production-peer-copy-smoke.v1', 'authority': 'production-deny-all',
            'transport': 'HOST-STAGED' if staged else 'NATIVE-XGMI', 'devices': '2', 'launches': '0',
            'peer_copies': '2', 'bytes_per_copy': '8388581', 'native_packets': '0' if staged else '6',
            'observed_native_copies': '0' if staged else '2', 'source_unique_id': pair[0][2],
            'destination_unique_id': pair[1][2], 'allocations': '4', 'streams': '2', 'readbacks': '8',
            'rounds_changed': 'true', 'pre_flush_observers': 'pending', 'expired_drain': 'rejected',
            'logical_counter': 'final-only', 'source_unchanged': 'full-byte-pass',
            'destination_sentinel': 'full-byte-pass', 'output': 'full-byte-pass',
            'cleanup': 'logical-and-native-explicit', 'performance_acceptance': 'false',
            'formal_refinement': 'false'}


def parse_pass(text):
    lines = text.splitlines()
    require(len(lines) == 1 and lines[0].startswith('PASS '), 'one exact PASS line')
    pairs = []
    for token in lines[0][5:].split():
        require(token.count('=') == 1, 'PASS token')
        key, value = token.split('=')
        require(key and value, 'empty PASS token')
        pairs.append((key, value))
    return unique(pairs)


def inner(folder, name, argv, bound, native=False):
    directory = folder / name
    receipt = load(directory / 'receipt.json')
    require(receipt['argv'] == argv and receipt['bound_seconds'] == bound
            and receipt['environment'] == CHILD_ENV, f'{name}: command identity')
    require(receipt['exit'] == 0 and receipt['error'] is None and not receipt.get('cleanup_error')
            and receipt['group_absent'] is True and type(receipt['pid']) is int
            and receipt['pid'] > 0 and receipt['members_before_reap'] == [receipt['pid']],
            f'{name}: completion/owned-group closure')
    executable = receipt['executable']
    require(bool(re.fullmatch(r'/proc/self/fd/[0-9]+', executable or '')) if native else executable is None,
            f'{name}: execution route')
    require(0 <= stamp(receipt['finished']) - stamp(receipt['started']) <= (bound + 13) * 10**9,
            f'{name}: time bound')
    for stream in ('stdout', 'stderr'):
        output = data(directory / stream)
        require(len(output) <= 1 << 20 and len(output) == receipt[stream + '_bytes']
                and hashlib.sha256(output).hexdigest() == receipt[stream + '_sha256'],
                f'{name}: bounded output binding')
    require(not data(directory / 'stderr').strip(), f'{name}: stderr')
    return receipt, data(directory / 'stdout').decode('ascii')


def observation(folder, label, endpoint, command_names):
    gpu, bdf, uid = endpoint
    name = f'{label}-gpu{gpu}'
    row = load(folder / (name + '.json'))
    require(row['schema'] == 'fe2o3.copy-host-observation.v1' and row['record'] == 'observation'
            and (row['gpu_index'], row['pci_bdf'], row['unique_id']) == endpoint
            and row['endpoint_admitted'] is True and row['reasons'] == [] and row['selected_pids'] == []
            and row['vram_limit_exclusive'] == 512 << 20 and row['visibility_filters'] == 'removed-for-cli'
            and row['scope'] == 'sequential-endpoint-observations-not-continuous-monitoring-or-reservation',
            f'{name}: observation identity')
    prefix = ['/usr/bin/timeout', '--kill-after=5s', '20s', '/opt/rocm/bin/rocm-smi']
    vectors = [prefix + ['--showuse', '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--json'],
               prefix + ['--showpidgpus']]
    receipts = []
    for ordinal, key in enumerate(('status', 'pids')):
        command_name = f'{name}-{ordinal}'
        command_names.append(command_name)
        receipt, text = inner(folder, command_name, vectors[ordinal], 35)
        require(row[key] == {'exit': 0, 'error': None, 'stdout': text,
                             'stderr': data(folder / command_name / 'stderr').decode('ascii')},
                f'{name}: raw {key} binding')
        receipts.append(receipt)
    status = decode(row['status']['stdout'])[f'card{gpu}']
    require(status['Unique ID'].lower() == uid and status['PCI Bus'].lower() == bdf
            and number(status['GPU use (%)'], 100) == 0
            and number(status['VRAM Total Used Memory (B)']) < 512 << 20, f'{name}: SMI admission')
    require(not any(gpu in devices for devices in parse_pids(row['pids']['stdout']).values()),
            f'{name}: selected process attachment')
    require(len(row['sysfs']) == 3, f'{name}: three sysfs samples')
    for sample in row['sysfs']:
        require(sample['path'] == f'/sys/bus/pci/devices/{bdf}' and sample['errors'] == {},
                f'{name}: sysfs path/error')
        values = sample['values']
        require(set(values) == {'unique_id', 'mem_info_vram_used', 'mem_info_vis_vram_used',
                                'mem_info_gtt_used', 'gpu_busy_percent', 'mem_busy_percent'}
                and values['unique_id'].lower() == uid[2:], f'{name}: complete sysfs identity')
        parsed = {key: number(value, 100 if key.endswith('percent') else (1 << 64) - 1)
                  for key, value in values.items() if key != 'unique_id'}
        require(parsed['gpu_busy_percent'] == 0 and parsed['mem_info_vram_used'] < 512 << 20,
                f'{name}: sysfs admission')
    ordered = [row['started'], row['sysfs'][0]['started'], row['sysfs'][0]['finished'],
               receipts[0]['started'], receipts[0]['finished'], row['sysfs'][1]['started'],
               row['sysfs'][1]['finished'], receipts[1]['started'], receipts[1]['finished'],
               row['sysfs'][2]['started'], row['sysfs'][2]['finished'], row['finished']]
    times = list(map(stamp, ordered))
    require(times == sorted(times) and times[-1] - times[0] <= 150 * 10**9, f'{name}: chronology')
    return row


def main():
    require(sha(RAW / 'capture.py') == CAPTURE, 'capture pin')
    for name, digest in PINS.items():
        require(sha(REPO / name) == digest, f'source pin: {name}')
    sources = current_sources()
    require(all(sources[name] == digest for name, digest in PINS.items()), 'source manifest pins')
    commands = {
        'native-build-02': (2400, ['cargo', '+nightly-2026-04-03', 'build', '--locked', '--offline',
                                 '-p', 'fe2o3-runtime', '--no-default-features', '--example', EXAMPLE,
                                 '--message-format=json']),
        'controller-tests-01': (120, ['python3', '-I', '-B', TESTS]),
        'upload-01': (120, SCP + [f'target/debug/examples/{EXAMPLE}', RUNNER, OBSERVER, f'mi300x:{REMOTE}/']),
        'native-run-01': (1300, SSH + ['timeout', '--signal=TERM', '--kill-after=30s', '1200s',
                                     'python3', '-I', '-B', f'{REMOTE}/selected_pair_smoke.py',
                                     '--allow-hardware', '--binary', f'{REMOTE}/{EXAMPLE}',
                                     '--binary-sha256', BINARY, '--device', ','.join(map(str, PAIR[0])),
                                     '--device', ','.join(map(str, PAIR[1])), '--output', f'{REMOTE}/results']),
        'remote-hashes-01': (120, SSH + ['sha256sum', f'{REMOTE}/{EXAMPLE}',
                                      f'{REMOTE}/selected_pair_smoke.py', f'{REMOTE}/copy-host-observe.py']),
        'download-01': (120, ['scp', '-r', *SCP[1:], f'mi300x:{REMOTE}/results', str(RAW / 'native-results')]),
        'cleanup-01': (120, SSH + ['rm', '-rf', '--', REMOTE]),
        'cleanup-check-01': (120, SSH + ['test', '!', '-e', REMOTE]),
    }
    captures = {name: outer(name, vector, sources, bound) for name, (bound, vector) in commands.items()}
    sequence = ['controller-tests-01', 'native-build-02', 'upload-01', 'native-run-01',
                'remote-hashes-01', 'download-01', 'cleanup-01', 'cleanup-check-01']
    # End hashes and download are independent read-only operations; both must
    # finish before cleanup, but need not be serialized with each other.
    order = [('controller-tests-01', 'upload-01'), ('native-build-02', 'upload-01'),
             ('upload-01', 'native-run-01'), ('native-run-01', 'remote-hashes-01'),
             ('native-run-01', 'download-01'), ('remote-hashes-01', 'cleanup-01'),
             ('download-01', 'cleanup-01'), ('cleanup-01', 'cleanup-check-01')]
    require(all(epoch(captures[left]['finished']) <= epoch(captures[right]['started'])
                for left, right in order), 'outer command chronology')
    for label in sequence[2:]:
        require(not raw_text(label, 'stderr').strip(), f'{label}: unexpected transport stderr')
    for label in ('upload-01', 'download-01', 'cleanup-01', 'cleanup-check-01'):
        require(not raw_text(label).strip(), f'{label}: unexpected stdout')
    test_names = [node.name for node in ast.walk(ast.parse(data(REPO / TESTS)))
                  if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    require(len(test_names) == len(set(test_names)) == 17 and raw_text('controller-tests-01') == ''
            and re.fullmatch(r'\.{17}\n-+\nRan 17 tests in [0-9.]+s\n\nOK\n',
                             raw_text('controller-tests-01', 'stderr')), 'exact controller tests')
    executable = str(REPO / 'target/debug/examples' / EXAMPLE)
    artifacts = []
    for line in raw_text('native-build-02').splitlines():
        row = decode(line)
        if row.get('reason') == 'compiler-artifact' and row.get('executable'):
            artifacts.append((row['executable'], row['target']['name'], row['profile']['test']))
    require(artifacts == [(executable, EXAMPLE, False)], 'exact built executable roster')
    artifact = captures['native-build-02']['executables']
    require(set(artifact) == {executable} and artifact[executable] == {
        'sha256': BINARY, 'byte_length': 19983184, 'target': EXAMPLE, 'test': False}
        and sha(Path(executable)) == BINARY and Path(executable).stat().st_size == 19983184,
        'current ELF/build receipt binding')
    remote_hashes = raw_text('remote-hashes-01').splitlines()
    require(remote_hashes == [f'{BINARY}  {REMOTE}/{EXAMPLE}',
                              f'{PINS[RUNNER]}  {REMOTE}/selected_pair_smoke.py',
                              f'{PINS[OBSERVER]}  {REMOTE}/copy-host-observe.py'], 'remote end hashes')
    folder = RAW / 'native-results'
    require(folder.is_dir() and not folder.is_symlink(), 'native results directory')
    report = load(folder / 'result.json')
    require(report['schema'] == 'fe2o3.selected-pair-smoke.v1' and report['accepted'] is True
            and report['errors'] == [] and report['devices'] == [list(row) for row in PAIR]
            and report['binary'] == f'{REMOTE}/{EXAMPLE}' and report['observer_sha256'] == PINS[OBSERVER]
            and report['scope'] == 'copy-only-selected-pair; point-observations-not-reservation; no-native-fault-injection',
            'terminal campaign acceptance/identity')
    identity = report['binary_identity']
    require(set(identity) == {'sha256', 'device', 'inode', 'bytes', 'mtime_ns', 'ctime_ns'}
            and identity['sha256'] == BINARY and identity['bytes'] == 19983184
            and all(type(identity[key]) is int and identity[key] >= 0
                    for key in ('device', 'inode', 'bytes', 'mtime_ns', 'ctime_ns')), 'remote ELF fingerprint')
    summary = decode(raw_text('native-run-01'))
    require(summary == {'accepted': True, 'results': f'{REMOTE}/results', 'cases': 4, 'errors': []},
            'captured native command terminal summary')
    require(len(report['cases']) == 4, 'exact native case count')
    command_names, observation_names = [], []
    previous = stamp(report['started'])
    for case, (name, staged, reverse) in zip(report['cases'], CASES):
        selected = list(reversed(PAIR)) if reverse else PAIR
        require(case['name'] == name and case['accepted'] is True and case['cleanup_observed'] is True,
                f'{name}: accepted case and cleanup')
        before = []
        for endpoint in PAIR:
            row = observation(folder, name + '-before', endpoint, command_names)
            observation_names.append(f'{name}-before-gpu{endpoint[0]}.json')
            require(previous <= stamp(row['started']), f'{name}: pre-observation order')
            previous = stamp(row['finished'])
            before.append(row)
        argv = [f'{REMOTE}/{EXAMPLE}', *(['--staged-default'] if staged else []),
                selected[0][2], selected[1][2]]
        command_names.append(name)
        receipt, stdout = inner(folder, name, argv, 180, native=True)
        require(previous <= stamp(receipt['started']) and all(
            0 <= stamp(receipt['started']) - stamp(row['started']) <= 150 * 10**9 for row in before),
            f'{name}: fresh pair admission before execution')
        require(parse_pass(stdout) == case['pass'] == expected(selected, staged), f'{name}: exact PASS')
        previous = stamp(receipt['finished'])
        for endpoint in PAIR:
            row = observation(folder, name + '-after', endpoint, command_names)
            observation_names.append(f'{name}-after-gpu{endpoint[0]}.json')
            require(previous <= stamp(row['started']) <= previous + 150 * 10**9,
                    f'{name}: post-observation order/freshness')
            previous = stamp(row['finished'])
    require(previous <= stamp(report['finished']) and stamp(report['finished']) - stamp(report['started']) <= 1200 * 10**9,
            'campaign chronology/bound')
    require(report['commands'] == command_names and len(command_names) == len(set(command_names)) == 36,
            'exact inner command roster')
    expected_files = {'result.json', *observation_names}
    expected_files.update(f'{name}/{suffix}' for name in command_names for suffix in ('receipt.json', 'stdout', 'stderr'))
    actual_files = set()
    for path in folder.rglob('*'):
        require(not path.is_symlink(), 'native results symlink')
        if path.is_file():
            actual_files.add(str(path.relative_to(folder)))
        else:
            require(path.is_dir() and str(path.relative_to(folder)) in command_names, 'unexpected native results path')
    require(actual_files == expected_files, 'complete downloaded native file roster')
    return {'accepted': True, 'schema': 'fe2o3.selected-pair-offline-audit.v1',
            'captures': len(captures), 'controller_tests': 17, 'cases': 4,
            'observations': len(observation_names), 'inner_commands': len(command_names),
            'source_files': len(sources), 'native_files': len(actual_files),
            'peer_copies': 8, 'native_copies': 4, 'staged_copies': 4, 'native_packets': 12,
            'full_readbacks': 32, 'kernel_launches': 0, 'binary_sha256': BINARY,
            'runner_sha256': PINS[RUNNER], 'tests_sha256': PINS[TESTS],
            'auditor_sha256': sha(Path(__file__)), 'excluded_diagnostic': 'native-build-01',
            'owned_remote_path_absent': True, 'performance_acceptance': False,
            'formal_refinement': False, 'exclusive_reservation': False}


if __name__ == '__main__':
    try:
        print(json.dumps(main(), sort_keys=True))
    except Exception as error:
        print(json.dumps({'accepted': False, 'error': f'{type(error).__name__}: {error}'}, sort_keys=True))
        sys.exit(1)
