"""Package completed, audited qualification captures without modifying sources."""

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '8eb0ebcb954c5cf795f08ba4265da54681bf40c9'
SPECS = [
    ('fe2o3-checked-u32-capture-20261003',
     'dev-checked-u32-emission-capture-2026-10-03', 'audit-final-02', 'build-02'),
    ('fe2o3-selected-pair-smoke-20261003',
     'mi300x-selected-pair-smoke-2026-10-03', 'audit-final-01', 'native-build-02'),
]

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def write_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + '\n')

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
for raw_name, evidence, audit, build in SPECS:
    raw = Path('/home/harsh/.codex-tmp') / raw_name
    destination = ROOT / 'docs/evidence' / evidence
    receipt = json.loads((raw / audit / 'receipt.json').read_text())
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True
    assert json.loads((raw / audit / 'stdout').read_text())['accepted'] is True
    source = json.loads((raw / build / 'source-after.json').read_text())
    assert all(digest((ROOT / name).read_bytes()) == sha for name, sha in source.items())
    scope = ['crates', 'scripts', '.github', 'tests/support',
             'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']
    if raw_name.startswith('fe2o3-selected'):
        scope.extend(['benchmarks/runtime_gfx942/selected_pair_smoke.py',
                      'benchmarks/runtime_gfx942/test_selected_pair_smoke.py',
                      'benchmarks/runtime_gfx942/copy-host-observe.py'])
    changed = subprocess.check_output(
        ['git', 'diff', '--cached', '--name-only', '-z', BASE, '--', *scope], cwd=ROOT,
    ).decode().rstrip('\0').split('\0')
    for name in changed:
        assert name in source
        assert digest(subprocess.check_output(['git', 'show', ':' + name], cwd=ROOT)) == source[name]
    patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', BASE, '--', *scope], cwd=ROOT)
    with (raw / 'source.patch').open('xb') as stream:
        stream.write(patch)
    with (raw / 'package.py').open('xb') as stream:
        stream.write(Path(__file__).read_bytes())
    inventory = {}
    for path in sorted(raw.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            data = path.read_bytes()
            inventory[str(path.relative_to(raw))] = {'bytes': len(data), 'sha256': digest(data)}
    write_json(raw / 'manifest.json', {'base': BASE, 'files': inventory,
                                    'source_patch_sha256': digest(patch),
                                    'changed_source_paths': changed})
    archive = destination / 'qualification.tar.gz'
    with archive.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:gz') as bundle:
            for path in sorted(raw.rglob('*')):
                if path.is_file():
                    data = path.read_bytes()
                    entry = tarfile.TarInfo(str(path.relative_to(raw)))
                    entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
                    bundle.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as bundle:
        members = bundle.getmembers()
        assert len(members) == len(inventory) + 1
        assert all(member.isfile() for member in members)
        for name, identity in inventory.items():
            data = bundle.extractfile(name).read()
            assert len(data) == identity['bytes'] and digest(data) == identity['sha256']
    summary = {'base': BASE, 'archive': archive.name,
               'archive_sha256': digest(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
               'files': len(inventory) + 1, 'source_patch_sha256': digest(patch),
               'audit_capture': audit, 'auditor_sha256': digest((raw / 'audit.py').read_bytes()),
               'source_paths': len(source), 'changed_source_paths': len(changed)}
    write_json(destination / 'archive.json', summary)
    print(json.dumps({'evidence': evidence, **summary}), flush=True)
