# Pre-Freeze Diagnostics

- `diagnostic-01/precheck`: strict Clippy rejected one nonminimal boolean in
  the new native directed blocker. The equivalent `is_none_or` expression
  replaced it; no suppression was added.
- `diagnostic-02/precheck`: the test worker wrote its consumer fixture during
  this diagnostic. Clippy reported three draft method-name errors and one
  overlapping borrow. The source-continuity check also rejected the changed
  roster with exit 125. This attempt is not qualification evidence.

- `attempt-01`: formatting, strict Clippy, build and all 32 source controls pass,
  but runtime tests reject two new consumer fixtures before their intended
  behavior is exercised. The unrelated host allocations were synthetic, not
  SDMA-backed. The focused run has 59 passes and two failures; the complete run
  has 2,107 passes, two failures and 32 unchanged hardware ignores. This is a
  rejected attempt, not qualification. The existing runtime launch guard is
  correct and unchanged. The repair must install proper scripted host ownership
  and exact materialized completion steps, not weaken the guard.

- `diagnostic-04`: strict Clippy, the optimized build and all 12 focused runtime
  groups pass after the fixture repair. All 61 native integrated-peer tests pass.
- `attempt-02`: all 2,109 runtime tests pass with 32 unchanged hardware ignores;
  all 32 source controls pass. The new directed witness fails compilation because
  this SHA-256 output type does not implement `LowerHex`. Its three check/build
  stages fail; every other check stage passes. This attempt remains rejected.
  The witness now uses the existing sibling example's fixed-width byte-to-hex
  formatter. No runtime implementation or executable proof body changed.

Final acceptance must name a separate source-frozen attempt and retain all
diagnostic and rejected packets unchanged.
