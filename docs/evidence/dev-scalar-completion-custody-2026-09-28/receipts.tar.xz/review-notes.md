# Developer Scope and Review

Baseline 6fc79a423f64cd7172926511b4eadad2082f9835 includes the signed bind-recovery
packet completed at the start of this goal continuation. The before-fix witness
changed only the existing scalar Poll/Recycle/Detach test helper's assertion:

    assert!(backend.active.is_none());

became

    assert_eq!(backend.active.as_ref().map(|active| active.id), Some(compute));

The first run aborted without displaying the captured assertion. The second,
with --nocapture and core dumps disabled, showed None versus Some(7) before the
unrepaired backend's Drop aborted. Both command receipts are retained.

An initial development cargo check found the missing PersistentCompleting arm
in the activity predicate; this was corrected before the recorded successful
check. The successful development check reported a temporarily unread access
field, later used by the exact admission preflight. Development Clippy passed.
The focused-retry run began before the formatter handle was observed terminal;
it is not frozen-source evidence. The signed final-source sequential campaign
is authoritative and includes a final source-continuity check.

Read-only async_code_review identified and verified corrections for entry and
commit preflights and Prepared publication/cancellation root validation. It
checked native legal output shapes, custody-before-diagnostics ordering and
original bind-shell reuse. queued_native_review checked the connected fixture,
63 then 81 fault children, exact lower owner/Active retention and test boundaries.
Neither reviewer edited files, ran builds or requested permissions.

The allocation witness is scripted public completion plus shared restoration
and commit, not native lower-body or GPU completion. Scripted writes verify
metadata, not executed kernel arithmetic. No current tests exercise native
lower-call internal unwind or post-commit profiler panic. Fresh cancellation
shell allocation remains unchanged; the donated completion boxes are empty
when healthy cancellation drops the Reserved root. Three-binding completion,
formal production refinement, Context composition, hardware and performance
remain outside this packet.
