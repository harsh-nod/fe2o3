cargo test -p fe2o3-runtime --all-features scalar_completion_ --lib -- --nocapture 
