#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-completion-custody-20260928-oe1uUG4c
out=/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-scalar-completion-custody-2026-09-28
test -f "$raw/final-source-continuity.finished"
test "$(< "$raw/final-source-continuity.status")" = 0
test "$(< "$raw/final-fmt.status")" = 0
tar --sort=name -cJf "$out/receipts.tar.xz" -C "$raw" .
cd "$out"
sha256sum receipts.tar.xz > receipts.tar.xz.sha256
sha256sum -c receipts.tar.xz.sha256
