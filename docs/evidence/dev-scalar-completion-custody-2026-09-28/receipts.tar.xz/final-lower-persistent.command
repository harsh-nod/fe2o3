cargo test -p fe2o3-kfd --all-features persistent_ --lib 
