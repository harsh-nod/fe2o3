#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
runner=/home/harsh/.codex-tmp/fe2o3-completion-custody-20260928-oe1uUG4c/run.sh
overall=0
run() {
    bash "$runner" "$@" || overall=1
}
run final-source-head git show -s --format=fuller HEAD
run final-source-tree git rev-parse HEAD HEAD^{tree}
run final-source-signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run final-focused cargo test -p fe2o3-runtime --all-features scalar_completion_ --lib -- --nocapture
run final-existing-scalar cargo test -p fe2o3-runtime --all-features scripted_persistent_ --lib
run final-lower-persistent cargo test -p fe2o3-kfd --all-features persistent_ --lib
run final-runtime-model cargo test -p fe2o3-runtime -p fe2o3-runtime-model --all-features --no-fail-fast
run final-clippy cargo clippy -p fe2o3-runtime -p fe2o3-runtime-model -p fe2o3-kfd --all-features --all-targets -- -D warnings
run final-no-default cargo check -p fe2o3-runtime --no-default-features
run final-fmt cargo fmt --all --check
run final-source-continuity git diff --exit-code HEAD -- crates/fe2o3-runtime crates/fe2o3-runtime-model crates/fe2o3-kfd
exit "$overall"
