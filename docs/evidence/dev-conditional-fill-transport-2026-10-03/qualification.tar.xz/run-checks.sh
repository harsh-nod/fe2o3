#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-conditional-transport-20261003-ank8mN
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-functional-proof --features internal-proof-staging --test import_v2 >"$scratch/boundary.log" 2>&1
tail -n 4 "$scratch/boundary.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-lower-mir-kernel --lib >"$scratch/lowering.log" 2>&1
tail -n 4 "$scratch/lowering.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --lib >"$scratch/verifier.log" 2>&1
tail -n 4 "$scratch/verifier.log"
cargo +nightly-2026-04-03 test --locked --offline -p rustc-codegen-fe2o3 --lib >"$scratch/compiler.log" 2>&1
tail -n 4 "$scratch/compiler.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-pliron --features internal-proof-staging --test production_middle_end_evidence_v5 >"$scratch/staging.log" 2>&1
tail -n 4 "$scratch/staging.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --test compiler_proof_binding_v4 >"$scratch/import.log" 2>&1
tail -n 4 "$scratch/import.log"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-verifier --doc >"$scratch/ownership.log" 2>&1
tail -n 4 "$scratch/ownership.log"
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-lower-mir-kernel -p fe2o3-verifier -p rustc-codegen-fe2o3 -p fe2o3-functional-proof --lib --no-deps -- -D warnings >"$scratch/clippy.log" 2>&1
tail -n 4 "$scratch/clippy.log"
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check \
    crates/fe2o3-functional-proof/src/lib.rs crates/fe2o3-functional-proof/tests/import_v2.rs \
    crates/fe2o3-lower-mir-kernel/src/production_semantic_kir_v1.rs \
    crates/fe2o3-verifier/src/conditional_output_evidence_v1.rs \
    crates/fe2o3-verifier/src/compiler_proof_binding_v3.rs \
    crates/fe2o3-verifier/src/compiler_target_lineage_v1.rs \
    crates/fe2o3-verifier/tests/compiler_proof_binding_v4.rs \
    crates/fe2o3-verifier/tests/support/conditional_output_evidence.rs \
    crates/fe2o3-verifier/src/conditional_output_verus_v1.rs crates/fe2o3-verifier/src/lib.rs \
    crates/rustc-codegen-fe2o3/src/production_semantic_lineage_v3.rs \
    crates/rustc-codegen-fe2o3/src/production_ranked_projection_v1.rs \
    crates/rustc-codegen-fe2o3/tests/production_extraction_driver_v1.rs >"$scratch/formatting.log" 2>&1
git diff --check >"$scratch/whitespace.log" 2>&1
