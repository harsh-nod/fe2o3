# Context Group Integration Developer Receipts

Source: e5a30e9e531d677a4a56b069fa950eece4ab118b
Parent: 2ecfa57e31c55fa9cf9b8e9c23aa5e16511d2694
Working directory: /home/harsh/.codex-tmp/fe2o3-r61-execution
Date: 2026-09-27

Final commands ran against the committed source. Only documentation changed
after final test compilation. Exits below were observed through the execution
tool. No test or proof result is inferred from file existence.

| Log | Command | Exit | Result |
| --- | --- | --- | --- |
| runtime-disposal-final.log | `cargo test -p fe2o3-runtime --all-features --lib context::tests::allocation_outcome_tests::disposal_tests` | 0 | 13 passed |
| model-final.log | `cargo test -p fe2o3-runtime-model --all-features` | 0 | 1067 passed, 19 ignored; 29 doctests passed |
| clippy.log | `cargo clippy -p fe2o3-runtime-model -p fe2o3-runtime --all-features --all-targets -- -D warnings` | 0 | Passed |
| runtime-serial.log | `cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1` | 101 | 1678 passed, 3 failed, 28 ignored |
| runtime-doc.log | `cargo test -p fe2o3-runtime --all-features --doc` | 0 | 8 merged and 44 separate doctests passed |
| model-minimal.log | `cargo check -p fe2o3-runtime-model --no-default-features` | 0 | Passed |
| fmt.log | `cargo fmt -p fe2o3-runtime -p fe2o3-runtime-model -- --check` | 0 | Passed |
| diff-check.log | `git diff --check` | 0 | Passed |
| source-signature.log | `git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD` | 0 | Source signature verified |
| mi300x-probe.log | `ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x true` | 255 | DNS resolution failed |
| origin-probe.log | `git ls-remote origin refs/heads/codex/r65-runtime-drain-versions` | 128 | DNS resolution failed |
| upstream-probe.log | `git ls-remote upstream refs/heads/codex/r65-runtime-drain-versions` | 128 | DNS resolution failed |

The full runtime run waited for Clippy compilation before test execution. It
failed only the existing authorized_execution tests
cooperative_debug_telemetry_emits_only_bounded_logical_records,
failed_session_end_is_explicit_and_terminal, and
pre_native_telemetry_failure_is_returned_and_poisoned at
authorized_execution.rs:1317 with InspectSocket(PermissionDenied).
No failure is waived or counted as passing. The runtime Worker deadline tests
passed in this final serial run; the previous checkpoint retains a parallel-run
deadline-tolerance failure separately.

runtime-disposal.log is an earlier development run (11 tests passed) before the
final Generated-domain branch, empty-arena fast paths and two new tests. It does
not qualify the final source. precommit-stat.log predates the final documentation
expansion; source-commit.log is the exact committed tree/stat identity.

Two read-only agents reviewed migration correctness, capacity equivalence,
Generated/synchronous separation, empty-reader count invariants and next shared
receipt integration. Their concrete suggestions were integrated; final review
found no release blocker. Review is not formal proof.

No Verus, mutation, relocation or source-bound proof campaign ran. The wrapper
composition and group transition remain unproved. No native GPU or HIP/HSA
performance run occurred, and the failed host probes created no remote files or
jobs. This is CPU regression evidence for current disjoint Context admission,
not shared queued-write, device-ordering, or performance qualification.
