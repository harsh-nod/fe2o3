#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
failed=0
run() {
    bash "$raw/run.sh" "$@" || failed=1
}
run requalified-source-before git diff --exit-code 108dfa8b1ed1b1ccb9113dac7f4932789721755e -- crates tools Cargo.toml Cargo.lock
if test "$failed" -ne 0; then exit 1; fi
run requalified-oracle cargo test -p fe2o3-kfd --all-features --lib production_dependency_owner_lane_envelope_and_teardown_shape_is_sealed -- --test-threads=1
run requalified-kfd-focused cargo test -p fe2o3-kfd --all-features --lib runtime_completion_cell_ -- --test-threads=1
run requalified-kfd cargo test -p fe2o3-kfd --all-features --lib -- --test-threads=1
run requalified-runtime-focused cargo test -p fe2o3-runtime --all-features --lib materialized_ -- --test-threads=1
run requalified-runtime cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1
run requalified-clippy cargo clippy -p fe2o3-runtime -p fe2o3-kfd --all-features --all-targets -- -D warnings
run requalified-no-default cargo check -p fe2o3-runtime -p fe2o3-kfd --no-default-features
run requalified-fmt cargo fmt --all -- --check
run requalified-mutations bash "$raw/check-mutations.sh"
run requalified-source-after git diff --exit-code 108dfa8b1ed1b1ccb9113dac7f4932789721755e -- crates tools Cargo.toml Cargo.lock
exit "$failed"
