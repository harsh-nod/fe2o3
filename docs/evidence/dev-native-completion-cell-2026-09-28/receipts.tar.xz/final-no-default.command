cargo check -p fe2o3-runtime -p fe2o3-kfd --no-default-features 
