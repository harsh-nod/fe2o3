cargo test -p fe2o3-kfd --all-features --lib -- --test-threads=1 
