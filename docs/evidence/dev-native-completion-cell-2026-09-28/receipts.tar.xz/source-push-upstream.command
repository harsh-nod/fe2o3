env GIT_TERMINAL_PROMPT=0 git push upstream HEAD:codex/r65-runtime-drain-versions 
