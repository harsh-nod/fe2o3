cargo test -p fe2o3-kfd --all-features --lib runtime_completion_cell_ -- --test-threads=1 
