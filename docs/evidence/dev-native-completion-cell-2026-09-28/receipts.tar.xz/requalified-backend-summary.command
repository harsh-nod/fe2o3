awk -f /home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08/backend-summary.awk /home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08/requalified-runtime.log 
