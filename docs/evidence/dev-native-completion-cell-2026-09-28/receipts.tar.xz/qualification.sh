#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
failed=0
run() {
    bash "$raw/run.sh" "$@" || failed=1
}
run final-source-before git diff --exit-code 6455855305d5000806cb23bca0264201cc454008 -- crates tools Cargo.toml Cargo.lock
if test "$failed" -ne 0; then exit 1; fi
run final-kfd-focused cargo test -p fe2o3-kfd --all-features --lib runtime_completion_cell_ -- --test-threads=1
run final-kfd cargo test -p fe2o3-kfd --all-features --lib -- --test-threads=1
run final-runtime-focused cargo test -p fe2o3-runtime --all-features --lib materialized_ -- --test-threads=1
run final-runtime cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1
run final-clippy cargo clippy -p fe2o3-runtime -p fe2o3-kfd --all-features --all-targets -- -D warnings
run final-no-default cargo check -p fe2o3-runtime -p fe2o3-kfd --no-default-features
run final-fmt cargo fmt --all -- --check
run final-source-after git diff --exit-code 6455855305d5000806cb23bca0264201cc454008 -- crates tools Cargo.toml Cargo.lock
exit "$failed"
