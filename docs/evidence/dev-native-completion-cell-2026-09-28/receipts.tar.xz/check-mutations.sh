#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08
prefix='test queue::live::tests::runtime_completion_tests::'
check() {
    local name=$1 passed=$2 failed=$3
    test "$(<"$raw/mutation-$name-test.status")" = 101
    rg -Fq 'Finished `test` profile' "$raw/mutation-$name-test.log"
    rg -xq 'running 9 tests' "$raw/mutation-$name-test.log"
    rg -Fq "test result: FAILED. $passed passed; $failed failed; 0 ignored; 0 measured; 1704 filtered out;" "$raw/mutation-$name-test.log"
    test "$(<"$raw/mutation-$name-diff.status")" = 0
    test -s "$raw/mutation-$name-diff.log"
    test "$(<"$raw/mutation-$name-restored.status")" = 0
    test ! -s "$raw/mutation-$name-restored.log"
}
failed_test() {
    rg -Fxq "$prefix$2 ... FAILED" "$raw/mutation-$1-test.log"
}
check pending 7 2
failed_test pending runtime_completion_cell_preserves_pending_ready_and_retired_occurrences
rg -Fq 'assertion failed: matches!(f.receipt, Receipt::Published(_))' "$raw/mutation-pending-test.log"
check ready 1 8
failed_test ready runtime_completion_cell_preserves_pending_ready_and_retired_occurrences
rg -Fq 'assertion failed: matches!(self.receipt, Receipt::Completed(_))' "$raw/mutation-ready-test.log"
check retry 6 3
failed_test retry runtime_completion_cell_genuine_pin_retry_preserves_then_reuses_generation
failed_test retry runtime_completion_cell_returned_custody_not_diagnostic_authorizes_retry
rg -Fq 'assertion failed: matches!(f.receipt, Receipt::Completed(_))' "$raw/mutation-retry-test.log"
check retired 3 6
failed_test retired runtime_completion_cell_preserves_pending_ready_and_retired_occurrences
rg -Fq 'assertion failed: matches!(&self.receipt, Receipt::Retired(o) if o.packet_count() == 1)' "$raw/mutation-retired-test.log"
for name in swallow classifier; do
    check "$name" 8 1
    failed_test "$name" runtime_completion_cell_recycle_faults_retain_generation_and_consuming_state
    rg -Fq 'assertion failed: f.recycle(&mut signals).is_err()' "$raw/mutation-$name-test.log"
done
test "$(<"$raw/final-kfd-focused.status")" = 0
rg -Fq 'test result: ok. 9 passed; 0 failed; 0 ignored;' "$raw/final-kfd-focused.log"
test "$(<"$raw/requalified-kfd-focused.status")" = 0
rg -Fq 'test result: ok. 9 passed; 0 failed; 0 ignored;' "$raw/requalified-kfd-focused.log"
test "$(<"$raw/requalified-oracle.status")" = 0
rg -Fq 'test result: ok. 1 passed; 0 failed; 0 ignored;' "$raw/requalified-oracle.log"
printf '%s\n' 'PASS: six compiled behavioral mutations, isolated restoration and restored nine-test baseline'
