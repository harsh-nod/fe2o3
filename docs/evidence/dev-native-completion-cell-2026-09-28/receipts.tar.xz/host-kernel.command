uname -srmo 
