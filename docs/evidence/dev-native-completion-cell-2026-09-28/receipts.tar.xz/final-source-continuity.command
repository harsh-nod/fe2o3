git diff --exit-code 108dfa8b1ed1b1ccb9113dac7f4932789721755e -- crates tools Cargo.toml Cargo.lock 
