#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
label=$1
bash "$raw/run.sh" "$label-diff" git diff HEAD -- crates
bash "$raw/run.sh" "$label-test" cargo test -p fe2o3-kfd --all-features --lib runtime_completion_cell_ -- --test-threads=1
