git diff HEAD -- crates 
