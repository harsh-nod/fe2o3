#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08
for name in source-before oracle kfd-focused runtime-focused clippy no-default fmt mutations source-after; do
    test "$(<"$raw/requalified-$name.status")" = 0
done
test ! -s "$raw/requalified-source-before.log"
test ! -s "$raw/requalified-source-after.log"
test "$(<"$raw/requalified-kfd.status")" = 101
test "$(<"$raw/requalified-runtime.status")" = 101
test "$(<"$raw/requalification.status")" = 1
rg -Fq 'test result: FAILED. 1712 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;' "$raw/requalified-kfd.log"
rg -Fxq 'test target_debug_telemetry_v2::tests::credential_bound_channel_accepts_typed_failure_before_publication ... FAILED' "$raw/requalified-kfd.log"
rg -Fq 'called `Result::unwrap()` on an `Err` value: SocketAdmission' "$raw/requalified-kfd.log"
rg -Fxq 'test queue::live::tests::production_dependency_owner_lane_envelope_and_teardown_shape_is_sealed ... ok' "$raw/requalified-kfd.log"
rg -Fq 'test result: FAILED. 1794 passed; 3 failed; 28 ignored; 0 measured; 0 filtered out;' "$raw/requalified-runtime.log"
for name in cooperative_debug_telemetry_emits_only_bounded_logical_records failed_session_end_is_explicit_and_terminal pre_native_telemetry_failure_is_returned_and_poisoned; do
    rg -Fxq "test authorized_execution::tests::$name ... FAILED" "$raw/requalified-runtime.log"
done
test "$(rg -Fc 'InspectSocket(Os { code: 1, kind: PermissionDenied, message: "Operation not permitted" })' "$raw/requalified-runtime.log")" = 3
rg -Fq 'test result: ok. 35 passed; 0 failed; 0 ignored;' "$raw/requalified-runtime-focused.log"
printf '%s\n' 'PASS: corrected-source gate receipts match four unwaived telemetry failures; aggregate qualification remains unsuccessful'
