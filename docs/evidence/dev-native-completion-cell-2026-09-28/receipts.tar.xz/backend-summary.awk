/^test kfd_backend::/ {
    if (pending) { malformed = 1; exit 2 }
    total++
    if (/ \.\.\. ok$/) passed++
    else if (/ \.\.\. ignored/) ignored++
    else if (/ \.\.\. FAILED$/) failed++
    else if (/ \.\.\. $/) pending = 1
    else malformed = 1
    next
}
pending && /^test / { malformed = 1; exit 2 }
pending && /^ok$/ { passed++; pending = 0 }
pending && /^FAILED$/ { failed++; pending = 0 }
END {
    printf "Runtime backend subset in full-suite log: %d registered, %d passed, %d failed, %d ignored, %d unresolved\n", total, passed, failed, ignored, pending
    if (malformed || pending || total != passed + failed + ignored || failed || passed != 897 || ignored != 28) exit 1
}
