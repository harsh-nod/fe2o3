bash /home/harsh/.codex-tmp/fe2o3-native-completion-cell-20260928-S4tzNg08/expanded.sh 
