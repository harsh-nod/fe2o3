target triple = "amdgcn-amd-amdhsa"
declare i32 @llvm.amdgcn.workgroup.id.x() #1
declare i32 @llvm.amdgcn.workitem.id.x() #1
define amdgpu_kernel void @fill_write_only(ptr addrspace(1) %data, i64 %length) #0 !reqd_work_group_size !0 {
entry:
  %local.i32 = call i32 @llvm.amdgcn.workitem.id.x()
  %group.i32 = call i32 @llvm.amdgcn.workgroup.id.x()
  %local = zext i32 %local.i32 to i64
  %group = zext i32 %group.i32 to i64
  %base = mul i64 %group, 64
  %index = add i64 %base, %local
  %value = trunc i64 %index to i32
  %guard = icmp ult i64 %index, %length
  %selected = select i1 %guard, i64 %index, i64 0
  %address = getelementptr i32, ptr addrspace(1) %data, i64 %selected
  br i1 %guard, label %store, label %end
store:
  store i32 %value, ptr addrspace(1) %address, align 4
  br label %end
end:
  ret void
}
attributes #0 = { nounwind "amdgpu-flat-work-group-size"="64,64" "target-features"="-wavefrontsize32,+wavefrontsize64,-xnack" "target-cpu"="gfx950" "denormal-fp-math-f32"="ieee,ieee" "unsafe-fp-math"="false" "no-infs-fp-math"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "approx-func-fp-math"="false" "fp-contract"="off" }
attributes #1 = { nounwind readnone speculatable willreturn }
!0 = !{i32 64, i32 1, i32 1}
