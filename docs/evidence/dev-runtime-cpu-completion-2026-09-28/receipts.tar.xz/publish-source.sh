#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-runtime-cpu-completion-20260928-qsZoMdU0
expected=f4b8985e7409055c1c22e9eef4c81de97a90ef96
branch=codex/r65-runtime-drain-versions
test "$(git rev-parse HEAD)" = "$expected"
git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
git diff --exit-code "$expected" -- crates Cargo.lock Cargo.toml rust-toolchain.toml
git diff --check
git status --short
git remote -v
for remote in origin upstream; do
    git push "$remote" "HEAD:refs/heads/$branch"
    git ls-remote --exit-code "$remote" "refs/heads/$branch" > "$out/$remote-source-head.log"
    read -r observed ref < "$out/$remote-source-head.log"
    test "$observed" = "$expected"
    test "$ref" = "refs/heads/$branch"
    printf 'verified %s %s %s\n' "$remote" "$observed" "$(date -u +%FT%TZ)"
done
printf 'source publication checks passed\n'
