"""Independent integer-quarter oracle; imports no runtime or Rust witness code."""
from functools import lru_cache
import hashlib
import struct

ELEMENTS = 65536
BYTES = ELEMENTS * 4


def descriptors(count):
    assert count in (4, 65, 4096)
    result = [(0, 0, 128), (128, 64, 128), (0, 0, 128), (512, 96, 68)]
    result.extend((4 * (1 + index * 13 % 10000),
                   4 * (257 + index * 17 % 40000), 4 * (1 + index % 17))
                  for index in range(4, count))
    assert len(result) == count
    assert all(size > 0 and (source | destination | size) % 4 == 0
               and source + size <= BYTES - 40
               and destination + size <= BYTES - 76
               for source, destination, size in result)
    return result


def floats(quarters):
    return struct.pack('<' + str(len(quarters)) + 'f', *(value / 4 for value in quarters))


@lru_cache(maxsize=6)
def oracle(count, direct):
    source = [(index % 64) + 4 * (index % 32) for index in range(ELEMENTS)]
    gathered = [1] * ELEMENTS
    for read, write, size in descriptors(count):
        first, out, length = (8 + read) // 4, (20 + write) // 4, size // 4
        gathered[out:out + length] = source[first:first + length]
    source_bytes, gathered_bytes = floats(source), floats(gathered)
    if direct:
        host = bytearray([0x5a]) * (BYTES + 273)
        host[97:97 + BYTES] = gathered_bytes
        snapshots = (source_bytes, gathered_bytes, host)
        domain = b'fe2o3.pending-segments-readback.v1\0'
    else:
        computed = floats([value + 2 * (index % 32)
                           for index, value in enumerate(gathered)])
        returned = bytearray([0xa5]) * (BYTES + 769)
        returned[131:131 + BYTES - 64] = computed[20:20 + BYTES - 64]
        host = bytearray([0x5a]) * (BYTES + 1153)
        host[97:97 + len(returned)] = returned
        snapshots = (source_bytes, gathered_bytes, computed, returned, host)
        domain = b'fe2o3.pending-segments-compute.v1\0'
    assert len(source_bytes) == len(gathered_bytes) == BYTES
    digest = hashlib.sha256(domain)
    for data in snapshots:
        digest.update(struct.pack('<Q', len(data)))
        digest.update(data)
    return digest.hexdigest()


def expected(count, late, direct, ids, settled=False):
    assert len(ids) == len(set(ids)) == 2 and not (late and direct)
    fields = dict(
        schema='fe2o3.pending-segments-readback.v1' if direct else 'fe2o3.pending-segments-compute.v1',
        authority='qualification-r57-n3-v2', devices='2', unique_ids=','.join(ids),
        elements=str(ELEMENTS), bytes=str(BYTES), descriptors=str(count),
        useful_bytes=str(sum(size for _, _, size in descriptors(count))),
        source_envelope='8,262104', destination_envelope='20,262068',
        descriptor_order='serial-last-writer-wins', duplicates='retained',
        caller_list='mutated-after-admission', launches='3' if direct else '4',
        setup_launches='2', pipeline_launches='1' if direct else '2',
        peer_copies='1' if direct else '2', segmented_copies='1', dependent_readbacks='1',
        completion_receipts='3' if direct else '5',
        pipeline='compute-segments-readback' if direct else 'compute-segments-deferred-compute-peer-readback',
        admission=('all-three-before-explicit-progress' if direct else
                   'consumer-after-list-publication' if late else 'all-five-before-explicit-progress'),
        progress='list-until-retained-then-final-readback-only' if late else 'final-readback-stream-only',
        late_consumer=str(late).lower(), publication_observed=str(late).lower(),
        retained_native_counter='0,1,0' if late else '0,0',
        public_events='released-after-dependent-admission', native_transport='NATIVE-XGMI',
        native_counter='0,1' if direct else '0,2', output='full-byte-pass',
        source_preservation='full-byte-pass', destination_frame='initialized-complement-checked',
        return_guards='not-applicable' if direct else 'full-byte-pass', host_guards='full-byte-pass',
        output_sha256=oracle(count, direct),
        digest='length-prefixed-source-input-host' if direct else 'length-prefixed-source-input-output-return-host',
        host_output_installations='0', journal='enabled', retained_results='3' if direct else '5',
        contexts='1', owners='1', pipeline_host_joins='0',
        results_release='readback-list-producer' if direct else 'readback-peer-consumer-list-producer',
        final_drain='completed-only', cleanup='owned-shutdown-explicit', physical_overlap='unmeasured',
        performance_acceptance='false', formal_refinement='false',
    )
    assert len(fields) == 48
    if settled:
        fields.update(
            schema='fe2o3.settled-segments-readback.v1' if direct else 'fe2o3.settled-segments-compute.v1',
            setup_launches='3', pipeline_launches='0' if direct else '1',
            completion_receipts='2' if direct else '4', retained_results='2' if direct else '4',
            pipeline='segments-readback' if direct else 'segments-deferred-compute-peer-readback',
            admission=('all-two-before-explicit-progress' if direct else
                       'consumer-after-list-publication' if late else 'all-four-before-explicit-progress'),
            results_release='readback-list' if direct else 'readback-peer-consumer-list',
            source_admission='settled-result-released', source_results_at_list_admission='0',
            source_events_supplied='0', source_stream='empty-before-and-after-admission',
        )
        assert len(fields) == 52
    return fields
