"""Bounded two-device settled-list frame qualification, not a performance claim."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
RAW = ROOT.parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'f9e8581ff77d210972ac733ae9e4fcf267234c0c'
ARCHIVE = 'docs/evidence/dev-unified-peer-segments-2026-10-02/raw.tar.xz'
ARCHIVE_SHA = '6964c627cc0794258fa40ee625bed3dd6cd6f8b30a4825f67aaec9c6c209d184'
HELPER_SHA = 'd22d7ee70a41a5e588e8c79455c8be7879928e42e59d80225de9cbd832197895'
TRANSPORT_SHA = '507ba3f408a423d698ebaf2ff8b9c83b4c33ba97a3bda16734643da298d7f20f'
CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
PREFIX = '/tmp/fe2o3-settled-frames-20261002-'
TARGETS = {'deferred': 'gfx942-runtime-deferred-peer-chain-smoke',
           'settled': 'gfx942-runtime-unified-segments-smoke'}
IDS = ['0x10a254ce4987e716', '0x53691ef168a0147d']
CASES = []
for mode, counts in (('settled-segments-compute', (4, 65, 4096)),
                     ('late-settled-segments-compute', (4,)),
                     ('settled-segments-readback', (4,)), ('segments-compute', (4,))):
    for count in counts:
        for direction, ids in (('forward', IDS), ('reverse', IDS[::-1])):
            CASES.append((f'{mode}-{count}-{direction}', 'deferred',
                          ['--' + mode, str(count), *ids]))
for case in ('packets',):
    for direction, ids in (('forward', IDS), ('reverse', IDS[::-1])):
        CASES.append((f'settled-{case}-{direction}', 'settled', [*ids, case]))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def helpers():
    """Reuse pinned transport/admission/oracle functions, never the old main."""
    blob = subprocess.check_output(['git', 'show', BASE + ':' + ARCHIVE], cwd=REPO)
    assert sha(blob) == ARCHIVE_SHA
    references = ((ROOT / 'reference' / 'campaign.py', 'raw/hardware-01/campaign.py', HELPER_SHA),
                  (ROOT / 'capture.py', 'raw/hardware-01/capture.py', TRANSPORT_SHA),
                  (ROOT / 'reference' / 'audit.py', 'raw/audit_hardware.py',
                   '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea'))
    with tarfile.open(fileobj=io.BytesIO(blob), mode='r:xz') as archive:
        for destination, name, expected in references:
            member = archive.getmember(name)
            assert member.isfile()
            data = archive.extractfile(member).read()
            assert sha(data) == expected
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists():
                assert not destination.is_symlink() and destination.read_bytes() == data
            else:
                with destination.open('xb') as output:
                    output.write(data)
    helper = load('settled_reference', references[0][0])
    # Only the location and source revision differ for these shared functions.
    helper.ROOT, helper.BASE = ROOT, BASE
    assert helper.IDS == IDS and helper.CARDS == ['card6', 'card7']
    assert helper.BDFS == ['0000:C6:00.0', '0000:E5:00.0']
    return helper


def build_identity(helper, kind, generation):
    target = TARGETS[kind]
    folder = RAW / ('build-' + kind + '-final-' + generation)
    receipt = json.loads((folder / 'receipt.json').read_text())
    command = json.loads((folder / 'command.json').read_text())
    assert all(receipt[key] == value for key, value in command.items())
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO)
    assert receipt['environment'] == helper.ENV
    assert receipt['controller_sha256'] == sha((RAW / 'capture.py').read_bytes()) == CAPTURE_SHA
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '900s',
        'cargo', 'build', '--locked', '--offline', '-p', 'fe2o3-runtime',
        '--no-default-features', '--features', 'hardware-qualification', '--example', target,
        '--profile', 'test', '--message-format=json']
    for name in ('stdout', 'stderr'):
        assert sha((folder / name).read_bytes()) == receipt[name + '_sha256']
    before = json.loads((folder / 'source-before.json').read_text())
    assert before == json.loads((folder / 'source-after.json').read_text()) == helper.source_snapshot()
    local = REPO / 'target/debug/examples' / target
    assert local.is_file() and not local.is_symlink()
    binary = local.read_bytes()
    assert binary.startswith(b'\x7fELF')
    identity = dict(sha256=sha(binary), byte_length=len(binary), target=target, test=False)
    assert receipt['executables'] == {str(local): identity}
    rows = [json.loads(line) for line in (folder / 'stdout').read_text().splitlines()]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'] is True
    artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['executable'] == str(local)
    assert artifacts[0]['target']['name'] == target and artifacts[0]['target']['kind'] == ['example']
    assert artifacts[0]['profile']['test'] is False
    return dict(local=str(local), sha256=identity['sha256'], byte_length=identity['byte_length'],
                build_receipt_sha256=sha((folder / 'receipt.json').read_bytes()),
                source_manifest_sha256=sha((folder / 'source-before.json').read_bytes()))


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2 and sys.argv[1].isdigit()
    generation = sys.argv[1]
    assert not (ROOT / 'campaign.json').exists()
    helper = helpers()
    oracle = load('pending_oracle', RAW / 'native_oracle.py')
    assert len(CASES) == len({name for name, _, _ in CASES}) == 14
    requirements = {}
    for name, kind, args in CASES:
        if kind == 'deferred':
            mode, count, *ids = args
            requirements[name] = oracle.expected(int(count), mode.startswith('--late-'),
                mode.endswith('segments-readback'), ids, settled='settled-' in mode)
        else:
            requirements[name] = helper.expected(args[-1], args[:2])
    binaries = {kind: build_identity(helper, kind, generation) for kind in TARGETS}
    completed, errors, directory, cleaned = [], [], None, False
    try:
        helper.BASELINE = json.loads(helper.remote('initial-availability', helper.AVAILABILITY))
        receipt, _, _ = helper.read_receipt('initial-availability', helper.remote_argv(helper.AVAILABILITY))
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(receipt['finished'])).total_seconds()
        assert 0 <= age <= 300
        helper.admit('baseline')
        candidate = helper.remote('create-scratch', ['/usr/bin/mktemp', '-d', PREFIX + 'XXXXXX']).strip()
        assert re.fullmatch(re.escape(PREFIX) + '[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
        for kind, binary in binaries.items():
            helper.capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            assert helper.remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
        for name, kind, args in CASES:
            helper.admit(name)
            binary = binaries[kind]
            assert helper.remote(name + '-hash', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
            output = helper.remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', binary['remote'], *args], '300s')
            fields = helper.pass_fields(output)
            assert fields == requirements[name], (name, fields, requirements[name])
            helper.admit(name + '-post')
            completed.append(dict(name=name, kind=kind, arguments=args, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [item['remote'] for item in binaries.values()]
                probe = ('import json,os,sys; from pathlib import Path; '
                    'targets=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe.removesuffix(" (deleted)") in targets: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = helper.remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    path = binary['remote']
                    exists = helper.remote('owned-executable-exists-' + kind, ['/usr/bin/python3', '-I', '-B', '-c',
                        'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))', path])
                    present = json.loads(exists)
                    assert present in ({'exists': True}, {'exists': False})
                    if present['exists']:
                        try:
                            assert helper.remote('final-hash-' + kind, ['/usr/bin/sha256sum', path]).split() == [binary['sha256'], path]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                        helper.remote('remove-owned-executable-' + kind, ['/usr/bin/rm', '--', path])
                    else:
                        errors.append('final hash: owned ' + kind + ' witness absent')
                helper.remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                helper.remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        if helper.BASELINE is not None:
            try:
                helper.admit('final')
            except Exception as error:
                errors.append('final admission: ' + repr(error))
        for kind, binary in binaries.items():
            try:
                assert build_identity(helper, kind, generation) == {key: value for key, value in binary.items() if key != 'remote'}
            except Exception as error:
                errors.append('final source/binary identity ' + kind + ': ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            selected_cards=helper.CARDS, selected_unique_ids=IDS, selected_bdfs=helper.BDFS,
            generation=generation, owned_directory=directory, owned_cleanup_complete=cleaned,
            native_process_timeout_seconds=300, transport_timeout_seconds=360,
            exclusive_reservation=False, performance_acceptance=False, formal_refinement=False,
            controller_sha256=sha(Path(__file__).read_bytes()), transport_sha256=TRANSPORT_SHA,
            helper_sha256=HELPER_SHA, oracle_sha256=sha((RAW / 'native_oracle.py').read_bytes()),
            limitations=['two selected devices, point observations, no exclusive reservation',
                         'finite R57 V2 constructor; not general application authority',
                         'one context per process; no repeat-context lifetime claim',
                         'initialized destination complement checked; hidden pool padding unobserved',
                         'ordered prefix semantics, not atomic transaction or native fault qualification',
                         'logical native completion, not physical overlap or performance parity',
                         'new adapter tested, not newly formally refined'])
        with (ROOT / 'campaign.json').open('x') as output:
            json.dump(result, output, indent=2)
            output.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
