"""Close fresh runtime qualification; distinguish unchanged baseline evidence."""
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile

import yaml

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'f9e8581ff77d210972ac733ae9e4fcf267234c0c'
CAPTURE = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
PINS = {
    'qualify.py': '0d63ee741a0025a436990db22d6519cf2edbbb36dc4702f158b7d93ce6ff5686',
    'audit_hardware.py': '4034e938da15be67c1730fd7f63bd94e3731abcb8abe428bfec61a80313c4280',
    'hardware-01/campaign.py': 'c0709fbdf9a12a17d4764b4f2e9eb62c124c08803d32b3a7d3060ffc9674e4db',
    'native_oracle.py': '8f652fcf5fc20b3dd0cb93e19127fb2d21116271d33d121c6fe6d0bf89c8bb2e',
    'source_controls_baseline.py': 'fb5b67b44ad85fd21792a2fe18f9bac60897033c8a37a51ea2fa5c04e0277a5c',
    'source_controls_final.py': '57b0d19228fd95ee5001b5d82759588277df1ea3c1c1d128f54573ee1a835112',
    'propose_metadata.py': '3cb88b3ad68e7bbc5ae643babc9e4ef8567d0f368513c41735021248263e8131',
}
CONTEXT_TESTS = '''settled_segments_empty_dependencies_hold_current_read_and_publish_full_frame
settled_segments_feed_read_only_compute_aliases_without_source_producer
settled_segments_capability_and_journal_are_independent_of_pending_compute_opt_in
settled_segments_do_not_reclassify_pending_or_unknown_source_as_initialized
settled_segments_require_exact_pending_list_event_and_read_only_frame_aliases
settled_segments_control_results_retain_real_depth_and_pending_controls_stay_legacy
settled_segments_exhausted_frame_depth_preserves_legacy_transfer
settled_segments_cancelled_or_failed_list_never_promotes_queued_readback
settled_segments_unknown_and_uncertain_faults_preserve_the_right_custody
settled_segments_admission_refunds_only_certified_preeffect_failures
settled_segments_validate_read_incarnation_origin_and_depth_before_observation'''.splitlines()
BACKEND_TESTS = '''settled_segments_full_frame_readback_prequeued_and_late_preserves_guards
settled_segments_compute_return_readback_uses_only_final_stream_and_exact_owners
settled_segments_frame_aliases_and_rejections_refund_without_native_effects
settled_segments_cancelled_parent_never_hands_off_compute_or_readback
settled_segments_exact_frame_rejects_plan_rank_and_endpoint_drift
settled_segments_native_fault_keeps_independent_frame_and_both_owners
settled_segments_restored_frame_outlives_source_release_before_compute_handoff
settled_segments_pending_controls_gate_frame_without_changing_endpoint_admission
settled_segments_completed_control_depth_preserves_legacy_transfer_limit
settled_segments_completed_native_copy_control_uses_its_retained_rank'''.splitlines()


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and sys.argv[1].isdigit() and sys.argv[2].isdigit()
    generation, proposal = sys.argv[1:]
    assert sha(RAW / 'capture.py') == CAPTURE
    for name, digest in PINS.items():
        assert sha(RAW / name) == digest
    capture = module('capture', RAW / 'capture.py')
    source = capture.snapshot()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
    qualify = module('qualification', RAW / 'qualify.py')
    jobs = [(name + '-final-' + generation, bound, argv) for name, bound, argv in qualify.JOBS]
    assert len(jobs) == 15
    summary = read(RAW / ('qualification-summary-' + generation + '.json'))
    assert summary == [dict(label=label, exit=0) for label, _, _ in jobs]
    verifier = RAW / ('proposal-' + proposal) / 'verify-applied.py'
    assert sha(verifier) == '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243'
    jobs += [
        ('metadata-final-before-' + generation, '120s', ['python3', '-I', '-B', str(verifier)]),
        ('metadata-final-after-' + generation, '120s', ['python3', '-I', '-B', str(verifier)]),
        ('source-controls-final-' + generation, '600s', ['python3', '-I', '-B', str(RAW / 'source_controls_final.py'), generation]),
        ('hardware-final-' + generation, '3600s', ['python3', '-I', '-B', str(RAW / 'hardware-01/campaign.py'), generation]),
        ('audit-native-final-' + generation, '120s', ['python3', '-I', '-B', str(RAW / 'audit_hardware.py'), generation]),
    ]
    selected = {}
    for label, bound, argv in jobs:
        folder = RAW / label
        receipt, command = (read(folder / name) for name in ('receipt.json', 'command.json'))
        assert all(receipt[key] == value for key, value in command.items()), label
        assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', bound, *argv], label
        assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, label
        assert receipt['base'] == BASE and receipt['cwd'] == str(REPO), label
        assert receipt['controller_sha256'] == CAPTURE and receipt['environment'] == capture.ENV, label
        assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == source, label
        assert datetime.fromisoformat(receipt['started']) <= datetime.fromisoformat(receipt['finished'])
        for output in ('stdout', 'stderr'):
            assert sha(folder / output) == receipt[output + '_sha256'], label
        selected[label] = dict(receipt_sha256=sha(folder / 'receipt.json'))
    counts = {}
    for kind in ('runtime', 'deferred', 'settled'):
        output = (RAW / (kind + '-tests-final-' + generation) / 'stdout').read_text()
        summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; 0 filtered out;', output, re.M)
        assert len(summaries) == 1 and summaries[0][1] == '0'
        passed, _, ignored = map(int, summaries[0])
        outcomes = re.findall(r'^test (.+?) \.\.\. (ok|ignored(?:, [^\n]*)?)$', output, re.M)
        roster = re.findall(r'^(.+): test$', (RAW / (kind + '-list-final-' + generation) / 'stdout').read_text(), re.M)
        assert len(roster) == len(set(roster)) == passed + ignored
        assert Counter(name for name, _ in outcomes) == Counter(roster)
        assert sum(status == 'ok' for _, status in outcomes) == passed
        assert ignored == (32 if kind == 'runtime' else 0)
        counts[kind] = dict(passed=passed, ignored=ignored)
    assert counts == {'runtime': {'passed': 2266, 'ignored': 32},
                      'deferred': {'passed': 20, 'ignored': 0},
                      'settled': {'passed': 3, 'ignored': 0}}
    archive_path = 'docs/evidence/dev-pending-peer-segments-2026-10-02/raw.tar.xz'
    blob = subprocess.check_output(['git', 'show', BASE + ':' + archive_path], cwd=REPO)
    assert hashlib.sha256(blob).hexdigest() == 'b5af0867a7a06f02b77c39d3b97dbb377396338635a5bed47c8e8921443bdcb1'
    with tarfile.open(fileobj=io.BytesIO(blob), mode='r:xz') as archive:
        old = archive.extractfile('raw/runtime-tests-final-02/stdout').read().decode()
        old_doctests = archive.extractfile('raw/doctests-final-02/stdout').read().decode()
        old_examples = {
            kind: archive.extractfile('raw/' + kind + '-list-final-02/stdout').read().decode()
            for kind in ('deferred', 'settled')
        }
        prior_source = json.loads(archive.extractfile('raw/metadata-final-after-02/source-before.json').read())
        prior_audit = json.loads(archive.extractfile('raw/audit-result.json').read())
        prior_controls = {
            member.name.removeprefix('raw/'): archive.extractfile(member).read()
            for member in archive.getmembers()
            if member.isfile() and member.name.startswith(('raw/source-controls-final-02/',
                                                           'raw/source-controls-final-02-commands/'))
        }
    assert prior_audit['accepted'] and prior_audit['source_controls'] == 32
    new_example_tests = {
        'deferred': {
            'segments::tests::settled_segment_cli_requires_distinct_explicit_provenance_modes',
            'segments::tests::settled_segment_reports_change_provenance_not_the_complete_byte_oracle',
        },
        'settled': set(),
    }
    for kind, previous in old_examples.items():
        before = re.findall(r'^(.+): test$', previous, re.M)
        after = re.findall(r'^(.+): test$',
            (RAW / (kind + '-list-final-' + generation) / 'stdout').read_text(), re.M)
        assert len(before) == len(set(before)) == (18 if kind == 'deferred' else 3)
        assert not (set(before) & new_example_tests[kind])
        assert set(after) == set(before) | new_example_tests[kind]
    current = (RAW / ('runtime-tests-final-' + generation) / 'stdout').read_text()
    ignored_pattern = r'^test (.+?) \.\.\. ignored(?:, [^\n]*)?$'
    assert len(re.findall(ignored_pattern, old, re.M)) == 32
    assert Counter(re.findall(ignored_pattern, old, re.M)) == Counter(re.findall(ignored_pattern, current, re.M))
    old_roster = set(re.findall(r'^test (.+?) \.\.\. ', old, re.M))
    new_roster = set(re.findall(r'^test (.+?) \.\.\. ', current, re.M))
    old_frame_test = 'kfd_backend::compute_xgmi::tests::segments::unified_segments_pending_envelope_is_not_scalar_compute_or_readback_coverage'
    new_frame_test = 'kfd_backend::compute_xgmi::tests::segments::unified_segments_missing_frame_cannot_promote_envelope_to_consumer_coverage'
    assert old_roster - new_roster == {old_frame_test}
    assert new_frame_test in new_roster - old_roster
    new_tests = sorted(new_roster - old_roster - {new_frame_test})
    assert new_tests == sorted([
        *('context::tests::compute_peer_tests::segments::settled::' + name for name in CONTEXT_TESTS),
        *('kfd_backend::tests::compute_peer_tests::segments::settled::' + name for name in BACKEND_TESTS),
    ])
    lower = {name: value for name, value in source.items() if name.startswith('crates/fe2o3-kfd/')}
    assert lower == {name: value for name, value in prior_source.items() if name.startswith('crates/fe2o3-kfd/')}
    for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'):
        assert source[name] == prior_source[name]
    report = read(verifier.parent / 'metadata-report.json')
    assert len(report['proof_files']) == 76
    invocation = read(verifier.parent / 'invocation.json')
    assert invocation['base'] == BASE
    assert invocation['wrapper_sha256'] == PINS['propose_metadata.py']
    assert invocation['solver_executed'] is invocation['build_executed'] is invocation['formal_qualification'] is False
    assert len(invocation['forwarding_methods']) == 4
    for row in report['changes']:
        original = subprocess.check_output(['git', 'show', BASE + ':' + row['path']], cwd=REPO)
        assert hashlib.sha256(original).hexdigest() == row['original_sha256']
        assert (verifier.parent / 'originals' / Path(row['path']).name).read_bytes() == original
        assert sha(REPO / row['path']) == row['proposed_sha256']
    for name, digest in report['proof_files'].items():
        previous = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=REPO)
        assert hashlib.sha256(previous).hexdigest() == digest == sha(REPO / name)
    for phase in ('before', 'after'):
        row = read(RAW / ('metadata-final-' + phase + '-' + generation) / 'stdout')
        assert row['ast_identical_except_recorded_metadata_literals'] and row['applied_guard_hashes_match_proposal']
        assert row['unchanged_proof_files'] == 76 and not row['formal_qualification']
    workflow = yaml.safe_load((REPO / '.github/workflows/runtime-component-source-guards.yml').read_text())
    commands = [(step['name'], shlex.split(line)) for step in workflow['jobs']['source-controls']['steps'] if 'run' in step for line in step['run'].splitlines()]
    assert len(commands) == 32
    baseline_prefix = 'source-controls-final-02/'
    baseline_read = lambda name: json.loads(prior_controls[baseline_prefix + name])
    baseline = baseline_read('receipt.json')
    baseline_command = baseline_read('command.json')
    assert hashlib.sha256(prior_controls[baseline_prefix + 'receipt.json']).hexdigest() == \
        prior_audit['selected_receipts']['source-controls-final-02']['receipt_sha256']
    assert all(baseline[key] == value for key, value in baseline_command.items())
    assert baseline['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '600s',
        'python3', '-I', '-B', '/home/harsh/.codex-tmp/fe2o3-pending-peer-segments-20261002/source_controls_final.py', '02']
    assert baseline['exit'] == 0 and baseline['source_unchanged'] is True
    assert baseline['base'] == prior_audit['base'] and baseline['cwd'] == str(REPO)
    assert baseline['controller_sha256'] == CAPTURE and baseline['environment'] == capture.ENV
    for output in ('stdout', 'stderr'):
        assert hashlib.sha256(prior_controls[baseline_prefix + output]).hexdigest() == baseline[output + '_sha256']
    baseline_source = baseline_read('source-before.json')
    assert baseline_source == baseline_read('source-after.json') == prior_source
    names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', BASE,
        '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=REPO).decode().rstrip('\0').split('\0')
    assert sorted(names) == sorted(baseline_source)
    blobs = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
        input=''.join(BASE + ':' + name + '\n' for name in sorted(baseline_source)).encode())
    offset = 0
    for name in sorted(baseline_source):
        end = blobs.index(b'\n', offset)
        _, kind, size = blobs[offset:end].split()
        assert kind == b'blob'
        offset, size = end + 1, int(size)
        assert hashlib.sha256(blobs[offset:offset + size]).hexdigest() == baseline_source[name]
        offset += size
        assert blobs[offset:offset + 1] == b'\n'
        offset += 1
    assert offset == len(blobs)
    for phase in ('baseline', 'final-' + generation):
        prefix = 'source-controls-final-02-commands/'
        folder = RAW / ('source-controls-' + phase + '-commands')
        control_bytes = lambda name: (prior_controls[prefix + name] if phase == 'baseline'
                                      else (folder / name).read_bytes())
        control = json.loads(control_bytes('summary.json'))
        assert control['accepted'] is True and control['solver_executed'] is False
        assert [(row['name'], row['command']) for row in control['commands']] == commands
        assert control['workflow_sha256'] == sha(REPO / '.github/workflows/runtime-component-source-guards.yml')
        assert control['controller_sha256'] == sha(RAW / 'source_controls_baseline.py')
        for index, row in enumerate(control['commands']):
            assert row['exit'] == 0 and json.loads(control_bytes(f'{index:02d}/receipt.json')) == row
            for output in ('stdout', 'stderr'):
                assert hashlib.sha256(control_bytes(f'{index:02d}/' + output)).hexdigest() == row[output + '_sha256']
    doctest = (RAW / ('doctests-final-' + generation) / 'stdout').read_text()
    docrows = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', doctest, re.M)
    assert list(map(int, docrows)) == [10, 51]
    doc_pattern = r'^test (crates/fe2o3-runtime/.+?) \.\.\. ok$'
    doc_names = re.findall(doc_pattern, doctest, re.M)
    old_doc_names = re.findall(doc_pattern, old_doctests, re.M)
    assert len(doc_names) == len(old_doc_names) == 61
    normalize_doc = lambda name: re.sub(r' \(line \d+\)', '', name)
    assert Counter(map(normalize_doc, doc_names)) == Counter(map(normalize_doc, old_doc_names))
    native = read(RAW / 'audit-native.json')
    assert native['accepted'] is True and native['cases'] == 14
    assert native['owned_cleanup_complete'] and not native['performance_acceptance'] and not native['formal_refinement']
    assert native['auditor_sha256'] == PINS['audit_hardware.py']
    assert read(RAW / ('audit-native-final-' + generation) / 'stdout') == {
        key: value for key, value in native.items() if key != 'native_events'}
    result = dict(accepted=True, base=BASE, source_files=len(source), counts=counts,
        new_runtime_tests=new_tests, doctests=61, source_controls=32, selected_receipts=selected,
        replaced_runtime_test={'old': old_frame_test, 'new': new_frame_test},
        native_audit_sha256=sha(RAW / 'audit-native.json'), native_cases=14,
        unchanged_proof_files=76, fresh_solver_execution=False, whole_adapter_verified=False,
        lower_kfd_freshly_tested=False, lower_kfd_unchanged_files=len(lower),
        lower_kfd_prior_evidence=archive_path, baseline_archive_sha256=hashlib.sha256(blob).hexdigest(),
        auditor_sha256=sha(Path(__file__)), performance_acceptance=False)
    with (RAW / 'audit-result.json').open('x') as output:
        json.dump(result, output, sort_keys=True, indent=2)
        output.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
