macro_rules! dispatch_cancel_binding_body {
    ($syntax:ident, $owner:ident, $identity:ident) => {
        $syntax!({ $owner.generation.next_generation = 0; $owner.generation.cancel_epoch($identity) })
    };
}
