#!/usr/bin/env python3
"""Independent final-result, source-continuity and process-group checks."""
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parent
expected = {"failure-final-2": (21, 21), "binding-final": (11, 21)}
reference = json.loads((root / "failure-final-2/source-before.json").read_text())
report = {"source_commit": reference["commit"], "source_hashes": len(reference["inputs"]), "campaigns": {}}
for name, (count, verified) in expected.items():
    directory = root / name
    results = json.loads((directory / "results.json").read_text())
    assert len(results) == count and all(row["passed"] is True for row in results.values())
    for side in ("before", "after"):
        assert json.loads((directory / ("source-" + side + ".json")).read_text()) == reference
    for stage in ("proof-before", "relocated-proof", "proof-after"):
        proof = json.loads((directory / stage / "stdout.log").read_text())["verification-results"]
        assert proof == {"encountered-error": False, "encountered-vir-error": False,
                         "success": True, "verified": verified, "errors": 0, "is-verifying-entire-crate": True}
    report["campaigns"][name] = {"stages": count, "verified": verified, "mutants": count - 8}
cpu = root / "cpu-final"
results = json.loads((cpu / "results.json").read_text())
assert len(results) == 9 and all(row["passed"] is True and row["status"] == 0 for row in results.values())
for side in ("before", "after"):
    assert json.loads((cpu / ("source-" + side + ".json")).read_text()) == reference
report["cpu"] = results
stopped = json.loads((root / "failure-final/omits-cancellation.json").read_text())
assert stopped == {"passed": False, "status": 1}
report["retained_warning_refusal"] = stopped
records = sorted(root.rglob("record.json"))
assert len(records) == 32 + 9 + 7
groups = []
for path in records:
    record = json.loads(path.read_text())
    assert record["group_absent"] is True and "exception" not in record
    group = record["process_group"]
    try:
        os.killpg(group, 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError("process group still exists: " + str(group))
    groups.append(group)
assert len(groups) == len(set(groups))
report["independently_absent_process_groups"] = groups
with (root / "final-audit.json").open("x") as output:
    json.dump(report, output, indent=2, sort_keys=True)
    output.write("\n")
print(f"PASS: 32 proof stages, 9 CPU/static stages, {len(groups)} absent groups")
