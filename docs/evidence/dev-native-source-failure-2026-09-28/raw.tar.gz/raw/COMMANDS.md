# Native Source Failure Qualification

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Raw output: this directory. No SSH/GPU command was run for this packet.

The first signed source is `859f0354b6f616bb7d63f147c629b690b9243810`.
The final source is `cbe547efadc1bae500424599d60263c319641cb7`.

## Development

`proof-dev-1` retains a frontend refusal for a ghost nat `+=` operation.
`proof-dev-2` uses explicit addition and verifies 21 obligations with no errors.
These are development observations, not signed campaign qualification.

The development verifier command used the pinned release below, with
`--crate-type lib --triggers-mode silent --no-cheating --output-json
--error-format=json --no-report-long-running --num-threads 4 --multiple-errors 2`
and the root `crates/fe2o3-runtime-model/verus/dependency_source_failure_v1.rs`.
`VERUS_Z3_PATH` was the sibling `z3`. Timeout was 120 seconds, foreground TERM
with a five-second KILL delay.

`kfd-build.log` records the all-feature KFD library no-run build.
The resulting owned test executable was run with `dependency_source_` and
`--test-threads=2` (13 passed), then `--skip construction_primary
--test-threads=2` (1421 passed, 320 filtered). Final Cargo reruns are below.

## Signed Campaigns

Use `python3 -I -B` for the checker:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-dependency-source-failure.py \
  --output "$RAW/failure-final" --verus "$VERUS"
```

`VERUS` was `/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus`.
`RAW` was `/home/harsh/.codex-tmp/fe2o3-source-dispatch-20260928-pbnMUKBF`.
The initial campaign stopped on an omitted-call mutant with two unused-macro
warnings plus a genuine postcondition failure. The strict checker was unchanged.
The mutant now keeps a syntactically referenced but unreachable call, preserving
the missing execution without unrelated diagnostics. The correction was signed.

At the final source, run sequentially:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-dependency-source-failure.py \
  --output "$RAW/failure-final-2" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-dependency-source-failure.py \
  --binding --output "$RAW/binding-final" --verus "$VERUS"
python3 -I -B "$RAW/qualify.py" /home/harsh/.codex-tmp/fe2o3-r61-execution
python3 -I -B "$RAW/audit-final.py"
```

Each campaign and the CPU driver record exact command argv, source hashes,
environment, exit status, elapsed time, and reaped process groups. The final
audit independently probes absence, including the stopped campaign groups.
The CPU driver checks exact test summaries; it does not accept a zero exit
status alone. The historical 22 epoch-cancellation mutants are not rerun here.

## Issue State

`gh issue view 182 --repo harsh-nod/fe2o3 --json number,title,state,updatedAt,url`
was checked on 2026-09-28 UTC with the configured TLS CA. It returned OPEN,
title `Runtime: build an asynchronous distributed direct-KFD execution plane`,
updatedAt `2026-09-27T10:25:24Z`.

## Archive

After all final commands terminate, copy this owned raw tree, create an inner
SHA256SUMS for every file, and produce raw.tar.gz. Independently extract to a
new owned temporary directory, check every hash and recursively compare with
the sealed source tree. Remove only that owned restored tree after validation.
