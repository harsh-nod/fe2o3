#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
out=/home/harsh/.codex-tmp/fe2o3-runtime-baseline-retest-20261001-2336
binary=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_runtime-6f56d726eb64a207
expected=1d9813aae38c72905bf9302e8cc1578333dba074fc24f2def70cca2fd8101b08
sha256sum "$binary" > "$out/binary-before.sha256"
read -r observed _ < "$out/binary-before.sha256"
if [[ "$observed" != "$expected" ]]; then
    printf '%s\n' 'binary hash mismatch; test not launched' > "$out/refusal.txt"
    exit 2
fi
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$out/started-utc.txt"
env -i PATH=/home/harsh/.cargo/bin:/usr/bin:/bin HOME=/home/harsh \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 TMPDIR=/tmp RUST_TEST_THREADS=1 \
    timeout --signal=TERM --kill-after=30s 600s \
    "$binary" --test-threads=1 \
    > "$out/runtime.stdout" 2> "$out/runtime.stderr"
status=$?
printf '%s\n' "$status" > "$out/runtime.exit"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$out/finished-utc.txt"
sha256sum "$binary" > "$out/binary-after.sha256"
read -r observed _ < "$out/binary-after.sha256"
if [[ "$observed" != "$expected" ]]; then
    printf '%s\n' 'binary hash changed during tests' > "$out/refusal.txt"
    exit 2
fi
exit "$status"
