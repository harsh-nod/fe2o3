#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/runtime-tests
elf=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_runtime-6f56d726eb64a207
expected=131229278c6ac7646d971fde9547ccc92e030b638ddd4425fe24fde98599d3e4
clean=(env -i PATH=/home/harsh/.cargo/bin:/usr/bin:/bin HOME=/home/harsh
    LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1)
overall=0
for suite in compute_xgmi full; do
    packet="$out/$suite"
    mkdir "$packet" || exit 2
    sha256sum "$elf" > "$packet/elf-before.sha256" || exit 2
    read -r measured ignored < "$packet/elf-before.sha256"
    if [[ "$measured" != "$expected" ]]; then
        printf '%s\n' 'ELF identity mismatch before execution' > "$packet/identity-error"
        exit 125
    fi
    "${clean[@]}" env > "$packet/environment.txt"
    if [[ "$suite" == compute_xgmi ]]; then
        command=("${clean[@]}" timeout --signal=TERM --kill-after=30s 300s "$elf" compute_xgmi --test-threads=1)
    else
        command=("${clean[@]}" timeout --signal=TERM --kill-after=30s 600s "$elf" --test-threads=1)
    fi
    printf '%q ' "${command[@]}" > "$packet/command.txt"
    printf '\n' >> "$packet/command.txt"
    date -u '+%Y-%m-%dT%H:%M:%S.%NZ' > "$packet/started.txt"
    "${command[@]}" > "$packet/stdout" 2> "$packet/stderr"
    status=$?
    printf '%s\n' "$status" > "$packet/exit"
    date -u '+%Y-%m-%dT%H:%M:%S.%NZ' > "$packet/finished.txt"
    sha256sum "$elf" > "$packet/elf-after.sha256" || exit 2
    read -r measured ignored < "$packet/elf-after.sha256"
    printf '%s exit=%s\n' "$suite" "$status"
    if [[ "$measured" != "$expected" ]]; then
        printf '%s\n' 'ELF identity mismatch after execution' > "$packet/identity-error"
        exit 125
    fi
    if [[ "$status" != 0 ]]; then
        overall=1
        if [[ "$suite" == compute_xgmi ]]; then
            printf '%s\n' 'Full suite not started because focused qualification failed.' > "$out/stopped.txt"
            break
        fi
    fi
done
printf '%s\n' "$overall" > "$out/exit"
exit "$overall"
