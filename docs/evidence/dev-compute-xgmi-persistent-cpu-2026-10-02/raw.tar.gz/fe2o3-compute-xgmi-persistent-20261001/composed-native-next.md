# Next CPU Test: Composed Persistent XGMI Custody

Date: 2026-10-01
Worktree: `/home/harsh/.codex-tmp/fe2o3-r61-execution`
Status: read-only source investigation and proposed next work, not implemented or executed.
No repository files were changed for this plan. The root agent's combined test build was still running.

## Target And Boundaries

Run the production `persistent::TransferRoot::execute` and production `TransferCore` map/copy/remap sequence against constructed, accounting-enabled memory and a real SDMA queue-owner ledger. Obtain the copy ticket and completed mappings only from the production SDMA submit/wait implementation. Retain the actual two model foundations through the production pair-loan sequencer.

This is the next CPU integration test if MI300X remains unavailable. It is not a substitute for the runtime two-GPU hardware witness or a final native-data-movement qualification. Do not add a production success bypass, public proof constructor, weaker preflight, runtime routing branch, or qualification framework.

Current six persistent tests execute production prepare/restore and pair-loan sequencing, but their operation callback does not execute the native transfer core. Existing lower map and SDMA tests exercise those components separately. This proposal closes that composition gap.

## Actual Blockers

1. `shared_memory.rs:4992`, `SharedGttMemorySessionV1`, fixes its engine to `SharedMemoryEngine<LinuxMemoryBackend>`. There is no CPU constructor for that concrete session. `PreparationMemoryFixtureV1` is a different type wrapping the real `SharedMemoryEngine<FakeBackend>` (`shared_memory/tests/preparation.rs:48`, `shared_memory.rs:8300`). Do not describe the existing fixture as a concrete SharedGtt session or forge a Linux backend.
2. `queue_live/compute_xgmi/persistent.rs:101`, `TransferRoot::execute<C>`, is already generic over `model_pair_loan::Context`. No abstraction change is needed at this ownership boundary. However, `transfer.rs:139`, `TransferCore::run`, accepts concrete Linux sessions and the native queue.
3. `sdma.rs:2198`, `Gfx942SdmaQueueOwnerV1::submit_xgmi`, still takes a concrete SharedGtt session and writes the doorbell directly. `sdma.rs:3573`, `wait_xgmi_for_in_current_scope`, already accepts `impl SdmaSingleMemoryV1`. Thus the real wait/completion path is already CPU-drivable, but the matching submit path is not.
4. `shared_memory/compute_xgmi_transition.rs` has generic real engine transitions (`local_unmap`, `peer_map`, `peer_unmap`, `local_map`), but its outer exact-roster, paired-currentness, and paired-panic-quarantine wrapper is concrete. A fixture must not duplicate or omit that wrapper and then claim full composition.
5. Existing memory fixture identities are not a valid two-GPU pair. `FakeBackend::gpu_id` at `shared_memory.rs:7463` returns 7; `model_correlation` at :7944 and `transferred_model_foundation_with_aperture` at :8021 hardcode one device/VM and aperture base `0x10000`. Two default fixtures also allocate overlapping GPU addresses, which real `submit_xgmi` correctly rejects.

## Minimal Private Execution Seams

Names below are proposed, not existing APIs.

### Transfer Core

In `queue_live/compute_xgmi/transfer.rs`, split the existing `run` body into `run_with(&mut impl ComputeXgmiTransferDriverV1, timeout)` plus the current concrete `run` forwarding through a native driver. Keep the ten steps, completed-extent check, and transfer of completed mappings back into the two roots in this one production implementation.

The private driver needs four operation families: local transition of one rooted buffer; exact peer transition of one rooted buffer; rooted submit of the two peer slots and copy custody; rooted wait into the same copy custody. It should carry the route internally. This is an operational driver, not a callback receiving only the Step enum and returning success. The test implementation must forward every operation to actual generic memory/SDMA algorithms below. The production adapter forwards through the unchanged native route checks.

Leave `persistent::TransferRoot::execute`, `prepare`, `restore`, and public admission/output publication semantics intact. Add the composed tests as a child of `persistent.rs` so they can inspect its private root without making it public. The decisive invocation is structurally:

```rust
root.execute(&mut pair_context, |context, core| {
    core.run_with(&mut context.transfer_driver(), timeout)
})
```

Here `pair_context.open/retake` perform actual `primary_loan/primary_reclaim`; they are not counter-only mocks. Avoid a self-borrowing design: the context owns or borrows two endpoint records and a peer queue, and `transfer_driver()` temporarily borrows those disjoint fields.

### Shared Memory

Keep the existing generic engine transitions in `shared_memory/compute_xgmi_transition.rs`. Extract the body of `transition_compute_xgmi_peer_v1` into one private generic pair helper whose environment supplies the two engines plus native route observations. Both the Linux wrapper and cfg(test) fixture must use that helper. Preserve, in order:

- exact retained roster equality before effects;
- distinct engine GPU IDs and canonical pair equality;
- each endpoint's retained directed route equality and currentness observation;
- peer engine currentness before and after the transition;
- the real borrowed map/unmap transition and its returned-prefix bookkeeping;
- outer error/panic quarantine of both phases, regardless of optional accounting;
- invalidation of `map_succeeded` on an indeterminate paired result.

Use the existing `with_compute_transition` for local transitions and preserve `with_device_backing_pair_unwind_quarantine` (`shared_memory.rs:1273`) for configured accounts. Do not replace the unconditional outer phase quarantine with this accounting-conditional wrapper.

For rooted submit/wait route checks, retain the existing production behavior of `validate_gfx942_xgmi_route_with_peer` and `validate_route_currentness` (`shared_memory.rs:5733`, `sdma.rs:5044`). A private generic route observation adapter may substitute only native observations in tests. The native implementation must call the existing full currentness check, and the fixture implementation must authenticate endpoint IDs, retained route, memory phases, and injected currentness results. Do not make an always-Ok test implementation stand in for those checks. If sharing that guarded wrapper requires more refactoring than the bounded change allows, explicitly narrow the first test claim to the shared ownership/transition core; do not silently claim the concrete Linux route-validation wrapper was exercised.

Expose cfg(test)-only forwarding methods on `PreparationMemoryFixtureV1` for these shared operations and for mapped-XGMI facts. Facts must come from the actual engine record and the fully-mapped lease, not fabricated addresses.

### SDMA Submit And Rooted Custody

Change the private `submit_xgmi` memory argument to `impl SdmaSingleMemoryV1`, following ordinary single-copy publication in the same file. Its existing trait already supplies control counters, host facts, completion reset, ring write, control publication, and completion observation (`sdma/single_copy.rs:7`). Replace the concrete `mapped_resource_facts` call with `single_host_facts`.

Route doorbell publication through a private hook, following `single_doorbell` (`single_copy.rs:44`). Preserve the current preallocation of the doorbell error string before moving mappings and its `Doorbell` error classification; simply replacing it with the default trait error would change diagnostics. The hook must remain allocation-free after publication admission. Native behavior remains the same actual `LinuxDoorbellSliceV1::store_packet_id_release` operation.

Factor `sdma/compute_xgmi.rs:85` and :155 into private generic borrowed helpers used by the existing concrete methods and the fixture driver. Keep live-owner checks, empty custody checks, exact roster/extent checks, opening/closing route checks, ticket rooting, uncertain-ticket recovery, and `retain_completion_then_check` in shared code. Do not manufacture `Gfx942SdmaCopyTicketV1` or `Gfx942XgmiCompletedCopyV1` in the composed test.

The real submit must move both mappings into `owner.xgmi_records[slot]` before any reset/ring/control/doorbell operation can panic. The real wait must remove that exact record only after authenticating its ticket and observing its completion. The completed value must be in `ComputeXgmiCopyCustodyV1` before a closing route check can fail or unwind.

## Constructed Pair And Queue

Add a cfg(test)-only endpoint constructor to `PreparationMemoryFixtureV1`/`BackingConstructorFixture`. Parameterize the model correlation, admitted GPU identity, VM identity, engine backend GPU ID, GPU-VA base, and projection rejection address consistently. Defaults remain unchanged for all existing tests. Use disjoint VA ranges and separate native handles/session identities.

Use `topology::tests::admitted_xgmi_routes()` (`topology.rs:2819`) rather than a new route proof constructor. This discovers a local filesystem topology fixture and calls the real route admission API; its GPU IDs are **1001 and 1002**, not 7 and 9. Construct endpoints matching these IDs, the selected directed route, and its recommended SDMA engine. Both endpoints must retain the same selected directed route. This involves no GPU or network access.

`sdma/retained_release/fixture.rs:26` (`generic`) and :75 (`creation_owners`) already allocate, initialize, map, and retain real ring/control/completion resources, real queue record vectors, and an anonymous local doorbell. Add a small cfg(test) helper within the SDMA module to obtain one owner with the admitted XGMI engine and wrap/drive it; do not export the owner publicly. This is an already-constructed queue fixture, not proof that native queue creation succeeded.

If creation custody is included, reuse `sdma/xgmi_creation.rs:152` (`create_with`) and its established native-leaf fixture (`xgmi_creation/tests.rs:174`, `finish_native_attempt`). Native ioctl outputs and doorbell mappings are simulated there, with production result validation. Creation integration is optional for the first transfer-only test and must not be conflated with real native creation.

`PreparationMemoryFixtureV1::enable_sdma_mapped_bytes_v1` (`shared_memory/tests/sdma_single.rs:93`) enables actual mapped ring/control/completion byte operations. The existing forwarding pattern is `construction_primary/integration_sdma_synchronous_tests.rs:78`; its completion-observation hook (:175) and doorbell hook (:200) are directly reusable patterns.

## Real Owners, Foundations, And Accounting

Keep `configured=true` in the primary success/failure cases. `PreparationMemoryFixtureV1::observation` (`preparation.rs:306`) captures actual device/host backing usage and engine records. Do not use the current `local_mapping_with_extent_for_persistent_sdma_test` synthetic lease constructor for this composed test.

A bounded transfer-only setup can build SDMA control resources before transferring the two initially empty model foundations (`primary_transfer`, `primary_construction.rs:347`), then loan each foundation while allocating its device lease. This avoids passing an incomplete device roster to `validate_complete_dispatch_device_memory_set`. Allocate and initialize PUBLIC backing using the actual engine operations behind `PreparationMemoryFixtureV1::device(true)` (:223); add a size-parameterized test helper for this existing path. The retained initialization metadata must be derived from that real initialization result. Reclaim the foundations afterward.

Build ordinary SDMA buffer metadata around those real leases, using the existing test-only buffer constructor only for metadata. Then use the production `promote_directional_persistent_sdma_custody_v1` (`persistent_directional_sdma.rs:1943`) with exact observed directional queue IDs and outstanding count. This constructs the original persistent owners once. There must be no demote/promote inside the XGMI transfer.

For a broader constructed endpoint setup, reuse `AllocationParent` plus `allocate_classified_in_place(PublicDevice)` (`construction_primary/integration_sdma_public_allocation_tests.rs:5`) and `promote_in_place` (`integration_sdma_promotion_tests.rs`). The already-constructed compute parent is `constructed_on_gate` (`integration_release_tests.rs:253`); it is also fixture-generic, not a concrete ComputeAql session. Test-only helper exports would be necessary across module privacy boundaries. This broader allocation/H2D construction path is useful but not required to close the first transfer composition gap.

The pair context must call actual `primary_loan` and `primary_reclaim` (`primary_construction.rs:376`, :394), and validate `primary_loan_state_v1` (:409). A successful transfer increments both loan generations and restores both certified foundations. Inject error/panic before and after each real reclaim, then inspect the retained root after execution returns/unwinds: neither persistent owner may already have its local backing restored. This avoids an invalid simultaneous context borrow of the mutably borrowed root. The successful test checks both certified foundations and both restored owners after return. Only after the second retake may `TransferRoot::restore` restore the two owners.

Use equal logical length 2048 with source/destination physical extents 4096/8192. Snapshot original persistent identity, generation, ledger identity, storage identity, attachment certificate, logical length, physical length/alignment, and account usage before admission. Assert all identities and extents are unchanged afterward and the packet's length is 2048. No device or host account refund may occur during map/copy/remap. After success assertions, explicit normal fixture cleanup may release backing and verify zero usage. Terminal cases retain the debits and rooted resources and must not try normal cleanup/retry; only clean anonymous test mappings under the established fixture convention, without pretending native custody was released.

## Minimal Initial Cases

1. Full successful composition with real source/destination records, real exact-pair map/unmap calls, packet publication, ticket, observed completion, both model retakes, and original persistent owners restored. Repeat with accounts absent to check optional-accounting semantics, not merely a second happy-path enum trace.
2. Partial or panicking second peer-map operation: first and second inputs remain rooted in their distinct actual states; both endpoints are terminal; optional-accounting absence does not prevent phase quarantine.
3. Error/panic after ring/control/doorbell publication starts: the real queue record retains both mappings and its uncertain ticket; no completed value or restored output is minted; backing debits remain.
4. Closing route-check error/panic after real submit and after real wait: respectively verify rooted ticket/record and rooted completed mappings. These are distinct custody boundaries.
5. Timeout or wrong completion value through real wait: retain the published mappings in the queue, terminalize the pair, and restore neither persistent owner.
6. First/second model-retake error/panic after a fully successful lower copy: local remapped leases remain in the transfer root; neither persistent owner is restored; both original accounting debits remain.

Success completion injection must happen only after the test observes the actual packet, control write, and local doorbell publication. Decode/assert the exact source/destination addresses, logical copy length, fence address, and expected completion generation; then write that completion value into the real mapped completion arena and let production wait reclaim the record. Do not return a fabricated completed object. The native-leaf shim may inject failures before/after the same actual mapped-byte operations, as the existing synchronous test does.

## Explicit Non-Claims

- FakeBackend models kernel map/unmap results; it does not perform AMD GPU VM operations.
- Writing a completion fence in the CPU fixture proves publication/custody/completion control flow, not device-to-device byte movement or hardware visibility ordering.
- Existing FakeBackend device mappings do not by themselves provide a persistent, GPU-address-indexed byte store across all device unmaps/remaps. Adding a simulated byte-copy engine is not required for this custody test and would still not prove hardware movement.
- A direct TransferRoot test does not exercise the concrete public ComputeAql preflight, runtime retained-cache retirement, asynchronous scheduling, or native queue creation/destruction unless separately composed. Preserve their existing tests and the hardware witness.
- No test was run and no implementation was made for this plan. The verified source remains frozen for the current combined build.
