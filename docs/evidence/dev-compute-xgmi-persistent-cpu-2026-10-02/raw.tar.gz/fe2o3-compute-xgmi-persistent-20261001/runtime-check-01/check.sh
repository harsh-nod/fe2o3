#!/bin/bash
set -u
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/runtime
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/check.started"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 timeout --signal=TERM --kill-after=30s 600s cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-runtime --all-features --lib --tests --example gfx942-runtime-compute-xgmi-smoke > "$out/check.stdout" 2> "$out/check.stderr"
status=$?
printf '%s\n' "$status" > "$out/check.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/check.finished"
exit "$status"
