#!/bin/bash
set -u
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/verification-final
mkdir -p "$out"
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
export HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8
export CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1
failed=0
stage() {
    name=$1
    seconds=$2
    shift 2
    printf '%q ' "$@" > "$out/$name.command"
    printf '\n' >> "$out/$name.command"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$out/$name.started"
    timeout --signal=TERM --kill-after=30s "$seconds" "$@" > "$out/$name.stdout" 2> "$out/$name.stderr"
    status=$?
    printf '%s\n' "$status" > "$out/$name.exit"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$out/$name.finished"
    printf '%s exit=%s\n' "$name" "$status"
    if [ "$status" -ne 0 ]; then failed=1; fi
}
stage no-default 300s cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-runtime --no-default-features --lib
stage example 1200s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --all-features --example gfx942-runtime-compute-xgmi-smoke -- --test-threads=1
stage formatting 120s rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true crates/fe2o3-kfd/src/persistent_allocation.rs crates/fe2o3-kfd/src/queue_live/compute_xgmi.rs crates/fe2o3-kfd/src/queue_live/compute_xgmi/transfer.rs crates/fe2o3-kfd/src/queue_live/compute_xgmi/persistent.rs crates/fe2o3-kfd/src/queue_live/rebind_tests/insertion.rs crates/fe2o3-kfd/src/queue_live/construction_primary/integration_sdma_public_allocation_tests.rs crates/fe2o3-kfd/src/sdma/compute_xgmi.rs crates/fe2o3-runtime/src/kfd_backend.rs crates/fe2o3-runtime/src/kfd_backend/compute_xgmi.rs crates/fe2o3-runtime/src/kfd_backend/compute_xgmi/tests.rs crates/fe2o3-runtime/src/kfd_backend/multi_qualification.rs crates/fe2o3-runtime/examples/gfx942-runtime-compute-xgmi-smoke.rs
stage whitespace 60s git diff --check
printf '%s\n' "$failed" > "$out/overall.exit"
exit "$failed"
