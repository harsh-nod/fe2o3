#!/bin/bash
set -u
artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/kfd
elf=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-893183054f25e631
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
sha256sum "$elf" > "$artifact_dir/tests-elf-before.sha256"
overall=0
for filter in compute_xgmi model_pair_loan; do
    date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$filter.started-utc.txt"
    timeout --signal=TERM --kill-after=10s 300s env -i HOME=/home/harsh \
        PATH=/home/harsh/.cargo/bin:/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8 \
        RUST_TEST_THREADS=1 "$elf" "$filter" --test-threads=1 \
        > "$artifact_dir/$filter.stdout" 2> "$artifact_dir/$filter.stderr"
    status=$?
    printf '%s\n' "$status" > "$artifact_dir/$filter.exit"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$filter.finished-utc.txt"
    if [[ "$status" != 0 ]]; then overall=$status; fi
done
sha256sum "$elf" > "$artifact_dir/tests-elf-after.sha256"
exit "$overall"
