# Corrected KFD Validation

Status: all requested KFD focused tests, strict combined Clippy, and normal witness build passed. This is not a full KFD suite or GPU qualification.

## Source Correction

Only two KFD test files were changed after the rejected `kfd-final` initialized run:

- `crates/fe2o3-kfd/src/queue_live/rebind_tests/insertion.rs`: retained the whole-module allocation/map custody ordering and no-initialization checks. Restricted the PUBLIC/new-public ban to the actual ordinary constructor, shared wrapper, ordinary request arm, insertion adapter, settled helper, and fixed-dispatch entry point. Added exact PRIVATE/PUBLIC constructor and request-arm wiring assertions.
- `crates/fe2o3-kfd/src/queue_live/construction_primary/integration_sdma_public_allocation_tests.rs`: asserted fresh PUBLIC buffers are uninitialized and lack content certificates; added a private/public/private constructed allocation sequence checking exact flags and unchanged uninitialized state, followed by normal release/accounting cleanup.

No production behavior was changed by this correction. Both files were rustfmt-formatted, and `git diff --check` passed before rebuilding. No source changed during or after the corrected build. The root agent's separate two formatting-only changes preceded this build.

The old 62-pass/1-fail initialized result and raw evidence remain preserved in `../kfd-final`; they were not reclassified as accepted.

## Exact Build

`build-command.sh` records the clean environment and exact combined locked/offline all-feature KFD/runtime library-test no-run command. Result: exit 0, optimized test profile, 3m 51s, under a 2400-second bound.

Final unit-test artifacts:

- KFD: `/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-408178a9a9b41651`
- KFD SHA256: `9bd96d9427dc92eb6fffb697e9f425602fa49f7d4f6aab1464cd780549361c9b`
- Runtime: `/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_runtime-6f56d726eb64a207`
- Runtime SHA256: `55d1270bc198e67902a34d4fed47a79f13ef6c36753729e036553105a99c0658`

Both final hashes were unchanged after Clippy and normal witness compilation (`build-elf.sha256` equals `unit-test-elf-after-tooling.sha256`). The runtime artifact was handed to the separate runtime validation agent after this build terminated.

## Direct KFD Tests

`tests-command.sh` and `tests-invocation.txt` record the exact commands. Each filter used a clean HOME/PATH/LANG/LC_ALL/RUST_TEST_THREADS environment, serial test threads, a 300-second bound, and no `--ignored`. Exact rosters, raw stdout/stderr, exit status, timestamps, and ELF hashes before/after every list and test run are present here. Every hash matched the final KFD artifact above.

| Filter | Passed | Failed | Ignored | Filtered | Time | Exit |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| initialized | 63 | 0 | 0 | 1825 | 126.08s | 0 |
| compute_xgmi | 25 | 0 | 0 | 1863 | 0.05s | 0 |
| model_pair_loan | 7 | 0 | 0 | 1881 | 0.00s | 0 |
| public_sdma | 6 | 0 | 0 | 1882 | 2.46s | 0 |
| constructed_sdma_allocation_success_preserves_extents_owners_and_refunds | 1 | 0 | 0 | 1887 | 1.73s | 0 |

The initialized roster includes the repaired ordinary-allocation source guard, all 13 initialized-storage conversion tests, and direct corrupt-prefix rejection. These cover both the prior compute-conversion contract around the extracted shared preflight helper and the surrounding custody regressions. The six PUBLIC cases cover native flags/refunds, retained owners after retake failures, settled capacity rejection, private/public/private allocation isolation, exact-flag pool best fit, and opposite-profile pool misses. The separate ordinary allocation test preserves private-device and HostVisible baseline behavior.

## Strict Clippy

`clippy-command.sh` records combined KFD/runtime all-feature library/tests/example Clippy with `--no-deps -- -D warnings`. Result: exit 0 in 1m 20s. No source correction was needed.

## Normal Witness Binary

`witness-build-command.sh` records the normal executable build, not just its unit-test harness:

`cargo +nightly-2026-04-03 build --locked --offline -p fe2o3-runtime --all-features --profile test --example gfx942-runtime-compute-xgmi-smoke`

Result: exit 0 in 9.41s, optimized test profile, under a 1200-second bound.

Binary: `/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/examples/gfx942-runtime-compute-xgmi-smoke`

SHA256: `99a28ea37d60f7dfa2c3f93b9cab0c6c612f76f0e29cb072bcf53178c002e844`

The normal witness binary was not executed. No GPU, SSH, or network operation was performed by this validation. Hardware data movement and the proposed composed-native CPU integration test remain unqualified by this packet.
