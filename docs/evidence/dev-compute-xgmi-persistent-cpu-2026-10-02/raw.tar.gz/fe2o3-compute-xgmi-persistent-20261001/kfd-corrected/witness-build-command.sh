#!/bin/bash
set -u
artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/kfd-corrected
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
printf '%s\n' "$PWD" > "$artifact_dir/witness-build.cwd.txt"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 /usr/bin/env \
    > "$artifact_dir/witness-build.environment.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/witness-build.started-utc.txt"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 \
    timeout --signal=TERM --kill-after=10s 1200s \
    cargo +nightly-2026-04-03 build --locked --offline \
    -p fe2o3-runtime --all-features --profile test \
    --example gfx942-runtime-compute-xgmi-smoke \
    > "$artifact_dir/witness-build.stdout" 2> "$artifact_dir/witness-build.stderr"
status=$?
printf '%s\n' "$status" > "$artifact_dir/witness-build.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/witness-build.finished-utc.txt"
if [[ "$status" == 0 ]]; then
    sha256sum /home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/examples/gfx942-runtime-compute-xgmi-smoke \
        > "$artifact_dir/witness-binary.sha256"
fi
sha256sum \
    /home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-408178a9a9b41651 \
    /home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_runtime-6f56d726eb64a207 \
    > "$artifact_dir/unit-test-elf-after-tooling.sha256"
printf 'normal witness build exit=%s\n' "$status"
exit "$status"
