#!/bin/bash
set -u
artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/kfd-corrected
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
printf '%s\n' "$PWD" > "$artifact_dir/clippy.cwd.txt"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 /usr/bin/env \
    > "$artifact_dir/clippy.environment.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/clippy.started-utc.txt"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 \
    timeout --signal=TERM --kill-after=10s 1200s \
    cargo +nightly-2026-04-03 clippy --locked --offline \
    -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --tests \
    --example gfx942-runtime-compute-xgmi-smoke --no-deps -- -D warnings \
    > "$artifact_dir/clippy.stdout" 2> "$artifact_dir/clippy.stderr"
status=$?
printf '%s\n' "$status" > "$artifact_dir/clippy.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/clippy.finished-utc.txt"
printf 'corrected combined clippy exit=%s\n' "$status"
exit "$status"
