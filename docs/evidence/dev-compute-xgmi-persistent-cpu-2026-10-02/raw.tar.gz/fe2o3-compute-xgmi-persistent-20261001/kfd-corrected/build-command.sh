#!/bin/bash
set -u
artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/kfd-corrected
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
printf '%s\n' "$PWD" > "$artifact_dir/build.cwd.txt"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 /usr/bin/env \
    > "$artifact_dir/build.environment.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/build.started-utc.txt"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 \
    CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
    CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true \
    CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 \
    timeout --signal=TERM --kill-after=10s 2400s \
    cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --no-run \
    > "$artifact_dir/build.stdout" 2> "$artifact_dir/build.stderr"
status=$?
printf '%s\n' "$status" > "$artifact_dir/build.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/build.finished-utc.txt"
printf 'corrected combined build exit=%s\n' "$status"
exit "$status"
