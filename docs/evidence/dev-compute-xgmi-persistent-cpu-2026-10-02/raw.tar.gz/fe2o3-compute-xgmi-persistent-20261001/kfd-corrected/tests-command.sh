#!/bin/bash
set -u
artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/kfd-corrected
elf=$1
expected=$2
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
printf '%s\n' "$PWD" > "$artifact_dir/tests.cwd.txt"
printf '%s  %s\n' "$expected" "$elf" > "$artifact_dir/tests.expected-elf.sha256"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1 /usr/bin/env \
    > "$artifact_dir/tests.environment.txt"
verify_elf_hash() {
    sha256sum "$elf" > "$1" || return 1
    read -r digest path < "$1"
    [[ "$digest" == "$expected" ]]
}
if ! verify_elf_hash "$artifact_dir/tests.elf-initial.sha256"; then exit 125; fi
overall=0
for filter in initialized compute_xgmi model_pair_loan public_sdma constructed_sdma_allocation_success_preserves_extents_owners_and_refunds; do
    if ! verify_elf_hash "$artifact_dir/$filter.list.elf-before.sha256"; then exit 125; fi
    env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
        LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1 \
        timeout --signal=TERM --kill-after=10s 300s \
        "$elf" "$filter" --list --test-threads=1 \
        > "$artifact_dir/$filter.list.stdout" 2> "$artifact_dir/$filter.list.stderr"
    status=$?
    printf '%s\n' "$status" > "$artifact_dir/$filter.list.exit"
    if ! verify_elf_hash "$artifact_dir/$filter.list.elf-after.sha256"; then exit 125; fi
    if [[ "$status" != 0 ]]; then overall=$status; fi

    if ! verify_elf_hash "$artifact_dir/$filter.elf-before.sha256"; then exit 125; fi
    date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$filter.started-utc.txt"
    env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
        LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1 \
        timeout --signal=TERM --kill-after=10s 300s \
        "$elf" "$filter" --test-threads=1 \
        > "$artifact_dir/$filter.stdout" 2> "$artifact_dir/$filter.stderr"
    status=$?
    printf '%s\n' "$status" > "$artifact_dir/$filter.exit"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$filter.finished-utc.txt"
    if ! verify_elf_hash "$artifact_dir/$filter.elf-after.sha256"; then exit 125; fi
    if [[ "$status" != 0 ]]; then overall=$status; fi
    printf '%s exit=%s\n' "$filter" "$status"
done
if ! verify_elf_hash "$artifact_dir/tests.elf-final.sha256"; then exit 125; fi
printf '%s\n' "$overall" > "$artifact_dir/tests.overall.exit"
exit "$overall"
