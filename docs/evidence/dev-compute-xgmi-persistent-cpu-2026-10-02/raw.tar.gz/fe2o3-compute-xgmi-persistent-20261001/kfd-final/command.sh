#!/bin/bash
set -u
artifact_dir=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/kfd-final
elf=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-408178a9a9b41651
expected=bc2f6c09ba646010e9b1ae15d572970dadda3f163bf807b680d06b8fc5b418b7
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
printf '%s\n' "$PWD" > "$artifact_dir/cwd.txt"
printf '%s  %s\n' "$expected" "$elf" > "$artifact_dir/expected-elf.sha256"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1 /usr/bin/env \
    > "$artifact_dir/environment.txt"
verify_elf_hash() {
    sha256sum "$elf" > "$1" || return 1
    read -r digest path < "$1"
    [[ "$digest" == "$expected" ]]
}
if ! verify_elf_hash "$artifact_dir/elf-initial.sha256"; then
    printf '%s\n' 'ELF hash differs from required final combined-build hash' >&2
    exit 125
fi
overall=0
for filter in compute_xgmi model_pair_loan initialized; do
    if ! verify_elf_hash "$artifact_dir/$filter.list.elf-before.sha256"; then exit 125; fi
    env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
        LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1 \
        timeout --signal=TERM --kill-after=10s 300s \
        "$elf" "$filter" --list --test-threads=1 \
        > "$artifact_dir/$filter.list.stdout" 2> "$artifact_dir/$filter.list.stderr"
    status=$?
    printf '%s\n' "$status" > "$artifact_dir/$filter.list.exit"
    if ! verify_elf_hash "$artifact_dir/$filter.list.elf-after.sha256"; then exit 125; fi
    if [[ "$status" != 0 ]]; then overall=$status; fi

    if ! verify_elf_hash "$artifact_dir/$filter.elf-before.sha256"; then exit 125; fi
    date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$filter.started-utc.txt"
    env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin \
        LANG=C.UTF-8 LC_ALL=C.UTF-8 RUST_TEST_THREADS=1 \
        timeout --signal=TERM --kill-after=10s 300s \
        "$elf" "$filter" --test-threads=1 \
        > "$artifact_dir/$filter.stdout" 2> "$artifact_dir/$filter.stderr"
    status=$?
    printf '%s\n' "$status" > "$artifact_dir/$filter.exit"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$artifact_dir/$filter.finished-utc.txt"
    if ! verify_elf_hash "$artifact_dir/$filter.elf-after.sha256"; then exit 125; fi
    if [[ "$status" != 0 ]]; then overall=$status; fi
    printf '%s exit=%s\n' "$filter" "$status"
done
if ! verify_elf_hash "$artifact_dir/elf-final.sha256"; then exit 125; fi
printf '%s\n' "$overall" > "$artifact_dir/overall.exit"
exit "$overall"
