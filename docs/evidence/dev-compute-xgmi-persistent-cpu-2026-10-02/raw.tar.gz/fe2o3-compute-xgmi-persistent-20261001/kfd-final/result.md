# Rejected Final KFD Filter Run

ELF: `/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_kfd-408178a9a9b41651`
SHA256: `bc2f6c09ba646010e9b1ae15d572970dadda3f163bf807b680d06b8fc5b418b7`

All initial, final, and per-filter before/after hashes matched this exact ELF. Each list and execution used the clean environment in `environment.txt`, serial test threads, no ignored-test override, and a 300-second timeout. Exact commands are in `command.sh`.

| Filter | Passed | Failed | Ignored | Filtered | Time | Exit |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| compute_xgmi | 25 | 0 | 0 | 1862 | 0.10s | 0 |
| model_pair_loan | 7 | 0 | 0 | 1880 | 0.00s | 0 |
| initialized | 62 | 1 | 0 | 1824 | 160.86s | 101 |

The initialized run failed `queue::live::rebind_tests::insertion::device_allocation_insertion_production_wiring_preserves_uninitialized_custody` at `crates/fe2o3-kfd/src/queue_live/rebind_tests/insertion.rs:957:13`, with `allocation-only path introduced DEVICE_LOCAL_PUBLIC`. The guard scanned the entire shared allocation implementation, which now includes the separate explicit PUBLIC constructor. The default private constructor and ordinary call path remained private; the constructed ordinary-allocation test passed its exact PRIVATE layout assertions.

All 13 initialized-storage conversion tests and the corrupt-prefix integrity test passed, as visible in `initialized.stdout`. Their mapping to the shared preflight helper is documented in `initialized-coverage.md`. This does not turn the filter result into a pass: it is rejected and requires a narrowly corrected test build and rerun.

The root agent authorized a test-only correction after this run closed. Future results belong under `kfd-corrected`; the raw outputs, exit codes, rosters, and hashes in this directory are preserved unchanged.
