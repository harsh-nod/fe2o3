# Initialized Filter Coverage

The exact final KFD ELF's `initialized --list --test-threads=1` roster contains 63 tests. The complete names are preserved in `initialized.list.stdout`. Execution outcome is recorded separately in `initialized.stdout` and `initialized.exit`; roster membership alone is not a pass claim.

The persistent adapter extracted `preflight_initialized_logical_storage` in `crates/fe2o3-kfd/src/persistent_allocation.rs:1374`. Both `preflight_initialized_storage_for_compute` (:1325) and `preflight_initialized_storage_for_xgmi` (:1352) call it. The existing compute conversion reaches it through `queue_live/initialized_storage.rs:171`.

The initialized roster includes all 13 tests from `queue_live/construction_primary/integration_initialized_storage_tests.rs`:

- `initialized_storage_conversion_accepts_full_and_contiguous_completed_copies_without_reallocation`
- `initialized_storage_conversion_currentness_and_retake_failures_retain_exact_custody`
- `initialized_storage_conversion_incomplete_public_input_cannot_bypass_missing_engine`
- `initialized_storage_conversion_incomplete_public_input_cannot_bypass_terminal_state`
- `initialized_storage_conversion_opening_failure_preserves_original_owner`
- `initialized_storage_conversion_public_adapter_preserves_retry_and_existing_root`
- `initialized_storage_conversion_public_guards_preserve_root_and_drop_aborts`
- `initialized_storage_conversion_rejects_changed_scope_without_losing_owner`
- `initialized_storage_conversion_rejects_completed_copy_from_unknown_source`
- `initialized_storage_conversion_rejects_partial_or_gapped_coverage_without_native_effects`
- `initialized_storage_conversion_rejects_reserved_and_prepared_uses`
- `initialized_storage_conversion_requires_retirement_even_after_full_completion`
- `initialized_storage_conversion_typed_ineligibility_is_authenticated_and_effect_free`

Direct shared-helper regression coverage includes:

- Typed ineligibility at :287 checks incomplete/gapped initialization without native effects, and verifies that logical 2048 / physical 4096 still reports `PartialExtent` for compute conversion.
- Retirement at :550 rejects a fully completed but unretired frontier and accepts it after actual frontier retirement.
- Scope rejection at :565 mutates pool generation, logical extent, physical extent, queue generation, quarantine, and detached/restored native metadata; it preserves exact owner custody without invoking native currentness.
- Outstanding-use rejection at :608 covers both reserved and prepared ledger entries, then accepts conversion after cancellation.
- Full/contiguous-copy success at :207 and currentness/retake failure matrices at :632 preserve the established conversion contract around the extracted helper.

The roster also includes `sdma::initialized_prefix_tests::initialized_storage_corrupt_prefix_is_integrity_failure_not_clean_ineligibility`. That test calls `preflight_initialized_storage_for_compute` directly (`sdma/initialized_prefix_tests.rs:28`) and rejects corrupt initialization metadata as an integrity error rather than a clean fallback.

The separate `compute_xgmi` filter includes the new XGMI-specific persistent preflight/full-logical-extent tests. Together these filters cover both callers of the shared helper. This remains CPU regression coverage, not native GPU-transfer qualification or a full KFD suite result.
