#!/bin/bash
set -u
out=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001/runtime
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 125
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/build.started"
env -i HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8 CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1 timeout --signal=TERM --kill-after=30s 2400s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --no-run > "$out/build.stdout" 2> "$out/build.stderr"
status=$?
printf '%s\n' "$status" > "$out/build.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/build.finished"
exit "$status"
