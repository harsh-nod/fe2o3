#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-persistent-20261001
packet="$repo/docs/evidence/dev-compute-xgmi-persistent-cpu-2026-10-02"
cd "$repo"
test "$(git rev-parse HEAD)" = f97257ed84c8a39e82a27955cd3f146df0d16781
git diff --cached --binary -- crates > "$raw/source.patch"
test -s "$raw/source.patch"
git diff --cached --name-only -- crates > "$raw/source-paths.txt"
git rev-parse HEAD > "$raw/base-commit.txt"
git diff --cached --check
while IFS= read -r path; do
    sha256sum "$path"
done < "$raw/source-paths.txt" > "$raw/source.sha256"
sha256sum "$raw/source.patch" > "$raw/source-patch.sha256"
rustc +nightly-2026-04-03 -Vv > "$raw/rustc.txt"
cargo +nightly-2026-04-03 -V > "$raw/cargo.txt"
uname -a > "$raw/uname.txt"
mkdir -p "$packet"
tar -czf "$packet/raw.tar.gz" \
    -C /home/harsh/.codex-tmp \
    fe2o3-compute-xgmi-persistent-20261001 \
    fe2o3-runtime-baseline-retest-20261001-2336 \
    fe2o3-multigpu-native-recovery-20261001/admission-expedite-2335 \
    fe2o3-multigpu-native-recovery-20261001/connectivity-20261002-0015
cd "$packet"
sha256sum raw.tar.gz > SHA256SUMS
sha256sum -c SHA256SUMS
tar -tzf raw.tar.gz > /dev/null
