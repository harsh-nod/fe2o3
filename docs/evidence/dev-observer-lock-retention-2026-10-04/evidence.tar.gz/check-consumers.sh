#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-observer-lock-retention-20261004-SiccjpCy
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/consumers.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-compiler-execution-coordinator -p fe2o3-compiler-execution-supervisor -p fe2o3-compiler-execution-issuer --lib -- --test-threads=1 > "$scratch/consumers.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-artifact-transaction --lib lock_retention -- --test-threads=4 > "$scratch/parallel-lock-retention.log" 2>&1
rustup run nightly-2026-04-03 rustfmt --edition 2024 --check --config skip_children=true \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff_lock_retention.rs \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff.rs \
    crates/fe2o3-artifact-transaction/src/lib.rs \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff/semantic_v3/tests/lock_retention.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_occurrence.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_supervision/tests/observer.rs > "$scratch/formatting.log" 2>&1
git diff --check > "$scratch/whitespace.log" 2>&1
