#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-observer-lock-retention-20261004-SiccjpCy
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/check.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-artifact-transaction --lib -- --test-threads=1 > "$scratch/artifact.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-artifact-transaction --doc > "$scratch/artifact-doc.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-artifact-transaction --lib -- -D warnings > "$scratch/artifact-clippy.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-artifact-transaction --all-targets -- -D warnings -A clippy::too_many_arguments > "$scratch/artifact-all-target-clippy.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service --lib -- --test-threads=1 > "$scratch/broker.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service --doc > "$scratch/broker-doc.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-broker-authority-service --all-targets -- -D warnings > "$scratch/broker-clippy.log" 2>&1
timeout --kill-after=10s 600s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service --lib --no-run --message-format=json > "$scratch/broker-build.json" 2> "$scratch/broker-build.log"
