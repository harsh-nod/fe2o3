#!/bin/bash
set -euo pipefail
mkdir -m 700 /tmp/observer-home /tmp/observer-runtime
export HOME=/tmp/observer-home XDG_RUNTIME_DIR=/tmp/observer-runtime
export RUSTC=/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin/rustc
exec "$1" --exact "compiler_execution_supervision::tests::observer::$2" --ignored --nocapture --test-threads=1
