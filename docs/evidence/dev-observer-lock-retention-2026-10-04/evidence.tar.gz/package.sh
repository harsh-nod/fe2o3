#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-observer-lock-retention-20261004-SiccjpCy
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
for status in check qualify consumers; do
    test "$(cat "$scratch/$status.status")" = 0
done
git diff HEAD -- \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff.rs \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff_lock_retention.rs \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff/semantic_v3/tests/lock_retention.rs \
    crates/fe2o3-artifact-transaction/src/lib.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_occurrence.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_supervision/tests/observer.rs > "$scratch/code.patch"
sha256sum "$scratch/code.patch"
tar -czf docs/evidence/dev-observer-lock-retention-2026-10-04/evidence.tar.gz -C "$scratch" \
    code.patch package.sh check.sh check-consumers.sh qualify.sh inside-root.sh \
    artifact.log artifact-doc.log artifact-clippy.log artifact-all-target-clippy.log \
    broker.log broker-doc.log broker-clippy.log broker-build.json broker-build.log \
    consumers.log parallel-lock-retention.log formatting.log whitespace.log \
    check.status consumers.status qualify.status binary.before.sha256 binary.after.sha256 \
    cross_uid_owned_occurrence.log cross_uid_publication_lock_contention.log \
    development-enum-lint.log
sha256sum docs/evidence/dev-observer-lock-retention-2026-10-04/evidence.tar.gz
