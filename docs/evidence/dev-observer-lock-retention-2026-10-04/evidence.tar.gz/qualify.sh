#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-observer-lock-retention-20261004-SiccjpCy
trap 'printf "%s\n" "$?" > "$scratch/qualify.status"' EXIT
binary=$(jq -r 'select(.reason=="compiler-artifact" and .target.name=="fe2o3_broker_authority_service" and .profile.test and .executable != null) | .executable' "$scratch/broker-build.json")
test -x "$binary"
sha256sum "$binary" > "$scratch/binary.before.sha256"
for case in cross_uid_owned_occurrence cross_uid_publication_lock_contention; do
    timeout --kill-after=5s 60s /mnt/c/Windows/System32/wsl.exe --user root --exec \
        /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
        --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
        --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN \
        --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
        /bin/bash "$scratch/inside-root.sh" "$binary" "$case" > "$scratch/$case.log" 2>&1
done
sha256sum "$binary" > "$scratch/binary.after.sha256"
cmp "$scratch/binary.before.sha256" "$scratch/binary.after.sha256"
