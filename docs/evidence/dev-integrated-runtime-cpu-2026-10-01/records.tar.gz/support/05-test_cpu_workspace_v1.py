#!/usr/bin/env python3
"""Generated TOML fixtures only, no Cargo process or source mutations."""
import hashlib
from pathlib import Path
import tempfile
import types
import unittest

path = Path(__file__).with_name("cpu_workspace_v1.py")
w = types.ModuleType("cpu_workspace_controls")
w.__file__ = str(path)
exec(compile(path.read_bytes(), str(path), "exec"), w.__dict__)


class WorkspaceControls(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="fe2o3-workspace-controls-")
        self.root = Path(self.tmp.name).resolve()
        self.addCleanup(self.tmp.cleanup)
        self.texts = {
            "Cargo.toml": '[workspace]\nmembers=["crates/*", "examples/add"]\ndefault-members=["crates/a"]\n'
                          '[workspace.dependencies]\nb={path="crates/b"}\n',
            "crates/a/Cargo.toml": '[package]\nname="a"\nversion="0.1.0"\n[dependencies]\nb={workspace=true}\n'
                                   '[target."cfg(unix)".dev-dependencies]\nx={path="../../fixtures/x"}\n',
            "crates/b/Cargo.toml": '[package]\nname="b"\nversion="0.1.0"\n',
            "examples/add/Cargo.toml": '[package]\nname="add"\nversion="0.1.0"\n[build-dependencies]\na={path="../../crates/a"}\n',
            "fixtures/x/Cargo.toml": '[package]\nname="x"\nversion="0.1.0"\n',
        }
        self.source = {}
        self.write()

    def write(self):
        for name, text in self.texts.items():
            file = self.root / name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(text)
            self.source[name] = {"sha256": hashlib.sha256(text.encode()).hexdigest(), "bytes": len(text.encode())}

    def test_explicit_glob_and_transitive_paths_complete(self):
        result = w.workspace_closure(self.root, self.source)
        self.assertEqual(result["members"], ["crates/a/Cargo.toml", "crates/b/Cargo.toml", "examples/add/Cargo.toml"])
        self.assertEqual(set(result["manifest_sha256"]), set(self.texts))
        self.assertIn(["crates/a/Cargo.toml", "x", "fixtures/x/Cargo.toml"], result["local_path_edges"])
        self.assertIn(["crates/a/Cargo.toml", "b", "crates/b/Cargo.toml"], result["local_path_edges"])
        self.assertIs(result["workspace_manifest_rewritten"], False)

    def test_missing_explicit_example_rejected(self):
        (self.root / "examples/add/Cargo.toml").unlink()
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)

    def test_missing_glob_member_detected_from_source_roster(self):
        (self.root / "crates/b/Cargo.toml").unlink()
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)

    def test_missing_transitive_target_dependency_rejected(self):
        (self.root / "fixtures/x/Cargo.toml").unlink()
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)

    def test_empty_glob_and_unbound_dependency_rejected(self):
        self.texts["Cargo.toml"] = self.texts["Cargo.toml"].replace('"crates/*"', '"absent/*"')
        self.write()
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)
        self.texts["Cargo.toml"] = self.texts["Cargo.toml"].replace('"absent/*"', '"crates/*"')
        self.write()
        del self.source["fixtures/x/Cargo.toml"]
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)

    def test_manifest_drift_and_symlinks_rejected(self):
        file = self.root / "examples/add/Cargo.toml"
        file.write_text(self.texts["examples/add/Cargo.toml"] + "\n")
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)
        file.unlink()
        file.symlink_to(self.root / "crates/a/Cargo.toml")
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)

    def test_paths_do_not_escape_or_overmatch_globs(self):
        self.assertTrue(w.matches("crates/a", "crates/*"))
        self.assertFalse(w.matches("crates/a/tests", "crates/*"))
        for pattern in ("/absolute", "../outside", "crates/**"):
            with self.assertRaises(ValueError):
                w.matches("crates/a", pattern)
        self.texts["examples/add/Cargo.toml"] = self.texts["examples/add/Cargo.toml"].replace("../../crates/a", "../../../outside")
        self.write()
        with self.assertRaises(ValueError):
            w.workspace_closure(self.root, self.source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
