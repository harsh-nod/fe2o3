#!/usr/bin/env python3
"""Generated parser fixtures only, never compiler/test execution evidence."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("cpu_results", HERE / "cpu_results_v1.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


def stream(rows):
    return "".join(json.dumps(row) + "\n" if type(row) is dict else row + "\n" for row in rows)


class ResultControls(unittest.TestCase):
    def suite(self):
        return [
            {"type": "suite", "event": "started", "test_count": 3},
            {"type": "test", "event": "started", "name": "normal"},
            {"type": "test", "event": "ok", "name": "normal"},
            {"type": "test", "event": "ignored", "name": "native", "reason": "GPU only"},
            {"type": "test", "event": "started", "name": "abort"},
            "", "running 1 test", "", "running 1 test",
            {"type": "test", "event": "ok", "name": "abort"},
            {"type": "suite", "event": "ok", "passed": 2, "failed": 0, "ignored": 1, "measured": 0, "filtered_out": 0},
        ]

    def parse_suite(self, rows):
        return p.libtest_output(stream(rows), ["normal", "native", "abort"],
            {"native": {"reason": "GPU only"}}, {"abort": 2}, {"normal", "abort"})

    def test_full_suite_with_exact_native_ignores_and_child_headers(self):
        result = self.parse_suite(self.suite())
        self.assertEqual(result["passed"], 2)
        self.assertEqual(result["ignored"], 1)
        self.assertEqual(len(result["abort_child_headers"]), 2)

    def test_missing_and_extra_child_headers_rejected(self):
        for changed in (self.suite()[:5] + self.suite()[7:], self.suite()[:9] + ["", "running 1 test"] + self.suite()[9:]):
            with self.assertRaises(ValueError):
                self.parse_suite(changed)

    def test_child_header_outside_matching_active_parent_rejected(self):
        rows = self.suite()
        rows[2:2] = ["", "running 1 test"]
        with self.assertRaises(ValueError):
            self.parse_suite(rows)

    def test_arbitrary_non_json_or_unpaired_header_rejected(self):
        for replacement in ("other output", "running 2 tests", "running 1 test extra"):
            rows = self.suite()
            rows[6] = replacement
            with self.assertRaises(ValueError):
                self.parse_suite(rows)

    def test_failure_timeout_terminal_or_missing_result_rejected(self):
        for event in ("failed", "timeout"):
            rows = self.suite()
            rows[2]["event"] = event
            with self.assertRaises(ValueError):
                self.parse_suite(rows)
        rows = self.suite()
        del rows[2]
        with self.assertRaises(ValueError):
            self.parse_suite(rows)

    def test_unknown_or_duplicate_test_event_rejected(self):
        for value in ("unknown", "native"):
            rows = self.suite()
            rows[2]["name"] = value
            with self.assertRaises(ValueError):
                self.parse_suite(rows)
        rows = self.suite()
        rows.insert(3, rows[2])
        with self.assertRaises(ValueError):
            self.parse_suite(rows)

    def test_unexpected_ignore_or_native_execution_rejected(self):
        rows = self.suite()
        rows[2]["event"] = "ignored"
        with self.assertRaises(ValueError):
            self.parse_suite(rows)
        rows = self.suite()
        rows[3]["event"] = "ok"
        with self.assertRaises(ValueError):
            self.parse_suite(rows)

    def test_ignore_reason_and_typed_counts_rejected(self):
        rows = self.suite()
        rows[3]["reason"] = "changed"
        with self.assertRaises(ValueError):
            self.parse_suite(rows)
        for key in ("ignored", "filtered_out", "failed", "measured"):
            rows = self.suite()
            rows[-1][key] = bool(rows[-1][key])
            with self.assertRaises(ValueError):
                self.parse_suite(rows)

    def test_concurrent_starts_rejected(self):
        rows = self.suite()
        rows.insert(2, {"type": "test", "event": "started", "name": "abort"})
        with self.assertRaises(ValueError):
            self.parse_suite(rows)

    def test_serial_timeout_notice_followed_by_success_allowed(self):
        rows = self.suite()
        rows.insert(2, {"type": "test", "event": "timeout", "name": "normal"})
        self.assertEqual(self.parse_suite(rows)["failed"], 0)

    def test_json_duplicate_keys_and_nonfinite_rejected(self):
        for text in ('{"x":0,"x":1}', '{"x":NaN}', '{"x":Infinity}'):
            with self.assertRaises(ValueError):
                p.parse(text)

    def test_list_and_exact_ignored_join(self):
        names = p.test_list("a: test\nb: test\n\n2 tests, 0 benchmarks\n", "")
        p.join_rosters(names, ["b"], {"b": {}}, {"a"})
        for stdout in ("a: test\na: test\n\n2 tests, 0 benchmarks\n", "a: test\n\n2 tests, 0 benchmarks\n"):
            with self.assertRaises(ValueError):
                p.test_list(stdout, "")
        for ignored in ([], ["a"], ["b", "extra"]):
            with self.assertRaises(ValueError):
                p.join_rosters(names, ignored, {"b": {}}, {"a"})

    def test_cargo_requires_unique_literal_success(self):
        good = [{"reason": "build-finished", "success": True}]
        self.assertEqual(p.cargo_output(stream(good), ""), good)
        for rows in (good * 2, [{"reason": "build-finished", "success": 1}], [{"reason": "build-finished", "success": False}]):
            with self.assertRaises(ValueError):
                p.cargo_output(stream(rows), "")

    def test_cargo_unknown_or_warning_diagnostics_rejected(self):
        for row in ({"reason": "unknown"}, {"reason": "compiler-message", "message": {"level": "warning"}},
                    {"reason": "compiler-message", "message": {"level": "error"}}):
            with self.assertRaises(ValueError):
                p.cargo_output(stream([row, {"reason": "build-finished", "success": True}]), "")
        with self.assertRaises(ValueError):
            p.cargo_output(stream([{"reason": "build-finished", "success": True}]), "warning: ignored issue\n")

    def artifact_fixture(self, root):
        target = root / "target"
        target.mkdir()
        elf = target / "runtime"
        elf.write_bytes(b"\x7fELFgenerated parser fixture, not a real test binary")
        elf.chmod(0o700)
        row = {"reason": "compiler-artifact", "target": {"name": "fe2o3_runtime", "kind": ["lib"]},
               "profile": {"test": True}, "executable": str(elf), "fresh": False,
               "manifest_path": str(root / "crates/fe2o3-runtime/Cargo.toml")}
        return target, elf, row

    def test_artifact_binds_runtime_manifest_kind_fresh_and_executable(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            target, elf, row = self.artifact_fixture(root)
            self.assertEqual(p.artifact([row], root, target)["path"], str(elf))
            for key, value in (("fresh", True), ("fresh", 0), ("manifest_path", "/different/Cargo.toml")):
                changed = copy.deepcopy(row)
                changed[key] = value
                with self.assertRaises(ValueError):
                    p.artifact([changed], root, target)
            row["target"]["kind"] = ["bin"]
            with self.assertRaises(ValueError):
                p.artifact([row], root, target)

    def test_artifact_duplicates_symlink_outside_target_or_nonelf_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            target, elf, row = self.artifact_fixture(root)
            with self.assertRaises(ValueError):
                p.artifact([row, row], root, target)
            with self.assertRaises(ValueError):
                p.artifact([row], root, root / "other")
            alias = target / "alias"
            alias.symlink_to(elf)
            changed = dict(row, executable=str(alias))
            with self.assertRaises(ValueError):
                p.artifact([changed], root, target)
            elf.write_bytes(b"not an ELF")
            with self.assertRaises(ValueError):
                p.artifact([row], root, target)

    def test_metadata_exact_manifest_members_and_target(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            manifest = root / "Cargo.toml"
            manifest.write_text('[package]\nname="fixture"\nversion="0.1.0"\n')
            workspace = {"members": ["Cargo.toml"], "manifest_sha256": {"Cargo.toml": p.file_identity(manifest)["sha256"]}}
            value = {"version": 1, "workspace_root": str(root), "target_directory": str(root / "target"), "resolve": None,
                     "packages": [{"manifest_path": str(manifest), "source": None, "id": "fixture"}], "workspace_members": ["fixture"]}
            self.assertEqual(p.metadata_output(stream([value]), "", root, root / "target", workspace)["packages"], 1)
            for key, changed in (("packages", []), ("workspace_members", []), ("target_directory", "/other"), ("version", True)):
                with self.assertRaises(ValueError):
                    p.metadata_output(stream([dict(value, **{key: changed})]), "", root, root / "target", workspace)


if __name__ == "__main__":
    unittest.main(verbosity=2)
