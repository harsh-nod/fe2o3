#!/usr/bin/env python3
"""Package completed CPU records; retain native executable and build cache."""
import hashlib
import json
from pathlib import Path
import stat
import tarfile

BASE = Path('/home/harsh/.codex-tmp')
RECORDS = BASE / 'fe2o3-integrated-runtime-cpu-records-20261001'
DESTINATION = BASE / 'fe2o3-r61-execution/docs/evidence/dev-integrated-runtime-cpu-2026-10-01'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    info = path.lstat()
    assert path.resolve(strict=True) == path and stat.S_ISREG(info.st_mode)
    assert info.st_nlink == 1
    return {'sha256': sha(path), 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode)}


def main():
    prepared = json.loads((RECORDS / 'inputs.json').read_bytes())
    result = json.loads((RECORDS / 'result.json').read_bytes())
    audit = json.loads((RECORDS / 'independent-readback.json').read_bytes())
    assert prepared['head'] == result['head'] == audit['head'] == '1cfb7580f36090c41cd9f96141c5d6b2952750ab'
    assert result['accepted'] and audit['accepted_readback']
    assert sha(RECORDS / 'independent-readback.json') == 'ae3278ba0988b68bf0df3289218c5263b7ca1c300e40b8a8eb5079c8b5eefd52'
    sources = {'records/' + path.name: path for path in RECORDS.iterdir() if path.is_file()}
    names = [row[0] for row in prepared['commands']]
    assert len(names) == 15
    for name in names:
        folder = RECORDS / 'commands' / name
        assert {path.name for path in folder.iterdir()} == {'receipt.json', 'stdout', 'stderr'}
        for path in folder.iterdir():
            sources['records/commands/' + name + '/' + path.name] = path
    for index, (path, digest) in enumerate(sorted(prepared['helper_pins'].items())):
        path = Path(path)
        assert sha(path) == digest
        sources['support/' + str(index).zfill(2) + '-' + path.name] = path
    for name in ('fe2o3-integrated-runtime-cpu-prepared-20261001.json',
                 'fe2o3-integrated-runtime-cpu-audit-20261001.py', Path(__file__).name):
        sources['support/' + name] = BASE / name
    inventory = {name: {**identity(path), 'original': str(path)} for name, path in sorted(sources.items())}
    assert sum(row['bytes'] for row in inventory.values()) < 16 * 1024**2
    DESTINATION.mkdir(mode=0o755)
    archive_path = DESTINATION / 'records.tar.gz'
    with archive_path.open('xb') as raw:
        with tarfile.open(fileobj=raw, mode='w:gz', compresslevel=6) as archive:
            for name, path in sorted(sources.items()):
                archive.add(path, arcname=name, recursive=False)
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name in inventory and member.name not in seen
            row = inventory[member.name]
            assert member.size == row['bytes'] and member.mode == row['mode']
            with archive.extractfile(member) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']
            assert identity(sources[member.name]) == {key: row[key] for key in ('sha256', 'bytes', 'mode')}
            seen.add(member.name)
    assert seen == set(inventory)
    packet = {'schema': 'fe2o3.integrated-runtime-cpu-records.v1', 'head': prepared['head'],
              'archive': {**identity(archive_path), 'path': archive_path.name}, 'members': inventory,
              'complete_command_groups': 15, 'counts': audit['counts'], 'source_files': audit['source_files'],
              'elf_identity': audit['elf'], 'elf_in_archive': False,
              'all_archived_originals_rechecked': True, 'tests_reexecuted_by_packaging': False,
              'scope': prepared['scope'],
              'external_prerequisites': ['Signed source at the recorded commit',
                  'Recorded Rust toolchain, registry, system libraries and OS',
                  'Fresh executable retained at elf_identity.path; not distributed in this compact packet',
                  'Controller absolute paths must be mapped explicitly before relocation; no turnkey portable replay claim']}
    with (DESTINATION / 'manifest.json').open('x') as stream:
        json.dump(packet, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in packet.items() if key != 'members'}, sort_keys=True))


if __name__ == '__main__':
    main()
