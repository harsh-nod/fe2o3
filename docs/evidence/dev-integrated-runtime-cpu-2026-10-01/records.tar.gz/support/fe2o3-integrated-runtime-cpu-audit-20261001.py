#!/usr/bin/env python3
"""Independent readback of the completed combined CPU run; no test rerun."""
import hashlib
import json
from pathlib import Path
import runpy
import sys

BASE = Path('/home/harsh/.codex-tmp')
OWNER = BASE / 'fe2o3-integrated-runtime-cpu-20261001.py'
PREPARED_SHA = '6d8f1becfb313eecb5839a7b9e30d39f60a8d51d2ba766265a72ec055ac76a67'


def main():
    assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
    owner = runpy.run_path(str(OWNER), run_name='cpu_readback_owner')
    root, output, sha = owner['ROOT'], owner['OUTPUT'], owner['sha']
    assert sha(owner['PREPARED']) == PREPARED_SHA
    prepared = json.loads(owner['PREPARED'].read_bytes())
    assert prepared['helper_pins'][str(OWNER)] == sha(OWNER)
    assert json.loads((output / 'inputs.json').read_bytes()) == prepared
    result = json.loads((output / 'result.json').read_bytes())
    assert result['accepted'] is True and result['errors'] == []
    assert result['head'] == prepared['head'] == owner['HEAD']
    assert result['prepared_sha256'] == PREPARED_SHA
    assert owner['source']() == prepared['source']
    assert all(sha(Path(path)) == digest for path, digest in prepared['helper_pins'].items())
    p = owner['load'](owner['OLD'] / 'cpu_results_v1.py', 'readback_parser', owner['HELPERS']['cpu_results_v1.py'])
    serial = owner['load'](owner['OLD'] / 'cpu_results_v2.py', 'readback_serial', owner['HELPERS']['cpu_results_v2.py'])
    assert {path: p.file_identity(Path(path)) for path in prepared['tools']} == prepared['tools']
    census = json.loads((output / 'fresh-census.json').read_bytes())
    assert census['scope'] == 'fresh-recorder-closed-groups-no-historical-pid-probes'
    names = [row[0] for row in prepared['commands']]
    assert len(names) == len(set(names)) == 15
    assert census['attempt_order'] == names == [row['name'] for row in result['rows']]
    assert {path.name for path in (output / 'commands').iterdir()} == set(names)
    assert set(census['raw_sha256']) == set(names)
    observed, pids = {}, set()
    elf = result['fresh_elf']
    assert p.file_identity(Path(elf['path'])) == {key: elf[key] for key in ('path', 'sha256', 'bytes', 'mode')}
    assert json.loads((output / 'fresh-elf.json').read_bytes()) == elf
    for name, command, seconds in prepared['commands']:
        folder = output / 'commands' / name
        assert {path.name for path in folder.iterdir()} == {'receipt.json', 'stdout', 'stderr'}
        hashes = {key: sha(folder / key) for key in ('receipt.json', 'stdout', 'stderr')}
        assert census['raw_sha256'][name] == hashes
        receipt = p.parse((folder / 'receipt.json').read_bytes())
        expected = [elf['path'], *command[1:]] if command[0] == '@elf' else command
        assert receipt['command'] == expected and receipt['timeout_seconds'] == seconds
        assert receipt['cwd'] == str(root) and receipt['environment'] == prepared['environment']
        assert receipt['stdin_sha256'] is None
        assert type(receipt['exit']) is int and receipt['exit'] == 0 and receipt['error'] is None
        assert receipt['group_absent'] is True
        assert type(receipt['pid']) is int and receipt['pid'] > 0 and receipt['pid'] not in pids
        pids.add(receipt['pid'])
        assert receipt['stdout_sha256'] == hashes['stdout'] and receipt['stderr_sha256'] == hashes['stderr']
        observed[name] = {'name': name, 'pid': receipt['pid'], 'receipt_sha256': hashes['receipt.json']}
    assert census['records'] == [observed[name] for name in sorted(names)]
    for row in result['rows']:
        for boundary in ('resources_before', 'resources_after'):
            assert row[boundary]['free_bytes'] >= owner['FLOOR']
            assert row[boundary]['target_bytes'] <= owner['TARGET_LIMIT']
            assert row[boundary]['packet_bytes'] <= owner['PACKET_LIMIT']
    def streams(name):
        return tuple((output / 'commands' / name / key).read_text() for key in ('stdout', 'stderr'))
    for name in ('signature', 'closing-signature'):
        stdout, stderr = streams(name)
        assert stdout == '' and stderr == 'Good "git" signature for harmenon@amd.com with ED25519 key SHA256:q8oGVYZ11904aFzlMkSiEwyeSP+6hbuiZGbNVGRZVCg\n'
    p.metadata_output(*streams('metadata'), root, owner['TARGET'], prepared['workspace'])
    for name in ('no-default-check', 'build', 'clippy'):
        messages = p.cargo_output(*streams(name))
        if name == 'build':
            assert p.artifact(messages, root, owner['TARGET']) == elf
    tests = p.test_list(*streams('list'))
    ignored = p.test_list(*streams('ignored'))
    assert tests == json.loads((output / 'list-roster.json').read_bytes())
    assert ignored == json.loads((output / 'ignored-roster.json').read_bytes())
    assert p.ignored_source(root, prepared['source']) == prepared['expected_ignored']
    p.join_rosters(tests, ignored, prepared['expected_ignored'])
    classification = serial.libtest_output(streams('suite')[0], tests, prepared['expected_ignored'])
    assert classification == json.loads((output / 'suite-classification.json').read_bytes())
    report = {'accepted_readback': True, 'test_reexecution': False, 'historical_pid_probes': False,
        'head': prepared['head'], 'prepared_sha256': PREPARED_SHA, 'source_files': len(prepared['source']),
        'closed_groups': len(pids), 'complete_roster': len(tests), 'ignored_roster': len(ignored),
        'counts': {key: classification[key] for key in ('passed', 'failed', 'ignored', 'filtered_out')},
        'result_sha256': sha(output / 'result.json'), 'census_sha256': sha(output / 'fresh-census.json'),
        'elf': {key: elf[key] for key in ('path', 'sha256', 'bytes', 'mode')},
        'raw_commands': census['raw_sha256'], 'scope': prepared['scope']}
    owner['save'](output / 'independent-readback.json', report)
    print(json.dumps({key: value for key, value in report.items() if key != 'raw_commands'}, sort_keys=True))


if __name__ == '__main__':
    main()
