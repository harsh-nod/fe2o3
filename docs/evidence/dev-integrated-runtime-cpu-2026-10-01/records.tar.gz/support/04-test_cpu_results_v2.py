#!/usr/bin/env python3
"""Exact serial-prefix controls; captured suite remains separately classified evidence."""
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("serial_cpu_results", HERE / "cpu_results_v2.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


class SerialControls(unittest.TestCase):
    def fixture(self):
        old = p.inherited()
        tests = sorted(old.REQUIRED) + ["native"]
        raw = json.dumps({"type": "suite", "event": "started", "test_count": len(tests)}) + "\n"
        for name in tests:
            if name == "native":
                raw += json.dumps({"type": "test", "event": "ignored", "name": name, "reason": "GPU"}) + "\n"
                continue
            raw += json.dumps({"type": "test", "event": "started", "name": name}) + "\n"
            if name in old.ABORT_HEADERS:
                raw += ("\nrunning 1 test\ntest " + name + " ... ") * old.ABORT_HEADERS[name]
            raw += json.dumps({"type": "test", "event": "ok", "name": name}) + "\n"
        raw += json.dumps({"type": "suite", "event": "ok", "passed": len(tests) - 1,
            "failed": 0, "ignored": 1, "measured": 0, "filtered_out": 0}) + "\n"
        return raw, tests, {"native": {"reason": "GPU"}}

    def test_exact_seven_serial_prefixes_accept_and_preserve_parent_counts(self):
        result = p.libtest_output(*self.fixture())
        self.assertEqual([row["count"] for row in result["raw_serial_child_prefixes"]], [5, 2])
        self.assertEqual(len(result["abort_child_headers"]), 7)
        self.assertEqual(result["ignored"], 1)

    def test_missing_extra_or_changed_prefix_rejected(self):
        raw, tests, ignored = self.fixture()
        parent, count = next(iter(p.inherited().ABORT_HEADERS.items()))
        prefix = "\nrunning 1 test\ntest " + parent + " ... "
        for text in (raw.replace(prefix, "", 1), raw.replace(prefix, prefix * 2, 1),
                     raw.replace(prefix, prefix.replace(" ... ", " .. "), 1), raw.replace(prefix, prefix.replace(parent, "unknown"), 1)):
            with self.assertRaises(ValueError):
                p.libtest_output(text, tests, ignored)

    def test_source_valid_prefix_under_wrong_active_parent_rejected(self):
        raw, tests, ignored = self.fixture()
        parents = list(p.inherited().ABORT_HEADERS)
        a, b = parents
        start_a = json.dumps({"type": "test", "event": "started", "name": a})
        start_b = json.dumps({"type": "test", "event": "started", "name": b})
        changed = raw.replace(start_a, "START_PLACEHOLDER").replace(start_b, start_a).replace("START_PLACEHOLDER", start_b)
        with self.assertRaises(ValueError):
            p.libtest_output(changed, tests, ignored)

    def test_unknown_trailing_text_or_missing_parent_success_rejected(self):
        raw, tests, ignored = self.fixture()
        parent = next(iter(p.inherited().ABORT_HEADERS))
        terminal = json.dumps({"type": "test", "event": "ok", "name": parent})
        for text in (raw.replace(terminal, "other output" + terminal, 1), raw.replace(terminal, "", 1)):
            with self.assertRaises(ValueError):
                p.libtest_output(text, tests, ignored)

    def test_captured_full_roster_readback_is_1901_32_with_no_rerun(self):
        packet = HERE / "cpu-attempt-1"
        frozen = json.loads((packet / "inputs.json").read_bytes())
        result = p.libtest_output((packet / "014-complete-runtime-suite/owned/stdout.log").read_text(),
            json.loads((packet / "complete-test-roster.json").read_bytes()), frozen["expected_native_ignores"])
        self.assertEqual((result["passed"], result["ignored"], result["failed"], result["filtered_out"]), (1901, 32, 0, 0))
        self.assertEqual(sum(row["count"] for row in result["raw_serial_child_prefixes"]), 7)


if __name__ == "__main__":
    unittest.main(verbosity=2)
