#!/usr/bin/env python3
"""Fresh combined-runtime CPU regression, not a proof or hardware campaign."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import subprocess
import sys
import time

BASE = Path('/home/harsh/.codex-tmp')
ROOT = BASE / 'fe2o3-r61-execution'
HEAD = '1cfb7580f36090c41cd9f96141c5d6b2952750ab'
OLD = BASE / 'fe2o3-a2-native-journal-observers-records-20261001-audit'
OUTPUT = BASE / 'fe2o3-integrated-runtime-cpu-records-20261001'
TARGET = OUTPUT / 'target'
PREPARED = BASE / 'fe2o3-integrated-runtime-cpu-prepared-20261001.json'
TC = Path('/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin')
SIGNERS = BASE / 'fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers'
SELECTORS = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo', 'crates', 'examples', 'tests', 'benchmarks']
FLOOR, TARGET_LIMIT, PACKET_LIMIT = 4 * 1024**3, 512 * 1024**2, 128 * 1024**2
HELPERS = {
    'cpu_results_v1.py': '62471de76b92ed900df159e30031c0aae124d1479b8d4ab55be9eb87328b8099',
    'cpu_results_v2.py': '85e5238c580d2177ca55d553e5c1bf4413273da79cef7c8a4a5f57d32c807f1d',
    'cpu_workspace_v1.py': '37acbc9670a70141d17602e251cf08bcf81c4ba9318de6c9e416bea421410b47',
    'test_cpu_results_v1.py': 'cc122251f6d0547b27bb26efcbeebaced785cf66a63bd0b336ccf7d8bad74fd4',
    'test_cpu_results_v2.py': 'b58306846b31ac5372168b9dca40a0b0536f92e5326e62620c6d339b94a9fe33',
    'test_cpu_workspace_v1.py': 'c132f6eb4860999fdcc3154cc9f5234684a0e76c848de461a84c81f6caf32f54',
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def load(path, name, expected):
    assert path.resolve(strict=True) == path and sha(path) == expected
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def git(*args):
    return subprocess.check_output(['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', *args], cwd=ROOT, timeout=180)


def source():
    assert git('rev-parse', 'HEAD').decode().strip() == HEAD
    assert git('status', '--porcelain=v1', '--untracked-files=all', '--', *SELECTORS) == b''
    result = {}
    for item in git('ls-tree', '-rz', HEAD, '--', *SELECTORS).split(b'\0'):
        if not item:
            continue
        metadata, name = item.split(b'\t')
        mode, kind, blob = metadata.decode('ascii').split()
        name = name.decode('ascii')
        path = ROOT / name
        assert kind == 'blob' and mode in ('100644', '100755')
        assert path.resolve(strict=True) == path and path.is_file()
        data = path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blob
        assert ('100755' if path.stat().st_mode & 0o111 else '100644') == mode
        result[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'git_mode': mode, 'git_blob': blob}
    return result


def footprint(startup=False):
    free = shutil.disk_usage(BASE).free
    assert free >= FLOOR + (TARGET_LIMIT + PACKET_LIMIT if startup else 0), 'local disk reserve'
    target, packet = 0, 0
    if OUTPUT.exists():
        for path in OUTPUT.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():
                if path.is_relative_to(TARGET):
                    target += path.stat().st_size
                else:
                    packet += path.stat().st_size
    assert target <= TARGET_LIMIT and packet <= PACKET_LIMIT
    return {'free_bytes': free, 'target_bytes': target, 'packet_bytes': packet}


def main():
    assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', metavar='PREPARED_SHA256')
    args = parser.parse_args()
    os.umask(0o077)
    assert not OUTPUT.exists()
    p = load(OLD / 'cpu_results_v1.py', 'cpu_parser', HELPERS['cpu_results_v1.py'])
    serial = load(OLD / 'cpu_results_v2.py', 'cpu_serial', HELPERS['cpu_results_v2.py'])
    workspace = load(OLD / 'cpu_workspace_v1.py', 'cpu_workspace', HELPERS['cpu_workspace_v1.py'])
    native = load(ROOT / 'benchmarks/runtime_gfx942/xgmi_peer_series_native.py', 'cpu_recorder',
                  'fef3e00f9310ee1895dff2dac133826c66a8432a600d5be6065b4249f3ebc3f4')
    hot, _, _ = native.load_helpers()
    frozen = source()
    manifests = workspace.workspace_closure(ROOT, frozen)
    ignores = p.ignored_source(ROOT, frozen)
    tools = [TC / name for name in ('rustc', 'cargo', 'clippy-driver', 'rustdoc')]
    tools += [Path(name).resolve(strict=True) for name in ('/usr/bin/git', '/usr/bin/python3', '/usr/bin/cc',
              '/usr/bin/ld', '/usr/bin/ar', '/usr/bin/as', '/bin/sh', '/usr/libexec/gcc/x86_64-linux-gnu/13/collect2')]
    identities = {str(path): p.file_identity(path) for path in tools}
    pins = {str(OLD / name): digest for name, digest in HELPERS.items()}
    pins.update({str(SIGNERS): sha(SIGNERS), str(Path(__file__)): sha(Path(__file__))})
    pending, seen = [native, hot], set()
    while pending:
        module = pending.pop()
        if id(module) in seen:
            continue
        seen.add(id(module))
        path = Path(module.__file__).resolve()
        if not path.is_relative_to(BASE):
            continue
        pins[str(path)] = sha(path)
        pending.extend(value for value in vars(module).values() if isinstance(value, type(sys)) and getattr(value, '__file__', None))
    assert all(sha(Path(path)) == digest for path, digest in pins.items())
    env = {'CARGO_BUILD_JOBS': '1', 'CARGO_HOME': '/home/harsh/.cargo', 'CARGO_INCREMENTAL': '0',
        'CARGO_NET_OFFLINE': 'true', 'CARGO_TARGET_DIR': str(TARGET), 'CARGO_TERM_COLOR': 'never',
        'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1', 'HOME': '/home/harsh',
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'LOGNAME': 'harsh', 'USER': 'harsh', 'TZ': 'UTC',
        'PATH': str(TC) + ':/usr/bin:/bin', 'RUSTC': str(TC / 'rustc'), 'RUSTDOC': str(TC / 'rustdoc'),
        'RUSTUP_HOME': '/home/harsh/.rustup', 'RUSTUP_TOOLCHAIN': TC.parent.name, 'RUST_BACKTRACE': '0',
        'RUST_TEST_THREADS': '1', 'TMPDIR': str(OUTPUT / 'tmp')}
    for profile in ('DEV', 'TEST'):
        for key, value in {'DEBUG': '0', 'DEBUG_ASSERTIONS': 'true', 'OPT_LEVEL': '1', 'OVERFLOW_CHECKS': 'true'}.items():
            env['CARGO_PROFILE_' + profile + '_' + key] = value
    common = ['-p', 'fe2o3-runtime', '--frozen', '--offline', '--jobs', '1', '--message-format=json', '--target-dir', str(TARGET)]
    signature = ['/usr/bin/git', '-c', 'gpg.ssh.allowedSignersFile=' + str(SIGNERS), 'verify-commit', HEAD]
    commands = [('signature', signature, 60)]
    for file in ('test_cpu_results_v1.py', 'test_cpu_workspace_v1.py'):
        commands.append((file, ['/usr/bin/python3', '-I', '-B', str(OLD / file)], 60))
    serial_controls = ['test_exact_seven_serial_prefixes_accept_and_preserve_parent_counts',
        'test_missing_extra_or_changed_prefix_rejected', 'test_source_valid_prefix_under_wrong_active_parent_rejected',
        'test_unknown_trailing_text_or_missing_parent_success_rejected']
    commands.append(('serial-controls', ['/usr/bin/python3', '-I', '-B', str(OLD / 'test_cpu_results_v2.py'),
                                        *['SerialControls.' + name for name in serial_controls]], 60))
    commands += [(name + '-version', [str(TC / name), flag], 30) for name, flag in
                 (('rustc', '-vV'), ('cargo', '-V'), ('clippy-driver', '--version'))]
    commands += [
        ('metadata', [str(TC / 'cargo'), 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'], 60),
        ('no-default-check', [str(TC / 'cargo'), 'check', *common, '--no-default-features', '--lib'], 900),
        ('build', [str(TC / 'cargo'), 'test', *common, '--all-features', '--lib', '--no-run'], 1800),
        ('list', ['@elf', '--list', '--color=never'], 120),
        ('ignored', ['@elf', '--list', '--ignored', '--color=never'], 120),
        ('suite', ['@elf', '--test-threads=1', '-Z', 'unstable-options', '--format=json'], 1800),
        ('clippy', [str(TC / 'cargo'), 'clippy', *common, '--all-features', '--all-targets', '--', '-D', 'warnings'], 1200),
        ('closing-signature', signature, 60),
    ]
    plan = {'head': HEAD, 'source': frozen, 'workspace': manifests, 'expected_ignored': ignores,
        'tools': identities, 'helper_pins': pins, 'environment': env, 'commands': commands,
        'limits': {'floor_bytes': FLOOR, 'target_bytes': TARGET_LIMIT, 'packet_bytes': PACKET_LIMIT,
                   'owner_stage_boundary_seconds': 7200, 'single_file_bytes': PACKET_LIMIT, 'address_space_bytes': 8 * 1024**3},
        'scope': 'Fresh combined runtime CPU regression only. No GPU, solver, hardware-ignore removal or parity claim. Signed source and explicit tool/helper inputs bound; registry, system libraries and OS are not hermetically attested. Disk/elapsed bounds checked at stage boundaries, not continuously. No automatic retry.'}
    if args.execute is None:
        save(PREPARED, plan)
        print(json.dumps({'prepared_sha256': sha(PREPARED), 'source_files': len(frozen), 'commands': len(commands), 'free_bytes': shutil.disk_usage(BASE).free}))
        return
    assert sha(PREPARED) == args.execute and json.loads(PREPARED.read_bytes()) == json.loads(json.dumps(plan))
    footprint(startup=True)
    OUTPUT.mkdir()
    TARGET.mkdir()
    (OUTPUT / 'tmp').mkdir()
    save(OUTPUT / 'inputs.json', plan)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (PACKET_LIMIT, PACKET_LIMIT))
    for number in hot.B.MANAGED:
        signal.signal(number, hot.B.interrupted)
    recorder = native.FreshRecorder(OUTPUT / 'commands', ROOT, hot)
    namespace, start = os.readlink('/proc/self/ns/pid'), time.monotonic()
    elf = all_tests = ignored_tests = classification = None
    errors, rows = [], []

    def continuity():
        assert time.monotonic() - start <= 7200
        assert source() == frozen
        assert all(sha(Path(path)) == digest for path, digest in pins.items()) and sha(PREPARED) == args.execute
        assert {str(path): p.file_identity(path) for path in tools} == identities
        if elf:
            assert p.file_identity(Path(elf['path'])) == {key: elf[key] for key in ('path', 'sha256', 'bytes', 'mode')}
        return footprint()

    try:
        for name, argv, seconds in commands:
            before = continuity()
            if argv[0] == '@elf':
                assert elf is not None
                argv = [elf['path'], *argv[1:]]
            folder = recorder.run(name, argv, seconds, env=env)
            stdout, stderr = [(folder / stream).read_text() for stream in ('stdout', 'stderr')]
            if name == 'metadata':
                p.metadata_output(stdout, stderr, ROOT, TARGET, manifests)
            elif name in ('no-default-check', 'build', 'clippy'):
                messages = p.cargo_output(stdout, stderr)
                if name == 'build':
                    elf = p.artifact(messages, ROOT, TARGET)
                    save(OUTPUT / 'fresh-elf.json', elf)
            elif name in ('list', 'ignored'):
                tests = p.test_list(stdout, stderr)
                if name == 'list':
                    all_tests = tests
                else:
                    ignored_tests = tests
                    p.join_rosters(all_tests, ignored_tests, ignores)
                save(OUTPUT / (name + '-roster.json'), tests)
            elif name == 'suite':
                assert all_tests is not None and ignored_tests is not None
                classification = serial.libtest_output(stdout, all_tests, ignores)
                save(OUTPUT / 'suite-classification.json', classification)
            rows.append({'name': name, 'resources_before': before, 'resources_after': continuity()})
    except BaseException as error:
        errors.append(repr(error))
    finally:
        for label, action in [('closing-continuity', continuity), ('fresh-census', lambda: native.fresh_census(recorder, hot, namespace))]:
            try:
                save(OUTPUT / (label + '.json'), action())
            except BaseException as error:
                errors.append(label + ': ' + repr(error))
        accepted = len(rows) == len(commands) and not errors and classification is not None
        save(OUTPUT / 'result.json', {'accepted': accepted, 'head': HEAD, 'rows': rows, 'errors': errors,
             'fresh_elf': elf, 'scope': plan['scope'], 'prepared_sha256': args.execute})
        print(json.dumps({'accepted': accepted, 'stages': len(rows), 'errors': errors}), flush=True)
    raise SystemExit(0 if accepted else 1)


if __name__ == '__main__':
    main()
