#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-app-observation-20261004-4H6ejfkH
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/final.status"' EXIT
cd "$repo"
sha256sum crates/fe2o3-broker-authority-service/src/{lib.rs,linux.rs,linux/application_observation.rs,linux/application_observation/tests.rs,linux/application_observation/fixture.c} > "$scratch/source.before.sha256"
bash "$scratch/check.sh"
bash "$scratch/qualify.sh"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=4
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo check -p fe2o3-compiler-execution-coordinator --all-targets > "$scratch/coordinator-check.log" 2>&1
sha256sum -c "$scratch/source.before.sha256" > "$scratch/source-final-check.log"
cc --version > "$scratch/cc-version.log"
ld --version > "$scratch/ld-version.log"
rustc --version --verbose > "$scratch/rustc-version.log"
