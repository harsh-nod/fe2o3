#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-app-observation-20261004-4H6ejfkH
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/check.status"' EXIT
cd "$repo"
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1
export RUST_TEST_THREADS=4
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo test -p fe2o3-broker-authority-service --lib --no-run --message-format=json > "$scratch/broker-build.json" 2> "$scratch/broker-build.log"
cargo test -p fe2o3-broker-authority-service --lib > "$scratch/broker.log" 2>&1
cargo test -p fe2o3-broker-authority-service --doc > "$scratch/broker-doc.log" 2>&1
cargo clippy -p fe2o3-broker-authority-service --all-targets -- -D warnings > "$scratch/broker-clippy.log" 2>&1
rustfmt --edition 2024 --check --config skip_children=true crates/fe2o3-broker-authority-service/src/{lib.rs,linux.rs,linux/application_observation.rs,linux/application_observation/tests.rs} > "$scratch/formatting.log" 2>&1
git diff --check > "$scratch/whitespace.log" 2>&1
