#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-app-observation-20261004-4H6ejfkH
trap 'printf "%s\n" "$?" > "$scratch/qualify.status"' EXIT
binary=$(jq -r 'select(.reason=="compiler-artifact" and .target.name=="fe2o3_broker_authority_service" and .profile.test and .executable != null) | .executable' "$scratch/broker-build.json")
test -x "$binary"
sha256sum "$binary" > "$scratch/binary.before.sha256"
timeout --kill-after=5s 180s /mnt/c/Windows/System32/wsl.exe --user root --exec \
    /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
    --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
    --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN \
    --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
    /bin/bash "$scratch/inside-root.sh" "$binary" > "$scratch/root-observation.log" 2>&1
sha256sum "$binary" > "$scratch/binary.after.sha256"
cmp "$scratch/binary.before.sha256" "$scratch/binary.after.sha256"
