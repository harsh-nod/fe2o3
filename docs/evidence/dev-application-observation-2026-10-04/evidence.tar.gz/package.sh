#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-app-observation-20261004-4H6ejfkH
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
test "$(cat "$scratch/final.status")" = 0
test "$(cat "$scratch/check.status")" = 0
test "$(cat "$scratch/qualify.status")" = 0
sha256sum -c "$scratch/source.before.sha256" > "$scratch/source-package-check.log"
git rev-parse HEAD > "$scratch/source-commit.txt"
git show --format=fuller --binary HEAD > "$scratch/code.patch"
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers verify-commit HEAD > "$scratch/signature.log" 2>&1
cd "$scratch"
sha256sum code.patch > code.patch.sha256
mkdir package
cp -- *.sh *.log *.json *.sha256 *.status source-commit.txt code.patch package/
cp -r initial package/
cd package
find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
sha256sum -c SHA256SUMS > ../manifest-check.log
tar -czf "$repo/docs/evidence/dev-application-observation-2026-10-04/evidence.tar.gz" .
tar -dzf "$repo/docs/evidence/dev-application-observation-2026-10-04/evidence.tar.gz" > ../archive-compare.log
sha256sum "$repo/docs/evidence/dev-application-observation-2026-10-04/evidence.tar.gz" > ../archive.sha256
