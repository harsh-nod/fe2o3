#!/bin/bash
set -euo pipefail
mkdir -m 700 /tmp/observer-home /tmp/observer-runtime
export HOME=/tmp/observer-home XDG_RUNTIME_DIR=/tmp/observer-runtime
export LD_LIBRARY_PATH=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib
exec "$1" --exact linux::application_observation::tests::root_application_observation_campaign --ignored --nocapture --test-threads=1
