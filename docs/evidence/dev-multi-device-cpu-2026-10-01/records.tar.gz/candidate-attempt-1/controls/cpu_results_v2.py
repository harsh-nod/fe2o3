#!/usr/bin/env python3
"""Account for exact serial libtest prefixes from the two existing abort parents."""
import hashlib
from pathlib import Path
import types

HERE = Path(__file__).resolve().parent
PRIOR_SHA = "62471de76b92ed900df159e30031c0aae124d1479b8d4ab55be9eb87328b8099"


def inherited():
    path = HERE / "cpu_results_v1.py"
    raw = path.read_bytes()
    if path.resolve() != path or path.is_symlink() or hashlib.sha256(raw).hexdigest() != PRIOR_SHA:
        raise ValueError("immutable reviewed CPU parser")
    module = types.ModuleType("runtime_serial_child_prior_parser")
    module.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


def libtest_output(stdout, all_tests, expected_ignored):
    p = inherited()
    normalized, prefixes = stdout, []
    for parent, count in sorted(p.ABORT_HEADERS.items()):
        prefix = "\nrunning 1 test\ntest " + parent + " ... "
        block = prefix * count
        p.need(stdout.count(prefix) == count and stdout.count(block) == 1,
               "exact contiguous serial child prefixes for each reviewed parent")
        start = stdout.index(block)
        prefixes.append({"parent": parent, "count": count, "raw_character_start": start,
                         "raw_character_end": start + len(block), "prefix": prefix})
        normalized = normalized.replace(block, "\nrunning 1 test\n" * count, 1)
    result = p.libtest_output(normalized, all_tests, expected_ignored)
    result.update(raw_serial_child_prefixes=prefixes,
        raw_stdout_sha256=hashlib.sha256(stdout.encode()).hexdigest(),
        normalized_stdout_sha256=hashlib.sha256(normalized.encode()).hexdigest(),
        normalization="Only seven exact known serial child test-name prefixes removed; prior strict parser joins every header to its active parent.")
    return result
