#!/usr/bin/env python3
"""TOML-based workspace materialization check before any fresh Cargo build."""
import fnmatch
import hashlib
from pathlib import Path, PurePosixPath
import tomllib


def need(value, message):
    if not value:
        raise ValueError(message)


def matches(path, pattern):
    need(type(pattern) is str and pattern and not PurePosixPath(pattern).is_absolute()
         and ".." not in PurePosixPath(pattern).parts and "**" not in pattern,
         "reviewable relative workspace glob without recursive wildcard")
    values, parts = PurePosixPath(path).parts, PurePosixPath(pattern).parts
    return len(values) == len(parts) and all(fnmatch.fnmatchcase(value, part) for value, part in zip(values, parts))


def dependency_tables(document):
    tables = []
    for key in ("dependencies", "dev-dependencies", "build-dependencies"):
        if key in document:
            tables.append(document[key])
    for target in document.get("target", {}).values():
        for key in ("dependencies", "dev-dependencies", "build-dependencies"):
            if key in target:
                tables.append(target[key])
    tables.extend(document.get("patch", {}).values())
    if "replace" in document:
        tables.append(document["replace"])
    need(all(type(table) is dict for table in tables), "TOML dependency tables")
    return tables


def workspace_closure(repo, source):
    need(repo.is_dir() and repo.resolve() == repo and not repo.is_symlink(), "canonical source repository")
    manifests = {path: row for path, row in source.items() if PurePosixPath(path).name == "Cargo.toml"}
    need("Cargo.toml" in manifests, "bound original workspace manifest")
    parsed, pins = {}, {}

    def read(name):
        need(name in manifests, "required tracked/source-bound manifest: " + name)
        file = repo / name
        need(file.is_file() and file.resolve() == file and not file.is_symlink(), "materialized ordinary manifest: " + name)
        raw = file.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        need(digest == manifests[name]["sha256"] and len(raw) == manifests[name]["bytes"], "manifest equals frozen source: " + name)
        parsed[name] = tomllib.loads(raw.decode())
        pins[name] = digest
        return parsed[name]

    root = read("Cargo.toml")
    workspace = root.get("workspace")
    need(type(workspace) is dict and type(workspace.get("members")) is list, "original workspace member declaration")
    directories = {str(PurePosixPath(name).parent): name for name in manifests if name != "Cargo.toml"}
    excluded = workspace.get("exclude", [])
    need(type(excluded) is list, "explicit workspace exclusions")
    members = set()
    expansions = {}
    for pattern in workspace["members"]:
        found = {name for directory, name in directories.items() if matches(directory, pattern)
                 and not any(matches(directory, exclude) for exclude in excluded)}
        need(found, "nonempty signed-roster workspace member expansion: " + pattern)
        expansions[pattern] = sorted(found)
        members.update(found)
    for pattern in workspace.get("default-members", []):
        need(any(matches(str(PurePosixPath(name).parent), pattern) for name in members), "default member is materialized workspace member")
    workspace_dependencies = workspace.get("dependencies", {})
    need(type(workspace_dependencies) is dict, "workspace dependency table")
    pending, edges = ["Cargo.toml", *sorted(members)], set()
    if "package" in root:
        members.add("Cargo.toml")
    visited = set()
    while pending:
        name = pending.pop()
        if name in visited:
            continue
        visited.add(name)
        document = parsed.get(name) or read(name)
        if name in members:
            need(type(document.get("package")) is dict, "each workspace member is a package")
        tables = dependency_tables(document)
        if name == "Cargo.toml":
            tables.append(workspace_dependencies)
        for table in tables:
            for dependency_name, declaration in table.items():
                if type(declaration) is not dict:
                    continue
                base = (repo / name).parent
                if declaration.get("workspace") is True:
                    need(dependency_name in workspace_dependencies, "defined inherited workspace dependency")
                    declaration = workspace_dependencies[dependency_name]
                    base = repo
                if type(declaration) is not dict or "path" not in declaration:
                    continue
                need(type(declaration["path"]) is str, "typed local path dependency")
                target = (base / declaration["path"] / "Cargo.toml").resolve()
                need(target.is_relative_to(repo), "local dependency remains in frozen source repository")
                target_name = str(target.relative_to(repo))
                need(target_name in manifests, "bound local dependency manifest: " + target_name)
                edges.add((name, dependency_name, target_name))
                pending.append(target_name)
    return {"workspace_manifest_sha256": pins["Cargo.toml"], "members": sorted(members),
            "member_expansions": expansions, "manifest_sha256": dict(sorted(pins.items())),
            "local_path_edges": [list(edge) for edge in sorted(edges)],
            "workspace_manifest_rewritten": False}
