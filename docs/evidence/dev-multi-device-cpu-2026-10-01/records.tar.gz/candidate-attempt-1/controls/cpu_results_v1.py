#!/usr/bin/env python3
"""Strict fresh runtime Cargo/libtest joins; no command execution."""
import hashlib
import json
import os
from pathlib import Path
import re

ABORT_HEADERS = {
    "kfd_backend::tests::scripted_sdma_drop_still_aborts_with_live_or_terminal_custody": 2,
    "kfd_backend::tests::runtime_compute_pipeline_drop_aborts_for_every_live_logical_phase": 5,
}
REQUIRED = frozenset({
    "context::tests::producer_launch_tests::producer_launch_root_flag_dependency_and_late_marker_loss_seal_before_observation",
    "context::tests::producer_launch_tests::queued_reads::queued_reads_corruption_rejects_before_backend_before_and_after_producer_slot_reuse",
    "context::tests::producer_launch_tests::queued_reads::queued_reads_mixed_stable_active_and_queued_rosters_release_together",
    *ABORT_HEADERS,
})


def need(value, message):
    if not value:
        raise ValueError(message)


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def invalid(value):
        raise ValueError("nonfinite JSON: " + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def file_identity(path):
    need(path.is_absolute() and path.resolve(strict=True) == path and not path.is_symlink()
         and path.is_file(), "canonical ordinary file")
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": digest, "bytes": path.stat().st_size, "mode": path.stat().st_mode}


def cargo_output(stdout, stderr):
    need(stdout.endswith("\n"), "complete Cargo JSON stream")
    rows = [parse(line) for line in stdout.splitlines()]
    need(rows and all(type(row) is dict for row in rows), "Cargo objects")
    need(rows[-1] == {"reason": "build-finished", "success": True}
         and rows[-1]["success"] is True
         and sum(row.get("reason") == "build-finished" for row in rows) == 1, "one literal successful Cargo finish")
    for row in rows:
        need(row.get("reason") in {"compiler-artifact", "compiler-message", "build-script-executed", "build-finished"},
             "known Cargo record")
        if row["reason"] == "compiler-message":
            need(type(row.get("message")) is dict and row["message"].get("level") in {"note", "help"},
                 "no warning/error/unknown compiler diagnostic")
    need(re.search(r"^\s*(?:warning|error)(?:\[|:)", stderr, re.M) is None, "no textual Cargo warning or error")
    return rows


def artifact(rows, repo, target):
    selected = [row for row in rows if row.get("reason") == "compiler-artifact"
                and row.get("target", {}).get("name") == "fe2o3_runtime"
                and row.get("profile", {}).get("test") is True and row.get("executable") is not None]
    need(len(selected) == 1, "one runtime library test artifact")
    row = selected[0]
    need(row.get("fresh") is False and row.get("manifest_path") == str(repo / "crates/fe2o3-runtime/Cargo.toml")
         and row["target"].get("kind") == ["lib"], "new runtime lib artifact from exact manifest")
    path = Path(row["executable"])
    identity = file_identity(path)
    need(path.is_relative_to(target) and os.access(path, os.X_OK), "fresh owned executable path")
    with path.open("rb") as stream:
        need(stream.read(4) == b"\x7fELF", "actual ELF bytes")
    return dict(identity, cargo_record=row, newly_built_in_this_attempt=True)


def ignored_source(repo, source):
    result = {}
    prefix = "crates/fe2o3-runtime/src/"
    pattern = re.compile(r'^#\[ignore = "([^"\n]+)"\]\nfn ([a-zA-Z0-9_]+)\(', re.M)
    for name in sorted(source):
        if not name.startswith(prefix) or not name.endswith(".rs"):
            continue
        text = (repo / name).read_text()
        rows = pattern.findall(text)
        need(text.count("#[ignore") == len(rows), "all ignore attributes use the reviewed top-level form")
        for reason, function in rows:
            module = name[len(prefix):-3].replace("/", "::")
            test = module + "::" + function
            need(test not in result, "unique ignored test source")
            result[test] = {"reason": reason, "source": name, "source_sha256": source[name]["sha256"]}
    need(len(result) == 32, "exact existing 32 hardware-only ignores")
    return result


def test_list(stdout, stderr):
    need(stderr == "" and stdout.endswith("\n"), "complete clean libtest listing")
    lines = stdout.splitlines()
    need(len(lines) >= 2 and lines[-2] == "", "libtest list separator")
    match = re.fullmatch(r"(\d+) tests, 0 benchmarks", lines[-1])
    need(match is not None, "libtest complete-list summary")
    names = [line[:-6] for line in lines[:-2]]
    need(all(line.endswith(": test") and len(line) > 6 for line in lines[:-2])
         and len(names) == len(set(names)) == int(match[1]), "complete unique listed test roster")
    return names


def join_rosters(all_tests, ignored_tests, expected_ignored, required=REQUIRED):
    need(len(all_tests) == len(set(all_tests)) and set(ignored_tests) == set(expected_ignored)
         and set(ignored_tests) < set(all_tests) and set(required) <= set(all_tests) - set(ignored_tests),
         "complete independent roster, exact preserved native ignores, required semantic tests enabled")


def libtest_output(stdout, all_tests, expected_ignored, headers=ABORT_HEADERS, required=REQUIRED):
    join_rosters(all_tests, list(expected_ignored), expected_ignored, required)
    need(stdout.endswith("\n"), "complete libtest JSON")
    lines = stdout.split("\n")[:-1]
    need(len(lines) >= 2, "full libtest suite")
    opening = parse(lines[0])
    need(type(opening) is dict and type(opening.get("test_count")) is int
         and opening == {"type": "suite", "event": "started", "test_count": len(all_tests)}, "exact full suite count")
    started, ended, witnesses = set(), {}, []
    seen_headers = dict.fromkeys(headers, 0)
    need(set(headers) <= set(all_tests) - set(expected_ignored), "all native abort parents enabled")
    index = 1
    while index < len(lines) - 1:
        active = started - set(ended)
        if lines[index] == "":
            need(index + 1 < len(lines) - 1 and lines[index + 1] == "running 1 test"
                 and len(active) == 1, "exact child header during one serial parent")
            parent = next(iter(active))
            need(parent in headers and seen_headers[parent] < headers[parent], "bounded reviewed parent header count")
            seen_headers[parent] += 1
            witnesses.append({"blank_line": index + 1, "header_line": index + 2, "active_parent": parent})
            index += 2
            continue
        row = parse(lines[index])
        index += 1
        need(type(row) is dict and row.get("type") == "test" and row.get("name") in all_tests, "only listed test events")
        name, event = row["name"], row.get("event")
        if event == "started":
            need(not active and name not in started and name not in ended, "unique serial test start")
            started.add(name)
        elif event == "ok":
            need(name in active and name not in expected_ignored and name not in ended, "expected normal test passed")
            ended[name] = event
        elif event == "ignored":
            need(name in expected_ignored and name not in ended and (not active or active == {name}), "only authorized hardware ignore")
            need("reason" not in row or row["reason"] == expected_ignored[name]["reason"], "unchanged native ignore reason")
            ended[name] = event
        elif event == "timeout":
            need(name in active and name not in ended, "timeout notice belongs to current serial test")
        else:
            raise ValueError("failed or unknown libtest event")
    final = parse(lines[-1])
    need(set(ended) == set(all_tests) and started - set(ended) == set()
         and type(final) is dict and final.get("type") == "suite" and final.get("event") == "ok", "complete successful suite")
    counts = {"passed": len(all_tests) - len(expected_ignored), "failed": 0, "ignored": len(expected_ignored),
              "measured": 0, "filtered_out": 0}
    need(all(type(final.get(key)) is int and final[key] == value for key, value in counts.items()), "exact full suite integer totals")
    need(seen_headers == headers, "all seven reviewed child header pairs observed under their successful parents")
    return dict(counts, terminal_tests=ended, abort_child_headers=witnesses,
                stderr_is_captured_not_a_standalone_success_or_failure_predicate=True)


def metadata_output(stdout, stderr, repo, target, workspace):
    need(stderr == "" and stdout.endswith("\n"), "clean complete Cargo metadata")
    value = parse(stdout)
    need(type(value) is dict and type(value.get("version")) is int and value["version"] == 1
         and value.get("workspace_root") == str(repo) and value.get("target_directory") == str(target)
         and value.get("resolve") is None, "exact no-deps workspace/target metadata")
    packages = value.get("packages")
    need(type(packages) is list and all(type(row) is dict for row in packages), "workspace package records")
    manifests, ids = [], []
    for row in packages:
        manifest = Path(row["manifest_path"])
        need(manifest.is_relative_to(repo) and manifest.resolve(strict=True) == manifest, "bound materialized workspace package")
        name = str(manifest.relative_to(repo))
        need(name in workspace["manifest_sha256"] and file_identity(manifest)["sha256"] == workspace["manifest_sha256"][name]
             and row.get("source") is None and type(row.get("id")) is str, "exact local package manifest")
        manifests.append(name)
        ids.append(row["id"])
    need(len(ids) == len(set(ids)) == len(manifests) == len(set(manifests))
         and set(manifests) == set(workspace["members"]), "complete independent TOML/metadata workspace join")
    members = value.get("workspace_members")
    need(type(members) is list and len(members) == len(set(members)) and set(members) == set(ids), "exact Cargo workspace member IDs")
    return {"packages": len(packages), "manifest_names": sorted(manifests), "workspace_members": sorted(members)}
