#!/usr/bin/env python3
"""Portable CPU-only bindings over the existing recorder and result classifiers."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / 'candidate-attempt-1'
SOURCE = CANDIDATE / 'source'
BASE = 'dd5e61712b3e7f16c43c7bf9ecb90eaac46bbaaf'
RECORD_SHA = 'b1ab447c92cb6a7bd51f549f6489c828db304144b41ff79f1665e5c51730689a'
TC = Path('/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu')
RUST_SHA = 'a342ecbc4a9d5f5f33f96271bba82e5f992a2cc86f22aa81437bdf641eae7fe9'
PYTHON = '/usr/bin/python3'
PREFIX = '/tmp/fe2o3-multigpu-cpu-dd5-'
GIB, MIB = 1024**3, 1024**2
DISK, RAM, OWNED = 4 * GIB, 64 * GIB, 3 * GIB
TARGET_LIMIT, CACHE_LIMIT, SOURCE_LIMIT, RECORD_LIMIT = GIB, GIB, 256 * MIB, 128 * MIB
TOTAL, GRACE = 10800, 30
EXAMPLE = 'gfx942-runtime-multi-device-smoke'
HELPERS = {
    'qualify.py': '0c504f7a512873776df4af8e1666d6dfd3ab401e5f05dbf7d3c35a9e49eae3cb',
    'native.py': 'fef3e00f9310ee1895dff2dac133826c66a8432a600d5be6065b4249f3ebc3f4',
    'hot.py': '820ad87e74a1f9915c2eb7d2d7c7c6c1c451da4cecf29fcc381229324d98473b',
    'base.py': 'df740a80c83c94af02f7e7dfb1203dcf7c1eafbde0010e41219e4aac40b34bb7',
}
PLATFORM = {
    '/usr/bin/python3': 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f',
    '/usr/bin/git': '2a8c18fbf43da9f692d75474c72bea9dfd796c260b0f3dfe456376abc3bbd668',
    '/usr/bin/cc': '1b99826121ae6682a634e5efe09bd3e3df58ce58e0b28f849114ab5b89139c26',
    '/usr/bin/ld': 'e9ceb054c12207970f2726dfc07e9a66b411602748628baf27399f02a9bbb31b',
    '/usr/bin/ar': '6452af2eea333b8c65e1adb92964fc8f97863ab003fa13f9d12bff5345cd7dbe',
    '/usr/bin/timeout': '12690a043dfd555a6c14ccc1564f5649c18f1762c0d6ff66729948130898ec52',
    '/usr/bin/ssh-keygen': '5175ddce2146fc8a03ab8e1ef25a1b0382dd3cb209484f7ae11ac782171c0d04',
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def load(path, expected, name):
    need(path.is_file() and not path.is_symlink() and sha(path) == expected, 'pinned helper: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def helpers():
    p = load(HERE / 'helpers/qualify.py', HELPERS['qualify.py'], 'remote_cpu_qualification')
    native = load(HERE / 'helpers/native.py', HELPERS['native.py'], 'remote_cpu_recorder')
    hot = load(HERE / 'helpers/hot.py', HELPERS['hot.py'], 'remote_cpu_owned_groups')
    need(sha(HERE / 'helpers/base.py') == HELPERS['base.py'], 'exact transitive recorder')
    p.SOURCE = SOURCE
    return p, native, hot


def files(root):
    need(root.is_dir() and not root.is_symlink() and root.resolve() == root, 'canonical ordinary root')
    result = {}
    for path in root.rglob('*'):
        info = path.lstat()
        need(not path.is_symlink(), 'no owned-tree symlink')
        if stat.S_ISDIR(info.st_mode):
            continue
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'owned ordinary single-link file')
        result[path.relative_to(root).as_posix()] = {'sha256': sha(path), 'bytes': info.st_size,
                                                   'mode': stat.S_IMODE(info.st_mode)}
    return result


def source_snapshot(p):
    record = CANDIDATE / 'record.json'
    need(type(RECORD_SHA) is str and re.fullmatch(r'[0-9a-f]{64}', RECORD_SHA), 'reviewed exported source pin required')
    need(sha(record) == RECORD_SHA, 'exact local candidate export record')
    value = p.parse_json(record.read_bytes())
    expected = {name: {key: entry[key] for key in ('sha256', 'bytes', 'mode')}
                for name, entry in value['candidate_inventory'].items()}
    observed = files(SOURCE)
    need(observed == expected and len(observed) == value['source_count'], 'complete frozen multi-GPU source')
    controls = files(CANDIDATE / 'controls')
    need(controls == value['controls'], 'complete portable parser and source-control inputs')
    for name, expected_sha in value['unsigned_overlay'].items():
        need(sha(SOURCE / name) == expected_sha, 'actual reviewed multi-GPU overlay')
    for folder in {HERE / 'cargo-home', *(parent / '.cargo' for parent in SOURCE.parents)}:
        for name in ('config', 'config.toml'):
            need(not os.path.lexists(folder / name), 'no unbound inherited Cargo configuration')
    return {'record_sha256': RECORD_SHA, 'sources': observed, 'controls': controls}


def tools(p):
    selected = {TC / 'bin' / name for name in ('cargo', 'rustc', 'clippy-driver', 'cargo-clippy', 'rustdoc')}
    selected.update(path for path in (TC / 'lib').iterdir() if path.is_file())
    selected.update(path for path in (TC / 'lib/rustlib/x86_64-unknown-linux-gnu/lib').iterdir() if path.is_file())
    result = {str(path): p.identity(path) for path in sorted(selected)}
    rust = {path: item['sha256'] for path, item in result.items()}
    need(len(result) == 325 and hashlib.sha256(canonical(rust)).hexdigest() == RUST_SHA,
         'actual remote compiler/std closure, not the local 327-entry closure')
    for name, expected in PLATFORM.items():
        result[name] = p.identity(Path(name))
        need(result[name]['sha256'] == expected, 'remote platform tool identity')
    return result


def namespace():
    pid = os.readlink('/proc/self/ns/pid')
    child = os.readlink('/proc/self/ns/pid_for_children')
    need(pid == child and re.fullmatch(r'pid:\[[0-9]+\]', pid), 'identical owner/child PID namespace')
    return {'pid_namespace': pid, 'child_pid_namespace': child}


def owner(marker):
    need(re.fullmatch(re.escape(PREFIX) + r'[0-9a-f]{16}', str(HERE)), 'exact remote private root prefix')
    info = HERE.lstat()
    need(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and
         stat.S_IMODE(info.st_mode) == 0o700 and HERE.resolve() == HERE, 'private canonical owned root')
    need(sha(HERE / 'owner-marker.json') == marker, 'exact transport ownership marker')
    return {'path': str(HERE), 'device': info.st_dev, 'inode': info.st_ino, 'uid': info.st_uid,
            'marker_sha256': marker}


def resources(*, startup=False, admit=False):
    info = os.statvfs(HERE)
    available = info.f_bavail * info.f_frsize
    memory = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                      if line.startswith('MemAvailable:'))) * 1024
    inventory = {}
    for path in HERE.rglob('*'):
        current = path.lstat()
        need(not path.is_symlink(), 'no owned resource-tree symlink')
        if stat.S_ISDIR(current.st_mode):
            continue
        need(stat.S_ISREG(current.st_mode), 'only ordinary resource-tree files')
        inventory[path.relative_to(HERE).as_posix()] = current.st_size
    size = lambda prefixes: sum(size for name, size in inventory.items() if name.startswith(prefixes))
    target = size(('target-no-default/', 'target-all-features/', 'target-metadata/'))
    cache = size(('cache-seed/', 'cargo-home/'))
    source = size(('candidate-attempt-1/',))
    records = sum(inventory.values()) - target - cache - source
    need(available >= DISK + (OWNED if startup else 0), '4 GiB disk floor plus startup allowance')
    need(target <= TARGET_LIMIT and cache <= CACHE_LIMIT and source <= SOURCE_LIMIT and records <= RECORD_LIMIT,
         'separate source/cache/target/record budgets')
    need(sum(inventory.values()) <= OWNED, '3 GiB combined owned-root budget')
    if startup or admit:
        need(memory >= RAM + OWNED, '64 GiB RAM plus 3 GiB allowance at command admission')
    return {'disk_available_bytes': available, 'memory_available_bytes': memory,
            'target_bytes': target, 'cache_bytes': cache, 'source_bytes': source, 'records_bytes': records,
            'ram_checked_for_admission': startup or admit,
            'guard': 'stage-boundary-only-not-continuous-not-quota'}


def environment(mode):
    target = HERE / 'target-metadata/target' if mode == 'metadata' else HERE / 'target-all-features'
    return {'HOME': str(HERE / 'home'), 'PATH': str(TC / 'bin') + ':/usr/bin:/bin',
            'LD_LIBRARY_PATH': str(TC / 'lib'),
            'RUSTC': str(TC / 'bin/rustc'), 'RUSTDOC': str(TC / 'bin/rustdoc'),
            'CARGO_HOME': str(HERE / 'cargo-home'), 'CARGO_TARGET_DIR': str(target),
            'RUSTUP_HOME': str(HERE / 'rustup-home'), 'PYTHONDONTWRITEBYTECODE': '1',
            'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
            'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
            'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true', 'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true',
            'CARGO_PROFILE_RELEASE_OPT_LEVEL': '3', 'CARGO_PROFILE_RELEASE_DEBUG': '0',
            'CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS': 'false', 'CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS': 'false',
            'CARGO_NET_OFFLINE': 'true', 'CARGO_TERM_COLOR': 'never',
            'CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER': '/usr/bin/cc',
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TMPDIR': str(HERE / 'tmp'),
            'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
            'GIT_OPTIONAL_LOCKS': '0', 'RUST_TEST_THREADS': '1'}


def expected_rosters(p):
    record = p.parse_json((CANDIDATE / 'record.json').read_bytes())
    groups = record['required_tests']
    need(groups and all(names == sorted(set(names)) and names for names in groups.values()),
         'exact new source-selected runtime test groups')
    need(len(record['runtime_ignored']) == 32, 'unchanged native ignored roster')
    return groups


def results():
    record = json.loads((CANDIDATE / 'record.json').read_bytes())
    modules = []
    for name in ('cpu_results_v1.py', 'cpu_results_v2.py', 'cpu_workspace_v1.py'):
        modules.append(load(CANDIDATE / 'controls' / name, record['controls'][name]['sha256'], 'a4_' + name[:-3]))
    return modules[0], modules[1], None, modules[2]


def stages():
    rows = []
    def add(name, argv, seconds, kind, mode='no-default'):
        rows.append({'name': name, 'argv': argv, 'seconds': seconds, 'kind': kind, 'mode': mode})
    attest = [PYTHON, '-I', '-B', str(HERE / 'cpu.py'), '--attest']
    add('opening-attestation', attest, 30, 'attest')
    for name, flag in (('rustc', '-vV'), ('cargo', '-V'), ('clippy-driver', '--version')):
        add(name + '-version', [str(TC / 'bin' / name), flag], 30, 'version')
    loader_path = str(TC / 'lib/rustlib/x86_64-unknown-linux-gnu/lib') + ':' + str(TC / 'lib')
    smoke = ('import os; e=dict(os.environ); e["LD_LIBRARY_PATH"]=' + repr(loader_path) +
             '; p=' + repr(str(TC / 'bin/rustc')) + '; os.execve(p,[p,"-vV"],e)')
    add('rustc-build-script-loader-smoke', [PYTHON, '-I', '-B', '-c', smoke], 30, 'loader-smoke')
    add('workspace-metadata', [str(TC / 'bin/cargo'), 'metadata', '--offline', '--locked', '--no-deps',
                                '--format-version', '1'], 60, 'metadata', 'metadata')
    add('source-controls', [PYTHON, '-I', '-B', str(HERE / 'source_controls.py'), '--candidate',
                             str(CANDIDATE), '--record-sha256', RECORD_SHA], 120, 'controls')
    for name in ('test_cpu_results_v1.py', 'test_cpu_results_v2.py', 'test_cpu_workspace_v1.py'):
        add(name[:-3], [PYTHON, '-I', '-B', str(CANDIDATE / 'controls' / name)], 60, 'parser-controls')
    common = ['--frozen', '--offline', '--jobs', '1', '--message-format=json']
    add('runtime-no-default-check', [str(TC / 'bin/cargo'), 'check', *common, '-p', 'fe2o3-runtime',
                                      '--no-default-features', '--lib'], 900, 'cargo')
    add('runtime-strict-clippy', [str(TC / 'bin/cargo'), 'clippy', *common, '-p', 'fe2o3-runtime',
                                 '--all-features', '--lib', '--tests', '--example', EXAMPLE,
                                 '--', '-D', 'warnings'], 1200, 'cargo')
    mode = 'runtime-debug'
    add(mode + '-test-build', [str(TC / 'bin/cargo'), 'test', *common, '-p', 'fe2o3-runtime',
                               '--all-features', '--lib', '--no-run'], 1800, 'build', mode)
    add(mode + '-test-list', ['@' + mode, '--list', '--color=never'], 120, 'list', mode)
    add(mode + '-ignored-list', ['@' + mode, '--list', '--ignored', '--color=never'], 120, 'ignored', mode)
    add(mode + '-full-suite', ['@' + mode, '--test-threads=1', '-Z', 'unstable-options', '--format=json'],
        1800, 'full', mode)
    add('smoke-example-test-build', [str(TC / 'bin/cargo'), 'test', *common, '-p', 'fe2o3-runtime',
                                     '--all-features', '--example', EXAMPLE, '--no-run'], 1200, 'build', 'smoke-tests')
    add('smoke-example-test-list', ['@smoke-tests', '--list', '--color=never'], 120, 'list', 'smoke-tests')
    add('smoke-example-cli-suite', ['@smoke-tests', '--test-threads=1', '-Z', 'unstable-options', '--format=json'],
        120, 'example-tests', 'smoke-tests')
    add('smoke-example-build', [str(TC / 'bin/cargo'), 'build', *common, '-p', 'fe2o3-runtime',
                                '--all-features', '--example', EXAMPLE], 1200, 'build', 'smoke-example')
    add('closing-attestation', attest, 30, 'attest')
    need(len(rows) == 21 and sum(row['seconds'] for row in rows) == 9120, 'exact runtime-only command budget')
    return rows
