"""Offline record consistency and strict endpoint checks, not native refinement."""
import hashlib
from pathlib import Path
import sys
from types import ModuleType

root = Path(__file__).resolve().parent
raw = (root / "protocol.py").read_bytes()
if hashlib.sha256(raw).hexdigest() != "384cf35d5f3471c4fe0b2228e39963f647383fbbb63e2475d64d643be2d40be1":
    raise ValueError("protocol pin")
p = ModuleType("protocol")
exec(compile(raw, "protocol.py", "exec"), p.__dict__)
observer = p.load_module(root / "observer.py", p.OBSERVER_SHA, "observer")
p.need(sys.flags.isolated and sys.flags.dont_write_bytecode, "isolated Python")
test = "kfd_backend::native_budget::generated_composed_tests::native_generated_composed_admission_pressure_gate_and_refund"
remote = root / "remote"
owned = Path((remote / "owner").read_text().strip())
rows = {}
for name in ("before", "test", "immediate", "delayed"):
    folder = remote / "results" / name
    row = p.parse((folder / "record.json").read_text())
    p.need(row["status"] == 0 and row["error"] is None and row["group_absent"] is True, "closed successful group")
    p.need(row["cwd"] == str(owned) and row["environment"] == p.environment(owned), "owned command environment")
    p.need(row["stdout_sha256"] == p.sha(folder / "stdout.log") and row["stderr_sha256"] == p.sha(folder / "stderr.log"), "transcript identity")
    p.need((folder / "stderr.log").read_bytes() == b"", "empty stderr")
    rows[name] = row
before = p.endpoint((remote / "results/before/stdout.log").read_bytes(), observer)
test_row = rows["test"]
p.need(0 <= test_row["spawned"]["monotonic_ns"] - p.stamp(before["finished"]) <= 10**9, "fresh preflight")
p.need(test_row["command"] == ["/usr/bin/timeout", "--signal=TERM", "--kill-after=5s", "60s",
    str(owned / "runtime-tests"), "--exact", test, "--ignored", "--nocapture", "--test-threads=1"], "exact test command")
endpoints = [before]
for name, offset in (("immediate", 0), ("delayed", 20)):
    endpoints.append(p.endpoint((remote / "results" / name / "stdout.log").read_bytes(), observer,
        t0=test_row["t0"]["monotonic_ns"], offset=offset))
transcript = (remote / "results/test/stdout.log").read_text()
p.need(transcript.count("running 1 test") == 1 and transcript.count("test " + test + " ... ") == 1, "exact harness")
p.need("test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 1847 filtered out;" in transcript, "complete harness summary")
p.need("generated_composed uid=" + p.UID + " domain_pressure=passed request_pressure=passed gate=generated_only refund=bootstrap no_vm_or_dispatch=true" in transcript, "assertion marker")
finished = p.parse((remote / "results/finished.json").read_text())
p.need(finished["test"] == test and finished["failures"] == [], "controller success")
p.need(finished["elf_sha256"] == p.sha(root / "runtime-tests") == (remote / "elf.sha256").read_text().split()[0], "executed ELF join")
p.need((remote / "source.commit").read_bytes() == (root / "source.commit").read_bytes(), "source commit join")
p.need((remote / "source.sha256").read_bytes() == (root / "source.sha256").read_bytes(), "source manifest join")
print(p.json.dumps({"test_passes": 1, "strict_endpoints": 3, "closed_groups": len(rows),
    "elf_sha256": finished["elf_sha256"], "vram_bytes": [int(sample["values"]["mem_info_vram_used"])
        for endpoint in endpoints for sample in endpoint["sysfs"]],
    "scope": "record consistency and admission/accounting assertions; no protected execution or formal native refinement"}, indent=2))
