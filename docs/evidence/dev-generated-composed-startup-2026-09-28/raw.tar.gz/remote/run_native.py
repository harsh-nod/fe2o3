"""One no-VM admission test with pinned endpoint and owned-group recording."""
import hashlib
from pathlib import Path
import resource
import signal
import sys
import time
from types import ModuleType

ROOT = Path(__file__).resolve().parent
TEST = "kfd_backend::native_budget::generated_composed_tests::native_generated_composed_admission_pressure_gate_and_refund"


def load(name, digest):
    path = ROOT / (name + ".py")
    raw = path.read_bytes()
    if path.is_symlink() or hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError("pinned helper mismatch: " + name)
    module = ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module


p = load("protocol", "384cf35d5f3471c4fe0b2228e39963f647383fbbb63e2475d64d643be2d40be1")
r = load("recorder", "3960b587fb80c45af05f8c906ef7067ccc8b3a28d4ad161e8ff7a10ccd4f354c")
observer = load("observer", "5d37b09bf0823854c6a45b914d866c042c1e65486cd96c6301285a0147ae6c51")
p.need(sys.flags.isolated and sys.flags.dont_write_bytecode, "isolated Python")
p.need(ROOT.name.startswith("fe2o3-generated-composed-20260928."), "owned prefix")
p.need((ROOT / "owner").read_text().strip() == str(ROOT), "owned marker")
elf_sha = (ROOT / "elf.sha256").read_text().split()[0]
p.need(p.sha(ROOT / "runtime-tests") == elf_sha, "ELF input identity")
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
for number in r.MANAGED:
    signal.signal(number, r.interrupted)
rec = r.Recorder(ROOT)
rec.environment = p.environment(ROOT)
(ROOT / "tmp").mkdir()


def endpoint(name, t0=None, offset=None):
    row, out, err = rec.run(name, ["/usr/bin/python3", "-I", "-B", str(ROOT / "observer.py"),
        "--gpu-index", str(p.GPU), "--pci-bdf", p.BDF, "--unique-id", p.UID, "--samples", "1"], 75)
    p.need(r.passed(row) and not err.read_bytes(), "observer command")
    return p.endpoint(out.read_bytes(), observer, t0=t0, offset=offset)


failures = []
try:
    before = endpoint("before")
    row, out, err = rec.run("test", ["/usr/bin/timeout", "--signal=TERM", "--kill-after=5s", "60s",
        str(ROOT / "runtime-tests"), "--exact", TEST, "--ignored", "--nocapture", "--test-threads=1"],
        70, p.stamp(before["finished"]))
    p.need(row["group_absent"] and row["t0"] is not None, "reaped test group")
    t0 = row["t0"]["monotonic_ns"]
    for name, offset in [("immediate", 0), ("delayed", 20)]:
        time.sleep(max(0, (t0 + offset * 10**9 - time.monotonic_ns()) / 1e9))
        try:
            endpoint(name, t0, offset)
        except Exception as error:
            failures.append(name + ": " + repr(error))
    p.need(r.passed(row) and not err.read_bytes(), "exact native test success")
    text = out.read_text()
    p.need("test result: ok. 1 passed; 0 failed; 0 ignored;" in text and TEST in text, "test summary")
    p.need("generated_composed uid=" + p.UID + " domain_pressure=passed request_pressure=passed gate=generated_only refund=bootstrap no_vm_or_dispatch=true" in text,
           "admission assertions reached final marker")
except BaseException as error:
    failures.append(repr(error))
finally:
    if r.ACTIVE is not None:
        r.stop_owned(r.ACTIVE)
    p.need(p.sha(ROOT / "runtime-tests") == elf_sha, "ELF closing identity")
    r.write(rec.output / "finished.json", {"test": TEST, "elf_sha256": elf_sha, "failures": failures,
        "scope": "checked-device accounting only; no VM, allocation, dispatch, performance or protected Worker execution"})
if failures:
    raise SystemExit(1)
