#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-reactor-20261004-l38LUIL2
[[ $EUID == 0 ]]
for case in poll-pair poll-cancel-proof poll-cancel-gated poll-drop-gated poll-deadline poll-proof-deadline poll-probe-timeout good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison; do
    log="$scratch/$case-final2.log"
    grep -q '^test result: ok. 1 passed; 0 failed;' "$log"
    grep -q '^PASS: no live task remains in pid:' "$scratch/$case-final2-namespace.log"
    scope=$(sed -n 's/^outer cgroup removed: //p' "$log")
    [[ $scope == /sys/fs/cgroup/*/fe2o3-custodian-qual-* && $scope != *$'\n'* && ! -e $scope ]]
    printf 'PASS %s: test, empty PID namespace, removed outer scope\n' "$case"
done
for case in poll-pair poll-cancel-proof poll-proof-deadline poll-probe-timeout; do
    [[ -s "$scratch/$case-final2/subject.bin" ]]
    grep -q '^alternating startup polls:' "$scratch/$case-final2/polls.txt"
    grep -q '^alternating proof/cancellation polls:' "$scratch/$case-final2/polls.txt"
    grep -q 'controller reaped; owned scope absent; sibling survived' "$scratch/$case-final2/cleanup.txt"
done
[[ -s "$scratch/poll-cancel-proof-final2/verifier-command.bin" ]]
[[ -s "$scratch/poll-pair-final2/second-subject.bin" ]]
printf 'PASS: genuine concurrent proof subjects and live-Verus cancellation captured\n'
