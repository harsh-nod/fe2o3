#!/bin/bash
set -euo pipefail
[[ $EUID == 0 ]]
readonly capture=${1:?exact capture directory}
readonly expected=$(<"$capture/pid-namespace.txt")
[[ $expected =~ ^pid:\[[0-9]+\]$ ]]
[[ $expected != "$(readlink /proc/self/ns/pid)" ]]
for attempt in {1..100}; do
    live=()
    for path in /proc/[0-9]*/task/[0-9]*/ns/pid; do
        if ! actual=$(readlink "$path" 2>/dev/null); then
            if [[ -L $path ]]; then
                printf 'FAIL: could not inspect live namespace link %s\n' "$path" >&2
                exit 1
            fi
            continue
        fi
        if [[ $actual == "$expected" ]]; then
            live+=("$path")
        fi
    done
    if [[ ${#live[@]} == 0 ]]; then
        printf 'PASS: no live task remains in %s after wrapper exit\n' "$expected"
        exit 0
    fi
    sleep 0.1
done
printf 'FAIL: tasks remain in %s: %s\n' "$expected" "${live[*]}" >&2
exit 1
