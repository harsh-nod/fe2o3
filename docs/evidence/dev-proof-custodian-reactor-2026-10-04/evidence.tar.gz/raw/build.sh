#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-proof-custodian -p fe2o3-protected-service-spawn -p fe2o3-protected-service-profile
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-proof-custodian -p fe2o3-protected-service-spawn --all-targets -- -D warnings
CARGO_TARGET_DIR=target/qualification-static-deployment/cargo \
    cargo +nightly-2026-04-03 rustc --locked --offline --release --target x86_64-unknown-linux-musl \
    -p fe2o3-proof-custodian --bin fe2o3-conditional-fill-proof-controller -- \
    -C target-feature=+crt-static -C relocation-model=static -C link-arg=-static \
    -C link-arg=-no-pie -C link-arg=-Wl,-e,fe2o3_secure_start_v1
cargo +nightly-2026-04-03 fmt -p fe2o3-proof-custodian -p fe2o3-protected-service-spawn --check
git diff --check
git diff --cached --check
