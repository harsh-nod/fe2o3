#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-reactor-20261004-l38LUIL2
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly destination="$repo/docs/evidence/dev-proof-custodian-reactor-2026-10-04/evidence.tar.gz"
[[ $EUID == 0 && ! -e $scratch/package && ! -e $destination ]]
mkdir -m 700 "$scratch/package"
mkdir "$scratch/package/raw" "$scratch/package/captures" "$scratch/package/diagnostics"
cp "$scratch/raw/"* "$scratch/package/raw/"
cp "$scratch/deployment-v1" "$scratch/package/raw/"
cp "$scratch/build-final2.log" "$scratch/static-elf-final2.log" "$scratch/prepare-reactor2.log" \
    "$scratch/campaign-final2.log" "$scratch/final-results.log" "$scratch/prepare-runtime.log" \
    "$scratch/final-source-check.log" "$scratch/final-binary-check.log" "$scratch/package/raw/"
cp -r "$scratch/captures/inputs-2" "$scratch/package/captures/"
for case in poll-pair poll-cancel-proof poll-cancel-gated poll-drop-gated poll-deadline poll-proof-deadline poll-probe-timeout good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison; do
    cp "$scratch/$case-final2.log" "$scratch/$case-final2-namespace.log" "$scratch/package/raw/"
    cp -r "$scratch/$case-final2" "$scratch/package/captures/"
done
cp "$scratch/build.log" "$scratch/build-final.log" "$scratch/poll-pair-final.log" \
    "$scratch/poll-pair-final-namespace.log" "$scratch/package/diagnostics/"
cd "$scratch/package"
find raw captures diagnostics -type f -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum -c MANIFEST.sha256 > "$scratch/package-check.log"
tar --sort=name -cf - MANIFEST.sha256 raw captures diagnostics | gzip -n > "$destination"
chown 1000:1000 "$destination"
chmod 0644 "$destination"
sha256sum "$destination"
