#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-reactor-20261004-l38LUIL2
readonly binary=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_proof_custodian-849eb3b1efa9a34b
for case in poll-pair poll-cancel-proof poll-cancel-gated poll-drop-gated poll-deadline poll-proof-deadline poll-probe-timeout good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison; do
    printf 'START %s %s\n' "$case" "$(date -u +%FT%TZ)"
    bash "$scratch/raw/run.sh" "$case-final2" "$case" "$binary"
    printf 'PASS %s %s\n' "$case" "$(date -u +%FT%TZ)"
done
