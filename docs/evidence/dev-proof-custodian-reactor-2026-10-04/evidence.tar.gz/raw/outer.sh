#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-reactor-20261004-l38LUIL2
[[ $EUID == 0 ]]
member=$(</proc/self/cgroup)
[[ $member == 0::/* && $member != *$'\n'* ]]
readonly parent="/sys/fs/cgroup/${member#0::/}"
readonly scope=$(mktemp -d "$parent/fe2o3-custodian-qual-XXXXXXXX")
cleanup() {
    local status=$?
    trap - EXIT
    printf '1\n' > "$scope/cgroup.kill"
    for attempt in {1..1000}; do
        if ! grep -q '^populated 1$' "$scope/cgroup.events"; then break; fi
        sleep 0.01
    done
    if grep -q '^populated 1$' "$scope/cgroup.events"; then
        printf 'FAIL: owned qualification scope still populated: %s\n' "$scope" >&2
        exit 99
    fi
    # These can only be fresh controller scopes inside our newly created outer scope.
    for child in "$scope"/fe2o3-proof-*; do
        [[ -d $child ]] || continue
        printf 'FAIL: launcher left an empty owned scope: %s\n' "$child" >&2
        rmdir -- "$child"
        status=98
    done
    rmdir -- "$scope"
    printf 'outer cgroup removed: %s\n' "$scope"
    exit "$status"
}
trap cleanup EXIT
(
    printf '%s\n' "$BASHPID" > "$scope/cgroup.procs"
    export FE2O3_CUSTODIAN_HOST_PID_NAMESPACE=$(readlink /proc/self/ns/pid)
    exec timeout --kill-after=15s 400s /bin/bash "$scratch/raw/isolated-runtime.sh" "$@"
) &
child=$!
wait "$child"
