#!/usr/bin/env python3
"""Gathered-frame compute consumers plus current-source peer regression controls."""
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0xb7baafd0fb173d8e', '0x10a254ce4987e716', '0x53691ef168a0147d']
GATHER4 = ['0x54f88318ca05093d', *IDS]
CARDS = ['card4', 'card5', 'card6', 'card7']
BD = ['0000:85:00.0', '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
BASELINE = None
CASES = [
    ('gather-compute-forward', 'deferred', ['--gather-compute'], IDS),
    ('gather-compute-reverse', 'deferred', ['--gather-compute'], IDS[::-1]),
    ('gather-compute-overlap-forward', 'deferred', ['--gather-compute-overlap'], IDS),
    ('gather-compute-overlap-reverse', 'deferred', ['--gather-compute-overlap'], IDS[::-1]),
    ('gather-compute-three-sources-forward', 'deferred', ['--gather-compute'], GATHER4),
    ('gather-compute-three-sources-reverse', 'deferred', ['--gather-compute'], GATHER4[::-1]),
    ('gather-compute-three-overlap-forward', 'deferred', ['--gather-compute-overlap'], GATHER4),
    ('gather-compute-three-overlap-reverse', 'deferred', ['--gather-compute-overlap'], GATHER4[::-1]),
    ('gather-forward', 'live-sharded', ['--gather'], IDS),
    ('gather-reverse', 'live-sharded', ['--gather'], IDS[::-1]),
    ('gather-overlap-forward', 'live-sharded', ['--gather-overlap'], IDS),
    ('gather-overlap-reverse', 'live-sharded', ['--gather-overlap'], IDS[::-1]),
    ('gather-three-sources-forward', 'live-sharded', ['--gather'], GATHER4),
    ('gather-three-sources-reverse', 'live-sharded', ['--gather'], GATHER4[::-1]),
    ('gather-three-overlap-forward', 'live-sharded', ['--gather-overlap'], GATHER4),
    ('gather-three-overlap-reverse', 'live-sharded', ['--gather-overlap'], GATHER4[::-1]),
    ('compute-window-forward', 'deferred', ['--return-window'], IDS[1:]),
    ('compute-window-reverse', 'deferred', ['--return-window'], IDS[1:][::-1]),
    ('late-compute-window-forward', 'deferred', ['--late-compute', '--return-window'], IDS[1:]),
    ('late-compute-window-reverse', 'deferred', ['--late-compute', '--return-window'], IDS[1:][::-1]),
    ('subrange-readback-chain-forward', 'directed', ['--subranges', '--readback'], IDS),
    ('subrange-readback-chain-reverse', 'directed', ['--subranges', '--readback'], IDS[::-1]),
    ('late-compute-forward', 'deferred', ['--late-compute'], IDS[1:]),
    ('late-compute-reverse', 'deferred', ['--late-compute'], IDS[1:][::-1]),
    ('deferred-chain-forward', 'deferred', [], IDS[1:]),
    ('deferred-chain-reverse', 'deferred', [], IDS[1:][::-1]),
    ('live-sharded-2', 'live-sharded', [], IDS[1:]),
    ('live-sharded-2-reverse', 'live-sharded', [], IDS[1:][::-1]),
]
LIMITATIONS = [
    'point observations, not continuous attachment census',
    'finite trusted-artifact qualification, not general kernel authority',
    'finite ordinary producer chain, not arbitrary dependency graph support',
    'compute may eagerly publish before explicit progress; physical overlap is unmeasured',
    'native completion counter is observed for directed, deferred and live cases',
    'live cases reuse logical handles; physical mapping identity is not independently observed',
    'live snapshots use serialized settled host reads, not drain-capture byte-credit ownership',
    'ACQUIRE_VM admission lasts until process exit; same-process reopen is unsupported',
    'directed copy and return-window cases observe full postcopy source bytes; legacy compute controls do not',
    'native faults, general kernel authority and physical overlap are not qualified',
    'late modes observe sole native root retained after publication; fence currentness and overlap are not observed',
    'readback late admission follows bounded seed; readback parent publication is not independently observed',
    'subrange guards cover logical owner bytes, not hidden physical pool padding',
    'pending compute writers remain exact full-allocation Write; only their peer reads are contained windows',
    'new gathered-frame consumers are prequeued; late gathered-ancestor admission is CPU-qualified only',
    'new gathered-frame witness does not qualify repeated expired-deadline command-future resumption',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_receipt(name, argv):
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout = (folder / 'stdout').read_bytes()
    stderr = (folder / 'stderr').read_bytes()
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert receipt['exit_code'] == 0, (name, receipt, stderr)
    assert not receipt['timed_out'] and receipt['local_process_group_absent'], (name, receipt)
    return receipt, stdout, stderr


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    receipt, stdout, stderr = read_receipt(name, argv)
    assert process.returncode == receipt['exit_code'], (name, receipt, stderr)
    return stdout.decode()


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def remote(name, argv, bound='30s'):
    return capture(name, remote_argv(argv, bound))


def initial_baseline():
    receipt, stdout, stderr = read_receipt('initial-availability', remote_argv(AVAILABILITY))
    assert not stderr
    finished = datetime.fromisoformat(receipt['finished'])
    age = (datetime.now(timezone.utc) - finished).total_seconds()
    assert 0 <= age <= 300, 'initial availability is stale; capture a fresh campaign packet'
    return json.loads(stdout)


def admit(name):
    assert BASELINE is not None
    state = json.loads(remote(name + '-availability', AVAILABILITY))
    for card, uid, bdf in zip(CARDS, GATHER4, BD):
        assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bdf
        assert BASELINE[card]['Unique ID'] == uid and BASELINE[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == BASELINE[card]['GPU use (%)'] == '0'
        assert state[card]['VRAM Total Memory (B)'] == BASELINE[card]['VRAM Total Memory (B)']
        assert state[card]['VRAM Total Used Memory (B)'] == BASELINE[card]['VRAM Total Used Memory (B)']
    assert state['system'] == BASELINE['system'], 'changed PID roster; stop and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
        assert pid not in records and not {card.removeprefix('card') for card in CARDS}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system']), (records, state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    return state


@lru_cache(maxsize=1)
def global_digests():
    digests = tuple(sha(b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                               for global_index in range(65537)))
                    for round_index in (0, 1))
    assert digests[0] != digests[1]
    return digests


def expected(kind, flags, ids):
    if kind == 'deferred' and flags in (['--gather-compute'], ['--gather-compute-overlap']):
        return expected_gather_compute(flags, ids)
    if kind == 'live-sharded' and flags in (['--gather'], ['--gather-overlap']):
        return expected_gather(flags, ids)
    if kind == 'directed' and '--subranges' in flags:
        assert flags in ([ '--subranges' ], ['--subranges', '--fanout'],
            ['--subranges', '--readback'], ['--subranges', '--fanout', '--readback'],
            ['--subranges', '--readback', '--late-peer'],
            ['--subranges', '--fanout', '--readback', '--late-peer'])
        assert len(ids) == len(set(ids)) == 3
        readback = '--readback' in flags
        return dict(schema='fe2o3.native-peer-subranges.v1',
            authority='production-deny-all', transport='NATIVE-XGMI',
            mode='fanout' if '--fanout' in flags else 'chain', devices='3',
            unique_ids=','.join(ids), rounds='2', bytes_per_copy='8388581',
            logical_extents='8388838,8389350,8389734', peer_offsets='17,131,509',
            readback_offset='97', readback=str(readback).lower(),
            late_peer=str('--late-peer' in flags).lower(), peer_copies='4',
            native_packets='12', observed_native_copies='4', native_counter='0,2,4',
            allocations='6', streams='4' if readback else '3', launches='0', modules='0',
            completion_receipts='6' if readback else '4', readbacks='16' if readback else '12',
            d2h_copies='2' if readback else '0',
            progress='readback-only-after-seed' if readback else 'final-directed-peer-only-after-seed',
            first_publication_observed=str('--late-peer' in flags).lower(),
            public_events='released-before-tail-drive', observers='pending',
            expired_drain='rejected', journal='enabled', source_unchanged='full-byte-pass',
            outside_destination_ranges='full-byte-pass', output='full-byte-pass',
            readback_guards='full-byte-pass' if readback else 'not-requested',
            digest='length-prefixed-devices-and-optional-readback',
            round_sha256=','.join(subrange_digests(readback)), rounds_changed='true',
            allocation_reuse='true', contexts='1', cleanup='logical-and-native-explicit',
            physical_overlap='unmeasured', performance_acceptance='false', formal_refinement='false')
    if kind == 'directed':
        assert flags in ([], ['--fanout'], ['--readback'], ['--fanout', '--readback'],
                         ['--readback', '--late-peer'], ['--fanout', '--readback', '--late-peer'])
        assert len(ids) == len(set(ids)) == 3
        fanout = '--fanout' in flags
        fields = dict(schema='fe2o3.directed-peer-copy-smoke.v1',
            authority='production-deny-all', transport='NATIVE-XGMI',
            mode='fanout' if fanout else 'chain', devices='3', unique_ids=','.join(ids),
            rounds='2', bytes_per_copy='8388581', peer_copies='4', native_packets='12',
            observed_native_copies='4', native_counter='0,2,4', allocations='6', streams='3',
            launches='0', modules='0', completion_receipts='4', readbacks='12',
            admission='both-before-progress', progress='final-directed-peer-only',
            first_seed='two-bounded-steps' if fanout else 'none',
            public_events='released-before-progress', pre_progress_observers='pending',
            expired_drain='rejected', journal='enabled', source_unchanged='full-byte-pass',
            destination_sentinels='full-byte-pass', output='full-byte-pass',
            round_sha256=','.join(directed_digests()), rounds_changed='true',
            allocation_reuse='true', contexts='1', drain='completed-only',
            cleanup='logical-and-native-explicit', physical_overlap='unmeasured',
            performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 37
        if '--readback' in flags:
            fields.update(schema='fe2o3.directed-peer-readback-smoke.v1',
                streams='4', completion_receipts='6', readbacks='16',
                admission='peers-before-progress', progress='readback-only-after-seed',
                public_events='released-after-readback-admission-before-tail-drive',
                drain='pending-readback-then-completed-peers', d2h_copies='2',
                readback_admission='before-progress,after-bounded-seed',
                readback_admission_native_counts='0,3', tail_seed_steps='2' if fanout else '3',
                publication_observed='false', readback_sentinels='full-byte-pass')
            assert len(fields) == 43
        if '--late-peer' in flags:
            fields.pop('pre_progress_observers')
            fields.pop('publication_observed')
            fields.update(schema='fe2o3.late-directed-peer-readback-smoke.v1',
                admission='second-after-first-publication', first_seed='observed-native-publication',
                pre_tail_observers='pending',
                readback_admission='before-tail-progress,after-bounded-seed',
                readback_publication_observed='false', first_publication_observed='true',
                retained_at_peer_admission='1')
            assert len(fields) == 45
        return fields
    if kind == 'deferred':
        assert flags in ([], ['--late-compute'], ['--return-window'],
                         ['--late-compute', '--return-window']) and len(ids) == len(set(ids)) == 2
        output = b''.join(struct.pack('<f', (index & 63) / 4 + (index & 31))
                          for index in range(65536))
        assert len(output) == 262144
        fields = dict(schema='fe2o3.deferred-peer-chain-smoke.v1',
            authority='qualification-r57-n3-v2', devices='2', unique_ids=','.join(ids),
            elements='65536', bytes='262144', padding_bytes='0', launches='4',
            setup_launches='3', pipeline_launches='1', peer_copies='2',
            dependent_readbacks='1', completion_receipts='4',
            pipeline='peer-deferred-compute-peer-readback',
            admission='all-four-before-explicit-progress',
            compute_admission='deferred-before-first-peer-completion',
            progress='final-readback-stream-only',
            public_events='released-after-dependent-admission',
            native_transport='NATIVE-XGMI', native_counter='0,2',
            initial_peer_sentinel='full-byte-pass', final_peer_sentinel='full-byte-pass',
            output='full-byte-pass', padding='exact-page-extent', output_sha256=sha(output),
            snapshot='settled-host-visible-owner-command', host_output_installations='0',
            journal='enabled', retained_results='4', allocations='12', modules='2',
            streams='5', contexts='1', owners='1', pipeline_host_joins='0',
            results_release='readback-peer-compute-peer', final_drain='completed-only',
            cleanup='owned-shutdown-explicit', source_preservation='unobserved',
            physical_overlap='unmeasured', performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 42
        if '--late-compute' in flags:
            fields.update(schema='fe2o3.late-deferred-peer-chain-smoke.v1',
                admission='consumer-tail-after-first-native-publication',
                compute_admission='deferred-after-first-peer-publication',
                progress='first-peer-until-retained-then-final-readback-only',
                initial_peer='directed', retained_native_at_compute_admission='1',
                retained_native_counter='0,1,0', publication_observed='true')
            assert len(fields) == 46
        if '--return-window' in flags:
            fields.pop('padding_bytes')
            returned = bytearray([0xa5]) * 262913
            host = bytearray([0x5a]) * 263297
            returned[131:262211] = output[20:262100]
            host[97:262177] = output[20:262100]
            assert (len(output), len(returned), len(host)) == (262144, 262913, 263297)
            digest = hashlib.sha256(b'fe2o3.pending-compute-return-window.v1\0')
            for contents in (output, returned, host):
                digest.update(struct.pack('<Q', len(contents)))
                digest.update(contents)
            fields.update(schema='fe2o3.pending-compute-return-window.v1',
                kernel_padding_bytes='0',
                padding='logical-guards-checked', snapshot='settled-full-D-E-host-owner-command',
                source_preservation='full-computed-source-byte-pass',
                output_sha256=digest.hexdigest(), return_window='true',
                logical_extents='262144,262913,263297', peer_offsets='20,131',
                readback_offsets='131,97', copy_bytes='262080',
                outside_destination_ranges='full-byte-pass', readback_guards='full-byte-pass',
                digest='length-prefixed-D-E-host')
            assert len(fields) == (54 if '--late-compute' in flags else 50)
        return fields
    count = len(ids)
    assert 2 <= count <= 8 and len(set(ids)) == count
    quotient, remainder = divmod(65537, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    padded = [((size * 4 + 4095) // 4096) * 4096 for size in sizes]
    assert sum(sizes) == 65537 and offsets[-1] + sizes[-1] == 65537
    assert all(size > 0 for size in sizes) and sum(padded) <= 286720
    ranges = ','.join(f'{offset}:{size}:{physical}'
                      for offset, size, physical in zip(offsets, sizes, padded))
    if kind == 'live-sharded':
        assert flags == []
        # Full source-shard-order snapshots include untouched f32(-1) padding.
        full_digests = []
        for round_index in (0, 1):
            chunks = []
            for offset, size, physical in zip(offsets, sizes, padded):
                logical = b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                                   for global_index in range(offset, offset + size))
                chunks.append(logical + struct.pack('<f', -1) * ((physical - len(logical)) // 4))
            full = b''.join(chunks)
            assert len(full) == sum(padded)
            full_digests.append(sha(full))
        fields = dict(
            schema='fe2o3.live-sharded-vecadd-smoke.v1',
            authority='qualification-sharded-vecadd-rounds-v1', devices=str(count),
            unique_ids=','.join(ids), rounds='2', logical_elements_per_round='65537',
            logical_bytes_per_round='262148', shard_ranges=ranges,
            padded_bytes_per_round=str(sum(padded)), launches=str(2 * count),
            peer_copies=str(2 * count), dependent_readbacks=str(2 * count),
            completion_receipts=str(6 * count), batch_admission='one-owner-command',
            compute_api='producer-aware', compute_dependency='exact-event',
            compute_admission='may-publish-before-progress', compute_progress='dependent-readback-streams',
            journal='enabled', host_output_installations='0', input_refresh='full-padded-per-batch',
            incoming_sentinel='full-byte-pass', output='full-byte-pass', padding='full-byte-pass',
            coverage='exact-contiguous-disjoint', round0_sha256=global_digests()[0],
            round1_sha256=global_digests()[1], round0_padded_sha256=full_digests[0],
            round1_padded_sha256=full_digests[1], native_transport='authenticated-pending-peer',
            native_counter=f'0,{count},{2 * count}', stable_handles='logical-only', contexts='1',
            owners='1', allocation_reuse='true', module_reuse='true', kernel_reuse='true',
            stream_reuse='true', public_events='released-after-admission',
            batch_results='released-before-refresh', intermediate_cutoffs='0',
            snapshot='settled-host-visible-owner-command', snapshot_byte_bound='286720',
            reply_credits_after_batches='0', deadline_resumption='same-command-future',
            final_drain='completed-only', cleanup='owned-shutdown-explicit',
            source_preservation='unobserved', physical_overlap='unmeasured',
            performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 51
        return fields
    assert kind == 'compute-sharded' and flags in (
        ['--queued-compute', '--round', '0'], ['--queued-compute', '--round', '1'])
    round_index = int(flags[2])
    fields = dict(
        schema='fe2o3.sharded-vecadd-queued-capture-smoke.v1',
        authority='qualification-sharded-vecadd-v1', devices=str(count),
        unique_ids=','.join(ids), round=str(round_index), rounds='1',
        logical_elements='65537', logical_bytes='262148', shard_ranges=ranges,
        padded_bytes=str(sum(padded)), launches=str(count), compute_receipts=str(count),
        transfer_receipts=str(2 * count), completion_receipts=str(3 * count),
        compute_admission='may-publish-before-cutoff', compute_join='owned-drain',
        compute_api='producer-aware', compute_dependency='exact-event',
        compute_progress='dependent-readback-streams', retained_submissions=str(3 * count),
        peer_copies=str(count), dependent_readbacks=str(count), capture_ranges=str(count),
        captured_bytes=str(sum(padded)), abi_bytes='48', kernel='vecadd', journal='enabled',
        host_output_installations='0', c_initial='-1', incoming_sentinel='full-byte-pass',
        output='full-byte-pass', padding='full-byte-pass', coverage='exact-contiguous-disjoint',
        global_sha256=global_digests()[round_index],
        admission='all-transfers-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_preservation='unobserved', allocation_reuse='false', contexts='one-per-process',
        drain='pending-group', capture='coherent-host-group', physical_overlap='unmeasured',
        cleanup='owned-shutdown-explicit', performance_acceptance='false', formal_refinement='false')
    assert len(fields) == 49
    return fields


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in fields
        fields[key] = value
    return fields


@lru_cache(maxsize=1)
def directed_digests():
    mask = (1 << 64) - 1
    digests = [hashlib.sha256(), hashlib.sha256()]
    for start in range(0, 8388581, 8192):
        block = bytearray()
        for index in range(start, min(start + 8192, 8388581)):
            value = (index + 0x9e3779b97f4a7c15) & mask
            value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
            value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
            block.append((value ^ (value >> 31)) & 255)
        digests[0].update(block)
        digests[1].update(bytes(byte ^ 73 for byte in block))
    return tuple(digest.hexdigest() for digest in digests)


@lru_cache(maxsize=2)
def subrange_digests(readback):
    # Formula-based full logical byte expectations, independent of runtime windows.
    count = 8388581
    lengths = (count + 257, count + 769, count + 1153)
    offsets = (17, 131, 509)
    mask = (1 << 64) - 1
    pattern = bytearray()
    for index in range(max(lengths)):
        value = (index + 0x9e3779b97f4a7c15) & mask
        value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
        value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
        pattern.append((value ^ (value >> 31)) & 255)
    result = []
    for round_index in (0, 1):
        shift = 73 * round_index
        digest = hashlib.sha256(b'fe2o3.native-peer-subranges.v1\0')
        for device, length in enumerate(lengths):
            contents = bytearray(byte ^ shift ^ (0, 0xa5, 0x5a)[device]
                                 for byte in pattern[:length])
            if device:
                contents[offsets[device]:offsets[device] + count] = bytes(
                    byte ^ shift for byte in pattern[offsets[0]:offsets[0] + count])
            assert len(contents) == length
            digest.update(struct.pack('<Q', length))
            digest.update(contents)
        digest.update(bytes([int(readback)]))
        if readback:
            contents = bytearray(byte ^ shift ^ 0xa5 for byte in pattern[:lengths[2]])
            contents[97:97 + count] = bytes(byte ^ shift for byte in pattern[17:17 + count])
            assert len(contents) == lengths[2]
            digest.update(struct.pack('<Q', len(contents)))
            digest.update(contents)
        result.append(digest.hexdigest())
    assert result[0] != result[1]
    return tuple(result)


def expected_gather_compute(flags, ids):
    assert 3 <= len(ids) <= 8 and len(set(ids)) == len(ids)
    count = len(ids) - 1
    overlap = flags == ['--gather-compute-overlap']
    extent = 65536 * 4
    windows, end = [], 64
    for index in range(count):
        source = 4 * (1 + 7 * index)
        destination = end if index == 0 else end + (-48 if overlap else 28)
        size = (((extent - 512) // count) & ~3) - 4 * index
        assert source + size <= extent and destination + size < extent
        windows.append((source, destination, size))
        end = destination + size
    source = b''.join(struct.pack('<f', (index & 63) * 0.25 + (index & 31))
                      for index in range(65536))
    gathered = bytearray(struct.pack('<f', 0.25) * 65536)
    for source_offset, destination, size in windows:
        gathered[destination:destination + size] = source[source_offset:source_offset + size]
    computed = b''.join(struct.pack('<f', struct.unpack_from('<f', gathered, 4 * index)[0]
                                   + (index & 31) * 0.5) for index in range(65536))
    returned = bytearray([0xa5]) * (extent + 769)
    returned[131:131 + extent - 64] = computed[20:extent - 44]
    host = bytearray([0x5a]) * (extent + 1153)
    host[97:97 + len(returned)] = returned
    assert len(gathered) == len(computed) == extent
    assert len(returned) == extent + 769 and len(host) == extent + 1153
    framed = b'fe2o3.gather-compute.v1\0' + b''.join(
        struct.pack('<Q', len(data)) + data
        for data in [*[source] * count, gathered, computed, returned, host])
    return dict(schema='fe2o3.gather-compute.v1', authority='qualification-r57-n3-v2',
        devices=str(len(ids)), sources=str(count), unique_ids=','.join(ids),
        overlap=str(overlap).lower(), windows=','.join(':'.join(map(str, window)) for window in windows),
        elements='65536', bytes=str(extent), setup_launches=str(len(ids)),
        pipeline_launches=str(count + 1), peer_copies=str(count + 1), dependent_readbacks='1',
        completion_receipts=str(2 * count + 3), pipeline='compute-gather-compute-peer-readback',
        admission='all-before-explicit-progress', progress='final-readback-stream-only',
        public_events='released-after-dependent-admission', consumer_dependencies='latest-gather-only',
        consumer_bindings='full-frame-read-stable-read-full-write', native_transport='NATIVE-XGMI',
        native_counter=f'0,{count + 1}', output='full-byte-pass', source_preservation='full-byte-pass',
        gathered_frame='full-byte-pass', return_guards='full-byte-pass', host_guards='full-byte-pass',
        output_sha256=sha(framed), digest='length-prefixed-sources-C-D-E-host',
        host_output_installations='0', pipeline_host_joins='0', journal='enabled', contexts='1',
        owners='1', batches='1', results_release='reverse-dependencies', final_drain='completed-only',
        cleanup='owned-shutdown-explicit', physical_overlap='unmeasured',
        performance_acceptance='false', formal_refinement='false')


def expected_gather(flags, ids):
    assert 3 <= len(ids) <= 8 and len(set(ids)) == len(ids)
    overlap = flags == ['--gather-overlap']
    sizes = [65537 // len(ids) + int(i < 65537 % len(ids)) for i in range(len(ids))]
    starts = [sum(sizes[:i]) for i in range(len(ids))]
    windows, end = [], 17
    for index, size in enumerate(sizes[:-1]):
        dest = end if index == 0 else end + (-31 if overlap else 23)
        size = 4 * size - 20 - 8 * index
        windows.append((4 + 4 * index, dest, size))
        end = dest + size
    extent = end + 97
    digests, frames = [], []
    for round_index in (0, 1):
        sources = []
        for start, size in zip(starts[:-1], sizes[:-1]):
            source = b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                              for global_index in range(start, start + size))
            padded = ((4 * size + 4095) // 4096) * 4096
            source += struct.pack('<f', -1) * ((padded - len(source)) // 4)
            sources.append(source)
        destination = bytearray([0xa5]) * extent
        for source, (source_offset, dest_offset, size) in zip(sources, windows):
            destination[dest_offset:dest_offset + size] = source[source_offset:source_offset + size]
        host = bytearray([0x5a]) * (extent + 42)
        host[13:13 + extent] = destination
        assert len(destination) == extent and len(host) == extent + 42
        framed = b'fe2o3.queued-gather.v1\0' + b''.join(
            struct.pack('<Q', len(contents)) + contents for contents in [*sources, destination, host])
        digests.append(sha(destination))
        frames.append(sha(framed))
    assert digests[0] != digests[1] and frames[0] != frames[1]
    count = len(ids) - 1
    return dict(schema='fe2o3.queued-gather.v1', authority='qualification-sharded-vecadd-rounds-v1',
        devices=str(len(ids)), sources=str(count), unique_ids=','.join(ids), rounds='2',
        overlap=str(overlap).lower(), windows=','.join(':'.join(map(str, w)) for w in windows),
        destination_bytes=str(extent), host_bytes=str(extent + 42), launches=str(2 * count),
        peer_copies=str(2 * count), dependent_readbacks='2', completion_receipts=str(4 * count + 2),
        admission='all-before-explicit-progress', progress='final-readback-stream-only',
        public_events='released-after-admission', native_transport='NATIVE-XGMI',
        native_counter=f'0,{count},{2 * count}', output='full-byte-pass',
        source_preservation='full-byte-pass', untouched_destination='full-byte-pass', host_guards='full-byte-pass',
        round0_sha256=digests[0], round1_sha256=digests[1], round0_framed_sha256=frames[0],
        round1_framed_sha256=frames[1], pipeline_host_joins='0', host_output_installations='0',
        contexts='1', owners='1', allocation_reuse='true', input_refresh='full-padded-per-batch',
        deadline_resumption='same-command-future', intermediate_cutoffs='0', final_drain='completed-only',
        cleanup='owned-shutdown-explicit', physical_overlap='unmeasured', performance_acceptance='false',
        formal_refinement='false')


def main():
    global BASELINE
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) in (1, 2)
    attempt = sys.argv[1] if len(sys.argv) == 2 else 'attempt-01'
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert not (ROOT / 'campaign.json').exists()
    BASELINE = initial_baseline()
    checks = ROOT.parent / attempt / 'checks'
    binaries = {}
    for kind, receipt, basename in [
        ('directed', 'directed-witness.sha256', 'gfx942-runtime-directed-peer-copy-smoke'),
        ('deferred', 'deferred-witness.sha256', 'gfx942-runtime-deferred-peer-chain-smoke'),
        ('live-sharded', 'live-sharded-witness.sha256', 'gfx942-runtime-live-sharded-vecadd-smoke')]:
        digest, path = (checks / receipt).read_text().strip().split(maxsplit=1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest)
        local = REPO / path
        assert local == REPO / 'target/debug/examples' / basename
        assert sha(local.read_bytes()) == digest
        binaries[kind] = dict(local=str(local), sha256=digest)
    completed, errors = [], []
    directory = None
    cleaned = False
    try:
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-gather-compute-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-gather-compute-20261002-[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
            capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            hashed = remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
            assert hashed.split() == [binary['sha256'], binary['remote']]
        for name, kind, flags, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8',
                binaries[kind]['remote'], *flags, *ids], '180s')
            fields = pass_fields(output)
            required = expected(kind, flags, ids)
            assert fields == required, (name, fields, required)
            assert not (ROOT / name / 'stderr').read_bytes()
            admit(name + '-post')
            completed.append(dict(name=name, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [directory + '/' + kind + '-witness' for kind in binaries]
                probe = ('import json,os,sys; from pathlib import Path; '
                    'paths=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    if 'remote' in binary:
                        try:
                            hashed = remote('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
                            assert hashed.split() == [binary['sha256'], binary['remote']]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        try:
            admit('final')
        except Exception as error:
            errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            selected_build_attempt=attempt, owned_directory=directory,
            owned_cleanup_complete=cleaned, exclusive_reservation=False,
            performance_acceptance=False, formal_refinement=False, limitations=LIMITATIONS)
        with (ROOT / 'campaign.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
