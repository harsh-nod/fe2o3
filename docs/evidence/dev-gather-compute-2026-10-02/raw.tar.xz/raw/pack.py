"""Archive completed raw receipts deterministically, without redistributing tools."""

import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile


RAW = Path(__file__).resolve().parent
DEST = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-gather-compute-2026-10-02')
assert json.loads((RAW / 'audit-01.json').read_text())['accepted'] is True
assert json.loads((RAW / 'hardware-01/campaign.json').read_text())['owned_cleanup_complete'] is True
assert json.loads((RAW / 'hardware-campaign-01/receipt.json').read_text())['source_unchanged'] is True
assert (RAW / 'candidate.patch').is_file()
assert (DEST / 'README.md').is_file()
rows = {}
with (DEST / 'raw.tar.xz').open('xb') as archive:
    with lzma.LZMAFile(archive, mode='w', preset=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as output:
            for path in sorted(RAW.rglob('*')):
                assert not path.is_symlink(), path
                if path.is_dir():
                    continue
                assert path.is_file(), path
                data = path.read_bytes()
                name = path.relative_to(RAW).as_posix()
                rows[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
                info = tarfile.TarInfo('raw/' + name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                output.addfile(info, io.BytesIO(data))
with (DEST / 'raw-manifest.json').open('x') as output:
    json.dump(rows, output, indent=2, sort_keys=True)
    output.write('\n')
for name, row in rows.items():
    data = (RAW / name).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
assert sorted(rows) == sorted(p.relative_to(RAW).as_posix() for p in RAW.rglob('*') if p.is_file())
with tarfile.open(DEST / 'raw.tar.xz', 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(rows)
    assert {member.name for member in members} == {'raw/' + name for name in rows}
    for member in members:
        assert member.isfile()
        row = rows[member.name.removeprefix('raw/')]
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
with (DEST / 'SHA256SUMS').open('x') as output:
    for name in ['README.md', 'raw-manifest.json', 'raw.tar.xz']:
        sha = hashlib.sha256((DEST / name).read_bytes()).hexdigest()
        output.write(sha + '  ' + name + '\n')
print(json.dumps({'files': len(rows), 'uncompressed_bytes': sum(row['bytes'] for row in rows.values()),
                  'archive_bytes': (DEST / 'raw.tar.xz').stat().st_size}, sort_keys=True))
