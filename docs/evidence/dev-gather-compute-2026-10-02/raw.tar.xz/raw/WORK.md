# Gathered Frame Compute Consumers

Baseline: 0bbef399bdb8f219627d656c7ca1a66b15cfeba2.
Previous goal turn made progress: ordered gather and full-frame readback were
implemented, qualified, signed and pushed to both remotes.

Current priority: ordinary producer-aware compute consumes a success-ordered
gathered frame through the exact latest peer event and existing queued reader
lease. Every original alias remains Read-only and checked; preserved-frame
coverage does not change the meaning of a peer's actual copied window. Retain
original whole-owner custody and success-only per-node reconciliation.

Context and backend agents own isolated implementation/tests. Root owns contracts,
native witness, execution, hardware cleanup and Git. Verification agent owns
external source/audit controllers after root provides the new packet layout.

No general kernel authority or qualification policy changes are permitted.
Native witness uses unchanged R57 V2 first setup gates, pending second-gate source
outputs, gather into original sink C, sink C+B->D, return peer and full E readback.
Formal adapter refinement and matched HIP/HSA performance are not inferred from
CPU or native functional tests. The full persistent goal remains incomplete.

## Integration

The first focused runtime diagnostic passed 15 tests and failed two bounded
late-owner progress tests. Review found a real cycle: the selected tail followed
its source compute while an older gather peer held the child's native custody.
The source compute could not finish, and the cursor never reached that older
peer. The fix advances only an authenticated, already-started destination
ancestor through the existing paired progress/failure envelope before retrying
the tail. No fixture completion flags or progress bounds were relaxed.

Source metadata proposal-01 was reversed using its exact owned patch; fresh
proposal-02 binds the corrected source. Selected CPU build/runtime/checks are
attempt-02; source controls are attempt-02-after. The fresh focused diagnostic
passed all 17 tests. Full runtime passed 2,198 with 32 historical ignores, and
examples passed 28; source controls passed 32. A premature checks invocation
while the build still held the controller lock exited without starting work or
creating an attempt directory; checks ran after the build completed.

Next application-facing priority from review: generate ordinary Context argument
projection beside existing owned arguments, using RuntimeArgumentsV1 and checked
allocation-relative regions, without converting private generated storage or
creating new kernel authority. A concrete production semantic-machine provider
remains absent; finite R57 native qualification cannot substitute for it.

The follow-up review found no need for a new trait. Generate a separate owned
`ContextArguments` with existing primitive scalar fields and host-side typed
Read/Write/ReadWrite slice descriptors holding private allocation ID, offset and
element count. Check multiplication, end, nonzero length and element alignment;
encode existing ABI offsets, LE scalars/counts and zero pointer placeholders.
Use renamed-host `__generated` reexports. Existing Context validation already
rejects foreign handles as UnknownAllocation, wrong device as WrongDevice, and
invalid bounds as InvalidRange before submission. Start with ordinary slices
only; do not claim mapped/global-pointer/by-value support or new authority.

## Native Result

Hardware-01 completed all 28 cases successfully: eight new gathered-consumer
cases and 20 current-source controls. Fresh per-case shared-host availability
and attachment checks passed. Final executable hashes matched; no owned process
remained. Exactly the three uploaded binaries and owned directory
`/tmp/fe2o3-gather-compute-20261002-leQolv` were removed, and absence plus final
availability were confirmed. The outer capture passed source stability.
