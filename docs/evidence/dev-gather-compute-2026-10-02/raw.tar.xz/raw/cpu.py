"""Bounded, source-bound CPU build, complete test shards, and witness checks."""

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import threading
import time


ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
BASE = '0bbef399bdb8f219627d656c7ca1a66b15cfeba2'
CAPTURE_SHA = '84b5f1e88a891c42562613d3fdf178ea41ef1228324f0d2d2f09c0b621f1eac1'
PACKAGES = ['-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime']
PREFIX = 'queue::live::construction_primary::'
EXAMPLES = {
    'directed': 'gfx942-runtime-directed-peer-copy-smoke',
    'deferred': 'gfx942-runtime-deferred-peer-chain-smoke',
    'live-sharded': 'gfx942-runtime-live-sharded-vecadd-smoke',
}
ABORT = threading.Event()


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pairs(rows):
    result = {}
    for key, value in rows:
        need(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + '\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def load_capture():
    path = RAW / 'capture.py'
    need(path.is_file() and not path.is_symlink() and sha(path.read_bytes()) == CAPTURE_SHA,
         'pinned capture controller')
    spec = importlib.util.spec_from_file_location('qualification_capture', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    need(module.ROOT == ROOT and module.OUT == RAW, 'capture controller paths')
    return module


def executable(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path and path.is_file()
         and not path.is_symlink() and path.is_relative_to(ROOT / 'target'),
         'canonical built executable')
    data = path.read_bytes()
    return {'path': str(path), 'sha256': sha(data), 'byte_length': len(data)}


def session_members(session):
    result = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            stat = (entry / 'stat').read_text()
            fields = stat[stat.rfind(')') + 2:].split()
            if int(fields[3]) == session:
                result.append((int(entry.name), int(fields[2])))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return result


def signal_owned_session(session, number):
    # Only groups still containing a member of the session created by this controller.
    signaled = set()
    for pid, group in session_members(session):
        try:
            if group not in signaled and os.getsid(pid) == session and os.getpgid(pid) == group:
                os.killpg(group, number)
                signaled.add(group)
        except ProcessLookupError:
            continue


def owned(command, seconds, directory, environment):
    directory.mkdir()
    metadata = {'command': command, 'environment': environment, 'cwd': str(ROOT),
                'started': utc(), 'timeout_seconds': seconds,
                'controller_sha256': sha(Path(__file__).read_bytes())}
    save(directory / 'command.json', metadata)
    process = None
    error = None
    interrupted = False
    timed_out = False
    leftovers = False
    try:
        need(not ABORT.is_set(), 'controller interrupted before spawn')
        with (directory / 'stdout').open('xb') as stdout, (directory / 'stderr').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            metadata['session_id'] = process.pid
            deadline = time.monotonic() + seconds
            while process.poll() is None:
                interrupted = ABORT.is_set()
                timed_out = time.monotonic() >= deadline
                if interrupted or timed_out:
                    signal_owned_session(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        signal_owned_session(process.pid, signal.SIGKILL)
                        process.wait(timeout=10)
                    break
                time.sleep(0.1)
    except BaseException as failure:
        error = type(failure).__name__ + ': ' + str(failure)
    finally:
        if process is not None:
            if process.poll() is None:
                signal_owned_session(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
            for _ in range(20):
                if not session_members(process.pid):
                    break
                time.sleep(0.05)
            leftovers = bool(session_members(process.pid))
            if leftovers:
                signal_owned_session(process.pid, signal.SIGKILL)
                for _ in range(20):
                    if not session_members(process.pid):
                        break
                    time.sleep(0.05)
        absent = process is not None and not session_members(process.pid)
        status = None if process is None else process.returncode
        metadata.update(finished=utc(), exit=status, timed_out=timed_out,
                        interrupted=interrupted, error=error, retained_session_members=leftovers,
                        group_absent=absent, session_absent=absent,
                        accepted=status == 0 and not (timed_out or interrupted or error or leftovers)
                        and absent)
        for name in ['stdout', 'stderr']:
            path = directory / name
            if not path.exists():
                path.touch(exist_ok=False)
            metadata[name + '_sha256'] = sha(path.read_bytes())
        save(directory / 'result.json', metadata)
    return metadata


def capture_step(capture, attempt, mode, step, seconds, command, output, sources):
    label = '-'.join([attempt, mode, step])
    need(not (RAW / label).exists(), 'fresh capture: ' + label)
    command = [str(item) for item in command]
    launcher = [sys.executable, '-I', '-B', str(RAW / 'capture.py'), label, str(seconds) + 's', *command]
    owned_result = owned(launcher, seconds + 45, output / (step + '-controller'), capture.ENV)
    need(owned_result['accepted'], 'owned capture failed: ' + label)
    path = RAW / label
    receipt = read(path / 'receipt.json')
    need(receipt['exit'] == 0 and receipt['source_unchanged'] is True
         and receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', str(seconds) + 's', *command]
         and receipt['environment'] == capture.ENV and receipt['cwd'] == str(ROOT)
         and receipt['base'] == BASE and receipt['controller_sha256'] == CAPTURE_SHA,
         'successful exact capture: ' + label)
    need(read(path / 'source-before.json') == sources and read(path / 'source-after.json') == sources,
         'frozen capture sources: ' + label)
    for name in ['stdout', 'stderr']:
        need(receipt[name + '_sha256'] == sha((path / name).read_bytes()), 'capture output hash')
    print(json.dumps({'step': label, 'accepted': True}), flush=True)
    return {'capture': label, 'controller': str((output / (step + '-controller')).relative_to(RAW)),
            'receipt_sha256': sha((path / 'receipt.json').read_bytes())}


def cargo(command, *args):
    return ['cargo', '+nightly-2026-04-03', command, '--locked', '--offline', '--jobs', '4', *args]


def roster(text):
    names = re.findall(r'^(.+): test$', text, re.M)
    footers = re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', text, re.M)
    need(len(names) == len(set(names)) and len(footers) == 1
         and int(footers[0][0]) == len(names) and footers[0][1] == '0', 'exact libtest roster')
    return sorted(names)


def test_results(text, selected, ignored, full_count):
    rows = re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$', text, re.M)
    need(Counter(name for name, _ in rows) == Counter(selected), 'exact selected test multiset')
    actual_ignored = sorted(name for name, status in rows if status == 'ignored')
    need(actual_ignored == sorted(ignored) and all(status in {'ok', 'ignored'} for _, status in rows),
         'only exact prelisted ignores, no failures')
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                           r'(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$', text, re.M)
    need(len(summaries) == 1, 'one libtest result')
    passed = len(selected) - len(ignored)
    need(tuple(map(int, summaries[0][:5])) == (passed, 0, len(ignored), 0, full_count - len(selected)),
         'exact pass/ignore/filter summary')
    return {'passed': passed, 'ignored': len(ignored), 'filtered': full_count - len(selected),
            'seconds': float(summaries[0][5])}


def build(capture, attempt, output, sources):
    steps = []
    steps.append(capture_step(capture, attempt, 'build', 'cargo', 2400,
                             cargo('test', *PACKAGES, '--all-features', '--lib', '--no-run',
                                   '--message-format=json'), output, sources))
    captured = RAW / steps[0]['capture']
    receipt = read(captured / 'receipt.json')
    messages = [json.loads(line) for line in (captured / 'stdout').read_text().splitlines()]
    need([row for row in messages if row.get('reason') == 'build-finished']
         == [{'reason': 'build-finished', 'success': True}], 'Cargo build completed')
    executables = {}
    for target in ['fe2o3_kfd', 'fe2o3_runtime']:
        matches = {row['executable'] for row in messages
                   if row.get('reason') == 'compiler-artifact' and row.get('executable')
                   and row['target']['name'] == target and row['profile']['test'] is True}
        need(len(matches) == 1, 'one freshly built library ELF: ' + target)
        identity = executable(matches.pop())
        retained = receipt['executables'][identity['path']]
        need(retained == {key: value for key, value in identity.items() if key != 'path'}
             | {'target': target, 'test': True}, 'captured ELF identity')
        for ignored in [False, True]:
            suffix = 'ignored' if ignored else 'list'
            command = [identity['path'], '--list', '--test-threads=1']
            if ignored:
                command.append('--ignored')
            step = capture_step(capture, attempt, 'build', target + '-' + suffix, 60,
                                command, output, sources)
            steps.append(step)
            identity[suffix] = roster((RAW / step['capture'] / 'stdout').read_text())
        need(set(identity['ignored']).issubset(identity['list']), 'ignore subset')
        if target == 'fe2o3_kfd':
            need(not identity['ignored'], 'complete KFD suite has no ignored tests')
        executables[target] = identity
    save(output / 'build.json', {'schema': 'fe2o3.native-peer-subranges.cpu-build.v1',
                                'executables': executables, 'steps': steps})
    return {'steps': steps, 'executables': executables}


def direct_test(capture, output, label, identity, selected, ignored, sources, seconds):
    need({key: identity[key] for key in ['path', 'sha256', 'byte_length']}
         == executable(identity['path']), 'test ELF before ' + label)
    folder = output / label
    folder.mkdir()
    before = capture.snapshot()
    save(folder / 'source-before.json', before)
    need(before == sources, 'test frozen source before ' + label)
    argv = [identity['path'], '--test-threads=1', '--exact', *selected]
    if label == 'runtime-full':
        argv = [identity['path'], '--test-threads=1']
    save(folder / 'selection.json', {'selected': selected, 'ignored': ignored,
                                    'executable': {key: identity[key] for key in ['path', 'sha256', 'byte_length']},
                                    'full_roster': identity['list']})
    discovered = owned([*argv, '--list'], 60, folder / 'list', capture.ENV)
    error = None
    counts = None
    run = None
    try:
        need(discovered['accepted'] and roster((folder / 'list/stdout').read_text()) == selected,
             'selected exact discovery ' + label)
        run = owned(argv, seconds, folder / 'run', capture.ENV)
        need(run['accepted'], 'owned test execution ' + label)
        counts = test_results((folder / 'run/stdout').read_text(), selected, ignored, len(identity['list']))
    except BaseException as failure:
        error = type(failure).__name__ + ': ' + str(failure)
    after = capture.snapshot()
    save(folder / 'source-after.json', after)
    unchanged = before == after == sources
    elf_unchanged = executable(identity['path']) == {key: identity[key] for key in ['path', 'sha256', 'byte_length']}
    result = {'accepted': error is None and unchanged and elf_unchanged,
              'error': error, 'source_unchanged': unchanged, 'executable_unchanged': elf_unchanged,
              'counts': counts, 'run': run, 'selection_sha256': sha((folder / 'selection.json').read_bytes())}
    save(folder / 'result.json', result)
    print(json.dumps({'test': label, 'accepted': result['accepted'], 'counts': counts}), flush=True)
    return result


def tests(capture, attempt, output, sources, selected_build):
    build_dir = RAW / selected_build / 'build'
    previous = read(build_dir / 'result.json')
    need(previous['accepted'] is True and read(build_dir / 'source-before.json') == sources
         and read(build_dir / 'source-after.json') == sources, 'successful exact-source selected build')
    built = read(build_dir / 'build.json')['executables']
    kfd, runtime = built['fe2o3_kfd'], built['fe2o3_runtime']
    heavy = [name for name in kfd['list'] if name.startswith(PREFIX)]
    groups = {f'kfd-heavy-{index}': heavy[index::4] for index in range(4)}
    groups['kfd-rest'] = [name for name in kfd['list'] if not name.startswith(PREFIX)]
    need(all(groups.values()) and Counter(name for names in groups.values() for name in names)
         == Counter(kfd['list']), 'five disjoint complete KFD partitions')
    save(output / 'partitions.json', {'prefix': PREFIX, 'groups': groups,
                                     'runtime': runtime['list'], 'runtime_ignored': runtime['ignored'],
                                     'build_attempt': selected_build})
    completed = {}
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {name: executor.submit(direct_test, capture, output, name, kfd, names, [], sources, 1800)
                   for name, names in groups.items() if name != 'kfd-rest'}
        try:
            completed['kfd-rest'] = direct_test(capture, output, 'kfd-rest', kfd,
                                                groups['kfd-rest'], [], sources, 1200)
            completed['runtime-full'] = direct_test(capture, output, 'runtime-full', runtime,
                                                    runtime['list'], runtime['ignored'], sources, 1200)
        finally:
            for name, future in futures.items():
                completed[name] = future.result()
    need(all(row['accepted'] for row in completed.values()), 'all complete CPU suites accepted')
    need(sum(completed[name]['counts']['passed'] for name in groups) == len(kfd['list']),
         'exact full KFD passed total')
    return {'build_attempt': selected_build, 'results': completed,
            'kfd_passed': len(kfd['list']), 'runtime_passed': len(runtime['list']) - len(runtime['ignored']),
            'runtime_ignored': len(runtime['ignored'])}


def runtime_tests(capture, attempt, output, sources, selected_build):
    build_dir = RAW / selected_build / 'build'
    need(read(build_dir / 'result.json')['accepted'] is True
         and read(build_dir / 'source-before.json') == sources
         and read(build_dir / 'source-after.json') == sources, 'accepted current-source build')
    built = read(build_dir / 'build.json')['executables']
    runtime = built['fe2o3_runtime']
    result = direct_test(capture, output, 'runtime-full', runtime, runtime['list'],
                        runtime['ignored'], sources, 1200)
    need(result['accepted'], 'complete current runtime suite')
    reused = capture_step(capture, attempt, 'runtime', 'kfd-proof-reuse', 120,
                          [sys.executable, '-I', '-B', str(RAW / 'reuse-check.py')], output, sources)
    assessment = read(RAW / reused['capture'] / 'stdout')
    need(assessment['historical_reuse_valid'] is True
         and assessment['kfd_executable'] == {key: built['fe2o3_kfd'][key]
             for key in ['path', 'sha256', 'byte_length']}, 'current build matches authenticated old KFD ELF')
    return {'build_attempt': selected_build, 'runtime': result,
            'runtime_passed': len(runtime['list']) - len(runtime['ignored']),
            'runtime_ignored': len(runtime['ignored']), 'reuse': reused,
            'kfd_historical_passes_reused': assessment['kfd_passed'], 'kfd_tests_executed': 0}


def changed_rust():
    names = set()
    for command in [
        ['git', 'diff', 'HEAD', '--name-only', '-z', '--', 'crates/fe2o3-kfd/**/*.rs', 'crates/fe2o3-runtime/**/*.rs'],
        ['git', 'ls-files', '--others', '--exclude-standard', '-z', '--', 'crates/fe2o3-kfd/**/*.rs', 'crates/fe2o3-runtime/**/*.rs'],
    ]:
        names.update(os.fsdecode(name) for name in subprocess.check_output(command, cwd=ROOT).split(b'\0') if name)
    need(names, 'changed Rust formatting roster')
    return sorted(names)


def checks(capture, attempt, output, sources):
    steps = []
    def step(name, seconds, command):
        row = capture_step(capture, attempt, 'checks', name, seconds, command, output, sources)
        steps.append(row)
        return RAW / row['capture']
    examples = [item for name in EXAMPLES.values() for item in ['--example', name]]
    step('clippy', 1800, cargo('clippy', *PACKAGES, '--all-features', '--lib', '--tests', *examples,
                              '--no-deps', '--', '-D', 'warnings'))
    step('directed-clippy', 1200, cargo('clippy', '-p', 'fe2o3-runtime', '--no-default-features',
                                       '--example', EXAMPLES['directed'], '--no-deps', '--', '-D', 'warnings'))
    step('no-default', 600, cargo('check', *PACKAGES, '--no-default-features', '--lib',
                                 '--example', EXAMPLES['directed']))
    step('hardware-feature', 600, cargo('check', '-p', 'fe2o3-runtime', '--no-default-features',
                                       '--features', 'hardware-qualification', '--lib',
                                       '--example', EXAMPLES['deferred'], '--example', EXAMPLES['live-sharded']))
    witnesses = {}
    for name, example in EXAMPLES.items():
        features = ['--no-default-features'] if name == 'directed' else ['--all-features']
        args = ['-p', 'fe2o3-runtime', *features, '--example', example]
        listing = step(name + '-list', 1200, cargo('test', *args, '--', '--list', '--test-threads=1'))
        names = roster((listing / 'stdout').read_text())
        run = step(name + '-tests', 1200, cargo('test', *args, '--', '--test-threads=1'))
        counts = test_results((run / 'stdout').read_text(), names, [], len(names))
        build_path = step(name + '-build', 1200, cargo('build', *args, '--profile', 'test', '--message-format=json'))
        receipt = read(build_path / 'receipt.json')
        path = ROOT / 'target/debug/examples' / example
        identity = executable(path)
        expected = {key: identity[key] for key in ['sha256', 'byte_length']} | {'target': example, 'test': False}
        need(receipt['executables'].get(str(path)) == expected, 'exact witness build identity')
        with (output / (name + '-witness.sha256')).open('x') as stream:
            stream.write(identity['sha256'] + '  target/debug/examples/' + example + '\n')
        witnesses[name] = {'executable': identity, 'tests': counts, 'build_capture': build_path.name}
    step('rustc', 60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose'])
    step('cargo', 60, ['cargo', '+nightly-2026-04-03', '--version'])
    step('uname', 60, ['uname', '-a'])
    step('format', 120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                        '--config', 'skip_children=true', *changed_rust()])
    step('whitespace', 60, ['git', 'diff', 'HEAD', '--check'])
    for value in witnesses.values():
        need(executable(value['executable']['path']) == value['executable'], 'witness unchanged at close')
    return {'steps': steps, 'witnesses': witnesses}


def main():
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3 -I -B')
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('mode', choices=['build', 'tests', 'runtime', 'checks'])
    parser.add_argument('attempt')
    parser.add_argument('--build-attempt')
    args = parser.parse_args()
    need(re.fullmatch(r'attempt-[0-9]+', args.attempt) is not None, 'fresh attempt label')
    need(args.mode in ('tests', 'runtime') or args.build_attempt is None, 'build selection only for tests')
    selected = args.build_attempt or args.attempt
    need(re.fullmatch(r'attempt-[0-9]+', selected) is not None, 'selected build label')
    capture = load_capture()
    need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                  env=capture.ENV, text=True).strip() == BASE, 'exact implementation baseline')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    for number in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP]:
        signal.signal(number, lambda _number, _frame: ABORT.set())
    # Example-only checks do not relink the immutable library test executables.
    lock_name = 'cpu-tests.lock' if args.mode in ('tests', 'runtime') else 'cpu-cargo.lock'
    with (RAW / lock_name).open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        output = RAW / args.attempt / args.mode
        output.parent.mkdir(exist_ok=True)
        output.mkdir()
        sources = capture.snapshot()
        save(output / 'source-before.json', sources)
        metadata = {'schema': 'fe2o3.native-peer-subranges.cpu.v1', 'base': BASE,
                    'mode': args.mode, 'attempt': args.attempt, 'started': utc(),
                    'controller_sha256': sha(Path(__file__).read_bytes()),
                    'capture_sha256': CAPTURE_SHA, 'environment': capture.ENV, 'cwd': str(ROOT),
                    'argv': sys.argv}
        save(output / 'command.json', metadata)
        error = None
        results = None
        try:
            if args.mode == 'build':
                results = build(capture, args.attempt, output, sources)
            elif args.mode == 'tests':
                results = tests(capture, args.attempt, output, sources, selected)
            elif args.mode == 'runtime':
                results = runtime_tests(capture, args.attempt, output, sources, selected)
            else:
                results = checks(capture, args.attempt, output, sources)
        except BaseException as failure:
            error = type(failure).__name__ + ': ' + str(failure)
        after = capture.snapshot()
        save(output / 'source-after.json', after)
        metadata.update(finished=utc(), source_unchanged=sources == after,
                        accepted=error is None and sources == after and not ABORT.is_set(),
                        error=error, results=results)
        save(output / 'result.json', metadata)
        print(json.dumps({'mode': args.mode, 'attempt': args.attempt,
                          'accepted': metadata['accepted'], 'error': error}), flush=True)
        return 0 if metadata['accepted'] else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(json.dumps({'accepted': False, 'error': type(error).__name__ + ': ' + str(error)}))
        sys.exit(1)
