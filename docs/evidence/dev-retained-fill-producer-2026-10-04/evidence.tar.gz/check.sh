#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-retained-fill-20261004-SwB5HA2T
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
trap 'printf "%s\n" "$?" > "$scratch/check.status"' EXIT
bash "$scratch/freeze.sh" > "$scratch/source-before.sha256"
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib > "$scratch/host-tests.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --doc > "$scratch/host-doc-tests.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical -- --skip strict_v3_ --skip cargo_supervisor_and_static_host_consumer > "$scratch/vertical-tests.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-host --lib --tests -- -D warnings > "$scratch/host-clippy.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical -- -D warnings > "$scratch/vertical-clippy.log" 2>&1
bash "$scratch/freeze.sh" > "$scratch/source-after.sha256"
cmp "$scratch/source-before.sha256" "$scratch/source-after.sha256"
git diff --check > "$scratch/whitespace.log"
