#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-retained-fill-20261004-SwB5HA2T
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
sha256sum -c "$scratch/final-source.sha256" > "$scratch/source-final.log"
git -c gpg.ssh.allowedSignersFile="$scratch/allowed-signers" verify-commit HEAD > "$scratch/source-signature.log" 2>&1
git show --format=fuller --no-patch HEAD > "$scratch/source-commit.txt"
git diff HEAD^ HEAD --binary > "$scratch/committed-source.patch"
cmp "$scratch/source.patch" "$scratch/committed-source.patch"
sha256sum "$scratch/source.patch" > "$scratch/source-patch.sha256"
sha256sum target/debug/deps/fe2o3_host-006f51dabd6b4865 \
    target/debug/deps/worker_v3_load_envelope_vertical-46b0de5152134567 \
    target/debug/fe2o3-worker-v3-hsaco-fixture target/debug/cargo-fe2o3 \
    target/qualification-native-workers/fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715/fe2o3-llvm-link-worker \
    > "$scratch/binaries.sha256"
