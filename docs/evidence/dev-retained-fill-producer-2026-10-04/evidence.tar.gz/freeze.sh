#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
while IFS= read -r -d '' path; do
    case "$path" in
        docs/*) continue ;;
        *.rs|*.toml|*.lock|*.sh|*.c|*.cc|*.cpp|*.h|*.hpp|*.json|*.yml|*.yaml|*.py|*.cmake|*/CMakeLists.txt|rust-toolchain*) sha256sum -- "$path" ;;
    esac
done < <(git ls-files --cached --others --exclude-standard -z | sort -zu)
