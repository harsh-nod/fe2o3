#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-retained-fill-20261004-SwB5HA2T
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/final.status"' EXIT
env -u RUSTC_WRAPPER -u RUSTC_WORKSPACE_WRAPPER -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u FE2O3_CRATE_BINDING_ID_V1 -u FE2O3_SIMULATION_MODE -u FE2O3_SIMULATION_ATTEMPT CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1 LD_LIBRARY_PATH=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib cargo +nightly-2026-04-03 clippy --locked --offline --no-deps -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical -- -D warnings > "$scratch/vertical-clippy.log" 2>&1
bash "$scratch/freeze.sh" > "$scratch/source-after.sha256"
cmp "$scratch/final-source.sha256" "$scratch/source-before.sha256"
cmp "$scratch/final-source.sha256" "$scratch/source-after.sha256"
git diff --check > "$scratch/whitespace.log"
git diff --cached --check >> "$scratch/whitespace.log"
