#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-retained-fill-20261004-SwB5HA2T
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly out="$repo/docs/evidence/dev-retained-fill-producer-2026-10-04"
test "$(<"$scratch/final.status")" = 0
test "$(<"$scratch/qualified-2/status")" = 0
test ! -e "$scratch/root"
test ! -e /tmp/cargo-fe2o3-v3-static-host-consumer-2355439
test ! -e /tmp/fe2o3-worker-v3-admission-2355439-4
test ! -e /opt/fe2o3/verus-runtime-v2/functional-refinement-0.2026.08.02-b677dd5
test -z "$(find "$scratch/qualified-2/tmp" -mindepth 1 -print -quit)"
printf '%s\n' 'Private PID/mount namespace exited; test TMPDIR empty.' \
    'Owned temporary static build, interrupted fixture and root overlay removed.' \
    'No host protected runtime installation or MI300X use.' > "$scratch/cleanup.log"
mkdir "$scratch/packet"
mkdir -p "$out"
cp -r -- "$scratch/qualified-1" "$scratch/qualified-2" "$scratch/development-check" "$scratch/packet/"
for name in source.patch committed-source.patch source-patch.sha256 source-commit.txt \
    source-signature.log allowed-signers binaries.sha256 final-source.sha256 \
    source-before.sha256 source-after.sha256 source-during-proof.log source-final.log \
    host-tests.log host-doc-tests.log vertical-tests.log host-clippy.log vertical-clippy.log \
    dependency-clippy.log check.status final.status runtime-inputs.log rustfmt.log whitespace.log \
    cleanup.log stop-extra-static-build.log check.sh final-check.sh freeze.sh prepare-runtime.sh \
    isolated-runtime.sh run-native.sh source-audit.sh package.sh; do
    cp -- "$scratch/$name" "$scratch/packet/"
done
cd "$scratch/packet"
find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum -c MANIFEST.sha256 > "$scratch/manifest-audit.log"
tar -czf "$out/evidence.tar.gz" .
tar -dzf "$out/evidence.tar.gz" > "$scratch/archive-compare.log"
sha256sum "$out/evidence.tar.gz"
