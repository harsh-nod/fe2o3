#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-launch-20261004-FIAoL7CD
readonly cache=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/qualification-verus-runtime-inputs/ffef09bd240c90e72cbff31a82bc5173c796ba7ab9af239245e7ad892c25641c
cp -- "$cache/rustup-init" "$cache/libc.deb" "$cache/zlib.deb" "$scratch/"
cd "$scratch"
printf '%s\n' \
    '4acc9acc76d5079515b46346a485974457b5a79893cfb01112423c89aeb5aa10  rustup-init' \
    '3b8d5391b6b484a4c81fd000b6064885ad967ec3cb966bc57603f3fb3ebf0ed5  libc.deb' \
    '7074b6a2f6367a10d280c00a1cb02e74277709180bab4f2491a2f355ab2d6c20  zlib.deb' | sha256sum -c -
chmod +x rustup-init
dpkg-deb -x libc.deb glibc
dpkg-deb -x zlib.deb zlib
sha256sum /home/harsh/.codex-tmp/fe2o3-r61-execution/target/qualification-native-workers/fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715/fe2o3-llvm-link-worker
