#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-launch-20261004-FIAoL7CD
cd "$repo"
git diff --cached --binary > "$scratch/source.patch"
git diff --cached --name-only -z | xargs -0 sha256sum > "$scratch/sources.sha256"
git rev-parse HEAD > "$scratch/source-parent.txt"
sha256sum "$scratch/source.patch"
sha256sum target/debug/deps/fe2o3_proof_custodian-849eb3b1efa9a34b \
    target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-conditional-fill-proof-controller \
    > "$scratch/binaries.sha256"
sha256sum docs/evidence/dev-proof-controller-execution-2026-10-04/evidence.tar.gz > "$scratch/input-provenance.sha256"
