#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-launch-20261004-FIAoL7CD
readonly label=${1:?fresh capture label}
readonly mode=${2:?prepare or case}
readonly binary=${3:?exact test binary}
mkdir -m 700 "$scratch/$label-tmp" "$scratch/$label-runtime"
if [[ $mode == prepare ]]; then
    args=(/usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups --inh-caps=-all --ambient-caps=-all --bounding-set=-all)
    test_name=launch::qualification::prepare_fixed_deployment
else
    args=()
    test_name=launch::qualification::root_production_launcher
fi
status=0
timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/outer.sh" "${args[@]}" /usr/bin/env \
    TMPDIR="$scratch/$label-tmp" XDG_RUNTIME_DIR="$scratch/$label-runtime" \
    FE2O3_CUSTODIAN_DEPLOYMENT_OUTPUT="$scratch/deployment-v1" \
    FE2O3_CUSTODIAN_INPUTS="$scratch/captures/inputs-2" \
    FE2O3_CUSTODIAN_CAPTURE="$scratch/$label" FE2O3_CUSTODIAN_PRIVATE_INSTALL=1 FE2O3_CUSTODIAN_CASE="$mode" \
    "$binary" --exact "$test_name" --ignored --nocapture --test-threads=1 \
    > "$scratch/$label.log" 2>&1 || status=$?
if [[ $mode != prepare && -e "$scratch/$label/pid-namespace.txt" ]]; then
    /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
        "$scratch/raw/check-namespace.sh" "$scratch/$label" > "$scratch/$label-namespace.log" 2>&1
fi
exit "$status"
