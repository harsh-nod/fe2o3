#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-launch-20261004-FIAoL7CD
for case in good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison; do
    grep -Fx "PASS $case" "$scratch/campaign.log"
    grep -F 'test result: ok. 1 passed; 0 failed;' "$scratch/$case-final.log"
    grep -F 'outer cgroup removed:' "$scratch/$case-final.log"
    grep -F 'PASS: no live task remains in pid:' "$scratch/$case-final-namespace.log"
done
grep -F 'WorkerIdentityMismatch' "$scratch/worker-final/rejection.txt"
grep -F 'protected Verus runtime identity differs' "$scratch/runtime-final/rejection.txt"
grep -F 'Closure(FinalizedLengthMismatch)' "$scratch/payload-final/rejection.txt"
grep -F 'differs from its trusted measurement' "$scratch/controller-final/rejection.txt"
grep -F 'installed object metadata differs' "$scratch/fifo-final/rejection.txt"
grep -F 'unexpected root control transition' "$scratch/poison-final/rejection.txt"
for case in good cancel-ready cancel worker runtime payload poison; do
    grep -Fx 'controller reaped; owned scope absent; sibling survived' "$scratch/$case-final/cleanup.txt"
done
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
sha256sum -c "$scratch/sources.sha256"
sha256sum -c "$scratch/binaries.sha256"
