#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-launch-20261004-FIAoL7CD
readonly binary=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps/fe2o3_proof_custodian-849eb3b1efa9a34b
for mode in good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison; do
    printf 'START %s\n' "$mode"
    if bash "$scratch/run.sh" "$mode-final" "$mode" "$binary"; then
        printf 'PASS %s\n' "$mode"
    else
        status=$?
        tail -60 "$scratch/$mode-final.log"
        exit "$status"
    fi
done
