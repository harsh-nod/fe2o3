#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-custodian-launch-20261004-FIAoL7CD
readonly destination="$repo/docs/evidence/dev-proof-custodian-launch-2026-10-04"
cd "$repo"
git rev-parse HEAD > "$scratch/source-commit.txt"
git -c gpg.ssh.allowedSignersFile="$scratch/allowed-signers" verify-commit HEAD > "$scratch/source-signature.log" 2>&1
sha256sum -c "$scratch/sources.sha256" > "$scratch/final-source-check.log"
sha256sum -c "$scratch/binaries.sha256" > "$scratch/final-binary-check.log"
mkdir "$scratch/package" "$scratch/package/raw" "$scratch/package/captures" "$scratch/package/diagnostics"
for name in build.sh freeze.sh package.sh check-static.sh check-results.sh outer.sh run.sh campaign.sh allowed-signers \
    source.patch sources.sha256 binaries.sha256 input-provenance.sha256 source-parent.txt source-commit.txt source-signature.log \
    final-source-check.log final-binary-check.log final-results-check.log final-build-and-tests.log \
    static-elf-final-2.log prepare-final-2.log campaign.log deployment-v1; do
    cp -- "$scratch/$name" "$scratch/package/raw/$name"
done
cp -- "$scratch/raw/prepare-runtime.sh" "$scratch/raw/isolated-runtime.sh" "$scratch/raw/check-namespace.sh" "$scratch/package/raw/"
cp -- "$scratch/prepare-1.log" "$scratch/clippy.log" "$scratch/package/diagnostics/"
cp -a -- "$scratch/captures/inputs-2" "$scratch/package/captures/"
for case in good scope-drop cancel-ready cancel worker runtime payload controller replace fifo poison; do
    cp -a -- "$scratch/$case-final" "$scratch/package/captures/"
    cp -- "$scratch/$case-final.log" "$scratch/$case-final-namespace.log" "$scratch/package/raw/"
done
cd "$scratch/package"
find raw captures diagnostics -type f -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum -c MANIFEST.sha256
mkdir -p "$destination"
tar -czf "$destination/evidence.tar.gz" MANIFEST.sha256 raw captures diagnostics
sha256sum "$destination/evidence.tar.gz"
