## focused-01
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features r57 -- --test-threads=1 
## mi300x-probe
ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname 
exit=255

exit=101

## focused-02
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib r57 -- --test-threads=1 
## source-gate
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --test r57_n3_hardware_source -- --test-threads=1 
exit=0

exit=101

## focused-03
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib r57_v2_mixed -- --test-threads=1 
exit=101

## focused-04
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib r57 -- --test-threads=1 
## clippy
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo clippy -p fe2o3-runtime -p fe2o3-runtime-model --all-features --all-targets -- -D warnings 
## fmt
cargo fmt -p fe2o3-runtime -- --check 
exit=0

## diff-check
git diff --check 
exit=0

exit=0

exit=0

## source
git rev-parse HEAD 
exit=0

## source-signature
git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD 
exit=0

## runtime-final
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --no-fail-fast -- --test-threads=1 
## source-sha256
sha256sum crates/fe2o3-runtime/src/kfd_backend.rs crates/fe2o3-runtime/src/kfd_backend/tests/r57_v2_tests.rs crates/fe2o3-runtime/src/qualification_gfx942_r57_n3_v1.rs crates/fe2o3-runtime/src/qualification_gfx942_r57_n3_v1/tests/v2.rs crates/fe2o3-runtime/tests/r57_n3_hardware_source.rs crates/fe2o3-runtime/examples/gfx942-runtime-r57-n3-qualification.rs crates/fe2o3-runtime/fixtures/trusted-gfx942-r57-n3-v2/policy-v2.txt crates/fe2o3-runtime/fixtures/trusted-gfx942-r57-n3-v2/README.md crates/fe2o3-runtime/fixtures/trusted-gfx942-r57-n3-v1/policy-v1.txt 
exit=0

## historical-identity
git diff --exit-code HEAD\^ HEAD -- crates/fe2o3-runtime/fixtures/trusted-gfx942-r57-n3-v1 crates/fe2o3-runtime/fixtures/trusted-gfx942-vecadd-v1 
exit=0

## origin-checkpoint
git ls-remote origin refs/heads/codex/r65-runtime-drain-versions 
exit=128

## upstream-checkpoint
git ls-remote upstream refs/heads/codex/r65-runtime-drain-versions 
exit=128

exit=101

## minimal-check
env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo check -p fe2o3-runtime --no-default-features 
## source-digest-check
sha256sum -c /home/harsh/.codex-tmp/fe2o3-r57-v2-20260927-w9Nh7kpE/source-sha256.log 
exit=0

## rustc
rustc --version --verbose 
exit=0

exit=0

