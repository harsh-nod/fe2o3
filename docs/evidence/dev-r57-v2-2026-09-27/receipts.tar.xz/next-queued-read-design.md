# Next Runtime Slice: Queued Output Readers

Read-only agent design, not implemented or verified. Continue from public queued
full-Write Context admission. Decisive workflow: A Write(x), B queued Write(x),
C pure Read(x) explicitly depending on exact latest B, including cross-stream.

Add outer queued-producer read leases to ContextQueuedWriterJournalV1, retaining
exact allocation generation/range and writer reference without predicted epoch
or lineage. Preallocate R entries/free slots plus allocation counts and linked
writer reader heads. A writer resolves only its own attached readers, making
settlement O(destination members + attached readers), not O(R). Terminal reader
results retain captured actual epoch/lineage and survive writer-slot reuse.

Share total read capacity: inner retained reads + retained queued reads <= R.
Every existing outer capacity/acquisition wrapper must enforce this, not just
the new API. Atomic mixed stable/active/queued acquisition preflights every
request, output slot, incarnation and link before any commit. Keep typed queued
references distinct from existing epoch-bearing active-producer references.

New writers are excluded by queued readers, but already-admitted ancestors must
activate/settle with inner-only reader checks or A->B->C deadlocks. Resolve
Success only after actual B settlement; authenticated NoEffect and Unknown stay
distinct. Blocked descendants do not automatically become NoEffect. Release
requires canonical references and consumer quiescence and allocates nothing.

Include queued leases in availability, retirement and group-disposal checks,
including selected writers' queued input leases outside the destination union.
Context retained producer inputs need a typed queued alternative. Keep current
producer-first reconciliation and release-before-writer-settlement ordering.

Tests: exact tail/event/range authentication, released public events, consumer-
first observation, exact B bytes, fanout, mixed acquisition atomicity/capacity,
cancel B or C while A active, Unknown disposal, ancestor progress, stale refs,
writer/read-slot reuse, shared capacity and no speculative versions. Partial and
ReadWrite successors require separate semantics. Native full-range R/R/W has
deferred storage waits but still needs Context-integrated hardware qualification.
Inner journal proofs do not prove the new outer composition.
