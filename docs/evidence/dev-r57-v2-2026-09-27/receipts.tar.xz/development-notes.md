# R57 V2 Developer Run

Source: 05b92526e25fc09fbcd50fcd5d9839f7c3562932.
Parent: ef4ef1fa79c5c4100e07f40b5c6416bc7e5d40ce.
The primary agent owned edits and integration; agents reviewed identity
separation, authority semantics, source guards and scripted custody read-only.

This repairs the qualification mismatch exposed by the queued Context checkpoint,
not a generic runtime behavior regression. A new V2 policy/signature/gate preserves
the changed mixed-memory negative honestly. V1 policy, signature and final
authority behavior remain unchanged; historical hardware receipts remain V1.

Development failures are retained:

- focused-01.log: new test fixture attempted a host allocation against a scripted
  driver whose next step was device release. Its exact mismatch terminalized the
  resource-free test backend. The fixture retains terminal mocks on panic, so the
  test process did not abort.
- focused-02.log: a synthetic host allocation was rejected before the intended
  mixed-memory shape check. Final fixture uses actual scripted host Allocate and
  initialization Write, plus explicit host and device release steps. Production
  rejection rules were not weakened or special-cased.
- focused-03.log: diagnostic formatting incorrectly required Debug on a successful
  RuntimeSubmission. The final diagnostic formats only the optional error.
- A review caught whitespace sensitivity in the new source assertion. It now
  normalizes ASCII whitespace within the bounded negative block, retaining exact
  equality and the policy's complete error reason.

focused-04.log: all nine focused R57 unit tests passed, including four new tests.
source-gate.log: both source-shape gates passed. clippy.log: strict all-feature,
all-target runtime/model Clippy passed. Formatting and whitespace checks passed.
The final full runtime run starts after Clippy has completed; no compilation
runs concurrently with its Worker deadline tests.

runtime-final.log: 1,703 unit tests passed, three unchanged socket-inspection
PermissionDenied failures and 28 ignored. All 11 integration tests and 52
doctests passed; three hardware integration tests remain ignored. Unlike the
parent checkpoint, the R57 source gate passes with the distinct V2 contract.
All source digests match the final signed source; historical fixture diff is
empty. No failing test was waived, hidden or counted passing.
minimal-check.log: no-default-feature runtime check passed after the full suite.

No new Verus or source-bound proof campaign ran. No GPU test or matched HIP/HSA
benchmark ran. MI300X DNS failed and no remote files/jobs were created. Existing
V1 hardware evidence is not V2 hardware qualification. The active parity goal
remains open; queued-read design notes are a future implementation proposal only.
