#!/usr/bin/env bash
set -u
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
receipts=${FE2O3_RECEIPTS:-/home/harsh/.codex-tmp/fe2o3-r57-v2-20260927-w9Nh7kpE}
name=$1
shift
cd "$root" || exit 125
printf '%s\n' "## $name" >> "$receipts/commands.md"
printf '%q ' "$@" >> "$receipts/commands.md"
printf '\n' >> "$receipts/commands.md"
"$@" > "$receipts/$name.log" 2>&1
status=$?
printf 'exit=%s\n\n' "$status" >> "$receipts/commands.md"
tail -n 45 "$receipts/$name.log"
exit "$status"
