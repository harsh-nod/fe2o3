# Retained Diagnostic CPU Qualification Draft

Source-only controller for parent review. Nothing in this directory authorizes a
compiler, test ELF, solver, or GPU launch. The eleven-path candidate remains
unchanged at the exact hashes in `qualify.py`, over base
`1c589082e8c76410ab3b5b2683468ca6a1932519`.

Plan only, with no child commands or output directory:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-controller-20260930/qualify.py
```

Proposed one-shot invocation, only after the parent's heavy-slot handoff:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-controller-20260930/qualify.py --execute --output /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-attempt-1
```

## Qualification Surface

- Twenty-four sequential owned commands. Fresh, separate no-default and
  all-features targets; offline/frozen Cargo and two compiler jobs. Test profile
  opt-level 1, no debug information, no incremental compilation.
- Both modes build the library and a new test ELF. Cargo JSON binds each ELF to
  its manifest, target kind, feature-mode command, fresh artifact status, path,
  size, and SHA-256. Neither old ELF nor historical test acceptance is reused.
- Six new semantic tests run in each mode: four instrumentation timer controls,
  one retained terminal/error/panic bridge control, and one ordinary/profiled
  wait equivalence matrix. Every focused name must be listed and pass.
- Strict Clippy (`--all-targets -- -D warnings`) runs in both modes. Both ordinary
  and diagnostic examples are built with all features, but never executed.
- The full all-features KFD library roster runs with two threads and a 3600-second
  deadline. Listed ignored tests remain explicitly ignored; no `--ignored` or
  GPU workload is requested. The no-default full suite is not claimed.
- The normal producers, shared macros, currentness implementation, packet body,
  and wait policy remain bound by the existing fourteen source/parser controls.
  All four affected proof-source guards must still reject the modified source.
  No proof guard is refreshed and no solver is invoked.

## Bounds and Failure Handling

Per-command deadlines are explicit in the printed plan. The 10800-second
work-admission budget must cover the entire next command's deadline before that
command launches; independent closing observations can extend beyond this
budget. Two test threads are requested. Each child inherits an 8 GiB address-space
and 1 GiB per-file limit, with core files disabled. At least 4 GiB must remain
free before each stage and generated targets must remain below 4 GiB of logical
bytes between stages. The disk observation is not a filesystem quota or an
in-stage watcher; no watcher thread is introduced around the owned recorder.

The first rejection ends the work sequence. Closing source, tool, controller,
namespace and fresh receipt-census observations are independent. Signal handlers
restore even if receipt writing fails. Fresh census replays only this owner's
receipts; it does not probe historical PIDs. Failed attempts, build directories
and raw outputs are preserved for parent review. No cleanup, retry, source edit,
guard rebind, remote invocation or performance acceptance is automatic.

The tool profile pins the compiler/Cargo/Clippy/Python/Git executables and measures
the local Rust libraries and selected linker tools for before/after continuity.
Cargo registry contents and the full system dynamic-loader/linker dependency
closure are not hermetically attested. The source claim is a reviewed unsigned
delta over a pinned base, not a new signed-source or formal-proof qualification.

Light controller tests use synthetic artifacts and process receipts only:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-controller-20260930/test_qualify.py
```
