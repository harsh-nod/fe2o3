#!/usr/bin/env python3
"""Fresh, bounded CPU/static qualification of the reviewed diagnostic delta."""

import argparse
from contextlib import contextmanager
import hashlib
import importlib.util
from itertools import permutations
import json
import os
from pathlib import Path
import re
import resource
import runpy
import shutil
import signal
import stat
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-diagnostic-20260930-attempt-2')
BASE = '1c589082e8c76410ab3b5b2683468ca6a1932519'
TC = Path('/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu')
PYTHON = '/usr/bin/python3.12'
NATIVE = 'benchmarks/runtime_gfx942/xgmi_peer_series_native.py'
NATIVE_SHA = 'fef3e00f9310ee1895dff2dac133826c66a8432a600d5be6065b4249f3ebc3f4'
HOT = 'docs/evidence/dev-xgmi-peer-hot-mi300x-2026-09-19/native.py'
HOT_SHA = '820ad87e74a1f9915c2eb7d2d7c7c6c1c451da4cecf29fcc381229324d98473b'
BASE_HELPER = 'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/native.py'
BASE_HELPER_SHA = 'df740a80c83c94af02f7e7dfb1203dcf7c1eafbde0010e41219e4aac40b34bb7'
ROOTS = ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo', 'crates', 'examples',
         'benchmarks/runtime_gfx942', HOT, BASE_HELPER,
         'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/.gitattributes',
         'docs/runtime-xgmi-retained-host-diagnostic-v1.md')
PINS = {
    'crates/fe2o3-kfd/Cargo.toml': 'dfab5cc56c6b1103c25397df76d336781729bfb3f98ec054e49d51db3f191d2c',
    'crates/fe2o3-kfd/src/lib.rs': 'cc11da652731e1a616c13f87b3c1259e8187cdc1615a2da2b2d035475944baea',
    'crates/fe2o3-kfd/src/sdma.rs': 'a7962431d265bd0288517800385cd08be17d1141f3ec00029c4f3f619f476b50',
    'crates/fe2o3-kfd/src/sdma/retained_pair.rs': 'f5ac968c1082fb1dfdba7181029db8cfb70cec5ef20f211cfb5e56345cb0ef54',
    'crates/fe2o3-kfd/src/sdma/retained_pair/tests.rs': '45f83a2a6b239d96fb1210c7cbd78d7730ea24adfff8ac9f537c7425779af7d6',
    'crates/fe2o3-kfd/src/sdma/tests/xgmi_batch_wait.rs': '25206fcec070506a1fdb513059a5adf9e28cd1512b5afa2961b213e1d73cbeb5',
    'crates/fe2o3-kfd/src/sdma/xgmi_retirement/tests.rs': '60a68a99fc0b7adaeadd088756db72ac2f92aae4b463b505e9f1e3d70ac28e01',
    'crates/fe2o3-kfd/src/sdma/retained_pair_diagnostic.rs': 'cfc121dccee766c55bf7f626423594a4bef8d281de3a0eb9fa4fa119bd86a650',
    'crates/fe2o3-kfd/examples/kfd-xgmi-retained-host-diagnostic.rs': '788f520f4905610142afc98cd4186037d9ca883f1b2313c27223985e90def1fd',
    'benchmarks/runtime_gfx942/xgmi_retained_host_diagnostic.py': '2240bd0a94d35f65171c4814397ae91ef9552d6917ac311c4da16ea577c82a4b',
    'benchmarks/runtime_gfx942/test_xgmi_retained_host_diagnostic.py': 'f116738facee0b7eac771eed028674654922fcf72a18152c3132c00d0dc9693c',
    'docs/runtime-xgmi-retained-host-diagnostic-v1.md': 'deba3d278627d816d1b118624f1891d22d64ee422827dceaa9b3f433cbea2f02',
}
NEW_PATHS = frozenset((
    'crates/fe2o3-kfd/src/sdma/retained_pair_diagnostic.rs',
    'crates/fe2o3-kfd/examples/kfd-xgmi-retained-host-diagnostic.rs',
    'benchmarks/runtime_gfx942/xgmi_retained_host_diagnostic.py',
    'benchmarks/runtime_gfx942/test_xgmi_retained_host_diagnostic.py',
    'docs/runtime-xgmi-retained-host-diagnostic-v1.md',
))
TOOL_PINS = {
    str(TC / 'bin/cargo'): 'c9ad606cb1dbb4a65aa27c80be88ed61eb2b811b6450eeec6794f60ed78b94a3',
    str(TC / 'bin/rustc'): '08dfef109ad22d90556dbd2f964543cd93843dcd75a2e9792c173667392a1950',
    str(TC / 'bin/clippy-driver'): '34e8d8902bd690d547d847ae97168d95e0c1d05f5fcf564cb5c2032911db86ca',
    str(TC / 'bin/cargo-clippy'): '3c73b2cc41e8d69adb88d4ac57d73135f024c4ddfefbc71442ff6d9afda9722d',
    PYTHON: 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f',
    '/usr/bin/git': '2a8c18fbf43da9f692d75474c72bea9dfd796c260b0f3dfe456376abc3bbd668',
}
TIMER_PREFIX = 'sdma::retained_pair_diagnostic::tests::'
FOCUS_GROUPS = (
    (TIMER_PREFIX, False, frozenset(TIMER_PREFIX + name for name in (
        'disabled_instrumentation_leaves_every_observation_absent',
        'counters_record_requested_sleep_and_invalidate_on_overflow',
        'disabled_pause_calls_only_the_exact_ordinary_cursor_once',
        'duplicate_phase_cannot_become_valid_again_and_panics_are_not_retried'))),
    ('sdma::retained_pair::tests::retained_diagnostic_errors_terminal_success_and_panics_never_publish_observations', True, None),
    ('sdma::tests::xgmi_batch_wait::ordinary_and_profiled_batch_wait_preserve_custody_deadlines_and_panics', True, None),
)
FOCUS = frozenset().union(*(names if names is not None else {name} for name, _, names in FOCUS_GROUPS))
ABORT_PARENTS = frozenset((
    'queue_linux::tests::payload_release_failure_after_event_destroy_is_process_terminal',
    'queue_linux::tests::terminal_unpublished_cleanup_failure_aborts_instead_of_losing_custody',
    'queue_linux::tests::unpublished_custody_cleanup_failure_is_process_terminal',
))
PROOF_BOUNDARIES = {
    'check-retained-pair-post-catch.py': ('f9f8628a08fc8f60d43721239df31f3225cf5ddcff4ed4b7237573ddec90ca59', 'c41d4d9111ce5418de7725a1b4e63773a064ae4436b84b19e6f120d9cbf1052a'),
    'check-retained-pair-owned-storage.py': ('f9f8628a08fc8f60d43721239df31f3225cf5ddcff4ed4b7237573ddec90ca59', 'c41d4d9111ce5418de7725a1b4e63773a064ae4436b84b19e6f120d9cbf1052a'),
    'check-retained-credit-dispatch.py': ('2b6f21626c0c4aaa2fd79e9af39026cfe3867d284a2c8c8e69f5aa8829c2b114', 'e12eb39e143bc32dcdc0e4ad90dc5bc9d2c7f274a734d1f486673909caae6bb4'),
    'check-request-charge.py': ('c40aa6b6dc786aa024b5b4020001d2e90ed2d34c92b42895097987f52c329c1e', '6a350a6e04e95cfe0f3694f07f5710ff41e17424df134078fbdc983535f11996'),
}
SCOPE = ('Unsigned reviewed twelve-file delta over pinned base; CPU/static only. No solver, '
         'native performance, parity, signed-source or refreshed proof-guard acceptance.')
MIN_FREE_BYTES = 4 * 1024**3
MAX_TARGET_BYTES = 4 * 1024**3
TOTAL_SECONDS = 10800


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def parse_json(raw):
    def invalid(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(raw, object_pairs_hook=strict_object, parse_constant=invalid)


def load(path, digest, name):
    need(path.resolve(strict=True) == path and path.is_file() and not path.is_symlink(), 'canonical helper')
    need(sha(path) == digest, 'pinned helper ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def helpers():
    native = load(SOURCE / NATIVE, NATIVE_SHA, 'diagnostic_cpu_native_owner')
    need(sha(SOURCE / BASE_HELPER) == BASE_HELPER_SHA, 'pinned base owner')
    need(not (SOURCE / HOT).with_name('base.py').exists(), 'no alternate base helper')
    hot = load(SOURCE / HOT, HOT_SHA, 'diagnostic_cpu_hot_owner')
    return native, hot


def parse_tree(raw):
    need(raw.endswith(b'\0'), 'complete Git tree stream')
    result = {}
    for row in raw[:-1].split(b'\0'):
        metadata, name = row.split(b'\t', 1)
        mode, kind, oid = metadata.decode('ascii').split(' ')
        name = name.decode('ascii')
        need(mode in ('100644', '100755') and kind == 'blob' and re.fullmatch('[0-9a-f]{40}', oid), 'ordinary Git blob')
        need(name not in result and not name.startswith('/') and all(part not in ('', '.', '..') for part in name.split('/')), 'unique relative source')
        result[name] = {'mode': mode, 'blob': oid}
    need(bool(result), 'nonempty source tree')
    return result


def source_snapshot(tree, root=SOURCE, roots=ROOTS, pins=PINS, new_paths=NEW_PATHS):
    need(root.resolve(strict=True) == root and root.is_dir(), 'canonical source root')
    need(set(pins) - set(tree) == set(new_paths), 'exact reviewed new-file delta')
    expected, actual = set(tree) | set(pins), {}
    for relative in roots:
        path = root / relative
        if relative == '.cargo' and not any(name == relative or name.startswith(relative + '/') for name in expected):
            need(not path.exists() and not path.is_symlink(), 'unsigned optional Cargo configuration')
            continue
        need(path.exists() and not path.is_symlink() and path.resolve() == path, 'canonical source root member')
        for member in path.rglob('*') if path.is_dir() else (path,):
            need(not member.is_symlink() and member.resolve() == member, 'no source alias')
            if member.is_dir():
                continue
            need(stat.S_ISREG(member.stat().st_mode), 'ordinary source file')
            name = member.relative_to(root).as_posix()
            need(name in expected, 'unexpected source file: ' + name)
            data = member.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            if name in pins:
                need(digest == pins[name], 'reviewed delta changed: ' + name)
            else:
                oid = hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()
                need(oid == tree[name]['blob'], 'base source changed: ' + name)
            mode = '100755' if member.stat().st_mode & 0o111 else '100644'
            need(mode == tree.get(name, {'mode': '100644'})['mode'], 'source executable mode')
            actual[name] = {'sha256': digest, 'mode': mode}
    need(set(actual) == expected, 'exact source closure: missing tracked file')
    return actual


def identity(path):
    resolved = path.resolve(strict=True)
    need(resolved.is_file(), 'ordinary measured tool')
    return {'invocation': str(path), 'resolved': str(resolved), 'sha256': sha(resolved)}


def tool_snapshot():
    paths = set(map(Path, TOOL_PINS)) | {TC / 'bin/rustdoc', Path('/usr/bin/cc'), Path('/usr/bin/ld'), Path('/usr/bin/ar')}
    paths.update(path for path in (TC / 'lib').iterdir() if path.is_file())
    paths.update((TC / 'lib/rustlib/x86_64-unknown-linux-gnu/lib').glob('*'))
    result = {str(path): identity(path) for path in sorted(paths)}
    for path, digest in TOOL_PINS.items():
        need(result[path]['sha256'] == digest, 'pinned tool bytes: ' + path)
    # Cargo configuration can be inherited from every source ancestor and CARGO_HOME.
    config_dirs = {Path('/home/harsh/.cargo'), *(path / '.cargo' for path in SOURCE.parents)}
    for folder in config_dirs:
        for name in ('config', 'config.toml'):
            path = folder / name
            need(not path.exists() and not path.is_symlink(), 'no ambient Cargo configuration: ' + str(path))
    return result


def environment(output, mode):
    return {'HOME': '/home/harsh', 'PATH': str(TC / 'bin') + ':/usr/bin:/bin',
            'RUSTUP_TOOLCHAIN': TC.name, 'RUSTC': str(TC / 'bin/rustc'), 'RUSTDOC': str(TC / 'bin/rustdoc'),
            'CARGO_HOME': '/home/harsh/.cargo', 'RUSTUP_HOME': '/home/harsh/.rustup',
            'CARGO_TARGET_DIR': str(output / ('target-' + mode)), 'CARGO_BUILD_JOBS': '2',
            'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1', 'CARGO_PROFILE_TEST_DEBUG': '0',
            'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_NET_OFFLINE': 'true', 'CARGO_TERM_COLOR': 'never',
            'CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER': '/usr/bin/cc',
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TMPDIR': str(output / 'tmp'),
            'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
            'RUST_TEST_THREADS': '2'}


def stages():
    rows = []
    def add(name, argv, seconds, kind, mode='all-features', **extra):
        rows.append({'name': name, 'argv': argv, 'seconds': seconds, 'kind': kind, 'mode': mode, **extra})
    git = ['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0']
    add('opening-head', git + ['rev-parse', 'HEAD'], 30, 'head')
    add('opening-tree', git + ['ls-tree', '-rz', '--full-tree', BASE, '--', *ROOTS], 30, 'tree')
    add('rustc-version', [str(TC / 'bin/rustc'), '-vV'], 30, 'version')
    add('cargo-version', [str(TC / 'bin/cargo'), '-V'], 30, 'version')
    add('clippy-version', [str(TC / 'bin/clippy-driver'), '--version'], 30, 'version')
    add('source-controls', [PYTHON, '-I', '-B', '-c',
        "import sys, unittest; sys.path.insert(0, " + repr(str(SOURCE / 'benchmarks/runtime_gfx942')) + "); "
        "suite=unittest.defaultTestLoader.loadTestsFromName('test_xgmi_retained_host_diagnostic'); "
        "result=unittest.TextTestRunner(verbosity=2).run(suite); sys.exit(not result.wasSuccessful())"], 90, 'controls')
    add('proof-boundary', [PYTHON, '-I', '-B', str(HERE / 'qualify.py'), '--proof-boundary'], 60, 'proof')
    for mode, flag in (('no-default', '--no-default-features'), ('all-features', '--all-features')):
        common = ['--frozen', '--offline', '--jobs', '2', '-p', 'fe2o3-kfd', flag, '--message-format=json']
        add(mode + '-lib-build', [str(TC / 'bin/cargo'), 'build', *common, '--lib'], 900, 'cargo', mode)
        add(mode + '-test-build', [str(TC / 'bin/cargo'), 'test', *common, '--lib', '--no-run'], 1200, 'test-build', mode)
        add(mode + '-test-list', ['@' + mode, '--list'], 90, 'list', mode)
        for index, (name, exact, _) in enumerate(FOCUS_GROUPS):
            add(mode + '-focus-' + str(index), ['@' + mode, name, *(['--exact'] if exact else []),
                '--test-threads=2', '-Z', 'unstable-options', '--format=json'], 180, 'focused', mode, focus=index)
        add(mode + '-clippy', [str(TC / 'bin/cargo'), 'clippy', *common, '--all-targets', '--', '-D', 'warnings'], 1200, 'cargo', mode)
    add('all-features-examples', [str(TC / 'bin/cargo'), 'build', '--frozen', '--offline', '--jobs', '2',
        '-p', 'fe2o3-kfd', '--all-features', '--message-format=json', '--example', 'kfd-sdma-xgmi-peer-benchmark',
        '--example', 'kfd-xgmi-retained-host-diagnostic'], 900, 'examples')
    add('all-features-full-lib', ['@all-features', '--test-threads=2', '-Z', 'unstable-options', '--format=json'], 3600, 'full')
    add('closing-head', git + ['rev-parse', 'HEAD'], 30, 'head')
    return rows


def cargo_output(raw, stderr):
    need(raw.endswith(b'\n'), 'complete Cargo JSON')
    rows = [parse_json(line) for line in raw.splitlines()]
    need(rows and rows[-1] == {'reason': 'build-finished', 'success': True}, 'successful Cargo completion')
    need(sum(row.get('reason') == 'build-finished' for row in rows) == 1, 'one Cargo completion')
    for row in rows:
        need(row.get('reason') in ('compiler-artifact', 'compiler-message', 'build-script-executed', 'build-finished'), 'known Cargo message')
        if row['reason'] == 'compiler-message':
            need(row['message']['level'] not in ('warning', 'error', 'failure-note'), 'diagnostic-free build')
    need(not re.search(rb'^\s*(?:warning|error)(?:\[|:)', stderr, re.M), 'no textual Cargo errors or warnings')
    return rows


def executable_artifact(rows, output, mode, target, test):
    selected = [row for row in rows if row.get('reason') == 'compiler-artifact'
                and row.get('target', {}).get('name') == target
                and row.get('profile', {}).get('test') is test and row.get('executable') is not None]
    need(len(selected) == 1 and selected[0].get('fresh') is False, 'one newly built artifact')
    row = selected[0]
    need(row.get('manifest_path') == str(SOURCE / 'crates/fe2o3-kfd/Cargo.toml'), 'KFD artifact manifest')
    need(row['target'].get('kind') == (['lib'] if test else ['example']), 'artifact target kind')
    path = Path(row['executable'])
    need(path.is_absolute() and path.resolve(strict=True) == path and path.is_relative_to(output / ('target-' + mode)), 'fresh owned artifact path')
    info = path.stat()
    need(stat.S_ISREG(info.st_mode) and info.st_mode & 0o111, 'ordinary executable ELF')
    with path.open('rb') as stream:
        need(stream.read(4) == b'\x7fELF', 'ELF artifact magic')
    return {'path': str(path), 'sha256': sha(path), 'size': info.st_size,
            'cargo_record': row, 'newly_built_in_this_attempt': True}


def test_list(raw):
    lines = raw.decode('ascii').splitlines()
    need(len(lines) >= 3 and lines[-2] == '', 'complete libtest list')
    summary = re.fullmatch(r'(\d+) tests, 0 benchmarks', lines[-1])
    need(summary is not None, 'libtest list summary')
    names = [line.removesuffix(': test') for line in lines[:-2]]
    need(all(line.endswith(': test') for line in lines[:-2]) and len(names) == len(set(names)) == int(summary[1]), 'exact unique listed tests')
    need(len(names) >= 1824 and FOCUS <= set(names), 'complete affected KFD roster and six new controls')
    return names


def libtest_output(raw, expected, total):
    need(raw.endswith(b'\n'), 'complete libtest JSON')
    lines = raw.split(b'\n')[:-1]
    need(len(lines) >= 2, 'complete libtest suite')
    opening = parse_json(lines[0])
    need(isinstance(opening, dict) and type(opening.get('test_count')) is int
         and opening == {'type': 'suite', 'event': 'started', 'test_count': len(expected)}, 'exact integer started test count')
    selected_parents = ABORT_PARENTS & set(expected)
    started, ended, witnesses = set(), {}, []
    index = 1
    while index < len(lines) - 1:
        if lines[index] == b'':
            need(index + 1 < len(lines) - 1 and lines[index + 1] == b'running 1 test', 'only exact adjacent abort-child header pair')
            active = (started - set(ended)) & selected_parents
            need(active and len(witnesses) < len(selected_parents), 'bounded header with a compatible active abort parent')
            witnesses.append({'blank_line': index + 1, 'header_line': index + 2,
                              'compatible_active_parents': sorted(active)})
            index += 2
            continue
        row = parse_json(lines[index])
        index += 1
        need(isinstance(row, dict) and row.get('type') == 'test' and row.get('name') in expected, 'only expected test events')
        name, event = row['name'], row.get('event')
        if event == 'started':
            need(name not in started and name not in ended, 'unique test start')
            started.add(name)
        elif event in ('ok', 'ignored'):
            need(name not in ended and (event == 'ignored' or name in started), 'unique terminal test observation')
            ended[name] = event
        elif event == 'timeout':
            need(name in started and name not in ended, 'timeout notification belongs to running test')
        else:
            raise ValueError('failed or unknown test event')
    final = parse_json(lines[-1])
    passed, ignored = sum(value == 'ok' for value in ended.values()), sum(value == 'ignored' for value in ended.values())
    need(set(ended) == set(expected) and isinstance(final, dict) and final.get('type') == 'suite' and final.get('event') == 'ok', 'complete successful test roster')
    need(ignored == 0, 'every expected KFD test must pass; no ignored roster is authorized')
    for key, value in {'passed': passed, 'failed': 0, 'ignored': ignored, 'measured': 0, 'filtered_out': total - len(expected)}.items():
        need(type(final.get(key)) is int and final[key] == value, 'exact libtest summary: ' + key)
    need(all(ended.get(name) == 'ok' for name in FOCUS & set(expected)), 'new semantic tests actually passed, not ignored')
    need(len(witnesses) == len(selected_parents) and all(ended.get(name) == 'ok' for name in selected_parents), 'one header witness per successful selected abort parent')
    # At most three parents means at most six assignments; overlap does not identify a child.
    assignments = [list(order) for order in permutations(sorted(selected_parents))
                   if all(parent in witness['compatible_active_parents'] for parent, witness in zip(order, witnesses))]
    need(bool(assignments), 'bounded compatible abort-header assignment exists')
    return {'passed': passed, 'ignored': ignored, 'filtered_out': total - len(expected), 'terminal_tests': ended,
            'abort_child_headers': {'expected_parents': sorted(selected_parents), 'witnesses': witnesses,
                                    'compatible_assignments': assignments, 'assignment_is_child_identity': False}}


def proof_boundary():
    result = {}
    for name, (prior, candidate) in PROOF_BOUNDARIES.items():
        module = runpy.run_path(str(SOURCE / 'crates/fe2o3-runtime-model/verus' / name), run_name='source_boundary_only')
        sources = module['snapshot']()
        observed = module['tree_hash']({path: text for path, text in sources.items() if path != module['PROOF']})
        need(module['SOURCE_TREE_SHA'] == prior and observed == candidate and prior != candidate, 'expected intentional source-guard mismatch')
        try:
            module['audit'](sources)
        except ValueError as error:
            result[name] = {'prior_guard': prior, 'candidate': candidate, 'accepted': False, 'rejection': str(error)}
        else:
            raise ValueError('proof source guard unexpectedly accepted changed source')
    return {'scope': 'source guard rejection only; no solver executed', 'guards': result, 'proof_acceptance': False}


@contextmanager
def handlers(owner):
    previous = {sig: signal.getsignal(sig) for sig in owner.MANAGED}
    try:
        for sig in owner.MANAGED:
            signal.signal(sig, owner.interrupted)
        yield
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)


def footprint(output):
    need(shutil.disk_usage(output).free >= MIN_FREE_BYTES, 'at least 4 GiB free before next stage')
    size = 0
    for mode in ('no-default', 'all-features'):
        for path in (output / ('target-' + mode)).rglob('*'):
            need(not path.is_symlink(), 'no owned target aliases')
            if path.is_file():
                size += path.stat().st_size
    need(size <= MAX_TARGET_BYTES, 'owned target logical bytes at most 4 GiB between stages')
    return size


def execute(output):
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3.12 -I -B')
    native, hot = helpers()
    native.fresh_output(output)
    os.umask(0o077)
    for name in ('tmp', 'target-no-default', 'target-all-features'):
        (output / name).mkdir(mode=0o700)
    rec = native.FreshRecorder(output / 'commands', SOURCE, hot)
    namespace = os.readlink('/proc/self/ns/pid')
    raw_before = {str(path): sha(path) for path in (HERE / 'qualify.py', HERE / 'test_qualify.py')}
    started, results, failures, artifacts, lists = time.monotonic(), [], [], {}, {}
    tree = source_before = tools_before = None
    accepted = False
    def save(name, value):
        hot.B.write_json(output / (name + '.json'), value)
    def continuity(full_tools=False):
        need(os.readlink('/proc/self/ns/pid') == namespace, 'same live owner PID namespace')
        need({path: sha(path) for path in raw_before} == raw_before, 'controller bytes unchanged')
        if source_before is not None:
            need(source_snapshot(tree) == source_before, 'source continuity')
        if tools_before is not None:
            if full_tools:
                need(tool_snapshot() == tools_before, 'complete observed tool continuity')
            else:
                need(all(identity(Path(path)) == tools_before[path] for path in TOOL_PINS), 'pinned executable continuity')
        for artifact in artifacts.values():
            path = Path(artifact['path'])
            need(path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
                 and path.stat().st_size == artifact['size'] and path.stat().st_mode & 0o111
                 and sha(path) == artifact['sha256'], 'retained fresh ELF continuity')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
    with handlers(hot.B):
        try:
            tools_before = tool_snapshot()
            save('tools-before', tools_before)
            save('plan', plan())
            save('raw-before', raw_before)
            save('namespace-before', namespace)
            save('environment', {mode: environment(output, mode) for mode in ('no-default', 'all-features')})
            for spec in stages():
                continuity()
                target_bytes = footprint(output)
                remaining = TOTAL_SECONDS - (time.monotonic() - started)
                need(remaining >= spec['seconds'], 'remaining total bound must cover whole next stage')
                argv = list(spec['argv'])
                if argv[0].startswith('@'):
                    argv[0] = artifacts[argv[0][1:]]['path']
                print(json.dumps({'event': 'start', 'stage': spec['name'], 'timeout_seconds': spec['seconds']}), flush=True)
                folder = rec.run(spec['name'], argv, spec['seconds'], env=environment(output, spec['mode']))
                raw, stderr = (folder / 'stdout').read_bytes(), (folder / 'stderr').read_bytes()
                detail = {}
                kind, mode = spec['kind'], spec['mode']
                if kind == 'head':
                    need(raw == (BASE + '\n').encode('ascii') and not stderr, 'pinned base HEAD')
                elif kind == 'tree':
                    need(not stderr, 'empty Git tree stderr')
                    tree = parse_tree(raw)
                    source_before = source_snapshot(tree)
                    save('source-before', source_before)
                    save('base-tree', tree)
                elif kind == 'version':
                    need(bool(raw) and not stderr, 'tool version output')
                elif kind == 'controls':
                    need(not raw and stderr.endswith(b'\nOK\n') and re.findall(rb'^Ran (\d+) tests in [0-9.]+s$', stderr, re.M) == [b'14'], 'all 14 source/parser controls')
                elif kind == 'proof':
                    detail = parse_json(raw)
                    need(not stderr and detail['proof_acceptance'] is False and set(detail['guards']) == set(PROOF_BOUNDARIES), 'explicit rejected proof-boundary roster')
                elif kind in ('cargo', 'test-build', 'examples'):
                    rows = cargo_output(raw, stderr)
                    if kind == 'test-build':
                        artifacts[mode] = executable_artifact(rows, output, mode, 'fe2o3_kfd', True)
                        detail = artifacts[mode]
                        save(mode + '-elf', detail)
                    elif kind == 'examples':
                        for target in ('kfd-sdma-xgmi-peer-benchmark', 'kfd-xgmi-retained-host-diagnostic'):
                            artifacts[target] = executable_artifact(rows, output, mode, target, False)
                        detail = {key: artifacts[key] for key in artifacts if key.startswith('kfd-')}
                        save('example-elfs', detail)
                elif kind == 'list':
                    need(not stderr, 'empty test list stderr')
                    lists[mode] = test_list(raw)
                    detail = {'names': lists[mode]}
                elif kind in ('focused', 'full'):
                    need(not stderr, 'empty test harness stderr')
                    if kind == 'full':
                        expected = set(lists[mode])
                    else:
                        name, exact, names = FOCUS_GROUPS[spec['focus']]
                        expected = names if names is not None else {name}
                        need({item for item in lists[mode] if item == name or (not exact and name in item)} == expected, 'exact focused filter selection')
                    detail = libtest_output(raw, expected, len(lists[mode]))
                else:
                    raise ValueError('unknown qualification stage')
                continuity()
                result = {'name': spec['name'], 'accepted': True, 'raw_sha256': rec.pins[spec['name']],
                          'detail': detail, 'target_logical_bytes_before': target_bytes}
                save(spec['name'] + '-result', result)
                results.append(result)
        except BaseException as error:
            failures.append(type(error).__name__ + ': ' + str(error))
        finally:
            # Every closing observation is independent, including when an earlier save fails.
            closing = {}
            for name, observe in (
                ('source-after', lambda: source_snapshot(tree) if tree is not None else None),
                ('tools-after', tool_snapshot),
                ('raw-after', lambda: {path: sha(path) for path in raw_before}),
                ('namespace-after', lambda: os.readlink('/proc/self/ns/pid')),
                ('fresh-census', lambda: native.fresh_census(rec, hot, namespace)),
            ):
                try:
                    closing[name] = observe()
                    save(name, closing[name])
                except BaseException as error:
                    failures.append(name + ': ' + type(error).__name__ + ': ' + str(error))
            try:
                continuity(full_tools=True)
                need(closing.get('source-after') == source_before and source_before is not None, 'complete closing source observation')
                need(closing.get('tools-after') == tools_before and tools_before is not None, 'complete closing tools observation')
                need(closing.get('raw-after') == raw_before and closing.get('namespace-after') == namespace, 'complete closing raw and namespace observations')
                need('fresh-census' in closing, 'complete fresh owned-group closure')
            except BaseException as error:
                failures.append('closing continuity: ' + str(error))
            accepted = not failures and [row['name'] for row in results] == [row['name'] for row in stages()]
            save('result', {'accepted': accepted, 'scope': SCOPE, 'failures': failures, 'results': results,
                 'attempted': rec.attempts, 'artifacts': artifacts, 'source_commit': BASE,
                 'fresh_elf_qualification_only': True, 'proof_acceptance': False,
                 'no_default_full_suite_run': False, 'all_features_full_suite_required': True,
                 'solver_invocations': 0, 'gpu_invocations': 0, 'cleanup_performed': False,
                 'next': 'parent review; preserve this attempt; no automatic retry or candidate mutation'})
    return 0 if accepted else 1


def plan():
    return {'scope': SCOPE, 'source': str(SOURCE), 'base': BASE, 'reviewed_delta': PINS,
            'stages': stages(), 'total_seconds': TOTAL_SECONDS, 'cargo_jobs': 2, 'test_threads': 2,
            'per_process_address_space_bytes': 8 * 1024**3, 'per_file_bytes': 1024**3,
            'min_free_bytes_before_each_stage': MIN_FREE_BYTES, 'max_target_logical_bytes_between_stages': MAX_TARGET_BYTES,
            'disk_guard_is_between_stages_not_a_filesystem_quota': True,
            'external_registry_and_system_dynamic_loader_not_hermetically_attested': True,
            'source_tree_mutation': False, 'format_edits': False, 'solver_invocations': 0, 'gpu_invocations': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--execute', action='store_true')
    group.add_argument('--proof-boundary', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3.12 -I -B')
    if args.proof_boundary:
        need(args.output is None, 'no proof-boundary output path')
        print(json.dumps(proof_boundary(), sort_keys=True))
    elif args.execute:
        need(args.output is not None, 'explicit fresh output is required')
        raise SystemExit(execute(args.output))
    else:
        need(args.output is None, 'output is only valid with explicit execute')
        print(json.dumps(plan(), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
