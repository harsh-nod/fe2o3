#!/usr/bin/env python3
"""Light controls only: no compiler, test ELF, solver, or GPU execution."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import tempfile
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('diagnostic_cpu_controller', HERE / 'qualify.py')
Q = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(Q)


def encoded(rows):
    return ('\n'.join(json.dumps(row) for row in rows) + '\n').encode('ascii')


def libtest_fixture(names, total=None):
    result = [{'type': 'suite', 'event': 'started', 'test_count': len(names)}]
    for name in names:
        result.extend(({'type': 'test', 'event': 'started', 'name': name},
                       {'type': 'test', 'event': 'ok', 'name': name}))
    result.append({'type': 'suite', 'event': 'ok', 'passed': len(names), 'failed': 0,
                   'ignored': 0, 'measured': 0, 'filtered_out': (total or len(names)) - len(names),
                   'exec_time': 0.001})
    return result


def libtest_stream(events):
    return b''.join(event if isinstance(event, bytes) else encoded([event]) for event in events)


def abort_fixture():
    names = sorted(Q.ABORT_PARENTS)
    rows = libtest_fixture(names)
    events = [rows[0]]
    for index in range(1, len(rows) - 1, 2):
        events.extend((rows[index], b'\nrunning 1 test\n', rows[index + 1]))
    return events + [rows[-1]]


def wait_wiring(source):
    queue = source.split('impl Gfx942NativeXgmiSdmaQueueV1 {', 1)[1]
    def method_body(method):
        return queue.split(method, 1)[1].split('\n    }\n', 1)[0]
    inner = method_body('fn wait_batch_with_timer')
    guard = inner.index('self.require_live_queue_state_v1()')
    Q.need(guard < inner.index('timer.measure'), 'live-state guard precedes first route timing effect')
    wrapper = ''.join(method_body('fn wait_batch_for_with_currentness').split(' {\n', 1)[1].split())
    Q.need(wrapper == ('self.wait_batch_with_timer(source_session,destination_session,tickets,'
                       'deadline,currentness,&mutXgmiWaitTimer::<false>::new(),)'),
           'exact effect-free const-false delegation')


class PlanTests(unittest.TestCase):
    def test_plan_is_explicit_bounded_and_never_launches_benchmarks(self):
        rows = Q.stages()
        self.assertEqual(len(rows), len({row['name'] for row in rows}))
        self.assertEqual([row['name'] for row in rows if row['kind'] == 'full'], ['all-features-full-lib'])
        full = next(row for row in rows if row['kind'] == 'full')
        self.assertEqual(full['seconds'], 3600)
        self.assertIn('--test-threads=2', full['argv'])
        self.assertNotIn('--ignored', full['argv'])
        self.assertEqual(len([row for row in rows if row['kind'] == 'focused']), 6)
        for row in rows:
            argv = row['argv']
            self.assertTrue(0 < row['seconds'] <= 3600)
            if argv[0] == str(Q.TC / 'bin/cargo') and row['kind'] != 'version':
                for token in ('--frozen', '--offline', '--jobs', '2', '-p', 'fe2o3-kfd'):
                    self.assertIn(token, argv)
                self.assertIn('--no-default-features' if row['mode'] == 'no-default' else '--all-features', argv)
                if argv[1] == 'clippy':
                    self.assertEqual(argv[-3:], ['--', '-D', 'warnings'])
                    self.assertIn('--all-targets', argv)
            self.assertNotIn('ssh', argv)
            self.assertFalse(argv[0].endswith('kfd-xgmi-retained-host-diagnostic'))

    def test_git_ignores_replacements_and_environment_is_closed(self):
        for row in Q.stages():
            if row['argv'][0] == '/usr/bin/git':
                self.assertIn('--no-replace-objects', row['argv'])
                self.assertIn('gc.auto=0', row['argv'])
        with patch.dict('os.environ', {'RUSTFLAGS': 'injected', 'LD_PRELOAD': 'injected'}):
            first = Q.environment(Path('/fresh'), 'no-default')
            second = Q.environment(Path('/fresh'), 'all-features')
        self.assertNotIn('RUSTFLAGS', first)
        self.assertNotIn('LD_PRELOAD', first)
        self.assertNotEqual(first['CARGO_TARGET_DIR'], second['CARGO_TARGET_DIR'])
        self.assertEqual(first['CARGO_BUILD_JOBS'], '2')
        self.assertEqual(first['CARGO_INCREMENTAL'], '0')
        self.assertEqual(first['CARGO_PROFILE_TEST_OPT_LEVEL'], '1')

    def test_reviewed_source_pins_still_match_without_building(self):
        self.assertEqual(len(Q.PINS), 12)
        for name, digest in Q.PINS.items():
            self.assertEqual(Q.sha(Q.SOURCE / name), digest, name)
        self.assertEqual(Q.sha(Q.SOURCE / Q.NATIVE), Q.NATIVE_SHA)
        self.assertEqual(Q.sha(Q.SOURCE / Q.HOT), Q.HOT_SHA)
        self.assertEqual(Q.sha(Q.SOURCE / Q.BASE_HELPER), Q.BASE_HELPER_SHA)


class SourceTests(unittest.TestCase):
    def test_guarded_inner_and_exact_ordinary_delegation_match_repaired_rust_test(self):
        source = (Q.SOURCE / 'crates/fe2o3-kfd/src/sdma.rs').read_text()
        wait_wiring(source)
        repair = (Q.SOURCE / 'crates/fe2o3-kfd/src/sdma/xgmi_retirement/tests.rs').read_text()
        self.assertIn('("fn wait_batch_with_timer", "timer.measure")', repair)
        self.assertIn('assert!(guard < effect, "{method}");', repair)
        self.assertIn('let wait_wrapper = method_body("fn wait_batch_for_with_currentness")', repair)
        self.assertIn('.split_once(" {\\n")', repair)
        self.assertIn('.split_whitespace()\n        .collect::<String>()', repair)
        self.assertIn('assert_eq!(\n        wait_wrapper,\n        concat!(', repair)
        self.assertIn('"&mutXgmiWaitTimer::<false>::new(),)"', repair)

    def test_guard_repair_mirror_rejects_missing_late_guard_true_mode_and_wrapper_effects(self):
        source = (Q.SOURCE / 'crates/fe2o3-kfd/src/sdma.rs').read_text()
        prefix, inner = source.split('fn wait_batch_with_timer', 1)
        missing = prefix + 'fn wait_batch_with_timer' + inner.replace('self.require_live_queue_state_v1()', 'Ok(())', 1)
        late = prefix + 'fn wait_batch_with_timer' + inner.replace('self.require_live_queue_state_v1()', 'timer.measure(/* effect */)', 1).replace('timer.measure(XgmiWaitPhase::Opening', 'self.require_live_queue_state_v1(); timer.measure(XgmiWaitPhase::Opening', 1)
        prefix, wrapper = source.split('fn wait_batch_for_with_currentness', 1)
        true_mode = prefix + 'fn wait_batch_for_with_currentness' + wrapper.replace('XgmiWaitTimer::<false>', 'XgmiWaitTimer::<true>', 1)
        preceding = prefix + 'fn wait_batch_for_with_currentness' + wrapper.replace(' {\n', ' {\n        effect();\n', 1)
        trailing = prefix + 'fn wait_batch_for_with_currentness' + wrapper.replace('\n    }\n', ';\n        effect();\n    }\n', 1)
        for altered in (missing, late, true_mode, preceding, trailing):
            with self.subTest(altered=altered[:80]), self.assertRaises(ValueError):
                wait_wiring(altered)

    def test_exact_three_abort_parents_keep_inherited_child_harness_and_sigabrt_assertions(self):
        path = Q.SOURCE / 'crates/fe2o3-kfd/src/queue_linux.rs'
        self.assertEqual(Q.sha(path), '45b668e07376f4edccadb2c282093af35d17298a81b47b1b6fa0ef08cab827b8')
        source = path.read_text()
        self.assertEqual(len(Q.ABORT_PARENTS), 3)
        for parent in Q.ABORT_PARENTS:
            body = source.split('fn ' + parent.rsplit('::', 1)[-1] + '() {', 1)[1].split('\n    }\n', 1)[0]
            self.assertEqual(body.count('std::process::Command::new(std::env::current_exe().unwrap())'), 1)
            for token in ('.arg("--exact")', '.arg("' + parent + '")', '.env(CHILD_ENV, "1")', '.status()', 'assert_eq!(status.signal(), Some(libc::SIGABRT));'):
                self.assertIn(token, body)
            for token in ('.stdout(', '.stderr(', '--format', '--test-threads'):
                self.assertNotIn(token, body)

    def fixture(self, root):
        (root / 'crates').mkdir()
        raw = b'base source\n'
        path = root / 'crates/source.rs'
        path.write_bytes(raw)
        oid = hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()
        return {'crates/source.rs': {'mode': '100644', 'blob': oid}}

    def test_exact_tree_and_optional_absence_then_refuse_extra_or_missing_source(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            tree = self.fixture(root)
            def observe():
                return Q.source_snapshot(tree, root, ('crates', '.cargo'), {}, set())
            self.assertEqual(set(observe()), {'crates/source.rs'})
            (root / '.cargo').mkdir()
            with self.assertRaisesRegex(ValueError, 'optional Cargo'):
                observe()
            (root / '.cargo').rmdir()
            (root / 'crates/extra').write_bytes(b'extra')
            with self.assertRaisesRegex(ValueError, 'unexpected source'):
                observe()
            (root / 'crates/extra').unlink()
            (root / 'crates/source.rs').unlink()
            with self.assertRaisesRegex(ValueError, 'missing tracked'):
                observe()

    def test_changed_baseline_and_aliases_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            tree = self.fixture(root)
            path = root / 'crates/source.rs'
            path.write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError, 'base source changed'):
                Q.source_snapshot(tree, root, ('crates',), {}, set())
            path.unlink()
            path.symlink_to(root / 'missing')
            with self.assertRaisesRegex(ValueError, 'source alias'):
                Q.source_snapshot(tree, root, ('crates',), {}, set())

    def test_tree_parser_rejects_duplicate_paths_and_symlink_modes(self):
        row = b'100644 blob ' + b'0' * 40 + b'\tfile\0'
        self.assertEqual(set(Q.parse_tree(row)), {'file'})
        for raw in (row + row, row[:-1], row.replace(b'100644', b'120000'), row.replace(b'file', b'../file')):
            with self.assertRaises(ValueError):
                Q.parse_tree(raw)


class ClassifierTests(unittest.TestCase):
    def test_cargo_requires_one_terminal_success_and_rejects_warnings(self):
        good = [{'reason': 'build-finished', 'success': True}]
        self.assertEqual(Q.cargo_output(encoded(good), b''), good)
        for rows in ([{'reason': 'build-finished', 'success': False}], good + good,
                     [{'reason': 'compiler-message', 'message': {'level': 'warning'}}, *good],
                     [{'reason': 'unknown'}, *good]):
            with self.assertRaises(ValueError):
                Q.cargo_output(encoded(rows), b'')
        with self.assertRaises(ValueError):
            Q.cargo_output(encoded(good), b'warning: quiet success is not enough\n')

    def test_artifacts_require_fresh_cargo_manifest_target_and_owned_real_elf(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            target = output / 'target-all-features'
            target.mkdir()
            path = target / 'elf'
            path.write_bytes(b'\x7fELFsynthetic-not-executed')
            path.chmod(0o700)
            row = {'reason': 'compiler-artifact', 'manifest_path': str(Q.SOURCE / 'crates/fe2o3-kfd/Cargo.toml'),
                   'target': {'name': 'fe2o3_kfd', 'kind': ['lib']}, 'profile': {'test': True},
                   'executable': str(path), 'fresh': False}
            record = Q.executable_artifact([row], output, 'all-features', 'fe2o3_kfd', True)
            self.assertEqual(record['sha256'], Q.sha(path))
            for update in ({'fresh': True}, {'manifest_path': '/other/Cargo.toml'},
                           {'target': {'name': 'fe2o3_kfd', 'kind': ['example']}}, {'executable': '/bin/true'}):
                with self.assertRaises(ValueError):
                    Q.executable_artifact([dict(row, **update)], output, 'all-features', 'fe2o3_kfd', True)
            alias = target / 'alias'
            alias.symlink_to(path)
            with self.assertRaises(ValueError):
                Q.executable_artifact([dict(row, executable=str(alias))], output, 'all-features', 'fe2o3_kfd', True)

    def test_complete_test_list_is_exact_and_contains_all_six_new_tests(self):
        names = sorted(Q.FOCUS | {f'old::{index}' for index in range(1824 - len(Q.FOCUS))})
        raw = ('\n'.join(name + ': test' for name in names) + '\n\n1824 tests, 0 benchmarks\n').encode('ascii')
        self.assertEqual(Q.test_list(raw), names)
        for altered in (raw.replace(b'1824 tests', b'1825 tests'), raw.replace(names[0].encode(), names[1].encode(), 1),
                        raw.replace(next(iter(Q.FOCUS)).encode(), b'not_the_new_control', 1)):
            with self.assertRaises(ValueError):
                Q.test_list(altered)

    def test_harness_requires_exact_started_terminal_and_summary_join(self):
        expected = set(Q.FOCUS)
        good = libtest_fixture(sorted(expected), 1830)
        result = Q.libtest_output(encoded(good), expected, 1830)
        self.assertEqual(result['passed'], 6)
        malformed = []
        changed = copy.deepcopy(good)
        changed[2]['event'] = 'ignored'
        changed[-1].update(passed=5, ignored=1)
        malformed.append(changed)
        malformed.append(good[:2] + good[3:])
        malformed.append(good[:-1] + [good[2], good[-1]])
        changed = copy.deepcopy(good)
        changed[-1]['filtered_out'] = 0
        malformed.append(changed)
        changed = copy.deepcopy(good)
        changed[2]['event'] = 'failed'
        malformed.append(changed)
        for rows in malformed:
            with self.assertRaises(ValueError):
                Q.libtest_output(encoded(rows), expected, 1830)

    def test_long_running_notifications_are_explicit_but_ignored_old_tests_are_rejected(self):
        rows = libtest_fixture(['old::a', 'old::b'])
        rows.insert(4, {'type': 'test', 'name': 'old::b', 'event': 'timeout'})
        result = Q.libtest_output(encoded(rows), {'old::a', 'old::b'}, 2)
        self.assertEqual(result['ignored'], 0)
        rows[2]['event'] = 'ignored'
        rows[-1].update(passed=1, ignored=1)
        with self.assertRaisesRegex(ValueError, 'no ignored roster'):
            Q.libtest_output(encoded(rows), {'old::a', 'old::b'}, 2)

    def test_suite_started_count_rejects_bool_and_non_integer(self):
        for count in (True, False, 1.0, '1'):
            rows = libtest_fixture(['old::a'])
            rows[0]['test_count'] = count
            with self.assertRaisesRegex(ValueError, 'integer started test count'):
                Q.libtest_output(encoded(rows), {'old::a'}, 1)

    def test_three_exact_abort_headers_and_focused_no_header_selection(self):
        events = abort_fixture()
        result = Q.libtest_output(libtest_stream(events), Q.ABORT_PARENTS, 3)
        witness = result['abort_child_headers']
        self.assertEqual(witness['expected_parents'], sorted(Q.ABORT_PARENTS))
        self.assertEqual(witness['compatible_assignments'], [sorted(Q.ABORT_PARENTS)])
        self.assertEqual(len(witness['witnesses']), 3)
        self.assertIs(witness['assignment_is_child_identity'], False)
        for parent in Q.ABORT_PARENTS:
            rows = libtest_fixture([parent], 1830)
            raw = libtest_stream([rows[0], rows[1], b'\nrunning 1 test\n', rows[2], rows[3]])
            self.assertEqual(Q.libtest_output(raw, {parent}, 1830)['passed'], 1)
        plain = Q.libtest_output(encoded(libtest_fixture(sorted(Q.FOCUS))), Q.FOCUS, len(Q.FOCUS))
        self.assertEqual(plain['abort_child_headers']['witnesses'], [])
        self.assertEqual(plain['abort_child_headers']['compatible_assignments'], [[]])

    def test_overlapping_parents_have_bounded_compatible_assignments_not_exact_identity(self):
        rows = libtest_fixture(sorted(Q.ABORT_PARENTS))
        events = [rows[0], rows[1], rows[3], b'\nrunning 1 test\n', b'\nrunning 1 test\n',
                  rows[2], rows[4], rows[5], b'\nrunning 1 test\n', rows[6], rows[7]]
        witness = Q.libtest_output(libtest_stream(events), Q.ABORT_PARENTS, 3)['abort_child_headers']
        self.assertEqual(len(witness['compatible_assignments']), 2)
        self.assertIs(witness['assignment_is_child_identity'], False)
        self.assertEqual(witness['witnesses'][0]['compatible_active_parents'], sorted(Q.ABORT_PARENTS)[:2])
        events = [rows[0], rows[1], rows[3], rows[5], *([b'\nrunning 1 test\n'] * 3), rows[2], rows[4], rows[6], rows[7]]
        self.assertEqual(len(Q.libtest_output(libtest_stream(events), Q.ABORT_PARENTS, 3)['abort_child_headers']['compatible_assignments']), 6)

    def test_header_assignment_rejects_hall_deficient_active_sets(self):
        rows = libtest_fixture(sorted(Q.ABORT_PARENTS))
        events = [rows[0], rows[1], b'\nrunning 1 test\n', b'\nrunning 1 test\n', rows[2],
                  rows[3], rows[5], b'\nrunning 1 test\n', rows[4], rows[6], rows[7]]
        with self.assertRaisesRegex(ValueError, 'compatible abort-header assignment'):
            Q.libtest_output(libtest_stream(events), Q.ABORT_PARENTS, 3)

    def test_extra_missing_or_unmatched_header_witnesses_are_rejected(self):
        events = abort_fixture()
        malformed = (events[:2] + events[3:], events[:2] + [b'\nrunning 1 test\n'] + events[2:],
                     events[:1] + [b'\nrunning 1 test\n'] + events[1:], events[:4] + [b'\nrunning 1 test\n'] + events[4:],
                     events[:-1] + [b'\nrunning 1 test\n'] + events[-1:])
        for changed in malformed:
            with self.assertRaises(ValueError):
                Q.libtest_output(libtest_stream(changed), Q.ABORT_PARENTS, 3)
        plain = libtest_fixture(['old::a'])
        with self.assertRaisesRegex(ValueError, 'compatible active abort parent'):
            Q.libtest_output(libtest_stream(plain[:2] + [b'\nrunning 1 test\n'] + plain[2:]), {'old::a'}, 1)

    def test_header_grammar_and_arbitrary_non_json_remain_closed(self):
        events = abort_fixture()
        for bad in (b'running 1 test\n', b'\nrunning 2 tests\n', b' \nrunning 1 test\n',
                    b'\r\nrunning 1 test\r\n', b'\n', b'\n\nrunning 1 test\n',
                    b'arbitrary diagnostic\n', b'[]\n', b'"running 1 test"\n', b'0\n'):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                Q.libtest_output(libtest_stream(events[:2] + [bad] + events[3:]), Q.ABORT_PARENTS, 3)
        for suffix in (b'\n', b'running 1 test\n', b'extra\n'):
            with self.assertRaises(ValueError):
                Q.libtest_output(libtest_stream(events) + suffix, Q.ABORT_PARENTS, 3)

    def test_failed_or_ignored_tests_never_pass_with_matching_headers(self):
        for event in ('failed', 'ignored'):
            events = abort_fixture()
            events[3]['event'] = event
            events[-1].update(passed=2, failed=int(event == 'failed'), ignored=int(event == 'ignored'))
            with self.assertRaises(ValueError):
                Q.libtest_output(libtest_stream(events), Q.ABORT_PARENTS, 3)
        events = abort_fixture()
        events[-1].update(event='failed', failed=1)
        with self.assertRaises(ValueError):
            Q.libtest_output(libtest_stream(events), Q.ABORT_PARENTS, 3)

    def test_original_rejected_full_suite_raw_still_rejects_without_reclassification(self):
        old = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-attempt-1')
        raw = old / 'commands/all-features-full-lib/stdout'
        self.assertEqual(Q.sha(raw), '69ecfd73475f6f35a70f498316e12df4aa635e739e5aa40e89a688d876dfcb6c')
        names = Q.test_list((old / 'commands/all-features-test-list/stdout').read_bytes())
        with self.assertRaisesRegex(ValueError, 'failed or unknown test event'):
            Q.libtest_output(raw.read_bytes(), set(names), len(names))

    def test_json_duplicate_keys_and_nonfinite_numbers_are_rejected(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}'):
            with self.assertRaises(ValueError):
                Q.parse_json(raw)


class LifecycleTests(unittest.TestCase):
    def run_fake(self, output, save_failure=False):
        attempts, saves, closing = [], [], []
        managed = (signal.SIGHUP, signal.SIGTERM)
        old_handlers = {sig: signal.getsignal(sig) for sig in managed}
        owner = types.SimpleNamespace(MANAGED=managed, interrupted=lambda *_: None)
        def write(path, value):
            saves.append(path.stem)
            if save_failure and path.stem in ('source-after', 'result'):
                raise OSError('synthetic disk failure')
            path.write_text(json.dumps(value))
        owner.write_json = write
        class Recorder:
            def __init__(self, folder, _source, _hot):
                self.output = folder
                folder.mkdir()
                self.attempts, self.pins = attempts, {}
            def run(self, name, argv, seconds, **_kwargs):
                attempts.append(name)
                folder = self.output / name
                folder.mkdir()
                (folder / 'stdout').write_bytes(b'not a Cargo JSON success\n' if name != 'opening-tree' else b'tree\0')
                (folder / 'stderr').write_bytes(b'')
                self.pins[name] = {'synthetic': name}
                return folder
        def census(*_args):
            closing.append('census')
            return {'scope': 'synthetic-replay-only'}
        native = types.SimpleNamespace(FreshRecorder=Recorder, fresh_census=census,
                                       fresh_output=lambda path: path.mkdir(mode=0o700))
        specs = [{'name': name, 'argv': ['/not/executed'], 'seconds': 1, 'kind': kind, 'mode': 'all-features'}
                 for name, kind in (('opening-tree', 'tree'), ('malformed-cargo', 'cargo'), ('forbidden-next', 'cargo'))]
        hot = types.SimpleNamespace(B=owner)
        with patch.object(Q, 'helpers', return_value=(native, hot)), patch.object(Q, 'stages', return_value=specs), \
             patch.object(Q, 'tool_snapshot', return_value={'tools': 'synthetic'}), patch.object(Q, 'TOOL_PINS', {}), \
             patch.object(Q, 'source_snapshot', return_value={'source': 'synthetic'}), patch.object(Q, 'parse_tree', return_value={}), \
             patch.object(Q, 'footprint', return_value=0), patch.object(Q.resource, 'setrlimit'), \
             patch.object(Q.os, 'umask'):
            if save_failure:
                with self.assertRaisesRegex(OSError, 'disk failure'):
                    Q.execute(output)
            else:
                self.assertEqual(Q.execute(output), 1)
        self.assertEqual({sig: signal.getsignal(sig) for sig in managed}, old_handlers)
        self.assertEqual(attempts, ['opening-tree', 'malformed-cargo'])
        self.assertEqual(closing, ['census'])
        self.assertTrue({'source-after', 'tools-after', 'raw-after', 'namespace-after', 'fresh-census', 'result'} <= set(saves))

    def test_first_malformed_success_stops_work_but_runs_every_closing_observation(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(Path(directory) / 'attempt')

    def test_disk_failure_does_not_skip_other_closing_observations_or_handler_restore(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(Path(directory) / 'attempt', save_failure=True)

    def test_signal_handler_restoration_survives_base_exception(self):
        managed = (signal.SIGHUP, signal.SIGTERM)
        previous = {sig: signal.getsignal(sig) for sig in managed}
        owner = types.SimpleNamespace(MANAGED=managed, interrupted=lambda *_: None)
        with self.assertRaises(KeyboardInterrupt):
            with Q.handlers(owner):
                raise KeyboardInterrupt('synthetic interrupt')
        self.assertEqual({sig: signal.getsignal(sig) for sig in managed}, previous)


if __name__ == '__main__':
    unittest.main(verbosity=2)
