#!/usr/bin/env python3
"""Explicit linked D2 CPU qualification; never promote either rejected attempt."""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time
import types

HERE = Path(__file__).resolve().parent
CONTROLLER = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-controller-20260930-revision-2')
PRIOR = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-attempt-2')
CONTROLLER_PINS = {
    'qualify.py': '0c504f7a512873776df4af8e1666d6dfd3ab401e5f05dbf7d3c35a9e49eae3cb',
    'test_qualify.py': '1e9ed499bfedd484462836d059b43489c6f416b7f6ebabf3e8c917763a1e27af',
    'README.md': '3d84f4eb1deb7e43d3837dc2030c250bd3472d1b91e187985a388882dafdf084',
    'TRANSITION.json': '4bb5172dbacb5801e32eccaf3dc26a7c477f921930b6df5cc2f841b6ccbc3cf1',
}
PRIOR_PINS = {
    'result.json': 'dfb50491fefc4ddbf982c23d6e8c2238c8996b86934607000294a86ce235e302',
    'fresh-census.json': '19f8768b20c596e88a705493388bb697b92df7a0536e937ac7493d714329a7f2',
    'source-before.json': '73ef7e432dea941606caa96ab815a91b326dca33dc0a2126a402dba1989af4f7',
    'source-after.json': '73ef7e432dea941606caa96ab815a91b326dca33dc0a2126a402dba1989af4f7',
    'tools-before.json': '69b38d4e68c8a316b3ea3272e9ff3418be8ddf0aa5df269eb336914beeccf4af',
    'tools-after.json': '69b38d4e68c8a316b3ea3272e9ff3418be8ddf0aa5df269eb336914beeccf4af',
    'raw-before.json': '2377568b110a3ffa49d5b2d7251d051135aa121c6e7956776394dffef7746453',
    'raw-after.json': '2377568b110a3ffa49d5b2d7251d051135aa121c6e7956776394dffef7746453',
    'namespace-before.json': '4bb3cdd663603f5697b593fdbaf2446996a7c30bd4be84dfeaf74deca6ad88db',
    'namespace-after.json': '4bb3cdd663603f5697b593fdbaf2446996a7c30bd4be84dfeaf74deca6ad88db',
    'no-default-elf.json': '8259528a4cf749f20b32f8af61d383af3ec159b3c32e8c7e7e427d5c61c8a4bb',
    'all-features-elf.json': '107a6258c0ad0cd9fa07d28fe771e0210ac642ec320cf3ddca80a638b3d3e4e3',
    'plan.json': 'a07e32749ee8ea6cee8ec0de2f21e448e136abbf07646da00d0adb62cd1b68a2',
    'environment.json': '6a8e584e9608a02d131df8ec1fac70458f9037953f99863aa776a9641d74937b',
    'base-tree.json': '7d7b3f3febcb7d037cf5f8976c6423962cba659af795ceae8d57a7e7cdd73e12',
}
REMAINING = ('all-features-focus-2', 'all-features-clippy', 'all-features-examples',
             'all-features-full-lib', 'closing-head')
FORMATTER_SHA = 'a9137d0c198ceb6c72193d517d3c9007b3ec7a90d3d10ec6889773eca48261b4'
LEGACY_TEST = 'crates/fe2o3-kfd/src/sdma/retained_pair/tests.rs'
BASE_TEST_BLOB = 'e4d1bcddcfa626b3bfb584db972b348d000004bb'
BASE_TEST_SHA = '51c8f719a9daebf022e8628e3099f234bc768482cf59617e285e83907667b0bd'
INSERTION_SHA = 'ca8affadbdc8e1052a1d801ab6d38336f0aec56cc52b0cae0c8451e6663e54bf'
FRAGMENT_SHA = '614a600c667ba95c0082b36fd20ca38b7e25614b7426a59a01ee939d02544d9c'
FRAGMENT_NAME = 'retained-diagnostic-added-test.rs'
FORMAT_HISTORY = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-1')
OLD_CONTROLLER = HERE.with_name('fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930')
FORMAT_HISTORY_PINS = {
    FORMAT_HISTORY / 'result.json': '0ec4eaaec20a5d91e4e43b3a5ede17114391e71199dc2d5f18686cc4ea40434e',
    FORMAT_HISTORY / 'fresh-census.json': '870b80ac71e8f997cb53a417dc747112bc74769508441205e3758a2b03ae24a7',
    FORMAT_HISTORY / 'commands/changed-rust-format-check/receipt.json': 'f822ce09c18f7ea802a048a61b7a7f817dca283038bee3988d8cb2bcdae52928',
    FORMAT_HISTORY / 'commands/changed-rust-format-check/stdout': '8c5b45cff60245cda661637cd0f0bb3c05b482c772c6f1341fa9d5c701bcb683',
    FORMAT_HISTORY / 'commands/changed-rust-format-check/stderr': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    OLD_CONTROLLER / 'continue.py': 'aa595babd8bf4d716eaf58c9dbe50758c764a1a7edb759b6c62ad19d2e151a0a',
    OLD_CONTROLLER / 'test_continue.py': '78b38148146eae02905e0ecc7325b664b258f389c907ea4f72fd8c60e87433e1',
    OLD_CONTROLLER / 'README.md': 'f1528441d43259afed55ca2ddd1a2db3291fa5d684b92bc71a6dddf2db37dfdb',
}
SCOPE = ('New linked CPU/static qualification: replay exact D2 prior19, two changed-code format checks and five new stages. '
         'Prior attempt remains rejected. Retained test ELFs come from D2; no continuous '
         'single-owner time window, solver, formal proof, GPU or native-performance claim. '
         'Legacy full-file formatting rejection remains rejected; no whole-file formatting acceptance.')


def need(value, message):
    if not value:
        raise ValueError(message)


def ordinary(path):
    need(path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
         and stat.S_ISREG(path.stat().st_mode), 'canonical ordinary input: ' + str(path))
    return path


def sha(path):
    with ordinary(Path(path)).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def controller_snapshot():
    result = {name: sha(CONTROLLER / name) for name in CONTROLLER_PINS}
    need(result == CONTROLLER_PINS, 'unchanged pinned C2 controller')
    return result


controller_snapshot()
SPEC = importlib.util.spec_from_file_location('retained_diagnostic_c2_linked', CONTROLLER / 'qualify.py')
Q = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(Q)


def stages():
    rows = Q.stages()
    need(len(rows) == 24 and tuple(row['name'] for row in rows[19:]) == REMAINING, 'exact five unattempted C2 stages')
    rust = sorted(name for name in Q.PINS if name.endswith('.rs'))
    need(len(rust) == 8 and LEGACY_TEST in rust, 'exact eight changed/new Rust paths')
    formatter = [str(Q.TC / 'bin/rustfmt'), '--check', '--edition', '2024', '--config', 'skip_children=true']
    return [
        {'name': 'seven-rust-paths-format-check', 'argv': formatter + [name for name in rust if name != LEGACY_TEST],
         'seconds': 90, 'kind': 'format', 'mode': 'all-features'},
        {'name': 'added-test-fragment-format-check', 'argv': formatter + ['@format-fragment'],
         'seconds': 90, 'kind': 'format', 'mode': 'all-features'},
        *rows[19:],
    ]


def formatter_snapshot():
    value = Q.identity(Q.TC / 'bin/rustfmt')
    need(value['sha256'] == FORMATTER_SHA, 'pinned scoped formatter')
    return value


def legacy_rejection_snapshot():
    observed = {str(path): sha(path) for path in FORMAT_HISTORY_PINS}
    need(observed == {str(path): digest for path, digest in FORMAT_HISTORY_PINS.items()}, 'unchanged full-file formatting rejection and controller')
    result = Q.parse_json((FORMAT_HISTORY / 'result.json').read_bytes())
    need(result['accepted'] is False and result['attempted'] == ['changed-rust-format-check']
         and result['failures'] == ['RuntimeError: changed-rust-format-check failed'], 'legacy full-file formatting remains rejected')
    return observed


def extract_fragment(data, base_row):
    need(base_row == {'mode': '100644', 'blob': BASE_TEST_BLOB}, 'authenticated base test blob and mode')
    begin = b'#[test]\nfn retained_diagnostic_errors_terminal_success_and_panics_never_publish_observations() {\n'
    following = b'#[test]\nfn retained_pair_nonlossy_ticket_projection_preserves_exact_variant_custody() {\n'
    need(data.count(begin) == data.count(following) == 1, 'unique exact diagnostic block boundaries')
    start, end = data.index(begin), data.index(following)
    need(start < end, 'ordered diagnostic block boundaries')
    insertion = data[start:end]
    need(insertion.endswith(b'}\n\n') and hashlib.sha256(insertion).hexdigest() == INSERTION_SHA, 'exact added diagnostic block bytes')
    reconstructed = data[:start] + data[end:]
    blob = hashlib.sha1(b'blob ' + str(len(reconstructed)).encode('ascii') + b'\0' + reconstructed).hexdigest()
    need(blob == BASE_TEST_BLOB and hashlib.sha256(reconstructed).hexdigest() == BASE_TEST_SHA,
         'removing exact insertion reconstructs authenticated base bytes')
    fragment = insertion[:-1]
    need(fragment.endswith(b'}\n') and not fragment.endswith(b'\n\n')
         and hashlib.sha256(fragment).hexdigest() == FRAGMENT_SHA, 'canonical pinned standalone fragment')
    return fragment


def create_fragment(output, tree):
    data = ordinary(Q.SOURCE / LEGACY_TEST).read_bytes()
    fragment = extract_fragment(data, tree[LEGACY_TEST])
    need(hashlib.sha256(data).hexdigest() == Q.PINS[LEGACY_TEST], 'unchanged pinned candidate test file')
    with (output / FRAGMENT_NAME).open('xb') as target:
        target.write(fragment)
    return fragment_snapshot(output)


def fragment_snapshot(output):
    path = ordinary(output / FRAGMENT_NAME)
    info = path.stat()
    need(info.st_nlink == 1 and info.st_size == 1821 and sha(path) == FRAGMENT_SHA, 'fresh standalone fragment unchanged')
    return {'path': str(path), 'sha256': FRAGMENT_SHA, 'size': info.st_size,
            'source_path': LEGACY_TEST, 'source_sha256': Q.PINS[LEGACY_TEST],
            'base_blob': BASE_TEST_BLOB, 'base_sha256': BASE_TEST_SHA, 'insertion_sha256': INSERTION_SHA}


def environment(output, mode):
    result = Q.environment(PRIOR, mode)
    result['TMPDIR'] = str(output / 'tmp')
    return result


def artifact_snapshot(artifacts):
    result = {}
    for name, artifact in artifacts.items():
        path = ordinary(Path(artifact['path']))
        need(path.is_relative_to(PRIOR / 'target-all-features') or path.is_relative_to(PRIOR / 'target-no-default'),
             'retained artifact in exact D2 targets')
        need(path.stat().st_mode & 0o111 and path.stat().st_size == artifact['size']
             and sha(path) == artifact['sha256'], 'unchanged retained ELF: ' + name)
        result[name] = {'path': str(path), 'sha256': artifact['sha256'], 'size': artifact['size']}
    return result


def command(spec, artifacts, output=None):
    argv = list(spec['argv'])
    if argv[0].startswith('@'):
        argv[0] = artifacts[argv[0][1:]]['path']
    if '@format-fragment' in argv:
        need(output is not None, 'fresh fragment output path')
        argv = [str(output / FRAGMENT_NAME) if arg == '@format-fragment' else arg for arg in argv]
    return argv


def classify(spec, raw, stderr, artifacts, lists):
    kind, mode = spec['kind'], spec['mode']
    if kind == 'format':
        need(not raw and not stderr, 'empty successful scoped formatter output')
    elif kind == 'head':
        need(raw == (Q.BASE + '\n').encode('ascii') and not stderr, 'pinned base HEAD')
    elif kind == 'tree':
        need(not stderr, 'empty Git tree stderr')
        Q.parse_tree(raw)
    elif kind == 'version':
        need(bool(raw) and not stderr, 'tool version output')
    elif kind == 'controls':
        need(not raw and stderr.endswith(b'\nOK\n')
             and Q.re.findall(rb'^Ran (\d+) tests in [0-9.]+s$', stderr, Q.re.M) == [b'14'], 'all 14 source controls')
    elif kind == 'proof':
        detail = Q.parse_json(raw)
        need(not stderr and detail == Q.proof_boundary(), 'exact intentionally rejected proof boundary')
        return detail
    elif kind in ('cargo', 'test-build', 'examples'):
        rows = Q.cargo_output(raw, stderr)
        if kind == 'test-build':
            artifacts[mode] = Q.executable_artifact(rows, PRIOR, mode, 'fe2o3_kfd', True)
            return artifacts[mode]
        if kind == 'examples':
            for target in ('kfd-sdma-xgmi-peer-benchmark', 'kfd-xgmi-retained-host-diagnostic'):
                artifacts[target] = Q.executable_artifact(rows, PRIOR, mode, target, False)
            return {name: value for name, value in artifacts.items() if name.startswith('kfd-')}
    elif kind == 'list':
        need(not stderr, 'empty test list stderr')
        lists[mode] = Q.test_list(raw)
        return {'names': lists[mode]}
    elif kind in ('focused', 'full'):
        need(not stderr, 'empty test harness stderr')
        expected = set(lists[mode])
        if kind == 'focused':
            name, exact, names = Q.FOCUS_GROUPS[spec['focus']]
            expected = names if names is not None else {name}
            need({item for item in lists[mode] if item == name or (not exact and name in item)} == expected,
                 'exact focused filter selection')
        return Q.libtest_output(raw, expected, len(lists[mode]))
    else:
        raise ValueError('unknown linked stage')
    return {}


def prior_audit(native, hot, namespace):
    controller_snapshot()
    need(PRIOR.resolve(strict=True) == PRIOR and PRIOR.is_dir(), 'canonical rejected D2 attempt')
    load = lambda name: Q.parse_json(ordinary(PRIOR / (name + '.json')).read_bytes())
    pins = {name: sha(PRIOR / name) for name in PRIOR_PINS}
    need(pins == PRIOR_PINS, 'exact pinned rejected D2 metadata')
    result, census = load('result'), load('fresh-census')
    specs = Q.stages()[:19]
    names = [spec['name'] for spec in specs]
    need(result['accepted'] is False and result['failures'] == ['ValueError: at least 4 GiB free before next stage'],
         'prior remains the exact rejected free-space attempt')
    need(result['attempted'] == names and [row['name'] for row in result['results']] == names,
         'exact prior19, no missing/duplicate/later work')
    need(load('plan') == Q.plan() and load('environment') == {mode: Q.environment(PRIOR, mode) for mode in ('no-default', 'all-features')},
         'exact prior plan and environments')
    for label in ('source', 'tools', 'raw', 'namespace'):
        need(load(label + '-before') == load(label + '-after'), 'prior closing ' + label + ' join')
    need(namespace == census['namespace'] == load('namespace-before'), 'same current measured PID namespace')
    raw = {str(CONTROLLER / name): CONTROLLER_PINS[name] for name in ('qualify.py', 'test_qualify.py')}
    need(load('raw-before') == raw, 'exact C2 executed controller bytes')
    rec = types.SimpleNamespace(output=PRIOR / 'commands', attempts=names, pins=census['raw_sha256'])
    need(native.fresh_census(rec, hot, namespace) == census, 'prior fresh closure replay, no historical PID probes')
    artifacts, lists = {}, {}
    for spec, stored in zip(specs, result['results'], strict=True):
        folder = ordinary(PRIOR / 'commands' / spec['name'] / 'receipt.json').parent
        receipt = Q.parse_json((folder / 'receipt.json').read_bytes())
        need(type(receipt['exit']) is int and receipt['exit'] == 0 and receipt['error'] is None
             and receipt['group_absent'] is True, 'successful closed prior owned invocation')
        need(receipt['command'] == command(spec, artifacts) and receipt['cwd'] == str(Q.SOURCE)
             and receipt['environment'] == Q.environment(PRIOR, spec['mode'])
             and type(receipt['timeout_seconds']) is int and receipt['timeout_seconds'] == spec['seconds'],
             'exact prior command, environment, source and deadline')
        detail = classify(spec, (folder / 'stdout').read_bytes(), (folder / 'stderr').read_bytes(), artifacts, lists)
        need(stored['accepted'] is True and stored['raw_sha256'] == census['raw_sha256'][spec['name']]
             and stored['detail'] == detail and load(spec['name'] + '-result') == stored, 'prior strict classifier/result/raw join')
        checkpoint = spec['name'] + '-result.json'
        pins[checkpoint] = sha(PRIOR / checkpoint)
        for stream, digest in census['raw_sha256'][spec['name']].items():
            pins['commands/' + spec['name'] + '/' + stream] = digest
    expected_top = set(PRIOR_PINS) | {name + '-result.json' for name in names} | {'commands', 'tmp', 'target-no-default', 'target-all-features'}
    need({path.name for path in PRIOR.iterdir()} == expected_top, 'exact prior evidence/cache root roster')
    for name in ('commands', 'tmp', 'target-no-default', 'target-all-features'):
        path = PRIOR / name
        need(path.is_dir() and not path.is_symlink() and path.resolve() == path, 'canonical prior owned directory')
    need(artifacts == result['artifacts'] and all(load(mode + '-elf') == artifacts[mode] for mode in artifacts), 'prior artifact record join')
    need({mode: len(names) for mode, names in lists.items()} == {'no-default': 1824, 'all-features': 1830}, 'exact D2 test rosters')
    tree = Q.parse_tree((PRIOR / 'commands/opening-tree/stdout').read_bytes())
    need(tree == load('base-tree') and Q.source_snapshot(tree) == load('source-before'), 'current exact D2 source and base-tree join')
    need(Q.tool_snapshot() == load('tools-before'), 'current complete tool closure matches D2')
    artifact_snapshot(artifacts)
    return {'immutable_files': pins, 'tree': tree, 'source': load('source-before'), 'tools': load('tools-before'),
            'artifacts': artifacts, 'lists': lists, 'prior_accepted': False, 'replayed_stages': names}


def immutable_snapshot(pins):
    observed = {name: sha(PRIOR / name) for name in pins}
    need(observed == pins, 'prior immutable evidence unchanged')
    return observed


def raw_snapshot():
    controller_snapshot()
    return {str(path): sha(path) for path in (HERE / 'continue.py', HERE / 'test_continue.py',
                                             HERE / 'README.md', *(CONTROLLER / name for name in CONTROLLER_PINS))}


def execute(output):
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3.12 -I -B')
    need(not any(output.is_relative_to(root) for root in (PRIOR, CONTROLLER, HERE, FORMAT_HISTORY, OLD_CONTROLLER)), 'new output outside immutable evidence/controllers')
    native, hot = Q.helpers()
    native.fresh_output(output)
    need(output.stat().st_dev == PRIOR.stat().st_dev, 'same filesystem for linked disk guard')
    os.umask(0o077)
    (output / 'tmp').mkdir(mode=0o700)
    rec = native.FreshRecorder(output / 'commands', Q.SOURCE, hot)
    namespace = os.readlink('/proc/self/ns/pid')
    raw_before, started = raw_snapshot(), time.monotonic()
    formatter_before = None
    fragment_before = legacy_before = None
    state, results, failures, artifacts = None, [], [], {}
    save = lambda name, value: hot.B.write_json(output / (name + '.json'), value)

    def continuity():
        need(os.readlink('/proc/self/ns/pid') == namespace and raw_snapshot() == raw_before, 'current owner/controller continuity')
        if formatter_before is not None:
            need(formatter_snapshot() == formatter_before, 'scoped formatter continuity')
        if legacy_before is not None:
            need(legacy_rejection_snapshot() == legacy_before, 'legacy formatting rejection continuity')
        if fragment_before is not None:
            need(fragment_snapshot(output) == fragment_before, 'standalone fragment continuity')
        if state is not None:
            immutable_snapshot(state['immutable_files'])
            need(Q.source_snapshot(state['tree']) == state['source'], 'current source continuity')
            need(all(Q.identity(Path(path)) == state['tools'][path] for path in Q.TOOL_PINS), 'pinned tool continuity')
            artifact_snapshot(artifacts)

    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))
    with Q.handlers(hot.B):
        try:
            save('plan', plan())
            save('raw-before', raw_before)
            save('namespace-before', namespace)
            formatter_before = formatter_snapshot()
            save('formatter-before', formatter_before)
            legacy_before = legacy_rejection_snapshot()
            save('legacy-format-rejection-before', legacy_before)
            state = prior_audit(native, hot, namespace)
            artifacts = dict(state['artifacts'])
            save('prior-before', {'immutable_files': state['immutable_files'], 'replayed_stages': state['replayed_stages'], 'prior_accepted': False})
            save('source-before', state['source'])
            save('tools-before', state['tools'])
            save('artifacts-before', artifact_snapshot(artifacts))
            fragment_before = create_fragment(output, state['tree'])
            save('fragment-before', fragment_before)
            for spec in stages():
                continuity()
                target_bytes = Q.footprint(PRIOR)
                need(Q.TOTAL_SECONDS - (time.monotonic() - started) >= spec['seconds'], 'remaining bound must cover whole next stage')
                print(json.dumps({'event': 'start', 'stage': spec['name'], 'timeout_seconds': spec['seconds']}), flush=True)
                folder = rec.run(spec['name'], command(spec, artifacts, output), spec['seconds'], env=environment(output, spec['mode']))
                detail = classify(spec, (folder / 'stdout').read_bytes(), (folder / 'stderr').read_bytes(), artifacts, state['lists'])
                continuity()
                row = {'name': spec['name'], 'accepted': True, 'raw_sha256': rec.pins[spec['name']],
                       'detail': detail, 'target_logical_bytes_before': target_bytes}
                save(spec['name'] + '-result', row)
                results.append(row)
        except BaseException as error:
            failures.append(type(error).__name__ + ': ' + str(error))
        finally:
            closing = {}
            for name, observe in (
                ('source-after', lambda: Q.source_snapshot(state['tree']) if state is not None else None),
                ('tools-after', Q.tool_snapshot), ('raw-after', raw_snapshot),
                ('formatter-after', formatter_snapshot),
                ('legacy-format-rejection-after', legacy_rejection_snapshot),
                ('fragment-after', lambda: fragment_snapshot(output) if fragment_before is not None else None),
                ('namespace-after', lambda: os.readlink('/proc/self/ns/pid')),
                ('artifacts-after', lambda: artifact_snapshot(artifacts)),
                ('prior-after', lambda: prior_audit(native, hot, namespace)),
                ('fresh-census', lambda: native.fresh_census(rec, hot, namespace)),
            ):
                try:
                    closing[name] = observe()
                    value = closing[name]
                    if name == 'prior-after':
                        value = {key: value[key] for key in ('immutable_files', 'replayed_stages', 'prior_accepted')}
                    save(name, value)
                except BaseException as error:
                    failures.append(name + ': ' + type(error).__name__ + ': ' + str(error))
            try:
                continuity()
                need(state is not None and closing.get('source-after') == state['source']
                     and closing.get('tools-after') == state['tools'], 'complete current source/tool closing join')
                need(closing.get('raw-after') == raw_before and closing.get('namespace-after') == namespace, 'complete controller/namespace closing join')
                need(formatter_before is not None and closing.get('formatter-after') == formatter_before, 'complete formatter closing join')
                need(legacy_before is not None and closing.get('legacy-format-rejection-after') == legacy_before,
                     'complete preserved legacy rejection closing join')
                need(fragment_before is not None and closing.get('fragment-after') == fragment_before, 'complete standalone fragment closing join')
                need(closing.get('prior-after') == state and 'fresh-census' in closing
                     and closing.get('artifacts-after') == artifact_snapshot(artifacts), 'complete prior/ELF/new-owner closure joins')
            except BaseException as error:
                failures.append('closing continuity: ' + str(error))
            accepted = not failures and [row['name'] for row in results] == [spec['name'] for spec in stages()]
            save('result', {'schema': 'fe2o3.retained-host-diagnostic-linked-cpu.v2', 'accepted': accepted,
                 'scope': SCOPE, 'failures': failures, 'results': results, 'attempted': rec.attempts,
                 'prior_root': str(PRIOR), 'prior_result_sha256': PRIOR_PINS['result.json'], 'prior_accepted': False,
                 'prior_reclassified': False, 'replayed_prior_stage_count': 19 if state is not None else 0,
                 'artifacts': artifacts, 'retained_test_elfs_built_in_prior_attempt': True, 'test_elfs_rebuilt_here': False,
                 'new_example_elf_names': sorted(name for name in artifacts if name.startswith('kfd-')),
                 'source_commit': Q.BASE, 'full_all_features_suite_required': True, 'no_default_full_suite_run': False,
                 'single_continuous_owner_or_deadline_claim': False, 'proof_acceptance': False,
                 'format_scope': 'seven full Rust paths plus exact added diagnostic-test fragment',
                 'full_legacy_test_file_format_accepted': False, 'legacy_format_rejection_reclassified': False,
                 'legacy_format_result_sha256': FORMAT_HISTORY_PINS[FORMAT_HISTORY / 'result.json'],
                 'solver_invocations': 0, 'gpu_invocations': 0, 'cleanup_performed': False,
                 'next': 'parent review; preserve rejected packets and this linked qualification; no automatic retry'})
    return 0 if accepted else 1


def plan():
    return {'scope': SCOPE, 'source': str(Q.SOURCE), 'base': Q.BASE, 'prior_root': str(PRIOR),
            'prior_pins': PRIOR_PINS, 'controller_pins': CONTROLLER_PINS, 'replay_prior_stages': 19,
            'stages': stages(), 'total_seconds_for_this_new_owner': Q.TOTAL_SECONDS,
            'formatter_sha256': FORMATTER_SHA,
            'format_scope': 'seven full Rust paths plus exact added diagnostic-test fragment',
            'fragment_sha256': FRAGMENT_SHA, 'base_test_blob': BASE_TEST_BLOB, 'base_test_sha256': BASE_TEST_SHA,
            'full_file_legacy_formatting_debt_unchanged': True,
            'cargo_jobs': 2, 'test_threads': 2, 'min_free_bytes': Q.MIN_FREE_BYTES,
            'max_reused_target_bytes': Q.MAX_TARGET_BYTES, 'per_process_address_space_bytes': 8 * 1024**3,
            'per_file_bytes': 1024**3, 'core_bytes': 0, 'target_cache_writes_only_in_prior': True,
            'prior_raw_and_metadata_read_only': True, 'prior_rejection_unchanged': True,
            'disk_guard_between_stages_not_quota': True, 'solver_invocations': 0, 'gpu_invocations': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'use python3.12 -I -B')
    if args.execute:
        need(args.output is not None, 'explicit fresh continuation output')
        raise SystemExit(execute(args.output))
    need(args.output is None, 'output only with explicit execute')
    print(json.dumps(plan(), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
