# D2 Linked CPU Qualification Revision 2

Preparation only. No formatter, compiler, test executable or GPU is launched by
printing the plan or running the synthetic controls. An explicit parent handoff
is required before `--execute`.

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930-revision-2/continue.py
```

Proposed fresh output after review and handoff:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930-revision-2/continue.py --execute --output /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-2
```

## Exact Link

Both rejected attempts remain rejected. D2 attempt-2 stopped before its twentieth
stage because free space was below 4 GiB, after all nineteen launched stages had
succeeded and closed. This controller pins that exact false result, census,
opening/closing observations, artifact records, plan and original C2 controller.
It replays the nineteen raw streams using C2's strict classifiers, exact commands,
environments, deadlines, checkpoint results and receipt hashes. It independently
measures the current 6,477-file source closure, complete C2 tool profile, original
two ELF hashes and PID namespace. Historical group closure is replayed from the
original owner's receipts, never inferred by probing or signaling old PIDs.

The new qualification is a separately owned, explicitly linked packet. It does
not reclassify D2 attempt-2, resume an old process handle or claim an uninterrupted
measurement interval. Initial and closing joins must both match. Original raw
files and metadata are read-only. Only the two already-owned Cargo target caches
may receive build-cache writes, and both original test ELF identities must stay
unchanged. New temporary files, command receipts and results live in the fresh
continuation output. No old result, census or checkpoint is rewritten.

## Formatting Scope

Continuation-1 remains rejected. Its exact full-file formatting check found 31
hunks in inherited portions of `sdma/retained_pair/tests.rs`; it launched none of
the five remaining CPU stages. This successor pins that false result, receipt,
raw diff, census and old controller. It never accepts the old diff as success or
claims that the whole test file is formatted. Pre-existing formatting debt in
that file is explicitly outside this changed-code formatting scope.

The exact new diagnostic test occupies lines 113-163 including its inter-item
separator. Extraction requires its unique full attribute/function boundary,
unique following-test boundary, exact 1,822-byte insertion SHA-256, and matching
candidate source pin. Removing it must reconstruct both the authenticated
`100644` Git blob `e4d1bcddcfa626b3bfb584db972b348d000004bb` from the pinned prior
base-tree receipt and SHA-256
`51c8f719a9daebf022e8628e3099f234bc768482cf59617e285e83907667b0bd`.
This authenticates all unchanged prefix/suffix bytes without querying another
worktree or copying a historical source file. No source bytes are modified.

Only after those checks, the fresh output receives the exact attribute/function
fragment with one canonical final newline, without the extra inter-item blank
line: 1,821 bytes, SHA-256
`614a600c667ba95c0082b36fd20ca38b7e25614b7426a59a01ee939d02544d9c`.
Its canonical ordinary single-link path, length and hash are checked before and
after every command and independently at closing. Creating over an existing file,
malformed extraction, changed old prefix/suffix, aliases and fragment drift fail.

## Seven Commands

1. Pinned nightly `rustfmt --check --edition 2024 --config skip_children=true` on
   the other seven changed/new Rust paths. No source edits or `cargo fmt`.
2. The same strict formatter on the exact fresh standalone diagnostic-test fragment.
3. The one remaining all-features ordinary/profiled wait semantic test.
4. Original all-features strict all-target Clippy command.
5. Original ordinary and diagnostic example build command, requiring fresh Cargo
   artifacts from the retained targets. Neither example is executed.
6. Original full 1,830-test all-features KFD library suite, two threads, 3,600s.
7. Original closing HEAD observation with replacement objects disabled.

The five original commands and their timeouts are unchanged. Both formatting
commands have a 90-second deadline and a separately pinned formatter identity.
Each requires exit zero and empty stdout/stderr. Any formatting difference or
malformed successful output rejects this packet
before later work. Every expected test must pass; ignored tests, failures and
arbitrary non-JSON output reject. The inherited three exact abort-child header
witnesses use bounded compatible assignments, not claimed child identities.

## Bounds and Closure

Two Cargo jobs and two test threads; offline/frozen builds; 8 GiB per-process
address space, 1 GiB per-file and zero core dumps. Before every command, at least
4 GiB must remain free and the sum of both reused target trees must be at most
4 GiB. This remains an inter-stage observation, not a filesystem quota. The new
owner has a 10,800-second work-admission budget; it is not presented as the old
owner's uninterrupted deadline. Source, pinned tools, formatter, prior immutable
evidence and retained ELFs are checked between stages.

The first error stops later work. Closing source, full tools, formatter, fragment,
preserved full-file format rejection, raw controller bytes, namespace, retained
ELF inventory, full prior replay and fresh
new-owner receipt census are independent. Signal handlers restore even if saving
a closing record or final result fails. All failed packets and new artifacts
remain for review. No automatic retry, target cleanup, source changes, proof guard
refresh, signing, native launch or integration is performed.

Four broad proof-source guards must still reject the unchanged D2 source. The
same trusted host/Python/Cargo-cache/system-loader limitations as C2 apply.
No formal, GPU, performance or parity acceptance follows from this CPU packet.

Light controls:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930-revision-2/test_continue.py
```
