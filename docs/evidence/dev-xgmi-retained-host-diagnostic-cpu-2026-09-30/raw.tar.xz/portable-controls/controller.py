#!/usr/bin/env python3
"""Bounded synthetic helper qualification, including a Git-free relocation."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import stat

SOURCE = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-portable-20260930')
OUTPUT = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-portable-controls-20260930-final')
CPU = Path('/home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-2/source-after.json')
DOC = 'docs/runtime-xgmi-retained-host-diagnostic-v1.md'
BENCH = 'benchmarks/runtime_gfx942/'
FAMILIES = ('campaign', 'native', 'transport')
ADDED = tuple(BENCH + prefix + 'xgmi_retained_host_diagnostic_' + family + '.py'
              for family in FAMILIES for prefix in ('', 'test_'))
NATIVE_SHA = 'fef3e00f9310ee1895dff2dac133826c66a8432a600d5be6065b4249f3ebc3f4'


def sha(path):
    assert path.is_file() and not path.is_symlink()
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (OUTPUT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def snapshot():
    assert sha(CPU) == '73ef7e432dea941606caa96ab815a91b326dca33dc0a2126a402dba1989af4f7'
    expected = json.loads(CPU.read_bytes())
    actual = {}
    for name in sorted(set(expected) | set(ADDED)):
        path = SOURCE / name
        assert path.resolve(strict=True) == path and stat.S_ISREG(path.stat().st_mode)
        actual[name] = {'sha256': sha(path), 'mode': '100755' if path.stat().st_mode & 0o111 else '100644'}
        if name in expected and name != DOC:
            assert actual[name] == expected[name], name
    return actual


def main():
    os.umask(0o077)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (16 * 1024**2, 16 * 1024**2))
    OUTPUT.mkdir(mode=0o700)
    before = snapshot()
    save('source-before.json', before)
    save('controller.json', {'path': str(Path(__file__).resolve()), 'sha256': sha(Path(__file__).resolve())})
    path = SOURCE / (BENCH + 'xgmi_peer_series_native.py')
    assert sha(path) == NATIVE_SHA
    spec = importlib.util.spec_from_file_location('native_portable_qualification', path)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    hot, _, _ = native.load_helpers()
    namespace = os.readlink('/proc/self/ns/pid')
    projection = OUTPUT / 'relocated'
    projection.mkdir()
    projection_files = sorted({name for name in before if name.startswith(BENCH) and name.endswith('.py')}
        | {'docs/evidence/dev-xgmi-peer-hot-mi300x-2026-09-19/native.py',
           'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/native.py'})
    for name in projection_files:
        target = projection / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / name, target)
        assert sha(target) == before[name]['sha256']
    assert not (projection / '.git').exists()
    for name in ADDED:
        assert b'/home/harsh/.codex-tmp/' not in (projection / name).read_bytes()
    save('projection.json', {name: before[name] for name in projection_files})
    rec = native.FreshRecorder(OUTPUT / 'commands', SOURCE, hot)
    environment = {'PATH': '', 'HOME': str(OUTPUT), 'LANG': 'C', 'LC_ALL': 'C',
                   'TMPDIR': str(OUTPUT / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1'}
    (OUTPUT / 'tmp').mkdir()
    records = []
    failure = None
    try:
        for label, root in (('source', SOURCE), ('relocated', projection)):
            for family, count in zip(FAMILIES, (7, 9, 10), strict=True):
                name = label + '-' + family
                command = ['/usr/bin/python3.12', '-I', '-B',
                           str(root / (BENCH + 'test_xgmi_retained_host_diagnostic_' + family + '.py'))]
                folder = rec.run(name, command, 60, env=environment)
                assert (folder / 'stdout').read_bytes() == b''
                text = (folder / 'stderr').read_text('ascii')
                assert re.search(r'\nRan ' + str(count) + r' tests in [0-9.]+s\n\nOK\n\Z', text)
                assert len(re.findall(r' \.\.\. ok\n', text)) == count
                records.append({'name': name, 'tests': count, 'receipt_sha256': sha(folder / 'receipt.json')})
                assert snapshot() == before
    except BaseException as error:
        failure = repr(error)
    finally:
        after = snapshot()
        save('source-after.json', after)
        census = native.fresh_census(rec, hot, namespace)
        save('fresh-census.json', census)
        assert after == before
        assert all(sha(projection / name) == before[name]['sha256'] for name in projection_files)
        save('result.json', {'accepted': failure is None and len(records) == 6, 'failure': failure,
             'scope': 'synthetic helper controls only; no native launch, benchmark, solver, or parity acceptance',
             'source_root': str(SOURCE), 'projection_root': str(projection),
             'projection_has_git': False, 'empty_path': True, 'records': records,
             'source_sha256': sha(OUTPUT / 'source-before.json'),
             'census_sha256': sha(OUTPUT / 'fresh-census.json')})
    assert failure is None, failure
    print(json.dumps({'accepted': True, 'tests': 52, 'stages': 6, 'result_sha256': sha(OUTPUT / 'result.json')}))


if __name__ == '__main__':
    main()
