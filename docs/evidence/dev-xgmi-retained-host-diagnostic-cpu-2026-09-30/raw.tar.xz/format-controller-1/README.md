# D2 Linked CPU Qualification Draft

Preparation only. No formatter, compiler, test executable or GPU is launched by
printing the plan or running the synthetic controls. An explicit parent handoff
is required before `--execute`.

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930/continue.py
```

Proposed fresh output after review and handoff:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930/continue.py --execute --output /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-1
```

## Exact Link

Both rejected attempts remain rejected. D2 attempt-2 stopped before its twentieth
stage because free space was below 4 GiB, after all nineteen launched stages had
succeeded and closed. This controller pins that exact false result, census,
opening/closing observations, artifact records, plan and original C2 controller.
It replays the nineteen raw streams using C2's strict classifiers, exact commands,
environments, deadlines, checkpoint results and receipt hashes. It independently
measures the current 6,477-file source closure, complete C2 tool profile, original
two ELF hashes and PID namespace. Historical group closure is replayed from the
original owner's receipts, never inferred by probing or signaling old PIDs.

The new qualification is a separately owned, explicitly linked packet. It does
not reclassify D2 attempt-2, resume an old process handle or claim an uninterrupted
measurement interval. Initial and closing joins must both match. Original raw
files and metadata are read-only. Only the two already-owned Cargo target caches
may receive build-cache writes, and both original test ELF identities must stay
unchanged. New temporary files, command receipts and results live in the fresh
continuation output. No old result, census or checkpoint is rewritten.

## Six Commands

1. Pinned nightly `rustfmt --check --edition 2024 --config skip_children=true` on
   exactly the eight changed/new Rust paths. No source edits or `cargo fmt`.
2. The one remaining all-features ordinary/profiled wait semantic test.
3. Original all-features strict all-target Clippy command.
4. Original ordinary and diagnostic example build command, requiring fresh Cargo
   artifacts from the retained targets. Neither example is executed.
5. Original full 1,830-test all-features KFD library suite, two threads, 3,600s.
6. Original closing HEAD observation with replacement objects disabled.

The five original commands and their timeouts are unchanged. The formatting
control has a 90-second deadline and a separately pinned formatter identity.
Any formatting difference or malformed successful output rejects this packet
before later work. Every expected test must pass; ignored tests, failures and
arbitrary non-JSON output reject. The inherited three exact abort-child header
witnesses use bounded compatible assignments, not claimed child identities.

## Bounds and Closure

Two Cargo jobs and two test threads; offline/frozen builds; 8 GiB per-process
address space, 1 GiB per-file and zero core dumps. Before every command, at least
4 GiB must remain free and the sum of both reused target trees must be at most
4 GiB. This remains an inter-stage observation, not a filesystem quota. The new
owner has a 10,800-second work-admission budget; it is not presented as the old
owner's uninterrupted deadline. Source, pinned tools, formatter, prior immutable
evidence and retained ELFs are checked between stages.

The first error stops later work. Closing source, full tools, formatter, raw
controller bytes, namespace, retained ELF inventory, full prior replay and fresh
new-owner receipt census are independent. Signal handlers restore even if saving
a closing record or final result fails. All failed packets and new artifacts
remain for review. No automatic retry, target cleanup, source changes, proof guard
refresh, signing, native launch or integration is performed.

Four broad proof-source guards must still reject the unchanged D2 source. The
same trusted host/Python/Cargo-cache/system-loader limitations as C2 apply.
No formal, GPU, performance or parity acceptance follows from this CPU packet.

Light controls:

```sh
/usr/bin/python3.12 -I -B /home/harsh/.codex-tmp/fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930/test_continue.py
```
