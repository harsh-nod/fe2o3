#!/usr/bin/env python3
"""Light synthetic controls and read-only prior replay; no executable under test."""

import copy
import importlib.util
import json
import os
from pathlib import Path
import signal
import tempfile
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('retained_cpu_continuation', HERE / 'continue.py')
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)
Q = C.Q


def encoded(rows):
    return b''.join(row if isinstance(row, bytes) else (json.dumps(row) + '\n').encode('ascii') for row in rows)


def suite(names):
    rows = [{'type': 'suite', 'event': 'started', 'test_count': len(names)}]
    for name in names:
        rows.append({'type': 'test', 'event': 'started', 'name': name})
        if name in Q.ABORT_PARENTS:
            rows.append(b'\nrunning 1 test\n')
        rows.append({'type': 'test', 'event': 'ok', 'name': name})
    rows.append({'type': 'suite', 'event': 'ok', 'passed': len(names), 'failed': 0, 'ignored': 0,
                 'measured': 0, 'filtered_out': 0})
    return rows


class PlanTests(unittest.TestCase):
    def test_only_scoped_formatter_and_five_unattempted_original_commands(self):
        specs = C.stages()
        self.assertEqual(len(specs), 6)
        self.assertEqual(specs[1:], Q.stages()[19:])
        self.assertEqual(tuple(row['name'] for row in specs[1:]), C.REMAINING)
        formatter = specs[0]
        self.assertEqual(formatter['argv'][:6], [str(Q.TC / 'bin/rustfmt'), '--check', '--edition', '2024', '--config', 'skip_children=true'])
        self.assertEqual(formatter['argv'][6:], sorted(name for name in Q.PINS if name.endswith('.rs')))
        self.assertEqual(len(formatter['argv'][6:]), 8)
        self.assertEqual(formatter['seconds'], 90)
        self.assertEqual(next(row for row in specs if row['kind'] == 'full')['seconds'], 3600)
        self.assertFalse(any('ssh' in row['argv'] or '--ignored' in row['argv'] for row in specs))
        self.assertEqual(Q.MIN_FREE_BYTES, 4 * 1024**3)
        self.assertEqual(Q.MAX_TARGET_BYTES, 4 * 1024**3)

    def test_target_reuse_changes_only_tmpdir_from_original_environment(self):
        output = Path('/synthetic/new-continuation')
        for mode in ('no-default', 'all-features'):
            expected = Q.environment(C.PRIOR, mode)
            expected['TMPDIR'] = str(output / 'tmp')
            self.assertEqual(C.environment(output, mode), expected)
            self.assertEqual(expected['CARGO_TARGET_DIR'], str(C.PRIOR / ('target-' + mode)))
            self.assertEqual(expected['CARGO_BUILD_JOBS'], '2')
            self.assertEqual(expected['RUST_TEST_THREADS'], '2')

    def test_formatter_is_measured_but_not_launched(self):
        self.assertEqual(C.formatter_snapshot()['sha256'], C.FORMATTER_SHA)
        with patch.object(Q, 'identity', return_value={'sha256': '0' * 64}):
            with self.assertRaisesRegex(ValueError, 'pinned scoped formatter'):
                C.formatter_snapshot()

    def test_output_cannot_be_created_inside_prior_or_controllers(self):
        for root in (C.PRIOR, C.CONTROLLER, C.HERE):
            with patch.object(Q, 'helpers') as helpers:
                with self.assertRaisesRegex(ValueError, 'outside immutable'):
                    C.execute(root / 'must-not-be-created')
                helpers.assert_not_called()


class PriorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.native, cls.hot = Q.helpers()
        cls.namespace = os.readlink('/proc/self/ns/pid')

    def replay(self):
        return C.prior_audit(self.native, self.hot, self.namespace)

    def parsed_mutation(self, predicate, change):
        original = Q.parse_json
        def altered(raw):
            value = original(raw)
            if predicate(value):
                value = copy.deepcopy(value)
                change(value)
            return value
        return patch.object(Q, 'parse_json', side_effect=altered)

    def test_real_prior19_replays_read_only_and_remains_rejected(self):
        before = {name: C.sha(C.PRIOR / name) for name in C.PRIOR_PINS}
        state = self.replay()
        self.assertIs(state['prior_accepted'], False)
        self.assertEqual(len(state['replayed_stages']), 19)
        self.assertEqual(len(state['source']), 6477)
        self.assertEqual({mode: len(names) for mode, names in state['lists'].items()}, {'no-default': 1824, 'all-features': 1830})
        self.assertEqual(before, {name: C.sha(C.PRIOR / name) for name in C.PRIOR_PINS})
        self.assertEqual(C.immutable_snapshot(state['immutable_files']), state['immutable_files'])

    def test_changed_metadata_hash_and_already_accepted_or_different_rejection_refuse(self):
        with patch.dict(C.PRIOR_PINS, {'result.json': '0' * 64}):
            with self.assertRaisesRegex(ValueError, 'pinned rejected D2 metadata'):
                self.replay()
        predicate = lambda value: isinstance(value, dict) and 'fresh_elf_qualification_only' in value
        for change in (lambda row: row.update(accepted=True), lambda row: row.update(failures=[]),
                       lambda row: row.update(failures=['another failure'])):
            with self.parsed_mutation(predicate, change), self.assertRaisesRegex(ValueError, 'exact rejected free-space'):
                self.replay()

    def test_missing_extra_duplicate_prior_stage_or_mismatched_checkpoint_refuse(self):
        predicate = lambda value: isinstance(value, dict) and 'fresh_elf_qualification_only' in value
        for change in (lambda row: row['attempted'].pop(), lambda row: row['attempted'].append('all-features-full-lib'),
                       lambda row: row['attempted'].__setitem__(1, row['attempted'][0])):
            with self.parsed_mutation(predicate, change), self.assertRaisesRegex(ValueError, 'exact prior19'):
                self.replay()
        predicate = lambda value: isinstance(value, dict) and value.get('name') == 'opening-head' and 'target_logical_bytes_before' in value
        with self.parsed_mutation(predicate, lambda row: row.update(accepted=False)), self.assertRaisesRegex(ValueError, 'classifier/result/raw'):
            self.replay()

    def test_prior_command_environment_cwd_timeout_status_and_error_are_exact(self):
        predicate = lambda value: isinstance(value, dict) and value.get('command', [])[-2:] == ['rev-parse', 'HEAD'] and 'pid' in value
        for key, value in (('command', ['/bin/true']), ('environment', {}), ('cwd', '/other'),
                           ('timeout_seconds', 31), ('timeout_seconds', True), ('exit', 1),
                           ('exit', False), ('error', 'failed'), ('group_absent', False)):
            with self.subTest(key=key, value=value), self.parsed_mutation(predicate, lambda row, k=key, v=value: row.update({k: v})):
                with self.assertRaises(ValueError):
                    self.replay()

    def test_current_namespace_source_tools_and_raw_receipt_joins_refuse_substitution(self):
        with self.assertRaisesRegex(ValueError, 'current measured PID namespace'):
            C.prior_audit(self.native, self.hot, 'pid:[not-this-namespace]')
        with patch.object(Q, 'source_snapshot', return_value={'substituted': True}):
            with self.assertRaisesRegex(ValueError, 'current exact D2 source'):
                self.replay()
        with patch.object(Q, 'tool_snapshot', return_value={'substituted': True}):
            with self.assertRaisesRegex(ValueError, 'complete tool closure'):
                self.replay()
        with patch.object(self.native, 'fresh_census', return_value={'substituted': True}):
            with self.assertRaisesRegex(ValueError, 'prior fresh closure replay'):
                self.replay()

    def test_retained_elf_alias_bytes_mode_and_size_are_checked(self):
        with tempfile.TemporaryDirectory() as directory:
            prior = Path(directory)
            target = prior / 'target-all-features'
            target.mkdir()
            path = target / 'test-elf'
            path.write_bytes(b'\x7fELFsynthetic')
            path.chmod(0o700)
            artifact = {'path': str(path), 'size': path.stat().st_size, 'sha256': C.sha(path)}
            with patch.object(C, 'PRIOR', prior):
                self.assertIn('all-features', C.artifact_snapshot({'all-features': artifact}))
                for update in ({'size': artifact['size'] + 1}, {'sha256': '0' * 64}):
                    with self.assertRaises(ValueError):
                        C.artifact_snapshot({'all-features': dict(artifact, **update)})
                alias = target / 'alias'
                alias.symlink_to(path)
                with self.assertRaises(ValueError):
                    C.artifact_snapshot({'all-features': dict(artifact, path=str(alias))})
                path.chmod(0o600)
                with self.assertRaises(ValueError):
                    C.artifact_snapshot({'all-features': artifact})


class ClassifierTests(unittest.TestCase):
    def test_noncanonical_formatter_and_malformed_cargo_output_refuse(self):
        spec = C.stages()[0]
        self.assertEqual(C.classify(spec, b'', b'', {}, {}), {})
        for raw, stderr in ((b'Diff in source\n', b''), (b'', b'warning\n')):
            with self.assertRaises(ValueError):
                C.classify(spec, raw, stderr, {}, {})
        clippy = next(row for row in C.stages() if row['kind'] == 'cargo')
        with self.assertRaises(ValueError):
            C.classify(clippy, b'not JSON\n', b'', {}, {})

    def test_full_suite_keeps_zero_ignored_failure_rejection_and_three_header_rule(self):
        spec = next(row for row in C.stages() if row['kind'] == 'full')
        names = sorted(Q.FOCUS | Q.ABORT_PARENTS | {'ordinary::non_focus'})
        rows = suite(names)
        lists = {'all-features': names}
        result = C.classify(spec, encoded(rows), b'', {}, lists)
        self.assertEqual(result['passed'], len(names))
        self.assertEqual(len(result['abort_child_headers']['witnesses']), 3)
        for event in ('ignored', 'failed'):
            changed = copy.deepcopy(rows)
            for row in changed:
                if isinstance(row, dict) and row.get('name') == 'ordinary::non_focus' and row.get('event') == 'ok':
                    row['event'] = event
            changed[-1].update(passed=len(names)-1, ignored=int(event == 'ignored'), failed=int(event == 'failed'))
            with self.assertRaises(ValueError):
                C.classify(spec, encoded(changed), b'', {}, lists)
        with self.assertRaises(ValueError):
            C.classify(spec, encoded([row for row in rows if not isinstance(row, bytes)]), b'', {}, lists)


class LifecycleTests(unittest.TestCase):
    def run_fake(self, directory, *, fail_format=False, low_space=False, fail_prior=False, save_failure=False):
        output = Path(directory) / 'new-output'
        attempts, saves, closes, gates = [], [], [], []
        managed = (signal.SIGHUP, signal.SIGTERM)
        previous = {sig: signal.getsignal(sig) for sig in managed}
        owner = types.SimpleNamespace(MANAGED=managed, interrupted=lambda *_: None)
        def write(path, value):
            saves.append(path.stem)
            if save_failure and path.stem in ('source-after', 'result'):
                raise OSError('synthetic disk failure')
            path.write_text(json.dumps(value))
        owner.write_json = write
        hot = types.SimpleNamespace(B=owner)
        class Recorder:
            def __init__(self, folder, _source, _hot):
                self.output, self.attempts, self.pins = folder, attempts, {}
                folder.mkdir()
            def run(self, name, argv, seconds, **kwargs):
                attempts.append(name)
                self.pins[name] = {'synthetic': name}
                self_folder = self.output / name
                self_folder.mkdir()
                (self_folder / 'stdout').write_bytes(b'Diff in frozen source\n' if fail_format else b'')
                (self_folder / 'stderr').write_bytes(b'')
                return self_folder
        def census(*_args):
            closes.append('fresh-census')
            return {'synthetic': 'fresh-census'}
        native = types.SimpleNamespace(FreshRecorder=Recorder, fresh_output=lambda path: path.mkdir(mode=0o700), fresh_census=census)
        state = {'immutable_files': {}, 'tree': {}, 'source': {'source': 'synthetic'}, 'tools': {},
                 'artifacts': {'all-features': {'path': '/not/executed'}}, 'lists': {'all-features': []},
                 'prior_accepted': False, 'replayed_stages': [row['name'] for row in Q.stages()[:19]]}
        def prior(*_args):
            closes.append('prior-replay')
            if fail_prior:
                raise ValueError('synthetic changed prior evidence')
            return copy.deepcopy(state)
        def footprint(path):
            gates.append(path)
            if low_space:
                raise ValueError('at least 4 GiB free before next stage')
            return 0
        actual_classify = C.classify
        def classify(spec, raw, stderr, artifacts, lists):
            return actual_classify(spec, raw, stderr, artifacts, lists) if spec['kind'] == 'format' else {'synthetic': spec['name']}
        with patch.object(Q, 'helpers', return_value=(native, hot)), patch.object(C, 'prior_audit', side_effect=prior), \
             patch.object(C, 'raw_snapshot', return_value={'raw': 'synthetic'}), patch.object(C, 'formatter_snapshot', return_value={'format': 'synthetic'}), \
             patch.object(C, 'immutable_snapshot', return_value={}), patch.object(C, 'artifact_snapshot', return_value={}), \
             patch.object(Q, 'source_snapshot', return_value=state['source']), patch.object(Q, 'tool_snapshot', return_value={}), \
             patch.object(Q, 'TOOL_PINS', {}), patch.object(Q, 'footprint', side_effect=footprint), patch.object(C, 'classify', side_effect=classify), \
             patch.object(C.resource, 'setrlimit'), patch.object(C.os, 'umask'):
            if save_failure:
                with self.assertRaisesRegex(OSError, 'synthetic disk failure'):
                    C.execute(output)
            else:
                expected = int(fail_format or low_space or fail_prior)
                self.assertEqual(C.execute(output), expected)
                result = json.loads((output / 'result.json').read_text())
                self.assertIs(result['prior_accepted'], False)
                self.assertIs(result['prior_reclassified'], False)
                self.assertIs(result['single_continuous_owner_or_deadline_claim'], False)
        self.assertEqual({sig: signal.getsignal(sig) for sig in managed}, previous)
        self.assertTrue({'source-after', 'tools-after', 'formatter-after', 'raw-after', 'namespace-after', 'artifacts-after', 'fresh-census', 'result'} <= set(saves))
        self.assertEqual(closes.count('prior-replay'), 2)
        self.assertEqual(closes.count('fresh-census'), 1)
        if fail_prior or low_space:
            self.assertEqual(attempts, [])
        elif fail_format:
            self.assertEqual(attempts, ['changed-rust-format-check'])
        else:
            self.assertEqual(attempts, [row['name'] for row in C.stages()])
        self.assertTrue(all(path == C.PRIOR for path in gates))

    def test_success_runs_only_six_new_commands_and_keeps_prior_false(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(directory)

    def test_formatter_rejection_stops_five_remaining_stages_and_closes(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(directory, fail_format=True)

    def test_unchanged_free_space_guard_refuses_before_any_new_command(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(directory, low_space=True)

    def test_bad_prior_blocks_all_new_work_and_still_attempts_closing_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(directory, fail_prior=True)

    def test_save_failure_does_not_skip_closing_observations_or_handler_restore(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_fake(directory, fail_format=True, save_failure=True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
