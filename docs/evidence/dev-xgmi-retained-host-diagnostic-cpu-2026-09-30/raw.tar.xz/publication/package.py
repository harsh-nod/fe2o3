#!/usr/bin/env python3
"""Package immutable CPU records without rerunning historical controllers."""

import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

BASE = Path('/home/harsh/.codex-tmp')
OUTPUT = BASE / 'fe2o3-xgmi-retained-host-diagnostic-publication-20260930'
SOURCES = {
    'rejected-cpu-1': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-attempt-1',
    'rejected-cpu-2': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-attempt-2',
    'rejected-format-1': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-1',
    'linked-cpu': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-2',
    'cpu-controller-1': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-controller-20260930',
    'cpu-controller-2': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-controller-20260930-revision-2',
    'format-controller-1': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930',
    'linked-controller': BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-continuation-controller-20260930-revision-2',
    'portable-controls': BASE / 'fe2o3-xgmi-retained-host-diagnostic-portable-controls-20260930-final',
}
RESULT_PINS = {
    'rejected-cpu-2': 'dfb50491fefc4ddbf982c23d6e8c2238c8996b86934607000294a86ce235e302',
    'rejected-format-1': '0ec4eaaec20a5d91e4e43b3a5ede17114391e71199dc2d5f18686cc4ea40434e',
    'linked-cpu': 'a8622e3ed86c18d3bd25db2c85571ab49cd52b30c730aacdadc690874855a747',
    'portable-controls': '9bcfe0b9231787cfb45bd7285c04e973c02c59c620cf8a50c9d81e74fbc1e921',
}
SOURCE_PIN = '73ef7e432dea941606caa96ab815a91b326dca33dc0a2126a402dba1989af4f7'


def sha(path):
    assert path.is_file() and not path.is_symlink() and stat.S_ISREG(path.stat().st_mode)
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    with (OUTPUT / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def main():
    os.umask(0o077)
    OUTPUT.mkdir(mode=0o700)
    for label, digest in RESULT_PINS.items():
        assert sha(SOURCES[label] / 'result.json') == digest
    linked = json.loads((SOURCES['linked-cpu'] / 'result.json').read_bytes())
    prior = json.loads((SOURCES['rejected-cpu-2'] / 'result.json').read_bytes())
    assert linked['accepted'] is True and linked['failures'] == []
    assert linked['prior_accepted'] is linked['prior_reclassified'] is False
    assert linked['replayed_prior_stage_count'] == len(prior['attempted']) == 19
    assert len(linked['attempted']) == 7
    assert len(linked['results']) == 7 and all(row['accepted'] is True for row in linked['results'])
    assert linked['prior_result_sha256'] == RESULT_PINS['rejected-cpu-2']
    assert prior['accepted'] is False
    assert all(sha(SOURCES[label] / ('source-' + edge + '.json')) == SOURCE_PIN
               for label in ('rejected-cpu-2', 'linked-cpu') for edge in ('before', 'after'))
    full = next(row for row in linked['results'] if row['name'] == 'all-features-full-lib')['detail']
    assert full['passed'] == 1830 and full['ignored'] == full['filtered_out'] == 0
    assert len(full['terminal_tests']) == 1830 and set(full['terminal_tests'].values()) == {'ok'}
    for row in linked['artifacts'].values():
        path = Path(row['path'])
        assert path.stat().st_size == row['size'] and sha(path) == row['sha256']
    for label in ('rejected-cpu-1', 'rejected-cpu-2', 'rejected-format-1'):
        assert json.loads((SOURCES[label] / 'result.json').read_bytes())['accepted'] is False
    paths = {}
    for label, root in SOURCES.items():
        for current, directories, files in os.walk(root):
            directories[:] = sorted(name for name in directories
                if name not in ('target-all-features', 'target-no-default', 'tmp', '__pycache__'))
            for name in sorted(files):
                path = Path(current) / name
                assert path.resolve(strict=True) == path and not path.is_symlink()
                archive_name = label + '/' + path.relative_to(root).as_posix()
                assert archive_name not in paths
                paths[archive_name] = path
    paths['publication/package.py'] = Path(__file__).resolve()
    paths['portable-controls/controller.py'] = BASE / 'fe2o3-xgmi-retained-host-diagnostic-portable-qualification-20260930.py'
    inventory = {name: {'sha256': sha(path), 'size': path.stat().st_size, 'source': str(path)}
                 for name, path in sorted(paths.items())}
    assert sum(row['size'] for row in inventory.values()) < 48 * 1024**2
    for path in paths.values():
        with path.open('rb') as stream:
            assert stream.read(4) != b'\x7fELF'
    archive = OUTPUT / 'raw.tar.xz'
    with tarfile.open(archive, 'x:xz', preset=6) as target:
        for name, row in inventory.items():
            data = paths[name].read_bytes()
            assert hashlib.sha256(data).hexdigest() == row['sha256']
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            member.mtime = 0
            target.addfile(member, io.BytesIO(data))
    with tarfile.open(archive, 'r:xz') as target:
        members = target.getmembers()
        assert [member.name for member in members] == list(inventory)
        for member in members:
            assert member.isfile() and member.size == inventory[member.name]['size']
            assert hashlib.sha256(target.extractfile(member).read()).hexdigest() == inventory[member.name]['sha256']
    assert all(sha(paths[name]) == row['sha256'] for name, row in inventory.items())
    save('raw-index.json', inventory)
    summary = {
        'schema': 'fe2o3.retained-host-diagnostic-cpu-publication.v1',
        'signed_implementation_commit': 'd6b1906d0d24b366ea4222fbca4ae4a6966fad6c',
        'cpu_base_commit': linked['source_commit'],
        'cpu_source_snapshot_sha256': SOURCE_PIN,
        'linked_cpu_result_sha256': RESULT_PINS['linked-cpu'],
        'prior_cpu_stages_replayed': 19,
        'fresh_continuation_stages': 7,
        'all_features_full_suite': {'passed': 1830, 'failed': 0, 'ignored': 0, 'filtered_out': 0},
        'no_default_full_suite_run': False,
        'test_elfs_rebuilt_in_continuation': False,
        'original_artifacts_unchanged_at_packaging': {
            name: {key: row[key] for key in ('path', 'size', 'sha256')} for name, row in linked['artifacts'].items()},
        'format_scope': linked['format_scope'],
        'full_legacy_test_file_format_accepted': False,
        'rejections': {label: {'result_sha256': sha(SOURCES[label] / 'result.json'),
            'failures': json.loads((SOURCES[label] / 'result.json').read_bytes())['failures'],
            'accepted': False} for label in ('rejected-cpu-1', 'rejected-cpu-2', 'rejected-format-1')},
        'portable_helper_controls': {'source_tests': 26, 'git_free_empty_path_tests': 26,
            'result_sha256': RESULT_PINS['portable-controls'], 'native_qualification': False},
        'new_solver_or_test_commands_executed_by_packager': False,
        'historical_pid_probes': False,
        'single_continuous_owner_or_deadline_claim': False,
        'gpu_invocations': 0,
        'solver_invocations': 0,
        'formal_proof_acceptance': False,
        'performance_acceptance': False,
        'hip_hsa_parity': False,
        'archive': {'path': 'raw.tar.xz', 'sha256': sha(archive), 'size': archive.stat().st_size,
                    'members': len(inventory), 'logical_bytes': sum(row['size'] for row in inventory.values())},
        'raw_index_sha256': sha(OUTPUT / 'raw-index.json'),
        'archive_readback_verified': True,
        'elf_payloads_included': False,
        'original_records_unchanged': True,
    }
    save('summary.json', summary)
    print(json.dumps({'summary_sha256': sha(OUTPUT / 'summary.json'), 'archive': summary['archive']}, sort_keys=True))


if __name__ == '__main__':
    main()
