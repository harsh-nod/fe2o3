#!/usr/bin/env python3
"""Add signed-source portability to immutable diagnostic CPU evidence."""

import hashlib
import importlib.util
import io
import json
import lzma
import os
from pathlib import Path
import tarfile

BASE = Path('/home/harsh/.codex-tmp')
SOURCE = BASE / 'fe2o3-xgmi-retained-diagnostic-20260930-attempt-2'
PUBLIC = BASE / 'fe2o3-xgmi-retained-host-diagnostic-publication-20260930'
OUTPUT = BASE / 'fe2o3-xgmi-retained-host-diagnostic-signed-binding-20260930'
CPU = BASE / 'fe2o3-xgmi-retained-host-diagnostic-cpu-20260930-continuation-2/source-after.json'
COMMIT = 'd6b1906d0d24b366ea4222fbca4ae4a6966fad6c'
PARENT = '1c589082e8c76410ab3b5b2683468ca6a1932519'
BRANCH = 'refs/heads/codex/xgmi-retained-diagnostic-20260930-attempt-2'
ROOTS = ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo', 'crates', 'examples',
         'benchmarks/runtime_gfx942', 'docs/evidence/dev-xgmi-peer-hot-mi300x-2026-09-19/native.py',
         'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/native.py',
         'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/.gitattributes',
         'docs/runtime-xgmi-retained-host-diagnostic-v1.md')


def sha(path):
    assert path.is_file() and not path.is_symlink()
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode('ascii')


def write(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def main():
    os.umask(0o077)
    assert sha(PUBLIC / 'raw.tar.xz') == 'f2e534117fa242cf7e41da14a060d4461588736a751b2d25ca36a1713ca354e2'
    assert sha(PUBLIC / 'raw-index.json') == '503413710e76542a5ae5a41a7d6eca055efab9e04b898e4a95ff8f16876201cc'
    assert sha(PUBLIC / 'summary.json') == 'b73d487f4156d1ca3e8cf40f575267d5291b27d57266242a6c243eb60a3d4b55'
    assert sha(CPU) == '73ef7e432dea941606caa96ab815a91b326dca33dc0a2126a402dba1989af4f7'
    assert sha(Path('/usr/bin/git')) == '2a8c18fbf43da9f692d75474c72bea9dfd796c260b0f3dfe456376abc3bbd668'
    assert (PUBLIC / 'allowed-signers').read_text('ascii') == (
        'harmenon@amd.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAICITzoV64zd4tYeZhvOi+mnwQaxEI4rFvXeC3HxileBS\n')
    module_path = SOURCE / 'benchmarks/runtime_gfx942/xgmi_peer_series_native.py'
    assert sha(module_path) == 'fef3e00f9310ee1895dff2dac133826c66a8432a600d5be6065b4249f3ebc3f4'
    spec = importlib.util.spec_from_file_location('native_signed_binding', module_path)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    hot, _, _ = native.load_helpers()
    OUTPUT.mkdir(mode=0o700)
    rec = native.FreshRecorder(OUTPUT / 'commands', SOURCE, hot)
    environment = {'HOME': '/home/harsh', 'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
    namespace = os.readlink('/proc/self/ns/pid')
    git = ['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', '-c', 'pack.threads=2']

    def command(name, arguments):
        return rec.run(name, git + arguments, 60, env=environment)

    status = command('opening-status', ['status', '--porcelain=v1', '-z', '--untracked-files=all'])
    assert (status / 'stdout').read_bytes() == b'' and (status / 'stderr').read_bytes() == b''
    head = command('opening-head', ['rev-parse', 'HEAD', 'HEAD^1'])
    assert (head / 'stdout').read_text('ascii') == COMMIT + '\n' + PARENT + '\n'
    signature = command('signature', ['-c', 'gpg.ssh.allowedSignersFile=' + str(PUBLIC / 'allowed-signers'),
                                      'verify-commit', COMMIT])
    assert (signature / 'stdout').read_bytes() == b''
    expected_signature = 'Good "git" signature for harmenon@amd.com with ED25519 key SHA256:q8oGVYZ11904aFzlMkSiEwyeSP+6hbuiZGbNVGRZVCg\n'
    assert (signature / 'stderr').read_text('ascii') == expected_signature
    selected = command('signed-source-tree', ['ls-tree', '-rz', '--full-tree', COMMIT, '--', *ROOTS])
    raw = (selected / 'stdout').read_bytes()
    assert raw.endswith(b'\0') and (selected / 'stderr').read_bytes() == b''
    cpu = json.loads(CPU.read_bytes())
    files = {}
    for record in raw[:-1].split(b'\0'):
        header, name = record.split(b'\t')
        mode, kind, blob = header.decode('ascii').split()
        name = name.decode('ascii')
        assert name not in files and kind == 'blob' and mode in ('100644', '100755')
        path = SOURCE / name
        assert path.resolve(strict=True) == path and not path.is_symlink()
        data = path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest() == blob
        row = {'sha256': hashlib.sha256(data).hexdigest(), 'mode': mode}
        assert ('100755' if path.stat().st_mode & 0o111 else '100644') == mode
        assert row == cpu[name]
        files[name] = {**row, 'git_blob': blob, 'size': len(data)}
    assert set(files) == set(cpu) and len(files) == 6477
    bundle = PUBLIC / 'signed-candidate.bundle'
    assert not bundle.exists()
    command('create-bundle', ['bundle', 'create', '--version=2', str(bundle), PARENT + '..' + BRANCH])
    verified = command('verify-bundle', ['bundle', 'verify', str(bundle)])
    heads = command('bundle-heads', ['bundle', 'list-heads', str(bundle)])
    assert (heads / 'stdout').read_text('ascii') == COMMIT + ' ' + BRANCH + '\n'
    with bundle.open('rb') as stream:
        assert stream.readline() == b'# v2 git bundle\n'
        prerequisite = stream.readline().decode('ascii')
        assert prerequisite.startswith('-' + PARENT + ' ')
        assert stream.readline().decode('ascii') == COMMIT + ' ' + BRANCH + '\n'
        assert stream.readline() == b'\n'
    closing = command('closing-status', ['status', '--porcelain=v1', '-z', '--untracked-files=all'])
    assert (closing / 'stdout').read_bytes() == b'' and (closing / 'stderr').read_bytes() == b''
    closing_head = command('closing-head', ['rev-parse', 'HEAD'])
    assert (closing_head / 'stdout').read_text('ascii') == COMMIT + '\n'
    assert all(sha(SOURCE / name) == row['sha256'] for name, row in files.items())
    binding = {'schema': 'fe2o3.signed-cpu-source-binding.v1', 'commit': COMMIT, 'parent': PARENT,
        'source_root': str(SOURCE), 'source_roots': ROOTS, 'cpu_source_snapshot_sha256': sha(CPU),
        'files': files, 'claim': 'exact signed Git blob/mode and filesystem bytes equal retained CPU inventory'}
    binding_bytes = encoded(binding)
    write(PUBLIC / 'signed-source-binding.json.xz', lzma.compress(binding_bytes, preset=6))
    assert lzma.decompress((PUBLIC / 'signed-source-binding.json.xz').read_bytes()) == binding_bytes
    census = native.fresh_census(rec, hot, namespace)
    write(OUTPUT / 'fresh-census.json', encoded(census))
    write(OUTPUT / 'controller.py', Path(__file__).read_bytes())
    index = {str(path.relative_to(OUTPUT)): {'sha256': sha(path), 'size': path.stat().st_size}
             for path in sorted(OUTPUT.rglob('*')) if path.is_file()}
    records_archive = PUBLIC / 'signed-source-records.tar.xz'
    with tarfile.open(records_archive, 'x:xz', preset=6) as target:
        for name, row in index.items():
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = row['size'], 0o644, 0
            target.addfile(member, io.BytesIO((OUTPUT / name).read_bytes()))
    with tarfile.open(records_archive, 'r:xz') as target:
        members = target.getmembers()
        assert [member.name for member in members] == list(index)
        assert all(member.isfile() and hashlib.sha256(target.extractfile(member).read()).hexdigest()
                   == index[member.name]['sha256'] for member in members)
    verification = {'schema': 'fe2o3.signed-cpu-source-verification.v1', 'commit': COMMIT, 'parent': PARENT,
        'signature_verified': True, 'signature_stdout': '', 'signature_stderr': expected_signature,
        'signature_receipt_sha256': sha(signature / 'receipt.json'),
        'allowed_signers_sha256': sha(PUBLIC / 'allowed-signers'),
        'git_sha256': sha(Path('/usr/bin/git')), 'bundle_verified': True,
        'bundle_verify_stdout': (verified / 'stdout').read_text('ascii'),
        'bundle_verify_stderr': (verified / 'stderr').read_text('ascii'),
        'bundle_sha256': sha(bundle), 'bundle_size': bundle.stat().st_size,
        'binding_sha256': sha(PUBLIC / 'signed-source-binding.json.xz'),
        'binding_uncompressed_sha256': hashlib.sha256(binding_bytes).hexdigest(),
        'binding_files': 6477, 'historical_pid_probes': False,
        'source_records_sha256': sha(records_archive), 'source_records_members': index,
        'fresh_census_sha256': sha(OUTPUT / 'fresh-census.json'),
        'tests_or_solver_or_remote_commands_executed': False, 'original_cpu_records_rewritten': False}
    write(PUBLIC / 'signed-source-verification.json', encoded(verification))
    before = (PUBLIC / 'summary.json').read_bytes()
    write(PUBLIC / 'summary-before-signed-binding.json', before)
    summary = json.loads(before)
    summary['signed_source_verification'] = {key: verification[key] for key in (
        'signature_verified', 'bundle_verified', 'bundle_sha256', 'bundle_size', 'binding_sha256',
        'binding_uncompressed_sha256', 'binding_files', 'source_records_sha256')}
    summary['signed_source_verification']['verification_sha256'] = sha(PUBLIC / 'signed-source-verification.json')
    summary['signed_source_verification']['prerequisite_commit'] = PARENT
    (PUBLIC / 'summary.json').write_bytes(encoded(summary))
    assert sha(PUBLIC / 'raw.tar.xz') == 'f2e534117fa242cf7e41da14a060d4461588736a751b2d25ca36a1713ca354e2'
    assert sha(PUBLIC / 'raw-index.json') == '503413710e76542a5ae5a41a7d6eca055efab9e04b898e4a95ff8f16876201cc'
    print(json.dumps({'bundle_sha256': sha(bundle), 'bundle_size': bundle.stat().st_size,
        'binding_sha256': verification['binding_sha256'], 'verification_sha256': sha(PUBLIC / 'signed-source-verification.json'),
        'summary_sha256': sha(PUBLIC / 'summary.json')}))


if __name__ == '__main__':
    main()
