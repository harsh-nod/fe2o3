# Closed Unknown Group Developer Regression Receipts

Source commit: da58d3ed57dff47f24ebbdd134f7c9a4cb46efd6
Source parent: d0bee64ebda0a0e51c33e028b15602c2fcac01a3
Working directory: /home/harsh/.codex-tmp/fe2o3-r61-execution
Date: 2026-09-27

Final commands ran against the source files committed above. The later plan
wording edit only aligned the documented destruction order with the code.
All exits below are tool-observed, not inferred from a successful log suffix.

| Log | Command | Exit | Result |
| --- | --- | --- | --- |
| model-final.log | `cargo test -p fe2o3-runtime-model --all-features` | 0 | 1067 passed, 19 ignored; 29 doctests passed; no warnings |
| runtime-final.log | `cargo test -p fe2o3-runtime --all-features --lib` | 101 | 1675 passed, 4 failed, 28 ignored |
| runtime-serial.log | `cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1` | 101 | 1676 passed, 3 failed, 28 ignored |
| runtime-doc.log | `cargo test -p fe2o3-runtime --all-features --doc` | 0 | 8 merged and 44 separate doctests passed |
| clippy-final.log | `cargo clippy -p fe2o3-runtime-model -p fe2o3-runtime --all-features --all-targets -- -D warnings` | 0 | Passed |
| model-minimal.log | `cargo check -p fe2o3-runtime-model --no-default-features` | 0 | Passed |
| fmt.log | `cargo fmt -p fe2o3-runtime-model -p fe2o3-runtime -- --check` | 0 | Passed |
| diff-check.log | `git diff --check` | 0 | Passed |
| origin-probe.log | `git ls-remote origin refs/heads/codex/r65-runtime-drain-versions` | 128 | DNS resolution failed |
| mi300x-probe.log | `ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x true` | 255 | Host DNS resolution failed |
| source-signature.log | `git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD` | 0 | Signature verified for source commit |

Both full runtime runs failed the same three authorized_execution tests at
authorized_execution.rs:1317 with InspectSocket(PermissionDenied):
cooperative_debug_telemetry_emits_only_bounded_logical_records,
failed_session_end_is_explicit_and_terminal, and
pre_native_telemetry_failure_is_returned_and_poisoned.

The parallel runtime run additionally failed
worker::tests::v4_flush_deadline_failure_reaps_and_seals_the_worker at
worker.rs:5576, exceeding its 75 ms scheduler tolerance. Clippy compilation
overlapped the test execution. The complete serial rerun, after Clippy finished,
passed that test. This does not erase the first failure or prove its cause.
No tests were skipped beyond the suites' existing ignored tests, and no timeout
tolerance or production Worker code was changed.

Development logs are retained, but do not describe the exact final source:
focused-01.log contains a fixture ordering failure, corrected by registering the
outside producer before its consumer. focused-02.log passed the then-existing
29 queue tests. model-full.log passed all 1067 model tests and 29 doctests but
reported an unused_must_use warning, fixed before model-final.log. The earlier
runtime-disposal.log passed 10 then-existing disposal tests; the final suites
also include the additional later-quarantine test and completion-fault marker
assertions.

No new Verus, mutation, relocation or authenticated source-bound proof campaign
ran for this checkpoint. Existing proofs do not establish the new outer group
transition. No GPU, HIP/HSA baseline, or performance test ran. No remote jobs or
files were created. The archive is CPU developer regression evidence only.

Two read-only agents reviewed group closure/custody/terminal behavior and
Context quiescence caller boundaries respectively; both reported no remaining
actionable blocker after the terminal-precedence correction. This is review,
not machine-checked evidence.
