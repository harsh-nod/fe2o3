"""Replay selected CPU and native receipts without executing GPU work."""

import ast
from collections import Counter
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import subprocess
from types import SimpleNamespace

import yaml

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'a2951fe9d8191e757198574d9f12b80535712c1d'
NATIVE = RAW / 'native-results'
REMOTE = (RAW / 'remote-create-final/stdout').read_text().strip()
assert re.fullmatch(r'/tmp/fe2o3-frame-segments-20261003\.[A-Za-z0-9]{8}', REMOTE)
SOURCE = json.loads((RAW / 'runtime-tests-final2/source-before.json').read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def receipt(label, source=SOURCE):
    folder = RAW / label
    row = read(folder / 'receipt.json')
    assert row['exit'] == 0 and row['source_unchanged'] is True, label
    assert row['base'] == BASE
    assert row['controller_sha256'] == digest(RAW / 'capture.py')
    assert row['cwd'] == str(CAPTURE.ROOT) and row['environment'] == CAPTURE.ENV
    assert read(folder / 'source-before.json') == source
    assert read(folder / 'source-after.json') == source
    for name in ('stdout', 'stderr'):
        assert digest(folder / name) == row[name + '_sha256'], (label, name)
    return row


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


CAPTURE = load('campaign_capture', RAW / 'capture.py')


def check_ast(old, new):
    if isinstance(old, ast.Constant) and isinstance(new, ast.Constant) and old.value != new.value:
        pair = (old.value, new.value)
        assert pair in ((403, 405), (408, 410)) or all(
            isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) for value in pair)
        return [pair]
    assert type(old) is type(new)
    if isinstance(old, ast.AST):
        result = []
        assert old._fields == new._fields
        for field in old._fields:
            result.extend(check_ast(getattr(old, field), getattr(new, field)))
        return result
    if isinstance(old, list):
        assert len(old) == len(new)
        return [pair for left, right in zip(old, new) for pair in check_ast(left, right)]
    assert old == new
    return []


def main():
    assert CAPTURE.ROOT == ROOT and SOURCE == CAPTURE.snapshot()
    labels = ['runtime-tests-final2', 'example-tests-final2', 'runtime-doc-tests-final2',
              'no-default-check-final2', 'runtime-test-artifact-final2', 'runtime-roster-final2',
              'native-build-final2', 'clippy-final2', 'format-final2', 'diff-check-final2']
    accepted = {label: receipt(label) for label in labels}
    examples = ['--example', 'gfx942-runtime-destination-segments-smoke',
                '--example', 'gfx942-runtime-deferred-peer-chain-smoke',
                '--example', 'gfx942-runtime-peer-copy-smoke']
    def cargo(subcommand, tail):
        return ['cargo', '+nightly-2026-04-03', subcommand, '--locked', '--offline',
                '-p', 'fe2o3-runtime', *tail]
    exact_commands = {
        'runtime-tests-final2': cargo('test', ['--all-features', '--lib', '--', '--test-threads=4']),
        'example-tests-final2': cargo('test', ['--all-features', *examples]),
        'runtime-doc-tests-final2': cargo('test', ['--all-features', '--doc']),
        'no-default-check-final2': cargo('check', ['--no-default-features', '--lib']),
        'runtime-test-artifact-final2': cargo('test', ['--all-features', '--lib', '--no-run', '--message-format=json']),
        'native-build-final2': cargo('build', ['--no-default-features', '--features', 'hardware-qualification',
                                              *examples[:2], '--message-format=json']),
        'clippy-final2': cargo('clippy', ['--all-features', '--lib', '--tests', *examples, '--', '-D', 'warnings']),
        'format-final2': ['python3', '-I', '-B', str(RAW / 'format_changed.py')],
        'diff-check-final2': ['git', 'diff', '--check'],
    }
    test_artifacts = accepted['runtime-test-artifact-final2']['executables']
    executable = str(ROOT / 'target/debug/deps/fe2o3_runtime-f5a715f6eec7097e')
    assert list(test_artifacts) == [executable]
    assert test_artifacts[executable]['target'] == 'fe2o3_runtime'
    assert test_artifacts[executable]['test'] is True
    exact_commands['runtime-roster-final2'] = [executable, '--list']
    for label, command in exact_commands.items():
        seconds = '900s' if command[0] == 'cargo' else '90s'
        assert accepted[label]['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', seconds, *command]
    controls = read(RAW / 'controls-final2.json')
    workflow = yaml.safe_load((ROOT / '.github/workflows/runtime-component-source-guards.yml').read_text())
    commands = [shlex.split(line.strip())
                for step in workflow['jobs']['source-controls']['steps'] if 'run' in step
                for line in step['run'].splitlines() if line.strip()]
    assert len(commands) == 33 and commands == [row['command'] for row in controls]
    for row in controls:
        accepted[row['label']] = receipt(row['label'])
        assert accepted[row['label']]['command'] == [
            'timeout', '--signal=TERM', '--kill-after=30s', '180s', *row['command']]
    assert re.search(r'Ran 25 tests in .*\n\nOK\n',
                     (RAW / 'controls-final2-30/stderr').read_text())
    runtime_output = (RAW / 'runtime-tests-final2/stdout').read_text()
    # These abort-isolation tests inherit stdout; the child repeats its parent's
    # unterminated test banner. Accept only the exact doubled successful banner.
    for name in (
        'kfd_backend::tests::runtime_compute_pipeline_drop_aborts_for_every_live_logical_phase',
        'kfd_backend::tests::scripted_sdma_drop_still_aborts_with_live_or_terminal_custody',
    ):
        banner = 'test ' + name + ' ... '
        runtime_output, count = re.subn(
            '^' + re.escape(banner + banner) + 'ok$', banner + 'ok', runtime_output, flags=re.M)
        assert count == 1, name
    rows = re.findall(r'^test (\S+) \.\.\. (ok|ignored[^\n]*)$', runtime_output, re.M)
    roster = re.findall(r'^(\S+): test$', (RAW / 'runtime-roster-final2/stdout').read_text(), re.M)
    assert len(rows) == len(roster) == len(set(roster)) == 2384
    assert len({name for name, _ in rows}) == len(rows)
    assert {name for name, _ in rows} == set(roster)
    assert sum(status == 'ok' for _, status in rows) == 2352
    assert '2352 passed; 0 failed; 32 ignored; 0 measured; 0 filtered out' in runtime_output
    new_tests = [name for name, status in rows if '::frame_segments_' in name and status == 'ok']
    assert len(new_tests) == 15
    example_output = (RAW / 'example-tests-final2/stdout').read_text()
    example_summaries = re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', example_output)
    assert list(map(int, example_summaries)) == [25, 12, 3]
    example_rows = re.findall(r'^test (\S+) \.\.\. ok$', example_output, re.M)
    assert len(example_rows) == len(set(example_rows)) == 40
    assert {name for name in example_rows if name.startswith('forward_window::')} == {
        'forward_window::tests::forward_cli_is_separate_bounded_and_preserves_legacy_modes',
        'forward_window::tests::forward_oracle_matches_independent_last_writer_and_complete_target_host_bytes',
        'forward_window::tests::forward_report_has_exact_separate_schema_counts_and_publication_scope',
        'forward_window::tests::forward_segments_cli_and_last_descriptor_oracle_are_independent',
        'forward_window::tests::forward_window_crosses_frame_envelope_and_retains_independent_guards'}
    doc_output = (RAW / 'runtime-doc-tests-final2/stdout').read_text()
    doc_summaries = re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', doc_output)
    assert list(map(int, doc_summaries)) == [10, 51]
    for label in ('runtime-test-artifact-final2', 'native-build-final2'):
        for path, artifact in accepted[label]['executables'].items():
            assert digest(Path(path)) == artifact['sha256']
            assert Path(path).stat().st_size == artifact['byte_length']

    metadata = read(RAW / 'metadata-03/metadata-report.json')
    constant_changes = []
    changed_guards = 0
    for change in metadata['changes']:
        path = change['path']
        old = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
        new = (ROOT / path).read_bytes()
        assert hashlib.sha256(old).hexdigest() == change['original_sha256']
        assert hashlib.sha256(new).hexdigest() == change['proposed_sha256']
        pairs = check_ast(ast.parse(old), ast.parse(new))
        assert len(pairs) == len(change['edits'])
        constant_changes.extend(pairs)
        changed_guards += bool(pairs)
    assert changed_guards == 9 and len(constant_changes) == 25
    assert Counter(type(pair[0]).__name__ for pair in constant_changes) == {'str': 18, 'int': 7}
    assert len(metadata['proof_files']) == 76
    for path, sha in metadata['proof_files'].items():
        old = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
        assert digest(ROOT / path) == hashlib.sha256(old).hexdigest() == sha

    build = accepted['native-build-final2']
    native_path = str(ROOT / 'target/debug/examples/gfx942-runtime-destination-segments-smoke')
    assert list(build['executables']) == [native_path]
    artifact = build['executables'][native_path]
    assert artifact['target'] == 'gfx942-runtime-destination-segments-smoke'
    assert artifact['test'] is False
    for label in ('native-campaign-final', 'remote-hashes-final', 'binary-upload-final'):
        receipt(label)
    for label in ('native-retrieve-final', 'remote-cleanup-final'):
        receipt(label)
    cleanup = read(RAW / 'remote-cleanup-final/stdout')
    assert cleanup == {'owned_processes': [], 'removed': REMOTE, 'absent': True}
    report = read(NATIVE / 'result.json')
    assert report['accepted'] is True and report['errors'] == []
    assert report['schema'] == 'fe2o3.forward-segments-smoke.v1'
    assert report['binary_identity']['sha256'] == artifact['sha256']
    assert report['binary_identity']['bytes'] == artifact['byte_length']
    controller = load('forwarding_controller', ROOT / 'benchmarks/runtime_gfx942/forward_window_smoke.py')
    shared = controller.S
    observer = shared.load_observer()
    selected = tuple(tuple(device) for device in report['devices'])
    assert selected == ((1, '0000:26:00.0', '0xab83d2ffef0d3cdf'),
                        (6, '0000:c6:00.0', '0x10a254ce4987e716'),
                        (7, '0000:e5:00.0', '0x53691ef168a0147d'))
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'mi300x']
    device_options = [item for device in selected for item in ('--device', ','.join(map(str, device)))]
    outer = receipt('native-campaign-final')
    assert report['binary'] == REMOTE + '/gfx942-runtime-destination-segments-smoke'
    assert outer['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '3660s', *ssh,
        'timeout', '--kill-after=30s', '3600s', 'python3', '-I', '-B', REMOTE + '/forward_window_smoke.py',
        '--allow-hardware', '--segments', '--binary', report['binary'], '--binary-sha256', artifact['sha256'],
        *device_options, '--output', REMOTE + '/results']
    names = ['forward_window_smoke.py', 'selected_pair_smoke.py', 'copy-host-observe.py',
             'gfx942-runtime-destination-segments-smoke']
    hashes = receipt('remote-hashes-final')
    assert hashes['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '90s',
                                *ssh, 'sha256sum', *(REMOTE + '/' + name for name in names)]
    assert (RAW / 'remote-hashes-final/stdout').read_text().splitlines() == [
        (digest(ROOT / 'benchmarks/runtime_gfx942' / name) if i < 3 else artifact['sha256'])
        + '  ' + REMOTE + '/' + name for i, name in enumerate(names)]
    assert receipt('remote-cleanup-final')['command'] == [
        'timeout', '--signal=TERM', '--kill-after=30s', '90s', *ssh,
        'python3', '-I', '-B', REMOTE + '/remote_cleanup.py']
    upload = receipt('helpers-upload-final')
    assert upload['command'] == [
        'timeout', '--signal=TERM', '--kill-after=30s', '90s', 'scp', '-B', '-o',
        'ConnectTimeout=10', 'benchmarks/runtime_gfx942/forward_window_smoke.py',
        'benchmarks/runtime_gfx942/selected_pair_smoke.py',
        'benchmarks/runtime_gfx942/copy-host-observe.py', str(RAW / 'remote_cleanup.py'),
        'mi300x:' + REMOTE + '/']
    helper_hash = receipt('cleanup-helper-hash-final')
    assert helper_hash['command'] == [
        'timeout', '--signal=TERM', '--kill-after=30s', '90s', *ssh,
        'sha256sum', REMOTE + '/remote_cleanup.py']
    assert (RAW / 'cleanup-helper-hash-final/stdout').read_text() == (
        digest(RAW / 'remote_cleanup.py') + '  ' + REMOTE + '/remote_cleanup.py\n')
    retrieval = receipt('native-retrieve-final')
    assert retrieval['command'] == [
        'timeout', '--signal=TERM', '--kill-after=30s', '180s', 'scp', '-B', '-r',
        'mi300x:' + REMOTE + '/results', str(NATIVE)]
    cleanup_receipt = receipt('remote-cleanup-final')
    def timestamp(row, key):
        return datetime.datetime.fromisoformat(row[key])
    assert timestamp(upload, 'finished') <= timestamp(outer, 'started')
    assert timestamp(outer, 'finished') <= timestamp(retrieval, 'started')
    assert timestamp(retrieval, 'finished') <= timestamp(cleanup_receipt, 'started')
    assert timestamp(upload, 'finished') <= timestamp(helper_hash, 'started')
    assert timestamp(helper_hash, 'finished') <= timestamp(cleanup_receipt, 'started')
    outer_begin = int(datetime.datetime.fromisoformat(outer['started']).timestamp() * 10**9)
    outer_end = int(datetime.datetime.fromisoformat(outer['finished']).timestamp() * 10**9)
    assert outer_begin <= report['started']['unix_ns'] <= report['finished']['unix_ns'] <= outer_end
    assert len(report['cases']) == len(controller.CASES) == 8
    assert report['shared_sha256'] == controller.SHARED_SHA
    assert report['observer_sha256'] == shared.OBSERVER_SHA
    command_names = []
    observations = 0
    for case, (name, shape, late, reverse) in zip(report['cases'], controller.CASES):
        assert case['name'] == name and case['accepted'] and case['cleanup_observed']
        devices = tuple(reversed(selected)) if reverse else selected
        expected = controller.expected(devices, shape, late, True)
        native = read(NATIVE / name / 'receipt.json')
        assert native['argv'] == [report['binary'], '--late-forward-segments' if late else '--forward-segments',
                                  *(device[2] for device in devices), shape]
        parsed = shared.parse_pass(shared.command_text(SimpleNamespace(output=NATIVE), name, native), expected)
        assert parsed == case['pass']
        for phase in ('before', 'after'):
            for index, bdf, uid in selected:
                label = f'{name}-{phase}-gpu{index}'
                observation = read(NATIVE / (label + '.json'))
                start = observation['started']['monotonic_ns']
                end = observation['finished']['monotonic_ns']
                assert report['started']['monotonic_ns'] <= start <= end <= report['finished']['monotonic_ns']
                if phase == 'before':
                    assert end <= native['started']['monotonic_ns']
                    assert 0 <= native['started']['monotonic_ns'] - start <= 150 * 10**9
                else:
                    assert native['finished']['monotonic_ns'] <= start
                captures = [read(NATIVE / f'{label}-{number}' / 'receipt.json') for number in range(2)]
                timeline = [observation['sysfs'][0], captures[0], observation['sysfs'][1],
                            captures[1], observation['sysfs'][2]]
                previous = start
                for interval in timeline:
                    assert previous <= interval['started']['monotonic_ns'] <= interval['finished']['monotonic_ns'] <= end
                    previous = interval['finished']['monotonic_ns']
                snapshots = iter(observation['sysfs'])
                observer.capture_sysfs = lambda root, pci: next(snapshots)
                ordinal = 0

                def run(argv):
                    nonlocal ordinal
                    capture_name = f'{label}-{ordinal}'
                    ordinal += 1
                    command = read(NATIVE / capture_name / 'receipt.json')
                    assert command['argv'] == argv
                    return dict(exit=command['exit'], error=command['error'],
                                stdout=(NATIVE / capture_name / 'stdout').read_text(),
                                stderr=(NATIVE / capture_name / 'stderr').read_text())

                replay = observer.observe(index, bdf, uid, Path('/opt/rocm/bin/rocm-smi'), run=run)
                assert ordinal == 2 and next(snapshots, None) is None
                assert {k: v for k, v in replay.items() if k not in ('started', 'finished')} == {
                    k: v for k, v in observation.items() if k not in ('started', 'finished')}
                assert replay['endpoint_admitted'] and replay['selected_pids'] == [] and replay['reasons'] == []
                command_names.extend(f'{label}-{number}' for number in range(2))
                observations += 1
            if phase == 'before':
                command_names.append(name)
    assert command_names == report['commands'] and len(set(command_names)) == 104
    previous = report['started']['monotonic_ns']
    for name in command_names:
        folder = NATIVE / name
        row = read(folder / 'receipt.json')
        assert row['exit'] == 0 and row['error'] is None and row['group_absent'] is True
        assert row['environment'] == shared.ENV
        assert row['bound_seconds'] == (180 if name in {case[0] for case in controller.CASES} else 35)
        start, end = row['started']['monotonic_ns'], row['finished']['monotonic_ns']
        assert previous <= start <= end <= report['finished']['monotonic_ns']
        assert end - start <= (row['bound_seconds'] + 15) * 10**9
        assert outer_begin <= row['started']['unix_ns'] <= row['finished']['unix_ns'] <= outer_end
        previous = end
        for output in ('stdout', 'stderr'):
            assert digest(folder / output) == row[output + '_sha256']
            assert (folder / output).stat().st_size == row[output + '_bytes']
    result = dict(accepted=True, base=BASE, runtime_passed=2352, runtime_ignored=32,
                  focused_runtime_passed=len(new_tests), example_passed=sum(map(int, example_summaries)),
                  doctests_passed=61, source_controls=33, smoke_controller_tests=25,
                  source_files=len(SOURCE), guard_files_changed=changed_guards,
                  guard_metadata_literals=len(constant_changes), unchanged_proof_files=76,
                  native_cases=8, native_command_receipts=len(command_names), endpoint_observations=observations,
                  native_sha256=artifact['sha256'], native_source_identical=True,
                  solver_run=False, whole_adapter_refinement=False, performance_qualification=False,
                  remote_cleanup=cleanup)
    (RAW / 'audit-report.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
