"""Remove only this campaign's private directory after its processes have exited."""

import json
import os
from pathlib import Path
import shutil

ROOT = Path('/tmp/fe2o3-frame-segments-20261003.KMkzCpOq')
assert ROOT.is_dir() and not ROOT.is_symlink()
assert ROOT.stat().st_uid == os.getuid()
owned = []
for process in Path('/proc').iterdir():
    if not process.name.isdecimal() or int(process.name) == os.getpid():
        continue
    try:
        argv = (process / 'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError, ProcessLookupError):
        continue
    if any(arg.startswith(os.fsencode(ROOT) + b'/') for arg in argv):
        owned.append(int(process.name))
assert not owned, owned
shutil.rmtree(ROOT)
assert not ROOT.exists()
print(json.dumps({'owned_processes': owned, 'removed': str(ROOT), 'absent': True}, sort_keys=True))
