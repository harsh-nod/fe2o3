//! Solver-neutral, non-executable `proof.*` Pliron overlay.
//!
//! Every evidence reference names exactly one property and one status at one
//! covered boundary. No status, operation, or interface in this crate grants
//! proof promotion, publication, loading, launch, or runtime authority.

#![forbid(unsafe_code)]

use std::{error::Error, fmt};

use dialect_kernel::{SemanticScalarType, is_index_type, ranked_view_type};
use pliron::{
    attribute::Attribute,
    builtin::op_interfaces::{NOpdsInterface, NRegionsInterface, NResultsInterface},
    combine::{Parser, count_min_max, parser::char::hex_digit},
    common_traits::Verify,
    context::Context,
    derive::{op_interface, pliron_attr, pliron_op, pliron_type},
    dialect::{Dialect, DialectName},
    op::Op,
    operation::Operation,
    parsable::{Parsable, ParseResult, StateStream},
    printable::{self, Printable},
    result::Result,
    r#type::{Type, Typed},
    value::Value,
    verify_err, verify_err_noloc,
};

mod registration;

pub use registration::dialect_registration;

/// Pliron dialect name.
pub const DIALECT_NAME: &str = "proof";

/// Number of bits in every stable reference carried by this shell.
pub const IDENTITY_BITS: usize = 256;

pliron::dict_key!(
    PROOF_REGISTRATION_KEY,
    "fe2o3_dialect_proof_explicit_registration"
);

#[derive(Debug)]
struct RegistrationMarker;

/// Result of explicitly registering this dialect in a context.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RegistrationOutcome {
    /// The complete dialect surface was explicitly registered.
    Registered,
    /// The same complete surface was already registered by this crate.
    AlreadyRegistered,
}

/// A fail-closed explicit registration error.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RegistrationError {
    /// Another typed value already claimed this crate's marker key.
    MarkerCollision,
    /// The marker map referenced absent auxiliary data.
    CorruptMarker,
}

impl fmt::Display for RegistrationError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MarkerCollision => formatter.write_str("proof registration marker collision"),
            Self::CorruptMarker => formatter.write_str("proof registration marker is corrupt"),
        }
    }
}

impl Error for RegistrationError {}

/// A fixed-width canonical reference. The all-zero value is reserved and rejected.
#[pliron_attr(name = "proof.id")]
#[derive(Clone, Debug, Eq, Hash, PartialEq)]
pub struct ProofIdAttr([u64; 4]);

impl ProofIdAttr {
    pub const fn new(words: [u64; 4]) -> Self {
        Self(words)
    }

    pub const fn words(&self) -> [u64; 4] {
        self.0
    }

    pub const fn is_zero(&self) -> bool {
        self.0[0] == 0 && self.0[1] == 0 && self.0[2] == 0 && self.0[3] == 0
    }
}

impl Verify for ProofIdAttr {
    fn verify(&self, _context: &Context) -> Result<()> {
        if self.is_zero() {
            return verify_err_noloc!("proof.id cannot be the reserved all-zero identity");
        }
        Ok(())
    }
}

impl Printable for ProofIdAttr {
    fn fmt(
        &self,
        _context: &Context,
        _state: &printable::State,
        formatter: &mut core::fmt::Formatter<'_>,
    ) -> core::fmt::Result {
        write!(
            formatter,
            "{:016x}{:016x}{:016x}{:016x}",
            self.0[0], self.0[1], self.0[2], self.0[3]
        )
    }
}

impl Parsable for ProofIdAttr {
    type Arg = ();
    type Parsed = Self;

    fn parse<'a>(
        state_stream: &mut StateStream<'a>,
        _arg: Self::Arg,
    ) -> ParseResult<'a, Self::Parsed> {
        let word = || {
            count_min_max::<String, _, _>(16, 16, hex_digit())
                .and_then(|digits| u64::from_str_radix(&digits, 16))
        };
        word()
            .and(word())
            .and(word())
            .and(word())
            .map(|(((first, second), third), fourth)| Self([first, second, third, fourth]))
            .parse_stream(state_stream)
            .into()
    }
}

/// Independently tracked proof properties.
#[pliron_attr(name = "proof.property", format, verifier = "succ")]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum PropertyAttr {
    Bounds,
    Provenance,
    RegionDisjointness,
    Initialization,
    RaceFreedom,
    Convergence,
    FunctionalRefinement,
    NumericalBound,
    Determinism,
    DeadlockFreedom,
}

/// Status of one property only. It is never a global verification badge.
#[pliron_attr(name = "proof.evidence_status", format, verifier = "succ")]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum EvidenceStatusAttr {
    Proved,
    Validated,
    Contracted,
    Checked,
    Unsupported,
}

impl EvidenceStatusAttr {
    /// Evidence status alone never grants authority.
    pub const fn grants_authority(self) -> bool {
        false
    }
}

/// Last semantic boundary covered by one evidence record.
#[pliron_attr(name = "proof.covered_boundary", format, verifier = "succ")]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum CoveredBoundaryAttr {
    Source,
    Mir,
    StructuredKernel,
    Schedule,
    TargetNeutralGpu,
}

/// Marker type for obligation references in proof-only schemas.
#[pliron_type(
    name = "proof.obligation_ref",
    format,
    generate_get = true,
    verifier = "succ"
)]
#[derive(Debug, Eq, Hash, PartialEq)]
pub struct ObligationRefType;

/// Marker type for evidence references in proof-only schemas.
#[pliron_type(
    name = "proof.evidence_ref",
    format,
    generate_get = true,
    verifier = "succ"
)]
#[derive(Debug, Eq, Hash, PartialEq)]
pub struct EvidenceRefType;

/// Interface shared by inert proof overlay operations.
#[op_interface]
pub trait ProofOverlayOpInterface {
    fn verify(_op: &dyn Op, _context: &Context) -> Result<()>
    where
        Self: Sized,
    {
        Ok(())
    }

    fn is_executable(&self) -> bool {
        false
    }

    fn grants_authority(&self) -> bool {
        false
    }
}

/// Declares one solver-neutral property obligation.
#[pliron_op(
    name = "proof.obligation",
    format = "attr($proof_obligation_obligation_id, $ProofIdAttr) ` ` attr($proof_obligation_subject_id, $ProofIdAttr) ` ` attr($proof_obligation_model_id, $ProofIdAttr) ` ` attr($proof_obligation_property, $PropertyAttr)",
    interfaces = [
        ProofOverlayOpInterface,
        NOpdsInterface<0>,
        NResultsInterface<0>,
        NRegionsInterface<0>
    ],
    attributes = (
        proof_obligation_obligation_id: ProofIdAttr,
        proof_obligation_subject_id: ProofIdAttr,
        proof_obligation_model_id: ProofIdAttr,
        proof_obligation_property: PropertyAttr
    )
)]
pub struct ObligationOp;

impl ObligationOp {
    pub fn new(
        context: &mut Context,
        obligation_id: ProofIdAttr,
        subject_id: ProofIdAttr,
        model_id: ProofIdAttr,
        property: PropertyAttr,
    ) -> Self {
        let operation = Operation::new(
            context,
            Self::get_concrete_op_info(),
            vec![],
            vec![],
            vec![],
            0,
        );
        let op = Self::from_operation(operation);
        op.set_attr_proof_obligation_obligation_id(context, obligation_id);
        op.set_attr_proof_obligation_subject_id(context, subject_id);
        op.set_attr_proof_obligation_model_id(context, model_id);
        op.set_attr_proof_obligation_property(context, property);
        op
    }

    pub fn obligation_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_obligation_obligation_id(context)
            .map(|identity| identity.words())
    }

    pub fn subject_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_obligation_subject_id(context)
            .map(|identity| identity.words())
    }

    pub fn model_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_obligation_model_id(context)
            .map(|identity| identity.words())
    }

    pub fn property(&self, context: &Context) -> Option<PropertyAttr> {
        self.get_attr_proof_obligation_property(context)
            .map(|property| *property)
    }
}

impl Verify for ObligationOp {
    fn verify(&self, context: &Context) -> Result<()> {
        verify_closed_shape(self, context, 4)?;
        required_attr(
            self,
            context,
            self.get_attr_proof_obligation_obligation_id(context),
            "obligation_id",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_obligation_subject_id(context),
            "subject_id",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_obligation_model_id(context),
            "model_id",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_obligation_property(context),
            "property",
        )?;
        Ok(())
    }
}

/// References evidence for exactly one obligation/property/status tuple.
#[pliron_op(
    name = "proof.evidence_ref",
    format = "attr($proof_evidence_ref_evidence_id, $ProofIdAttr) ` ` attr($proof_evidence_ref_obligation_id, $ProofIdAttr) ` ` attr($proof_evidence_ref_property, $PropertyAttr) ` ` attr($proof_evidence_ref_status, $EvidenceStatusAttr) ` ` attr($proof_evidence_ref_covered_boundary, $CoveredBoundaryAttr)",
    interfaces = [
        ProofOverlayOpInterface,
        NOpdsInterface<0>,
        NResultsInterface<0>,
        NRegionsInterface<0>
    ],
    attributes = (
        proof_evidence_ref_evidence_id: ProofIdAttr,
        proof_evidence_ref_obligation_id: ProofIdAttr,
        proof_evidence_ref_property: PropertyAttr,
        proof_evidence_ref_status: EvidenceStatusAttr,
        proof_evidence_ref_covered_boundary: CoveredBoundaryAttr
    )
)]
pub struct EvidenceRefOp;

impl EvidenceRefOp {
    pub fn new(
        context: &mut Context,
        evidence_id: ProofIdAttr,
        obligation_id: ProofIdAttr,
        property: PropertyAttr,
        status: EvidenceStatusAttr,
        covered_boundary: CoveredBoundaryAttr,
    ) -> Self {
        let operation = Operation::new(
            context,
            Self::get_concrete_op_info(),
            vec![],
            vec![],
            vec![],
            0,
        );
        let op = Self::from_operation(operation);
        op.set_attr_proof_evidence_ref_evidence_id(context, evidence_id);
        op.set_attr_proof_evidence_ref_obligation_id(context, obligation_id);
        op.set_attr_proof_evidence_ref_property(context, property);
        op.set_attr_proof_evidence_ref_status(context, status);
        op.set_attr_proof_evidence_ref_covered_boundary(context, covered_boundary);
        op
    }

    pub fn evidence_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_evidence_ref_evidence_id(context)
            .map(|identity| identity.words())
    }

    pub fn obligation_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_evidence_ref_obligation_id(context)
            .map(|identity| identity.words())
    }

    pub fn property(&self, context: &Context) -> Option<PropertyAttr> {
        self.get_attr_proof_evidence_ref_property(context)
            .map(|property| *property)
    }

    pub fn status(&self, context: &Context) -> Option<EvidenceStatusAttr> {
        self.get_attr_proof_evidence_ref_status(context)
            .map(|status| *status)
    }

    pub fn covered_boundary(&self, context: &Context) -> Option<CoveredBoundaryAttr> {
        self.get_attr_proof_evidence_ref_covered_boundary(context)
            .map(|boundary| *boundary)
    }
}

impl Verify for EvidenceRefOp {
    fn verify(&self, context: &Context) -> Result<()> {
        verify_closed_shape(self, context, 5)?;
        let evidence_id = required_attr(
            self,
            context,
            self.get_attr_proof_evidence_ref_evidence_id(context),
            "evidence_id",
        )?;
        let obligation_id = required_attr(
            self,
            context,
            self.get_attr_proof_evidence_ref_obligation_id(context),
            "obligation_id",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_evidence_ref_property(context),
            "property",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_evidence_ref_status(context),
            "status",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_evidence_ref_covered_boundary(context),
            "covered_boundary",
        )?;
        if evidence_id == obligation_id {
            return verify_err!(
                self.loc(context),
                "proof evidence and obligation identities must occupy distinct domains"
            );
        }
        Ok(())
    }
}

/// Joins one exact functional-refinement proof obligation to one pair of
/// target-neutral semantic expressions.
///
/// This operation remains inert. The semantic-refinement analysis validates
/// the referenced obligation and evidence and proves expression equality; the
/// operation alone grants no authority.
#[pliron_op(
    name = "proof.require_refinement",
    format,
    interfaces = [NResultsInterface<0>, NRegionsInterface<0>],
    attributes = (proof_require_refinement_obligation_id: ProofIdAttr)
)]
pub struct RequireRefinementOp;

impl RequireRefinementOp {
    pub fn new(
        context: &mut Context,
        obligation_id: ProofIdAttr,
        actual: Value,
        expected: Value,
    ) -> Self {
        let operation = Operation::new(
            context,
            Self::get_concrete_op_info(),
            vec![],
            vec![actual, expected],
            vec![],
            0,
        );
        let op = Self::from_operation(operation);
        op.set_attr_proof_require_refinement_obligation_id(context, obligation_id);
        op
    }

    pub fn obligation_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_require_refinement_obligation_id(context)
            .map(|identity| identity.words())
    }

    pub fn actual(&self, context: &Context) -> Value {
        self.get_operation().deref(context).get_operand(0)
    }

    pub fn expected(&self, context: &Context) -> Value {
        self.get_operation().deref(context).get_operand(1)
    }
}

impl Verify for RequireRefinementOp {
    fn verify(&self, context: &Context) -> Result<()> {
        verify_closed_shape_with_operands(self, context, 2, 1)?;
        required_attr(
            self,
            context,
            self.get_attr_proof_require_refinement_obligation_id(context),
            "obligation_id",
        )?;
        for operand in 0..2 {
            let value = self.get_operation().deref(context).get_operand(operand);
            if !value
                .get_type(context)
                .deref(context)
                .is::<SemanticScalarType>()
            {
                return verify_err!(
                    self.loc(context),
                    "proof refinement operand {operand} is not kernel.semantic_scalar"
                );
            }
        }
        Ok(())
    }
}

/// Joins one claim-specific cooperative-tensor theorem to a live output view,
/// one aggregate actual/reference pair, and an ordered list of result-component
/// actual/reference pairs.
///
/// This operation is inert. Its local verifier checks only the bounded typed
/// payload. Whole-function analysis must authenticate the MIR-bound obligation;
/// production admission separately binds the exact tensor layout, capability
/// roots, component order, and correlated output stores into that obligation.
pub const MAX_TENSOR_REFINEMENT_COMPONENTS_V1: usize =
    dialect_kernel::MAX_TENSOR_RESULT_COMPONENTS_V1;

#[pliron_op(
    name = "proof.require_tensor_refinement",
    format,
    interfaces = [NResultsInterface<0>, NRegionsInterface<0>],
    attributes = (
        proof_require_tensor_refinement_obligation_id: ProofIdAttr,
        proof_require_tensor_refinement_result_root: ProofIdAttr
    )
)]
pub struct RequireTensorRefinementOp;

impl RequireTensorRefinementOp {
    pub fn try_new(
        context: &mut Context,
        obligation_id: ProofIdAttr,
        result_root: ProofIdAttr,
        view: Value,
        actual: Value,
        reference: Value,
        components: impl IntoIterator<Item = (Value, Value)>,
    ) -> std::result::Result<Self, &'static str> {
        let mut operands = vec![view, actual, reference];
        for (component, (gpu, sequential)) in components.into_iter().enumerate() {
            if component == MAX_TENSOR_REFINEMENT_COMPONENTS_V1 {
                return Err("proof tensor refinement component limit exceeded");
            }
            operands.extend([gpu, sequential]);
        }
        let operation = Operation::new(
            context,
            Self::get_concrete_op_info(),
            vec![],
            operands,
            vec![],
            0,
        );
        let op = Self::from_operation(operation);
        op.set_attr_proof_require_tensor_refinement_obligation_id(context, obligation_id);
        op.set_attr_proof_require_tensor_refinement_result_root(context, result_root);
        Ok(op)
    }

    pub fn obligation_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_require_tensor_refinement_obligation_id(context)
            .map(|identity| identity.words())
    }

    pub fn result_root(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_require_tensor_refinement_result_root(context)
            .map(|identity| identity.words())
    }

    pub fn view(&self, context: &Context) -> Value {
        self.get_operation().deref(context).get_operand(0)
    }

    pub fn actual(&self, context: &Context) -> Value {
        self.get_operation().deref(context).get_operand(1)
    }

    pub fn reference(&self, context: &Context) -> Value {
        self.get_operation().deref(context).get_operand(2)
    }

    pub fn components(&self, context: &Context) -> Vec<(Value, Value)> {
        let operation = self.get_operation().deref(context);
        let operand_count = operation.get_num_operands();
        if operand_count < 5
            || !(operand_count - 3).is_multiple_of(2)
            || (operand_count - 3) / 2 > MAX_TENSOR_REFINEMENT_COMPONENTS_V1
        {
            return Vec::new();
        }
        (3..operand_count)
            .step_by(2)
            .map(|operand| {
                (
                    operation.get_operand(operand),
                    operation.get_operand(operand + 1),
                )
            })
            .collect()
    }
}

impl Verify for RequireTensorRefinementOp {
    fn verify(&self, context: &Context) -> Result<()> {
        let operation = self.get_operation().deref(context);
        let operand_count = operation.get_num_operands();
        if operand_count < 5 || !(operand_count - 3).is_multiple_of(2) {
            return verify_err!(
                self.loc(context),
                "proof tensor refinement requires a view, an aggregate pair, and at least one complete component pair"
            );
        }
        if (operand_count - 3) / 2 > MAX_TENSOR_REFINEMENT_COMPONENTS_V1 {
            return verify_err!(
                self.loc(context),
                "proof tensor refinement exceeds the {} component limit",
                MAX_TENSOR_REFINEMENT_COMPONENTS_V1
            );
        }
        verify_closed_shape_with_operands(self, context, operand_count, 2)?;
        required_attr(
            self,
            context,
            self.get_attr_proof_require_tensor_refinement_obligation_id(context),
            "obligation_id",
        )?;
        required_attr(
            self,
            context,
            self.get_attr_proof_require_tensor_refinement_result_root(context),
            "result_root",
        )?;
        if ranked_view_type(operation.get_operand(0), context).is_none() {
            return verify_err!(
                self.loc(context),
                "proof tensor refinement operand 0 is not a ranked view"
            );
        }
        for operand in 1..operand_count {
            if !operation
                .get_operand(operand)
                .get_type(context)
                .deref(context)
                .is::<SemanticScalarType>()
            {
                return verify_err!(
                    self.loc(context),
                    "proof tensor refinement semantic operand {} is not kernel.semantic_scalar",
                    operand - 1
                );
            }
        }
        Ok(())
    }
}

/// Joins one MIR-level functional-refinement obligation to one logical GPU
/// write and its normalized sequential-reference effect.
///
/// This operation is inert. Its local verifier checks only the bounded typed
/// payload. Whole-function analysis must correlate it with a real write,
/// reconstruct the write's guarded ownership domain, validate MIR proof
/// evidence, and compare the domain, precondition, and value expressions.
#[pliron_op(
    name = "proof.require_effect_refinement",
    format,
    interfaces = [NResultsInterface<0>, NRegionsInterface<0>],
    attributes = (proof_require_effect_refinement_obligation_id: ProofIdAttr)
)]
pub struct RequireEffectRefinementOp;

impl RequireEffectRefinementOp {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        context: &mut Context,
        obligation_id: ProofIdAttr,
        view: Value,
        indices: Vec<Value>,
        gpu_coordinates: Vec<Value>,
        reference_coordinates: Vec<Value>,
        gpu_domain: Value,
        reference_domain: Value,
        gpu_precondition: Value,
        reference_precondition: Value,
        gpu_value: Value,
        reference_value: Value,
    ) -> Self {
        let mut operands = Vec::with_capacity(indices.len() * 3 + 7);
        operands.push(view);
        operands.extend(indices);
        operands.extend(gpu_coordinates);
        operands.extend(reference_coordinates);
        operands.extend([
            gpu_domain,
            reference_domain,
            gpu_precondition,
            reference_precondition,
            gpu_value,
            reference_value,
        ]);
        let operation = Operation::new(
            context,
            Self::get_concrete_op_info(),
            vec![],
            operands,
            vec![],
            0,
        );
        let op = Self::from_operation(operation);
        op.set_attr_proof_require_effect_refinement_obligation_id(context, obligation_id);
        op
    }

    pub fn obligation_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_require_effect_refinement_obligation_id(context)
            .map(|identity| identity.words())
    }

    pub fn view(&self, context: &Context) -> Value {
        self.get_operation().deref(context).get_operand(0)
    }

    pub fn indices(&self, context: &Context) -> Vec<Value> {
        let rank = ranked_view_type(self.view(context), context)
            .map(|view| view.deref(context).rank())
            .unwrap_or(0);
        let operation = self.get_operation();
        let operation = operation.deref(context);
        (1..=rank)
            .map(|operand| operation.get_operand(operand))
            .collect()
    }

    pub fn gpu_coordinates(&self, context: &Context) -> Vec<Value> {
        let rank = ranked_view_type(self.view(context), context)
            .map(|view| view.deref(context).rank())
            .unwrap_or(0);
        let operation = self.get_operation();
        let operation = operation.deref(context);
        (1 + rank..1 + rank * 2)
            .map(|operand| operation.get_operand(operand))
            .collect()
    }

    pub fn reference_coordinates(&self, context: &Context) -> Vec<Value> {
        let rank = ranked_view_type(self.view(context), context)
            .map(|view| view.deref(context).rank())
            .unwrap_or(0);
        let operation = self.get_operation();
        let operation = operation.deref(context);
        (1 + rank * 2..1 + rank * 3)
            .map(|operand| operation.get_operand(operand))
            .collect()
    }

    fn semantic_operand(&self, context: &Context, offset: usize) -> Value {
        let rank = ranked_view_type(self.view(context), context)
            .map(|view| view.deref(context).rank())
            .unwrap_or(0);
        self.get_operation()
            .deref(context)
            .get_operand(1 + rank * 3 + offset)
    }

    pub fn gpu_domain(&self, context: &Context) -> Value {
        self.semantic_operand(context, 0)
    }

    pub fn reference_domain(&self, context: &Context) -> Value {
        self.semantic_operand(context, 1)
    }

    pub fn gpu_precondition(&self, context: &Context) -> Value {
        self.semantic_operand(context, 2)
    }

    pub fn reference_precondition(&self, context: &Context) -> Value {
        self.semantic_operand(context, 3)
    }

    pub fn gpu_value(&self, context: &Context) -> Value {
        self.semantic_operand(context, 4)
    }

    pub fn reference_value(&self, context: &Context) -> Value {
        self.semantic_operand(context, 5)
    }
}

impl Verify for RequireEffectRefinementOp {
    fn verify(&self, context: &Context) -> Result<()> {
        let operation = self.get_operation();
        let operation = operation.deref(context);
        if operation.get_num_operands() < 7 {
            return verify_err!(
                self.loc(context),
                "proof effect refinement has a truncated operand payload"
            );
        }
        let view = operation.get_operand(0);
        let Some(view_type) = ranked_view_type(view, context) else {
            return verify_err!(
                self.loc(context),
                "proof effect refinement operand 0 is not a ranked view"
            );
        };
        let rank = view_type.deref(context).rank();
        verify_closed_shape_with_operands(self, context, rank * 3 + 7, 1)?;
        required_attr(
            self,
            context,
            self.get_attr_proof_require_effect_refinement_obligation_id(context),
            "obligation_id",
        )?;
        for operand in 1..=rank {
            if !is_index_type(operation.get_operand(operand), context) {
                return verify_err!(
                    self.loc(context),
                    "proof effect refinement index operand {} is not kernel.index",
                    operand - 1
                );
            }
        }
        for operand in rank + 1..rank * 3 + 7 {
            if !operation
                .get_operand(operand)
                .get_type(context)
                .deref(context)
                .is::<SemanticScalarType>()
            {
                return verify_err!(
                    self.loc(context),
                    "proof effect refinement semantic operand {} is not kernel.semantic_scalar",
                    operand - rank - 1
                );
            }
        }
        Ok(())
    }
}

/// Canonical absolute-error bits carried by a numerical-refinement proof.
#[pliron_attr(name = "proof.absolute_error_f64_bits", format = "$0")]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct AbsoluteErrorF64BitsAttr(pub u64);

impl Verify for AbsoluteErrorF64BitsAttr {
    fn verify(&self, _context: &Context) -> Result<()> {
        let value = f64::from_bits(self.0);
        if !value.is_finite() || value < 0.0 {
            return verify_err_noloc!("proof absolute error must be a finite nonnegative f64");
        }
        Ok(())
    }
}

/// Canonical relative-error bits carried by a numerical-refinement proof.
#[pliron_attr(name = "proof.relative_error_f64_bits", format = "$0")]
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct RelativeErrorF64BitsAttr(pub u64);

impl Verify for RelativeErrorF64BitsAttr {
    fn verify(&self, _context: &Context) -> Result<()> {
        let value = f64::from_bits(self.0);
        if !value.is_finite() || value < 0.0 {
            return verify_err_noloc!("proof relative error must be a finite nonnegative f64");
        }
        Ok(())
    }
}

/// Joins an authenticated finite-error theorem to exact semantic roots.
///
/// Under the Boolean domain and precondition operands, both floating roots are
/// finite and `abs(actual-reference) <= absolute + relative*abs(reference)`.
///
/// The operation is workload-neutral and inert by itself. Production admission
/// authenticates the obligation id against the complete ranked graph, roots,
/// domain, precondition, and bounds before this operation can enter the live IR.
#[pliron_op(
    name = "proof.require_numerical_refinement",
    format,
    interfaces = [NOpdsInterface<4>, NResultsInterface<0>, NRegionsInterface<0>],
    attributes = (
        proof_require_numerical_refinement_obligation_id: ProofIdAttr,
        proof_require_numerical_refinement_absolute_error: AbsoluteErrorF64BitsAttr,
        proof_require_numerical_refinement_relative_error: RelativeErrorF64BitsAttr
    )
)]
pub struct RequireNumericalRefinementOp;

impl RequireNumericalRefinementOp {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        context: &mut Context,
        obligation_id: ProofIdAttr,
        absolute_error: AbsoluteErrorF64BitsAttr,
        relative_error: RelativeErrorF64BitsAttr,
        actual: Value,
        reference: Value,
        domain: Value,
        precondition: Value,
    ) -> Self {
        let operation = Operation::new(
            context,
            Self::get_concrete_op_info(),
            vec![],
            vec![actual, reference, domain, precondition],
            vec![],
            0,
        );
        let op = Self::from_operation(operation);
        op.set_attr_proof_require_numerical_refinement_obligation_id(context, obligation_id);
        op.set_attr_proof_require_numerical_refinement_absolute_error(context, absolute_error);
        op.set_attr_proof_require_numerical_refinement_relative_error(context, relative_error);
        op
    }

    pub fn obligation_id(&self, context: &Context) -> Option<[u64; 4]> {
        self.get_attr_proof_require_numerical_refinement_obligation_id(context)
            .map(|identity| identity.words())
    }

    pub fn absolute_error_f64_bits(&self, context: &Context) -> Option<u64> {
        self.get_attr_proof_require_numerical_refinement_absolute_error(context)
            .map(|bound| bound.0)
    }

    pub fn relative_error_f64_bits(&self, context: &Context) -> Option<u64> {
        self.get_attr_proof_require_numerical_refinement_relative_error(context)
            .map(|bound| bound.0)
    }
}

impl Verify for RequireNumericalRefinementOp {
    fn verify(&self, context: &Context) -> Result<()> {
        verify_closed_shape_with_operands(self, context, 4, 3)?;
        required_attr(
            self,
            context,
            self.get_attr_proof_require_numerical_refinement_obligation_id(context),
            "obligation_id",
        )?;
        let absolute = required_attr(
            self,
            context,
            self.get_attr_proof_require_numerical_refinement_absolute_error(context),
            "absolute_error",
        )?;
        let relative = required_attr(
            self,
            context,
            self.get_attr_proof_require_numerical_refinement_relative_error(context),
            "relative_error",
        )?;
        absolute.verify(context)?;
        relative.verify(context)?;
        if f64::from_bits(absolute.0) == 0.0 && f64::from_bits(relative.0) == 0.0 {
            return verify_err!(
                self.loc(context),
                "proof numerical refinement must carry a nonzero finite error bound"
            );
        }
        for operand in 0..4 {
            let value = self.get_operation().deref(context).get_operand(operand);
            if !value
                .get_type(context)
                .deref(context)
                .is::<SemanticScalarType>()
            {
                return verify_err!(
                    self.loc(context),
                    "proof numerical refinement operand {operand} is not kernel.semantic_scalar"
                );
            }
        }
        Ok(())
    }
}

fn verification_error(op: &dyn Op, context: &Context, message: &str) -> pliron::result::Error {
    pliron::verify_error!(op.loc(context), "{message}")
}

fn required_attr<T: Clone>(
    op: &dyn Op,
    context: &Context,
    value: Option<std::cell::Ref<'_, T>>,
    name: &str,
) -> Result<T> {
    value
        .map(|value| (*value).clone())
        .ok_or_else(|| verification_error(op, context, &format!("missing typed {name} attribute")))
}

fn verify_closed_shape(op: &dyn Op, context: &Context, attributes: usize) -> Result<()> {
    verify_closed_shape_with_operands(op, context, 0, attributes)
}

fn verify_closed_shape_with_operands(
    op: &dyn Op,
    context: &Context,
    operands: usize,
    attributes: usize,
) -> Result<()> {
    let operation = op.get_operation();
    let operation = operation.deref(context);
    if operation.get_num_operands() != operands
        || operation.get_num_results() != 0
        || operation.get_num_successors() != 0
        || operation.num_regions() != 0
        || operation.attributes.0.len() != attributes
    {
        return verify_err!(
            op.loc(context),
            "{} has malformed or unbounded structural payload",
            op.get_opid()
        );
    }
    Ok(())
}

/// Explicitly registers every `proof.*` type, attribute, and operation.
pub fn register_dialect(
    context: &mut Context,
) -> std::result::Result<RegistrationOutcome, RegistrationError> {
    if let Some(index) = context.aux_data_map.get(&*PROOF_REGISTRATION_KEY).copied() {
        return match context.aux_data.get(index) {
            Some(marker) if marker.downcast_ref::<RegistrationMarker>().is_some() => {
                Ok(RegistrationOutcome::AlreadyRegistered)
            }
            Some(_) => Err(RegistrationError::MarkerCollision),
            None => Err(RegistrationError::CorruptMarker),
        };
    }

    let dialect_name = DialectName::try_new(DIALECT_NAME).expect("static proof dialect name");
    Dialect::register(context, &dialect_name);

    <ProofIdAttr as Attribute>::register::<ProofIdAttr>(context);
    <PropertyAttr as Attribute>::register::<PropertyAttr>(context);
    <EvidenceStatusAttr as Attribute>::register::<EvidenceStatusAttr>(context);
    <CoveredBoundaryAttr as Attribute>::register::<CoveredBoundaryAttr>(context);
    <ObligationRefType as Type>::register(context);
    <EvidenceRefType as Type>::register(context);
    <ObligationOp as Op>::register(context);
    <EvidenceRefOp as Op>::register(context);
    <RequireRefinementOp as Op>::register(context);
    <RequireTensorRefinementOp as Op>::register(context);
    <RequireEffectRefinementOp as Op>::register(context);
    <AbsoluteErrorF64BitsAttr as Attribute>::register::<AbsoluteErrorF64BitsAttr>(context);
    <RelativeErrorF64BitsAttr as Attribute>::register::<RelativeErrorF64BitsAttr>(context);
    <RequireNumericalRefinementOp as Op>::register(context);

    let marker = context.aux_data.insert(Box::new(RegistrationMarker));
    context
        .aux_data_map
        .insert(PROOF_REGISTRATION_KEY.clone(), marker);
    Ok(RegistrationOutcome::Registered)
}
