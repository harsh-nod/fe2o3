use std::fs;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{MetadataExt, PermissionsExt};
use std::path::PathBuf;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

struct ScratchDirectory(PathBuf);

impl ScratchDirectory {
    fn new() -> Self {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock after Unix epoch")
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "cargo-fe2o3-production-build-config-{}-{nonce}",
            std::process::id()
        ));
        fs::create_dir(&path).expect("create scratch directory");
        Self(path)
    }
}

impl Drop for ScratchDirectory {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

#[test]
fn production_configuration_has_no_compatibility_type_alias() {
    let source = include_str!("../src/build_config.rs");
    assert!(!source.contains("type PreparedBuildConfig = PreparedProductionBuildConfig"));
    let production_api = source
        .split("impl PreparedProductionBuildConfig {")
        .nth(1)
        .expect("production configuration API exists")
        .split("fn prepare_production_manifest")
        .next()
        .expect("production parser follows its API");
    assert!(!production_api.contains("executes_worker_in_rustc"));
    assert!(!production_api.contains("into_production"));
}

#[test]
fn cargo_package_has_no_worker_v2_compiler_surface() {
    let manifest = include_str!("../Cargo.toml");
    for rejected in [
        "worker-v2-fault-injection-test-only",
        "fe2o3-worker-v2-bundle",
        "cargo-fe2o3-worker-v2-fixture",
        "cargo-fe2o3-envelope-input-fixture",
    ] {
        assert!(
            !manifest.contains(rejected),
            "Cargo package still exposes retired compiler surface {rejected}"
        );
    }
    assert!(manifest.contains("application-handoff-fault-injection-test-only"));
    assert!(manifest.contains("worker-v3-envelope-integration-test-only"));

    let package = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    for retired in [
        "src/worker_v2_artifact_container.rs",
        "src/worker_v2_envelope_mode.rs",
        "src/worker_v2_restart.rs",
        "tests/worker_v2_vertical_slice.rs",
    ] {
        assert!(
            !package.join(retired).exists(),
            "retired Cargo compiler implementation remains at {retired}"
        );
    }
}

#[test]
fn cargo_and_application_routes_use_fixed_production_types() {
    let source = include_str!("../src/main.rs");
    let cargo_route = source
        .split("fn cargo_with_backend_result(")
        .nth(1)
        .expect("Cargo production route exists")
        .split("fn authority_sha256_from_environment(")
        .next()
        .expect("Cargo production route has a bounded body");
    assert!(cargo_route.contains("PreparedProductionBuildConfig"));
    assert!(cargo_route.contains("ProductionCargoPlan"));

    let application_route = source
        .split("fn run_application_boundary_result(")
        .nth(1)
        .expect("application production route exists")
        .split("fn run_application_with_handoff(")
        .next()
        .expect("application production route has a bounded body");
    assert!(application_route.contains("RUNNER_EXPECTS_ENVELOPE"));
    assert!(application_route.contains("requires a canonical load envelope"));
}

#[test]
fn production_managed_transaction_has_no_qualification_dispatch() {
    let source = include_str!("../src/binding_wrapper.rs");
    let preparation = source
        .split("fn prepare_production_managed_attempt(")
        .nth(1)
        .expect("direct production preparation exists")
        .split("fn complete_managed_attempt(")
        .next()
        .expect("production completion follows production preparation");
    for rejected in [
        "PreparedManagedWork",
        "ManagedQualificationWork",
        "executes_worker_in_rustc",
        "WorkerV2ResumeStore",
        "row_softmax",
        "qualification",
    ] {
        assert!(
            !preparation.contains(rejected),
            "production preparation contains qualification decision {rejected}"
        );
    }
    assert!(preparation.contains("prepare_managed_production_build"));
    assert!(preparation.contains("production_build,"));
    assert!(!preparation.contains("production_build: Option"));

    let completion = source
        .split("fn complete_managed_attempt_inner(")
        .nth(1)
        .expect("direct production completion exists")
        .split("fn complete_managed_production_build(")
        .next()
        .expect("production build completion follows transaction dispatch");
    assert!(!completion.contains("finish_build_attempt"));
    assert!(!completion.contains("qualification_work"));
    assert!(completion.contains("production_build"));
    assert!(completion.contains("source_isa_observer"));
    assert!(!completion.contains("production_build.take()"));
    assert!(completion.contains("complete_managed_production_build"));

    let environment = source
        .split("fn materialize_production_child_environment(")
        .nth(1)
        .expect("direct production child environment exists")
        .split("fn materialize_closed_child_environment(")
        .next()
        .expect("closed child environment follows production selection");
    assert!(!environment.contains("GeneralGemm"));
    assert!(!environment.contains("WorkerV2"));
    assert!(!environment.contains("qualification"));
}

#[test]
fn production_capability_release_preserves_v1_and_defers_only_selected_v2() {
    let source = include_str!("../src/binding_wrapper.rs");
    let broker = include_str!("../src/capability_broker.rs");
    let intake = source
        .split("fn from_production_environment(")
        .nth(1)
        .expect("direct production capability intake exists")
        .split("fn output_dir(&self)")
        .next()
        .expect("production capability API follows capability intake");
    assert!(intake.contains("release_or_retain_invocation_authority"));
    assert!(intake.contains("false"));
    assert!(intake.contains("from_production_environment_with_source_isa_observer"));
    assert!(!intake.contains("ROW_SOFTMAX"));
    assert!(!intake.contains("FE2O3_QUALIFICATION"));
    let selection = source
        .split("let source_isa_selection =")
        .nth(1)
        .expect("source/ISA unit selection exists")
        .split("scope_managed_rustc_arguments")
        .next()
        .expect("managed argument scoping follows capability release");
    assert!(selection.contains("prepare_production_managed_attempt"));
    assert!(selection.contains("release_invocation_with_source_isa_observer"));
    assert!(selection.contains("config, unit, managed.attempt"));
    assert!(selection.contains("retain_source_isa_observer"));

    assert!(!source.contains("from_qualification_environment"));
    assert!(!source.contains("ManagedQualificationWork"));
    assert!(!source.contains("PreparedBuildConfig"));
    assert!(!broker.contains("S09"));
    assert!(!broker.contains("fn inherit_for_child("));
    assert!(!broker.contains("pinned_cargo_image: File"));
}

#[test]
fn source_isa_observer_lifecycle_is_one_shot_and_prepublication() {
    let source = include_str!("../src/binding_wrapper.rs");
    assert_eq!(
        source
            .matches("admit_production_source_isa_acceptance_summary_v1")
            .count(),
        0,
        "summary mapping belongs exclusively to source_isa_observation.rs"
    );
    let mapping = include_str!("../src/source_isa_observation.rs");
    assert_eq!(
        mapping
            .matches(".admit_production_source_isa_acceptance_summary_v1()")
            .count(),
        1,
        "there is one summary computation entry point"
    );

    let fresh = source
        .split("fn complete_fresh_production_artifact(")
        .nth(1)
        .expect("fresh completion exists")
        .split("fn complete_recovered_production_artifact(")
        .next()
        .expect("recovered completion follows fresh completion");
    let finalization = fresh
        .find("finalize_protected_worker_v3_hsaco_v1")
        .expect("fresh finalization exists");
    let observation = fresh
        .find("emit_finalized_source_isa_observation(&finalized)")
        .expect("fresh observation exists");
    let preparation = fresh
        .find("prepare_protected_worker_v3_hsaco_publication_v1")
        .expect("publication preparation exists");
    assert!(finalization < observation && observation < preparation);

    let recovered = source
        .split("fn complete_recovered_production_artifact(")
        .nth(1)
        .expect("recovered completion exists")
        .split("fn complete_published_production_artifact(")
        .next()
        .expect("published completion follows recovered completion");
    assert!(
        recovered.contains("emit_finalized_source_isa_observation(recovered.finalized_evidence())")
    );
    assert!(source.contains("let Some(sink) = sink.take() else"));

    let ready = source
        .split("fn complete_ready_production_artifact(")
        .nth(1)
        .expect("Ready completion exists")
        .split("fn derive_build_attempt_input_with_config_identity(")
        .next()
        .expect("Ready completion has a bounded body");
    assert!(ready.contains("record.attempt()"));
    assert!(ready.contains("record.plan().finalization().as_bytes()"));
    assert!(ready.contains("emit_ready_source_isa_observation"));
    assert!(!ready.contains("admit_production_source_isa_acceptance_summary_v1"));
}

#[test]
fn cargo_finishes_and_exposes_observer_collection_nonfatally() {
    let source = include_str!("../src/main.rs");
    let run = source
        .split("fn run_cargo_with_backend_inner(")
        .nth(1)
        .expect("Cargo backend route exists")
        .split("struct CapabilityBrokerCompletionV1")
        .next()
        .expect("capability completion follows the device route");
    assert!(run.contains("start_protected_with_source_isa_observer"));
    assert!(run.contains("CapabilityBrokerCompletionV1::new"));
    assert!(source.contains("impl<Value> Drop for ObserverFinishOnDropV1<Value>"));
    assert!(run.contains("capability_broker.finish()"));
    assert!(source.contains("finish_capability_broker_observations"));
    assert!(source.contains("source-isa-observation-collection-v1"));
    assert!(source.contains("authority=observation-only"));
    let aggregate = run
        .split("aggregate_post_spawn_results(")
        .last()
        .expect("post-spawn aggregation exists");
    assert!(!aggregate.contains("source/ISA observer collection"));
}

#[test]
fn production_run_has_one_worker_v3_application_path() {
    let source = include_str!("../src/main.rs");
    let injection = source
        .split("fn inject_production_application_runner(")
        .nth(1)
        .expect("production runner injection exists")
        .split("fn application_runner_executable(")
        .next()
        .expect("production runner injection has a bounded body");
    assert!(injection.contains("RUNNER_EXPECTS_ENVELOPE"));
    assert!(injection.contains("does not permit an intermediate Cargo runner"));
    assert!(!injection.contains("RUNNER_EXPECTS_NO_ENVELOPE"));
    assert!(!injection.contains("expects_envelope"));

    let execution = source
        .split("if runner_count != 0 || !original_runner.is_empty()")
        .nth(1)
        .expect("production runner execution exists")
        .split("fn run_application_with_handoff(")
        .next()
        .expect("production runner execution has a bounded body");
    assert!(execution.contains("requires a canonical load envelope"));
    assert!(execution.contains("run_application_with_handoff"));
    assert!(!execution.contains("RUNNER_EXPECTS_NO_ENVELOPE"));
    assert!(!execution.contains("run_qualification_application_without_handoff"));

    let handoff_source = include_str!("../src/application_handoff.rs");
    assert!(!handoff_source.contains("RUNNER_EXPECTS_NO_ENVELOPE"));
    let exec_source = include_str!("../src/application_exec.rs");
    assert!(!exec_source.contains("configure_closed_descriptor_baseline"));
}

#[test]
fn production_receipt_is_carried_by_one_v2_envelope_through_host_admission() {
    let binding = include_str!("../src/binding_wrapper.rs");
    let intake = include_str!("../src/protected_compiler_handoff_v3.rs");
    let application = include_str!("../src/application_handoff.rs");
    let host_handoff = include_str!("../../fe2o3-host/src/application_descriptor_handoff.rs");
    let host_admission = include_str!("../../fe2o3-host/src/recovered_worker_v3_admission.rs");
    let host_verification =
        include_str!("../../fe2o3-host/src/worker_v3_verification_admission.rs");

    assert!(intake.contains("recover_compiler_execution_receipt_transport_with_currentness_v1"));
    assert!(intake.contains("admit_receipt_transport(&subject, receipt_transport)"));
    let intake_body = intake
        .split("pub(crate) fn consume_after_preflight<T>(")
        .nth(1)
        .expect("fresh protected handoff intake exists");
    let receipt_recovery = intake_body
        .find("recover_compiler_execution_receipt_transport_with_currentness_v1")
        .expect("fresh intake recovers the subject-bound compiler receipt");
    let consumption = intake_body
        .find("consume_compiler_module_handoff_with_currentness_v3")
        .expect("fresh intake consumes the exact handoff");
    assert!(receipt_recovery < consumption);

    assert!(binding.contains("WorkerV3LoadEnvelopeV2::from_published_hsaco_v1"));
    assert!(binding.contains("persist_durable_replay_custody_v2"));
    assert!(binding.contains("recover_worker_v3_load_envelope_v2"));
    assert!(binding.contains("validate_compiler_execution_receipt_carriage"));
    assert!(application.contains("WorkerV3LoadEnvelopeWireV2::decode_canonical"));
    assert!(host_handoff.contains("recover_worker_v3_load_envelope_v2"));
    assert!(host_handoff.contains("WorkerV3LoadEnvelopeWireV2::decode_canonical"));
    assert!(host_admission.contains("RecoveredWorkerV3LoadEnvelopeV2"));
    assert!(host_admission.contains("compiler_execution_subject"));
    assert!(host_admission.contains("compiler_execution_receipt.canonical_bytes()"));
    assert!(host_verification.contains("compiler_execution_subject:"));
    assert!(host_verification.contains("compiler_execution_receipt:"));
    assert!(host_verification.contains("compiler_execution_receipt_bytes"));
    assert!(host_verification.contains("protected_policy_verification_sha256"));
    assert!(host_verification.contains("protected_worker_ledger_verification_sha256"));
    assert!(host_verification.contains("external_rollback_verification_sha256"));
    assert!(host_verification.contains("validate_decision::<K>(&request, &verification)"));

    for production_source in [
        binding,
        application,
        host_handoff,
        host_admission,
        host_verification,
    ] {
        for retired in [
            "WorkerV3LoadEnvelopeV1::from_published_hsaco_v1",
            "persist_durable_replay_custody_v1",
            "recover_worker_v3_load_envelope_v1",
            "WorkerV3LoadEnvelopeWireV1::decode_canonical",
            "RecoveredWorkerV3LoadEnvelopeV1",
        ] {
            assert!(
                !production_source.contains(retired),
                "production source retained receipt-free envelope path {retired}"
            );
        }
    }
}

#[test]
fn production_worker_v3_verifier_is_sealed_and_synthetic_authority_is_test_only() {
    let host = include_str!("../../fe2o3-host/src/worker_v3_verification_admission.rs");
    let host_exports = include_str!("../../fe2o3-host/src/lib.rs");
    let host_manifest = include_str!("../../fe2o3-host/Cargo.toml");
    let cargo_manifest = include_str!("../Cargo.toml");

    assert!(host.contains("verifier_seal::Sealed<K>"));
    assert!(host.contains("pub(crate) fn new("));
    assert!(host.contains("feature = \"worker-v3-verifier-test-support\""));
    assert!(host.contains("pub unsafe trait WorkerV3SyntheticVerifierV1"));
    assert!(host_exports.contains("WorkerV3SyntheticVerifierAdapterV1"));
    assert!(host_exports.contains("WorkerV3SyntheticVerifierV1"));
    assert!(host_manifest.contains("worker-v3-verifier-test-support = []"));

    let test_feature = cargo_manifest
        .split("worker-v3-envelope-integration-test-only = [")
        .nth(1)
        .expect("receipt-bearing integration feature exists")
        .split(']')
        .next()
        .expect("receipt-bearing integration feature is bounded");
    assert!(test_feature.contains("fe2o3-host/worker-v3-verifier-test-support"));

    let default_dependencies = cargo_manifest
        .split("[dependencies]")
        .nth(1)
        .expect("Cargo dependencies exist")
        .split("[dev-dependencies]")
        .next()
        .expect("Cargo dependencies are bounded");
    assert!(!default_dependencies.contains("fe2o3-host/worker-v3-verifier-test-support"));
}

#[test]
fn production_build_has_one_fixed_device_then_host_plan() {
    let source = include_str!("../src/main.rs");
    let plan = include_str!("../src/production_cargo_plan.rs");
    assert!(source.contains("ProductionCargoPlan::new"));
    assert!(source.contains("run_production_host_cargo"));
    assert!(source.contains("host phase uses ordinary rustc"));
    assert!(plan.contains("command: \"build\""));
    assert!(plan.contains("PRODUCTION_GFX942_RUSTC_TARGET_V1"));
    assert!(plan.contains("reject_caller_target"));
    assert!(!plan.contains("enum Pipeline"));
    assert!(!plan.contains("selector"));
}

#[test]
fn ordinary_host_phase_has_no_device_compiler_controls() {
    let source = include_str!("../src/main.rs");
    let host_phase = source
        .split("fn run_production_host_cargo(")
        .nth(1)
        .expect("host phase exists")
        .split("fn scrub_simulation_build_environment(")
        .next()
        .expect("host phase ends before environment scrubbing helpers");

    for removed in [
        ".env_remove(BACKEND_ENV)",
        ".env_remove(TARGET_ENV)",
        ".env_remove(build_config::PRODUCTION_BUILD_CONFIG_ENV)",
        ".env_remove(build_config::PRODUCTION_BUILD_CONFIG_V2_ENV)",
        ".env_remove(build_config::PRODUCTION_BUILD_EXPECTED_ID_ENV)",
        ".env_remove(build_config::PRODUCTION_BUILD_EXPECTED_ID_V2_ENV)",
        ".env_remove(build_config::QUALIFICATION_ORACLE_ENV)",
        ".env_remove(capability_broker::CAPABILITY_BROKER_ENV)",
    ] {
        assert!(host_phase.contains(removed), "missing {removed}");
    }
    assert!(host_phase.contains("configure_pinned_rustc_child"));
    assert!(host_phase.contains("generation.reject_if_substituted"));
    assert!(!host_phase.contains("configure_production_target_environment"));
}

#[test]
fn production_runner_rejects_no_envelope_marker() {
    let scratch = ScratchDirectory::new();
    fs::set_permissions(&scratch.0, fs::Permissions::from_mode(0o700))
        .expect("make scratch generation private");
    let mut owner_record = b"fe2o3-owned-v1\0".to_vec();
    owner_record.extend_from_slice(&[1_u8; 16]);
    let owner_path = scratch.0.join(".fe2o3-owned-v1");
    fs::write(&owner_path, owner_record).expect("write generation owner record");
    fs::set_permissions(&owner_path, fs::Permissions::from_mode(0o600))
        .expect("make generation owner record private");
    let metadata = fs::metadata(&scratch.0).expect("stat scratch directory");
    let encoded_path = scratch
        .0
        .as_os_str()
        .as_bytes()
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect::<String>();
    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .args([
            "__fe2o3-runner-v1".to_owned(),
            "3".to_owned(),
            encoded_path,
            metadata.dev().to_string(),
            metadata.ino().to_string(),
            "none".to_owned(),
            "0".to_owned(),
            "/bin/true".to_owned(),
        ])
        .output()
        .expect("run production application boundary");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("production application runner requires the Worker V3 envelope marker"),
        "{stderr}"
    );
}

#[test]
fn production_driver_rejects_qualification_before_target_preparation() {
    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .env("FE2O3_QUALIFICATION_ORACLE_V1", "kernel-ir-v1")
        .args(["build", "--target", "host-placeholder"])
        .output()
        .expect("run cargo-fe2o3");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("FE2O3_QUALIFICATION_ORACLE_V1 is unavailable")
            && stderr.contains("production compilation has no selector"),
        "{stderr}"
    );
    assert!(!stderr.contains("production compilation requires exact FE2O3_TARGET"));
}

#[test]
fn production_manifest_rejects_qualification_envelope_fields() {
    let scratch = ScratchDirectory::new();
    let manifest = scratch.0.join("build-config.json");
    fs::write(
        &manifest,
        br#"{"candidate_output_max_bytes":1,"format":"fe2o3-production-build-config-v1","limits":{},"link_options":[],"load_envelope":"required","load_envelope_inputs":{},"providers":[],"units":[],"worker":{}}"#,
    )
    .expect("write manifest");

    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .env("FE2O3_TARGET", "gfx942")
        .env("FE2O3_PRODUCTION_BUILD_CONFIG_V1", &manifest)
        .arg("build")
        .output()
        .expect("run cargo-fe2o3");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("production configuration must contain exactly the fields")
            && stderr.contains("load_envelope"),
        "{stderr}"
    );
}

#[test]
fn production_config_versions_are_mutually_exclusive_before_either_manifest_is_read() {
    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .env("FE2O3_TARGET", "gfx942")
        .env(
            "FE2O3_PRODUCTION_BUILD_CONFIG_V1",
            "/does/not/exist/production-v1.json",
        )
        .env(
            "FE2O3_PRODUCTION_BUILD_CONFIG_V2",
            "/does/not/exist/production-v2.json",
        )
        .arg("build")
        .output()
        .expect("run cargo-fe2o3");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("FE2O3_PRODUCTION_BUILD_CONFIG_V1")
            && stderr.contains("FE2O3_PRODUCTION_BUILD_CONFIG_V2")
            && stderr.contains("mutually exclusive"),
        "{stderr}"
    );
    assert!(!stderr.contains("does/not/exist"), "{stderr}");
}

#[test]
fn production_v2_manifest_requires_the_exact_source_isa_observation() {
    let scratch = ScratchDirectory::new();
    let manifest = scratch.0.join("build-config-v2.json");
    fs::write(
        &manifest,
        br#"{"candidate_output_max_bytes":1,"format":"fe2o3-production-build-config-v2","limits":{},"link_options":[],"observation":{"kind":"source-isa-summary-v2"},"providers":[],"units":[],"worker":{}}"#,
    )
    .expect("write manifest");

    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .env("FE2O3_TARGET", "gfx942")
        .env("FE2O3_PRODUCTION_BUILD_CONFIG_V2", &manifest)
        .arg("build")
        .output()
        .expect("run cargo-fe2o3");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("observation.kind must be exactly \"source-isa-summary-v1\""),
        "{stderr}"
    );
    assert!(!stderr.contains("worker.path"), "{stderr}");
}

#[test]
fn production_rejects_worker_v2_namespace_before_reading_its_manifest() {
    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .env("FE2O3_TARGET", "gfx942")
        .env(
            "FE2O3_WORKER_V2_CONFIG_V2",
            "/does/not/exist/worker-v2-config.json",
        )
        .arg("build")
        .output()
        .expect("run cargo-fe2o3");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("FE2O3_WORKER_V2_CONFIG_V2 is qualification-only")
            && stderr.contains("FE2O3_PRODUCTION_BUILD_CONFIG_V1")
            && stderr.contains("FE2O3_PRODUCTION_BUILD_CONFIG_V2"),
        "{stderr}"
    );
    assert!(!stderr.contains("does/not/exist"), "{stderr}");
}

#[test]
fn production_driver_rejects_caller_target_selection() {
    let output = Command::new(env!("CARGO_BIN_EXE_cargo-fe2o3"))
        .env_clear()
        .env("FE2O3_TARGET", "gfx942")
        .args(["build", "--target", "amdgcn-amd-amdhsa"])
        .output()
        .expect("run cargo-fe2o3");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("owns device and host target selection"),
        "{stderr}"
    );
}
