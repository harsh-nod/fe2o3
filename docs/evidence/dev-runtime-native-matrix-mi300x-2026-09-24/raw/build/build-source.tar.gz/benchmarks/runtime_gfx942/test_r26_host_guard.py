#!/usr/bin/env python3

from __future__ import annotations

import errno
import hashlib
import importlib.util
import io
import os
import pathlib
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from contextlib import ExitStack, redirect_stderr
from unittest import mock


GUARD_PATH = pathlib.Path(__file__).with_name("r26-host-guard.py")
SPEC = importlib.util.spec_from_file_location("fe2o3_r26_host_guard", GUARD_PATH)
assert SPEC is not None and SPEC.loader is not None
GUARD = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = GUARD
SPEC.loader.exec_module(GUARD)


class TopologyFixture:
    bdf = "0000:05:00.0"
    unique_id = "0x6ced1647a296545c"

    def __init__(self, root: pathlib.Path) -> None:
        self.pci_root = root / "pci"
        self.topology_root = root / "topology"
        self.status_path = root / "status"
        device = self.pci_root / self.bdf
        device.mkdir(parents=True)
        (device / "vendor").write_text("0x1002\n", encoding="ascii")
        (device / "unique_id").write_text(
            self.unique_id.removeprefix("0x") + "\n", encoding="ascii"
        )
        (device / "numa_node").write_text("0\n", encoding="ascii")
        (device / "local_cpulist").write_text("0-7\n", encoding="ascii")
        nodes = self.topology_root / "nodes"
        cpu = nodes / "0"
        cpu.mkdir(parents=True)
        (cpu / "gpu_id").write_text("0\n", encoding="ascii")
        (cpu / "properties").write_text("cpu_cores_count 8\n", encoding="ascii")
        gpu = nodes / "2"
        gpu.mkdir()
        (gpu / "gpu_id").write_text("28851\n", encoding="ascii")
        (gpu / "properties").write_text(
            "domain 0\n"
            "location_id 1280\n"
            f"unique_id {int(self.unique_id, 16)}\n"
            "vendor_id 4098\n"
            "gfx_target_version 90402\n",
            encoding="ascii",
        )
        self.status_path.write_text(
            "Name:\ttest\nCpus_allowed_list:\t0-7,48-55\nMems_allowed_list:\t0-1\n",
            encoding="ascii",
        )

    def record(self) -> str:
        return GUARD.topology_record(
            gpu_index=0,
            pci_bdf=self.bdf,
            unique_id=self.unique_id,
            pci_root=self.pci_root,
            topology_root=self.topology_root,
            status_path=self.status_path,
        )


def fields(record: str) -> tuple[str, dict[str, str]]:
    prefix, *tokens = record.split()
    return prefix, dict(token.split("=", 1) for token in tokens)


def write_process(
    proc_root: pathlib.Path,
    pid: int,
    *,
    ppid: int,
    process_group: int,
    start_time: int,
) -> None:
    directory = proc_root / str(pid)
    directory.mkdir(parents=True)
    tail = [
        "S",
        str(ppid),
        str(process_group),
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "0",
        "1",
        "0",
        str(start_time),
    ]
    (directory / "stat").write_text(
        f"{pid} (test process) {' '.join(tail)}\n", encoding="ascii"
    )


def write_queue(kfd_root: pathlib.Path, pid: int, queue: int, gpu_id: int) -> None:
    directory = kfd_root / str(pid) / "queues" / str(queue)
    directory.mkdir(parents=True)
    (directory / "gpuid").write_text(f"{gpu_id}\n", encoding="ascii")


def raise_guard_os_error(error_number: int, description: str) -> None:
    error = OSError(error_number, os.strerror(error_number))
    raise GUARD.GuardError(f"cannot {description}: {error}") from error


class TopologyTests(unittest.TestCase):
    def test_exact_topology_produces_sealed_placement(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            fixture = TopologyFixture(pathlib.Path(temporary))
            record = fixture.record()
        prefix, observed = fields(record)
        self.assertEqual(prefix, "topology")
        self.assertEqual(observed["schema"], GUARD.TOPOLOGY_SCHEMA)
        self.assertEqual(
            observed["placement"],
            "taskset-cpulist-then-numactl-physcpubind-membind-v1",
        )
        self.assertEqual(observed["pci_bdf"], fixture.bdf)
        self.assertEqual(observed["unique_id"], fixture.unique_id)
        self.assertEqual(observed["measurement_cpu_list"], "0-7")
        self.assertEqual(observed["observer_cpu"], "55")
        self.assertEqual(observed["kfd_node"], "2")
        self.assertEqual(observed["kfd_gpu_id"], "28851")
        digest = observed.pop("topology_sha256")
        payload = GUARD._record("topology", observed) + "\n"
        self.assertEqual(digest, hashlib.sha256(payload.encode()).hexdigest())

    def test_reserves_one_local_cpu_when_no_nonlocal_cpu_is_allowed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            fixture = TopologyFixture(pathlib.Path(temporary))
            fixture.status_path.write_text(
                "Cpus_allowed_list:\t0-7\nMems_allowed_list:\t0\n",
                encoding="ascii",
            )
            _, observed = fields(fixture.record())
        self.assertEqual(observed["measurement_cpu_list"], "0-6")
        self.assertEqual(observed["observer_cpu"], "7")

    def test_rejects_identity_and_kfd_location_substitution(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            fixture = TopologyFixture(pathlib.Path(temporary))
            device = fixture.pci_root / fixture.bdf
            (device / "unique_id").write_text("0123456789abcdef\n", encoding="ascii")
            with self.assertRaisesRegex(GUARD.GuardError, "PCI unique ID"):
                fixture.record()

        with tempfile.TemporaryDirectory() as temporary:
            fixture = TopologyFixture(pathlib.Path(temporary))
            properties = fixture.topology_root / "nodes" / "2" / "properties"
            properties.write_text(
                properties.read_text(encoding="ascii").replace(
                    "location_id 1280", "location_id 9728"
                ),
                encoding="ascii",
            )
            with self.assertRaisesRegex(GUARD.GuardError, "one exact KFD node"):
                fixture.record()

    def test_rejects_disallowed_local_cpu_or_memory_node(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            fixture = TopologyFixture(pathlib.Path(temporary))
            fixture.status_path.write_text(
                "Cpus_allowed_list:\t48-55\nMems_allowed_list:\t0-1\n",
                encoding="ascii",
            )
            with self.assertRaisesRegex(GUARD.GuardError, "local CPU"):
                fixture.record()

        with tempfile.TemporaryDirectory() as temporary:
            fixture = TopologyFixture(pathlib.Path(temporary))
            fixture.status_path.write_text(
                "Cpus_allowed_list:\t0-7\nMems_allowed_list:\t1\n",
                encoding="ascii",
            )
            with self.assertRaisesRegex(GUARD.GuardError, "Mems_allowed_list"):
                fixture.record()


class QueueCensusTests(unittest.TestCase):
    def test_live_authentication_uses_captured_leaf_and_types_departure(self) -> None:
        root = GUARD.ProcessObservation(1, 100, 1000)
        child = GUARD.ProcessObservation(100, 100, 1001)
        for pid, observations in (
            (100, [root, None]),
            (101, [child, root, None]),
        ):
            with (
                self.subTest(pid=pid),
                mock.patch.object(
                    GUARD, "_read_process", side_effect=observations
                ) as read_process,
            ):
                authentication = GUARD._target_process_identity(
                    pathlib.Path("/proc"), pid, 100, 1000
                )
            self.assertEqual(authentication.identity, observations[0])
            self.assertTrue(authentication.departed)
            self.assertEqual(read_process.call_count, len(observations))

    def test_live_authentication_rejects_reuse_or_reparenting(self) -> None:
        root = GUARD.ProcessObservation(1, 100, 1000)
        child = GUARD.ProcessObservation(100, 100, 1001)
        changed = (
            [root, GUARD.ProcessObservation(1, 100, 2000)],
            [root, GUARD.ProcessObservation(1, 999, 1000)],
            [child, root, GUARD.ProcessObservation(1, 100, 1001)],
        )
        for observations in changed:
            with (
                self.subTest(observations=observations),
                mock.patch.object(GUARD, "_read_process", side_effect=observations),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD._target_process_identity(
                    pathlib.Path("/proc"),
                    100 if observations[0] == root else 101,
                    100,
                    1000,
                )

    def test_live_authentication_preserves_stable_root_and_descendant(self) -> None:
        root = GUARD.ProcessObservation(1, 100, 1000)
        child = GUARD.ProcessObservation(100, 100, 1001)
        for pid, observations in (
            (100, [root, root]),
            (101, [child, root, child]),
        ):
            with (
                self.subTest(pid=pid),
                mock.patch.object(GUARD, "_read_process", side_effect=observations),
            ):
                authentication = GUARD._target_process_identity(
                    pathlib.Path("/proc"), pid, 100, 1000
                )
            self.assertEqual(authentication.identity, observations[0])
            self.assertFalse(authentication.departed)

    def test_live_authentication_does_not_authenticate_missing_ancestry(self) -> None:
        child = GUARD.ProcessObservation(100, 100, 1001)
        for observations in ([None], [child, None]):
            with (
                self.subTest(observations=observations),
                mock.patch.object(GUARD, "_read_process", side_effect=observations),
            ):
                authentication = GUARD._target_process_identity(
                    pathlib.Path("/proc"), 101, 100, 1000
                )
            self.assertIsNone(authentication.identity)
            self.assertFalse(authentication.departed)

    def test_esrch_is_absence_at_each_live_authentication_read_seam(self) -> None:
        with mock.patch.object(
            pathlib.Path,
            "read_text",
            side_effect=ProcessLookupError("process exited"),
        ):
            authentication = GUARD._target_process_identity(
                pathlib.Path("/proc"), 100, 100, 1000
            )
        self.assertIsNone(authentication.identity)
        self.assertFalse(authentication.departed)

        with tempfile.TemporaryDirectory() as temporary:
            proc_root = pathlib.Path(temporary) / "proc"
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_process(proc_root, 101, ppid=100, process_group=100, start_time=1001)
            root_stat = proc_root / "100" / "stat"
            original_read_text = pathlib.Path.read_text

            def ancestry_esrch(
                path: pathlib.Path, *args: object, **kwargs: object
            ) -> str:
                if path == root_stat:
                    raise ProcessLookupError("ancestor exited")
                return original_read_text(path, *args, **kwargs)

            with mock.patch.object(pathlib.Path, "read_text", new=ancestry_esrch):
                authentication = GUARD._target_process_identity(
                    proc_root, 101, 100, 1000
                )
            self.assertIsNone(authentication.identity)
            self.assertFalse(authentication.departed)

            root_reads = 0

            def closing_esrch(
                path: pathlib.Path, *args: object, **kwargs: object
            ) -> str:
                nonlocal root_reads
                if path == root_stat:
                    root_reads += 1
                    if root_reads == 2:
                        raise ProcessLookupError("target exited")
                return original_read_text(path, *args, **kwargs)

            with mock.patch.object(pathlib.Path, "read_text", new=closing_esrch):
                authentication = GUARD._target_process_identity(
                    proc_root, 100, 100, 1000
                )
            self.assertEqual(
                authentication.identity,
                GUARD.ProcessObservation(1, 100, 1000),
            )
            self.assertTrue(authentication.departed)

    def test_live_authentication_propagates_process_read_failure(self) -> None:
        for error in (PermissionError(13, "denied"), OSError(5, "I/O error")):
            with (
                self.subTest(error=error),
                mock.patch.object(pathlib.Path, "read_text", side_effect=error),
                self.assertRaisesRegex(
                    GUARD.GuardError, "cannot read process identity"
                ),
            ):
                GUARD._target_process_identity(pathlib.Path("/proc"), 100, 100, 1000)

    def test_invalid_process_identity_requires_discarding_the_attempt(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            proc_root = pathlib.Path(temporary) / "proc"
            write_process(
                proc_root,
                100,
                ppid=1,
                process_group=-1,
                start_time=1000,
            )
            with self.assertRaises(GUARD.RetryableCensusError) as failure:
                GUARD._read_process(proc_root, 100)
        self.assertEqual(failure.exception.reason, "process-identity-invalid")
        self.assertEqual(failure.exception.pid, 100)
        self.assertIn("negative process identity", str(failure.exception))

    def test_retryable_census_has_a_canonical_record_and_distinct_exit(self) -> None:
        failure = GUARD.RetryableCensusError(
            "process-directory-disappeared-before-authentication",
            123,
            "discard this process attempt",
        )
        parser = mock.Mock()
        parser.parse_args.return_value = mock.Mock()
        stderr = io.StringIO()
        with (
            mock.patch.object(GUARD, "_build_parser", return_value=parser),
            mock.patch.object(GUARD, "_run", side_effect=failure),
            mock.patch.object(GUARD.signal, "signal"),
            redirect_stderr(stderr),
        ):
            status = GUARD.main([])
        self.assertEqual(status, 75)
        self.assertEqual(status, GUARD.RETRYABLE_CENSUS_EXIT)
        self.assertEqual(
            stderr.getvalue(),
            "retryable-census schema=fe2o3.r55-kfd-census-retry.v1 "
            "reason=process-directory-disappeared-before-authentication pid=123\n",
        )

    def test_final_departure_confirmation_accepts_esrch(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            process_path = root / "kfd-proc" / "100"
            process_path.mkdir(parents=True)
            process_path_identity = GUARD._directory_identity(
                process_path, "KFD process directory"
            )
            self.assertIsNotNone(process_path_identity)
            process_binding = GUARD._open_directory_binding(
                process_path, "KFD process directory"
            )
            self.assertIsNotNone(process_binding)
            assert process_binding is not None
            with (
                process_binding,
                mock.patch.object(
                    pathlib.Path,
                    "read_text",
                    side_effect=ProcessLookupError("target exited"),
                ),
            ):
                GUARD._confirm_departed_target(
                    proc_root=root / "proc",
                    pid=100,
                    process_binding=process_binding,
                )

    def test_kfd_esrch_is_not_typed_as_tolerable_disappearance(self) -> None:
        with (
            mock.patch.object(
                pathlib.Path,
                "read_bytes",
                side_effect=ProcessLookupError("KFD gpuid ESRCH"),
            ),
            self.assertRaises(GUARD.GuardError) as gpuid_failure,
        ):
            GUARD._read_text(pathlib.Path("/kfd/gpuid"), "KFD queue GPU ID")
        self.assertIsInstance(gpuid_failure.exception.__cause__, ProcessLookupError)
        self.assertFalse(GUARD._disappeared_during_census(gpuid_failure.exception))

        with (
            mock.patch.object(
                GUARD.os,
                "scandir",
                side_effect=ProcessLookupError("KFD queue enumeration ESRCH"),
            ),
            self.assertRaises(GUARD.GuardError) as enumeration_failure,
        ):
            GUARD._live_queue_directories(
                pathlib.Path("/kfd/queues"), "KFD queue directory", 1, True
            )
        self.assertIsInstance(
            enumeration_failure.exception.__cause__, ProcessLookupError
        )
        self.assertFalse(
            GUARD._disappeared_during_census(enumeration_failure.exception)
        )

    def test_initial_authentication_departure_is_reconfirmed_after_census(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            with mock.patch.object(
                GUARD,
                "_read_process",
                side_effect=[root_observation, None, None, None],
            ) as read_process:
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [])
        self.assertEqual(read_process.call_count, 4)

    def test_initial_authentication_departure_rejects_pid_recreation(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        replacement = GUARD.ProcessObservation(1, 100, 2000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            with (
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    side_effect=[root_observation, None, replacement],
                ),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_initial_departure_is_sticky_across_exact_identity_aba(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            with (
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    side_effect=[
                        root_observation,
                        None,
                        root_observation,
                        root_observation,
                    ],
                ),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_post_census_departure_is_reconfirmed(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            with mock.patch.object(
                GUARD,
                "_read_process",
                side_effect=[
                    root_observation,
                    root_observation,
                    root_observation,
                    None,
                    None,
                ],
            ):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [])

    def test_post_census_departure_rejects_recreation_before_decision(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            with (
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    side_effect=[
                        root_observation,
                        root_observation,
                        root_observation,
                        None,
                        root_observation,
                    ],
                ),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_foreign_owner_cannot_launder_through_departed_target_replacement(
        self,
    ) -> None:
        foreign_observation = GUARD.ProcessObservation(1, 200, 2000)
        init_observation = GUARD.ProcessObservation(0, 1, 1)
        replacement = GUARD.ProcessObservation(100, 100, 3000)
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 200, 0, 28851)
            with mock.patch.object(
                GUARD,
                "_read_process",
                side_effect=[
                    foreign_observation,
                    init_observation,
                    replacement,
                    root_observation,
                    None,
                ],
            ):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [(200, 0)])

    def test_departed_target_rejects_kfd_process_path_replacement(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            process_path = kfd_root / "100"
            old_process_path = kfd_root / "100-old"
            gpu_id_path = process_path / "queues" / "0" / "gpuid"
            original = GUARD._read_text

            def replace_process_path(path: pathlib.Path, description: str) -> str:
                value = original(path, description)
                if path == gpu_id_path:
                    process_path.rename(old_process_path)
                    (process_path / "queues").mkdir(parents=True)
                return value

            with (
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    side_effect=[root_observation, None, None, None],
                ),
                mock.patch.object(
                    GUARD, "_read_text", side_effect=replace_process_path
                ),
                self.assertRaisesRegex(
                    GUARD.GuardError, "process directory.*identity changed"
                ),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_whitelists_target_tree_and_rejects_only_foreign_selected_gpu(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_process(proc_root, 101, ppid=100, process_group=100, start_time=1001)
            write_process(proc_root, 200, ppid=1, process_group=200, start_time=2000)
            write_process(proc_root, 201, ppid=1, process_group=201, start_time=2001)
            write_queue(kfd_root, 100, 0, 28851)
            write_queue(kfd_root, 101, 1, 28851)
            write_queue(kfd_root, 200, 2, 28851)
            write_queue(kfd_root, 201, 3, 23018)
            foreign = GUARD.foreign_selected_gpu_queues(
                kfd_proc_root=kfd_root,
                proc_root=proc_root,
                selected_gpu_id=28851,
                root_pid=100,
                root_start_time=1000,
            )
            target, classified_foreign = GUARD.classify_selected_gpu_queues(
                kfd_proc_root=kfd_root,
                proc_root=proc_root,
                selected_gpu_id=28851,
                root_pid=100,
                root_start_time=1000,
            )
        self.assertEqual(foreign, [(200, 2)])
        self.assertEqual(target, [(100, 0), (101, 1)])
        self.assertEqual(classified_foreign, foreign)

    def test_pid_reuse_is_not_whitelisted(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=2000)
            write_queue(kfd_root, 100, 0, 28851)
            foreign = GUARD.foreign_selected_gpu_queues(
                kfd_proc_root=kfd_root,
                proc_root=proc_root,
                selected_gpu_id=28851,
                root_pid=100,
                root_start_time=1000,
            )
        self.assertEqual(foreign, [(100, 0)])

    def test_missing_process_for_queue_owner_is_foreign(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 101, 0, 28851)
            target, foreign = GUARD.classify_selected_gpu_queues(
                kfd_proc_root=kfd_root,
                proc_root=proc_root,
                selected_gpu_id=28851,
                root_pid=100,
                root_start_time=1000,
            )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [(101, 0)])

    def test_live_classifier_tolerates_confirmed_target_queue_disappearance(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queues_path = kfd_root / "100" / "queues"
            queue_path = queues_path / "0"
            original = GUARD._live_queue_directories

            def enumerate_then_remove(
                path: pathlib.Path,
                description: str,
                maximum_entries: int,
                target_owned: bool,
            ) -> tuple[list[tuple[int, pathlib.Path]], bool]:
                entries = original(path, description, maximum_entries, target_owned)
                if path == queues_path:
                    (queue_path / "gpuid").unlink()
                    queue_path.rmdir()
                return entries

            with mock.patch.object(
                GUARD, "_live_queue_directories", side_effect=enumerate_then_remove
            ):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [])

    def test_live_classifier_tolerates_target_gpuid_enodev_after_queue_exit(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"
            original = GUARD._read_text

            def enodev_after_queue_exit(path: pathlib.Path, description: str) -> str:
                if path == gpu_id_path:
                    gpu_id_path.unlink()
                    queue_path.rmdir()
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                return original(path, description)

            with mock.patch.object(
                GUARD, "_read_text", side_effect=enodev_after_queue_exit
            ):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [])

    def test_live_classifier_waits_for_deactivated_target_queue_unlink(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"
            now_ns = 0
            sleeps: list[int] = []

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            def unlink_during_sleep(seconds: float) -> None:
                nonlocal now_ns
                duration_ns = int(seconds * 1_000_000_000)
                sleeps.append(duration_ns)
                now_ns += duration_ns
                gpu_id_path.unlink()
                queue_path.rmdir()

            with mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=unlink_during_sleep,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [])
        self.assertEqual(sleeps, [GUARD.QUEUE_ENODEV_DISAPPEAR_POLL_NS])

    def test_live_classifier_accepts_sticky_departure_during_enodev_unlink(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"
            process_stat_path = proc_root / "100" / "stat"
            now_ns = 0
            departed = False

            def depart_on_enodev(path: pathlib.Path, _description: str) -> str:
                nonlocal departed
                if path == gpu_id_path:
                    if not departed:
                        process_stat_path.unlink()
                        departed = True
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            def unlink_during_sleep(seconds: float) -> None:
                nonlocal now_ns
                now_ns += int(seconds * 1_000_000_000)
                gpu_id_path.unlink()
                queue_path.rmdir()

            with mock.patch.object(GUARD, "_read_text", side_effect=depart_on_enodev):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=unlink_during_sleep,
                )
        self.assertTrue(departed)
        self.assertEqual(target, [])
        self.assertEqual(foreign, [])

    def test_enodev_helper_departure_rejects_exact_identity_aba(self) -> None:
        target_identity = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"
            now_ns = 0

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            def unlink_during_sleep(seconds: float) -> None:
                nonlocal now_ns
                now_ns += int(seconds * 1_000_000_000)
                gpu_id_path.unlink()
                queue_path.rmdir()

            process_observations = [
                target_identity,
                target_identity,
                target_identity,
                target_identity,
                None,
                None,
                None,
                None,
                target_identity,
                target_identity,
            ]
            with (
                mock.patch.object(
                    GUARD, "_read_process", side_effect=process_observations
                ) as read_process,
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=unlink_during_sleep,
                )
            self.assertEqual(read_process.call_count, len(process_observations))

    def test_enodev_departure_remains_sticky_across_multiple_queues(self) -> None:
        target_identity = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            write_queue(kfd_root, 100, 1, 28851)
            first_queue = kfd_root / "100" / "queues" / "0"
            gpu_id_paths = {
                first_queue / "gpuid",
                kfd_root / "100" / "queues" / "1" / "gpuid",
            }
            now_ns = 0

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path in gpu_id_paths:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            def unlink_first_during_sleep(seconds: float) -> None:
                nonlocal now_ns
                now_ns += int(seconds * 1_000_000_000)
                (first_queue / "gpuid").unlink()
                first_queue.rmdir()

            process_observations = [
                target_identity,
                target_identity,
                target_identity,
                target_identity,
                None,
                None,
                None,
                None,
                target_identity,
                target_identity,
            ]
            with (
                mock.patch.object(
                    GUARD, "_read_process", side_effect=process_observations
                ) as read_process,
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=unlink_first_during_sleep,
                )
            self.assertEqual(read_process.call_count, len(process_observations))

    def test_live_classifier_rejects_target_gpuid_enodev_while_queue_exists(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            gpu_id_path = kfd_root / "100" / "queues" / "0" / "gpuid"
            original = GUARD._read_text
            now_ns = 0
            sleeps: list[int] = []

            def enodev_while_present(path: pathlib.Path, description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                return original(path, description)

            def advance_clock(seconds: float) -> None:
                nonlocal now_ns
                duration_ns = int(seconds * 1_000_000_000)
                sleeps.append(duration_ns)
                now_ns += duration_ns

            with (
                mock.patch.object(
                    GUARD, "_read_text", side_effect=enodev_while_present
                ),
                self.assertRaisesRegex(GUARD.GuardError, "remained present"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=advance_clock,
                )
            self.assertTrue(gpu_id_path.parent.is_dir())
            self.assertEqual(sum(sleeps), GUARD.QUEUE_ENODEV_DISAPPEAR_TIMEOUT_NS)
            self.assertLess(
                GUARD.QUEUE_ENODEV_DISAPPEAR_TIMEOUT_NS,
                GUARD.MAX_OBSERVATION_GAP_NS,
            )
            self.assertTrue(
                all(
                    duration <= GUARD.QUEUE_ENODEV_DISAPPEAR_POLL_NS
                    for duration in sleeps
                )
            )

    def test_enodev_nonadvancing_clock_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            gpu_id_path = kfd_root / "100" / "queues" / "0" / "gpuid"

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            with (
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(GUARD.GuardError, "clock did not advance"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: 0,
                    sleeper=lambda _seconds: None,
                )

    def test_enodev_sleep_overshoot_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            gpu_id_path = kfd_root / "100" / "queues" / "0" / "gpuid"
            now_ns = 0

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            def oversleep(_seconds: float) -> None:
                nonlocal now_ns
                now_ns += GUARD.QUEUE_ENODEV_DISAPPEAR_TIMEOUT_NS + 1

            with (
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(GUARD.GuardError, "remained present"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=oversleep,
                )

    def test_enodev_disappearance_at_deadline_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"
            now_ns = 0

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            def unlink_at_deadline(_seconds: float) -> None:
                nonlocal now_ns
                now_ns = GUARD.QUEUE_ENODEV_DISAPPEAR_TIMEOUT_NS
                gpu_id_path.unlink()
                queue_path.rmdir()

            with (
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(GUARD.GuardError, "remained present"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: now_ns,
                    sleeper=unlink_at_deadline,
                )
            self.assertFalse(queue_path.exists())

    def test_directory_bindings_reach_final_authentication_and_close(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            opened_fds: list[int] = []
            original_open = GUARD._open_directory_binding
            original_authenticate = GUARD._target_process_identity

            def capture_binding(path: pathlib.Path, description: str) -> object:
                binding = original_open(path, description)
                if binding is not None:
                    opened_fds.append(binding.fd)
                return binding

            def authenticate(*args: object, **kwargs: object) -> object:
                if kwargs.get("expected_identity") is not None:
                    self.assertEqual(len(opened_fds), 2)
                    for fd in opened_fds:
                        os.fstat(fd)
                return original_authenticate(*args, **kwargs)

            with (
                mock.patch.object(
                    GUARD, "_open_directory_binding", side_effect=capture_binding
                ),
                mock.patch.object(
                    GUARD, "_target_process_identity", side_effect=authenticate
                ),
            ):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
            self.assertEqual(target, [(100, 0)])
            self.assertEqual(foreign, [])
            self.assertEqual(len(opened_fds), 2)
            for fd in opened_fds:
                with self.assertRaises(OSError) as closed:
                    os.fstat(fd)
                self.assertEqual(closed.exception.errno, errno.EBADF)

    def test_directory_bindings_close_after_enodev_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            gpu_id_path = kfd_root / "100" / "queues" / "0" / "gpuid"
            opened_fds: list[int] = []
            original_open = GUARD._open_directory_binding

            def capture_binding(path: pathlib.Path, description: str) -> object:
                binding = original_open(path, description)
                if binding is not None:
                    opened_fds.append(binding.fd)
                return binding

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            with (
                mock.patch.object(
                    GUARD, "_open_directory_binding", side_effect=capture_binding
                ),
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(GUARD.GuardError, "clock did not advance"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: 0,
                    sleeper=lambda _seconds: None,
                )
            self.assertEqual(len(opened_fds), 2)
            for fd in opened_fds:
                with self.assertRaises(OSError) as closed:
                    os.fstat(fd)
                self.assertEqual(closed.exception.errno, errno.EBADF)

    def test_live_classifier_rejects_untrusted_gpuid_enodev_after_queue_exit(
        self,
    ) -> None:
        for owner_kind in ("foreign", "unknown"):
            with self.subTest(owner_kind=owner_kind):
                with tempfile.TemporaryDirectory() as temporary:
                    root = pathlib.Path(temporary)
                    proc_root = root / "proc"
                    kfd_root = root / "kfd-proc"
                    kfd_root.mkdir()
                    write_process(
                        proc_root, 100, ppid=1, process_group=100, start_time=1000
                    )
                    if owner_kind == "foreign":
                        write_process(
                            proc_root,
                            200,
                            ppid=1,
                            process_group=200,
                            start_time=2000,
                        )
                    write_queue(kfd_root, 200, 0, 28851)
                    queue_path = kfd_root / "200" / "queues" / "0"
                    gpu_id_path = queue_path / "gpuid"
                    original = GUARD._read_text

                    def enodev_after_queue_exit(
                        path: pathlib.Path, description: str
                    ) -> str:
                        if path == gpu_id_path:
                            gpu_id_path.unlink()
                            queue_path.rmdir()
                            raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                        return original(path, description)

                    with (
                        mock.patch.object(
                            GUARD,
                            "_read_text",
                            side_effect=enodev_after_queue_exit,
                        ),
                        self.assertRaisesRegex(GUARD.GuardError, "cannot read"),
                    ):
                        GUARD.classify_selected_gpu_queues(
                            kfd_proc_root=kfd_root,
                            proc_root=proc_root,
                            selected_gpu_id=28851,
                            root_pid=100,
                            root_start_time=1000,
                        )

    def test_kfd_enodev_outside_live_gpuid_read_remains_fatal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queues_path = kfd_root / "100" / "queues"
            original_scandir = GUARD.os.scandir

            def enodev_during_queue_enumeration(path: os.PathLike[str]) -> object:
                if pathlib.Path(path) == queues_path:
                    raise OSError(errno.ENODEV, os.strerror(errno.ENODEV))
                return original_scandir(path)

            with (
                mock.patch.object(
                    GUARD.os,
                    "scandir",
                    side_effect=enodev_during_queue_enumeration,
                ),
                self.assertRaisesRegex(GUARD.GuardError, "cannot enumerate"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

            with (
                mock.patch.object(
                    GUARD,
                    "_read_text",
                    side_effect=lambda _path, _description: raise_guard_os_error(
                        errno.ENODEV, "read KFD queue GPU ID"
                    ),
                ),
                self.assertRaisesRegex(GUARD.GuardError, "cannot read"),
            ):
                GUARD.selected_gpu_queue_owners(kfd_root, 28851)

    def test_live_classifier_rejects_other_gpuid_errors_after_queue_exit(
        self,
    ) -> None:
        fatal_errors = (
            errno.EIO,
            errno.ENXIO,
            errno.ESTALE,
            errno.EACCES,
            errno.ESRCH,
            errno.EBUSY,
        )
        for error_number in fatal_errors:
            with self.subTest(error_number=error_number):
                with tempfile.TemporaryDirectory() as temporary:
                    root = pathlib.Path(temporary)
                    proc_root = root / "proc"
                    kfd_root = root / "kfd-proc"
                    kfd_root.mkdir()
                    write_process(
                        proc_root, 100, ppid=1, process_group=100, start_time=1000
                    )
                    write_queue(kfd_root, 100, 0, 28851)
                    queue_path = kfd_root / "100" / "queues" / "0"
                    gpu_id_path = queue_path / "gpuid"
                    original = GUARD._read_text

                    def fail_after_queue_exit(
                        path: pathlib.Path, description: str
                    ) -> str:
                        if path == gpu_id_path:
                            gpu_id_path.unlink()
                            queue_path.rmdir()
                            raise_guard_os_error(error_number, "read KFD queue GPU ID")
                        return original(path, description)

                    with (
                        mock.patch.object(
                            GUARD, "_read_text", side_effect=fail_after_queue_exit
                        ),
                        self.assertRaisesRegex(GUARD.GuardError, "cannot read"),
                    ):
                        GUARD.classify_selected_gpu_queues(
                            kfd_proc_root=kfd_root,
                            proc_root=proc_root,
                            selected_gpu_id=28851,
                            root_pid=100,
                            root_start_time=1000,
                        )

    def test_gpuid_enodev_rejects_queue_identity_replacement(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            old_queue_path = queue_path.with_name("0-old")
            gpu_id_path = queue_path / "gpuid"

            def deactivated_gpuid(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    queue_path.rename(old_queue_path)
                    write_queue(kfd_root, 100, 0, 28851)
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            with (
                mock.patch.object(GUARD, "_read_text", side_effect=deactivated_gpuid),
                self.assertRaisesRegex(
                    GUARD.GuardError, "queue directory.*identity changed"
                ),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: 0,
                    sleeper=lambda _seconds: self.fail("unexpected sleep"),
                )

    def test_gpuid_enodev_rejects_queue_becoming_readable(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            gpu_id_path = kfd_root / "100" / "queues" / "0" / "gpuid"
            original = GUARD._read_text
            reads = 0

            def deactivated_then_readable(path: pathlib.Path, description: str) -> str:
                nonlocal reads
                if path == gpu_id_path:
                    reads += 1
                    if reads == 1:
                        raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                return original(path, description)

            with (
                mock.patch.object(
                    GUARD, "_read_text", side_effect=deactivated_then_readable
                ),
                self.assertRaisesRegex(GUARD.GuardError, "became readable"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: 0,
                    sleeper=lambda _seconds: self.fail("unexpected sleep"),
                )
            self.assertEqual(reads, 2)

    def test_gpuid_enodev_still_requires_post_census_pid_binding(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        replacement = GUARD.ProcessObservation(1, 100, 2000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"

            def enodev_after_queue_exit(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            with (
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    side_effect=[
                        root_observation,
                        root_observation,
                        None,
                        replacement,
                    ],
                ),
                mock.patch.object(
                    GUARD, "_read_text", side_effect=enodev_after_queue_exit
                ),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: 0,
                    sleeper=lambda _seconds: self.fail("unexpected sleep"),
                )

    def test_gpuid_enodev_rejects_kfd_process_path_churn(self) -> None:
        root_observation = GUARD.ProcessObservation(1, 100, 1000)
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            process_path = kfd_root / "100"
            old_process_path = kfd_root / "100-old"
            queue_path = kfd_root / "100" / "queues" / "0"
            gpu_id_path = queue_path / "gpuid"

            def enodev_after_queue_exit(path: pathlib.Path, _description: str) -> str:
                if path == gpu_id_path:
                    gpu_id_path.unlink()
                    queue_path.rmdir()
                    process_path.rename(old_process_path)
                    (process_path / "queues").mkdir(parents=True)
                    raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                raise AssertionError(f"unexpected read: {path}")

            with (
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    side_effect=[
                        root_observation,
                        root_observation,
                        root_observation,
                        root_observation,
                    ],
                ),
                mock.patch.object(
                    GUARD, "_read_text", side_effect=enodev_after_queue_exit
                ),
                self.assertRaisesRegex(
                    GUARD.GuardError, "process directory.*identity changed"
                ),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                    clock=lambda: 0,
                    sleeper=lambda _seconds: self.fail("unexpected sleep"),
                )

    def test_live_queue_enumerator_types_both_disappearance_shapes(self) -> None:
        class VanishedEntry:
            name = "0"

            def __init__(self, path: pathlib.Path, raises: bool) -> None:
                self.path = str(path)
                self.raises = raises

            def is_dir(self, *, follow_symlinks: bool) -> bool:
                self.test_follow_symlinks = follow_symlinks
                if self.raises:
                    raise FileNotFoundError(self.path)
                return False

        with tempfile.TemporaryDirectory() as temporary:
            queue_path = pathlib.Path(temporary) / "vanished" / "0"
            for raises in (True, False):
                with self.subTest(raises=raises):
                    entry = VanishedEntry(queue_path, raises)
                    with mock.patch.object(GUARD.os, "scandir", return_value=[entry]):
                        queues, vanished = GUARD._live_queue_directories(
                            queue_path.parent, "KFD queue directory", 1, True
                        )
                    self.assertEqual(queues, [])
                    self.assertTrue(vanished)
                    self.assertFalse(entry.test_follow_symlinks)

                    with (
                        mock.patch.object(GUARD.os, "scandir", return_value=[entry]),
                        self.assertRaises(GUARD.GuardError),
                    ):
                        GUARD._live_queue_directories(
                            queue_path.parent, "KFD queue directory", 1, False
                        )

    def test_live_classifier_rejects_process_disappearance_before_authentication(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            queues_path = kfd_root / "100" / "queues"
            queues_path.mkdir(parents=True)
            process_path = queues_path.parent
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            original = GUARD._numeric_directories

            def enumerate_then_remove(
                path: pathlib.Path, description: str, maximum_entries: int
            ) -> list[tuple[int, pathlib.Path]]:
                entries = original(path, description, maximum_entries)
                if path == kfd_root:
                    queues_path.rmdir()
                    process_path.rmdir()
                return entries

            with (
                mock.patch.object(
                    GUARD, "_numeric_directories", side_effect=enumerate_then_remove
                ),
                self.assertRaises(GUARD.RetryableCensusError) as failure,
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
            self.assertEqual(
                failure.exception.reason,
                "process-directory-disappeared-before-authentication",
            )
            self.assertEqual(failure.exception.pid, 100)

    def test_vanished_foreign_kfd_owner_cannot_be_laundered_by_pid_reuse(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_process(proc_root, 200, ppid=1, process_group=200, start_time=2000)
            write_queue(kfd_root, 200, 0, 28851)
            queue_path = kfd_root / "200" / "queues" / "0"
            queues_path = queue_path.parent
            process_path = queues_path.parent
            original = GUARD._numeric_directories

            def enumerate_then_remove_and_reuse_pid(
                path: pathlib.Path, description: str, maximum_entries: int
            ) -> list[tuple[int, pathlib.Path]]:
                entries = original(path, description, maximum_entries)
                if path == kfd_root:
                    (queue_path / "gpuid").unlink()
                    queue_path.rmdir()
                    queues_path.rmdir()
                    process_path.rmdir()
                    (proc_root / "200" / "stat").unlink()
                    (proc_root / "200").rmdir()
                    write_process(
                        proc_root,
                        200,
                        ppid=100,
                        process_group=100,
                        start_time=3000,
                    )
                return entries

            with (
                mock.patch.object(
                    GUARD,
                    "_numeric_directories",
                    side_effect=enumerate_then_remove_and_reuse_pid,
                ),
                mock.patch.object(
                    GUARD,
                    "_target_process_identity",
                    wraps=GUARD._target_process_identity,
                ) as authenticate,
            ):
                with self.assertRaisesRegex(
                    GUARD.GuardError, "disappeared before authentication"
                ):
                    GUARD.classify_selected_gpu_queues(
                        kfd_proc_root=kfd_root,
                        proc_root=proc_root,
                        selected_gpu_id=28851,
                        root_pid=100,
                        root_start_time=1000,
                    )
            authenticate.assert_not_called()

    def test_strict_owner_census_rejects_queue_disappearance(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_queue(kfd_root, 100, 0, 28851)
            queues_path = kfd_root / "100" / "queues"
            queue_path = queues_path / "0"
            original = GUARD._numeric_directories

            def enumerate_then_remove(
                path: pathlib.Path, description: str, maximum_entries: int
            ) -> list[tuple[int, pathlib.Path]]:
                entries = original(path, description, maximum_entries)
                if path == queues_path:
                    (queue_path / "gpuid").unlink()
                    queue_path.rmdir()
                return entries

            with (
                mock.patch.object(
                    GUARD, "_numeric_directories", side_effect=enumerate_then_remove
                ),
                self.assertRaisesRegex(GUARD.GuardError, "cannot read"),
            ):
                GUARD.selected_gpu_queue_owners(kfd_root, 28851)

    def test_live_classifier_rejects_foreign_queue_disappearance(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_process(proc_root, 200, ppid=1, process_group=200, start_time=2000)
            write_queue(kfd_root, 200, 0, 28851)
            queues_path = kfd_root / "200" / "queues"
            queue_path = queues_path / "0"
            original = GUARD._live_queue_directories

            def enumerate_then_remove(
                path: pathlib.Path,
                description: str,
                maximum_entries: int,
                target_owned: bool,
            ) -> tuple[list[tuple[int, pathlib.Path]], bool]:
                entries = original(path, description, maximum_entries, target_owned)
                if path == queues_path:
                    (queue_path / "gpuid").unlink()
                    queue_path.rmdir()
                return entries

            with (
                mock.patch.object(
                    GUARD, "_live_queue_directories", side_effect=enumerate_then_remove
                ),
                self.assertRaisesRegex(GUARD.GuardError, "disappeared before binding"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_target_disappearance_preserves_foreign_queue_in_either_order(self) -> None:
        for target_pid, foreign_pid in ((200, 100), (100, 200)):
            with self.subTest(target_pid=target_pid, foreign_pid=foreign_pid):
                with tempfile.TemporaryDirectory() as temporary:
                    root = pathlib.Path(temporary)
                    proc_root = root / "proc"
                    kfd_root = root / "kfd-proc"
                    kfd_root.mkdir()
                    write_process(
                        proc_root,
                        target_pid,
                        ppid=1,
                        process_group=target_pid,
                        start_time=target_pid * 10,
                    )
                    write_process(
                        proc_root,
                        foreign_pid,
                        ppid=1,
                        process_group=foreign_pid,
                        start_time=foreign_pid * 10,
                    )
                    write_queue(kfd_root, target_pid, 1, 28851)
                    write_queue(kfd_root, foreign_pid, 0, 28851)
                    queues_path = kfd_root / str(target_pid) / "queues"
                    queue_path = queues_path / "1"
                    original = GUARD._live_queue_directories

                    def enumerate_then_remove(
                        path: pathlib.Path,
                        description: str,
                        maximum_entries: int,
                        target_owned: bool,
                    ) -> tuple[list[tuple[int, pathlib.Path]], bool]:
                        entries = original(
                            path, description, maximum_entries, target_owned
                        )
                        if path == queues_path:
                            (queue_path / "gpuid").unlink()
                            queue_path.rmdir()
                        return entries

                    with mock.patch.object(
                        GUARD,
                        "_live_queue_directories",
                        side_effect=enumerate_then_remove,
                    ):
                        target, foreign = GUARD.classify_selected_gpu_queues(
                            kfd_proc_root=kfd_root,
                            proc_root=proc_root,
                            selected_gpu_id=28851,
                            root_pid=target_pid,
                            root_start_time=target_pid * 10,
                        )
                self.assertEqual(target, [])
                self.assertEqual(foreign, [(foreign_pid, 0)])

    def test_selected_queue_requires_post_read_target_reauthentication(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            with mock.patch.object(
                GUARD, "_is_target_process", side_effect=[True, False]
            ):
                target, foreign = GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
        self.assertEqual(target, [])
        self.assertEqual(foreign, [(100, 0)])

    def test_disappearance_requires_post_read_target_reauthentication(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            queues_path = kfd_root / "100" / "queues"
            queue_path = queues_path / "0"
            original = GUARD._live_queue_directories

            def enumerate_then_remove(
                path: pathlib.Path,
                description: str,
                maximum_entries: int,
                target_owned: bool,
            ) -> tuple[list[tuple[int, pathlib.Path]], bool]:
                entries = original(path, description, maximum_entries, target_owned)
                if path == queues_path:
                    (queue_path / "gpuid").unlink()
                    queue_path.rmdir()
                return entries

            with (
                mock.patch.object(
                    GUARD, "_live_queue_directories", side_effect=enumerate_then_remove
                ),
                mock.patch.object(
                    GUARD, "_is_target_process", side_effect=[True, False]
                ),
                self.assertRaisesRegex(GUARD.GuardError, "identity changed"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_persistently_missing_target_gpuid_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            (kfd_root / "100" / "queues" / "0").mkdir(parents=True)
            with self.assertRaisesRegex(GUARD.GuardError, "cannot read"):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_unreadable_or_malformed_gpuid_fails_without_retry(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            write_process(proc_root, 100, ppid=1, process_group=100, start_time=1000)
            write_queue(kfd_root, 100, 0, 28851)
            gpu_id_path = kfd_root / "100" / "queues" / "0" / "gpuid"
            original = GUARD._read_text
            reads = 0

            def unreadable(path: pathlib.Path, description: str) -> str:
                nonlocal reads
                if path == gpu_id_path:
                    reads += 1
                    try:
                        raise PermissionError("denied")
                    except PermissionError as error:
                        raise GUARD.GuardError(
                            "cannot read KFD queue GPU ID"
                        ) from error
                return original(path, description)

            with (
                mock.patch.object(GUARD, "_read_text", side_effect=unreadable),
                self.assertRaisesRegex(GUARD.GuardError, "cannot read"),
            ):
                GUARD.selected_gpu_queue_owners(kfd_root, 28851)
            with (
                mock.patch.object(GUARD, "_read_text", side_effect=unreadable),
                self.assertRaisesRegex(GUARD.GuardError, "cannot read"),
            ):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )
            self.assertEqual(reads, 2)

            gpu_id_path.write_text("028851\n", encoding="ascii")
            with self.assertRaisesRegex(GUARD.GuardError, "canonical decimal"):
                GUARD.selected_gpu_queue_owners(kfd_root, 28851)
            with self.assertRaisesRegex(GUARD.GuardError, "canonical decimal"):
                GUARD.classify_selected_gpu_queues(
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    selected_gpu_id=28851,
                    root_pid=100,
                    root_start_time=1000,
                )

    def test_cadence_fails_closed_on_large_or_nonmonotonic_gap(self) -> None:
        self.assertEqual(GUARD.MAX_OBSERVATION_GAP_NS, 10_000_000)
        cadence = GUARD.ObservationCadence(GUARD.MAX_OBSERVATION_GAP_NS)
        cadence.observe(100)
        cadence.observe(2_000_100)
        with self.assertRaisesRegex(
            GUARD.GuardError,
            r"observation 3 gap exceeded: observed_ns=10000001 maximum_ns=10000000",
        ):
            cadence.observe(12_000_101)
        nonmonotonic = GUARD.ObservationCadence(10)
        nonmonotonic.observe(1)
        with self.assertRaisesRegex(GUARD.GuardError, "did not advance"):
            nonmonotonic.observe(1)

    def test_absolute_deadline_wait_does_not_reset_when_overdue(self) -> None:
        now_ns = 1_000_000
        sleeps: list[float] = []

        def clock() -> int:
            return now_ns

        def sleeper(seconds: float) -> None:
            nonlocal now_ns
            sleeps.append(seconds)
            now_ns += int(seconds * 1_000_000_000)

        GUARD._sleep_until_observation_deadline(
            deadline_ns=3_000_000, clock=clock, sleeper=sleeper
        )
        self.assertEqual(now_ns, 3_000_000)
        self.assertEqual(sleeps, [0.002])

        now_ns = 7_000_000
        GUARD._sleep_until_observation_deadline(
            deadline_ns=5_000_000, clock=clock, sleeper=sleeper
        )
        self.assertEqual(now_ns, 7_000_000)
        self.assertEqual(sleeps, [0.002])

    def test_cleanup_signals_group_even_after_leader_was_reaped(self) -> None:
        class ReapedProcess:
            pid = 100

            @staticmethod
            def poll() -> int:
                return 0

        process = ReapedProcess()
        with (
            mock.patch.object(GUARD.os, "killpg") as killpg,
            mock.patch.object(GUARD, "_process_group_exists", return_value=True),
            mock.patch.object(
                GUARD, "_wait_for_process_group_absence", return_value=True
            ) as wait_for_absence,
        ):
            GUARD._terminate_process_group(process)
        killpg.assert_called_once_with(100, signal.SIGTERM)
        wait_for_absence.assert_called_once_with(
            process, GUARD.PROCESS_GROUP_GRACE_SECONDS
        )

    def test_cleanup_escalates_and_rejects_a_surviving_process_group(self) -> None:
        class ReapedProcess:
            pid = 100

            @staticmethod
            def poll() -> int:
                return 0

        process = ReapedProcess()
        with (
            mock.patch.object(GUARD.os, "killpg") as killpg,
            mock.patch.object(GUARD, "_process_group_exists", return_value=True),
            mock.patch.object(
                GUARD,
                "_wait_for_process_group_absence",
                side_effect=[False, False],
            ),
            self.assertRaisesRegex(GUARD.GuardError, "survived SIGKILL"),
        ):
            GUARD._terminate_process_group(process)
        self.assertEqual(
            killpg.call_args_list,
            [mock.call(100, signal.SIGTERM), mock.call(100, signal.SIGKILL)],
        )

    def test_cleanup_removes_same_group_child_after_leader_exit(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            child_pid_path = pathlib.Path(temporary) / "child.pid"
            program = """
import os
import pathlib
import signal
import sys
import time

child = os.fork()
if child == 0:
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    time.sleep(30)
    os._exit(0)
pathlib.Path(sys.argv[1]).write_text(str(child), encoding="ascii")
time.sleep(0.05)
os._exit(0)
"""
            process = subprocess.Popen(
                [sys.executable, "-c", program, str(child_pid_path)],
                start_new_session=True,
            )
            try:
                process.wait(timeout=2)
                self.assertTrue(child_pid_path.exists())
                self.assertTrue(GUARD._process_group_exists(process.pid))
                with mock.patch.object(GUARD, "PROCESS_GROUP_GRACE_SECONDS", 0.05):
                    GUARD._terminate_process_group(process)
                self.assertFalse(GUARD._process_group_exists(process.pid))
            finally:
                if GUARD._process_group_exists(process.pid):
                    os.killpg(process.pid, signal.SIGKILL)


class MonitorCommandTests(unittest.TestCase):
    def monitor_argv(
        self,
        *,
        kfd_root: pathlib.Path,
        output: pathlib.Path,
        command: list[str],
    ) -> list[str]:
        observer_cpu = min(os.sched_getaffinity(0))
        return [
            sys.executable,
            str(GUARD_PATH),
            "monitor",
            "--gpu-id",
            "28851",
            "--observer-cpu",
            str(observer_cpu),
            "--target-output",
            str(output),
            "--kfd-proc-root",
            str(kfd_root),
            "--",
            *command,
        ]

    def run_monitor(
        self, temporary: pathlib.Path, command: list[str], *, foreign: bool = False
    ) -> subprocess.CompletedProcess[str]:
        kfd_root = temporary / "kfd-proc"
        kfd_root.mkdir()
        if foreign:
            write_queue(kfd_root, 1, 0, 28851)
        output = temporary / "target.out"
        return subprocess.run(
            self.monitor_argv(kfd_root=kfd_root, output=output, command=command),
            check=False,
            capture_output=True,
            text=True,
        )

    def deterministic_monitor_argv(
        self,
        *,
        kfd_root: pathlib.Path,
        output: pathlib.Path,
        command: list[str],
        retain_rejected_output: bool = False,
    ) -> list[str]:
        observer_cpu = min(os.sched_getaffinity(0))
        program = """
import importlib.util
import pathlib
import signal
import sys

spec = importlib.util.spec_from_file_location("fe2o3_r26_guard_child", sys.argv[1])
guard = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = guard
spec.loader.exec_module(guard)
guard.PROCESS_GROUP_GRACE_SECONDS = 0.1
now_ns = 0

def clock():
    global now_ns
    now_ns += guard.POLL_INTERVAL_NS
    return now_ns

try:
    for signum in guard.MANAGED_SIGNALS:
        signal.signal(signum, guard._raise_signal_error)
    print(guard.monitor_target(
        selected_gpu_id=28851,
        observer_cpu=int(sys.argv[4]),
        target_output=pathlib.Path(sys.argv[3]),
        command=sys.argv[6:],
        kfd_proc_root=pathlib.Path(sys.argv[2]),
        proc_root=pathlib.Path("/proc"),
        retain_rejected_output=sys.argv[5] == "1",
        clock=clock,
    ))
except guard.GuardError as error:
    print(f"r26-host-guard: {error}", file=sys.stderr)
    raise SystemExit(2)
"""
        return [
            sys.executable,
            "-c",
            program,
            str(GUARD_PATH),
            str(kfd_root),
            str(output),
            str(observer_cpu),
            str(int(retain_rejected_output)),
            *command,
        ]

    def monitor_direct(
        self,
        temporary: pathlib.Path,
        command: list[str],
        *,
        target_observed: bool = True,
        retain_rejected_output: bool = False,
    ) -> str:
        kfd_root = temporary / "kfd-proc"
        kfd_root.mkdir()
        observer_cpu = min(os.sched_getaffinity(0))
        now_ns = 0
        census = 0

        def deterministic_clock() -> int:
            nonlocal now_ns
            now_ns += GUARD.POLL_INTERVAL_NS
            return now_ns

        with ExitStack() as stack:
            stack.enter_context(mock.patch.object(GUARD.os, "sched_setaffinity"))
            stack.enter_context(
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                )
            )
            if target_observed:

                def classify(
                    **_arguments: object,
                ) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
                    nonlocal census
                    census += 1
                    return ([], []) if census == 1 else ([(123, 0)], [])

                stack.enter_context(
                    mock.patch.object(
                        GUARD,
                        "classify_selected_gpu_queues",
                        side_effect=classify,
                    )
                )
            return GUARD.monitor_target(
                selected_gpu_id=28851,
                observer_cpu=observer_cpu,
                target_output=temporary / "target.out",
                command=command,
                kfd_proc_root=kfd_root,
                proc_root=pathlib.Path("/proc"),
                retain_rejected_output=retain_rejected_output,
                clock=deterministic_clock,
            )

    def test_monitor_buffers_target_output_until_clean_exit(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            result = self.monitor_direct(
                root,
                [
                    sys.executable,
                    "-c",
                    "import time; time.sleep(0.03); print('backend=kfd')",
                ],
            )
            target_output = root / "target.out"
            retained_output = target_output.read_text(encoding="ascii")
        prefix, observed = fields(result)
        self.assertEqual(prefix, "monitor")
        self.assertEqual(observed["schema"], "fe2o3.r26-kfd-queue-monitor.v2")
        self.assertEqual(observed["status"], "clean")
        self.assertEqual(observed["monitor"], "selected-kfd-gpu-process-tree-census-v2")
        self.assertEqual(observed["schedule"], "absolute-monotonic-raw-deadline-v1")
        self.assertEqual(observed["process_group"], observed["root_pid"])
        self.assertEqual(observed["target_reaped"], "1")
        self.assertEqual(observed["process_group_absent"], "1")
        self.assertEqual(observed["terminal_selected_queues"], "0")
        self.assertEqual(observed["foreign_selected_queues"], "0")
        self.assertGreater(int(observed["target_selected_queue_observations"]), 0)
        self.assertGreaterEqual(int(observed["observations"]), 2)
        self.assertEqual(retained_output, "backend=kfd\n")
        self.assertEqual(
            observed["target_output_sha256"],
            hashlib.sha256(retained_output.encode()).hexdigest(),
        )

    def test_target_exec_waits_for_clean_gated_census(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            marker = root / "target-started"
            observer_cpu = min(os.sched_getaffinity(0))
            census = 0
            now_ns = 0

            def deterministic_clock() -> int:
                nonlocal now_ns
                now_ns += GUARD.POLL_INTERVAL_NS
                return now_ns

            def classify(
                **_arguments: object,
            ) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
                nonlocal census
                census += 1
                if census == 1:
                    self.assertFalse(marker.exists())
                    return [], []
                return [(123, 0)], []

            with (
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(
                    GUARD, "classify_selected_gpu_queues", side_effect=classify
                ),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=root / "target.out",
                    command=[
                        sys.executable,
                        "-c",
                        (
                            "import pathlib,time; "
                            f"pathlib.Path({str(marker)!r}).write_text('started'); "
                            "time.sleep(0.03); print('backend=kfd')"
                        ),
                    ],
                    kfd_proc_root=kfd_root,
                    proc_root=pathlib.Path("/proc"),
                    clock=deterministic_clock,
                )
            self.assertTrue(marker.exists())
            self.assertGreaterEqual(census, 2)

    def test_observer_is_pinned_before_the_prelaunch_census(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            order: list[str] = []
            observer_cpu = min(os.sched_getaffinity(0))

            def set_affinity(_pid: int, cpus: set[int]) -> None:
                self.assertEqual(cpus, {observer_cpu})
                order.append("set-affinity")

            def get_affinity(_pid: int) -> set[int]:
                order.append("get-affinity")
                return {observer_cpu}

            def initial_census(
                _root: pathlib.Path, _gpu_id: int
            ) -> list[tuple[int, int]]:
                order.append("initial-census")
                raise GUARD.GuardError("stop after initial census")

            with (
                mock.patch.object(GUARD.os, "sched_setaffinity", set_affinity),
                mock.patch.object(GUARD.os, "sched_getaffinity", get_affinity),
                mock.patch.object(
                    GUARD, "selected_gpu_queue_owners", side_effect=initial_census
                ),
                self.assertRaisesRegex(GUARD.GuardError, "stop after initial census"),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=root / "target.out",
                    command=["fixed-target"],
                    kfd_proc_root=root / "kfd-proc",
                    proc_root=root / "proc",
                )
        self.assertEqual(order, ["set-affinity", "get-affinity", "initial-census"])

    def test_preopen_race_does_not_delete_unowned_target_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            observer_cpu = min(os.sched_getaffinity(0))

            def initial_census(
                _root: pathlib.Path, _gpu_id: int
            ) -> list[tuple[int, int]]:
                output.write_text("unowned\n", encoding="ascii")
                return []

            with (
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(
                    GUARD, "selected_gpu_queue_owners", side_effect=initial_census
                ),
                self.assertRaisesRegex(
                    GUARD.GuardError, "cannot create private target stdout"
                ),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                )
            self.assertEqual(output.read_text(encoding="ascii"), "unowned\n")

    def test_launch_delay_remains_part_of_the_census_gap(self) -> None:
        class FakeProcess:
            pid = 100

            @staticmethod
            def poll() -> int:
                return 0

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            now_ns = 0
            process = FakeProcess()

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                nonlocal now_ns
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                now_ns += GUARD.MAX_OBSERVATION_GAP_NS + 1
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return process

            observer_cpu = min(os.sched_getaffinity(0))
            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    return_value=GUARD.ProcessObservation(1, 100, 1000),
                ),
                mock.patch.object(
                    GUARD,
                    "classify_selected_gpu_queues",
                    return_value=([(100, 0)], []),
                ),
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(GUARD, "_terminate_process_group") as cleanup,
                self.assertRaisesRegex(
                    GUARD.RetryableCensusError,
                    r"observation 2 gap exceeded: observed_ns=10000001 maximum_ns=10000000",
                ) as failure,
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    clock=lambda: now_ns,
                    sleeper=lambda _seconds: None,
                )
            self.assertEqual(failure.exception.reason, "observation-gap-exceeded")
            self.assertEqual(failure.exception.pid, process.pid)
            cleanup.assert_called_once_with(process)
            self.assertFalse(output.exists())

    def test_target_process_group_must_match_its_root_pid(self) -> None:
        class FakeProcess:
            pid = 100

            @staticmethod
            def poll() -> int | None:
                return None

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            observer_cpu = min(os.sched_getaffinity(0))

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return FakeProcess()

            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    return_value=GUARD.ProcessObservation(1, 99, 1000),
                ),
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(GUARD, "_terminate_process_group"),
                self.assertRaisesRegex(
                    GUARD.GuardError, "did not establish its dedicated process group"
                ),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                )
            self.assertFalse(output.exists())

    def test_live_censuses_follow_absolute_deadlines_after_launch_probe(self) -> None:
        class FakeProcess:
            pid = 100

            def __init__(self) -> None:
                self.polls = 0

            def poll(self) -> int | None:
                self.polls += 1
                return None if self.polls < 3 else 0

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            observer_cpu = min(os.sched_getaffinity(0))
            now_ns = 0
            owner_calls = 0
            classify_calls = 0
            sleeps: list[int] = []

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return FakeProcess()

            def classify(
                **_arguments: object,
            ) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
                nonlocal classify_calls, now_ns
                classify_calls += 1
                now_ns += 100_000
                return ([], []) if classify_calls == 1 else ([(100, 0)], [])

            def owners(_root: pathlib.Path, _gpu_id: int) -> list[tuple[int, int]]:
                nonlocal now_ns, owner_calls
                owner_calls += 1
                if owner_calls == 2:
                    now_ns += 100_000
                return []

            def sleeper(seconds: float) -> None:
                nonlocal now_ns
                duration_ns = int(seconds * 1_000_000_000)
                sleeps.append(duration_ns)
                now_ns += duration_ns

            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(
                    GUARD.os, "write", return_value=len(GUARD.START_GATE_TOKEN)
                ),
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    return_value=GUARD.ProcessObservation(1, 100, 1000),
                ),
                mock.patch.object(
                    GUARD, "classify_selected_gpu_queues", side_effect=classify
                ),
                mock.patch.object(
                    GUARD, "selected_gpu_queue_owners", side_effect=owners
                ),
                mock.patch.object(GUARD, "_process_group_exists", return_value=False),
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    clock=lambda: now_ns,
                    sleeper=sleeper,
                )
        self.assertEqual(sleeps, [1_800_000, 1_900_000])

    def test_terminal_selected_gpu_queue_rejects_success(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            observer_cpu = min(os.sched_getaffinity(0))
            now_ns = 0

            def clock() -> int:
                nonlocal now_ns
                now_ns += GUARD.POLL_INTERVAL_NS
                return now_ns

            original_write = GUARD.os.write

            def release_target(descriptor: int, payload: bytes) -> int:
                setattr(clock, "released", True)
                return original_write(descriptor, payload)

            with (
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(
                    GUARD,
                    "classify_selected_gpu_queues",
                    side_effect=(
                        lambda **_arguments: (
                            ([], [])
                            if not hasattr(clock, "released")
                            else ([(123, 0)], [])
                        )
                    ),
                ),
                mock.patch.object(
                    GUARD.os,
                    "write",
                    side_effect=release_target,
                ),
                mock.patch.object(
                    GUARD,
                    "selected_gpu_queue_owners",
                    side_effect=[[], [(999, 7)]],
                ),
                self.assertRaisesRegex(
                    GUARD.GuardError, "selected-GPU queue remains after target exit"
                ),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=[
                        sys.executable,
                        "-c",
                        "import time; time.sleep(0.02); print('backend=kfd')",
                    ],
                    kfd_proc_root=kfd_root,
                    proc_root=pathlib.Path("/proc"),
                    clock=clock,
                    sleeper=lambda _seconds: None,
                )
            self.assertFalse(output.exists())

    def test_surviving_process_group_rejects_success_and_is_cleaned(self) -> None:
        class FakeProcess:
            pid = 100

            @staticmethod
            def poll() -> int:
                return 0

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            observer_cpu = min(os.sched_getaffinity(0))
            now_ns = 0

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return FakeProcess()

            def classify(
                **_arguments: object,
            ) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
                nonlocal now_ns
                now_ns += GUARD.POLL_INTERVAL_NS
                return (
                    ([], []) if now_ns == GUARD.POLL_INTERVAL_NS else ([(100, 0)], [])
                )

            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(
                    GUARD.os, "write", return_value=len(GUARD.START_GATE_TOKEN)
                ),
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    return_value=GUARD.ProcessObservation(1, 100, 1000),
                ),
                mock.patch.object(
                    GUARD, "classify_selected_gpu_queues", side_effect=classify
                ),
                mock.patch.object(GUARD, "_process_group_exists", return_value=True),
                mock.patch.object(GUARD, "_terminate_process_group") as cleanup,
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                self.assertRaisesRegex(
                    GUARD.GuardError, "target process group remains after leader exit"
                ),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    clock=lambda: now_ns,
                    sleeper=lambda _seconds: None,
                )
            cleanup.assert_called_once()
            self.assertFalse(output.exists())

    def test_terminal_queue_census_duration_participates_in_cadence(self) -> None:
        class FakeProcess:
            pid = 100

            @staticmethod
            def poll() -> int:
                return 0

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            observer_cpu = min(os.sched_getaffinity(0))
            now_ns = 0
            owner_calls = 0

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return FakeProcess()

            def classify(
                **_arguments: object,
            ) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
                nonlocal now_ns
                now_ns += GUARD.POLL_INTERVAL_NS
                return (
                    ([], []) if now_ns == GUARD.POLL_INTERVAL_NS else ([(100, 0)], [])
                )

            def owners(_root: pathlib.Path, _gpu_id: int) -> list[tuple[int, int]]:
                nonlocal now_ns, owner_calls
                owner_calls += 1
                if owner_calls == 2:
                    now_ns += GUARD.MAX_OBSERVATION_GAP_NS + 1
                return []

            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(
                    GUARD.os, "write", return_value=len(GUARD.START_GATE_TOKEN)
                ),
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    return_value=GUARD.ProcessObservation(1, 100, 1000),
                ),
                mock.patch.object(
                    GUARD, "classify_selected_gpu_queues", side_effect=classify
                ),
                mock.patch.object(
                    GUARD, "selected_gpu_queue_owners", side_effect=owners
                ),
                mock.patch.object(GUARD, "_process_group_exists", return_value=False),
                mock.patch.object(GUARD, "_terminate_process_group") as cleanup,
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                self.assertRaisesRegex(
                    GUARD.RetryableCensusError, "gap exceeded"
                ) as failure,
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    clock=lambda: now_ns,
                    sleeper=lambda _seconds: None,
                )
            self.assertEqual(failure.exception.reason, "observation-gap-exceeded")
            self.assertEqual(failure.exception.pid, 100)
            cleanup.assert_not_called()
            self.assertFalse(output.exists())

    def test_enodev_unlink_delays_compose_in_monitor_cadence(self) -> None:
        for deactivated_count, accepted in ((1, True), (6, False)):
            with (
                self.subTest(deactivated_count=deactivated_count, accepted=accepted),
                tempfile.TemporaryDirectory() as temporary,
            ):
                root = pathlib.Path(temporary)
                proc_root = root / "proc"
                kfd_root = root / "kfd-proc"
                kfd_root.mkdir()
                output = root / "target.out"
                observer_cpu = min(os.sched_getaffinity(0))
                now_ns = 0
                deactivated_gpuid_paths: set[pathlib.Path] = set()
                original_read_text = GUARD._read_text

                class FakeProcess:
                    pid = 100

                    def poll(self) -> int:
                        nonlocal now_ns
                        now_ns += 1
                        stable_queue = kfd_root / "100" / "queues" / "0"
                        (stable_queue / "gpuid").unlink()
                        stable_queue.rmdir()
                        return 0

                def launch(
                    _command: list[str],
                    *,
                    stdout: object,
                    start_new_session: bool,
                    pass_fds: tuple[int, ...],
                ) -> FakeProcess:
                    nonlocal now_ns
                    self.assertTrue(start_new_session)
                    self.assertEqual(len(pass_fds), 1)
                    now_ns += 1
                    write_process(
                        proc_root,
                        100,
                        ppid=1,
                        process_group=100,
                        start_time=1000,
                    )
                    stdout.write(b"backend=kfd\n")
                    stdout.flush()
                    return FakeProcess()

                def release_target(descriptor: int, payload: bytes) -> int:
                    write_queue(kfd_root, 100, 0, 28851)
                    for queue_id in range(1, deactivated_count + 1):
                        write_queue(kfd_root, 100, queue_id, 28851)
                        deactivated_gpuid_paths.add(
                            kfd_root / "100" / "queues" / str(queue_id) / "gpuid"
                        )
                    return len(payload)

                def deactivated_gpuid(path: pathlib.Path, description: str) -> str:
                    if path in deactivated_gpuid_paths:
                        raise_guard_os_error(errno.ENODEV, "read KFD queue GPU ID")
                    return original_read_text(path, description)

                def unlink_one_deactivated_queue(_seconds: float) -> None:
                    nonlocal now_ns
                    now_ns += 1_900_000
                    remaining = sorted(
                        path for path in deactivated_gpuid_paths if path.exists()
                    )
                    self.assertTrue(remaining)
                    gpu_id_path = remaining[0]
                    queue_path = gpu_id_path.parent
                    gpu_id_path.unlink()
                    queue_path.rmdir()

                with (
                    mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                    mock.patch.object(GUARD.os, "write", side_effect=release_target),
                    mock.patch.object(
                        GUARD, "_read_text", side_effect=deactivated_gpuid
                    ),
                    mock.patch.object(GUARD.os, "sched_setaffinity"),
                    mock.patch.object(
                        GUARD.os,
                        "sched_getaffinity",
                        return_value={observer_cpu},
                    ),
                    mock.patch.object(
                        GUARD, "_process_group_exists", return_value=False
                    ),
                    mock.patch.object(GUARD, "_terminate_process_group") as cleanup,
                ):
                    if accepted:
                        record = GUARD.monitor_target(
                            selected_gpu_id=28851,
                            observer_cpu=observer_cpu,
                            target_output=output,
                            command=["fixed-target"],
                            kfd_proc_root=kfd_root,
                            proc_root=proc_root,
                            clock=lambda: now_ns,
                            sleeper=unlink_one_deactivated_queue,
                        )
                        _, observed = fields(record)
                        self.assertEqual(observed["observed_maximum_gap_us"], "1900")
                        cleanup.assert_not_called()
                    else:
                        with self.assertRaisesRegex(GUARD.GuardError, "gap exceeded"):
                            GUARD.monitor_target(
                                selected_gpu_id=28851,
                                observer_cpu=observer_cpu,
                                target_output=output,
                                command=["fixed-target"],
                                kfd_proc_root=kfd_root,
                                proc_root=proc_root,
                                clock=lambda: now_ns,
                                sleeper=unlink_one_deactivated_queue,
                            )
                        cleanup.assert_called_once()
                        self.assertFalse(output.exists())

    def test_empty_queue_view_cannot_certify_success(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            with self.assertRaisesRegex(GUARD.GuardError, "no target-owned"):
                self.monitor_direct(
                    root,
                    [
                        sys.executable,
                        "-c",
                        "import time; time.sleep(0.02); print('backend=kfd')",
                    ],
                    target_observed=False,
                )
            self.assertFalse((root / "target.out").exists())

    def test_monitor_accepts_an_ancestry_owned_child_queue(self) -> None:
        class FakeProcess:
            pid = 100

            def __init__(self) -> None:
                self.polls = 0

            def poll(self) -> int | None:
                self.polls += 1
                return None if self.polls == 1 else 0

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            proc_root = root / "proc"
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            now_ns = 0
            process = FakeProcess()

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                write_process(
                    proc_root, 100, ppid=1, process_group=100, start_time=1000
                )
                write_process(
                    proc_root, 101, ppid=100, process_group=100, start_time=1001
                )
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return process

            def release_target(descriptor: int, payload: bytes) -> int:
                write_queue(kfd_root, 101, 0, 28851)
                return len(payload)

            def clock() -> int:
                nonlocal now_ns
                now_ns += GUARD.POLL_INTERVAL_NS
                return now_ns

            observer_cpu = min(os.sched_getaffinity(0))
            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(GUARD.os, "write", side_effect=release_target),
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(
                    GUARD,
                    "selected_gpu_queue_owners",
                    side_effect=[[], []],
                ),
                mock.patch.object(GUARD, "_process_group_exists", return_value=False),
            ):
                record = GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=proc_root,
                    clock=clock,
                    sleeper=lambda _seconds: None,
                )
        _, observed = fields(record)
        self.assertEqual(observed["target_selected_queue_observations"], "2")

    def test_final_census_duration_participates_in_cadence(self) -> None:
        class FakeProcess:
            pid = 100

            def __init__(self) -> None:
                self.polls = 0

            def poll(self) -> int | None:
                self.polls += 1
                return None if self.polls == 1 else 0

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            now_ns = 0
            census = 0
            process = FakeProcess()

            def launch(
                _command: list[str],
                *,
                stdout: object,
                start_new_session: bool,
                pass_fds: tuple[int, ...],
            ) -> FakeProcess:
                self.assertTrue(start_new_session)
                self.assertEqual(len(pass_fds), 1)
                stdout.write(b"backend=kfd\n")
                stdout.flush()
                return process

            def classify(
                **_arguments: object,
            ) -> tuple[list[tuple[int, int]], list[tuple[int, int]]]:
                nonlocal census, now_ns
                census += 1
                now_ns += (
                    GUARD.POLL_INTERVAL_NS
                    if census <= 2
                    else GUARD.MAX_OBSERVATION_GAP_NS + 1
                )
                return ([], []) if census == 1 else ([(100, 0)], [])

            def sleep_until_deadline(seconds: float) -> None:
                nonlocal now_ns
                now_ns += int(seconds * 1_000_000_000)

            observer_cpu = min(os.sched_getaffinity(0))
            with (
                mock.patch.object(GUARD.subprocess, "Popen", side_effect=launch),
                mock.patch.object(
                    GUARD,
                    "_read_process",
                    return_value=GUARD.ProcessObservation(1, 100, 1000),
                ),
                mock.patch.object(
                    GUARD, "classify_selected_gpu_queues", side_effect=classify
                ),
                mock.patch.object(GUARD.os, "sched_setaffinity"),
                mock.patch.object(
                    GUARD.os, "sched_getaffinity", return_value={observer_cpu}
                ),
                mock.patch.object(GUARD, "_terminate_process_group"),
                mock.patch.object(
                    GUARD.os, "write", return_value=len(GUARD.START_GATE_TOKEN)
                ),
                self.assertRaisesRegex(GUARD.GuardError, "gap exceeded"),
            ):
                GUARD.monitor_target(
                    selected_gpu_id=28851,
                    observer_cpu=observer_cpu,
                    target_output=output,
                    command=["fixed-target"],
                    kfd_proc_root=kfd_root,
                    proc_root=root / "proc",
                    clock=lambda: now_ns,
                    sleeper=sleep_until_deadline,
                )
            self.assertEqual(census, 3)
            self.assertFalse(output.exists())

    def test_foreign_queue_fails_without_releasable_target_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            result = self.run_monitor(
                root,
                [sys.executable, "-c", "import time; time.sleep(2); print('bad')"],
                foreign=True,
            )
            output_exists = (root / "target.out").exists()
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertIn("selected-GPU queue exists before target launch", result.stderr)
        self.assertFalse(output_exists)

    def test_nonzero_target_fails_without_releasable_target_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            with self.assertRaisesRegex(GUARD.GuardError, "status 3"):
                self.monitor_direct(
                    root,
                    [
                        sys.executable,
                        "-c",
                        "import time; time.sleep(0.02); print('bad'); raise SystemExit(3)",
                    ],
                )
            output_exists = (root / "target.out").exists()
        self.assertFalse(output_exists)

    def test_rejected_output_retention_is_explicit_in_cli(self) -> None:
        common = [
            "monitor",
            "--gpu-id", "28851",
            "--observer-cpu", "0",
            "--target-output", "/unused/target.out",
        ]
        for enabled in (False, True):
            with self.subTest(enabled=enabled):
                options = ["--retain-rejected-output"] if enabled else []
                arguments = GUARD._build_parser().parse_args(
                    [*common, *options, "--", "/unused/target"]
                )
                with mock.patch.object(
                    GUARD, "monitor_target", return_value="record"
                ) as monitor:
                    self.assertEqual(GUARD._run(arguments), "record")
                self.assertIs(monitor.call_args.kwargs["retain_rejected_output"], enabled)
                self.assertEqual(monitor.call_args.kwargs["command"], ["/unused/target"])

    def test_nonzero_target_retains_exact_unqualified_bytes_when_requested(self) -> None:
        payload = b"backend=kfd\n\x00partial\n\n"
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            with mock.patch.object(
                GUARD, "_terminate_process_group", wraps=GUARD._terminate_process_group
            ) as terminate:
                with self.assertRaisesRegex(GUARD.GuardError, "status 3"):
                    self.monitor_direct(
                        root,
                        [
                            sys.executable, "-c",
                            "import os,time; time.sleep(0.02); "
                            f"os.write(1, {payload!r}); raise SystemExit(3)",
                        ],
                        retain_rejected_output=True,
                    )
                terminate.assert_called_once()
            self.assertEqual((root / "target.out").read_bytes(), payload)
            self.assertEqual((root / "target.out").stat().st_mode & 0o777, 0o600)

    def test_output_validation_failure_retains_unqualified_bytes_when_requested(self) -> None:
        payload = b"backend=kfd\n\n"
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            with mock.patch.object(
                GUARD, "_hash_file", side_effect=GUARD.GuardError("invalid output")
            ):
                with self.assertRaisesRegex(GUARD.GuardError, "invalid output"):
                    self.monitor_direct(
                        root,
                        [
                            sys.executable, "-c",
                            "import os,time; time.sleep(0.02); "
                            f"os.write(1, {payload!r})",
                        ],
                        retain_rejected_output=True,
                    )
            self.assertEqual((root / "target.out").read_bytes(), payload)

    def test_cleanup_failure_retains_unqualified_bytes_without_hiding_error(self) -> None:
        payload = b"failed\n\n"
        terminate = GUARD._terminate_process_group

        def terminate_then_fail(process: subprocess.Popen[bytes]) -> None:
            terminate(process)
            raise GUARD.GuardError("cleanup observation failed")

        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            with mock.patch.object(
                GUARD, "_terminate_process_group", side_effect=terminate_then_fail
            ):
                with self.assertRaisesRegex(
                    GUARD.GuardError,
                    "target cleanup failed.*cleanup observation failed",
                ):
                    self.monitor_direct(
                        root,
                        [
                            sys.executable, "-c",
                            "import os,time; time.sleep(0.02); "
                            f"os.write(1, {payload!r}); raise SystemExit(3)",
                        ],
                        retain_rejected_output=True,
                    )
            self.assertEqual((root / "target.out").read_bytes(), payload)

    def test_termination_cleans_target_group_and_buffered_output(self) -> None:
        self.check_termination_retention(False)

    def test_termination_retains_evidence_but_still_cleans_target_group(self) -> None:
        self.check_termination_retention(True)

    def check_termination_retention(self, retain_rejected_output: bool) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = pathlib.Path(temporary)
            kfd_root = root / "kfd-proc"
            kfd_root.mkdir()
            output = root / "target.out"
            pid_file = root / "target.pid"
            command = [
                sys.executable,
                "-c",
                (
                    "import os,pathlib,signal,time; "
                    "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
                    "os.write(1, b'partial\\n\\n'); "
                    f"ready=pathlib.Path({str(pid_file.with_suffix('.pending'))!r}); "
                    "ready.write_text(str(os.getpid())); "
                    f"ready.replace({str(pid_file)!r}); "
                    "time.sleep(10)"
                ),
            ]
            monitor = subprocess.Popen(
                self.deterministic_monitor_argv(
                    kfd_root=kfd_root, output=output, command=command,
                    retain_rejected_output=retain_rejected_output,
                ),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            target_pid = None
            termination_requested = False
            try:
                deadline = time.monotonic() + 10
                target_pid_text = ""
                while time.monotonic() < deadline:
                    try:
                        target_pid_text = pid_file.read_text(encoding="ascii")
                    except FileNotFoundError:
                        pass
                    if target_pid_text or monitor.poll() is not None:
                        break
                    time.sleep(0.005)
                self.assertRegex(target_pid_text, r"^[1-9][0-9]*$")
                target_pid = int(target_pid_text)
                monitor.terminate()
                termination_requested = True
                time.sleep(0.02)
                monitor.terminate()
            finally:
                if monitor.poll() is None and not termination_requested:
                    monitor.terminate()
                try:
                    stdout, stderr = monitor.communicate(timeout=7)
                except subprocess.TimeoutExpired:
                    monitor.kill()
                    monitor.communicate(timeout=2)
                    raise
                finally:
                    # Record the cleanup oracle before test-only fallback cleanup.
                    target_exists = target_pid is not None and pathlib.Path(
                        f"/proc/{target_pid}"
                    ).exists()
                    output_exists = output.exists()
                    if target_pid is not None and GUARD._process_group_exists(
                        target_pid
                    ):
                        try:
                            os.killpg(target_pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        try:
                            os.waitpid(target_pid, 0)
                        except ChildProcessError:
                            pass
            if retain_rejected_output:
                retained_output = output.read_bytes()
        self.assertEqual(monitor.returncode, 2)
        self.assertEqual(stdout, "")
        self.assertIn("interrupted by signal", stderr)
        self.assertEqual(output_exists, retain_rejected_output)
        self.assertFalse(target_exists)
        if retain_rejected_output:
            self.assertEqual(retained_output, b"partial\n\n")


if __name__ == "__main__":
    unittest.main()
