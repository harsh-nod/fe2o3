env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib materialized_completion_ -- --test-threads=1 
