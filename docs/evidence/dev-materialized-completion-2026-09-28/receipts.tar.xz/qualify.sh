#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
raw=/home/harsh/.codex-tmp/fe2o3-materialized-completion-20260928-4QC6fvrv
failed=0
run() {
    bash "$raw/run.sh" "$@"
    status=$?
    printf 'QUALIFICATION %s: %s\n' "$1" "$status"
    if test "$status" -ne 0; then failed=1; fi
}
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
run qualified-peer cargo test -p fe2o3-runtime --all-features --lib kfd_backend::tests::compute_peer_gate_tests::child_peer_gate_ordered_successor_guard_has_a_downstream_attempt_control -- --exact --nocapture --test-threads=1
run qualified-focused cargo test -p fe2o3-runtime --all-features --lib materialized_ -- --test-threads=1
run qualified-runtime cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1
run qualified-protocol cargo test -p fe2o3-profiler-protocol --all-features
run qualified-clippy cargo clippy -p fe2o3-runtime -p fe2o3-kfd -p fe2o3-profiler-protocol --all-features --all-targets -- -D warnings
run qualified-no-default cargo check -p fe2o3-runtime --no-default-features
run qualified-format cargo fmt --all --check
run qualified-source-continuity git diff --exit-code ab81310394f01fbc32f7d08efcef4c21f908d976 -- crates Cargo.toml Cargo.lock
exit "$failed"
