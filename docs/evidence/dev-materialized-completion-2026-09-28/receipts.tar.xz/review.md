# Review and qualification scope

Two read-only collaboration agents reviewed production custody and CPU test
oracles. Primary owns all edits and sequential builds/tests. No permission
requests, escalation, external Qwen workers, or remote jobs were used.

Review corrections integrated before final qualification:
- Validate actual pipeline occupancy and exact per-slot identities before
  logical-frontier promotion; require the next deferred predecessor retain.
- Preserve first-Ready timing; include the outer native lane loan in recycle
  timing and accumulate confirmed retry attempts.
- Check script exhaustion before installing more steps, strengthen snapshots,
  cover Published/Completed promotion and first/middle/last profile failures.
- Distinct missing dirty extents use existing prepublication reservations;
  matching full-capacity extents remain valid.
- DispatchCompleted uses bounded stack JSON instead of a temporary Vec. Review
  computed a maximum current payload of 444 bytes versus the 1024-byte buffer.
  Differential tests compare canonical identity and full event encoded length.

Preliminary failures are retained, not replaced:
- initial-focused: profiled successful completion counted three allocations.
  These were temporary completion payload serialization allocations; the bounded
  encoder removes them in the measured pre-reserved runtime recorder workflow.
- reviewed-clippy: collapsible nested if; fixed without changing the predicate.
- final-backend at source 10b516b9 aborted in the peer-gate downstream-attempt
  control. That older fixture used PhysicallyRetired/None; production now
  requires an explicit retired observation. The exact diagnostic confirms its
  expected downstream error was no longer reached, followed by fail-closed Drop.
- peer-guard-diagnostic selected zero tests because its short name was combined
  with --exact. It provides no coverage; peer-guard-diagnostic-exact reproduces
  the actual failure.

Source ab813103 migrates only that fixture to ScriptedMaterializedRetired.
The additional eligibility is cfg(test), restricted to that exact phase/marker
and explicit completion-script opt-in. Existing Pending/Failed peer gates still
refuse; Succeeded reaches the missing-lane guard only with both marker and opt-in.
None-marker and absent-opt-in controls refuse. No native receipt is fabricated,
and production eligibility is unchanged. General metadata-only pipeline fixtures
remain untouched.

The eight new completion test groups contain seven runtime workflows and one
container-check group. Runtime workflows exercise 48 fault cases, their 48
unrepaired-Drop subprocesses, four counted frontier controls, sixteen out-of-order
and profile-prefix controls, four promotion controls, four target corruption
controls, and eighteen frontier/precommit corruption controls. These are case
counts, not independently registered tests or GPU launches. Pipeline B/C begin
as public Pending admissions but are constructed completion-only owners; they
do not qualify public successor publication, native receipt execution, or GPU
cleanup. The recorder allocation counts are scoped to selected retry/success
polls, not arbitrary completion/error/drain paths or generic vector growth.

No formal correspondence theorem is supplied. The existing R60 projection does
not establish refinement of these new native-consuming runtime transitions.
checked_frontier_v1 scans configured pipeline slots on each logical commit;
neither linear high-depth drain nor any native speedup has been established.

Next native adapter scope: ordered-successor submission currently precedes
pipeline insertion. Reserve an indexed staged tail before submit, retain the
predecessor, record returned outcomes inside the lane callback, confirm only
after successful outer return, and withdraw only a confirmed retry. Withdrawal
must not create logical-epoch holes. On failure with an indexed successor,
retire Pending FIFO/explicit-dependency metadata only, retaining the deferred
ordered predecessor and allocation/module/completion custody. Qualify native
coupling, Context composition, protected Worker, resource closure, and matched
HIP/HSA workloads separately.
