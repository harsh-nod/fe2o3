cargo clippy -p fe2o3-runtime -p fe2o3-kfd -p fe2o3-profiler-protocol --all-features --all-targets -- -D warnings 
