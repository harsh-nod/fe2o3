env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo fmt --all --check 
