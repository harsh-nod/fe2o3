#!/usr/bin/env python3
"""Record one bounded read-only SSH observation without admitting a device pair."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "admission"
PRIOR = Path("/home/harsh/.codex-tmp/fe2o3-multigpu-native-recovery-20261001/admission-continuation-20261002/result.json")
BASE = "a400b2c796eb056efef24b18ff5faa2c5ba421bd"
EXPECTED = "ssh -T -o BatchMode=yes -o ConnectTimeout=10 mi300x /usr/bin/timeout --kill-after=5s 30s /usr/bin/env -u HIP_VISIBLE_DEVICES -u ROCR_VISIBLE_DEVICES -u CUDA_VISIBLE_DEVICES -u GPU_DEVICE_ORDINAL /opt/rocm/bin/rocm-smi --showuse --showmeminfo vram --showuniqueid --showbus --showpids --json"


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def main():
    prior_bytes = PRIOR.read_bytes()
    command = json.loads(prior_bytes)["command"]
    if command != EXPECTED:
        raise SystemExit("retained command differs from exact authorized observer")
    OUT.mkdir()
    started = utc()
    monotonic_start = time.monotonic()
    timed_out = False
    try:
        completed = subprocess.run(shlex.split(command), stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   timeout=60, check=False)
        stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code = error.stdout or b"", error.stderr or b"", 124
        timed_out = True
    (OUT / "availability.json").write_bytes(stdout)
    (OUT / "availability.stderr").write_bytes(stderr)
    dns_failed = b"Could not resolve hostname" in stderr
    result = dict(
        observed_at_utc=started, finished_at_utc=utc(),
        elapsed_seconds=time.monotonic() - monotonic_start,
        source_base=BASE, purpose="single fresh bounded read-only A3 hardware admission observation",
        command=command, argv=shlex.split(command), local_timeout_seconds=60,
        retained_command_receipt_sha256=hashlib.sha256(prior_bytes).hexdigest(),
        exit_code=code, timed_out=timed_out,
        stdout="availability.json", stderr="availability.stderr",
        blocker=stderr.decode("utf-8", "replace").strip() if code else None,
        remote_command_executed=False if dns_failed else (True if code == 0 else None),
        remote_files_changed=False, gpu_workload_executed=False,
        fresh_available_pair=None, followup_hardware_attempts=0,
    )
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
