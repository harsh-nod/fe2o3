# Multi-GPU Async Lifecycle Work Order

Base: a400b2c796eb056efef24b18ff5faa2c5ba421bd.
The preceding goal turn was progress: source, tests and evidence were signed
and pushed to both user-designated repositories. A3 remains the priority;
A1/A2 remain parked, and the full parity objective is unchanged.

Current work:

1. Compose persistent transfer phases, actual mapping algorithms and actual
   SDMA submit/poll with fault-injected low-level CPU fixtures. Share one private
   production transfer driver, preserving concrete public APIs and semantics.
   Full Linux currentness/ioctl/hardware execution remains outside CPU evidence.
2. Test Context and current-thread-owned-engine outstanding native-route group
   drain, deadline retention/resumption, opposite directions, disjoint groups,
   cancellation versus uncertain failure, retained results and shutdown.
3. Change the native two-GPU witness to reject an expired public drain deadline
   without completion, then drive the unflushed copy through explicit drain.
   Keep all existing complete-output, transport-count and cleanup requirements.

One fresh read-only MI300X attempt failed DNS before remote execution. Its
command, timestamp and failure are under admission/. No remote scratch or GPU
work was created. Do not promote CPU results to hardware, formal or performance
acceptance. Existing three socket-inspection EPERM failures must remain visible.

Builds use one job, locked/offline nightly-2026-04-03, test optimization level1,
debug assertions and overflow checks. Root coordinates source freeze and one
combined build; agents then run direct test executables with retained hashes.
Every retry gets a new artifact directory. All source-CI metadata updates must
preserve predicates and executable proof bytes; no solver is implied.
