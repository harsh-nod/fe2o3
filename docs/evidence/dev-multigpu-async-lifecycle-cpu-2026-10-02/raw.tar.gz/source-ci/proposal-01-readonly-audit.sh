#!/bin/bash
set -eu
set -o pipefail
out=/home/harsh/.codex-tmp/fe2o3-multigpu-async-lifecycle-20261002/source-ci
report="$out/proposal-01/metadata-report.json"
test ! -e "$out/proposal-01-readonly-audit.stdout" || exit 125
test ! -e "$out/proposal-01-readonly-audit.stderr" || exit 125
test ! -e "$out/proposal-01-readonly-audit.exit" || exit 125
audit() {
    cd /home/harsh/.codex-tmp/fe2o3-r61-execution
    date -u +%Y-%m-%dT%H:%M:%SZ
    jq -r '.audited_source_sha256 | to_entries[] | "\(.value)  \(.key)"' "$report" | sha256sum --check --quiet
    printf 'All 1014 audited source hashes match the current tree.\n'
    jq -r '.proof_files | to_entries[] | "\(.value)  \(.key)"' "$report" | sha256sum --check --quiet
    printf 'All 76 executable proof hashes match the current tree.\n'
    jq -r '.proof_files | keys[]' "$report" | xargs git diff --exit-code a400b2c796eb056efef24b18ff5faa2c5ba421bd --
    printf 'All 76 executable proof files are unchanged from the baseline.\n'
    git diff --exit-code a400b2c796eb056efef24b18ff5faa2c5ba421bd -- crates/fe2o3-runtime-model/verus
    printf 'Guard directory remains unchanged from the baseline.\n'
    jq -r '.changes[] | "\(.original_sha256)  \(.path)"' "$report" | sha256sum --check --quiet
    printf 'All 13 audited guard preimages remain intact.\n'
    jq '{changed_paths: [.changes[] | select(.edits | length > 0) | .path], metadata_categories: ([.changes[].edits[]] | group_by(.category) | map({category: .[0].category, count: length})), source_counts: {runtime: .runtime_source_files, runtime_and_schema: .runtime_and_schema_files}, all_baseline_audits_passed, all_proposed_source_audits_passed, ast_identical_except_listed_metadata_constants, predicates_contracts_and_proof_counts_unchanged, proof_closures_unchanged}' "$report"
    sha256sum "$report" "$out/proposal-01/metadata.patch"
    date -u +%Y-%m-%dT%H:%M:%SZ
}
set +e
(set -e; audit) > "$out/proposal-01-readonly-audit.stdout" 2> "$out/proposal-01-readonly-audit.stderr"
status=$?
printf '%s\n' "$status" > "$out/proposal-01-readonly-audit.exit"
exit "$status"
