#!/bin/bash
set -u
out=/home/harsh/.codex-tmp/fe2o3-multigpu-async-lifecycle-20261002/source-ci
test ! -e "$out/proposal-01.stdout" || exit 125
test ! -e "$out/proposal-01.stderr" || exit 125
test ! -e "$out/proposal-01.exit" || exit 125
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/proposal-01.started"
env -i PATH=/usr/bin:/bin HOME=/home/harsh LANG=C.UTF-8 LC_ALL=C.UTF-8 \
    python3 -I -B "$out/support.py" propose --source-frozen --name proposal-01 \
    > "$out/proposal-01.stdout" 2> "$out/proposal-01.stderr"
status=$?
printf '%s\n' "$status" > "$out/proposal-01.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/proposal-01.finished"
exit "$status"
