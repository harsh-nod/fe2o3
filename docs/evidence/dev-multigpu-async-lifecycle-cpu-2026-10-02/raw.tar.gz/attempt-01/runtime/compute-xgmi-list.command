target/debug/deps/fe2o3_runtime-6f56d726eb64a207 compute_xgmi --list --test-threads=1 
