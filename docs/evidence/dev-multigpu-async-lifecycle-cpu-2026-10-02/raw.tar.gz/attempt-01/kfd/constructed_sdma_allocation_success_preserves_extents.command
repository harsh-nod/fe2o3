target/debug/deps/fe2o3_kfd-408178a9a9b41651 constructed_sdma_allocation_success_preserves_extents --test-threads=1 
