target/debug/deps/fe2o3_kfd-408178a9a9b41651 public_sdma --list --test-threads=1 
