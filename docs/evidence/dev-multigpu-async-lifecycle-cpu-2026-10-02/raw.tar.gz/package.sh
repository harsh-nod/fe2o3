#!/bin/bash
set -euo pipefail
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-multigpu-async-lifecycle-20261002
packet="$root/docs/evidence/dev-multigpu-async-lifecycle-cpu-2026-10-02"
base=a400b2c796eb056efef24b18ff5faa2c5ba421bd
build=${1:?final build attempt}
kfd=${2:?final KFD attempt}
runtime=${3:?final runtime attempt}
checks=${4:?final tooling attempt}
cd "$root"
test "$(git rev-parse HEAD)" = "$base"
test ! -e "$packet/raw.tar.gz"
test "$(< "$raw/$build/build/overall.exit")" = 0
test "$(< "$raw/$kfd/kfd/overall.exit")" = 0
test "$(< "$raw/$runtime/runtime/overall.exit")" = 1
test "$(< "$raw/$runtime/runtime/full.exit")" = 101
test "$(< "$raw/$runtime/runtime/compute-xgmi.exit")" = 0
test "$(< "$raw/$runtime/runtime/multi-group.exit")" = 0
test "$(< "$raw/$checks/checks/overall.exit")" = 0
test -z "$(git ls-files --others --exclude-standard -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model/verus)"
sha256sum -c "$raw/$build/build/elf.sha256"
sha256sum target/debug/deps/fe2o3_kfd-408178a9a9b41651 \
    target/debug/deps/fe2o3_runtime-6f56d726eb64a207 \
    target/debug/examples/gfx942-runtime-compute-xgmi-smoke > "$raw/final-elf.sha256"
cmp <(tail -n 1 "$raw/final-elf.sha256") <(tail -n 1 "$raw/$checks/checks/elf-final.sha256")
printf '%s\n' "$base" > "$raw/base-commit.txt"
printf 'build=%s\nkfd=%s\nruntime=%s\nchecks=%s\n' "$build" "$kfd" "$runtime" "$checks" > "$raw/final-attempts.txt"
git diff --binary "$base" -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model/verus > "$raw/source.patch"
git diff --name-only "$base" -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model/verus > "$raw/source-paths.txt"
mapfile -t paths < "$raw/source-paths.txt"
test "${#paths[@]}" -gt 0
sha256sum "${paths[@]}" > "$raw/source.sha256"
sha256sum "$raw/source.patch" > "$raw/source-patch.sha256"
rustc +nightly-2026-04-03 -Vv > "$raw/rustc.txt"
cargo +nightly-2026-04-03 -V > "$raw/cargo.txt"
uname -a > "$raw/uname.txt"
mkdir -p "$packet"
tar -czf "$packet/raw.tar.gz" -C "$raw" .
cd "$packet"
sha256sum raw.tar.gz > SHA256SUMS
