#!/bin/bash
set -u
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
artifact=/home/harsh/.codex-tmp/fe2o3-multigpu-async-lifecycle-20261002
mode=${1:?mode required}
attempt=${2:?fresh attempt label required}
out="$artifact/$attempt/$mode"
mkdir -p "$out" || exit 125
test ! -e "$out/environment.txt" || exit 125
cd "$root" || exit 125
export HOME=/home/harsh PATH=/home/harsh/.cargo/bin:/usr/bin:/bin LANG=C.UTF-8 LC_ALL=C.UTF-8
export CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true RUST_TEST_THREADS=1
env | sort > "$out/environment.txt"
printf '%s\n' "$PWD" > "$out/cwd.txt"
git rev-parse HEAD > "$out/base.txt"
failed=0
stage() {
    name=$1
    seconds=$2
    shift 2
    printf '%q ' "$@" > "$out/$name.command"
    printf '\n' >> "$out/$name.command"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$out/$name.started"
    timeout --signal=TERM --kill-after=30s "$seconds" "$@" > "$out/$name.stdout" 2> "$out/$name.stderr"
    status=$?
    printf '%s\n' "$status" > "$out/$name.exit"
    date -u +%Y-%m-%dT%H:%M:%SZ > "$out/$name.finished"
    printf '%s exit=%s\n' "$name" "$status"
    if [ "$status" -ne 0 ]; then failed=1; fi
}
kfd=target/debug/deps/fe2o3_kfd-408178a9a9b41651
runtime=target/debug/deps/fe2o3_runtime-6f56d726eb64a207
case "$mode" in
    build)
        stage combined 2400s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --no-run
        if [ "$failed" -eq 0 ]; then sha256sum "$kfd" "$runtime" > "$out/elf.sha256"; fi
        ;;
    kfd)
        for filter in compute_xgmi xgmi shared_memory::tests sdma::tests model_pair_loan initialized public_sdma constructed_sdma_allocation_success_preserves_extents; do
            sha256sum "$kfd" > "$out/$filter.elf-before.sha256"
            stage "$filter-list" 60s "$kfd" "$filter" --list --test-threads=1
            stage "$filter" 600s "$kfd" "$filter" --test-threads=1
            sha256sum "$kfd" > "$out/$filter.elf-after.sha256"
            cmp "$out/$filter.elf-before.sha256" "$out/$filter.elf-after.sha256" || exit 125
        done
        ;;
    runtime)
        sha256sum "$runtime" > "$out/elf-before.sha256"
        stage compute-xgmi-list 60s "$runtime" compute_xgmi --list --test-threads=1
        stage compute-xgmi 300s "$runtime" compute_xgmi --test-threads=1
        stage multi-group-list 60s "$runtime" multi_group_drain_tests --list --test-threads=1
        stage multi-group 300s "$runtime" multi_group_drain_tests --test-threads=1
        stage full-list 60s "$runtime" --list --test-threads=1
        stage full 600s "$runtime" --test-threads=1
        sha256sum "$runtime" > "$out/elf-after.sha256"
        cmp "$out/elf-before.sha256" "$out/elf-after.sha256" || exit 125
        ;;
    checks)
        stage clippy 1200s cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-kfd -p fe2o3-runtime --all-features --lib --tests --example gfx942-runtime-compute-xgmi-smoke --no-deps -- -D warnings
        stage no-default 300s cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-runtime --no-default-features --lib
        stage example 1200s cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-runtime --all-features --example gfx942-runtime-compute-xgmi-smoke -- --test-threads=1
        stage witness-build 1200s cargo +nightly-2026-04-03 build --locked --offline -p fe2o3-runtime --all-features --profile test --example gfx942-runtime-compute-xgmi-smoke
        sha256sum "$kfd" "$runtime" target/debug/examples/gfx942-runtime-compute-xgmi-smoke > "$out/elf-final.sha256"
        mapfile -t changed < <(git diff HEAD --name-only -- '*.rs')
        mapfile -t added < <(git ls-files --others --exclude-standard -- crates/fe2o3-kfd/src crates/fe2o3-runtime/src)
        stage formatting 120s rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true "${changed[@]}" "${added[@]}"
        stage whitespace 60s git diff HEAD --check
        ;;
    *) exit 125 ;;
esac
printf '%s\n' "$failed" > "$out/overall.exit"
exit "$failed"
