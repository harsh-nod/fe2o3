#!/usr/bin/env python3
"""Ten strict native ordered-list cases; never a performance or authority proof."""
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'ead9cfab9501d8332bf3f89485dfdafbea51eb7c'
TARGET = 'gfx942-runtime-unified-segments-smoke'
PREFIX = '/tmp/fe2o3-unified-segments-20261002-'
BUILD_CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0x10a254ce4987e716', '0x53691ef168a0147d']
CARDS = ['card6', 'card7']
BDFS = ['0000:C6:00.0', '0000:E5:00.0']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
CASES = [(f'segments-{case}-{direction}', case, ids)
         for case in ('1', '4', '65', '4096', 'packets')
         for direction, ids in (('forward', IDS), ('reverse', IDS[::-1]))]
ENV = {
    'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '4',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
    'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUST_TEST_THREADS': '1',
    'FE2O3_HIP_SYS_DISABLE': '1',
}
LIMITATIONS = [
    'selected GPUs 6 and 7 only; no other GPU is admitted or used',
    'point observations, not continuous attachment census or exclusive reservation',
    'existing finite R57 constructor; no kernels loaded or launched',
    'settled initialized PUBLIC native owners only; no pending compute provenance claim',
    'one cancelled and one completed list per process; no repeat-context lifetime claim',
    'full logical allocation bytes and guards checked; hidden pool padding unobserved',
    'ordered prefix semantics, not an atomic transaction or native fault qualification',
    'native logical completion count does not prove physical overlap or throughput',
    'no general application-kernel authorization, performance parity or formal refinement',
]
BASELINE = None


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_receipt(name, argv):
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout, stderr = ((folder / item).read_bytes() for item in ('stdout', 'stderr'))
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert receipt['exit_code'] == 0 and receipt['timed_out'] is False, (name, receipt, stderr)
    assert receipt['local_process_group_absent'] is True, (name, receipt)
    assert receipt['transport_timeout_seconds'] == 480
    start, finish = (datetime.fromisoformat(receipt[key]) for key in ('started', 'finished'))
    assert start <= finish and 0 <= receipt['elapsed_seconds'] <= 490
    return receipt, stdout, stderr


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    receipt, stdout, stderr = read_receipt(name, argv)
    assert process.returncode == receipt['exit_code'], (name, receipt, stderr)
    assert not stderr, (name, stderr)
    return stdout.decode('utf-8')


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def remote(name, argv, bound='30s'):
    return capture(name, remote_argv(argv, bound))


def admit(name):
    state = json.loads(remote(name + '-availability', AVAILABILITY))
    for card, uid, bdf in zip(CARDS, IDS, BDFS, strict=True):
        assert state[card]['Unique ID'] == BASELINE[card]['Unique ID'] == uid
        assert state[card]['PCI Bus'] == BASELINE[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == BASELINE[card]['GPU use (%)'] == '0'
        for field in ('VRAM Total Memory (B)', 'VRAM Total Used Memory (B)'):
            assert state[card][field] == BASELINE[card][field]
        # Prior clean driver baseline is about 285 MiB; this cap is not a
        # substitute for the simultaneous exact PID/attachment checks below.
        assert int(state[card]['VRAM Total Used Memory (B)']) <= 512 * 1024 * 1024
        assert int(state[card]['VRAM Total Memory (B)']) >= 16 * 1024 * 1024 * 1024
    assert state['system'] == BASELINE['system'], 'PID roster changed; reject and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
        assert pid not in records and not {'6', '7'}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    for suffix in ('availability', 'attachments', 'host-memory'):
        receipt = json.loads((ROOT / (name + '-' + suffix) / 'result.json').read_text())
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(receipt['finished'])).total_seconds()
        assert 0 <= age <= 300, (name, suffix, age)


@lru_cache(maxsize=5)
def oracle(case):
    cap, source_base, destination_base = 0x003fffe0, 17, 53
    if case == 'packets':
        source_bytes, destination_bytes = 2 * cap + 4096 + 97, 2 * cap + 4096 + 321
        source_len, destination_len = 2 * cap + 2048, 2 * cap + 3072
        segments = [(3, 41, cap + 17), (19, cap + 13, cap + 5), (cap + 53, 7, 31)]
    else:
        assert case in ('1', '4', '65', '4096')
        source_bytes, destination_bytes = 65536 + 97, 65536 + 321
        source_len, destination_len = 32768, 49152
        segments = []
        for index in range(int(case)):
            if index in (0, 2):
                segments.append((0, 0, 64))
            elif index == 1:
                segments.append((128, 32, 64))
            else:
                segments.append((512 + index * 13 % 32000,
                                 512 + index * 17 % 48000, index % 19 + 1))
    assert 0 < len(segments) <= 4096
    assert source_base + source_len < source_bytes
    assert destination_base + destination_len < destination_bytes
    # Independent u64 wrapping SplitMix transform, taking its low byte.
    mask = (1 << 64) - 1
    source = bytearray(source_bytes)
    for index in range(source_bytes):
        value = (index + 0x9e3779b97f4a7c15) & mask
        value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
        value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
        source[index] = (value ^ (value >> 31)) & 255
    destination = bytearray([0xa5]) * destination_bytes
    for source_offset, destination_offset, size in segments:
        assert size > 0 and source_offset + size <= source_len
        assert destination_offset + size <= destination_len
        start, end = source_base + source_offset, source_base + source_offset + size
        out = destination_base + destination_offset
        destination[out:out + size] = source[start:end]
    digest = hashlib.sha256(b'fe2o3.unified-peer-segments.v1\0')
    for data in (source, destination):
        digest.update(struct.pack('<Q', len(data)))
        digest.update(data)
    return dict(case=case, segments=str(len(segments)),
        packets=str(sum((size + cap - 1) // cap for _, _, size in segments)),
        useful_bytes=str(sum(size for _, _, size in segments)),
        source_bytes=str(source_bytes), destination_bytes=str(destination_bytes),
        source_envelope=f'{source_base}:{source_len}',
        destination_envelope=f'{destination_base}:{destination_len}',
        output_sha256=digest.hexdigest())


def expected(case, ids):
    assert ids in (IDS, IDS[::-1]) and len(set(ids)) == 2
    fields = dict(schema='fe2o3.unified-peer-segments.v1', devices='2',
        unique_ids=','.join(ids), backend='unified-compute-xgmi',
        authority='qualification-r57-n3-v2', kernels='0', native_counter='0,1',
        publication_retained='1', initial_cancel='cancelled', late_cancel='too-late',
        descriptor_snapshot='pass', event_scope='whole-list', source='full-byte-pass',
        destination='full-byte-pass', digest='length-prefixed-source-destination',
        cleanup='explicit-owned', physical_overlap='unmeasured',
        performance_acceptance='false', formal_refinement='false', **oracle(case))
    assert len(fields) == 28
    return fields


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    result = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in result
        result[key] = value
    return result


def source_snapshot():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, env=ENV, text=True).strip() == BASE
    listing = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard',
        '-z', '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=REPO, env=ENV)
    names = sorted(set(os.fsdecode(listing).rstrip('\0').split('\0')))
    assert names and all(name and not (REPO / name).is_symlink() for name in names)
    return {name: sha((REPO / name).read_bytes()) for name in names}


def build_witness():
    folder = ROOT.parent / 'build-witness-final-01'
    receipt = json.loads((folder / 'receipt.json').read_text())
    command = json.loads((folder / 'command.json').read_text())
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO)
    assert receipt['environment'] == ENV
    assert receipt['controller_sha256'] == sha((ROOT.parent / 'capture.py').read_bytes()) == BUILD_CAPTURE_SHA
    assert all(receipt[key] == value for key, value in command.items())
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '900s',
        'cargo', 'build', '--locked', '--offline', '-p', 'fe2o3-runtime',
        '--no-default-features', '--features', 'hardware-qualification', '--example', TARGET,
        '--profile', 'test', '--message-format=json']
    for name in ('stdout', 'stderr'):
        assert sha((folder / name).read_bytes()) == receipt[name + '_sha256']
    before = json.loads((folder / 'source-before.json').read_text())
    assert before == json.loads((folder / 'source-after.json').read_text()) == source_snapshot()
    local = REPO / 'target/debug/examples' / TARGET
    assert set(receipt['executables']) == {str(local)}
    identity = receipt['executables'][str(local)]
    assert identity['target'] == TARGET and identity['test'] is False
    assert local.is_file() and not local.is_symlink()
    binary = local.read_bytes()
    assert len(binary) == identity['byte_length'] and sha(binary) == identity['sha256']
    assert binary.startswith(b'\x7fELF')
    rows = [json.loads(line) for line in (folder / 'stdout').read_text().splitlines()]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'] is True
    artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['executable'] == str(local)
    assert artifacts[0]['target']['name'] == TARGET and artifacts[0]['target']['kind'] == ['example']
    assert artifacts[0]['profile']['test'] is False
    return dict(local=str(local), sha256=identity['sha256'], byte_length=identity['byte_length'],
                build_receipt_sha256=sha((folder / 'receipt.json').read_bytes()),
                source_manifest_sha256=sha((folder / 'source-before.json').read_bytes()))


def main():
    global BASELINE
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1 and not (ROOT / 'campaign.json').exists()
    assert len(CASES) == len({name for name, _, _ in CASES}) == 10
    # Compute every oracle before host admission so local hashing cannot age it.
    requirements = {name: expected(case, ids) for name, case, ids in CASES}
    binary = build_witness()
    completed, errors, directory, cleaned = [], [], None, False
    try:
        BASELINE = json.loads(remote('initial-availability', AVAILABILITY))
        receipt, _, _ = read_receipt('initial-availability', remote_argv(AVAILABILITY))
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(receipt['finished'])).total_seconds()
        assert 0 <= age <= 300
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', PREFIX + 'XXXXXX']).strip()
        assert re.fullmatch(re.escape(PREFIX) + '[A-Za-z0-9]{6}', candidate)
        directory = candidate
        binary['remote'] = directory + '/unified-segments-witness'
        capture('upload-witness', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
            '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
        assert remote('initial-hash', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
        for name, case, ids in CASES:
            admit(name)
            assert remote(name + '-hash', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8',
                binary['remote'], *ids, case], '300s')
            fields = pass_fields(output)
            assert fields == requirements[name], (name, fields, requirements[name])
            admit(name + '-post')
            completed.append(dict(name=name, case=case, unique_ids=ids, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                path = binary['remote']
                probe = ('import json,os,sys; from pathlib import Path; '
                    'target=sys.argv[1]; found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe.removesuffix(" (deleted)")==target: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, path])
                assert json.loads(observed) == {'owned_executable_pids': []}
                exists = remote('owned-executable-exists', ['/usr/bin/python3', '-I', '-B', '-c',
                    'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))', path])
                present = json.loads(exists)
                assert present in ({'exists': True}, {'exists': False})
                if present['exists']:
                    try:
                        assert remote('final-hash', ['/usr/bin/sha256sum', path]).split() == [binary['sha256'], path]
                    except Exception as error:
                        errors.append('final hash: ' + repr(error))
                    remote('remove-owned-executable', ['/usr/bin/rm', '--', path])
                else:
                    errors.append('final hash: owned witness absent')
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        if BASELINE is not None:
            try:
                admit('final')
            except Exception as error:
                errors.append('final admission: ' + repr(error))
        try:
            final_binary = build_witness()
            assert final_binary == {key: value for key, value in binary.items() if key != 'remote'}
        except Exception as error:
            errors.append('final source/binary identity: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == 10 and cleaned,
            errors=errors, completed=completed, expected_cases=10, binary=binary,
            selected_cards=CARDS, selected_unique_ids=IDS, selected_bdfs=BDFS,
            owned_directory=directory, owned_cleanup_complete=cleaned,
            native_process_timeout_seconds=300, transport_timeout_seconds=360,
            exclusive_reservation=False, performance_acceptance=False, formal_refinement=False,
            controller_sha256=sha(Path(__file__).read_bytes()),
            transport_sha256=sha((ROOT / 'capture.py').read_bytes()), limitations=LIMITATIONS)
        with (ROOT / 'campaign.json').open('x') as output:
            json.dump(result, output, indent=2)
            output.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
