"""Independent full-byte oracles; no witness/source imports or native effects."""
import hashlib
import struct

PACKET = 4194272
ELEMENTS = 65536
BYTES = 4 * ELEMENTS


def uid_fields(ids):
    assert len(ids) == len(set(ids)) == 3
    assert all(uid == f'0x{int(uid, 16):016x}' and int(uid, 16) > 0 for uid in ids)
    return ','.join(ids)


def framed(domain, parts):
    digest = hashlib.sha256(domain)
    for part in parts:
        digest.update(struct.pack('<Q', len(part)))
        digest.update(part)
    return digest.hexdigest()


def copy_geometry(case):
    assert case in ('disjoint', 'overlap', 'duplicates', 'packets')
    if case == 'packets':
        return ([2 * PACKET + 4193, 2 * PACKET + 4289], 2 * PACKET + 4417,
                2 * PACKET + 2048, 2 * PACKET + 3072,
                [[(3, 41, PACKET + 17), (PACKET + 53, 7, 31)],
                 [(19, PACKET + 13, PACKET + 5), (PACKET + 79, 13, 37)]])
    lists = {
        'disjoint': [[(0, 0, 8193), (12288, 10000, 4097)],
                     [(7, 20000, 8195), (15000, 32000, 4099)]],
        'overlap': [[(0, 0, 8193), (12288, 10000, 4097)],
                    [(7, 4096, 8195), (15000, 11000, 4099)]],
        'duplicates': [[(0, 0, 4096), (4096, 2048, 4096), (0, 0, 4096), (8192, 3072, 1025)],
                       [(7, 1024, 4097), (5000, 4096, 2049), (7, 1024, 4097), (12288, 2048, 513)]],
    }[case]
    return [65633, 65729], 65857, 32768, 49152, lists


def copy_digests(case):
    sizes, destination_size, source_envelope, destination_envelope, lists = copy_geometry(case)
    mask = (1 << 64) - 1
    # SplitMix is a source pattern, independent of any destination oracle.
    base = bytearray(max(sizes))
    for index in range(len(base)):
        value = (index + 0x9e3779b97f4a7c15) & mask
        value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
        value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
        base[index] = (value ^ (value >> 31)) & 255
    hashes = []
    for round_number in range(2):
        sources = [base[:size].translate(bytes(value ^ (source * 53) ^ (round_number * 73)
                                                   for value in range(256)))
                   for source, size in enumerate(sizes)]
        destination = bytearray([0xa5 ^ (round_number * 29)]) * destination_size
        for source, source_base in enumerate((17, 29)):
            for start, target, length in lists[source]:
                assert length > 0 and start + length <= source_envelope
                assert target + length <= destination_envelope
                assert source_base + start + length <= sizes[source]
                assert 53 + target + length <= destination_size
                destination[53 + target:53 + target + length] = \
                    sources[source][source_base + start:source_base + start + length]
        host = bytearray([0x6c ^ (round_number * 41)]) * (19 + destination_size + 23)
        host[19:19 + destination_size] = destination
        hashes.append(framed(b'fe2o3.destination-peer-segments.full-bytes.v1\0',
                             [*sources, destination, host]))
    assert hashes[0] != hashes[1]
    return hashes


def expected_copy(args):
    dispose = bool(args and args[0] == '--dispose-source')
    args = args[1:] if dispose else args
    assert len(args) == 4
    ids, case = args[:3], args[3]
    sizes, destination_size, source_envelope, destination_envelope, lists = copy_geometry(case)
    return dict(schema='fe2o3.destination-peer-segments.v1', authority='production-deny-all',
        transport='NATIVE-XGMI', devices='3', unique_ids=uid_fields(ids), case=case,
        source_disposal=str(dispose).lower(), contexts='1', rounds='2', kernels='0', modules='0',
        source_bytes=','.join(map(str, sizes)), destination_bytes=str(destination_size),
        source_offsets='17,29', destination_offset='53', source_envelope=str(source_envelope),
        destination_envelope=str(destination_envelope),
        descriptors_per_round=','.join(str(len(parts)) for parts in lists),
        copied_bytes_per_round=','.join(str(sum(length for _, _, length in parts)) for parts in lists),
        packets_per_round=','.join(str(sum((length + PACKET - 1) // PACKET for _, _, length in parts)) for parts in lists),
        host_offset='19', host_suffix='23', host_bytes=str(19 + destination_size + 23),
        lists='4', d2h_copies='2', native_counter='0,2,4', completion_receipts='6',
        callbacks='exact-original-ids-once-successful', admission='all-three-before-progress',
        dependency='exact-latest-predecessor-event', events='released-before-progress',
        descriptor_snapshot='caller-overwritten-after-admission',
        progress=('first-list-settlement-then-final-readback-only' if dispose else 'final-readback-only'),
        source_disposal_native_counts=('1,3' if dispose else 'not-applicable'),
        first_source_checks=('full-after-first-before-disposal' if dispose else 'full-after-tail'),
        sources='full-byte-pass', destination='full-byte-pass', initialized_complement='full-byte-pass',
        host_guards='full-byte-pass', digest='domain-and-u64le-length-prefixed-S0-S1-D-host',
        round_sha256=','.join(copy_digests(case)), payloads_changed='true',
        first_source_allocation=('disposed-after-first-replaced-next-round' if dispose else 'reused'),
        remaining_allocations='reused', results='released-readback-second-first-before-refresh',
        drain='completed-tail-only', cleanup='logical-and-native-explicit',
        physical_overlap='unmeasured', performance_acceptance='false', formal_refinement='false')


def compute_descriptors(source, count):
    assert source in (0, 1) and count in (4, 65, 4096)
    result = []
    for index in range(count):
        if index in (0, 2):
            result.append((4 * (1 + source * 9), 64, 128))
        elif index == 1:
            result.append((4 * (65 + source * 5), 96, 128))
        elif index == 3:
            result.append((4 * (257 + source * 7), 192, 68))
        else:
            result.append((4 * (1 + (index * 13 + source * 29) % 10000),
                           4 * (257 + (index * 17 + source * 19) % 40000),
                           4 * (1 + index % 17)))
    return result


def legacy_windows(overlap):
    result, end = [], 64
    for index in range(2):
        start = 4 * (1 + 7 * index)
        target = end if index == 0 else end + (-48 if overlap else 28)
        length = (((BYTES - 512) // 2) & ~3) - 4 * index
        result.append((start, target, length))
        end = target + length
    return result


def compute_digest(count=None, overlap=False):
    # All f32 additions here are exact integer quarters. No artifact/authority output is imported.
    c = [(index & 63) + 2 * (index & 31) for index in range(ELEMENTS)]
    d = [(index & 63) + 4 * (index & 31) for index in range(ELEMENTS)]
    sources = [c, d] if count is not None else [d, d]
    gathered = [1] * ELEMENTS
    lists = ([compute_descriptors(source, count) for source in range(2)] if count is not None
             else [[window] for window in legacy_windows(overlap)])
    for source, parts in enumerate(lists):
        for start, target, length in parts:
            assert start % 4 == target % 4 == length % 4 == 0
            assert length > 0 and start + length <= BYTES and target + length <= BYTES
            gathered[target // 4:(target + length) // 4] = sources[source][start // 4:(start + length) // 4]
    computed = [value + 2 * (index & 31) for index, value in enumerate(gathered)]
    parts = [b''.join(struct.pack('<f', quarter / 4) for quarter in values)
             for values in [*sources, gathered, computed]]
    returned = bytearray([0xa5]) * (BYTES + 769)
    returned[131:131 + BYTES - 64] = parts[3][20:20 + BYTES - 64]
    host = bytearray([0x5a]) * (BYTES + 1153)
    host[97:97 + len(returned)] = returned
    parts.extend((returned, host))
    domain = (b'fe2o3.destination-segments-compute.v1\0' if count is not None
              else b'fe2o3.gather-compute.v1\0')
    return framed(domain, parts)


def compute_common(ids):
    return dict(authority='qualification-r57-n3-v2', devices='3', sources='2',
        unique_ids=uid_fields(ids), elements=str(ELEMENTS), bytes=str(BYTES), peer_copies='3',
        dependent_readbacks='1', public_events='released-after-dependent-admission',
        consumer_bindings='full-frame-read-stable-read-full-write', native_transport='NATIVE-XGMI',
        native_counter='0,3', output='full-byte-pass', source_preservation='full-byte-pass',
        gathered_frame='full-byte-pass', return_guards='full-byte-pass', host_guards='full-byte-pass',
        host_output_installations='0', pipeline_host_joins='0', journal='enabled', contexts='1',
        owners='1', batches='1', results_release='reverse-dependencies', final_drain='completed-only',
        cleanup='owned-shutdown-explicit', physical_overlap='unmeasured',
        performance_acceptance='false', formal_refinement='false')


def expected_compute(args):
    assert len(args) == 5 and args[0] in ('--destination-segments-compute', '--late-destination-segments-compute')
    count = int(args[1])
    assert str(count) == args[1] and count in (4, 65, 4096)
    late = args[0] == '--late-destination-segments-compute'
    result = compute_common(args[2:])
    result.update(schema='fe2o3.destination-segments-compute.v1', lists='2',
        segments_per_list=str(count), descriptors=str(2 * count), setup_launches='4',
        pipeline_launches='1', completion_receipts='5', pipeline='settled-list-list-compute-peer-readback',
        source_payloads='C,D', source_producers='completed-and-released-before-list-admission',
        admission=('lists-preadmitted-consumer-after-oldest-publication' if late else 'all-before-explicit-progress'),
        progress=('oldest-list-seed-then-final-readback-stream-only' if late else 'final-readback-stream-only'),
        consumer_dependencies='latest-list-only', descriptor_snapshot='caller-overwritten-after-admission',
        output_sha256=compute_digest(count),
        digest='domain-and-u64le-length-prefixed-C-source-D-source-C-D-E-host')
    if late:
        result.update(publication_observed='true', publication_identity='ordered-roster-inference',
            paired_custody='validated-by-consumer-admission', retained_native_at_consumer_admission='1',
            retained_native_counter='0,1,0', publication_capture='single-peer-leaf-quantum',
            oldest_seed='bounded-context-progress')
    return result


def expected_legacy(args):
    assert len(args) == 4 and args[0] in ('--gather-compute', '--gather-compute-overlap')
    overlap = args[0] == '--gather-compute-overlap'
    result = compute_common(args[1:])
    result.update(schema='fe2o3.gather-compute.v1', overlap=str(overlap).lower(),
        windows=','.join(':'.join(map(str, window)) for window in legacy_windows(overlap)),
        setup_launches='3', pipeline_launches='3', completion_receipts='7',
        pipeline='compute-gather-compute-peer-readback', admission='all-before-explicit-progress',
        progress='final-readback-stream-only', consumer_dependencies='latest-gather-only',
        output_sha256=compute_digest(overlap=overlap), digest='length-prefixed-sources-C-D-E-host')
    return result


def expected(kind, args):
    if kind == 'copy':
        return expected_copy(args)
    assert kind == 'compute'
    if args[0] in ('--gather-compute', '--gather-compute-overlap'):
        return expected_legacy(args)
    return expected_compute(args)
