"""Bind independently replayed CPU/native qualification to one current source."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
BASE = 'c37c04d60ff9bdfd7ede21b2375d8bf5f79298a2'


def sha(path):
    assert path.is_file() and not path.is_symlink()
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and all(value.isdigit() for value in sys.argv[1:])
    generation, proposal = sys.argv[1:]
    spec = importlib.util.spec_from_file_location('aggregate_capture', RAW / 'capture.py')
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=capture.ROOT,
                                   text=True).strip() == BASE
    source = capture.snapshot()
    cpu, native = (read(RAW / name) for name in ('audit-cpu.json', 'audit-native.json'))
    assert cpu['accepted'] and cpu['base'] == BASE and cpu['source_sha256'] == source
    assert (cpu['generation'], cpu['proposal']) == (generation, proposal)
    assert cpu['auditor_sha256'] == sha(RAW / 'audit_cpu.py')
    for name, digest in cpu['controller_sha256'].items():
        assert sha(RAW / name) == digest, name
    assert cpu['formal_qualification'] is cpu['solver_executed'] is cpu['performance_claim'] is False
    assert native['accepted'] and native['errors'] == [] and native['owned_cleanup_complete']
    assert native['generation'] == generation and len(native['completed']) == native['expected_cases'] == 18
    assert native['performance_acceptance'] is native['formal_refinement'] is False
    assert native['controller_sha256'] == sha(RAW / 'hardware-02/campaign.py')
    assert native['oracle_sha256'] == sha(RAW / 'native_oracle.py')
    assert native == read(RAW / 'hardware-02/campaign.json')
    spec = importlib.util.spec_from_file_location('aggregate_receipts', RAW / 'audit_cpu.py')
    validation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validation)
    checker = validation.Audit(generation, proposal)
    assert checker.source == source and cpu['controller_sha256'] == validation.PINS
    for label, bound, command in (
        ('hardware-final-' + generation, '3600s',
         ['python3', '-I', '-B', str(RAW / 'hardware-02/campaign.py'), 'live', generation]),
        ('audit-native-final-' + generation, '900s',
         ['python3', '-I', '-B', str(RAW / 'hardware-02/campaign.py'), 'replay', generation]),
        ('audit-cpu-final-' + generation, '900s',
         ['python3', '-I', '-B', str(RAW / 'audit_cpu.py'), generation, proposal]),
        ('oracle-tests-final-' + generation, '120s',
         ['python3', '-I', '-B', str(RAW / 'oracle_tests.py')]),
    ):
        checker.receipt(label, bound, command)
    live = checker.receipts['hardware-final-' + generation]
    replay = checker.receipts['audit-native-final-' + generation]
    cpu_receipt = checker.receipts['audit-cpu-final-' + generation]
    assert validation.instant(live['finished']) <= validation.instant(replay['started'])
    assert (validation.instant(cpu_receipt['started']) <= validation.instant(cpu['started'])
            <= validation.instant(cpu['finished']) <= validation.instant(cpu_receipt['finished']))
    replay_lines = (RAW / ('audit-native-final-' + generation) / 'stdout').read_text().splitlines()
    assert validation.decode(replay_lines[-1]) == {
        key: value for key, value in native.items() if key != 'events'}
    oracle_output = (RAW / ('oracle-tests-final-' + generation) / 'stderr').read_text()
    assert 'Ran 8 tests' in oracle_output and oracle_output.rstrip().endswith('OK')
    pins = {path.relative_to(RAW).as_posix(): sha(path)
            for path in sorted(RAW.rglob('*.py'))}
    result = dict(accepted=True, base=BASE, generation=generation, proposal=proposal,
                  source_sha256=source, cpu_audit_sha256=sha(RAW / 'audit-cpu.json'),
                  native_audit_sha256=sha(RAW / 'audit-native.json'), controller_pins=pins,
                  runtime_passed=2294, runtime_ignored=32, example_tests=40,
                  runtime_doctests=61, independent_oracle_tests=8, native_cases=18,
                  kfd_tests_reused=1950, fresh_kfd_execution=False,
                  native_transport_receipts=len(native['events']),
                  aggregate_receipt_sha256=checker.selected,
                  formal_qualification=False, solver_executed=False, performance_claim=False)
    checker.archive.close()
    assert capture.snapshot() == source
    with (RAW / 'audit-final.json').open('x') as output:
        json.dump(result, output, sort_keys=True, indent=2)
        output.write('\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('source_sha256', 'controller_pins')}, sort_keys=True))


if __name__ == '__main__':
    main()
