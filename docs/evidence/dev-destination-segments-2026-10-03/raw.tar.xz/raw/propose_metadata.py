"""Run the accepted literal-only source-identity proposer on this checkpoint."""
import hashlib
from pathlib import Path
import sys
import types

RAW = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
source = RAW / 'reference/propose.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50'
module = types.ModuleType('strict_metadata')
module.__file__ = str(source)
exec(compile(data, str(source), 'exec'), module.__dict__)
module.BASE = 'c37c04d60ff9bdfd7ede21b2375d8bf5f79298a2'
module.OUT = RAW / ('proposal-' + sys.argv[1])
module.OUT.mkdir(mode=0o700)
module.main()
