# Ordered Destination Segment-List Composition

Draft for the checkpoint based on
`c37c04d60ff9bdfd7ede21b2375d8bf5f79298a2`. CPU, source-control and native
acceptance results must be filled from final selected receipts. This draft
does not assert that any qualification campaign has passed.

## Functional Scope

The new default-false `supports_ordered_peer_copy_segments_v1` backend
capability allows version-journal Context submissions to queue multiple
settled-source ordered peer-copy lists into the same initialized DeviceLocal
destination on one stream. Each successor must supply the exact event for
the current latest segmented destination writer. An earlier event, missing
event, foreign event, wrong stream or unrelated writer does not authorize the
new composition.

Each list retains its immutable checked descriptor plan and a distinct
destination-frame identity. The successor additionally retains the exact
predecessor result and immutable frame identity. These are not scalar copy
envelopes or fabricated compute producers. A full-frame Read-only compute
consumer or D2H copy can depend on the latest list, including initialized
bytes outside the written descriptors. Duplicate descriptors, overlapping
writes and holes retain ordered-list semantics.

Context holds an ordinary current-version source read lease and a queued
whole-destination writer. The existing queued-writer journal activates each
writer only after its actual predecessor settles successfully. Completion of
the final backend consumer alone cannot commit its Context destination while
logical predecessors remain unresolved. Public events can be released after
consumer admission because independent result retains preserve ancestry.

The unified KFD backend serializes physical destination ownership across the
lists. It authenticates the original endpoint records, exact shared descriptor
plans, same-stream predecessor identities and both retained native endpoint
markers. Predecessor traversal is bounded by strictly older identities and
decreasing frame ranks. Legacy transfer depth remains separate from the
consumer-frame rank. A restored completed ancestor can outlive disposal of
its source; a pending ancestor must still authenticate that source.

## Failure and Compatibility

Prepublication cancellation refunds only the canceled list's leases and
dependency retains. Failed predecessors cannot promote a successful frame;
destination versions remain conservatively Unknown after failed writes.
Indeterminate native outcomes retain the existing fail-stop custody policy.
No device reset, foreign-process termination or new error-classification
assumption is introduced by this composition.

The new capability does not change default backends, no-journal admission,
ordinary scalar coverage or existing pending-compute source admission.
Existing transfers outside the new frame profile keep their legacy behavior
where already admissible; unrelated pending controls do not acquire new data
provenance. This new ordered destination profile uses settled sources and
settled-origin list predecessors. Chaining pending-compute-source lists into
an already pending destination is not added here.

## Verification Boundaries

Focused CPU tests exercise the actual Context and backend adapters with
scripted storage and completion. Their byte checks establish test-model
ordering and frame behavior, not physical DMA or GPU arithmetic. Selected
native witnesses must independently check complete output bytes and untouched
guards, release events after admission, drive the final consumer stream, and
retain exact source/executable, device-admission and owned-cleanup receipts.

Source-guard maintenance changes only audited hash and source-inventory
literals. Existing producer-reader observer methods, journal/fold executable
proof bodies and proof predicates remain unchanged. Historical arithmetic or
journal proofs do not constitute a proof of this new Context/backend adapter;
no new solver/refinement qualification is claimed.

This checkpoint does not complete A3 or establish general HIP/HSA parity.
General application-kernel authority, broader destination-list/source-producer
combinations, indeterminate native-failure isolation, broad device/topology
coverage and matched performance remain separate gates. A finite unchanged
qualification kernel used by a witness does not expand production kernel
authority or prove arbitrary application kernels.
