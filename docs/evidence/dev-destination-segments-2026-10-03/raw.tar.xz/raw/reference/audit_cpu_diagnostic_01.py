"""Offline CPU receipt audit; historical KFD reuse is explicitly source-scoped."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile
import tomllib
import types

import yaml

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'c37c04d60ff9bdfd7ede21b2375d8bf5f79298a2'
ARCHIVE = REPO / 'docs/evidence/dev-xgmi-creation-recovery-2026-10-03/raw.tar.xz'
ARCHIVE_SHA = 'b3e89120907953c609593dcac492d79280b5b6d7e535084e428b2d02e7d8335b'
PINS = {
    'capture.py': '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1',
    'qualify.py': 'b04fa8e004c497803b138b4395246f405f38efe91a375d38ad0f9d74d07bc91f',
    'source_controls_baseline.py': 'fb5b67b44ad85fd21792a2fe18f9bac60897033c8a37a51ea2fa5c04e0277a5c',
    'source_controls_final.py': '57b0d19228fd95ee5001b5d82759588277df1ea3c1c1d128f54573ee1a835112',
    'propose_metadata.py': 'e7892906cade963d0981e27b9615995745c70a98bddda68624df06c8dace3439',
    'verify_metadata.py': '361e75242c5358382fbf9e7aeff1718ba8fa3f2e039732d9d8c6ca03603f945c',
    'reference/propose.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    'reference/verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
}
CONTEXT_TESTS = '''ordered_segments_latest_frame_reconciles_both_lists_from_only_final_readback
ordered_segments_latest_frame_feeds_all_read_only_compute_aliases
ordered_segments_require_enabled_exact_latest_same_stream_predecessor
ordered_segments_retained_successor_outlives_disposed_ancestor_source
ordered_segments_cancelled_or_failed_predecessor_never_promotes_latest_frame
ordered_segments_cancel_successor_refunds_only_its_source_and_predecessor_hold
ordered_segments_immutable_predecessor_and_rank_drift_fail_before_observation
ordered_segments_depth_bound_rejects_extra_pending_writer_without_effects
ordered_segments_foreign_and_released_events_reject_before_backend_admission
ordered_segments_completed_event_is_only_control_after_destination_rewrite'''.splitlines()
BACKEND_TESTS = '''ordered_segments_latest_frame_readback_serializes_overlap_and_released_events
ordered_segments_latest_compute_return_readback_waits_for_published_ancestor
ordered_segments_completed_ancestor_source_can_be_disposed_before_tail
ordered_segments_missing_latest_event_or_wrong_stream_never_mints_frame
ordered_segments_cancelled_ancestor_fails_tail_without_native_extraction
ordered_segments_predecessor_rank_plan_and_route_corruption_fail_closed
ordered_segments_depth_bound_rejects_before_effect_and_refunds_all_retains
ordered_segments_published_ancestor_fault_retains_tail_frame_and_both_owners'''.splitlines()
DEFERRED_TESTS = '''destination_segment_cli_keeps_two_settled_sources_and_three_devices_explicit
destination_segment_oracle_distinguishes_sources_list_order_and_full_guards
destination_segment_report_does_not_invent_pending_source_or_kernel_authority'''.splitlines()
DESTINATION_TESTS = '''cli_accepts_all_shapes_and_both_source_lifetimes
cli_rejects_zero_duplicate_overflow_and_malformed_uids_or_modes
every_descriptor_fits_independent_logical_envelopes_and_exact_packet_tails
complete_oracle_matches_independent_last_writer_lookup_and_preserves_guards
overlaps_and_duplicates_observe_both_descriptor_and_list_order
changed_payloads_and_length_framing_cover_complete_original_owners
exact_report_schema_distinguishes_seeded_disposal_from_final_only_progress'''.splitlines()
GUARDS = {
    'check-request-charge.py', 'check-retained-credit-dispatch.py',
    'check-producer-input-fold.py', 'check-producer-input-validate.py',
    'check-producer-journal-observers.py', 'check-retained-pair-routing.py',
    'check-producer-input-composition.py', 'check-producer-journal-composition.py',
    'test-producer-input-composition.py', 'producer-journal-composition-mutations-v1.py',
}
LOCAL_KFD_PACKAGES = {
    'fe2o3-amd-target', 'fe2o3-amdhsa-loader', 'fe2o3-aql', 'fe2o3-drm-uapi',
    'fe2o3-hsaco', 'fe2o3-kfd', 'fe2o3-kfd-uapi', 'fe2o3-resource-accounting',
    'fe2o3-runtime-model', 'fe2o3-target-spec',
}
# KFD and runtime-model share these source bodies by literal include/path, even
# though fe2o3-runtime itself is not a Cargo dependency of fe2o3-kfd.
KFD_SHARED_RUNTIME = {
    'context/allocation_admission/retained_lookup_body.rs',
    'context/completion_journal_prefix_body.rs', 'context/completion_reconciliation_body.rs',
    'context/completion_settlement_body.rs', 'context/versions/producer_input_fold_body.rs',
    'context/versions/producer_input_preflight_body.rs', 'context/versions/producer_journal_observer_bodies.rs',
    'context/versions/settlement_bodies.rs', 'kfd_backend/compute_peer_gate_body.rs',
    'kfd_backend/compute_pipeline_lifecycle_body.rs', 'kfd_backend/compute_pipeline_publication_body.rs',
    'kfd_backend/compute_quiescence_body.rs', 'kfd_backend/materialized_publication.rs',
    'kfd_backend/materialized_source_event.rs', 'kfd_backend/materialized_submission_attempt.rs',
    'kfd_backend/materialized_completion_receipt.rs', 'kfd_backend/ordered_publication.rs',
    'kfd_backend/ordered_publication_settlement_body.rs', 'kfd_backend/ordinary_queue_io.rs',
    'kfd_backend/xgmi_retained/routing_bodies.rs', 'kfd_backend/xgmi_retained/routing_declarations.rs',
    'retained_credit_dispatch_body.rs',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return digest(path.read_bytes())


def decode(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            assert key not in result, key
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=unique)


def read(path):
    return decode(path.read_bytes())


def instant(value):
    result = datetime.fromisoformat(value)
    assert result.tzinfo is not None
    return result


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def baseline(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=REPO)


def roster(text):
    names = re.findall(r'^(\S+): test$', text, re.M)
    assert names and len(names) == len(set(names))
    assert re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', text, re.M) == [(str(len(names)), '0')]
    assert all(not line or re.fullmatch(r'\S+: test|\d+ tests?, \d+ benchmarks?', line)
               for line in text.splitlines())
    return sorted(names)


def outcomes(text, expected, passed, ignored):
    # Preserve exactly the two existing subprocess-abort test output shapes.
    for name, count in {
        'kfd_backend::tests::runtime_compute_pipeline_drop_aborts_for_every_live_logical_phase': 5,
        'kfd_backend::tests::scripted_sdma_drop_still_aborts_with_live_or_terminal_custody': 2,
    }.items():
        if name in expected:
            block = (f'test {name} ... \nrunning 1 test\n' * count) + f'test {name} ... ok'
            assert text.count(block) == 1
            text = text.replace(block, f'test {name} ... ok', 1)
    rows = re.findall(r'^test (\S+) \.\.\. (ok|ignored(?:, [^\n]*)?)$', text, re.M)
    assert Counter(name for name, _ in rows) == Counter(expected)
    assert sum(status == 'ok' for _, status in rows) == passed
    assert sum(status.startswith('ignored') for _, status in rows) == ignored
    summaries = [line for line in text.splitlines() if line.startswith('test result:')]
    assert len(summaries) == 1 and re.fullmatch(
        rf'test result: ok\. {passed} passed; 0 failed; {ignored} ignored; 0 measured; 0 filtered out; finished in [0-9.]+s',
        summaries[0])
    assert len([line for line in text.splitlines()
                if line.startswith('test ') and not line.startswith('test result:')]) == len(rows)
    return sorted(name for name, status in rows if status.startswith('ignored'))


class Audit:
    def __init__(self, generation, proposal):
        self.generation, self.proposal = generation, proposal
        for path, value in PINS.items():
            assert sha(RAW / path) == value, path
        self.capture = module('destination_capture', RAW / 'capture.py')
        self.qualify = module('destination_qualification', RAW / 'qualify.py')
        self.source = self.capture.snapshot()
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
        assert sha(ARCHIVE) == ARCHIVE_SHA
        self.archive = tarfile.open(ARCHIVE)
        self.previous = decode(self.old('audit-final.json'))
        assert self.previous['accepted'] is True and self.previous['generation'] == '07'
        self.receipts, self.selected = {}, {}

    def old(self, name):
        member = self.archive.getmember('raw/' + name)
        assert member.isfile() and not member.issym()
        return self.archive.extractfile(member).read()

    def receipt(self, label, bound, argv):
        folder = RAW / label
        row, command = read(folder / 'receipt.json'), read(folder / 'command.json')
        assert all(row[key] == value for key, value in command.items()), label
        assert row['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', bound, *argv], label
        assert row['exit'] == 0 and row['source_unchanged'] is True, label
        assert row['base'] == BASE and row['cwd'] == str(REPO), label
        assert row['controller_sha256'] == PINS['capture.py'] and row['environment'] == self.capture.ENV
        assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == self.source, label
        assert instant(row['started']) <= instant(row['finished']), label
        for stream in ('stdout', 'stderr'):
            assert sha(folder / stream) == row[stream + '_sha256'], label
        self.receipts[label] = row
        self.selected[label] = sha(folder / 'receipt.json')
        return row

    def jobs(self):
        for stage, count in [('cpu', 21), ('build', 2)]:
            jobs = self.qualify.jobs(stage)
            assert len(jobs) == count
            expected, prior = [], None
            for name, bound, command in jobs:
                label = name + '-final-' + self.generation
                row = self.receipt(label, bound, command)
                if prior is not None:
                    assert prior <= instant(row['started'])
                prior = instant(row['finished'])
                expected.append(dict(label=label, exit=0))
            assert read(RAW / f'qualification-{stage}-{self.generation}.json') == expected
        for label in ('source-ci-verify-' + self.proposal, 'metadata-final-after-' + self.generation):
            self.receipt(label, '120s', ['python3', '-I', '-B', str(RAW / 'verify_metadata.py'), self.proposal])
        self.receipt('source-controls-final-' + self.generation, '900s',
                     ['python3', '-I', '-B', str(RAW / 'source_controls_final.py'), self.generation])
        opening = self.receipts['source-ci-verify-' + self.proposal]
        closing = self.receipts['metadata-final-after-' + self.generation]
        for label, row in self.receipts.items():
            if label not in ('source-ci-verify-' + self.proposal, 'metadata-final-after-' + self.generation):
                assert instant(opening['finished']) <= instant(row['started'])
                assert instant(row['finished']) <= instant(closing['started'])

    def tests(self):
        counts = {'runtime': (2294, 32), 'destination': (7, 0), 'deferred': (23, 0),
                  'recovery': (7, 0), 'settled': (3, 0)}
        additions = {'context::tests::compute_peer_tests::segments::ordered::' + n for n in CONTEXT_TESTS}
        additions |= {'kfd_backend::tests::compute_peer_tests::segments::ordered::' + n for n in BACKEND_TESTS}
        assert len(additions) == 18
        records = {}
        for kind, (passed, ignored) in counts.items():
            names = roster((RAW / f'{kind}-list-final-{self.generation}/stdout').read_text())
            ignores = outcomes((RAW / f'{kind}-tests-final-{self.generation}/stdout').read_text(), names, passed, ignored)
            if kind == 'destination':
                assert names == sorted('tests::' + n for n in DESTINATION_TESTS)
            else:
                old = roster(self.old(kind + '-list-final-07/stdout').decode())
                if kind == 'runtime':
                    assert not set(old) & additions and set(names) == set(old) | additions
                    assert ignores == outcomes(self.old('runtime-tests-final-07/stdout').decode(), old, 2276, 32)
                elif kind == 'deferred':
                    added = {'gather_compute::tests::' + n for n in DEFERRED_TESTS}
                    assert not set(old) & added and set(names) == set(old) | added
                else:
                    assert names == old
            records[kind] = dict(passed=passed, ignored=ignored, total=len(names),
                                 roster=names, ignored_names=ignores)
        docs = (RAW / f'doctests-final-{self.generation}/stdout').read_text()
        rows = re.findall(r'^test (crates/fe2o3-runtime/.+?) \.\.\. ok$', docs, re.M)
        old = re.findall(r'^test (crates/fe2o3-runtime/.+?) \.\.\. ok$',
                         self.old('doctests-final-07/stdout').decode(), re.M)
        normalize = lambda name: re.sub(r' \(line \d+\)', '', name)
        assert len(rows) == len(old) == 61
        assert Counter(map(normalize, rows)) == Counter(map(normalize, old))
        assert len([line for line in docs.splitlines() if line.startswith('test ') and
                    not line.startswith('test result:')]) == 61
        summaries = re.findall(r'^test result: (.+)$', docs, re.M)
        assert len(summaries) == 2
        for summary, count in zip(summaries, (10, 51), strict=True):
            assert re.fullmatch(
                rf'ok\. {count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in [0-9.]+s', summary)
        features = (RAW / f'features-no-default-final-{self.generation}/stdout').read_text()
        assert features.startswith('fe2o3-runtime ') and 'hardware-qualification' not in features
        return records

    def binaries(self):
        result = {}
        for kind in ('destination', 'deferred'):
            label = f'build-{kind}-final-{self.generation}'
            rows = [decode(line) for line in (RAW / label / 'stdout').read_text().splitlines()]
            assert [row['success'] for row in rows if row.get('reason') == 'build-finished'] == [True]
            artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
            assert len(artifacts) == 1
            item, = artifacts
            target = self.qualify.TARGETS[kind]
            assert item['target']['name'] == target and item['target']['kind'] == ['example']
            assert item['profile']['test'] is False
            path = Path(item['executable'])
            assert path.is_relative_to(REPO / 'target/debug') and path.read_bytes().startswith(b'\x7fELF')
            identity = dict(target=target, test=False, sha256=sha(path), byte_length=path.stat().st_size)
            assert self.receipts[label]['executables'] == {str(path): identity}
            result[kind] = dict(path=str(path), **identity)
        return result

    def metadata(self):
        folder = RAW / ('proposal-' + self.proposal)
        report = read(folder / 'metadata-report.json')
        previous = decode(self.old('proposal-03/metadata-report.json'))
        assert report['baseline'] == BASE and report['proof_files'] == previous['proof_files']
        assert len(report['proof_files']) == 76 and len(report['audited_source_sha256']) == 1086
        edits = [edit for row in report['changes'] for edit in row['edits']]
        assert Counter(edit['category'] for edit in edits) == {'content-sha256': 17, 'source-inventory-count': 7}
        changed = {row['path'] for row in report['changes'] if row['edits']}
        assert changed == {'crates/fe2o3-runtime-model/verus/' + name for name in GUARDS}
        for key in ('all_baseline_audits_passed', 'all_proposed_source_audits_passed',
                    'ast_identical_except_listed_metadata_constants',
                    'predicates_contracts_and_proof_counts_unchanged', 'proof_closures_unchanged'):
            assert report[key] is True
        for key in ('solver_executed', 'build_executed', 'formal_qualification'):
            assert report[key] is False
        for row in report['changes']:
            original = baseline(row['path'])
            assert original == (folder / 'originals' / Path(row['path']).name).read_bytes()
            assert digest(original) == row['original_sha256']
            assert sha(REPO / row['path']) == row['proposed_sha256']
            expected = ast.parse(original)
            nodes = {(node.lineno, node.col_offset): node for node in ast.walk(expected) if isinstance(node, ast.Constant)}
            lines, seen = original.decode().splitlines(keepends=True), set()
            for edit in sorted(row['edits'], key=lambda e: (e['line'], e['column']), reverse=True):
                pos = (edit['line'], edit['column'])
                node = nodes[pos]
                assert pos not in seen and node.value == edit['old']
                assert node.end_lineno == edit['end_line'] == edit['line']
                assert node.end_col_offset == edit['end_column']
                seen.add(pos)
                node.value = edit['new']
                if edit['category'] == 'content-sha256':
                    assert re.fullmatch('[0-9a-f]{64}', edit['old']) and re.fullmatch('[0-9a-f]{64}', edit['new'])
                else:
                    assert type(edit['old']) is type(edit['new']) is int and edit['new'] >= edit['old']
                line = lines[edit['line'] - 1]
                literal = line[edit['column']:edit['end_column']]
                replacement = literal[0] + edit['new'] + literal[-1] if isinstance(edit['new'], str) else str(edit['new'])
                lines[edit['line'] - 1] = line[:edit['column']] + replacement + line[edit['end_column']:]
            current = (REPO / row['path']).read_bytes()
            assert ''.join(lines).encode() == current
            assert ast.dump(expected) == ast.dump(ast.parse(current))
            assert row['proof_closure_unchanged'] is True and row['baseline_audit_passed'] is True
            for name in row['proof_files']:
                assert digest(baseline(name)) == sha(REPO / name)
        for name, value in report['proof_files'].items():
            assert digest(baseline(name)) == sha(REPO / name) == value
        for name, value in report['audited_source_sha256'].items():
            assert sha(REPO / name) == value
        assert report['runtime_source_files'] == len(list((REPO / 'crates/fe2o3-runtime/src').rglob('*.rs'))) == 398
        assert report['runtime_and_schema_files'] == 403
        for label in ('source-ci-verify-' + self.proposal, 'metadata-final-after-' + self.generation):
            result = read(RAW / label / 'stdout')
            assert result['applied_guard_hashes_match_proposal'] is True
            assert result['ast_identical_except_recorded_metadata_literals'] is True
            assert (result['changed_files'], result['hash_constants'], result['source_inventory_constants'],
                    result['unchanged_audited_source_files'], result['unchanged_proof_files']) == (10, 17, 7, 1086, 76)
            assert result['solver_executed'] is result['build_executed'] is result['formal_qualification'] is False
        self.guard_changes = changed
        return dict(changed_files=10, hash_constants=17, source_inventory_constants=7,
                    unchanged_proof_files=76, audited_sources=1086,
                    report_sha256=sha(folder / 'metadata-report.json'),
                    patch_sha256=sha(folder / 'metadata.patch'))

    def controls(self):
        workflow_path = REPO / '.github/workflows/runtime-component-source-guards.yml'
        workflow = yaml.safe_load(workflow_path.read_text())
        commands = [(step['name'], shlex.split(line)) for step in workflow['jobs']['source-controls']['steps']
                    if 'run' in step for line in step['run'].splitlines()]
        assert len(commands) == 32 and all(command[:3] == ['python3', '-I', '-B'] for _, command in commands)
        folder = RAW / f'source-controls-final-{self.generation}-commands'
        summary = read(folder / 'summary.json')
        assert summary['accepted'] is True and summary['solver_executed'] is False
        assert summary['workflow_sha256'] == sha(workflow_path)
        assert summary['controller_sha256'] == PINS['source_controls_baseline.py']
        assert [(row['name'], row['command']) for row in summary['commands']] == commands
        for index, row in enumerate(summary['commands']):
            assert read(folder / f'{index:02d}/receipt.json') == row and row['exit'] == 0
            for stream in ('stdout', 'stderr'):
                assert sha(folder / f'{index:02d}' / stream) == row[stream + '_sha256']
        return sha(folder / 'summary.json')

    def kfd(self):
        # No new KFD execution/build is claimed. All local transitive package
        # bytes remain exact except already-audited noncompiled guard literals.
        old_source = decode(self.old('kfd-build-final-06/source-after.json'))
        assert digest(self.old('kfd-build-final-06/source-after.json')) == self.previous['kfd_source_manifest_sha256']
        lock = tomllib.loads((REPO / 'Cargo.lock').read_text())
        local = {p['name']: p for p in lock['package'] if 'source' not in p}
        todo, closure = ['fe2o3-kfd'], set()
        while todo:
            name = todo.pop()
            if name in closure:
                continue
            closure.add(name)
            todo.extend(dep.split()[0] for dep in local[name].get('dependencies', []) if dep.split()[0] in local)
        assert closure == LOCAL_KFD_PACKAGES
        prefixes = tuple('crates/' + name + '/' for name in sorted(closure))
        shared = {'crates/fe2o3-runtime/src/' + name for name in KFD_SHARED_RUNTIME}
        def relevant(name):
            return (name.startswith(prefixes) or name in shared
                    or name.startswith('crates/fe2o3-runtime/fixtures/')
                    or name in ('Cargo.lock', 'Cargo.toml', 'rust-toolchain.toml'))
        old_scope = {name: value for name, value in old_source.items() if relevant(name)}
        current_scope = {name: value for name, value in self.source.items() if relevant(name)}
        assert old_scope.keys() == current_scope.keys()
        changed = {name for name in old_scope if old_scope[name] != current_scope[name]}
        assert changed == self.guard_changes
        for name in closure:
            manifest = tomllib.loads((REPO / 'crates' / name / 'Cargo.toml').read_text())
            assert manifest['package']['name'] == name
        # The sole changed external text include is in an unchanged dependency
        # unit-test module, which is not compiled when testing the KFD library.
        excluded = 'crates/fe2o3-runtime/src/context.rs'
        assert '#[cfg(test)]\nmod tests;' in (REPO / 'crates/fe2o3-runtime-model/src/context_version_journal.rs').read_text()
        for name in old_scope:
            if not name.endswith('.rs'):
                continue
            path = REPO / name
            text = path.read_text()
            patterns = (r'\binclude(?:_bytes|_str)?!\s*\(\s*"([^"]+)"', r'#\[path\s*=\s*"([^"]+)"')
            for pattern in patterns:
                for match in re.finditer(pattern, text):
                    target = (path.parent / match[1]).resolve().relative_to(REPO).as_posix()
                    if target == excluded:
                        assert name == 'crates/fe2o3-runtime-model/src/context_version_journal/tests.rs'
                    else:
                        # Nested #[path] attributes can resolve relative to a
                        # containing inline module; whole package rosters are
                        # already exact, including those alternate bases.
                        assert target.startswith(prefixes) or target in current_scope, (name, target)
        assert not list((REPO / '.cargo').glob('config*'))
        assert not list((Path('/home/harsh/.cargo')).glob('config*'))
        build = decode(self.old('kfd-build-final-06/receipt.json'))
        executable, identity = next(iter(build['executables'].items()))
        assert len(build['executables']) == 1 and identity == self.previous['kfd_executable']
        assert identity['target'] == 'fe2o3_kfd' and identity['test'] is True
        binary = Path(executable)
        assert binary.is_relative_to(REPO / 'target/debug/deps')
        assert sha(binary) == identity['sha256'] and binary.stat().st_size == identity['byte_length']
        assert binary.read_bytes().startswith(b'\x7fELF')
        full = roster(self.old('kfd-list-final-06/stdout').decode())
        assert len(full) == self.previous['kfd_tests'] == 1950
        assert self.old('kfd-list-final-06/stdout') == self.old('kfd-list-final-07/stdout')
        parser_data = self.old('reference/kfd_shard_final.py')
        assert digest(parser_data) == 'f6262d5575843228388e3909a4718cc6946390e3332bf63ae1f0ef5e9d34d01b'
        parser = types.ModuleType('archived_kfd_parser')
        parser.__file__ = str(RAW / 'archived-kfd-parser-not-written.py')
        exec(compile(parser_data, parser.__file__, 'exec'), parser.__dict__)
        def old_receipt(label, command):
            prefix = label + '/'
            row = decode(self.old(prefix + 'receipt.json'))
            initial = decode(self.old(prefix + 'command.json'))
            assert all(row[key] == value for key, value in initial.items())
            assert row['command'] == command and row['exit'] == 0 and row['source_unchanged'] is True
            assert row['environment'] == self.capture.ENV and row['cwd'] == str(REPO)
            assert row['base'] == self.previous['base'] and row['controller_sha256'] == PINS['capture.py']
            assert decode(self.old(prefix + 'source-before.json')) == decode(self.old(prefix + 'source-after.json')) == old_source
            assert instant(row['started']) <= instant(row['finished'])
            for stream in ('stdout', 'stderr'):
                assert digest(self.old(prefix + stream)) == row[stream + '_sha256']
            return row
        assert old_receipt('kfd-build-final-06', parser.BUILD_COMMAND) == build
        listing = old_receipt('kfd-list-final-06', parser.LIST_COMMAND)
        assert instant(build['finished']) <= instant(listing['started'])
        heavy = [name for name in full if name.startswith(parser.PREFIX)]
        partitions = {str(i): heavy[i::4] for i in range(4)}
        partitions['rest'] = [name for name in full if not name.startswith(parser.PREFIX)]
        assert Counter(n for names in partitions.values() for n in names) == Counter(full)
        shard_hashes = {}
        for mode, selected in partitions.items():
            outer = old_receipt('kfd-shard-final-06-' + mode, [
                'timeout', '--signal=TERM', '--kill-after=30s', '1320s', 'python3', '-I', '-B',
                '/home/harsh/.codex-tmp/fe2o3-xgmi-creation-recovery-20261003/kfd_shard.py', mode])
            prefix = 'kfd-shard-06-' + mode + '/'
            inputs, result = decode(self.old(prefix + 'inputs.json')), decode(self.old(prefix + 'result.json'))
            argv = [executable, '--test-threads=1', '--exact', *selected]
            assert inputs['argv'] == argv and inputs['selected'] == selected
            assert inputs['partitions'] == partitions and inputs['partition_union_exact'] is True
            assert inputs['total_roster'] == 1950 and inputs['construction_roster'] == len(heavy)
            assert inputs['executable_identity'] == identity and inputs['executable'] == executable
            assert inputs['environment'] == parser.ENV and inputs['cwd'] == str(REPO)
            assert inputs['core_limit_bytes'] == 0 and inputs['native_opt_in_environment'] == {}
            assert inputs['controller_sha256'] == digest(parser_data)
            assert inputs['build_command'] == parser.BUILD_COMMAND and inputs['list_command'] == parser.LIST_COMMAND
            assert inputs['source_manifest_sha256'] == digest(self.old('kfd-build-final-06/source-after.json'))
            for key, name in [('build_receipt_sha256', 'kfd-build-final-06/receipt.json'),
                              ('list_receipt_sha256', 'kfd-list-final-06/receipt.json'),
                              ('full_roster_sha256', 'kfd-list-final-06/stdout')]:
                assert inputs[key] == digest(self.old(name))
            last = instant(listing['finished'])
            for name, command in [('full-list', [executable, '--test-threads=1', '--list']),
                                  ('list', [*argv, '--list']), ('run', argv)]:
                row = decode(self.old(prefix + name + '.json'))
                assert row['argv'] == command and row['environment'] == parser.ENV and row['cwd'] == str(REPO)
                assert parser.clean_run(row) and 0 < row['timeout_seconds'] <= (1200 if name == 'run' else 60)
                assert last <= instant(row['started']) <= instant(row['finished'])
                assert instant(outer['started']) <= instant(row['started'])
                assert instant(row['finished']) <= instant(outer['finished'])
                last = instant(row['finished'])
                for stream in ('stdout', 'stderr'):
                    assert digest(self.old(prefix + name + '.' + stream)) == row[stream + '_sha256']
            assert roster(self.old(prefix + 'full-list.stdout').decode()) == full
            assert roster(self.old(prefix + 'list.stdout').decode()) == selected
            parsed = parser.parse_outcomes(self.old(prefix + 'run.stdout').decode(), selected, len(full))
            assert parsed['accepted'] and result['accepted'] is True and result['error'] is None
            assert result['mode'] == mode and result['scope'] == 'selected-partition-only'
            assert result['passed'] == selected and result['selected_count'] == len(selected)
            assert result['executable_sha256'] == identity['sha256'] and result['total_roster'] == 1950
            assert result['executable_unchanged'] and result['source_unchanged'] and result['group_absent']
            assert result['timed_out'] is False and result['exit_code'] == 0
            for key in ('summary', 'empty_progress', 'progress_problems', 'other_outcomes'):
                assert result[key] == parsed[key]
            for key, name in [('inputs_sha256', 'inputs.json'), ('execution_receipt_sha256', 'run.json'),
                              ('stdout_sha256', 'run.stdout'), ('stderr_sha256', 'run.stderr')]:
                assert result[key] == digest(self.old(prefix + name))
            shard_hashes[mode] = digest(self.old(prefix + 'result.json'))
        assert shard_hashes == self.previous['kfd_shard_receipt_sha256']
        assert decode(self.old('kfd-suite-06.json')) == [
            dict(mode=mode, label='kfd-shard-final-06-' + mode, exit=0)
            for mode in ('0', '1', '2', '3', 'rest')]
        return dict(tests=1950, fresh_execution=False, fresh_build=False, execution_generation='06',
                    baseline_archive_sha256=ARCHIVE_SHA, local_packages=sorted(closure),
                    executable=identity, executable_path=executable,
                    protected_source_sha256=current_scope, metadata_only_exceptions=sorted(changed),
                    shard_receipt_sha256=shard_hashes,
                    historical_source_manifest_sha256=digest(self.old('kfd-build-final-06/source-after.json')))


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 3 and all(value.isdigit() for value in sys.argv[1:])
    started = datetime.now(timezone.utc).isoformat()
    audit = Audit(*sys.argv[1:])
    audit.jobs()
    counts = audit.tests()
    binaries = audit.binaries()
    metadata = audit.metadata()
    controls = audit.controls()
    kfd = audit.kfd()
    assert audit.capture.snapshot() == audit.source
    diagnostics = {}
    for path in RAW.glob('*/receipt.json'):
        if path.parent.name not in audit.selected:
            row = read(path)
            diagnostics[path.parent.name] = dict(receipt_sha256=sha(path), exit=row['exit'],
                                                 source_unchanged=row['source_unchanged'], selected=False)
    result = dict(schema='fe2o3.destination-segments.cpu-audit.v1', accepted=True,
                  base=BASE, generation=audit.generation, proposal=audit.proposal,
                  started=started, finished=datetime.now(timezone.utc).isoformat(),
                  auditor_sha256=sha(Path(__file__)), controller_sha256=PINS,
                  source_sha256=audit.source, source_files=len(audit.source),
                  receipt_sha256=audit.selected, runtime=counts.pop('runtime'), examples=counts,
                  example_tests=40, doctests={'runtime': 61}, witness_executables=binaries,
                  metadata=metadata, source_controls=32, source_controls_summary_sha256=controls,
                  kfd_reuse=kfd, nonselected_receipts=diagnostics,
                  solver_executed=False, formal_qualification=False, performance_claim=False)
    with (RAW / 'audit-cpu.json').open('x') as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write('\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('source_sha256', 'runtime', 'examples', 'kfd_reuse')}, sort_keys=True))


if __name__ == '__main__':
    main()
