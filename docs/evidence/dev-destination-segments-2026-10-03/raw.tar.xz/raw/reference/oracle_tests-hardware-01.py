"""Offline controller/schema and independent byte-oracle cross-checks. No SSH."""
import hashlib
import importlib.util
from pathlib import Path
import re
import struct
import unittest

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


oracle = load('offline_oracle', ROOT / 'native_oracle.py')
campaign = load('offline_campaign', ROOT / 'hardware-01/campaign.py')


def independent_frame(domain, parts):
    return hashlib.sha256(domain + b''.join(len(part).to_bytes(8, 'little') + part for part in parts)).hexdigest()


def independent_compute(count):
    # Float formulas and byte-slice stores intentionally differ from the quarter-integer oracle.
    left = b''.join(struct.pack('<f', (index & 63) * .25 + (index & 31) * .5)
                    for index in range(65536))
    right = b''.join(struct.pack('<f', (index & 63) * .25 + (index & 31))
                     for index in range(65536))
    gathered = bytearray(struct.pack('<f', .25) * 65536)
    for source, contents in enumerate((left, right)):
        for index in range(count):
            if index in (0, 2):
                start, target, length = 4 + source * 36, 64, 128
            elif index == 1:
                start, target, length = 260 + source * 20, 96, 128
            elif index == 3:
                start, target, length = 1028 + source * 28, 192, 68
            else:
                start = 4 + 4 * ((13 * index + 29 * source) % 10000)
                target = 1028 + 4 * ((17 * index + 19 * source) % 40000)
                length = 4 + 4 * (index % 17)
            gathered[target:target + length] = contents[start:start + length]
    computed = b''.join(struct.pack('<f', struct.unpack_from('<f', gathered, 4 * index)[0]
                                    + (index & 31) * .5) for index in range(65536))
    returned = bytearray([165]) * 262913
    returned[131:262211] = computed[20:262100]
    host = bytearray([90]) * 263297
    host[97:263010] = returned
    return independent_frame(b'fe2o3.destination-segments-compute.v1\0',
                             (left, right, gathered, computed, returned, host))


class OracleTests(unittest.TestCase):
    def test_exact_matrix_and_receipt_label_mapping(self):
        self.assertEqual(len(campaign.CASES), 18)
        self.assertEqual(len({row[0] for row in campaign.CASES}), 18)
        self.assertEqual(sum(kind == 'copy' for _, kind, _ in campaign.CASES), 10)
        self.assertEqual(sum(kind == 'compute' for _, kind, _ in campaign.CASES), 8)
        self.assertEqual(campaign.BUILD_LABELS, {'copy': 'destination', 'compute': 'deferred'})
        self.assertEqual(campaign.CARDS, ['card1', 'card6', 'card7'])
        copy = [(args[-1], args[0] == '--dispose-source') for _, kind, args in campaign.CASES if kind == 'copy']
        self.assertEqual(sorted(case for case, disposed in copy if disposed), ['duplicates', 'overlap'])
        for case in ('disjoint', 'overlap', 'duplicates', 'packets'):
            self.assertEqual(copy.count((case, False)), 2)
        self.assertEqual(sum(args[0] == '--destination-segments-compute' for _, kind, args in campaign.CASES if kind == 'compute'), 4)
        self.assertEqual(sum(args[0] == '--late-destination-segments-compute' for _, kind, args in campaign.CASES if kind == 'compute'), 2)

    def test_exact_source_report_key_sets(self):
        copy_source = (REPO / 'crates/fe2o3-runtime/examples/gfx942-runtime-destination-segments-smoke.rs').read_text()
        compute_source = (REPO / 'crates/fe2o3-runtime/examples/deferred_peer_chain/gather_compute.rs').read_text()
        def fields(line):
            return set(re.findall(r' ([a-z][a-z0-9_]*)=', line))
        copy_keys = fields(next(line for line in copy_source.splitlines() if 'PASS schema=fe2o3.destination-peer-segments.v1 ' in line))
        compute_keys = fields(next(line for line in compute_source.splitlines() if 'PASS schema=fe2o3.destination-segments-compute.v1 ' in line))
        legacy_keys = fields(next(line for line in compute_source.splitlines() if 'pipeline=compute-gather-compute-peer-readback' in line and 'PASS schema=' in line))
        publication = fields(next(line for line in compute_source.splitlines() if ' publication_observed=true publication_identity=' in line))
        self.assertEqual(len(copy_keys), 50)
        self.assertEqual(len(compute_keys), 45)
        self.assertEqual(len(legacy_keys), 41)
        self.assertEqual(len(publication), 7)
        for _, kind, args in campaign.CASES:
            expected = oracle.expected(kind, args)
            wanted = (copy_keys if kind == 'copy' else legacy_keys if args[0].startswith('--gather-')
                      else compute_keys | publication if args[0].startswith('--late-') else compute_keys)
            self.assertEqual(set(expected), wanted)
            self.assertEqual(expected['performance_acceptance'], 'false')
            self.assertEqual(expected['formal_refinement'], 'false')

    def test_compute_integer_quarter_matches_independent_float_byte_oracle(self):
        digests = set()
        for count in (4, 65, 4096):
            actual = oracle.compute_digest(count)
            self.assertEqual(actual, independent_compute(count))
            digests.add(actual)
            print(f'compute-{count} {actual}', flush=True)
        self.assertEqual(len(digests), 3)

    def test_copy_scalar_boundaries_and_ordered_holes(self):
        for case in ('disjoint', 'overlap', 'duplicates', 'packets'):
            sizes, destination, source_length, destination_length, lists = oracle.copy_geometry(case)
            self.assertEqual(len(lists), 2)
            for source, base in enumerate((17, 29)):
                self.assertLess(base + source_length, sizes[source])
                for start, target, length in lists[source]:
                    self.assertGreater(length, 0)
                    self.assertLessEqual(start + length, source_length)
                    self.assertLessEqual(target + length, destination_length)
            self.assertLess(53 + destination_length, destination)
        lists = oracle.copy_geometry('duplicates')[4]
        self.assertEqual(lists[0][0], lists[0][2])
        self.assertEqual(lists[1][0], lists[1][2])
        self.assertEqual(sum((length + oracle.PACKET - 1) // oracle.PACKET
                             for parts in oracle.copy_geometry('packets')[4] for _, _, length in parts), 6)

    def test_framing_and_wrong_inputs_fail_closed(self):
        self.assertNotEqual(oracle.framed(b'x', (b'a', b'bc')), oracle.framed(b'x', (b'ab', b'c')))
        self.assertNotEqual(oracle.framed(b'x', (b'a',)), oracle.framed(b'y', (b'a',)))
        for ids in ([campaign.IDS[0]] * 3, ['0x0000000000000000', *campaign.IDS[1:]], ['0x1', *campaign.IDS[1:]]):
            with self.assertRaises(AssertionError):
                oracle.uid_fields(ids)
        for count in (0, 3, 4097):
            with self.assertRaises(AssertionError):
                oracle.compute_descriptors(0, count)
        with self.assertRaises(AssertionError):
            oracle.expected('unknown', [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
