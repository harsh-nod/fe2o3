"""Offline controller/schema and independent byte-oracle cross-checks. No SSH."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


oracle = load('offline_oracle', ROOT / 'native_oracle.py')
campaign = load('offline_campaign', ROOT / 'hardware-02/campaign.py')


def independent_frame(domain, parts):
    return hashlib.sha256(domain + b''.join(len(part).to_bytes(8, 'little') + part for part in parts)).hexdigest()


def independent_compute(count):
    # Float formulas and byte-slice stores intentionally differ from the quarter-integer oracle.
    left = b''.join(struct.pack('<f', (index & 63) * .25 + (index & 31) * .5)
                    for index in range(65536))
    right = b''.join(struct.pack('<f', (index & 63) * .25 + (index & 31))
                     for index in range(65536))
    gathered = bytearray(struct.pack('<f', .25) * 65536)
    for source, contents in enumerate((left, right)):
        for index in range(count):
            if index in (0, 2):
                start, target, length = 4 + source * 36, 64, 128
            elif index == 1:
                start, target, length = 260 + source * 20, 96, 128
            elif index == 3:
                start, target, length = 1028 + source * 28, 192, 68
            else:
                start = 4 + 4 * ((13 * index + 29 * source) % 10000)
                target = 1028 + 4 * ((17 * index + 19 * source) % 40000)
                length = 4 + 4 * (index % 17)
            gathered[target:target + length] = contents[start:start + length]
    computed = b''.join(struct.pack('<f', struct.unpack_from('<f', gathered, 4 * index)[0]
                                    + (index & 31) * .5) for index in range(65536))
    returned = bytearray([165]) * 262913
    returned[131:262211] = computed[20:262100]
    host = bytearray([90]) * 263297
    host[97:263010] = returned
    return independent_frame(b'fe2o3.destination-segments-compute.v1\0',
                             (left, right, gathered, computed, returned, host))


class OracleTests(unittest.TestCase):
    def test_preserved_original_assets_and_exact_rerun_matrix(self):
        pins = {
            'hardware-01/campaign.py': '5c5c61abac945a49d1cdc5757389732088552042c2c73e8fa4832fa1610bb205',
            'hardware-01/capture.py': '507ba3f408a423d698ebaf2ff8b9c83b4c33ba97a3bda16734643da298d7f20f',
            'hardware-01/reference/campaign.py': 'd22d7ee70a41a5e588e8c79455c8be7879928e42e59d80225de9cbd832197895',
            'hardware-01/reference/audit.py': '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea',
            'reference/oracle_tests-hardware-01.py': '9f44d8e9986cba70fd7b8f712bfca5cabf54a2daea055f8f2985fe9211c46433',
            'native_oracle.py': '1fe0eaa48d6245aec417385542766dae024779cd748bc3dc8c0e5181fd19b3ed',
        }
        for relative, expected in pins.items():
            self.assertEqual(hashlib.sha256((ROOT / relative).read_bytes()).hexdigest(), expected)
        original = load('offline_previous_campaign', ROOT / 'hardware-01/campaign.py')
        self.assertEqual(campaign.CASES, original.CASES)
        self.assertEqual(campaign.TARGETS, original.TARGETS)
        self.assertEqual(campaign.BUILD_LABELS, original.BUILD_LABELS)
        self.assertEqual((ROOT / 'hardware-02/reference/audit.py').read_bytes(),
                         (ROOT / 'hardware-01/reference/audit.py').read_bytes())

    def test_rerun_capture_bounds_and_helper_roots(self):
        self.assertEqual(campaign.NATIVE_PROCESS_TIMEOUT_SECONDS, 420)
        self.assertEqual(campaign.TRANSPORT_TIMEOUT_SECONDS, 480)
        helper, audit = campaign.helpers()
        self.assertEqual(campaign.ROOT, ROOT / 'hardware-02')
        self.assertEqual(helper.ROOT, campaign.ROOT)
        self.assertEqual(audit.HARDWARE, campaign.ROOT)
        self.assertEqual(audit.RAW, ROOT)
        capture = ast.parse((campaign.ROOT / 'capture.py').read_text())
        constants = {node.targets[0].id: node.value.value for node in capture.body
                     if isinstance(node, ast.Assign) and len(node.targets) == 1
                     and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Constant)}
        self.assertEqual(constants['TRANSPORT_TIMEOUT_SECONDS'], 480)
        calls = [node for node in ast.walk(capture) if isinstance(node, ast.Call)]
        timeout_uses = [keyword.value for node in calls
                        if isinstance(node.func, ast.Attribute) and node.func.attr == 'communicate'
                        for keyword in node.keywords if keyword.arg == 'timeout']
        self.assertEqual(sum(isinstance(value, ast.Name) and value.id == 'TRANSPORT_TIMEOUT_SECONDS'
                             for value in timeout_uses), 1)
        receipt_uses = [keyword.value for node in calls for keyword in node.keywords
                        if keyword.arg == 'transport_timeout_seconds']
        self.assertEqual(len(receipt_uses), 1)
        self.assertIsInstance(receipt_uses[0], ast.Name)
        self.assertEqual(receipt_uses[0].id, 'TRANSPORT_TIMEOUT_SECONDS')
        source = (campaign.ROOT / 'campaign.py').read_text()
        self.assertIn("f'{NATIVE_PROCESS_TIMEOUT_SECONDS}s'", source)
        self.assertIn('native_process_timeout_seconds=NATIVE_PROCESS_TIMEOUT_SECONDS', source)
        self.assertIn('transport_timeout_seconds=TRANSPORT_TIMEOUT_SECONDS', source)

    def test_transport_receipt_accepts_only_exact_bound_and_terminal_success(self):
        helper, _ = campaign.helpers()
        argv = ['ssh', 'offline-test-only']
        empty = hashlib.sha256(b'').hexdigest()
        good = dict(argv=argv, started='2026-10-03T00:00:00+00:00',
                    finished='2026-10-03T00:00:01+00:00', elapsed_seconds=1,
                    exit_code=0, timed_out=False, local_process_group_absent=True,
                    transport_timeout_seconds=480, stdout_sha256=empty, stderr_sha256=empty)
        # Generated temporary receipts only; no transport function is called.
        with tempfile.TemporaryDirectory(prefix='fe2o3-destination-controller-test-') as temporary:
            helper.ROOT = Path(temporary)
            folder = helper.ROOT / 'sample'
            folder.mkdir()
            (folder / 'stdout').write_bytes(b'')
            (folder / 'stderr').write_bytes(b'')
            (folder / 'result.json').write_text(json.dumps(good))
            self.assertEqual(helper.read_receipt('sample', argv)[0], good)
            for patch in ({'transport_timeout_seconds': 360}, {'elapsed_seconds': 491},
                          {'timed_out': True}, {'exit_code': 124},
                          {'local_process_group_absent': False}):
                (folder / 'result.json').write_text(json.dumps(good | patch))
                with self.assertRaises(AssertionError):
                    helper.read_receipt('sample', argv)

    def test_exact_matrix_and_receipt_label_mapping(self):
        self.assertEqual(len(campaign.CASES), 18)
        self.assertEqual(len({row[0] for row in campaign.CASES}), 18)
        self.assertEqual(sum(kind == 'copy' for _, kind, _ in campaign.CASES), 10)
        self.assertEqual(sum(kind == 'compute' for _, kind, _ in campaign.CASES), 8)
        self.assertEqual(campaign.BUILD_LABELS, {'copy': 'destination', 'compute': 'deferred'})
        self.assertEqual(campaign.CARDS, ['card1', 'card6', 'card7'])
        copy = [(args[-1], args[0] == '--dispose-source') for _, kind, args in campaign.CASES if kind == 'copy']
        self.assertEqual(sorted(case for case, disposed in copy if disposed), ['duplicates', 'overlap'])
        for case in ('disjoint', 'overlap', 'duplicates', 'packets'):
            self.assertEqual(copy.count((case, False)), 2)
        self.assertEqual(sum(args[0] == '--destination-segments-compute' for _, kind, args in campaign.CASES if kind == 'compute'), 4)
        self.assertEqual(sum(args[0] == '--late-destination-segments-compute' for _, kind, args in campaign.CASES if kind == 'compute'), 2)

    def test_exact_source_report_key_sets(self):
        copy_source = (REPO / 'crates/fe2o3-runtime/examples/gfx942-runtime-destination-segments-smoke.rs').read_text()
        compute_source = (REPO / 'crates/fe2o3-runtime/examples/deferred_peer_chain/gather_compute.rs').read_text()
        def fields(line):
            return set(re.findall(r' ([a-z][a-z0-9_]*)=', line))
        copy_keys = fields(next(line for line in copy_source.splitlines() if 'PASS schema=fe2o3.destination-peer-segments.v1 ' in line))
        compute_keys = fields(next(line for line in compute_source.splitlines() if 'PASS schema=fe2o3.destination-segments-compute.v1 ' in line))
        legacy_keys = fields(next(line for line in compute_source.splitlines() if 'pipeline=compute-gather-compute-peer-readback' in line and 'PASS schema=' in line))
        publication = fields(next(line for line in compute_source.splitlines() if ' publication_observed=true publication_identity=' in line))
        self.assertEqual(len(copy_keys), 50)
        self.assertEqual(len(compute_keys), 45)
        self.assertEqual(len(legacy_keys), 41)
        self.assertEqual(len(publication), 7)
        for _, kind, args in campaign.CASES:
            expected = oracle.expected(kind, args)
            wanted = (copy_keys if kind == 'copy' else legacy_keys if args[0].startswith('--gather-')
                      else compute_keys | publication if args[0].startswith('--late-') else compute_keys)
            self.assertEqual(set(expected), wanted)
            self.assertEqual(expected['performance_acceptance'], 'false')
            self.assertEqual(expected['formal_refinement'], 'false')

    def test_compute_integer_quarter_matches_independent_float_byte_oracle(self):
        digests = set()
        for count in (4, 65, 4096):
            actual = oracle.compute_digest(count)
            self.assertEqual(actual, independent_compute(count))
            digests.add(actual)
            print(f'compute-{count} {actual}', flush=True)
        self.assertEqual(len(digests), 3)

    def test_copy_scalar_boundaries_and_ordered_holes(self):
        for case in ('disjoint', 'overlap', 'duplicates', 'packets'):
            sizes, destination, source_length, destination_length, lists = oracle.copy_geometry(case)
            self.assertEqual(len(lists), 2)
            for source, base in enumerate((17, 29)):
                self.assertLess(base + source_length, sizes[source])
                for start, target, length in lists[source]:
                    self.assertGreater(length, 0)
                    self.assertLessEqual(start + length, source_length)
                    self.assertLessEqual(target + length, destination_length)
            self.assertLess(53 + destination_length, destination)
        lists = oracle.copy_geometry('duplicates')[4]
        self.assertEqual(lists[0][0], lists[0][2])
        self.assertEqual(lists[1][0], lists[1][2])
        self.assertEqual(sum((length + oracle.PACKET - 1) // oracle.PACKET
                             for parts in oracle.copy_geometry('packets')[4] for _, _, length in parts), 6)

    def test_framing_and_wrong_inputs_fail_closed(self):
        self.assertNotEqual(oracle.framed(b'x', (b'a', b'bc')), oracle.framed(b'x', (b'ab', b'c')))
        self.assertNotEqual(oracle.framed(b'x', (b'a',)), oracle.framed(b'y', (b'a',)))
        for ids in ([campaign.IDS[0]] * 3, ['0x0000000000000000', *campaign.IDS[1:]], ['0x1', *campaign.IDS[1:]]):
            with self.assertRaises(AssertionError):
                oracle.uid_fields(ids)
        for count in (0, 3, 4097):
            with self.assertRaises(AssertionError):
                oracle.compute_descriptors(0, count)
        with self.assertRaises(AssertionError):
            oracle.expected('unknown', [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
