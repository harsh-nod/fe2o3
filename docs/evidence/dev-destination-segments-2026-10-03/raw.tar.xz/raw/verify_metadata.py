"""Execute the accepted AST readback checker without changing its predicates."""
import hashlib
from pathlib import Path
import sys
import types

RAW = Path(__file__).resolve().parent
assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
source = RAW / 'reference/verify-applied.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243'
module = types.ModuleType('strict_metadata_readback')
module.__file__ = str(RAW / ('proposal-' + sys.argv[1]) / 'verify-applied.py')
exec(compile(data, str(source), 'exec'), module.__dict__)
