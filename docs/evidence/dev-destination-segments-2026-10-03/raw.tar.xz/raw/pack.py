"""Seal selected audited receipts and staged source; never bundle native binaries.

Manifest/archive/readback procedure adapted from accepted recovery pack_07.py,
SHA256 5a9532eebfe4f7ae02ba79403c01c47428b6775228aa4072015f64478a0f3996.
Run directly after root creates audit-final.json and stages the candidate.
Do not capture this command inside RAW while RAW is being sealed.
"""
import hashlib
import importlib.util
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
DEST = REPO / 'docs/evidence/dev-destination-segments-2026-10-03'
BASE = 'c37c04d60ff9bdfd7ede21b2375d8bf5f79298a2'
SOURCE_PATHS = ('crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock',
                'rust-toolchain.toml')
DOCUMENTATION_PATHS = {
    'docs/evidence/dev-destination-segments-2026-10-03/README.md',
    'docs/runtime-a1-a2-swarm-current.md',
    'docs/runtime-multi-device-qualification-v1.md',
}


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args, data=None):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', *args], cwd=REPO,
                                   input=data)


def source_path(name):
    return any(name == prefix or name.startswith(prefix + '/') for prefix in SOURCE_PATHS)


def indexed_sources_match(sources):
    paths = sorted(sources)
    data = git('cat-file', '--batch', data=''.join(':' + p + '\n' for p in paths).encode())
    cursor = 0
    for path in paths:
        end = data.index(b'\n', cursor)
        header = data[cursor:end].split()
        assert len(header) == 3 and header[1] == b'blob', path
        size = int(header[2])
        cursor = end + 1
        assert hashlib.sha256(data[cursor:cursor + size]).hexdigest() == sources[path], path
        cursor += size
        assert data[cursor:cursor + 1] == b'\n', path
        cursor += 1
    assert cursor == len(data)


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1
    accepted = json.loads((RAW / 'audit-final.json').read_bytes())
    assert accepted['accepted'] is True and accepted['base'] == BASE
    assert accepted['cpu_audit_sha256'] == sha(RAW / 'audit-cpu.json')
    assert accepted['native_audit_sha256'] == sha(RAW / 'audit-native.json')
    cpu = json.loads((RAW / 'audit-cpu.json').read_bytes())
    native = json.loads((RAW / 'audit-native.json').read_bytes())
    assert cpu['schema'] == 'fe2o3.destination-segments.cpu-audit.v1'
    assert cpu['accepted'] is True and cpu['base'] == BASE
    assert cpu['source_sha256'] == accepted['source_sha256']
    assert cpu['formal_qualification'] is cpu['solver_executed'] is False
    assert native['accepted'] is True and native['errors'] == []
    assert native['owned_cleanup_complete'] is True
    assert accepted['controller_pins']
    for name, digest in accepted['controller_pins'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert sha(RAW / name) == digest, name
    assert sha(RAW / 'capture.py') == \
        '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    spec = importlib.util.spec_from_file_location('destination_package_capture', RAW / 'capture.py')
    capture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(capture)
    assert capture.snapshot() == accepted['source_sha256']
    indexed_sources_match(accepted['source_sha256'])
    staged = {name.decode() for name in git('diff', '--cached', '--name-only', '-z').split(b'\0')
              if name}
    assert staged and all(source_path(name) or name in DOCUMENTATION_PATHS for name in staged)
    assert any(source_path(name) for name in staged)
    assert 'docs/evidence/dev-destination-segments-2026-10-03/README.md' in staged
    for name in staged & DOCUMENTATION_PATHS:
        assert git('show', ':' + name) == (REPO / name).read_bytes(), name
    assert (DEST / 'README.md').is_file() and not (DEST / 'README.md').is_symlink()
    readme_sha = sha(DEST / 'README.md')
    patch = git('diff', '--cached', '--binary', '--', *SOURCE_PATHS)
    assert patch and b'GIT binary patch' not in patch
    with (RAW / 'candidate.patch').open('xb') as output:
        output.write(patch)
    rows = {}
    with (DEST / 'raw.tar.xz').open('xb') as archive:
        with lzma.LZMAFile(archive, mode='w', preset=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as output:
                for path in sorted(RAW.rglob('*')):
                    assert not path.is_symlink(), path
                    if path.is_dir():
                        continue
                    assert path.is_file(), path
                    data = path.read_bytes()
                    assert not data.startswith(b'\x7fELF'), path
                    name = path.relative_to(RAW).as_posix()
                    rows[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
                    info = tarfile.TarInfo('raw/' + name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    output.addfile(info, io.BytesIO(data))
    with (DEST / 'raw-manifest.json').open('x') as output:
        json.dump(rows, output, indent=2, sort_keys=True)
        output.write('\n')
    for name, row in rows.items():
        data = (RAW / name).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert sorted(rows) == sorted(path.relative_to(RAW).as_posix()
                                  for path in RAW.rglob('*') if path.is_file())
    with tarfile.open(DEST / 'raw.tar.xz', 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert {member.name for member in members} == {'raw/' + name for name in rows}
        for member in members:
            assert member.isfile()
            row = rows[member.name.removeprefix('raw/')]
            data = archive.extractfile(member).read()
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert capture.snapshot() == accepted['source_sha256']
    indexed_sources_match(accepted['source_sha256'])
    assert git('diff', '--cached', '--binary', '--', *SOURCE_PATHS) == patch
    assert sha(DEST / 'README.md') == readme_sha
    with (DEST / 'SHA256SUMS').open('x') as output:
        for name in ('README.md', 'raw-manifest.json', 'raw.tar.xz'):
            output.write(sha(DEST / name) + '  ' + name + '\n')
    print(json.dumps(dict(files=len(rows),
                         uncompressed_bytes=sum(row['bytes'] for row in rows.values()),
                         archive_bytes=(DEST / 'raw.tar.xz').stat().st_size,
                         archive_sha256=sha(DEST / 'raw.tar.xz')), sort_keys=True))


if __name__ == '__main__':
    main()
