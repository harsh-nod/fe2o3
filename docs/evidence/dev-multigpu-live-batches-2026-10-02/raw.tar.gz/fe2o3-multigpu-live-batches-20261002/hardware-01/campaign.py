#!/usr/bin/env python3
"""Two live changed batches plus unchanged queued controls, not a benchmark."""
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33', '0x189ca857de1ef2fb',
       '0x54f88318ca05093d', '0xb7baafd0fb173d8e', '0x10a254ce4987e716',
       '0x53691ef168a0147d']
CARDS = ['card' + str(index) for index in range(1, 8)]
BD = ['0000:26:00.0', '0000:46:00.0', '0000:65:00.0', '0000:85:00.0',
      '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
BASELINE = None
PROFILES = [('live-sharded-2', IDS[5:]), ('live-sharded-3', IDS[4:]),
            ('live-sharded-5', IDS[2:]), ('live-sharded-7', IDS),
            ('live-sharded-7-reverse', IDS[::-1])]
CASES = [(name, 'live-sharded', [], ids) for name, ids in PROFILES] + [
    ('compute-sharded-2-queued-round-0', 'compute-sharded',
     ['--queued-compute', '--round', '0'], IDS[5:]),
    ('compute-sharded-7-queued-round-1', 'compute-sharded',
     ['--queued-compute', '--round', '1'], IDS),
]
LIMITATIONS = [
    'point observations, not continuous attachment census',
    'finite trusted-artifact qualification, not general kernel authority',
    'finite ordinary producer chain, not arbitrary dependency graph support',
    'compute may eagerly publish before explicit progress; physical overlap is unmeasured',
    'native completion counter is observed only for the live two-batch cases',
    'live cases reuse logical handles; physical mapping identity is not independently observed',
    'live snapshots use serialized settled host reads, not drain-capture byte-credit ownership',
    'queued controls use one-shot Contexts and leave the post-cutoff native counter unobserved',
    'ACQUIRE_VM admission lasts until process exit; same-process reopen is unsupported',
    'postcopy source preservation is not observed',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_receipt(name, argv):
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout = (folder / 'stdout').read_bytes()
    stderr = (folder / 'stderr').read_bytes()
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert receipt['exit_code'] == 0, (name, receipt, stderr)
    assert not receipt['timed_out'] and receipt['local_process_group_absent'], (name, receipt)
    return receipt, stdout, stderr


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    receipt, stdout, stderr = read_receipt(name, argv)
    assert process.returncode == receipt['exit_code'], (name, receipt, stderr)
    return stdout.decode()


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def remote(name, argv, bound='30s'):
    return capture(name, remote_argv(argv, bound))


def initial_baseline():
    receipt, stdout, stderr = read_receipt('initial-availability', remote_argv(AVAILABILITY))
    assert not stderr
    finished = datetime.fromisoformat(receipt['finished'])
    age = (datetime.now(timezone.utc) - finished).total_seconds()
    assert 0 <= age <= 300, 'initial availability is stale; capture a fresh campaign packet'
    return json.loads(stdout)


def admit(name):
    assert BASELINE is not None
    state = json.loads(remote(name + '-availability', AVAILABILITY))
    for card, uid, bdf in zip(CARDS, IDS, BD):
        assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bdf
        assert BASELINE[card]['Unique ID'] == uid and BASELINE[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == BASELINE[card]['GPU use (%)'] == '0'
        assert state[card]['VRAM Total Memory (B)'] == BASELINE[card]['VRAM Total Memory (B)']
        assert state[card]['VRAM Total Used Memory (B)'] == BASELINE[card]['VRAM Total Used Memory (B)']
    assert state['system'] == BASELINE['system'], 'changed PID roster; stop and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
        assert pid not in records and not {str(index) for index in range(1, 8)}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system']), (records, state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    return state


@lru_cache(maxsize=1)
def global_digests():
    digests = tuple(sha(b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                               for global_index in range(65537)))
                    for round_index in (0, 1))
    assert digests[0] != digests[1]
    return digests


def expected(kind, flags, ids):
    count = len(ids)
    assert 2 <= count <= 8 and len(set(ids)) == count
    quotient, remainder = divmod(65537, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    padded = [((size * 4 + 4095) // 4096) * 4096 for size in sizes]
    assert sum(sizes) == 65537 and offsets[-1] + sizes[-1] == 65537
    assert all(size > 0 for size in sizes) and sum(padded) <= 286720
    ranges = ','.join(f'{offset}:{size}:{physical}'
                      for offset, size, physical in zip(offsets, sizes, padded))
    if kind == 'live-sharded':
        assert flags == []
        # Full source-shard-order snapshots include untouched f32(-1) padding.
        full_digests = []
        for round_index in (0, 1):
            chunks = []
            for offset, size, physical in zip(offsets, sizes, padded):
                logical = b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                                   for global_index in range(offset, offset + size))
                chunks.append(logical + struct.pack('<f', -1) * ((physical - len(logical)) // 4))
            full = b''.join(chunks)
            assert len(full) == sum(padded)
            full_digests.append(sha(full))
        fields = dict(
            schema='fe2o3.live-sharded-vecadd-smoke.v1',
            authority='qualification-sharded-vecadd-rounds-v1', devices=str(count),
            unique_ids=','.join(ids), rounds='2', logical_elements_per_round='65537',
            logical_bytes_per_round='262148', shard_ranges=ranges,
            padded_bytes_per_round=str(sum(padded)), launches=str(2 * count),
            peer_copies=str(2 * count), dependent_readbacks=str(2 * count),
            completion_receipts=str(6 * count), batch_admission='one-owner-command',
            compute_api='producer-aware', compute_dependency='exact-event',
            compute_admission='may-publish-before-progress', compute_progress='dependent-readback-streams',
            journal='enabled', host_output_installations='0', input_refresh='full-padded-per-batch',
            incoming_sentinel='full-byte-pass', output='full-byte-pass', padding='full-byte-pass',
            coverage='exact-contiguous-disjoint', round0_sha256=global_digests()[0],
            round1_sha256=global_digests()[1], round0_padded_sha256=full_digests[0],
            round1_padded_sha256=full_digests[1], native_transport='authenticated-pending-peer',
            native_counter=f'0,{count},{2 * count}', stable_handles='logical-only', contexts='1',
            owners='1', allocation_reuse='true', module_reuse='true', kernel_reuse='true',
            stream_reuse='true', public_events='released-after-admission',
            batch_results='released-before-refresh', intermediate_cutoffs='0',
            snapshot='settled-host-visible-owner-command', snapshot_byte_bound='286720',
            reply_credits_after_batches='0', deadline_resumption='same-command-future',
            final_drain='completed-only', cleanup='owned-shutdown-explicit',
            source_preservation='unobserved', physical_overlap='unmeasured',
            performance_acceptance='false', formal_refinement='false')
        assert len(fields) == 51
        return fields
    assert kind == 'compute-sharded' and flags in (
        ['--queued-compute', '--round', '0'], ['--queued-compute', '--round', '1'])
    round_index = int(flags[2])
    fields = dict(
        schema='fe2o3.sharded-vecadd-queued-capture-smoke.v1',
        authority='qualification-sharded-vecadd-v1', devices=str(count),
        unique_ids=','.join(ids), round=str(round_index), rounds='1',
        logical_elements='65537', logical_bytes='262148', shard_ranges=ranges,
        padded_bytes=str(sum(padded)), launches=str(count), compute_receipts=str(count),
        transfer_receipts=str(2 * count), completion_receipts=str(3 * count),
        compute_admission='may-publish-before-cutoff', compute_join='owned-drain',
        compute_api='producer-aware', compute_dependency='exact-event',
        compute_progress='dependent-readback-streams', retained_submissions=str(3 * count),
        peer_copies=str(count), dependent_readbacks=str(count), capture_ranges=str(count),
        captured_bytes=str(sum(padded)), abi_bytes='48', kernel='vecadd', journal='enabled',
        host_output_installations='0', c_initial='-1', incoming_sentinel='full-byte-pass',
        output='full-byte-pass', padding='full-byte-pass', coverage='exact-contiguous-disjoint',
        global_sha256=global_digests()[round_index],
        admission='all-transfers-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_preservation='unobserved', allocation_reuse='false', contexts='one-per-process',
        drain='pending-group', capture='coherent-host-group', physical_overlap='unmeasured',
        cleanup='owned-shutdown-explicit', performance_acceptance='false', formal_refinement='false')
    assert len(fields) == 49
    return fields


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in fields
        fields[key] = value
    return fields


def main():
    global BASELINE
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) in (1, 2)
    attempt = sys.argv[1] if len(sys.argv) == 2 else 'attempt-01'
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert not (ROOT / 'campaign.json').exists()
    BASELINE = initial_baseline()
    checks = ROOT.parent / attempt / 'checks'
    binaries = {}
    for kind, receipt, basename in [
        ('live-sharded', 'live-sharded-witness.sha256', 'gfx942-runtime-live-sharded-vecadd-smoke'),
        ('compute-sharded', 'compute-sharded-witness.sha256', 'gfx942-runtime-sharded-vecadd-capture-smoke')]:
        digest, path = (checks / receipt).read_text().strip().split(maxsplit=1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest)
        local = REPO / path
        assert local == REPO / 'target/debug/examples' / basename
        assert sha(local.read_bytes()) == digest
        binaries[kind] = dict(local=str(local), sha256=digest)
    completed, errors = [], []
    directory = None
    cleaned = False
    try:
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-live-batches-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-multigpu-live-batches-20261002-[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
            capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            hashed = remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
            assert hashed.split() == [binary['sha256'], binary['remote']]
        for name, kind, flags, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
                'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8',
                binaries[kind]['remote'], *flags, *ids], '180s')
            fields = pass_fields(output)
            required = expected(kind, flags, ids)
            assert fields == required, (name, fields, required)
            assert not (ROOT / name / 'stderr').read_bytes()
            admit(name + '-post')
            completed.append(dict(name=name, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [directory + '/' + kind + '-witness' for kind in binaries]
                probe = ('import json,os,sys; from pathlib import Path; '
                    'paths=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    if 'remote' in binary:
                        try:
                            hashed = remote('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
                            assert hashed.split() == [binary['sha256'], binary['remote']]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        try:
            admit('final')
        except Exception as error:
            errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            selected_build_attempt=attempt, owned_directory=directory,
            owned_cleanup_complete=cleaned, exclusive_reservation=False,
            performance_acceptance=False, formal_refinement=False, limitations=LIMITATIONS)
        with (ROOT / 'campaign.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
