# Qualification Diagnostics

The final auditor selects only the complete frozen attempt named in its FINAL
record. Earlier receipts below remain diagnostic and cannot replace a missing
selected stage.

- Source review corrected the new owner test's constructor argument order and
  the example's unchecked third registration-result layer before selected
  qualification. Registration guards are retained only after admission succeeds.
- `attempt-01/precheck` failed strict Clippy because a test discarded the backend
  returned by Context shutdown. The test now explicitly calls native shutdown on
  that returned mock backend. No production readiness predicate changed.
- `proposal-01` was not applied. `proposal-02` followed the test cleanup change.
- `attempt-02` passed all 2,082 runtime tests, 39 example tests, strict Clippy and
  feature checks; its final formatting check rejected one unwrapped match arm.
  This attempt is not selected as fully qualified. The correction adds braces
  and line breaks only to the new gate-forwarding arm.
- The primary reversed only its own proposal-02 metadata literals, then generated
  and applied proposal-03 against the formatted source. The proof bodies,
  predicates and expected proof counts were not changed.
- `hardware-01` contains only an availability observation. No executable was
  uploaded and no GPU work ran from that directory. The selected hardware packet
  must have its own fresh availability receipt and complete cleanup evidence.

All controller environments originate from explicit allowlists. A command's
deliberately expired observation is resumed using the same accepted future; it
is not a device timeout or evidence of hard-preemptible Context operations.
The two-round gate authorizes at most two requests and never asserts successful
completion, physical identity reuse, arbitrary application authority, formal
machine-code refinement or performance parity.
