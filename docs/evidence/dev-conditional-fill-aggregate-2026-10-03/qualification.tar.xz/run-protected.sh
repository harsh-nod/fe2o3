#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-conditional-aggregate-20261003-JKJYG3
timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-verifier --lib protected_runtime_conditional_coverage \
    -- --ignored --nocapture >"$scratch/protected-conditional.log" 2>&1
tail -n 12 "$scratch/protected-conditional.log"
timeout --kill-after=15s 420s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p rustc-codegen-fe2o3 --test production_extraction_driver_v1 write_only_output_genuine \
    -- --ignored --skip write_only_output_genuine_v9_singleton_proof_inputs_are_admitted --nocapture \
    >"$scratch/protected-fill.log" 2>&1
tail -n 12 "$scratch/protected-fill.log"
