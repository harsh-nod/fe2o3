sha256sum --check /home/harsh/.codex-tmp/fe2o3-prefix-20260927-hO4GUD0k/sources.before.sha256 
