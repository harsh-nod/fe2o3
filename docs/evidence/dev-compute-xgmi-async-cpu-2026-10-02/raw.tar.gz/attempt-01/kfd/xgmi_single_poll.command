target/debug/deps/fe2o3_kfd-408178a9a9b41651 xgmi_single_poll --test-threads=1 
