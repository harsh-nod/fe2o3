# Asynchronous Compute-XGMI Increment

Base: d2ff52f63932a4765306528fefd5e82de5b87b12.
Worktree: /home/harsh/.codex-tmp/fe2o3-r61-execution.
Goal remains the complete runtime parity objective; current priority is A3.
Previous turn: progress, signed persistent routing commit pushed to both remotes.

## Implementation Ownership

- multigpu_host_admission: existing SDMA one-observation poll generalized over
  SdmaSingleMemoryV1; rooted compute poll retains completion before closing
  currentness; real mapped-arena CPU tests. No runtime or transfer edits.
- xgmi_integration_review: shared transfer sequence and persistent begin/poll/
  finish API. Settle both model loans before each return, original owners remain
  rooted while pending; reject occupied output slots before effects. Preserve
  synchronous API. No SDMA or runtime edits.
- xgmi_source_ci: runtime phaseful driver and exact whole-child occupancy;
  mutation/progress admission, observer deferral, cancellation and drain. Reuse
  existing cooperative ledger. Include repeated-Pending and disjoint-pair tests.
- root: integration review, source-guard metadata audit, validation, documentation,
  evidence, signed commit, and both remote pushes.

## Agreed Lower API

begin_persistent_data_full_extent_with_peer_v1 takes two input owner slots after
preflight, maps and publishes, and returns after both model retakes.
poll_persistent_data_full_extent_with_peer_v1 samples once, returning false for
Pending and true for Ready; it neither returns buffers nor remaps on Pending.
finish_persistent_data_full_extent_with_peer_v1 rejects nonempty output slots,
remaps locally, retakes both models and restores both original persistent owners.

SDMA poll_compute_xgmi_rooted_v1 returns Result<bool, Gfx942SdmaErrorV1>.
It uses the existing actual one-shot queue-owner poll, not a zero-duration wait.
Completed mappings are rooted before the closing route check can fail or unwind.
Pending is not terminal. Admitted uncertain errors and panics retain custody and
poison the queue and both endpoints. Wrong phase/session or occupied output-slot
preflight rejection leaves owners untouched without native effects.

Runtime retains both exact child reservations through queue retirement and BOTH
allocation restorations. No staging fallback after native effects. Harmless
stored observers remain available; blocked dependencies must not become failures.
Post-publication cancellation is TooLate. Pending sampling makes no cooperative
progress, so flush yields. Drain checks its deadline between phases. No hard
real-time bound is claimed over native ioctl/sysfs operations.

## Verification Plan

Source is not frozen and no new acceptance is claimed by this work order.
Once integrated, run locked/offline nightly-2026-04-03 combined library builds,
new focused lower/adapter/runtime tests, complete runtime regression, strict
combined all-feature Clippy, no-default check, example tests/build, formatting,
and the unchanged source-controls workflow. Keep optimized-test profile and all
assertions explicit; preserve failures and exact executable identities.

Source-guard refresh must remain AST metadata-only with proof closures unchanged;
it is not a new formal proof. Do not weaken guards to accommodate behavior.
The complete composed native map/packet/retirement fault campaign and hardware
execution remain separate gaps. Fresh SSH at 2026-10-02 00:35 UTC failed DNS
before any remote command; no current pair is admitted and no scratch was made.
Do not touch docs/evidence/dev-owner-inspection-2026-09-23/.
