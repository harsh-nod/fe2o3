#!/bin/bash
set -euo pipefail
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
raw=/home/harsh/.codex-tmp/fe2o3-compute-xgmi-async-20261002
packet="$root/docs/evidence/dev-compute-xgmi-async-cpu-2026-10-02"
base=d2ff52f63932a4765306528fefd5e82de5b87b12
cd "$root"
test "$(git rev-parse HEAD)" = "$base"
test ! -e "$packet/raw.tar.gz"
test "$(< "$raw/attempt-03/build/overall.exit")" = 0
test "$(< "$raw/attempt-03/kfd/overall.exit")" = 0
test "$(< "$raw/attempt-03/runtime/overall.exit")" = 1
test "$(< "$raw/attempt-03/runtime/full.exit")" = 101
test "$(< "$raw/attempt-04/checks/overall.exit")" = 0
sha256sum -c "$raw/attempt-03/build/elf.sha256"
sha256sum target/debug/deps/fe2o3_kfd-408178a9a9b41651 \
    target/debug/deps/fe2o3_runtime-6f56d726eb64a207 \
    target/debug/examples/gfx942-runtime-compute-xgmi-smoke > "$raw/final-elf.sha256"
cmp <(tail -n 1 "$raw/final-elf.sha256") \
    <(tail -n 1 "$raw/attempt-04/checks/elf-final.sha256")
printf '%s\n' "$base" > "$raw/base-commit.txt"
git diff --binary "$base" -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model/verus > "$raw/source.patch"
git diff --name-only "$base" -- crates/fe2o3-kfd crates/fe2o3-runtime crates/fe2o3-runtime-model/verus > "$raw/source-paths.txt"
mapfile -t paths < "$raw/source-paths.txt"
test "${#paths[@]}" -gt 0
sha256sum "${paths[@]}" > "$raw/source.sha256"
sha256sum "$raw/source.patch" > "$raw/source-patch.sha256"
rustc +nightly-2026-04-03 -Vv > "$raw/rustc.txt"
cargo +nightly-2026-04-03 -V > "$raw/cargo.txt"
uname -a > "$raw/uname.txt"
cp -a /home/harsh/.codex-tmp/fe2o3-multigpu-native-recovery-20261001/admission-continuation-20261002 "$raw/admission"
mkdir -p "$packet"
tar -czf "$packet/raw.tar.gz" -C "$raw" .
cd "$packet"
sha256sum raw.tar.gz > SHA256SUMS
