#!/usr/bin/env python3
"""Prepare a new metadata proposal for one declared Copy-clone test correction.

This is an audited equivalent of the retained final-refresh/verify-final pattern.
It reuses MetadataEdits and guard-loading logic from the pinned original proposer,
and emits the original report schema for the pinned verifier and exact32 runner.
No repository file is written. Invoke only after the root agent's final freeze.
"""

import argparse
import ast
import copy
import difflib
import json
from pathlib import Path
import runpy
import sys
import time


OUT = Path(__file__).resolve().parent
support = runpy.run_path(str(OUT / 'support.py'), run_name='final_refresh_support')
ROOT, BASE = support['ROOT'], support['BASE']
need, sha, git = support['need'], support['sha'], support['git']
V = Path('crates/fe2o3-runtime-model/verus')
RUNTIME = Path('crates/fe2o3-runtime/src')
TEST = 'crates/fe2o3-runtime/src/kfd_backend/compute_xgmi/tests.rs'
TEST_SHA = '9d8e1e93674e78d78571286362afe81ea76a81d7d1ac80aa1935d359314c6b84'
DECLARED = {
    'crates/fe2o3-kfd/src/sdma/tests/xgmi_single_poll.rs': 'xgmi-single-poll.before-clippy.rs',
}
PARENT = OUT / 'proposal-final-03'
PARENT_REPORT_SHA = '949db4c158f30bf29d9b1a43926a2233256a924f0159d7232f34a2356f27ccec'
PRIOR_ATTEMPT = 'attempt-04-after'
PRIOR_RESULT_SHA = 'da825a1079965276df91ffbe92fbf92ebe1faeb84dae7660ea0314dde324c3e2'


def constants(tree):
    return {(node.lineno, node.col_offset): node for node in ast.walk(tree)
            if isinstance(node, ast.Constant)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-frozen', action='store_true', required=True)
    parser.add_argument('--name', required=True)
    parser.add_argument('--test-preimages', type=Path, required=True)
    args = parser.parse_args()
    retained_support = support['check_support']()
    raw_parent = (PARENT / 'metadata-report.json').read_bytes()
    need(sha(raw_parent) == PARENT_REPORT_SHA, 'unchanged immediately preceding metadata report')
    parent = json.loads(raw_parent)
    need(parent['baseline'] == BASE, 'same original d2 baseline')
    need(sum(len(row['edits']) for row in parent['changes']) == 19
         and all(edit['category'] == 'content-sha256'
                 for row in parent['changes'] for edit in row['edits']),
         'exact original nineteen-node SHA-only whitelist')
    prior_result = OUT / PRIOR_ATTEMPT / 'result.json'
    need(sha(prior_result.read_bytes()) == PRIOR_RESULT_SHA, 'unchanged preceding workflow result')
    need(json.loads(prior_result.read_bytes())['accepted'], 'preceding workflow remains accepted')
    prior_inventory = json.loads((OUT / PRIOR_ATTEMPT / 'closing-source.json').read_bytes())
    runner_argv = sys.argv
    try:
        sys.argv = [str(support['RUNNER']), str(OUT / 'not-executed')]
        runner = runpy.run_path(str(support['RUNNER']), run_name='inventory_only')
    finally:
        sys.argv = runner_argv
    runner['source_paths'].__globals__['REPO'] = ROOT
    paths = runner['source_paths']()
    need(paths == set(prior_inventory), 'complete workflow source roster is unchanged')
    inventory = runner['snapshot'](paths)
    changed = {path for path in paths if inventory[path] != prior_inventory[path]}
    need(changed == set(DECLARED), 'only declared Copy-clone test source changed: ' + repr(sorted(changed)))
    need(inventory[TEST] == parent['audited_source_sha256'][TEST] == TEST_SHA,
         'previously qualified runtime test bytes remain unchanged')
    preimages = {}
    for path, relative in DECLARED.items():
        retained = args.test_preimages / relative
        need(retained.is_file() and not retained.is_symlink(),
             'ordinary retained exact preceding-run test preimage: ' + path)
        preimage = retained.read_bytes()
        need(sha(preimage) == parent['audited_source_sha256'][path] == prior_inventory[path],
             'test preimage authenticated by both preceding-run inventories: ' + path)
        before = b'let generations = owner.generations.clone();'
        after = b'let generations = owner.generations;'
        need(preimage.count(before) == 1 and preimage.replace(before, after) == (ROOT / path).read_bytes(),
             'exact single Copy-array redundant-clone removal with no other byte changes')
        need(path not in parent['proof_files'], 'declared test input is not an executable proof')
        preimages[path] = preimage
    folder = support['artifact'](args.name)
    folder.mkdir()
    support['fresh_json'](folder / 'invocation.json', dict(
        retained_support, recorded_utc_ns=time.time_ns(), command=sys.argv,
        parent_metadata_report_sha256=PARENT_REPORT_SHA,
        parent_workflow_result_sha256=PRIOR_RESULT_SHA,
        declared_source_delta=sorted(DECLARED), source_freeze_declared=True,
        exact_copy_clone_replacement_verified=True,
        original_sha_node_whitelist_size=19, allowed_count_changes=0))
    originals = folder / 'originals'
    originals.mkdir()
    namespace = runpy.run_path(str(OUT / 'reference/propose.py'), run_name='metadata_primitives')
    namespace['load'].__globals__['ROOT'] = ROOT
    Edits, load = namespace['MetadataEdits'], namespace['load']
    modules, proposed, changes, audited, proof_files, refreshes = {}, {}, [], {}, {}, []
    prior_rows = {Path(row['path']).name: row for row in parent['changes']}

    def record(name, current, edits):
        final = edits.proposed()
        prior = prior_rows[name]
        original = (PARENT / 'originals' / name).read_bytes()
        need(sha(original) == prior['original_sha256'], 'unchanged original guard preimage')
        need(original == git('show', f'{BASE}:{prior["path"]}'), 'guard original is baseline blob')
        expected = ast.parse(original)
        before_nodes, final_nodes = constants(expected), constants(ast.parse(final))
        approved = {(edit['line'], edit['column']) for edit in prior['edits']}
        need(all((edit['line'], edit['column']) in approved for edit in edits.edits),
             'every refreshed literal belongs to original nineteen-node whitelist')
        row = copy.deepcopy(prior)
        for edit in row['edits']:
            position = edit['line'], edit['column']
            need(before_nodes[position].value == edit['old'], 'exact original literal preimage')
            value = final_nodes[position].value
            need(isinstance(value, str) and len(value) == 64
                 and all(letter in '0123456789abcdef' for letter in value), 'exact SHA identity')
            before_nodes[position].value = value
            edit['new'] = value
        need(ast.dump(expected, include_attributes=False)
             == ast.dump(ast.parse(final), include_attributes=False),
             'final guard AST identical except original approved SHA nodes')
        row['previous_proposed_sha256'] = prior['proposed_sha256']
        row['proposed_sha256'] = sha(final.encode())
        row['final_refresh_edits'] = edits.edits
        (originals / name).write_bytes(original)
        proposed[name] = final
        changes.append(row)
        refreshes.extend(dict(path=prior['path'], **edit) for edit in edits.edits)
        return final

    for name in namespace['GUARDS']:
        prior = prior_rows[name]
        current = (ROOT / V / name).read_text()
        need(sha(current.encode()) == prior['proposed_sha256'], 'guard still matches preceding proposal')
        old = load(name, current)
        sources = old.snapshot()
        files = old.FILES if hasattr(old, 'FILES') else old.files()
        for path in files:
            digest = sha(sources[path].encode())
            need(digest == parent['proof_files'][str(path)], 'executable proof closure unchanged')
            proof_files[str(path)] = digest
        audited.update({str(path): sha(text.encode()) for path, text in sources.items()})
        edits = Edits(current)
        if hasattr(old, 'SOURCE_TREE_SHA'):
            if name in ('check-producer-input-fold.py', 'check-retained-pair-routing.py'):
                implementation = {path: text for path, text in sources.items() if path.is_relative_to(old.SRC)}
            elif name == 'check-producer-input-validate.py':
                implementation = {path: text for path, text in sources.items()
                                  if path.is_relative_to(old.SRC) or path in old.DECLARATIONS}
            else:
                implementation = {path: text for path, text in sources.items() if path != old.PROOF}
            edits.assignment('SOURCE_TREE_SHA', old.tree_hash(implementation), 'content-sha256',
                             'whole-source identity after declared Copy-clone test correction')
            if hasattr(old, 'SOURCE_FILES'):
                need(old.SOURCE_FILES == len(implementation), 'source inventory count unchanged')
        elif hasattr(old, 'RUNTIME_SHA'):
            implementation = {path: text for path, text in sources.items() if path.is_relative_to(old.RUNTIME)}
            edits.assignment('RUNTIME_SHA', old.tree_hash(implementation), 'content-sha256',
                             'runtime source identity after declared KFD Copy-clone test correction')
            need(old.RUNTIME_FILES == len(implementation), 'runtime inventory count unchanged')
        elif hasattr(old, 'PINS'):
            need(all(sha(sources[path].encode()) == digest for path, digest in old.PINS.items()),
                 'cadence pins including individually audited SDMA pin unchanged since preceding proposal')
        for attribute in ('CHECKER_PINS', 'HELPERS'):
            if hasattr(old, attribute):
                for helper in getattr(old, attribute):
                    edits.pin(attribute, helper, sha(proposed[helper].encode()))
        final = record(name, current, edits)
        new = load(name, final)
        if hasattr(new, 'load_checker'):
            new.load_checker = lambda helper: modules[helper]
        if hasattr(new, 'helper'):
            new.helper = lambda helper: modules[helper]
        new.audit(sources)
        modules[name] = new

    name = 'test-producer-input-composition.py'
    current = (ROOT / V / name).read_text()
    need(sha(current.encode()) == prior_rows[name]['proposed_sha256'], 'unchanged duplicate guard metadata')
    edits = Edits(current)
    fold, leaf = modules['check-producer-input-fold.py'], modules['check-producer-input-validate.py']
    edits.assignment('NATIVE_TREE_SHA', fold.SOURCE_TREE_SHA, 'content-sha256', 'duplicate runtime identity')
    edits.assignment('SCHEMA_TREE_SHA', leaf.SOURCE_TREE_SHA, 'content-sha256', 'duplicate runtime/schema identity')
    for helper in ('check-producer-input-validate.py', 'check-producer-input-fold.py', 'check-producer-input-composition.py'):
        edits.pin('CHECKER_PINS', helper, sha(proposed[helper].encode()))
    record(name, current, edits)
    name = 'producer-journal-composition-mutations-v1.py'
    current = (ROOT / V / name).read_text()
    need(sha(current.encode()) == prior_rows[name]['proposed_sha256'], 'unchanged mutation controller')
    edits = Edits(current)
    edits.assignment('GUARD_SHA', sha(proposed['check-producer-journal-composition.py'].encode()),
                     'content-sha256', 'transitive guard identity; mutation roster unchanged')
    record(name, current, edits)
    need(set(audited) == set(parent['audited_source_sha256']), 'audited input roster unchanged')
    need({path for path in audited if audited[path] != parent['audited_source_sha256'][path]} == set(DECLARED),
         'exact declared change in complete audited source inventory')
    need(proof_files == parent['proof_files'], 'exact original executable proof closure')
    need(runner['source_paths']() == paths and runner['snapshot'](paths) == inventory,
         'all source inputs remained stable throughout refresh proposal')
    patch = ['*** Begin Patch\n']
    for name, final in proposed.items():
        current = (ROOT / V / name).read_text()
        if current != final:
            patch.append('*** Update File: ' + str(ROOT / V / name) + '\n')
            patch.extend('@@\n' if line.startswith('@@ ') else line for line in
                         list(difflib.unified_diff(current.splitlines(True), final.splitlines(True), n=3))[2:])
    patch.append('*** End Patch\n')
    (folder / 'metadata.patch').write_text(''.join(patch))
    deltas = []
    for path, relative in DECLARED.items():
        preimage, final_bytes = preimages[path], (ROOT / path).read_bytes()
        deltas.append(dict(path=path, old_sha256=sha(preimage), new_sha256=sha(final_bytes),
                          scope='exact single redundant clone removal on Copy [u32; 64] in lower sampler test',
                          exact_prior_preimage_verified=True,
                          unified_diff=''.join(difflib.unified_diff(preimage.decode().splitlines(True),
                              final_bytes.decode().splitlines(True), fromfile=PRIOR_ATTEMPT + '/' + path,
                              tofile='final/' + path))))
        retained = folder / 'test-preimages' / relative
        retained.parent.mkdir(parents=True, exist_ok=True)
        retained.write_bytes(preimage)
    result = dict(parent, changes=changes, audited_source_sha256=audited,
                  parent_metadata_report_sha256=PARENT_REPORT_SHA, parent_workflow_result_sha256=PRIOR_RESULT_SHA,
                  declared_source_delta=deltas, metadata_refreshes=refreshes,
                  original_sha_whitelist_preserved=True, no_source_inventory_count_changes=True,
                  all_final_proposed_source_audits_passed=True,
                  complete_workflow_source_roster_unchanged=True)
    support['fresh_json'](folder / 'metadata-report.json', result)
    print(json.dumps(dict(declared_changed_test_files=1, exact_prior_preimages_verified=True,
                          refreshed_hash_constants=len(refreshes), original_hash_whitelist=19,
                          source_inventory_constants=0, unchanged_proof_files=len(proof_files),
                          unchanged_source_roster=len(audited), all_proposed_source_audits_passed=True,
                          solver_executed=False, build_executed=False), sort_keys=True))


if __name__ == '__main__':
    main()
