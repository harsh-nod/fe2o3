"""Final qualification after isolated test cleanup and signature formatting."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qualification_predecessor', RAW / 'qualify.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
jobs = {label: (bound, command) for label, bound, command in prior.JOBS}
ORDER = [
    ('format-final-04', 'format'),
    ('whitespace-final-04', 'whitespace'),
    ('build-witness-final-04', 'build-witness'),
    ('clippy-lib-final-04', 'clippy-lib'),
    ('clippy-example-final-04', 'clippy-example'),
    ('sharded-final-04', 'sharded-final'),
    ('runtime-tests-final-04', 'runtime-tests-final'),
    ('runtime-list-final-04', 'runtime-list'),
    ('example-tests-final-04', 'example-tests'),
    ('example-list-final-04', 'example-list'),
    ('doctests-final-04', 'doctests'),
    ('check-default-final-04', 'check-default'),
]
JOBS = [(new, *jobs[old]) for new, old in ORDER]


def main():
    results = []
    for label, bound, command in JOBS:
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'),
                                 label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    (RAW / 'qualification-final-04-summary.json').write_text(json.dumps(results, indent=2) + '\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
