"""Run the checked-in no-solver workflow commands, preserving each result."""

import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = Path(__file__).resolve().parent / 'source-controls-commands-final-03'
WORKFLOW = ROOT / '.github/workflows/runtime-component-source-guards.yml'


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode
    OUT.mkdir(mode=0o700)
    workflow = yaml.safe_load(WORKFLOW.read_text())
    commands = []
    for step in workflow['jobs']['source-controls']['steps']:
        if 'run' in step:
            for line in step['run'].splitlines():
                command = shlex.split(line)
                assert command[:3] == ['python3', '-I', '-B'], command
                commands.append((step['name'], command))
    assert len(commands) == 32
    results = []
    for index, (name, command) in enumerate(commands):
        folder = OUT / f'{index:02d}'
        folder.mkdir()
        with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
            result = subprocess.run(['timeout', '--kill-after=5s', '120s', *command],
                                    cwd=ROOT, stdout=stdout, stderr=stderr, check=False)
        row = dict(name=name, command=command, exit=result.returncode)
        for item in ('stdout', 'stderr'):
            row[item + '_sha256'] = hashlib.sha256((folder / item).read_bytes()).hexdigest()
        (folder / 'receipt.json').write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
        results.append(row)
        print(json.dumps(row), flush=True)
    accepted = all(row['exit'] == 0 for row in results)
    (OUT / 'summary.json').write_text(json.dumps(dict(
        accepted=accepted, commands=results,
        workflow_sha256=hashlib.sha256(WORKFLOW.read_bytes()).hexdigest(),
        controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        solver_executed=False), sort_keys=True, indent=2) + '\n')
    return 0 if accepted else 1


if __name__ == '__main__':
    sys.exit(main())
