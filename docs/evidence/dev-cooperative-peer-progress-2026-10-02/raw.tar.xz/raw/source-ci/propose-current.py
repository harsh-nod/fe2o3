"""Bind the unchanged strict metadata proposer to this baseline and a fresh output."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
BASE = '2bc47c614eaff9ba75cedfe42c9c8c030f3bfd21'
REFERENCES = {
    'propose.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    'verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
}


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2
    label = sys.argv[1]
    assert label.startswith('proposal-') and label[9:].isdigit()
    for name, expected in REFERENCES.items():
        assert hashlib.sha256((HERE / 'reference' / name).read_bytes()).hexdigest() == expected
    spec = importlib.util.spec_from_file_location('strict_metadata_proposer', HERE / 'reference/propose.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.BASE = BASE
    module.OUT = HERE / label
    owner = Path('crates/fe2o3-runtime/src/context/versions/producer_readers.rs')
    assert (module.ROOT / owner).read_text() == module.blobs([owner])[owner]
    module.OUT.mkdir(mode=0o700)
    (module.OUT / 'invocation.json').write_text(json.dumps(dict(
        base=BASE, output=str(module.OUT), references=REFERENCES,
        wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        native_owner_unchanged=True, no_custom_metadata_hooks=True,
        solver_executed=False, build_executed=False), sort_keys=True, indent=2) + '\n')
    module.main()
    report = json.loads((module.OUT / 'metadata-report.json').read_bytes())
    edits = [edit for row in report['changes'] for edit in row['edits']]
    assert sum(bool(row['edits']) for row in report['changes']) == 9
    assert sum(edit['category'] == 'content-sha256' for edit in edits) == 16
    assert sum(edit['category'] == 'source-inventory-count' for edit in edits) == 7
    assert len(report['proof_files']) == 76
    assert not any(edit['selector'] == 'NATIVE_PREEXTRACTION_SHA'
                   or edit['selector'].startswith('PINS[') for edit in edits)
    shutil.copyfile(HERE / 'reference/verify-applied.py', module.OUT / 'verify-applied.py')


if __name__ == '__main__':
    main()
