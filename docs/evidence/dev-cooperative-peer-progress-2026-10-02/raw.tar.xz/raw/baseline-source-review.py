"""Read-only source-control baseline replay in one owned detached worktree."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
OUT = RAW / 'baseline-source-controls-01'
WORK = Path('/home/harsh/.codex-tmp/fe2o3-cooperative-source-baseline-2bc47c614-01')
BASE = '2bc47c614eaff9ba75cedfe42c9c8c030f3bfd21'
ENV = {'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}


def record(name, argv, cwd, bound):
    folder = OUT / name
    folder.mkdir()
    command = ['timeout', '--kill-after=5s', f'{bound}s', *argv]
    row = dict(command=command, cwd=str(cwd), environment=ENV,
               started=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
        result = subprocess.run(command, cwd=cwd, env=ENV, stdout=stdout,
                                stderr=stderr, check=False)
    row.update(exit=result.returncode,
               finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for item in ('stdout', 'stderr'):
        row[item + '_sha256'] = hashlib.sha256((folder / item).read_bytes()).hexdigest()
    (folder / 'receipt.json').write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
    print(json.dumps(dict(stage=name, exit=row['exit'])), flush=True)
    return row


def snapshot():
    listing = subprocess.check_output(['git', 'ls-files', '-z', '--', 'crates',
        'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'], cwd=WORK, env=ENV)
    return {os.fsdecode(name): hashlib.sha256((WORK / os.fsdecode(name)).read_bytes()).hexdigest()
            for name in sorted(set(listing.split(b'\0'))) if name}


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode
    assert not WORK.exists()
    OUT.mkdir(mode=0o700)
    added = record('worktree-add', ['git', 'worktree', 'add', '--detach', str(WORK), BASE], ROOT, 240)
    assert added['exit'] == 0
    try:
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, env=ENV, text=True).strip()
        assert head == BASE
        workflow_path = WORK / '.github/workflows/runtime-component-source-guards.yml'
        workflow_bytes = workflow_path.read_bytes()
        commands = []
        for step in yaml.safe_load(workflow_bytes)['jobs']['source-controls']['steps']:
            for line in step.get('run', '').splitlines():
                argv = shlex.split(line)
                assert argv[:3] == ['python3', '-I', '-B']
                commands.append((step['name'], argv))
        assert len(commands) == 32
        before = snapshot()
        (OUT / 'source-before.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
        rows = [record(f'{index:02d}', argv, WORK, 120) for index, (_, argv) in enumerate(commands)]
        after = snapshot()
        (OUT / 'source-after.json').write_text(json.dumps(after, sort_keys=True, indent=2) + '\n')
        result = dict(base=BASE, worktree=str(WORK), workflow_sha256=hashlib.sha256(workflow_bytes).hexdigest(),
                      controller_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      source_unchanged=before == after, commands=rows,
                      accepted=before == after and all(row['exit'] == 0 for row in rows),
                      solver_executed=False, cargo_executed=False)
        (OUT / 'summary.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    finally:
        removed = record('worktree-remove', ['git', 'worktree', 'remove', str(WORK)], ROOT, 120)
        assert removed['exit'] == 0 and not WORK.exists()
    return 0


if __name__ == '__main__':
    sys.exit(main())
