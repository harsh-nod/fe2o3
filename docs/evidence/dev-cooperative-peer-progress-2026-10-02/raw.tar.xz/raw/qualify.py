"""Source-bound sequential CPU qualification after focused diagnostics."""

import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
COMMON = ['--locked', '--offline', '-p', 'fe2o3-runtime']
LIB = [*COMMON, '--all-features', '--lib']
WITNESS = [*COMMON, '--no-default-features', '--features', 'hardware-qualification',
           '--example', 'gfx942-runtime-deferred-peer-chain-smoke']
CHANGED = [
    'crates/fe2o3-runtime/src/async_engine.rs',
    'crates/fe2o3-runtime/src/async_engine/operation.rs',
    'crates/fe2o3-runtime/src/async_engine/registration.rs',
    'crates/fe2o3-runtime/src/context.rs',
    'crates/fe2o3-runtime/src/kfd_backend.rs',
    'crates/fe2o3-runtime/src/kfd_backend/compute_xgmi/tests.rs',
    'crates/fe2o3-runtime/src/kfd_backend/producer_peers.rs',
    'crates/fe2o3-runtime/src/kfd_backend/progress_quantum.rs',
    'crates/fe2o3-runtime/src/kfd_backend/progress_quantum_tests.rs',
    'crates/fe2o3-runtime/src/kfd_backend/compute_xgmi/tests/sharded.rs',
    'crates/fe2o3-runtime/src/async_engine/tests/progress_spi_tests.rs',
    'crates/fe2o3-runtime/src/context/tests/progress_stream_tests.rs',
    'crates/fe2o3-runtime/examples/deferred_peer_chain/gather_compute.rs',
]
JOBS = [
    ('build-witness', '900s', ['cargo', 'build', *WITNESS, '--profile', 'test', '--message-format=json']),
    ('sharded-final', '900s', ['cargo', 'test', *LIB,
        'kfd_backend::compute_xgmi::tests::sharded::current_thread_sharded_ring_queues_all_futures_before_expired_and_resumed_drive',
        '--', '--exact', '--test-threads=1']),
    ('runtime-tests-final', '900s', ['cargo', 'test', *LIB, '--', '--test-threads=1']),
    ('runtime-list', '120s', ['cargo', 'test', *LIB, '--', '--list']),
    ('example-tests', '900s', ['cargo', 'test', *WITNESS]),
    ('example-list', '120s', ['cargo', 'test', *WITNESS, '--', '--list']),
    ('clippy-lib', '900s', ['cargo', 'clippy', *LIB, '--tests', '--no-deps', '--', '-D', 'warnings']),
    ('clippy-example', '900s', ['cargo', 'clippy', *WITNESS, '--no-deps', '--', '-D', 'warnings']),
    ('doctests', '900s', ['cargo', 'test', *COMMON, '--all-features', '--doc']),
    ('check-default', '900s', ['cargo', 'check', *COMMON, '--no-default-features', '--lib']),
    ('format', '120s', ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024',
                        '--config', 'skip_children=true', *CHANGED]),
    ('whitespace', '60s', ['git', 'diff', 'HEAD', '--check']),
]


def main():
    results = []
    for label, bound, command in JOBS:
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'),
                                 label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    (RAW / 'qualification-summary.json').write_text(json.dumps(results, indent=2) + '\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
