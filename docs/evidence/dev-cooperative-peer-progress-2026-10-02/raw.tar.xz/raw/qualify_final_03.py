"""Repeat qualification after the isolated non-Drop test cleanup."""

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qualification_predecessor', RAW / 'qualify.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
jobs = {label: (bound, command) for label, bound, command in prior.JOBS}
ORDER = [
    ('build-witness-final', 'build-witness'),
    ('clippy-lib-final', 'clippy-lib'),
    ('clippy-example-final', 'clippy-example'),
    ('sharded-final-03', 'sharded-final'),
    ('runtime-tests-final-03', 'runtime-tests-final'),
    ('runtime-list-final', 'runtime-list'),
    ('example-tests-final', 'example-tests'),
    ('example-list-final', 'example-list'),
    ('doctests-final', 'doctests'),
    ('check-default-final', 'check-default'),
    ('format-final', 'format'),
    ('whitespace-final', 'whitespace'),
]
JOBS = [(new, *jobs[old]) for new, old in ORDER]


def main():
    results = []
    for label, bound, command in JOBS:
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'),
                                 label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    (RAW / 'qualification-final-summary.json').write_text(json.dumps(results, indent=2) + '\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
