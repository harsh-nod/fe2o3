"""Remove only this campaign's terminal extraction build directory."""
import json
import os
from pathlib import Path
import shutil

TARGET = Path('/home/harsh/.codex-tmp/fe2o3-entry-output-target-20261003')
assert TARGET.is_dir() and not TARGET.is_symlink() and TARGET.stat().st_uid == os.getuid()
processes = []
for process in Path('/proc').iterdir():
    if not process.name.isdecimal():
        continue
    try:
        if process.stat().st_uid == os.getuid() and str(TARGET).encode() in (process / 'cmdline').read_bytes():
            processes.append(int(process.name))
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        continue
assert not processes, processes
shutil.rmtree(TARGET)
report = dict(removed=str(TARGET), absent=not TARGET.exists(), matching_processes=processes)
assert report['absent']
print(json.dumps(report, sort_keys=True))
