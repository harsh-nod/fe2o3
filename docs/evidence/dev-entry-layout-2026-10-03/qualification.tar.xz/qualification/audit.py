"""Replay separate baseline-emission and final inspection qualification ledgers."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '62846ad4d7e78db663d1c22f3dd252af7c658893'
sys.path.insert(0, str(HERE))
import capture


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def receipt(label, source):
    folder = HERE / label
    row = read(folder / 'receipt.json')
    assert row['exit'] == 0 and row['source_unchanged'], label
    assert row['base'] == BASE and row['environment'] == capture.ENV
    assert row['controller_sha256'] == sha(HERE / 'capture.py')
    assert read(folder / 'source-before.json') == source == read(folder / 'source-after.json')
    for stream in ('stdout', 'stderr'):
        assert row[stream + '_sha256'] == sha(folder / stream)
    return row


def counts(label):
    output = (HERE / label / 'stdout').read_text()
    rows = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', output)
    assert rows and 'FAILED' not in output
    return [sum(int(row[index]) for row in rows) for index in range(2)]


baseline = read(HERE / 'discovery-build/source-before.json')
discovery = {label: receipt('discovery-' + label, baseline) for label in (
    'build', 'extract', 'clang', 'disassemble', 'metadata')}
source = capture.snapshot()
commands = read(HERE / 'qualification-commands-final2.json')
assert len(commands) == 44
final = {}
for command in commands:
    assert command['exit'] == 0 and command['label'].startswith('final2-')
    row = receipt(command['label'], source)
    assert row['command'][4:] == command['command']
    final[command['label']] = row
assert len(final) == 44
for label in ('final2-reproduce', 'final2-cleanup'):
    final[label] = receipt(label, source)
assert counts('final2-tests') == counts('final2-no-default') == [70, 1]
roster = set(re.findall(r'^(.+): test$', (HERE / 'final2-roster/stdout').read_text(), re.M))
tested = set(re.findall(r'^test (.+) \.\.\. (?:ok|ignored[^\n]*)$',
                        (HERE / 'final2-tests/stdout').read_text(), re.M))
assert roster == tested and len(roster) == 71

modified = {'crates/fe2o3-hsaco/src/kernel_binding.rs', 'crates/fe2o3-hsaco/src/lib.rs',
            'crates/fe2o3-hsaco/tests/inspection.rs'}
added = {'crates/fe2o3-hsaco/src/kernel_binding/gfx942_initial_registers.rs',
         'crates/fe2o3-hsaco/src/kernel_binding/gfx942_initial_registers/tests.rs'}
fixture = 'crates/fe2o3-hsaco/tests/fixtures/rust-fill-write-only-gfx942/'
added |= {fixture + name for name in ('README.md', 'kernel.ll', 'kernel.hsaco')}
assert set(source) - set(baseline) == added
assert set(baseline) <= set(source)
assert {path for path in baseline if source[path] != baseline[path]} == modified
tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', BASE], cwd=ROOT)
blobs = {}
for entry in tree.split(b'\0'):
    if entry:
        metadata, path = entry.split(b'\t', 1)
        blobs[path.decode()] = metadata.split()[2].decode()
for path, digest in baseline.items():
    data = (subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
            if path in modified else (ROOT / path).read_bytes())
    assert hashlib.sha256(data).hexdigest() == digest
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blobs[path]

identities = read(HERE / 'fill-write-only/identities.json')
for name, identity in identities.items():
    original = HERE / 'fill-write-only' / name
    assert sha(original) == identity['sha256'] and original.stat().st_size == identity['bytes']
    assert original.read_bytes() == (ROOT / fixture / name).read_bytes()
assert sha(HERE / 'reproduced.hsaco') == identities['kernel.hsaco']['sha256']
llvm = (HERE / 'fill-write-only/kernel.ll').read_text()
assert llvm.count('define amdgpu_kernel void @') == 1
assert 'define amdgpu_kernel void @fill_write_only(ptr addrspace(1) %arg0.data, i64 %arg0.len)' in llvm
diagnostic = (HERE / 'discovery-extract/stderr').read_text()
assert 'Kernel IR V9 with 1 GuardedStore operation(s)' in diagnostic
assert '-> gfx942:xnack- LLVM;' in diagnostic and 'artifact/launch authority false' in diagnostic
assert not any('EXTRACT_CHECKED_U32' in item for item in discovery['extract']['command'])
disassembly = (HERE / 'discovery-disassemble/stdout').read_text()
function = disassembly.split('<fill_write_only>:', 1)[1].split('s_nop', 1)[0]
assert len(re.findall(r'^\s+[a-z][a-z0-9_]*', function, re.M)) == 14
assert function.count('global_store_dword') == function.count('s_endpgm') == 1

for row in (final['final2-artifacts'], discovery['build']):
    for path, identity in row['executables'].items():
        assert sha(Path(path)) == identity['sha256']
        assert Path(path).stat().st_size == identity['bytes']
tools = {}
for line in (HERE / 'final2-tool-identities/stdout').read_text().splitlines():
    digest, path = line.split(maxsplit=1)
    assert path not in tools and sha(Path(path)) == digest
    tools[path] = digest
assert len(tools) == 5
proofs = read(Path('/home/harsh/.codex-tmp/fe2o3-result-staging-20261003/metadata-01/metadata-report.json'))['proof_files']
assert len(proofs) == 76 and all(source[path] == digest for path, digest in proofs.items())
(HERE / 'unchanged-proof-files.json').write_text(json.dumps(proofs, sort_keys=True, indent=2) + '\n')
cleanup = json.loads((HERE / 'final2-cleanup/stdout').read_text())
assert cleanup == dict(removed='/home/harsh/.codex-tmp/fe2o3-entry-output-target-20261003',
                       absent=True, matching_processes=[])
assert not Path(cleanup['removed']).exists()
report = dict(base=BASE, baseline_source_files=len(baseline), final_source_files=len(source),
              discovery_receipts=len(discovery), final_receipts=len(final),
              tests=counts('final2-tests'), roster=len(roster),
              supported_layout_combinations=768, user_count_combinations=512,
              unchanged_selected_proof_files=len(proofs),
              fixture_artifacts=identities, reproduced_hsaco=True, cleanup=cleanup,
              hsaco_artifacts=final['final2-artifacts']['executables'],
              native_runs=0, solver_runs=0,
              boundary='Descriptive initial locations, not a formal ABI/value/whole-kernel proof')
(HERE / 'audit-report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
