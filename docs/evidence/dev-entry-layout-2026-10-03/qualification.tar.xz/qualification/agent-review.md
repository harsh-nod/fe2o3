# Independent Read-Only Reviews

Primary implemented and tested the patch. The three native agents did not edit
files, build or run hardware.

- multigpu_host_admission: normal target lowering already owns the same semantic,
  KIR/formal and typed-root evidence; inert handoff preparation already performs
  descriptor construction/embedding. Do not add another ABI owner. Reviewed new
  inspection-derived register layout API and fixture provenance without finding
  a concrete blocker.
- xgmi_integration_review: verified the actual captured descriptor and ELF symbol
  with read-only inspection. Descriptor offset0x500, entry file0x600/VA0x1600,
  symbol length68, last END at0x1640, padding starts0x1644. RSRC1=0x00af0040,
  RSRC2=0x84, RSRC3=0, properties0x8, kernarg16, private/group/preload0. Reviewed
  initial input order, scratch exclusions, exact-user-count policy and encoded
  allocation checks; no concrete blocker.
- xgmi_source_ci: reviewed all768 supported enable combinations and512 count
  combinations (496rejects). Suggested exhaustive public-getter assertions and
  exact8/9 SGPR capacity boundary; primary added both before final2 qualification.
  VGPR capacity failure is unreachable in this profile (at most3 inputs, minimum
  capacity8); no negative test is claimed for that branch. No unsafe additions
  or existing proof-body changes.

Remaining full-kernel gap is concrete: write-only ranked projection records
plain Access, so optional written-value correspondence is not a universal output
proof. Existing translation validation excludes complete indexed-address and
operational equivalence. The next same-owner profile must bind actual call spans,
index/bounds/address/store value and full effect coverage. Machine-side modeling
must then cover all14 actual instructions and both terminating paths, with exact
input placement, alignment, length/launch bounds and memory completion.

The new layout is descriptive data, not initial register values, pointer validity,
all-active EXEC, compiler refinement or protected Worker authority.
