"""Emit and inspect a real Rust kernel; diagnostic artifacts grant no authority."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
TARGET = Path('/home/harsh/.codex-tmp/fe2o3-entry-output-target-20261003')
TARGET.mkdir(mode=0o700)
OUT = HERE / 'fill-write-only'
OUT.mkdir(mode=0o700)
CARGO = ['cargo', '+nightly-2026-04-03']
steps = [
    ('discovery-build', '1200s', CARGO + ['test', '--locked', '--offline', '-p', 'rustc-codegen-fe2o3',
      '--test', 'production_extraction_driver_v1', '--no-run', '--message-format=json']),
    ('discovery-extract', '1200s', ['env',
      f'RUSTC_WORKSPACE_WRAPPER={ROOT}/target/debug/fe2o3-rustc-extract',
      f'LD_LIBRARY_PATH={ROOT}/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib',
      'FE2O3_EXTRACT_CRATE_V1=fe2o3_production_extraction_fixture',
      f'FE2O3_EXTRACT_AMDGPU_LLVM_PATH_V1={OUT}/kernel.ll',
      'CARGO_TARGET_AMDGCN_AMD_AMDHSA_RUSTFLAGS=-Zalways-encode-mir -Copt-level=3 -Ctarget-cpu=gfx942 -Ctarget-feature=-xnack,+wavefrontsize64,-wavefrontsize32',
      *CARGO, 'check', '--locked', '--offline', '-Zbuild-std=core', '-p', 'fe2o3-production-extraction-fixture',
      '--features', 'write-only-output', '--target', 'amdgcn-amd-amdhsa', '--target-dir', str(TARGET)]),
    ('discovery-clang', '120s', ['env', 'LC_ALL=C', 'SOURCE_DATE_EPOCH=0', '/opt/rocm/llvm/bin/clang',
      '--target=amdgcn-amd-amdhsa', '-mcpu=gfx942:xnack-', '-nogpulib', '-O2',
      str(OUT / 'kernel.ll'), '-o', str(OUT / 'kernel.hsaco')]),
    ('discovery-disassemble', '60s', ['/opt/rocm/llvm/bin/llvm-objdump', '--disassemble', '--mcpu=gfx942',
      str(OUT / 'kernel.hsaco')]),
    ('discovery-metadata', '60s', ['/opt/rocm/llvm/bin/llvm-readobj', '--notes', '--symbols',
      str(OUT / 'kernel.hsaco')]),
]
for label, bound, command in steps:
    result = subprocess.run(['python3', '-I', '-B', str(HERE / 'capture.py'), label, bound, *command])
    if result.returncode:
        sys.exit(result.returncode)
identities = {path.name: dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
              for path in OUT.iterdir() if path.is_file()}
(OUT / 'identities.json').write_text(json.dumps(identities, sort_keys=True, indent=2) + '\n')
print(json.dumps(identities, sort_keys=True))
