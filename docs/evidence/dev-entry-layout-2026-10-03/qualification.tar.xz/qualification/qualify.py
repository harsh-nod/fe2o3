"""Run final CPU acceptance on the additive HSACO entry-layout change."""
import json
from pathlib import Path
import shlex
import subprocess
import sys

import yaml

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
CARGO = ['cargo', '+nightly-2026-04-03']
PREFIX = sys.argv[1] if len(sys.argv) == 2 else 'final'
assert PREFIX in ('final', 'final2')
steps = [
    ('final-artifacts', '300s', CARGO + ['test', '--locked', '--offline', '-p', 'fe2o3-hsaco', '--no-run', '--message-format=json']),
    ('final-roster', '300s', CARGO + ['test', '--locked', '--offline', '-p', 'fe2o3-hsaco', '--', '--list']),
    ('final-tests', '300s', CARGO + ['test', '--locked', '--offline', '-p', 'fe2o3-hsaco']),
    ('final-clippy', '300s', CARGO + ['clippy', '--locked', '--offline', '-p', 'fe2o3-hsaco', '--all-targets', '--', '-D', 'warnings']),
    ('final-no-default', '300s', CARGO + ['test', '--locked', '--offline', '-p', 'fe2o3-hsaco', '--no-default-features']),
    ('final-consumers', '900s', CARGO + ['check', '--locked', '--offline', '-p', 'fe2o3-verifier', '-p', 'fe2o3-host', '-p', 'fe2o3-hsaco-finalize', '-p', 'fe2o3-amdhsa-loader']),
    ('final-format', '60s', CARGO + ['fmt', '-p', 'fe2o3-hsaco', '--', '--check']),
    ('final-whitespace', '60s', ['git', 'diff', '--check']),
    ('final-clang-version', '30s', ['/opt/rocm/llvm/bin/clang', '--version']),
    ('final-rustc-version', '30s', ['rustc', '+nightly-2026-04-03', '-vV']),
    ('final-tool-identities', '60s', ['sha256sum',
      str(ROOT / 'target/debug/fe2o3-rustc-extract'),
      str(ROOT / 'target/debug/deps/librustc_codegen_fe2o3.so'),
      '/opt/rocm/llvm/bin/clang-22', '/opt/rocm/llvm/bin/llvm-objdump',
      '/opt/rocm/llvm/bin/llvm-readobj']),
]
workflow = yaml.safe_load((ROOT / '.github/workflows/runtime-component-source-guards.yml').read_text())
controls = []
for step in workflow['jobs']['source-controls']['steps']:
    for line in step.get('run', '').strip().splitlines():
        command = shlex.split(line)
        assert command[:3] == ['python3', '-I', '-B']
        controls.append(command)
assert len(controls) == 33
steps += [(f'final-control-{index:02}', '180s', command) for index, command in enumerate(controls)]
results = []
for label, bound, command in steps:
    label = label.replace('final-', PREFIX + '-', 1)
    result = subprocess.run(['python3', '-I', '-B', str(HERE / 'capture.py'), label, bound, *command])
    results.append(dict(label=label, command=command, exit=result.returncode))
    (HERE / f'qualification-commands-{PREFIX}.json').write_text(json.dumps(results, indent=2) + '\n')
    if result.returncode:
        sys.exit(result.returncode)
