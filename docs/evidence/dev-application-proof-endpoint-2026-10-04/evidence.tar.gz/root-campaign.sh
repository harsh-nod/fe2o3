#!/usr/bin/env bash
set -euo pipefail
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/home/harsh/.codex-tmp/fe2o3-proof-endpoint-20261004-0z7hfI4q
binary=$(jq -r 'select(.reason == "compiler-artifact" and .target.name == "fe2o3_broker_authority_service" and .profile.test == true) | .executable // empty' "$scratch/broker-build.jsonl")
test -x "$binary"
sha256sum "$binary"
exec timeout --kill-after=5s 180s \
  /mnt/c/Windows/System32/wsl.exe --user root --exec \
  /usr/bin/bwrap --die-with-parent \
  --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
  --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
  --cap-drop ALL \
  --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
  --cap-add CAP_CHOWN --cap-add CAP_DAC_OVERRIDE \
  --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
  /usr/bin/env \
  LD_LIBRARY_PATH="$root/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib" \
  /bin/sh -c '
    id
    sed -n "/^CapEff:/p; /^NoNewPrivs:/p" /proc/self/status
    exec "$@"
  ' sh "$binary" --exact \
  linux::application_observation::tests::root_application_observation_campaign \
  --ignored --nocapture --test-threads=1
