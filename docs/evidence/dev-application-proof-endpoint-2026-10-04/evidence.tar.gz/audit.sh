#!/usr/bin/env bash
set -euo pipefail
scratch=/home/harsh/.codex-tmp/fe2o3-proof-endpoint-20261004-0z7hfI4q
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
git rev-parse HEAD
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers verify-commit HEAD
git diff --exit-code HEAD -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**'
test -z "$(git ls-files --others --exclude-standard -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**')"
sha256sum --check --quiet "$scratch/source.sha256"
test "$(git diff --binary HEAD^ HEAD | sha256sum | cut -d ' ' -f1)" = "$(sha256sum "$scratch/source.patch" | cut -d ' ' -f1)"
sed -nE 's/^ *Running .*\((target\/[^)]+)\).*/\1/p' \
  "$scratch/protocol-client.log" "$scratch/cargo-unit.log" "$scratch/host-unit.log" \
  "$scratch/broker-unit.log" "$scratch/vertical-final.log" | sort -u | xargs sha256sum > "$scratch/test-binaries.sha256"
sha256sum "$scratch/static-target/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-worker-v3-host-consumer-app-fixture" \
  "$scratch/static-target/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-runner-app-fixture" \
  "$scratch/static-target/x86_64-unknown-linux-gnu/debug/cargo-fe2o3-runner-chain-fixture" > "$scratch/static-binaries.sha256"
printf 'PASS: signed commit, exact source patch, frozen source inventory, test/static binary hashes\n'
