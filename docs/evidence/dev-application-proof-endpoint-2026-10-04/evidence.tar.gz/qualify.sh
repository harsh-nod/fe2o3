#!/usr/bin/env bash
set -euo pipefail
scratch=/home/harsh/.codex-tmp/fe2o3-proof-endpoint-20261004-0z7hfI4q
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
git ls-files --cached --others --exclude-standard -z -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**' | xargs -0 sha256sum > "$scratch/source.sha256"
run() {
    local name=$1
    shift
    printf '%s start %s\n' "$(date -u +%FT%TZ)" "$name"
    timeout --kill-after=15s 1200s bash "$scratch/run.sh" "$@" > "$scratch/$name.log" 2>&1
    printf '%s passed %s\n' "$(date -u +%FT%TZ)" "$name"
}
run protocol-client test --offline --locked -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client
run cargo-unit test --offline --locked -p cargo-fe2o3 --bin cargo-fe2o3 --bin fe2o3-rustc-wrapper --bin fe2o3-engineering-lld-proxy
run host-unit test --offline --locked -p fe2o3-host --lib
run broker-unit test --offline --locked -p fe2o3-broker-authority-service --lib
run host-broker-doc test --offline --locked -p fe2o3-host -p fe2o3-broker-authority-service --doc
export FE2O3_V3_STATIC_FIXTURE_TARGET_DIR="$scratch/static-target"
run vertical-final test --offline --locked -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical strict_v3_ -- --test-threads=1
run clippy clippy --offline --locked -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client -p cargo-fe2o3 -p fe2o3-host -p fe2o3-broker-authority-service --all-targets --no-deps -- -D warnings
run clippy-fixtures clippy --offline --locked -p cargo-fe2o3 --features worker-v3-envelope-integration-test-only --test worker_v3_load_envelope_vertical --bin cargo-fe2o3-runner-app-fixture --bin cargo-fe2o3-worker-v3-host-consumer-app-fixture --no-deps -- -D warnings
run fmt fmt -p fe2o3-runtime-protocol -p fe2o3-compiler-execution-client -p cargo-fe2o3 -p fe2o3-host -- --check
rustfmt --check --edition 2024 crates/fe2o3-broker-authority-service/src/linux/application_observation.rs crates/fe2o3-broker-authority-service/src/linux/application_observation/tests.rs > "$scratch/broker-fmt.log" 2>&1
git diff --check > "$scratch/whitespace.log"
sha256sum --check --quiet "$scratch/source.sha256" > "$scratch/source-check.log"
printf '%s passed all qualification commands\n' "$(date -u +%FT%TZ)"
