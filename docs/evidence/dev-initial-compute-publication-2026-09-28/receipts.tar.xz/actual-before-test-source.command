cat crates/fe2o3-runtime/src/kfd_backend/tests/initial_publication_tests.rs 
