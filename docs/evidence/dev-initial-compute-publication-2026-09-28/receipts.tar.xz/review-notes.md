# Initial Persistent Publication Review

Read-only agents reviewed the native handoff and runtime test oracles. The
primary agent owns all edits, integration and test execution.

- After successful native bind, the prepared receipt is installed in Active
  before queue-registration profiling and before consuming submission.
- The initial and retry paths share the Armed -> NativeOwned -> Armed/Published
  transition. Single-binding lower error formatting now occurs after indexing.
- Returned errors with an Active owner retire the pending FIFO/dependency
  handoff, never settle it as unpublished and never reinsert a duplicate pending
  owner. Unexpected post-index Rejected/Quiescent outcomes become Terminal.
- Panic handling preserves the original payload through terminal poisoning.
- Tests require a completed public scripted H2D dependency so submit cannot
  eagerly publish before fault injection. The compute inputs themselves are
  seeded scripted owners, not real H2D-initialized GPU storage.
- The 24-case matrix covers single/three binding, authenticated-ready/initialized
  storage, terminal submit, consuming unwind, post-publication profile unwind,
  pre-submit observer unwind and inconsistent post-index error classifications.
- Twelve healthy controls cover immediate success, initial retry then success,
  and initial retry then cancellation, including complete scripted cleanup.
- The observer-unwind hook does not execute native queue registration. Source
  ordering establishes that Active precedes the real lane-registration call.
- Existing native bind failure restoration and internal lower-bind unwinding
  are outside this qualification. No GPU execution or formal correspondence is
  established here, and no HIP/HSA performance comparison was run.

The first experimental regression armed a fault after an eager submit and was
invalid. Its failures are retained for transparency, not claimed as a custody
regression. `actual-before-handoff` used the corrected dependency fixture with
the indexed initial publication but the old caller. It failed because the same
submission remained both Active and pending. Its positive controls passed.

Follow-up source review found a concrete remaining bind-recovery issue:
`restore_persistent_compute_input_v1` still uses `Box::new` after a single bind
returns Retryable typed custody (H2D-ready/device/replay origins). Three-binding
and single initialized-storage restoration already use preallocated shells.
The next change should reserve the single-origin shell before extracting input,
reuse the cancellation shell compatibility matrix, and restore returned custody
without allocation. This checkpoint deliberately does not claim that recovery
boundary or allocation-exhaustion behavior as qualified.
