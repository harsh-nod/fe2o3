env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features --lib initial_publication_consumes_through_indexed_transition -- --nocapture 
