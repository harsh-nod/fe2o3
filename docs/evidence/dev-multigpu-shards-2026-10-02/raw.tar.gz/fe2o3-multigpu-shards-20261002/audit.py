#!/usr/bin/env python3
"""Audit immutable current-source checks and exact-ELF historical KFD reuse."""
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'bafbfe73981aa177fc052a4dcc7120c66a34cfb6'
PREFIX = 'fe2o3-multigpu-production-peers-20261002/'
CONTROLLER_SHA = '8d7132ebfe7ac586f18576dac5616dd70f22b60cf138a4e9152624295740c8c6'
SUPPORT_SHA = 'bfa77e8866fc24e6f17440baf2f4b54f69f47cea635e3597a8e24a8137cf4a0b'
CAPTURE_SHA = 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f'
WORKFLOW_SHA = '33c8eb8b3bac347669f15e36aadbc736062a635812a95b908dbaba43ef5fae08'
REFERENCE_INPUTS_SHA = '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e'
IDS = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33', '0x189ca857de1ef2fb',
       '0x54f88318ca05093d', '0xb7baafd0fb173d8e', '0x10a254ce4987e716',
       '0x53691ef168a0147d']
CASES = [('shards-2', IDS[5:]), ('shards-3', IDS[4:]), ('shards-5', IDS[2:]),
         ('shards-7', IDS), ('shards-7-reverse', IDS[::-1])]
SOURCE_PREFIXES = ('.github/', 'benchmarks/', 'crates/', 'examples/', 'scripts/', 'tests/', 'tools/')
EVIDENCE_PREFIXES = (
    'docs/evidence/dev-completion-reconciliation-proof-2026-09-25/',
    'docs/evidence/dev-completion-leaf-outcomes-2026-09-25/',
    'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/',
    'docs/evidence/dev-xgmi-peer-hot-mi300x-2026-09-19/',
    'docs/evidence/dev-monotonic-wait-arithmetic-2026-10-01/',
)
GUARD_NAMES = {
    'check-request-charge.py', 'check-retained-credit-dispatch.py',
    'check-retained-pair-owned-storage.py', 'check-retained-pair-post-catch.py',
    'check-retained-pair-cadence.py', 'check-producer-input-fold.py',
    'check-producer-input-validate.py', 'check-producer-journal-observers.py',
    'check-retained-pair-routing.py', 'check-producer-input-composition.py',
    'check-producer-journal-composition.py', 'test-producer-input-composition.py',
    'producer-journal-composition-mutations-v1.py',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=REPO)


def manifest(raw):
    pairs = []
    for line in raw.decode().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        assert match, line
        pairs.append(match.groups())
    result = {path: digest for digest, path in pairs}
    assert result and len(result) == len(pairs)
    return result


def roster(raw):
    names = re.findall(r'^(.+): test$', raw.decode(), re.M)
    assert names and len(names) == len(set(names))
    return set(names)


def results(raw):
    pairs = re.findall(r'^test (.+) \.\.\. (ok|ignored)(?:,.*)?$', raw.decode(), re.M)
    result = dict(pairs)
    assert pairs and len(result) == len(pairs)
    return result


def test_result(raw, passed, ignored=0, filtered=0):
    output = raw.decode()
    summaries = [line for line in output.splitlines() if line.startswith('test result:')]
    prefix = f'test result: ok. {passed} passed; 0 failed; {ignored} ignored; 0 measured; {filtered} filtered out; finished in '
    assert len(summaries) == 1 and re.fullmatch(re.escape(prefix) + r'[0-9.]+s', summaries[0])
    observed = results(raw)
    assert list(observed.values()).count('ok') == passed
    assert list(observed.values()).count('ignored') == ignored
    assert not re.search(r'^test .+ \.\.\. FAILED', output, re.M)
    return observed, summaries[0]


def read_json(path):
    return json.loads(path.read_bytes())


def stamp(value):
    result = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    assert result.tzinfo is not None
    return result


def check_sources(sources):
    assert sources
    for name, digest in sources.items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        path = REPO / relative
        assert path.is_file() and not path.is_symlink() and path.resolve() == path
        assert sha(path.read_bytes()) == digest, name


def stage_commands(mode, runtime, kfd):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', '-p', 'fe2o3-runtime']
    compute = 'gfx942-runtime-compute-xgmi-smoke'
    production = 'gfx942-runtime-peer-copy-smoke'
    sharded = 'gfx942-runtime-sharded-peer-copy-smoke'
    if mode == 'build':
        return {'runtime': (2400, cargo + ['test', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--no-run', '--message-format=json']),
                'kfd-full-list': (60, [kfd, '--list', '--test-threads=1'])}
    if mode in ('focused', 'tests'):
        filters = ('compute_xgmi', 'drain_capture', 'deferred_compute', 'producer_peers', 'multi_open') if mode == 'focused' else ('compute_xgmi', 'packetized', 'full')
        stages = {}
        for selected in filters:
            name = selected if mode == 'focused' else 'fe2o3_runtime-' + selected
            argv = [runtime] + ([] if selected == 'full' else [selected])
            stages[name + '-list'] = (60, argv + ['--list', '--test-threads=1'])
            stages[name] = (1200 if selected == 'full' else 600, argv + ['--test-threads=1'])
        return stages
    assert mode == 'checks'
    patterns = ('crates/fe2o3-kfd/**/*.rs', 'crates/fe2o3-runtime/**/*.rs')
    changed = sorted(set(git('diff', 'HEAD', '--name-only', '--', *patterns).decode().splitlines()) |
                     set(git('ls-files', '--others', '--exclude-standard', '--', *patterns).decode().splitlines()))
    assert changed
    return {
        'rustc': (60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose']),
        'cargo': (60, cargo + ['--version']), 'uname': (60, ['uname', '-a']),
        'clippy': (1200, cargo + ['clippy', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--tests', '--example', compute, '--example', production, '--example', sharded, '--no-deps', '--', '-D', 'warnings']),
        'no-default': (300, cargo + ['check', *common, '--no-default-features', '--lib', '--example', production, '--example', sharded]),
        'example': (1200, cargo + ['test', *common, '--all-features', '--example', compute, '--', '--test-threads=1']),
        'production-example': (1200, cargo + ['test', *common, '--no-default-features', '--example', production, '--', '--test-threads=1']),
        'sharded-example': (1200, cargo + ['test', *common, '--example', sharded, '--', '--test-threads=1']),
        'witness-build': (1200, cargo + ['build', *common, '--all-features', '--profile', 'test', '--example', compute]),
        'production-witness-build': (1200, cargo + ['build', *common, '--no-default-features', '--profile', 'test', '--example', production]),
        'sharded-witness-build': (1200, cargo + ['build', *common, '--profile', 'test', '--example', sharded]),
        'formatting': (120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *changed]),
        'whitespace': (60, ['git', 'diff', 'HEAD', '--check']),
    }


def audit_cpu(selected, sources, runtime, kfd):
    assert sha((ROOT / 'verify.sh').read_bytes()) == CONTROLLER_SHA
    for mode in ('build', 'focused', 'tests', 'checks'):
        folder = selected / mode
        assert sha((folder / 'controller.sh').read_bytes()) == CONTROLLER_SHA
        assert (folder / 'overall.exit').read_text().strip() == '0'
        assert (folder / 'base.txt').read_text().strip() == BASE
        assert (folder / 'cwd.txt').read_text().strip() == str(REPO)
        environment = dict(line.split('=', 1) for line in (folder / 'environment.txt').read_text().splitlines())
        expected = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', RUST_TEST_THREADS='1', PWD=str(REPO))
        assert all(environment.get(key) == value for key, value in expected.items())
        assert set(environment) <= set(expected) | {'OLDPWD', 'SHLVL', '_'}
        assert manifest((folder / 'source-before.sha256').read_bytes()) == sources
        assert (folder / 'source-before.sha256').read_bytes() == (folder / 'source-after.sha256').read_bytes()
        commands = stage_commands(mode, runtime, kfd)
        assert {path.stem for path in folder.glob('*.exit')} == set(commands) | {'overall'}
        for suffix in ('command', 'started', 'finished', 'stdout', 'stderr'):
            assert {path.stem for path in folder.glob('*.' + suffix)} == set(commands)
        previous = None
        for name, (seconds, argv) in commands.items():
            assert (folder / (name + '.exit')).read_text().strip() == '0'
            assert shlex.split((folder / (name + '.command')).read_text()) == argv
            started = stamp((folder / (name + '.started')).read_text())
            finished = stamp((folder / (name + '.finished')).read_text())
            assert 0 <= (finished - started).total_seconds() <= seconds + 35
            assert previous is None or started >= previous
            previous = finished
    artifacts = [json.loads(line) for line in (selected / 'build/runtime.stdout').read_text().splitlines()]
    assert artifacts[-1].get('reason') == 'build-finished' and artifacts[-1]['success']
    for target, executable in [('fe2o3_runtime', runtime), ('fe2o3_kfd', kfd)]:
        assert Path(executable).parent == REPO / 'target/debug/deps'
        assert re.fullmatch(target + r'-[0-9a-f]+', Path(executable).name)
        emitted = {item['executable'] for item in artifacts if item.get('reason') == 'compiler-artifact'
                   and item.get('target', {}).get('name') == target and item.get('profile', {}).get('test')
                   and item.get('executable')}
        assert emitted == {executable}
        assert manifest((selected / f'build/{target}.sha256').read_bytes()) == {executable: sha(Path(executable).read_bytes())}
    full = roster((selected / 'tests/fe2o3_runtime-full-list.stdout').read_bytes())
    observed, _ = test_result((selected / 'tests/fe2o3_runtime-full.stdout').read_bytes(), 2011, 32)
    assert set(observed) == full
    for name, count in [('example', 9), ('production-example', 3), ('sharded-example', 7)]:
        test_result((selected / f'checks/{name}.stdout').read_bytes(), count)
    for mode, prefix, filters in [('focused', '', ('compute_xgmi', 'drain_capture', 'deferred_compute', 'producer_peers', 'multi_open')),
                                  ('tests', 'fe2o3_runtime-', ('compute_xgmi', 'packetized'))]:
        for name in filters:
            listed = roster((selected / mode / (prefix + name + '-list.stdout')).read_bytes())
            assert listed == {test for test in full if name in test}
            actual, _ = test_result((selected / mode / (prefix + name + '.stdout')).read_bytes(), len(listed), filtered=len(full) - len(listed))
            assert set(actual) == listed
    return full, observed


def selected_metadata_node(tree, selector):
    dictionary = re.fullmatch(r"(CHECKER_PINS|HELPERS)\['([a-z-]+\.py)'\]", selector)
    if dictionary:
        name, key = dictionary.groups()
        owners = [node.value for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
        assert len(owners) == 1 and isinstance(owners[0], ast.Dict)
        nodes = [value for candidate, value in zip(owners[0].keys, owners[0].values)
                 if isinstance(candidate, ast.Constant) and candidate.value == key]
    elif selector == 'len(implementation) == literal':
        nodes = [node.comparators[0] for node in ast.walk(tree)
                 if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq)
                 and isinstance(node.left, ast.Call) and isinstance(node.left.func, ast.Name)
                 and node.left.func.id == 'len' and len(node.left.args) == 1
                 and isinstance(node.left.args[0], ast.Name) and node.left.args[0].id == 'implementation']
    elif selector.startswith('assertEqual('):
        match = re.fullmatch(r'assertEqual\(len\((native|with_schemas)\), literal\)', selector)
        assert match
        variable = match.group(1)
        nodes = [node.args[1] for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == 'assertEqual'
                 and len(node.args) == 2 and isinstance(node.args[0], ast.Call)
                 and isinstance(node.args[0].func, ast.Name) and node.args[0].func.id == 'len'
                 and len(node.args[0].args) == 1 and isinstance(node.args[0].args[0], ast.Name)
                 and node.args[0].args[0].id == variable]
    else:
        nodes = [node.value for node in tree.body if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == selector for target in node.targets)]
    assert len(nodes) == 1 and isinstance(nodes[0], ast.Constant)
    return nodes[0]


def audit_metadata(proposal):
    folder = ROOT / 'source-ci' / proposal
    report = read_json(folder / 'metadata-report.json')
    assert report['baseline'] == BASE
    for flag in ('all_baseline_audits_passed', 'all_proposed_source_audits_passed', 'proof_closures_unchanged',
                 'predicates_contracts_and_proof_counts_unchanged', 'ast_identical_except_listed_metadata_constants'):
        assert report[flag]
    assert not report['solver_executed'] and not report['build_executed'] and not report['formal_qualification']
    counts, changed, patch = {'content-sha256': 0, 'source-inventory-count': 0}, 0, ['*** Begin Patch\n']
    paths = [row['path'] for row in report['changes']]
    assert len(paths) == len(set(paths)) == 13
    assert {Path(path).name for path in paths} == GUARD_NAMES
    for row in report['changes']:
        path = row['path']
        assert Path(path).parent == Path('crates/fe2o3-runtime-model/verus')
        old = (folder / 'originals' / Path(path).name).read_text()
        assert old.encode() == git('show', BASE + ':' + path)
        assert sha(old.encode()) == row['original_sha256']
        tree = ast.parse(old)
        nodes = {(n.lineno, n.col_offset, n.end_lineno, n.end_col_offset): n for n in ast.walk(tree) if isinstance(n, ast.Constant)}
        offsets = [0]
        for line in old.splitlines(keepends=True):
            offsets.append(offsets[-1] + len(line))
        edits = []
        for edit in row['edits']:
            node = nodes[edit['line'], edit['column'], edit['end_line'], edit['end_column']]
            assert node is selected_metadata_node(tree, edit['selector'])
            assert node.value == edit['old']
            category = edit['category']
            counts[category] += 1
            if category == 'content-sha256':
                assert all(isinstance(edit[key], str) and re.fullmatch('[0-9a-f]{64}', edit[key]) for key in ('old', 'new'))
                assert edit['selector'] in {'SOURCE_TREE_SHA', 'RUNTIME_SHA', 'NATIVE_TREE_SHA', 'SCHEMA_TREE_SHA', 'GUARD_SHA'} or re.fullmatch(r"(?:CHECKER_PINS|HELPERS)\['[a-z-]+\.py'\]", edit['selector'])
            else:
                assert category == 'source-inventory-count'
                assert edit['selector'] in {'SOURCE_FILES', 'RUNTIME_FILES', 'len(implementation) == literal', 'assertEqual(len(native), literal)', 'assertEqual(len(with_schemas), literal)'}
                assert type(edit['old']) is type(edit['new']) is int and edit['new'] > 0
            start = offsets[edit['line'] - 1] + edit['column']
            end = offsets[edit['end_line'] - 1] + edit['end_column']
            assert ast.literal_eval(old[start:end]) == edit['old']
            edits.append((start, end, json.dumps(edit['new'])))
            node.value = edit['new']
        new = old
        for start, end, value in sorted(edits, reverse=True):
            new = new[:start] + value + new[end:]
        assert ast.dump(tree) == ast.dump(ast.parse(new))
        assert sha(new.encode()) == row['proposed_sha256']
        assert (REPO / path).read_bytes() == new.encode()
        if old != new:
            changed += 1
            patch.append('*** Update File: ' + str(REPO / path) + '\n')
            patch.extend(list(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True)))[2:])
    assert ''.join(patch) + '*** End Patch\n' == (folder / 'metadata.patch').read_text()
    assert changed == 9 and counts == {'content-sha256': 16, 'source-inventory-count': 7}
    assert len(report['proof_files']) == 76 and len(report['audited_source_sha256']) == 1027
    assert report['runtime_source_files'] == 346 and report['runtime_and_schema_files'] == 351
    assert len(list((REPO / 'crates/fe2o3-runtime/src').rglob('*.rs'))) == 346
    check_sources(report['proof_files'])
    check_sources(report['audited_source_sha256'])
    return report


def audit_workflow(workflow, proposal, report):
    folder = ROOT / 'source-ci' / workflow
    data, inputs = read_json(folder / 'result.json'), read_json(folder / 'inputs.json')
    assert data['accepted'] and data['command_count'] == 32 and data['source_unchanged'] and not data['failed']
    assert not data['solver_invocations'] and not data['build_invocations'] and not data['gpu_invocations']
    assert inputs['head'] == BASE and inputs['workflow_sha256'] == WORKFLOW_SHA
    assert sha((REPO / '.github/workflows/runtime-component-source-guards.yml').read_bytes()) == WORKFLOW_SHA
    reference = ROOT / 'source-ci/reference/inputs.json'
    assert sha(reference.read_bytes()) == REFERENCE_INPUTS_SHA
    assert inputs['commands'] == read_json(reference)['commands']
    assert inputs['source_sha256'] == read_json(folder / 'closing-source.json')
    tracked = git('ls-files', '--cached', '-z').decode().split('\0')
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    names = {name for name in tracked if name and ('/' not in name or name.startswith(SOURCE_PREFIXES + EVIDENCE_PREFIXES))}
    names |= {name for name in untracked if name.endswith('.rs') and name.startswith(SOURCE_PREFIXES)}
    assert set(inputs['source_sha256']) == names
    assert data['source_files'] == len(names)
    check_sources(inputs['source_sha256'])
    assert all(inputs['source_sha256'].get(path) == digest for path, digest in report['audited_source_sha256'].items())
    assert inputs['environment'] == dict(PATH='/usr/bin:/bin', HOME=str(folder / 'home'), TMPDIR=str(folder / 'tmp'), LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_OPTIONAL_LOCKS='0')
    assert len(inputs['commands']) == len(data['commands']) == 32
    previous = None
    for index, (command, record) in enumerate(zip(inputs['commands'], data['commands']), 1):
        stage = folder / f'{index:02}'
        assert record == read_json(stage / 'receipt.json')
        assert [record['step'], record['literal'], record['argv']] == command
        assert record['argv'] == shlex.split(record['literal']) and record['cwd'] == str(REPO)
        assert record['exit'] == 0 and not record['timed_out'] and record['group_absent']
        assert 0 < record['timeout_seconds'] <= 120
        assert 0 <= (record['finished_ns'] - record['started_ns']) / 1e9 <= record['timeout_seconds'] + 10
        assert previous is None or record['started_ns'] >= previous
        previous = record['finished_ns']
        assert sha((stage / 'stdout').read_bytes()) == record['stdout_sha256']
        assert sha((stage / 'stderr').read_bytes()) == record['stderr_sha256']
    support = read_json(folder / 'reused-support.json')
    assert support['metadata_proposal'] == proposal and support['workflow_exit'] == 0 and support['workflow_accepted']
    assert not support['metadata_patch_applied_by_this_support']
    assert sha((ROOT / 'source-ci/support.py').read_bytes()) == SUPPORT_SHA


def receipt(folder):
    data = json.loads((folder / 'result.json').read_bytes())
    assert data['exit_code'] == 0 and not data['timed_out']
    assert data['local_process_group_absent']
    assert data['stdout_sha256'] == sha((folder / 'stdout').read_bytes())
    assert data['stderr_sha256'] == sha((folder / 'stderr').read_bytes())
    assert 0 <= data['elapsed_seconds'] <= 245
    assert stamp(data['finished']) >= stamp(data['started'])
    return data


def ring_digests():
    first, second = hashlib.sha256(), hashlib.sha256()
    translate = bytes(value ^ 73 for value in range(256))
    mask = (1 << 64) - 1
    for start in range(0, 67108901, 8192):
        block = bytearray()
        for offset in range(start, min(start + 8192, 67108901)):
            value = (offset + 0x9e3779b97f4a7c15) & mask
            value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
            value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
            block.append((value ^ (value >> 31)) & 255)
        first.update(block)
        second.update(block.translate(translate))
    assert first.digest() != second.digest()
    return first.hexdigest() + ',' + second.hexdigest()


def hardware_expected(ids, digests):
    count = len(ids)
    quotient, remainder = divmod(67108901, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    assert sum(sizes) == 67108901 and min(sizes) < max(sizes)
    return dict(schema='fe2o3.sharded-peer-copy-smoke.v1', authority='production-deny-all',
        transport='NATIVE-XGMI', devices=str(count), unique_ids=','.join(ids), rounds='2',
        total_bytes_per_round='67108901', total_copied_bytes='134217802',
        shard_ranges=','.join(f'{offset}:{size}' for offset, size in zip(offsets, sizes)),
        peer_copies=str(2 * count), observed_native_copies=str(2 * count),
        native_packets=str(2 * sum((size + 4194271) // 4194272 for size in sizes)),
        allocations=str(4 * count), streams=str(count), launches='0', readbacks=str(8 * count),
        submission='all-enqueued-before-drive', source_unchanged='full-byte-pass',
        destination_sentinel='full-byte-pass', output='full-byte-pass',
        coverage='exact-contiguous-disjoint', round_sha256=digests, rounds_changed='true',
        allocation_reuse='true', drain='completed-group-only', pending_group_drain='false',
        physical_overlap='unmeasured', cleanup='logical-and-native-explicit',
        performance_acceptance='false', formal_refinement='false')


def audit_hardware(hw, selected):
    data = read_json(hw / 'campaign.json')
    assert data['accepted'] and data['owned_cleanup_complete'] and not data['errors']
    assert not data['performance_acceptance'] and not data['formal_refinement'] and not data['exclusive_reservation']
    assert len(data['completed']) == data['expected_cases'] == 5
    assert [item['name'] for item in data['completed']] == [name for name, _ in CASES]
    assert sha((hw / 'capture.py').read_bytes()) == CAPTURE_SHA
    directory = data['owned_directory']
    assert re.fullmatch(r'/tmp/fe2o3-multigpu-shards-20261002-[A-Za-z0-9]{6}', directory)
    assert set(data['binaries']) == {'sharded'}
    binary = data['binaries']['sharded']
    path = 'target/debug/examples/gfx942-runtime-sharded-peer-copy-smoke'
    assert binary['local'] == str(REPO / path) and binary['remote'] == directory + '/sharded-witness'
    assert manifest((selected / 'checks/sharded-witness.sha256').read_bytes()) == {path: binary['sha256']}
    assert sha((REPO / path).read_bytes()) == binary['sha256']
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
    receipts, previous = {}, None

    def capture(name, argv, bound='30s', local=False):
        nonlocal previous
        folder = hw / name
        record = receipt(folder)
        expected = argv if local else ssh + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]
        assert record['argv'] == expected, name
        assert previous is None or stamp(record['started']) >= previous, name
        previous = stamp(record['finished'])
        receipts[name] = sha((folder / 'result.json').read_bytes())
        return (folder / 'stdout').read_text()

    availability = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']
    baseline = json.loads(capture('initial-availability', availability))

    def admission(name):
        state = json.loads(capture(name + '-availability', availability))
        buses = ['0000:26:00.0', '0000:46:00.0', '0000:65:00.0', '0000:85:00.0',
                 '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
        for index, (uid, bus) in enumerate(zip(IDS, buses), 1):
            card = 'card' + str(index)
            assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bus
            assert state[card]['GPU use (%)'] == '0'
            assert state[card]['VRAM Total Used Memory (B)'] == baseline[card]['VRAM Total Used Memory (B)']
        assert state['system'] == baseline['system']
        mapping = capture(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        pids = {}
        for item in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = item.groups()
            devices = [] if devices is None else devices.split()
            assert pid not in pids and int(count) == len(devices) == len(set(devices))
            assert bool(colon) == bool(devices)
            assert not {str(index) for index in range(1, 8)}.intersection(devices)
            pids[pid] = devices
        assert {'PID' + pid for pid in pids} == set(state['system'])
        assert all(int(state['system']['PID' + pid].split(',')[1]) == len(devices) for pid, devices in pids.items())
        memory = capture(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024

    admission('baseline')
    assert capture('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-shards-20261002-XXXXXX']).strip() == directory
    capture('upload-sharded', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']], local=True)
    assert capture('initial-hash-sharded', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    digests = ring_digests()
    for reported, (name, ids) in zip(data['completed'], CASES):
        admission(name)
        argv = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-u', 'HIP_VISIBLE_DEVICES',
                '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES', '-u', 'GPU_DEVICE_ORDINAL', binary['remote'], *ids]
        lines = capture(name, argv, '180s').splitlines()
        assert len(lines) == 1 and lines[0].startswith('PASS ')
        pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
        assert all(len(pair) == 2 and all(pair) for pair in pairs)
        fields = dict(pairs)
        assert len(fields) == len(pairs) and fields == reported['fields'] == hardware_expected(ids, digests)
        assert not (hw / name / 'stderr').read_bytes()
    paths = [binary['remote']]
    probe = ('import json,os,sys; from pathlib import Path; '
        'paths=set(sys.argv[1:]); found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    assert json.loads(capture('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])) == {'owned_executable_pids': []}
    assert capture('final-hash-sharded', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    assert not capture('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    assert not capture('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    assert not capture('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    admission('final')
    assert {path.name for path in hw.iterdir() if path.is_dir()} == set(receipts)
    return data, receipts


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    attempt, proposal, workflow, hardware = sys.argv[1:]
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert re.fullmatch(r'proposal-[0-9]+', proposal)
    assert re.fullmatch(r'attempt-[0-9]+-after', workflow)
    assert re.fullmatch(r'hardware-[a-z0-9-]+', hardware)
    assert not (ROOT / 'qualification.json').exists()
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    selected = ROOT / attempt
    snapshot = (selected / 'build/source-before.sha256').read_bytes()
    current = manifest(snapshot)
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
                'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo')
    assert set(current) == {name.decode() for name in names.split(b'\0') if name}
    check_sources(current)
    runtime_path = Path((selected / 'build/fe2o3_runtime.path').read_text().strip())
    kfd_path = Path((selected / 'build/fe2o3_kfd.path').read_text().strip())
    runtime_roster, runtime_results = audit_cpu(selected, current, str(runtime_path), str(kfd_path))
    runtime_hash = sha(runtime_path.read_bytes())
    for phase in ('before', 'after'):
        assert manifest((selected / f'tests/fe2o3_runtime-{phase}.sha256').read_bytes()) == {str(runtime_path): runtime_hash}
    metadata = audit_metadata(proposal)
    audit_workflow(workflow, proposal, metadata)

    packet = 'docs/evidence/dev-multigpu-production-peers-2026-10-02/'
    archive_pins = manifest(git('show', BASE + ':' + packet + 'SHA256SUMS'))
    expected_archive = archive_pins['raw.tar.gz']
    archive_path = REPO / packet / 'raw.tar.gz'
    assert sha(archive_path.read_bytes()) == expected_archive
    authenticated = {}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        assert len({member.name for member in members}) == len(members)
        def prior(path):
            member = archive.getmember(PREFIX + path)
            assert member.isfile() and not member.issym() and not member.islnk()
            raw = archive.extractfile(member).read()
            authenticated[path] = sha(raw)
            return raw
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted']
        assert qualification['accepted_build_attempt'] == 'attempt-08'
        assert qualification['kfd']['passed'] == 1925 and qualification['kfd']['failed'] == qualification['kfd']['ignored'] == 0
        assert qualification['kfd']['disjoint_roster_coverage'] and qualification['kfd']['fresh_full_run']
        old_runtime, _ = test_result(prior('attempt-08/tests/fe2o3_runtime-full.stdout'), 2001, 32)
        assert set(old_runtime) < runtime_roster
        added = runtime_roster - set(old_runtime)
        assert len(added) == 10
        assert all(name.startswith(('kfd_backend::compute_xgmi::tests::sharded::',
                                   'kfd_backend::drain_capture::multi::tests::')) for name in added)
        assert {name for name, state in old_runtime.items() if state == 'ignored'} == {
            name for name, state in runtime_results.items() if state == 'ignored'}
        old_source_raw = prior('attempt-08/build/source-before.sha256')
        assert sha(old_source_raw) == qualification['source_snapshot_sha256']
        assert old_source_raw == prior('attempt-08/build/source-after.sha256')
        old_sources = manifest(old_source_raw)
        kfd_sources = {name: digest for name, digest in old_sources.items() if name.startswith('crates/fe2o3-kfd/')}
        assert kfd_sources == {name: digest for name, digest in current.items() if name.startswith('crates/fe2o3-kfd/')}
        assert kfd_sources
        kfd_hash = sha(kfd_path.read_bytes())
        assert kfd_hash == qualification['kfd']['exact_executable_sha256']
        old_executable = prior('attempt-08/build/fe2o3_kfd.path').decode().strip()
        assert manifest(prior('attempt-08/build/fe2o3_kfd.sha256')) == {old_executable: kfd_hash}
        kfd_roster = roster((selected / 'build/kfd-full-list.stdout').read_bytes())
        old_roster_raw = prior('attempt-08/build/kfd-full-list.stdout')
        assert kfd_roster == roster(old_roster_raw)
        assert prior('attempt-08/build/kfd-full-list.exit').decode().strip() == '0'
        assert metadata['proof_files'] == json.loads(prior('source-ci/proposal-04/metadata-report.json'))['proof_files']
        prior_shards = qualification['kfd']['shards']
        assert [part['mode'] for part in prior_shards] == ['0', '1', '2', '3', 'rest']
        heavy = sorted(name for name in kfd_roster if name.startswith('queue::live::construction_primary::'))
        union = set()
        for part in prior_shards:
            shard = part['mode']
            directory = 'kfd-shard-' + shard + '/'
            raw = prior(directory + 'result.json')
            assert sha(raw) == part['result_sha256']
            data = json.loads(raw)
            inputs = json.loads(prior(directory + 'inputs.json'))
            stdout = prior(directory + 'run.stdout')
            assert data['accepted'] and data['exit_code'] == 0 and not data['timed_out']
            assert data['executable_unchanged'] and data['group_absent']
            assert 0 <= data['elapsed_seconds'] <= 1235 and stamp(data['finished']) >= stamp(data['started'])
            assert data['stdout_sha256'] == sha(stdout)
            assert data['stderr_sha256'] == sha(prior(directory + 'run.stderr'))
            expected = sorted(kfd_roster - set(heavy)) if shard == 'rest' else heavy[int(shard)::4]
            assert inputs['selected'] == expected and len(expected) == part['passed']
            assert roster(prior(directory + 'list.stdout')) == set(expected)
            assert inputs['executable_sha256'] == kfd_hash and inputs['cwd'] == str(REPO)
            assert inputs['argv'] == [old_executable, '--test-threads=1', '--exact', *expected]
            assert inputs['environment'] == dict(HOME='/home/harsh', PATH='/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', RUST_TEST_THREADS='1')
            assert inputs['controller_sha256'] == sha(prior('kfd_shard.py'))
            assert inputs['source_manifest_sha256'] == sha(old_source_raw)
            assert inputs['full_roster_sha256'] == sha(old_roster_raw) and inputs['total_roster'] == 1925
            passed, summary = test_result(stdout, len(expected), filtered=1925 - len(expected))
            assert data['summary'] == [summary] and set(passed) == set(expected)
            assert set(passed.values()) == {'ok'} and not union.intersection(passed)
            assert not prior(directory + 'run.stderr') and not prior(directory + 'list.stderr')
            union.update(passed)
        assert union == kfd_roster and len(union) == 1925

    data, hardware_receipts = audit_hardware(ROOT / hardware, selected)
    binary = data['binaries']['sharded']
    check_sources(current)
    assert sha(runtime_path.read_bytes()) == runtime_hash and sha(kfd_path.read_bytes()) == kfd_hash
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'source-ci/support.py'),
                    'verify', '--source-frozen', '--proposal', proposal, '--label', 'final-qualification'], check=True)

    result = dict(accepted=True, audited_at=datetime.now(timezone.utc).isoformat(), baseline=BASE,
        attempt=attempt, source_proposal=proposal, source_workflow=workflow, hardware=hardware,
        controller_sha256=CONTROLLER_SHA, source_snapshot_sha256=sha(snapshot), source_files=len(current),
        runtime=dict(passed=2011, ignored=32, failed=0, exact_roster=True, executable_sha256=runtime_hash),
        added_tests=sorted(added), kfd=dict(passed=1925, fresh_run=False, exact_elf_reuse=True,
            executable_sha256=kfd_hash, unchanged_source_files=len(kfd_sources), archive_sha256=expected_archive),
        source_controls=32, strict_clippy=True, no_default_check=True,
        examples=dict(compute=9, production_no_default=3, sharded=7),
        hardware_cases=5, hardware_device_counts=[2,3,5,7,7], owned_cleanup_complete=True,
        hardware_receipt_sha256=hardware_receipts, prior_archive_member_sha256=authenticated,
        sharded_executable_sha256=binary['sha256'], performance_acceptance=False,
        formal_refinement=False, pending_group_drain=False, capture_hardware_qualified=False)
    with (ROOT / 'qualification.json').open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
