# Next Gate: Pending Peer Copies Through Readback and Group Capture

Read-only decomposition against the sharded working tree based on `bafbfe739`.
This is a proposed next checkpoint, not implemented behavior or additional
qualification of the current sharded witness. No repository source was changed
for this note. Line references describe the inspected tree and may move.

## Smallest Backend Change

Reuse `CooperativeCopySubmissionV1`; do not introduce another scheduler,
`DeferredCopy` submission variant, or lower KFD queue primitive merely to wait
for the peer producer.

In `kfd_backend.rs`, `RuntimeAsyncCopyBackendV1::copy_async_v1` around line 13260
currently rejects a live same-device copy when the child is occupied, its stream
has pending cooperative work, or either allocation is retained by the router.
Add a narrow, authenticated admission branch before those rejection checks:

- The request is same-child DeviceLocal `Read` to HostVisible `Write`, with
  distinct allocations, equal positive lengths, checked offsets and bounds.
- An explicit dependency event resolves to an exact retained ordinary
  `CooperativeCopy` submission with a `compute_xgmi` root. Do not substitute a
  stream tail, a directed-copy identity, or a merely same-device event.
- The event child, producer destination child, readback stream child, and
  readback allocations' routes agree. The producer destination is the exact
  readback source allocation and covers the entire requested read span.
- Authenticate against the retained producer's immutable routes and regions,
  plus current global allocation routes. Do not require owner bytes to be in
  their normal child slots while the peer root legitimately holds them.
- Preserve existing duplicate-dependency, ordering, depth, allocation-retain,
  native-custody and capacity checks. Unsupported profiles retain their old
  behavior. A completed producer can use today's ordinary direct path when
  that path is available; the new case is pending-parent admission.

For that case, call existing `submit_cooperative_copy(..., false)`. Its admission
around line 8966 already reserves the routed submission, endpoint retains,
producer-result retains, stream tail, full staging bytes and bounded scratch.
Explicit parent dependencies permit the ordered endpoint overlap without
acquiring a child allocation owner before the parent can finish.

Existing progress around lines 8650-8948 descends the retained producer,
requires successful dependencies, and does not enter a child occupied by a
compute-XGMI transfer. The peer producer cannot report success until its queue
is retired and both original owners are restored. The readback then reuses
`cooperative_sdma.rs::progress_leaf_v1` around line 220: native DeviceLocal-to-host
scratch DMA, real scratch readback, then coherent write into the requested
HostVisible destination. Existing leaf retirement and scratch cleanup remain
authoritative.

This is a **cooperative staged readback continuation**, not zero-staging direct
D2H. It reserves a full host staging extent plus bounded scratch. It does not
increment the compute-XGMI logical-copy counter. If avoiding that staging is a
later requirement, a separate exact-child-copy handoff is warranted; it is not
necessary to close the first pending-group output-verification gate.

Poll/wait must remain observation-only. Flush/drain own progress. Cancellation
of an unstarted readback releases only its own retains and does not cancel its
producer. Published leaf custody follows existing TooLate/retirement rules.
Terminal errors or unwind preserve all original roots and stop further issue.

## Context Journal Boundary

Backend changes alone do not support journal-enabled pending inputs.

`context.rs::submit_prepared_copy_v1` around line 3523 currently calls
`submit_context_operation_v1` with `custody = None`. In
`context/versions/submissions.rs` around line 747 this selects ordinary reader
admission. `versions/readers.rs::prepare_submission_readers_v1` around line 109
rejects a pending source writer as `ContextReserved`, before backend entry.
That rejection must not be weakened.

The smallest first implementation may explicitly retain that rejection and
support the existing non-journal `Context::open` profile used by the sharded
witness. Backend-owned exact producer and allocation retention still applies.
Such a checkpoint must state that journal-aware pending D2H remains unsupported.

For journal-complete support, add an internal same-device producer-copy custody
profile, not a new public orchestration API:

1. Preserve exact source/destination records and the canonical event/submission
   roster using `prepare_dependency_roster_v1` and the existing scalar producer
   identity/range checks. Retain the Context producer independently of public
   event release before journal or backend effects.
2. Reuse the existing model producer-read lease for the actual pending writer,
   binding allocation identity, attempt epoch, content lineage and exact writer
   reference. Extend the Context adapter's explicit consumer-kind validation in
   `versions/producer_readers.rs`; do not permit every ordinary read to name an
   arbitrary pending writer.
3. Do not put same-device copies into `ScalarPeerCopyRootV1`: its validation in
   `peer_custody.rs` around line 175 deliberately requires different devices.
   Do not set a directed flag or reuse a compute-launch identity to bypass it.
4. Integrate the new internal copy profile with submission input checks,
   dependency release, cancellation, rejection refunds and terminal quarantine.
   Reconcile the exact ordinary peer parent's Context observation before
   publishing the dependent copy's logical success. Backend success alone must
   not leave the source writer logically pending while its consumer commits.
   Existing ordinary-leaf reconciliation provides a reusable pattern, not an
   automatic proof of the new adapter.

Likely Context boundaries are `context.rs`, a small copy-custody module,
`context/versions/{producer_readers,submissions}.rs`, and the existing completion
reconciliation adapter's operation-kind accessors. Existing model/body predicates
should be reused where their contracts apply, not edited to erase a failed check.
This is materially larger than the backend-only opt-in and should be selected
explicitly rather than appearing as an incidental guard relaxation.

## Composition With the Cutoff

For pending-peer qualification, prepare incoming HostVisible buffers and their
capture source tokens before moving Context into the current-thread owner.
Before cutoff, enqueue one owner command which admits all peer submissions,
records their exact events, then admits the dependent D2H operations and releases
the public events. All peer roots must be admitted before progress begins.
This uses existing Context/owner APIs; an ordinary `peer_copy_with_event` async
convenience method is not required just for the witness.

Then install drain-with-multi-range-capture before the first drive. The accepted
prefix contains all transfers, so no external future needs to enqueue D2H after
admission closes. The owner drives the existing copy state machines; only after
complete Context and backend quiescence may capture read the retained native
HostVisible tokens through the new multi-backend forwarding hook.

For the minimal ring gate, capture all **incoming destination shards**, proving
full global output coverage. Do not also claim post-copy source preservation
without capturing or otherwise checking those device sources. A source-side
D2H depends on a peer event located on another child; existing same-device
`copy_async` dependency-device rules do not admit that control dependency.
Do not silently relax them merely to obtain a source readback in this witness.

Bounded multi-range capture is still a separate missing production piece:

- `drain_capture_storage.rs` caps reply bytes at 64 MiB and has one accounting
  record. The fixed payload is 64 MiB+37, so even destination-only full coverage
  exceeds the current limit. Source plus destination coverage would require
  128 MiB+74.
- Prefer a bounded ordered roster of existing source tokens and one caller-owned
  concatenated destination. Check the range count, checked sum and exact total
  destination length before cutoff; reserve one aggregate byte credit and all
  metadata first. This preserves the current one-record accounting structure.
- Choose and document an explicit aggregate bound; do not silently allocate
  multiple reservation records or split the drain after cutoff.
- Revalidate each source after quiescence, forward through the sealed existing
  backend request, and expose a complete result only if every required range
  succeeds. Terminal/unwind stops further capture and preserves uncertainty.
- Check the drain report and individual operation results, not only captured
  bytes: quiescence can include failed work. Changed round patterns and sentinels
  remain necessary to reject stale or partial output.

No post-drain raw Context readback, privileged capture token, implicit GPU wait,
or external after-cutoff command is needed or acceptable as a substitute.

## Focused Test Matrix

- Actual public Context peer -> same-device readback admission before peer
  publication and while peer owners are rooted; exact routes, ranges and parent
  IDs retained. Parent remains native; readback adds no early child custody.
- Missing, duplicate, foreign, wrong-child, wrong-producer and released events;
  stale allocation identity; zero/overflow/out-of-bounds or uncovered spans;
  unsupported memory/access profiles. Reject before effects and refund exactly.
- Release public events and attempt producer/endpoint release or mutation after
  admission. Exact dependency and endpoint retains must survive independently.
- Drive only the readback stream. Repeated Pending, packet-boundary resumption,
  expired/resumed deadlines and shared-child ring ordering must progress the
  producer and then the native D2H leaf without deadlock or staging the peer.
- Producer cancellation/failure/quiescent diagnostic/terminal/unwind; readback
  cancellation before issue; leaf submit/poll/retire and scratch-cleanup failures.
  No false success, no premature native owner release and no producer cancellation
  caused by cancelling only its dependent readback.
- Submission/dependency/depth and aggregate staging/scratch limits, retain-count
  overflow and allocation failure. No partially admitted roots or leaked credits.
- Real coherent host storage versus stale Arc shadow at capture. Completed
  retained results/events are permitted; any child's pending or uncertain native
  custody prevents all capture without progressing it.
- Multi-range exact aggregate accounting, caller-storage return on rejection,
  foreign/released source, zero/count/sum limits, partial-reader failure, unwind,
  dropped result/future and byte credit retained through result lifetime.
- If journal support is included: exact pending writer/epoch/lineage, ordinary
  parent reconciliation before consumer success, event release, cancellation,
  failed/unknown writer outcomes and legitimate completed-producer reuse. If not,
  keep an explicit regression proving journal admission remains rejected.

CPU tests should compose the existing router, native-leaf seam, Context and
current-thread owner. Synthetic DMA completion is not hardware byte evidence.
Hardware acceptance should begin drain with the peer/readback prefix outstanding,
verify every captured destination byte in global order, require exact logical
native peer counts and explicit owned cleanup, and retain fresh per-device
admission/occupancy receipts. This remains correctness qualification, not
physical-overlap, performance, full kernel-authority or whole-adapter refinement.
