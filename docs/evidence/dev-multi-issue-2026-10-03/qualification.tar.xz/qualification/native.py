"""Bounded two-GPU issue/readback lifecycle witness using the reviewed process controller."""
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
from types import ModuleType

HERE = Path(__file__).resolve().parent
SHARED = 'd586fd438e6bb4c399b9dc73bfea3475365c33cd3802defa186e10e81f859f65'


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode
    raw = (HERE / 'selected_pair_smoke.py').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SHARED
    shared = ModuleType('selected_pair_smoke')
    shared.__file__ = str(HERE / 'selected_pair_smoke.py')
    exec(compile(raw, shared.__file__, 'exec'), shared.__dict__)
    base_env = dict(shared.ENV)
    binary_text, digest, first, second = sys.argv[1:]
    binary = Path(binary_text)
    assert binary.resolve(strict=True) == binary
    assert binary.name == 'fe2o3-runtime-multi-issue-tests'
    pair = shared.endpoints([first, second])
    helper = shared.load_observer()
    output = HERE / 'native-results'
    output.mkdir()
    recorder = shared.Recorder(output)
    for number in shared.MANAGED:
        signal.signal(number, shared.interrupted)
    fd = os.open(binary, os.O_RDONLY | os.O_NOFOLLOW)
    result = dict(accepted=False, devices=pair, cases=[], started=shared.stamp())
    try:
        identity = shared.fingerprint(fd)
        assert identity['sha256'] == digest
        result['binary_identity'] = identity
        for name, selected in [('forward', pair), ('reverse', tuple(reversed(pair)))]:
            shared.observe_pair(recorder, helper, pair, Path('/opt/rocm/bin/rocm-smi'), name + '-before')
            assert shared.fingerprint(fd) == identity
            try:
                shared.ENV = dict(base_env, FE2O3_TEST_NATIVE_ISOLATED='1',
                                  FE2O3_TEST_NATIVE_UNIQUE_IDS=','.join(row[2] for row in selected),
                                  RUST_TEST_THREADS='1')
                test = ('kfd_backend::generated_adoption::tests::native::multi::'
                        'issue::generated_native_multi_issue_readback_retire_and_rebind')
                receipt = recorder.run(name, [str(binary), '--ignored', '--exact', test, '--nocapture'], 180,
                                       executable=f'/proc/self/fd/{fd}', pass_fds=(fd,))
                assert receipt['exit'] == 0 and receipt['error'] is None and receipt['group_absent'] is True
                actual = (output / name / 'stdout').read_text()
                assert 'running 1 test\n' in actual
                assert f'test {test} ... ok\n' in actual
                assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in actual
                expected = ('MULTI ISSUE PASS: two exact devices, 3 dispatches, full-roster readback, independent retirement, '
                            'primary rebound, 12 DATA releases, shutdown complete\n')
                assert (output / name / 'stderr').read_text() == expected
                assert shared.fingerprint(fd) == identity
                metadata = binary.stat()
                assert (metadata.st_dev, metadata.st_ino) == (identity['device'], identity['inode'])
            finally:
                shared.ENV = base_env
                shared.observe_pair(recorder, helper, pair, Path('/opt/rocm/bin/rocm-smi'), name + '-after')
            result['cases'].append(dict(name=name, accepted=True, expected=expected))
        result['accepted'] = True
    finally:
        os.close(fd)
        result.update(commands=recorder.commands, finished=shared.stamp())
        shared.save(output / 'result.json', result)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()

