#!/usr/bin/env bash
# Read-only deployment prerequisites; no GPU opens or remote files.
set -u
date -u '+%Y-%m-%dT%H:%M:%SZ'
uname -r
id
if sudo -n true; then
  printf 'noninteractive-root=available\n'
else
  printf 'noninteractive-root=unavailable\n'
fi
for path in /usr/libexec/fe2o3 /etc/fe2o3 /run/fe2o3 \
  /usr/libexec/gcc /usr/bin/bwrap /usr/bin/setpriv /usr/bin/dpkg-deb \
  /usr/bin/timeout /usr/bin/jq /sys/fs/cgroup/cgroup.controllers \
  /usr/lib/x86_64-linux-gnu/libstdc++.so.6.0.33 \
  /usr/lib/x86_64-linux-gnu/libzstd.so.1.5.5 \
  /usr/lib/x86_64-linux-gnu/libcap-ng.so.0.0.0 \
  /usr/lib/x86_64-linux-gnu/libgcc_s.so.1; do
  if test -e "$path"; then
    printf 'present: %s\n' "$path"
  else
    printf 'absent: %s\n' "$path"
  fi
done
ls -l /dev/kfd /dev/dri/renderD128
