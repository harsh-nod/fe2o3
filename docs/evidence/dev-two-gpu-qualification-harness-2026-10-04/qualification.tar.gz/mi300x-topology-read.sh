#!/usr/bin/env bash
set -eu
for path in /sys/class/kfd/kfd/topology/nodes/*/properties; do
  awk -v path="$path" '$1 == "unique_id" || $1 == "drm_render_minor" || $1 == "location_id" || $1 == "simd_count" { printf "%s %s=%s\n", path, $1, $2 }' "$path"
done
