#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-refinement-20261003-SBbxgJWA
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly archive="$repo/docs/evidence/dev-fill-refinement-2026-10-03/qualification.tar.gz"
test "$(<"$scratch/protected.status")" = 0
test "$(<"$scratch/checks.status")" = 0
cd "$repo"
git diff --binary -- crates/fe2o3-functional-proof crates/fe2o3-verifier \
    crates/fe2o3-kernel-analysis/verus/gfx942_fill_wave_v1.rs > "$scratch/candidate.patch"
cd "$scratch"
tar -czf "$archive" -- \
    candidate.patch package-evidence.sh build-native.sh prepare-runtime.sh \
    isolated-runtime.sh run-protected.sh run-checks.sh check-format.sh test.sh \
    configure.log build.log build.status worker-tests.log worker-source.tar.gz \
    worker.sha256 worker-ldd.txt native/qualified-final/audit-1/finalized.hsaco \
    verifier.log import.log ownership.log host.log clippy.log formatting.log \
    whitespace.log checks.status review.txt prepare.log tests.log test.status \
    shared-dispatch.log generated.rs protected-first.log protected.log \
    protected.status protected-first protected-1 development*.log
sha256sum candidate.patch "$archive"
tar -tzf "$archive" | wc -l
tar -xOzf "$archive" candidate.patch | sha256sum
