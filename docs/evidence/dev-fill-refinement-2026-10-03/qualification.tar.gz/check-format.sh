#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
files=()
while IFS= read -r path; do
    case "$path" in
        */verus/*|*/conditional_fill_refinement_v1/proof.rs) ;;
        *.rs) files+=("$path") ;;
    esac
done < <(git diff --name-only -- crates)
rustfmt +nightly-2026-04-03 --edition 2024 --config skip_children=true --check "${files[@]}"
