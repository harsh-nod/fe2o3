// Shared executable bodies; annotation slots contain proof-only loop invariants.
macro_rules! gfx942_fill_pair_body_v1 {
    ($low:expr, $high:expr) => {
        ($low as u64) | (($high as u64) << 32)
    };
}

macro_rules! gfx942_fill_decode_body_v1 {
    ($bytes:ident) => {{
        [
            word($bytes[0], $bytes[1], $bytes[2], $bytes[3]),
            word($bytes[4], $bytes[5], $bytes[6], $bytes[7]),
            word($bytes[8], $bytes[9], $bytes[10], $bytes[11]),
            word($bytes[12], $bytes[13], $bytes[14], $bytes[15]),
        ]
    }};
}

macro_rules! gfx942_fill_word_body_v1 {
    ($a:ident, $b:ident, $c:ident, $d:ident) => {
        ($a as u32) | (($b as u32) << 8) | (($c as u32) << 16) | (($d as u32) << 24)
    };
}

macro_rules! gfx942_fill_index_body_v1 {
    ($low:ident, $high:ident, $local:ident) => {{ [($low | $local), $high] }};
}

macro_rules! gfx942_fill_wave_body_v1 {
    ($syntax:ident, $state:ident, $kernarg:ident, $lane:ident, $stores:ident,
     $incoming:ident, $words:ident, $length:ident,
     [$($index_annotations:tt)*], [$($compare_annotations:tt)*],
     [$($store_annotations:tt)*], [$($after_index:tt)*],
     [$($compare_step:tt)*], [$($after_compare:tt)*], [$($store_step:tt)*],
     [$($compare_end:tt)*], [$($finish:tt)*]) => {
        $syntax!({
            // S_LOAD captures its base and bytes before S_LSHL overwrites s0:s1.
            let read_address = pair($state.sgprs[0], $state.sgprs[1]);
            let pending_load = decode_kernarg($kernarg);
            let $incoming = $state.exec_mask;
            $state.sgprs[3] = 0;
            let shifted = ($state.sgprs[2] as u64) << 6;
            $state.sgprs[0] = shifted as u32;
            $state.sgprs[1] = (shifted >> 32) as u32;
            let mut $lane = 0usize;
            while $lane < 64
                $($index_annotations)*
            {
                if $incoming & (1u64 << $lane) != 0 {
                    let mut registers = $state.vgprs[$lane];
                    let index = index_words($state.sgprs[0], $state.sgprs[1], registers[0]);
                    registers[0] = index[0];
                    registers[1] = index[1];
                    $state.vgprs[$lane] = registers;
                }
                $lane += 1;
            }
            $($after_index)*
            // WAIT lgkmcnt(0): materialize the captured read, not the new s0:s1.
            let $words = pending_load;
            $state.sgprs[4] = $words[0];
            $state.sgprs[5] = $words[1];
            $state.sgprs[6] = $words[2];
            $state.sgprs[7] = $words[3];
            let $length = pair($words[2], $words[3]);
            $state.vcc = 0;
            $lane = 0;
            while $lane < 64
                $($compare_annotations)*
            {
                $($compare_step)*
                let bit = 1u64 << $lane;
                let index = pair($state.vgprs[$lane][0], $state.vgprs[$lane][1]);
                if $incoming & bit != 0 && $length > index {
                    $state.vcc |= bit;
                }
                $($compare_end)*
                $lane += 1;
            }
            $($after_compare)*
            // AND_SAVEEXEC reads old EXEC before replacing the aliased s0:s1.
            $state.sgprs[0] = $incoming as u32;
            $state.sgprs[1] = ($incoming >> 32) as u32;
            $state.exec_mask = $incoming & $state.vcc;
            $state.scc = $state.exec_mask != 0;
            let mut $stores = [None; 64];
            let retired_instructions;
            // CBRANCH_EXECZ targets END directly; no VGPR stores on this path.
            if $state.exec_mask == 0 {
                retired_instructions = 10;
            } else {
                retired_instructions = 14;
                $lane = 0;
                while $lane < 64
                    $($store_annotations)*
                {
                    $($store_step)*
                    if $state.exec_mask & (1u64 << $lane) != 0 {
                        let mut registers = $state.vgprs[$lane];
                        registers[2] = $words[0];
                        registers[3] = $words[1];
                        let index = pair(registers[0], registers[1]);
                        let base = pair(registers[2], registers[3]);
                        let address = (index << 2).wrapping_add(base);
                        registers[2] = address as u32;
                        registers[3] = (address >> 32) as u32;
                        $state.vgprs[$lane] = registers;
                        $stores[$lane] = Some(Gfx942FillStoreV1 {
                            address,
                            value: registers[0],
                        });
                    }
                    $lane += 1;
                }
            }
            $($finish)*
            // END implicitly drains this wave's operations in the projection.
            // It does not establish host visibility or AQL completion.
            Gfx942FillWaveExecutionV1 {
                state: $state,
                kernarg_read_address: read_address,
                stores: $stores,
                retired_instructions,
                terminal_pc: 0x44,
            }
        })
    };
}

macro_rules! gfx942_fill_byte_body_v1 {
    ($syntax:ident, $execution:ident, $address:ident, $before:ident,
     $lane:ident, $byte:ident, [$($annotations:tt)*]) => {
        $syntax!({
            let mut $byte = $before;
            let mut $lane = 0usize;
            while $lane < 64
                $($annotations)*
            {
                if let Some(store) = $execution.stores[$lane] {
                    if $address >= store.address && $address - store.address < 4 {
                        $byte = (store.value >> (8 * ($address - store.address))) as u8;
                    }
                }
                $lane += 1;
            }
            $byte
        })
    };
}

// Shared complete closed-wave projection; not ISA or compiler refinement.
use vstd::prelude::*;

verus! {
#[derive(Clone, Copy)]
pub struct Gfx942FillWaveStateV1 {
    pub sgprs: [u32; 8],
    pub vgprs: [[u32; 4]; 64],
    pub exec_mask: u64,
    pub vcc: u64,
    pub scc: bool,
}
#[derive(Clone, Copy)]
pub struct Gfx942FillStoreV1 {
    pub address: u64,
    pub value: u32,
}
pub struct Gfx942FillWaveExecutionV1 {
    pub state: Gfx942FillWaveStateV1,
    pub kernarg_read_address: u64,
    pub stores: [Option<Gfx942FillStoreV1>; 64],
    pub retired_instructions: u8,
    pub terminal_pc: u64,
}

spec fn pair_spec(low: u32, high: u32) -> u64 {
    (low as u64) | ((high as u64) << 32)
}
fn pair(low: u32, high: u32) -> (result: u64)
    ensures result == pair_spec(low, high),
{ gfx942_fill_pair_body_v1!(low, high) }

spec fn word_spec(a: u8, b: u8, c: u8, d: u8) -> u32 {
    (a as u32) | ((b as u32) << 8) | ((c as u32) << 16) | ((d as u32) << 24)
}
fn word(a: u8, b: u8, c: u8, d: u8) -> (result: u32)
    ensures result == word_spec(a, b, c, d),
{ gfx942_fill_word_body_v1!(a, b, c, d) }

spec fn words_spec(bytes: Seq<u8>) -> Seq<u32> {
    seq![word_spec(bytes[0], bytes[1], bytes[2], bytes[3]),
         word_spec(bytes[4], bytes[5], bytes[6], bytes[7]),
         word_spec(bytes[8], bytes[9], bytes[10], bytes[11]),
         word_spec(bytes[12], bytes[13], bytes[14], bytes[15])]
}
fn decode_kernarg(bytes: &[u8; 16]) -> (result: [u32; 4])
    ensures result@ == words_spec(bytes@),
{ gfx942_fill_decode_body_v1!(bytes) }

fn index_words(low: u32, high: u32, local: u32) -> (result: [u32; 2])
    ensures result@[0] == (low | local), result@[1] == high,
{ gfx942_fill_index_body_v1!(low, high, local) }

spec fn active(mask: u64, lane: int) -> bool {
    mask & (1u64 << lane) != 0
}
spec fn index_regs(regs: [u32; 4], group: u32) -> [u32; 4] {
    [(((group as u64) << 6) as u32) | regs[0],
     (((group as u64) << 6) >> 32) as u32, regs[2], regs[3]]
}
spec fn indexed(entry: Gfx942FillWaveStateV1, lane: int) -> [u32; 4] {
    if active(entry.exec_mask, lane) {
        index_regs(entry.vgprs[lane], entry.sgprs[2])
    } else { entry.vgprs[lane] }
}
spec fn global_index(entry: Gfx942FillWaveStateV1, lane: int) -> u64 {
    ((entry.sgprs[2] as u64) * 64 + entry.vgprs[lane][0] as u64) as u64
}
spec fn pointer(bytes: Seq<u8>) -> u64 {
    pair_spec(words_spec(bytes)[0], words_spec(bytes)[1])
}
spec fn count(bytes: Seq<u8>) -> u64 {
    pair_spec(words_spec(bytes)[2], words_spec(bytes)[3])
}
spec fn selected(entry: Gfx942FillWaveStateV1, bytes: Seq<u8>, lane: int) -> bool {
    active(entry.exec_mask, lane) && global_index(entry, lane) < count(bytes)
}
spec fn store_spec(entry: Gfx942FillWaveStateV1, bytes: Seq<u8>, lane: int)
    -> Option<Gfx942FillStoreV1>
{
    if selected(entry, bytes, lane) {
        Some(Gfx942FillStoreV1 {
            address: (pointer(bytes) + 4 * global_index(entry, lane)) as u64,
            value: global_index(entry, lane) as u32,
        })
    } else { None }
}
spec fn final_regs(entry: Gfx942FillWaveStateV1, bytes: Seq<u8>, lane: int) -> [u32; 4] {
    if selected(entry, bytes, lane) {
        let index = global_index(entry, lane);
        let address = (pointer(bytes) + 4 * index) as u64;
        [index as u32, (index >> 32) as u32, address as u32, (address >> 32) as u32]
    } else { indexed(entry, lane) }
}
spec fn valid(entry: Gfx942FillWaveStateV1, bytes: Seq<u8>) -> bool {
    bytes.len() == 16
    && pointer(bytes) as int + 4 * count(bytes) as int <= u64::MAX
    && forall|lane: int| 0 <= lane < 64 && active(entry.exec_mask, lane)
        ==> #[trigger] entry.vgprs[lane][0] < 64
}

proof fn index_arithmetic(group: u32, local: u32)
    requires local < 64,
    ensures
        pair_spec((((group as u64) << 6) as u32) | local,
            (((group as u64) << 6) >> 32) as u32) == (group as u64) * 64 + local as u64,
        ((((group as u64) << 6) as u32) | local) == ((group as u64) * 64 + local as u64) as u32,
        (((group as u64) << 6) >> 32) as u32 == ((((group as u64) * 64 + local as u64) as u64) >> 32) as u32,
        (group as u64) * 64 + (local as u64) < 0x40_0000_0000u64,
{
    assert(
        (((((group as u64) << 6) as u32) | local) as u64)
            | (((((group as u64) << 6) >> 32) as u32 as u64) << 32)
            == (group as u64) * 64 + local as u64
    ) by (bit_vector) requires local < 64;
    assert(
        ((((group as u64) << 6) as u32) | local) == ((group as u64) * 64 + local as u64) as u32
        && (((group as u64) << 6) >> 32) as u32 == ((((group as u64) * 64 + local as u64) as u64) >> 32) as u32
        && (group as u64) * 64 + (local as u64) < 0x40_0000_0000u64
    ) by (bit_vector) requires local < 64;
}

proof fn mask_insert(mask: u64, lane: usize)
    requires lane < 64,
    ensures
        active(mask | (1u64 << lane), lane as int),
        forall|other: int| 0 <= other < 64 && other != lane
            ==> active(mask | (1u64 << lane), other) == active(mask, other),
{
    assert((mask | (1u64 << lane)) & (1u64 << lane) != 0) by (bit_vector)
        requires lane < 64;
    assert forall|other: int| 0 <= other < 64 && other != lane
        implies active(mask | (1u64 << lane), other) == active(mask, other) by {
        let n = other as u64;
        assert((mask | (1u64 << lane)) & (1u64 << n) == mask & (1u64 << n))
            by (bit_vector) requires lane < 64, n < 64, n != lane;
    }
}

proof fn mask_zero()
    ensures forall|lane: int| 0 <= lane < 64 ==> !active(0, lane),
{
    assert forall|lane: int| 0 <= lane < 64 implies !active(0, lane) by {
        let n = lane as u64;
        assert(0u64 & (1u64 << n) == 0u64) by (bit_vector);
    }
}

proof fn mask_subset(incoming: u64, comparison: u64)
    requires forall|lane: int| 0 <= lane < 64 && active(comparison, lane) ==> active(incoming, lane),
    ensures incoming & comparison == comparison,
{
    assert forall|n: u64| n < 64 && comparison & (1u64 << n) != 0 implies
        incoming & (1u64 << n) != 0 by {
        assert(active(comparison, n as int) ==> active(incoming, n as int));
    }
    assert(incoming & comparison == comparison) by (bit_vector)
        requires forall|n: u64| n < 64 ==>
            (comparison & (1u64 << n) != 0 ==> incoming & (1u64 << n) != 0);
}

proof fn pair_roundtrip(value: u64)
    ensures pair_spec(value as u32, (value >> 32) as u32) == value,
{
    assert(((value as u32) as u64) | (((value >> 32) as u32 as u64) << 32) == value) by (bit_vector);
}

proof fn address_arithmetic(index: u64, base: u64, length: u64)
    requires index < length, base as int + 4 * length as int <= u64::MAX,
    ensures
        (index << 2).wrapping_add(base) == base as int + 4 * index as int,
        base as int + 4 * index as int + 4 <= base as int + 4 * length as int,
{
    assert((index << 2) == (index * 4) as u64) by (bit_vector);
}

fn execute_wave(mut state: Gfx942FillWaveStateV1, kernarg: &[u8; 16])
    -> (result: Gfx942FillWaveExecutionV1)
    requires valid(state, kernarg@),
    ensures
        result.kernarg_read_address == pair_spec(state.sgprs[0], state.sgprs[1]),
        result.terminal_pc == 0x44,
        result.retired_instructions == if result.state.exec_mask == 0 { 10u8 } else { 14u8 },
        result.state.scc == (result.state.exec_mask != 0),
        result.state.vcc == result.state.exec_mask,
        pair_spec(result.state.sgprs[0], result.state.sgprs[1]) == state.exec_mask,
        result.state.sgprs[2] == state.sgprs[2],
        result.state.sgprs[3] == 0,
        result.state.sgprs[4] == words_spec(kernarg@)[0],
        result.state.sgprs[5] == words_spec(kernarg@)[1],
        result.state.sgprs[6] == words_spec(kernarg@)[2],
        result.state.sgprs[7] == words_spec(kernarg@)[3],
        forall|lane: int| 0 <= lane < 64 ==>
            active(result.state.exec_mask, lane) == selected(state, kernarg@, lane),
        forall|lane: int| 0 <= lane < 64 ==>
            #[trigger] result.stores[lane] == store_spec(state, kernarg@, lane),
        forall|lane: int| 0 <= lane < 64 ==>
            #[trigger] result.state.vgprs[lane] == final_regs(state, kernarg@, lane),
{
    let ghost entry = state;
    proof { mask_zero(); }
    gfx942_fill_wave_body_v1!(verus_exec_expr, state, kernarg, lane, stores, incoming, words, length,
    [
        invariant
            lane <= 64, incoming == entry.exec_mask, valid(entry, kernarg@),
            state.sgprs[2] == entry.sgprs[2], state.sgprs[3] == 0,
            state.sgprs[0] == ((entry.sgprs[2] as u64) << 6) as u32,
            state.sgprs[1] == (((entry.sgprs[2] as u64) << 6) >> 32) as u32,
            forall|j: int| 0 <= j < 64 ==> #[trigger] state.vgprs[j]
                == if j < lane { indexed(entry, j) } else { entry.vgprs[j] },
        decreases 64 - lane,
    ], [
        invariant
            lane <= 64, incoming == entry.exec_mask, valid(entry, kernarg@),
            words@ == words_spec(kernarg@),
            length == count(kernarg@),
            forall|j: int| 0 <= j < 64 ==> #[trigger] state.vgprs[j] == indexed(entry, j),
            forall|j: int| 0 <= j < 64 ==> active(state.vcc, j)
                == (j < lane && selected(entry, kernarg@, j)),
        decreases 64 - lane,
    ], [
        invariant
            lane <= 64, incoming == entry.exec_mask, valid(entry, kernarg@),
            words@ == words_spec(kernarg@),
            forall|j: int| 0 <= j < 64 ==> active(state.exec_mask, j) == selected(entry, kernarg@, j),
            forall|j: int| 0 <= j < 64 ==> #[trigger] state.vgprs[j]
                == if j < lane { final_regs(entry, kernarg@, j) } else { indexed(entry, j) },
            forall|j: int| 0 <= j < 64 ==> #[trigger] stores[j]
                == if j < lane { store_spec(entry, kernarg@, j) } else { None },
        decreases 64 - lane,
    ], [
        proof {
            assert forall|j: int| 0 <= j < 64 && active(entry.exec_mask, j)
                implies pair_spec(state.vgprs[j][0], state.vgprs[j][1]) == global_index(entry, j) by {
                index_arithmetic(entry.sgprs[2], entry.vgprs[j][0]);
            }
        }
    ], [
        let ghost comparison_before = state.vcc;
        proof {
            mask_insert(state.vcc, lane);
            if active(entry.exec_mask, lane as int) {
                index_arithmetic(entry.sgprs[2], entry.vgprs[lane as int][0]);
            }
            assert((incoming & (1u64 << lane) != 0
                && pair_spec(state.vgprs[lane as int][0], state.vgprs[lane as int][1]) < count(kernarg@))
                == selected(entry, kernarg@, lane as int));
        }
    ], [
        proof {
            mask_subset(incoming, state.vcc);
            pair_roundtrip(incoming);
        }
    ], [
        proof {
            if active(state.exec_mask, lane as int) {
                index_arithmetic(entry.sgprs[2], entry.vgprs[lane as int][0]);
                address_arithmetic(global_index(entry, lane as int), pointer(kernarg@), count(kernarg@));
            }
        }
    ], [
        proof {
            assert(state.vcc == if selected(entry, kernarg@, lane as int) {
                comparison_before | (1u64 << lane)
            } else { comparison_before });
            assert forall|j: int| 0 <= j < 64 implies active(state.vcc, j)
                == (j <= lane && selected(entry, kernarg@, j)) by {
                if j != lane {
                    assert(active(state.vcc, j) == active(comparison_before, j));
                    assert(active(comparison_before, j) == (j < lane && selected(entry, kernarg@, j)));
                } else if selected(entry, kernarg@, j) {
                    assert(active(state.vcc, j));
                } else {
                    assert(!active(comparison_before, j));
                }
            }
        }
    ], [
        proof {
            if state.exec_mask == 0 {
                assert forall|j: int| 0 <= j < 64 implies !selected(entry, kernarg@, j) by {
                    assert(!active(0, j));
                }
            }
        }
    ])
}

spec fn covers(store: Option<Gfx942FillStoreV1>, address: u64) -> bool {
    match store {
        Some(s) => address >= s.address && address - s.address < 4,
        None => false,
    }
}
spec fn observe(stores: Seq<Option<Gfx942FillStoreV1>>, address: u64, before: u8, n: nat) -> u8
    decreases n,
{
    if n == 0 { before } else {
        match stores[n - 1] {
            Some(s) => if covers(stores[n - 1], address) {
                (s.value >> ((8 * (address - s.address)) as u64)) as u8
            } else { observe(stores, address, before, (n - 1) as nat) },
            None => observe(stores, address, before, (n - 1) as nat),
        }
    }
}

impl Gfx942FillWaveExecutionV1 {
    fn byte_after(&self, address: u64, before: u8) -> (result: u8)
        ensures
            result == observe(self.stores@, address, before, 64),
            (forall|lane: int| 0 <= lane < 64 ==> !covers(self.stores[lane], address))
                ==> result == before,
    {
        gfx942_fill_byte_body_v1!(verus_exec_expr, self, address, before, lane, byte, [
            invariant
                lane <= 64,
                byte == observe(self.stores@, address, before, lane as nat),
                (forall|j: int| 0 <= j < lane ==> !covers(self.stores[j], address)) ==> byte == before,
            decreases 64 - lane,
        ])
    }
}

proof fn distinct_store_intervals(group: u32, left: u32, right: u32, base: u64, length: u64)
    requires
        left < 64, right < 64, left != right,
        (group as int) * 64 + (left as int) < length,
        (group as int) * 64 + (right as int) < length,
        base as int + length as int * 4 <= u64::MAX,
    ensures
        base as int + 4 * (group as int * 64 + left as int) + 4
            <= base as int + 4 * (group as int * 64 + right as int)
        || base as int + 4 * (group as int * 64 + right as int) + 4
            <= base as int + 4 * (group as int * 64 + left as int),
{}
}

// Shared dispatch validation, ABI entry construction, and actual wave composition.
macro_rules! gfx942_fill_dispatch_valid_body_v1 {
    ($input:ident) => {{
        let words = decode_kernarg(&$input.kernarg);
        let count = pair(words[2], words[3]);
        $input.grid[0] > 0
            && $input.grid[0] % 64 == 0
            && $input.grid[1] == 1
            && $input.grid[2] == 1
            && $input.workgroup[0] == 64
            && $input.workgroup[1] == 1
            && $input.workgroup[2] == 1
            && count <= $input.grid[0] as u64
            && ($input.kernarg_bytes == 16 || $input.kernarg_bytes == 272)
            && $input.kernarg_address % 8 == 0
            && $input.kernarg_address <= u64::MAX - $input.kernarg_bytes
            && pair(words[0], words[1]) == $input.output_base
            && $input.output_base % 4 == 0
            && $input.output_bytes == count * 4
            && $input.output_base <= u64::MAX - $input.output_bytes
            && ($input.output_bytes == 0
                || $input.output_base >= $input.kernarg_address + $input.kernarg_bytes
                || $input.kernarg_address >= $input.output_base + $input.output_bytes)
    }};
}

macro_rules! gfx942_fill_entry_body_v1 {
    ($syntax:ident, $state:ident, $address:ident, $group:ident, $lane:ident,
     [$($annotations:tt)*]) => {
        $syntax!({
            $state.sgprs[0] = $address as u32;
            $state.sgprs[1] = ($address >> 32) as u32;
            $state.sgprs[2] = $group;
            $state.exec_mask = u64::MAX;
            let mut $lane = 0usize;
            while $lane < 64
                $($annotations)*
            {
                let mut registers = $state.vgprs[$lane];
                registers[0] = $lane as u32;
                $state.vgprs[$lane] = registers;
                $lane += 1;
            }
            $state
        })
    };
}

macro_rules! gfx942_fill_group_body_v1 {
    ($syntax:ident, $input:ident, $group:ident, $seed:ident, $entry:ident, [$($after_entry:tt)*]) => {
        $syntax!({
            if $group >= $input.grid[0] / 64 {
                None
            } else {
                let $entry = initialize_entry($seed, $input.kernarg_address, $group);
                $($after_entry)*
                Some(execute_wave($entry, &$input.kernarg))
            }
        })
    };
}

macro_rules! gfx942_fill_dispatch_byte_body_v1 {
    ($syntax:ident, $input:ident, $address:ident, $before:ident,
     $index:ident, $group:ident, $entry:ident, $execution:ident,
     [$($before_wave:tt)*], [$($after_wave:tt)*]) => {
        $syntax!({
            if $address < $input.output_base
                || $address - $input.output_base >= $input.output_bytes
            {
                $before
            } else {
                let $index = ($address - $input.output_base) / 4;
                let $group = ($index / 64) as u32;
                let seed = Gfx942FillWaveStateV1 {
                    sgprs: [0; 8], vgprs: [[0; 4]; 64], exec_mask: 0, vcc: 0, scc: false,
                };
                let $entry = initialize_entry(seed, $input.kernarg_address, $group);
                $($before_wave)*
                let $execution = execute_wave($entry, &$input.kernarg);
                $($after_wave)*
                $execution.byte_after($address, $before)
            }
        })
    };
}

// Complete projected dispatch; includes the actual existing wave proof unchanged.

verus! {
#[derive(Clone, Copy)]
pub struct DispatchInput {
    pub kernarg: [u8; 16],
    pub kernarg_address: u64,
    pub kernarg_bytes: u64,
    pub output_base: u64,
    pub output_bytes: u64,
    pub grid: [u32; 3],
    pub workgroup: [u32; 3],
}

spec fn dispatch_valid(input: DispatchInput) -> bool {
    input.grid[0] > 0 && input.grid[0] % 64 == 0
    && input.grid[1] == 1 && input.grid[2] == 1
    && input.workgroup[0] == 64 && input.workgroup[1] == 1 && input.workgroup[2] == 1
    && count(input.kernarg@) <= input.grid[0]
    && (input.kernarg_bytes == 16 || input.kernarg_bytes == 272)
    && input.kernarg_address % 8 == 0
    && input.kernarg_address as int + input.kernarg_bytes as int <= u64::MAX
    && pointer(input.kernarg@) == input.output_base
    && input.output_base % 4 == 0
    && input.output_bytes == 4 * count(input.kernarg@) as int
    && input.output_base as int + input.output_bytes as int <= u64::MAX
    && (input.output_bytes == 0
        || input.output_base as int >= input.kernarg_address as int + input.kernarg_bytes as int
        || input.kernarg_address as int >= input.output_base as int + input.output_bytes as int)
}

fn valid_dispatch(input: &DispatchInput) -> (result: bool)
    ensures result == dispatch_valid(*input),
{ gfx942_fill_dispatch_valid_body_v1!(input) }

spec fn entry_matches(entry: Gfx942FillWaveStateV1, address: u64, group: u32) -> bool {
    pair_spec(entry.sgprs[0], entry.sgprs[1]) == address
    && entry.sgprs[2] == group && entry.exec_mask == u64::MAX
    && forall|lane: int| 0 <= lane < 64 ==> #[trigger] entry.vgprs[lane][0] == lane
}

fn initialize_entry(mut state: Gfx942FillWaveStateV1, address: u64, group: u32)
    -> (result: Gfx942FillWaveStateV1)
    ensures
        entry_matches(result, address, group),
        forall|j: int| 3 <= j < 8 ==> #[trigger] result.sgprs[j] == state.sgprs[j],
        forall|j: int, k: int| 0 <= j < 64 && 1 <= k < 4 ==>
            #[trigger] result.vgprs[j][k] == state.vgprs[j][k],
        result.vcc == state.vcc, result.scc == state.scc,
{
    let ghost seed = state;
    proof { pair_roundtrip(address); }
    gfx942_fill_entry_body_v1!(verus_exec_expr, state, address, group, lane, [
        invariant
            lane <= 64,
            pair_spec(state.sgprs[0], state.sgprs[1]) == address,
            state.sgprs[2] == group, state.exec_mask == u64::MAX,
            state.vcc == seed.vcc, state.scc == seed.scc,
            forall|j: int| 3 <= j < 8 ==> #[trigger] state.sgprs[j] == seed.sgprs[j],
            forall|j: int| 0 <= j < 64 ==> #[trigger] state.vgprs[j]
                == [if j < lane { j as u32 } else { seed.vgprs[j][0] },
                    seed.vgprs[j][1], seed.vgprs[j][2], seed.vgprs[j][3]],
        decreases 64 - lane,
    ])
}

spec fn group_index(group: u32, lane: int) -> int { group as int * 64 + lane }
spec fn group_store(input: DispatchInput, group: u32, lane: int) -> Option<Gfx942FillStoreV1> {
    if group_index(group, lane) < count(input.kernarg@) {
        Some(Gfx942FillStoreV1 {
            address: (input.output_base as int + 4 * group_index(group, lane)) as u64,
            value: group_index(group, lane) as u32,
        })
    } else { None }
}

proof fn full_lane(lane: int)
    requires 0 <= lane < 64,
    ensures active(u64::MAX, lane),
{
    let n = lane as u64;
    assert(u64::MAX & (1u64 << n) != 0) by (bit_vector) requires n < 64;
}

proof fn dispatch_entry(input: DispatchInput, group: u32, entry: Gfx942FillWaveStateV1)
    requires dispatch_valid(input), group < input.grid[0] / 64,
        entry_matches(entry, input.kernarg_address, group),
    ensures
        valid(entry, input.kernarg@),
        forall|lane: int| 0 <= lane < 64 ==>
            global_index(entry, lane) == group_index(group, lane),
        forall|lane: int| 0 <= lane < 64 ==>
            store_spec(entry, input.kernarg@, lane) == group_store(input, group, lane),
{
    assert forall|lane: int| 0 <= lane < 64 implies
        global_index(entry, lane) == group_index(group, lane)
        && store_spec(entry, input.kernarg@, lane) == group_store(input, group, lane) by {
        full_lane(lane);
    }
}

fn execute_group(input: &DispatchInput, group: u32, seed: Gfx942FillWaveStateV1)
    -> (result: Option<Gfx942FillWaveExecutionV1>)
    requires dispatch_valid(*input),
    ensures
        result.is_some() == (group < input.grid[0] / 64),
        result.is_some() ==> {
            let execution = result.unwrap();
            execution.terminal_pc == 0x44
            && execution.kernarg_read_address == input.kernarg_address
            && execution.retired_instructions == if execution.state.exec_mask == 0 { 10u8 } else { 14u8 }
            && forall|lane: int| 0 <= lane < 64 ==>
                #[trigger] execution.stores[lane] == group_store(*input, group, lane)
        },
{
    gfx942_fill_group_body_v1!(verus_exec_expr, input, group, seed, entry, [
        proof { dispatch_entry(*input, group, entry); }
    ])
}

proof fn exact_coordinate(input: DispatchInput, index: int)
    requires dispatch_valid(input), 0 <= index < count(input.kernarg@),
    ensures
        0 <= index / 64 < input.grid[0] / 64,
        0 <= index % 64 < 64,
        group_index((index / 64) as u32, index % 64) == index,
        group_store(input, (index / 64) as u32, index % 64)
            == Some(Gfx942FillStoreV1 { address: (input.output_base as int + 4 * index) as u64, value: index as u32 }),
{
    vstd::arithmetic::div_mod::lemma_fundamental_div_mod(index, 64);
    vstd::arithmetic::div_mod::lemma_mod_pos_bound(index, 64);
    vstd::arithmetic::div_mod::lemma_fundamental_div_mod(input.grid[0] as int, 64);
}

proof fn unique_coordinates(group_a: u32, lane_a: int, group_b: u32, lane_b: int)
    requires 0 <= lane_a < 64, 0 <= lane_b < 64,
        group_index(group_a, lane_a) == group_index(group_b, lane_b),
    ensures group_a == group_b, lane_a == lane_b,
{
    let i = group_index(group_a, lane_a);
    vstd::arithmetic::div_mod::lemma_fundamental_div_mod_converse(i, 64, group_a as int, lane_a);
    vstd::arithmetic::div_mod::lemma_fundamental_div_mod_converse(i, 64, group_b as int, lane_b);
}

proof fn distinct_dispatch_intervals(input: DispatchInput, ga: u32, la: int, gb: u32, lb: int)
    requires dispatch_valid(input), 0 <= la < 64, 0 <= lb < 64,
        group_index(ga, la) < count(input.kernarg@),
        group_index(gb, lb) < count(input.kernarg@), ga != gb || la != lb,
    ensures
        input.output_base as int + 4 * group_index(ga, la) + 4
            <= input.output_base as int + 4 * group_index(gb, lb)
        || input.output_base as int + 4 * group_index(gb, lb) + 4
            <= input.output_base as int + 4 * group_index(ga, la),
{
    if group_index(ga, la) == group_index(gb, lb) { unique_coordinates(ga, la, gb, lb); }
}

spec fn inside_output(input: DispatchInput, address: u64) -> bool {
    input.output_base <= address && (address as int) < input.output_base as int + input.output_bytes as int
}
spec fn output_byte(input: DispatchInput, address: u64, before: u8) -> u8 {
    if inside_output(input, address) {
        let offset = address as int - input.output_base as int;
        ((offset / 4) as u32 >> ((offset % 4 * 8) as u64)) as u8
    } else { before }
}

proof fn covering_coordinates(input: DispatchInput, group: u32, lane: int, address: u64)
    requires dispatch_valid(input), 0 <= lane < 64,
    ensures covers(group_store(input, group, lane), address) ==
        (inside_output(input, address)
            && group as int == ((address as int - input.output_base as int) / 4) / 64
            && lane == ((address as int - input.output_base as int) / 4) % 64),
{
    let delta = address as int - input.output_base as int;
    let index = group_index(group, lane);
    if covers(group_store(input, group, lane), address) {
        vstd::arithmetic::div_mod::lemma_fundamental_div_mod_converse(delta, 4, index, delta - 4 * index);
        vstd::arithmetic::div_mod::lemma_fundamental_div_mod_converse(index, 64, group as int, lane);
    }
    if inside_output(input, address) {
        vstd::arithmetic::div_mod::lemma_fundamental_div_mod(delta, 4);
        vstd::arithmetic::div_mod::lemma_mod_pos_bound(delta, 4);
        vstd::arithmetic::div_mod::lemma_fundamental_div_mod(delta / 4, 64);
    }
}

proof fn observe_unique(stores: Seq<Option<Gfx942FillStoreV1>>, address: u64, before: u8, n: nat, lane: int)
    requires n <= stores.len(), 0 <= lane < n,
        covers(stores[lane], address),
        forall|j: int| 0 <= j < n && j != lane ==> !covers(#[trigger] stores[j], address),
    ensures observe(stores, address, before, n)
        == (stores[lane].unwrap().value >> ((8 * (address - stores[lane].unwrap().address)) as u64)) as u8,
    decreases n,
{
    if n - 1 != lane {
        observe_unique(stores, address, before, (n - 1) as nat, lane);
    }
}

fn dispatch_byte_after(input: &DispatchInput, address: u64, before: u8) -> (result: u8)
    requires dispatch_valid(*input),
    ensures result == output_byte(*input, address, before),
{
    gfx942_fill_dispatch_byte_body_v1!(verus_exec_expr, input, address, before,
        index, group, entry, execution, [
        proof {
            let delta = address as int - input.output_base as int;
            vstd::arithmetic::div_mod::lemma_fundamental_div_mod(delta, 4);
            vstd::arithmetic::div_mod::lemma_mod_pos_bound(delta, 4);
            exact_coordinate(*input, index as int);
            dispatch_entry(*input, group, entry);
        }
    ], [
        proof {
            let lane = index as int % 64;
            assert forall|j: int| 0 <= j < 64 implies
                covers(#[trigger] execution.stores[j], address) == (j == lane) by {
                covering_coordinates(*input, group, j, address);
            }
            observe_unique(execution.stores@, address, before, 64, lane);
        }
    ])
}
}

verus! {
spec fn artifact_dispatch_valid(input: DispatchInput) -> bool { dispatch_valid(input) && input.kernarg_bytes == 272 }
spec fn semantic_store(base: u64, length: u64, global: u64) -> Option<Gfx942FillStoreV1> {
    let v0 = (base, length);
    let v1 = global;
    let v2 = v1;
    let v3 = v2;
    let v4 = v3 as u32;
    let v5 = v0;
    let v6 = v1 < v5.1;
    if v1 < v5.1 { Some(Gfx942FillStoreV1 { address: (v5.0 as int + 4 * v1 as int) as u64, value: v4 }) } else { None }
}
spec fn semantic_byte(input: DispatchInput, address: u64, before: u8) -> u8 {
    if inside_output(input, address) {
        let index = ((address as int - input.output_base as int) / 4) as u64;
        let store = semantic_store(input.output_base, count(input.kernarg@), index);
        if store.is_some() && covers(store, address) {
            (store.unwrap().value >> ((8 * (address - store.unwrap().address)) as u64)) as u8
        } else { before }
    } else { before }
}
spec fn neutral_store(base: u64, length: u64, global: u64) -> Option<Gfx942FillStoreV1> {
    let v0 = (base, length);
    let v1 = global;
    let v2 = v1;
    let v3 = v2 as u32;
    let v4 = v0.1;
    let v5 = v1 < v4;
    let v6 = 0u64;
    let v7 = if v5 { v1 } else { v6 };
    let v8 = v0.0;
    let v9 = (v8 as int + 4 * v7 as int) as u64;
    if v5 { Some(Gfx942FillStoreV1 { address: v9, value: v3 }) } else { None }
}
spec fn neutral_byte(input: DispatchInput, address: u64, before: u8) -> u8 {
    if inside_output(input, address) {
        let index = ((address as int - input.output_base as int) / 4) as u64;
        let store = neutral_store(input.output_base, count(input.kernarg@), index);
        if store.is_some() && covers(store, address) {
            (store.unwrap().value >> ((8 * (address - store.unwrap().address)) as u64)) as u8
        } else { before }
    } else { before }
}
spec fn target_store(base: u64, length: u64, global: u64) -> Option<Gfx942FillStoreV1> {
    let v0 = (base, length);
    let v1 = global;
    let v2 = v1;
    let v3 = v2 as u32;
    let v4 = v0.1;
    let v5 = v1 < v4;
    let v6 = 0u64;
    let v7 = if v5 { v1 } else { v6 };
    let v8 = v0.0;
    let v9 = (v8 as int + 4 * v6 as int) as u64;
    if v5 { Some(Gfx942FillStoreV1 { address: v9, value: v3 }) } else { None }
}
spec fn target_byte(input: DispatchInput, address: u64, before: u8) -> u8 {
    if inside_output(input, address) {
        let index = ((address as int - input.output_base as int) / 4) as u64;
        let store = target_store(input.output_base, count(input.kernarg@), index);
        if store.is_some() && covers(store, address) {
            (store.unwrap().value >> ((8 * (address - store.unwrap().address)) as u64)) as u8
        } else { before }
    } else { before }
}
proof fn generated_store_relation(input: DispatchInput, group: u32, lane: int)
    requires artifact_dispatch_valid(input), group < input.grid[0] / 64, 0 <= lane < 64,
    ensures
        semantic_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64)
            == group_store(input, group, lane),
        neutral_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64)
            == group_store(input, group, lane),
        target_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64)
            == group_store(input, group, lane),
{}

fn execute_refining_group(input: &DispatchInput, group: u32, seed: Gfx942FillWaveStateV1)
    -> (result: Gfx942FillWaveExecutionV1)
    requires artifact_dispatch_valid(*input), group < input.grid[0] / 64,
    ensures
        result.terminal_pc == 0x44,
        result.kernarg_read_address == input.kernarg_address,
        forall|lane: int| 0 <= lane < 64 ==> #[trigger] result.stores[lane]
            == semantic_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64),
        forall|lane: int| 0 <= lane < 64 ==> #[trigger] result.stores[lane]
            == neutral_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64),
        forall|lane: int| 0 <= lane < 64 ==> #[trigger] result.stores[lane]
            == target_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64),
{
    let result = execute_group(input, group, seed).unwrap();
    proof {
        assert forall|lane: int| 0 <= lane < 64 implies
            result.stores[lane] == semantic_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64)
            && result.stores[lane] == neutral_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64)
            && result.stores[lane] == target_store(input.output_base, count(input.kernarg@), group_index(group, lane) as u64)
        by { generated_store_relation(*input, group, lane); }
    }
    result
}

proof fn generated_coverage(input: DispatchInput, index: int)
    requires artifact_dispatch_valid(input), 0 <= index < count(input.kernarg@),
    ensures
        0 <= index / 64 < input.grid[0] / 64,
        semantic_store(input.output_base, count(input.kernarg@), index as u64)
            == Some(Gfx942FillStoreV1 { address: (input.output_base as int + 4 * index) as u64, value: index as u32 }),
        neutral_store(input.output_base, count(input.kernarg@), index as u64)
            == semantic_store(input.output_base, count(input.kernarg@), index as u64),
        target_store(input.output_base, count(input.kernarg@), index as u64)
            == semantic_store(input.output_base, count(input.kernarg@), index as u64),
{
    exact_coordinate(input, index);
    generated_store_relation(input, (index / 64) as u32, index % 64);
}

proof fn generated_byte_relation(input: DispatchInput, address: u64, before: u8)
    requires artifact_dispatch_valid(input),
    ensures
        semantic_byte(input, address, before) == output_byte(input, address, before),
        neutral_byte(input, address, before) == output_byte(input, address, before),
        target_byte(input, address, before) == output_byte(input, address, before),
{
    if inside_output(input, address) {
        let offset = address as int - input.output_base as int;
        vstd::arithmetic::div_mod::lemma_fundamental_div_mod(offset, 4);
        vstd::arithmetic::div_mod::lemma_mod_pos_bound(offset, 4);
        generated_coverage(input, offset / 4);
    }
}

fn execute_refining_byte(input: &DispatchInput, address: u64, before: u8) -> (result: u8)
    requires artifact_dispatch_valid(*input),
    ensures
        result == semantic_byte(*input, address, before),
        result == neutral_byte(*input, address, before),
        result == target_byte(*input, address, before),
        !inside_output(*input, address) ==> result == before,
{
    let result = dispatch_byte_after(input, address, before);
    proof { generated_byte_relation(*input, address, before); }
    result
}
}
