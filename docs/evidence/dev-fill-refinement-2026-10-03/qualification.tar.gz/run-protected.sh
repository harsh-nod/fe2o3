#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-fill-refinement-20261003-SBbxgJWA
trap 'printf "%s\n" "$?" > "$scratch/protected.status"' EXIT
timeout --kill-after=15s 900s /mnt/c/Windows/System32/wsl.exe --user root --exec /bin/bash \
    "$scratch/isolated-runtime.sh" \
    /usr/bin/env FE2O3_MACHINE_EFFECT_NATIVE_WORKER="$scratch/fe2o3-llvm-link-worker" \
    FE2O3_FILL_ANALYSIS_HSACO="$scratch/native/qualified-final/audit-1/finalized.hsaco" \
    FE2O3_FILL_REFINEMENT_EVIDENCE="$scratch/protected-1" \
    /home/harsh/.cargo/bin/cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-verifier --lib protected_native_conditional_fill_refinement \
    -- --ignored --nocapture >"$scratch/protected.log" 2>&1
