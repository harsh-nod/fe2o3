# Quiescence Control Development Qualification

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Signed implementation: `1cc1bcbd70179f32cd04a658fb22e38e0b1e1c5f`.
All commands below completed; no observation timeout was treated as completion.
CPU commands ran on the implementation later signed in that commit. The signed
campaign additionally authenticates source blobs, per-phase continuity and the
verifier closure. CPU logs are development results, not a hermetic build proof.

## CPU Commands

Cargo commands used `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1` and offline mode.

| Command | Log | Exit/result |
| --- | --- | --- |
| `cargo test --offline -p fe2o3-runtime --all-features --lib quiescence -- --nocapture` | `runtime-focused.log` | 0; 39 passed |
| `cargo test --offline -p fe2o3-runtime --all-features --lib` | `runtime-all-features.log` | 101; 1664 passed, 3 failed, 28 ignored |
| `cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings` | `clippy.log` | 0 |
| `cargo test --offline -p fe2o3-runtime --all-features --doc` | `doctests.log` | 0; 8 + 44 passed |
| `cargo check --offline -p fe2o3-runtime --no-default-features` | `minimal.log` | 0 |
| `cargo fmt -p fe2o3-runtime -- --check` | `fmt.log` | 0 |

`git diff --check` passed. The three unchanged failures are the authorized
execution socket-inspection fixtures, all `InspectSocket(PermissionDenied)` at
`authorized_execution.rs:1317`; they are not waived or counted as passing.
The unit-test executable checksum is measured after the runs. Compiler identity,
signed source patch and signature verification are included separately.

## Proof Commands

The initial development invocation used the same verifier and flags as the
campaign below, with relative proof input
`crates/fe2o3-runtime-model/verus/compute_quiescence_v1.rs` and no function selector.
It exited 0, reporting 12 verified and 0 errors; its stdout/stderr are retained.

The signed campaign command was:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-compute-quiescence.py \
  --output /home/harsh/.codex-tmp/fe2o3-quiescence-campaign-20260927-v1 \
  --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus
```

It exited 0. `campaign.log` records its phase summaries. `campaign/` is an exact
copy of its completed output, including signed-input hashes, before/after source
snapshots, exact process argv, stdout/stderr, relocation, all mutant inputs,
per-phase exit codes, verifier closure results and final results.json.
All 17 negatives were accepted only as source-bound logical failures (exit 1).
Timeouts, malformed output, foreign diagnostics and resource failures are not
accepted as mutation rejection. Positive runs before, relocated and after each
reported the exact whole-root result: 12 verified, 0 errors, success true.

No physical quiescence, allocation/custody, retained graph, callback, unwind,
machine-code or GPU-memory-order proof is supplied by this scalar campaign.

## Remote Environment

`ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x 'hostname'` exited 255 before
connection: `Could not resolve hostname sharkmi300x-1: Temporary failure in name resolution`.
No remote files or jobs were created, and no GPU or matched performance run was
performed. Publication attempts occur after freezing these receipts and must be
reported separately rather than inferred from this archive.
