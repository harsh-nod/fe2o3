# Review and Scope

Read-only custody review found no production blocker. Legacy errors,
acceptance-before-binding, complete rollback before retry, original panic
payloads, and the cancellation-failure StaleDispatchGeneration error are
preserved. The raw operation is private; the native adapter and CPU tests both
enter the shared terminalizing wrapper. No public recipe or native callback
injection was added.

Read-only test review confirmed complete N=3 dispatch-roster joins, real lower
completion/event/reader receipts, capacity and pin assertions, neighbors,
terminal custody, and lane restoration. Source-forwarding checks are only
source wiring smoke. CPU native-return and signal injection is not hardware
execution, ring occupancy, or native semantic refinement.

The first compile attempt caught incorrect test API names and Option handling.
The next attempt passed seven of eight groups. The persistent-gate test wrongly
expected AUX callback entry. The broad run then passed 1720/1722 tests: a follow-up
oracle wrongly expected the primary lane to reject before callback entry, and an
existing runtime source-wiring assertion still expected the pre-OrdinaryQueueIo
call shape. Final test-only corrections distinguish primary/AUX behavior and
check both forwarding layers. Production hashes are unchanged from the broad
run. No correction weakened production admission.

## Next Source Proof

R42, R45 and R51 provide useful event/target model specifications but explicitly
exclude production-Rust refinement. In particular, target bounds of 256 cannot
stand for the 8192-packet source bound.

The next property should prove that returned source retry entails complete
selected-custody rollback by sharing actual source control bodies and exact
event-release, completion-cancel and dispatch-cancel algorithms. Require the
event-ledger/slot-pin cardinality invariant, preserve unrelated events/readers,
and do not assume a Boolean rollback-success contract. Retry leaves consumed
identities burned; a later rollback failure can leave an already-released prefix
and must be terminal. Native no-effect truth, hash-table representation,
allocation/unwind and process-global poisoning remain explicit boundaries unless
separately included. No new Verus result is claimed by this campaign.

## Next A2 Integration

Keep explicit producer-success gating. Initially request real native source
events only for logical events recorded while Pending/MaterializedPrepared;
late logical events retain existing behavior. Deposit returned event and batch
inside the native callback before outer-close settlement. Preserve requested
state through no-effect retries. Logical fan-out must not duplicate native
move-only authority.

After actual Ready, release an unused native source event before recycle.
Waiting for public logical-event destruction would deadlock wait-then-release
callers. Index consuming-release custody before handing over the event; retain
the returned exact event on safe refusal, and terminal custody on uncertainty.

Before enabling native targets, independently track physical completion and
logical settlement, preserving dependency identities/retains after publication.
Physically progress targets to release source pins without promoting physical
completion to semantic success. Resolve lane-local storage via checked transfer
or genuinely shared bounded native leases; never delete overlap/version guards.

## Cleanup

Recovered 2,279,870,464 allocated bytes by removing only five stale, untracked
host-test ELF files in this worktree's target/debug/deps. A read-only review
checked one hard link and no open handles for each. Kept current binaries,
dependency caches, all evidence, and unrelated user work. No MI300X jobs or
directories were created in this campaign.

Removed basenames:
- fe2o3_host-2cf4148bcf65e09d
- fe2o3_host-58f6f4400a07ddbb
- fe2o3_host-bb8ff53e86a35b3d
- fe2o3_host-7c92bd739e627443
- fe2o3_host-005b8cf814ffa965
