# Diagnostic Operations

This is a manually written operations note, not raw execution output or an
acceptance receipt. Accepted runs must be identified by the final auditor.

- `diagnostic-01/precheck` rejected the enlarged cleanup error type. The private
  bounded scalar-peer count now uses u32 while preserving its public usize getter.
- `diagnostic-02/precheck` rejected a test passing an Instant to a Duration API.
- `diagnostic-03/precheck` passed Clippy, but its source-continuity check rejected
  a concurrently completed witness file. It is not a final-source qualification.
- `diagnostic-build-01/focused` found invalid journal fixture capacities and a
  capture test shutting down without awaiting its accepted drain. Both fixtures
  were corrected; all seven focused filters pass in `diagnostic-build-02`.
- Source metadata `proposal-01` could not reconstruct the old surrounding native
  file after the new Copy adapters were added. `proposal-02` included the exact
  inverse-image hash but became stale after the fixture fixes; it was not applied.
- `proposal-03` was applied. The standalone `verify --label applied` receipt used
  the same name as the helper's temporary receipt. The first workflow invocation
  rejected before creating its output directory or running any workflow command.
  That receipt was preserved by renaming `applied-audit.json` to
  `standalone-audit.json`; the helper was unchanged.
- `source-ci/attempt-01-after` completed all 32 commands: 31 passed and stage 15
  rejected a stale `PINS['producer_readers.rs']` hash. Updating that reviewed
  native-file identity does not change proof bodies, acceptance predicates or
  formal-qualification status. This workflow remains a rejected diagnostic.
- `proposal-04` rejected before emitting a complete proposal because loading a
  baseline composition checker resolved its already-updated on-disk helper.
  Only our exact nine proposal-03 metadata edits were reversed with apply_patch;
  a Git diff confirmed no remaining metadata delta. Runtime sources were untouched.
  `proposal-05` was then generated from the original guards and applied together.
  Its only additional change relative to proposal-03 is the duplicate native-file
  PINS hash identified above. The original external helpers are preserved as
  `propose-current-v1.py` and `support-v1.py`.
- CPU `attempt-01` and source workflow `attempt-02-after` passed, but hardware
  `hardware-01` rejected its first two-device run during upload release, before
  peer admission. The first H2D had succeeded while the second still retained it
  as an implicit stream dependency; the runtime correctly returned Busy. The
  witness now settles every upload before reverse-order release. Runtime sources
  and retention rules were not changed. Hardware-01's exact owned executable and
  directory were removed, no owned processes remained, and final device/process
  admission passed. Its failed campaign is preserved, not relabeled as success.
- The fixed witness uses fresh CPU `attempt-02`, source workflow
  `attempt-03-after`, and hardware `hardware-02`. Proposal-05 still authenticates
  the exact unchanged 1,032-source and 76-proof inventory; the changed example is
  separately bound by the complete CPU source manifests and executable hashes.
- CPU attempt-02 and its source workflow passed, but hardware-02 rejected the
  two-Context process at device admission with ActiveDeviceExists. Post-ACQUIRE_VM
  device admission deliberately lasts until process exit, even after successful
  native queue/allocation cleanup. This is an existing same-process reopen
  restriction, not permission to reset model history. That rejected campaign's
  owned resources were removed and final device/process admission passed.
- The v2 witness accepts explicit `--round 0|1` and performs exactly one round
  and one Context per process. Hardware-03 runs both changed rounds as separately
  bounded processes for every selected GPU ordering. Fresh CPU attempt-03 and
  source workflow attempt-04-after bind the revised example. The final audit,
  not this note, determines whether this final campaign is accepted.
