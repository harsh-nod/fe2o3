#!/usr/bin/env python3
"""Finite, sequential correctness checks on freshly idle GPUs, never a benchmark."""
import hashlib
from functools import lru_cache
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33', '0x189ca857de1ef2fb',
       '0x54f88318ca05093d', '0xb7baafd0fb173d8e', '0x10a254ce4987e716',
       '0x53691ef168a0147d']
CARDS = ['card' + str(index) for index in range(1, 8)]
BD = ['0000:26:00.0', '0000:46:00.0', '0000:65:00.0', '0000:85:00.0',
      '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
BASELINE = json.loads((ROOT / 'initial-availability/stdout').read_text())
CASES = [
    ('pending-2', 'pending', [], IDS[5:]),
    ('pending-3', 'pending', [], IDS[4:]),
    ('pending-5', 'pending', [], IDS[2:]),
    ('pending-7', 'pending', [], IDS),
    ('pending-7-reverse', 'pending', [], IDS[::-1]),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout = (folder / 'stdout').read_bytes()
    stderr = (folder / 'stderr').read_bytes()
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert process.returncode == receipt['exit_code'] == 0, (name, receipt, stderr)
    assert not receipt['timed_out'] and receipt['local_process_group_absent'], (name, receipt)
    return stdout.decode()


def remote(name, argv, bound='30s'):
    return capture(name, SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])])


def admit(name):
    state = json.loads(remote(name + '-availability', ['/opt/rocm/bin/rocm-smi', '--showuse',
        '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']))
    for card, uid, bdf in zip(CARDS, IDS, BD):
        assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == '0'
        assert state[card]['VRAM Total Used Memory (B)'] == BASELINE[card]['VRAM Total Used Memory (B)']
    assert state['system'] == BASELINE['system'], 'changed PID roster; stop and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    # rocm-smi omits the PID->GPU map in JSON mode; accept only its counted text records.
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) and bool(colon) == bool(devices)
        assert pid not in records and not {str(index) for index in range(1, 8)}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system']), (records, state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    return state


@lru_cache(maxsize=1)
def global_digests():
    # Independent Python reference, bounded blocks, no Rust witness output input.
    first, second = hashlib.sha256(), hashlib.sha256()
    translate = bytes(value ^ 73 for value in range(256))
    mask = (1 << 64) - 1
    for start in range(0, 67108901, 262144):
        block = bytearray()
        for offset in range(start, min(start + 262144, 67108901)):
            value = (offset + 0x9e3779b97f4a7c15) & mask
            value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
            value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
            block.append((value ^ (value >> 31)) & 255)
        first.update(block)
        second.update(block.translate(translate))
    return first.hexdigest() + ',' + second.hexdigest()


def expected(kind, flags, ids):
    assert kind == 'pending' and not flags
    count = len(ids)
    quotient, remainder = divmod(67108901, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [sum(sizes[:index]) for index in range(count)]
    return dict(schema='fe2o3.pending-peer-capture-smoke.v1', authority='production-deny-all',
        devices=str(count), unique_ids=','.join(ids), rounds='2',
        total_bytes_per_round='67108901', total_copied_bytes='134217802',
        shard_ranges=','.join(str(offset) + ':' + str(size) for offset, size in zip(offsets, sizes)),
        peer_copies=str(2*count), dependent_readbacks=str(2*count),
        completion_receipts=str(4*count), capture_ranges=str(2*count),
        captured_bytes='134217802', launches='0', journal='enabled',
        admission='all-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_initial='full-byte-pass', destination_sentinel='full-byte-pass',
        source_preservation='unobserved', output='full-byte-pass',
        coverage='exact-contiguous-disjoint', round_sha256=global_digests(), rounds_changed='true',
        allocation_reuse='false', contexts='fresh-per-round', drain='pending-group',
        capture='coherent-host-group', physical_overlap='unmeasured', cleanup='owned-shutdown-explicit',
        performance_acceptance='false', formal_refinement='false')


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in fields
        fields[key] = value
    return fields


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    attempt = sys.argv[1]
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert not (ROOT / 'campaign.json').exists()
    checks = ROOT.parent / attempt / 'checks'
    binaries = {}
    for kind, receipt, basename in [
        ('pending', 'pending-witness.sha256', 'gfx942-runtime-pending-peer-capture-smoke')]:
        digest, path = (checks / receipt).read_text().strip().split(maxsplit=1)
        local = REPO / path
        assert local == REPO / 'target/debug/examples' / basename
        assert sha(local.read_bytes()) == digest
        binaries[kind] = dict(local=str(local), sha256=digest)
    completed, errors = [], []
    directory = None
    cleaned = False
    try:
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-pending-capture-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-multigpu-pending-capture-20261002-[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
            capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            hashed = remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
            assert hashed.split() == [binary['sha256'], binary['remote']]
        for name, kind, flags, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
                '-u', 'HIP_VISIBLE_DEVICES', '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES',
                '-u', 'GPU_DEVICE_ORDINAL', binaries[kind]['remote'], *flags, *ids], '180s')
            fields = pass_fields(output)
            assert fields == expected(kind, flags, ids), (name, fields, expected(kind, flags, ids))
            assert not (ROOT / name / 'stderr').read_bytes()
            completed.append(dict(name=name, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [directory + '/pending-witness']
                probe = ('import json,os,sys; from pathlib import Path; '
                    'paths=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    if 'remote' in binary:
                        try:
                            hashed = remote('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
                            assert hashed.split() == [binary['sha256'], binary['remote']]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        try:
            admit('final')
        except Exception as error:
            errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            owned_directory=directory, owned_cleanup_complete=cleaned, exclusive_reservation=False,
            performance_acceptance=False, formal_refinement=False,
            limitations=['point observations, not continuous attachment census',
                        'native completion counter after cutoff is unobserved',
                        'two fresh contexts; no allocation reuse across rounds',
                        'postcopy source preservation is not observed'])
        with (ROOT / 'campaign.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
