#!/usr/bin/env python3
"""Fail-closed final audit for pending peer -> D2H -> group capture.

Acceptance requires every selected CPU, source and hardware receipt to validate.
This file does not invoke Cargo, SSH, GPU work or proofs.
"""
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'dec70e410699a0fb44ffe4c287e0e2954e1575bd'
CONTROLLER_SHA = '4f42d3901d040401b1e97dfeb85e85e510f26e6375242e61c2d11758cffae73d'
SUPPORT_SHA = '1e8296048364faa7de12a636acfcbb166658c6bf4d102f1cf7953bc8f83f6b63'
WORKFLOW_SHA = '33c8eb8b3bac347669f15e36aadbc736062a635812a95b908dbaba43ef5fae08'
REFERENCE_INPUTS_SHA = '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e'
# Final labels, rosters and hardware schema were reviewed before selection.
# Required: attempt, proposal, workflow, hardware, runtime_passed,
# runtime_ignored, examples, metadata (changed/counts/proof_files/audited_files/
# runtime_files/runtime_and_schema_files), changed_source_paths, added_tests,
# kfd_mode. Hardware schema/controller/case pins are explicit below.
# Observed inventory, rechecked against the proposal and executable rosters by
# this audit. Diagnostic attempts and rejected hardware runs are not selected.
PLANNED = {
    'runtime_passed': 2036,
    'runtime_ignored': 32,
    'examples': {'example': 9, 'production-example': 3,
                 'sharded-example': 7, 'pending-example': 4},
    'metadata': {'changed': 9,
                 'counts': {'content-sha256': 18, 'source-inventory-count': 7},
                 'proof_files': 76, 'audited_files': 1032,
                 'runtime_files': 351, 'runtime_and_schema_files': 356},
    'kfd_mode': 'exact-elf-reuse',
    'changed_source_paths': [
        'crates/fe2o3-runtime-model/verus/check-producer-input-composition.py',
        'crates/fe2o3-runtime-model/verus/check-producer-input-fold.py',
        'crates/fe2o3-runtime-model/verus/check-producer-input-validate.py',
        'crates/fe2o3-runtime-model/verus/check-producer-journal-composition.py',
        'crates/fe2o3-runtime-model/verus/check-producer-journal-observers.py',
        'crates/fe2o3-runtime-model/verus/check-retained-credit-dispatch.py',
        'crates/fe2o3-runtime-model/verus/check-retained-pair-routing.py',
        'crates/fe2o3-runtime-model/verus/producer-journal-composition-mutations-v1.py',
        'crates/fe2o3-runtime-model/verus/test-producer-input-composition.py',
        'crates/fe2o3-runtime/examples/gfx942-runtime-pending-peer-capture-smoke.rs',
        'crates/fe2o3-runtime/src/async_engine.rs',
        'crates/fe2o3-runtime/src/async_engine/current_thread.rs',
        'crates/fe2o3-runtime/src/async_engine/drain_capture.rs',
        'crates/fe2o3-runtime/src/async_engine/drain_capture_storage.rs',
        'crates/fe2o3-runtime/src/async_engine/owned.rs',
        'crates/fe2o3-runtime/src/async_engine/tests/owned_tests.rs',
        'crates/fe2o3-runtime/src/async_engine/tests/owned_tests/drain_capture_group_tests.rs',
        'crates/fe2o3-runtime/src/async_engine/tests/owned_tests/drain_capture_tests.rs',
        'crates/fe2o3-runtime/src/context.rs',
        'crates/fe2o3-runtime/src/context/copy_custody.rs',
        'crates/fe2o3-runtime/src/context/drain_capture.rs',
        'crates/fe2o3-runtime/src/context/generated_issue.rs',
        'crates/fe2o3-runtime/src/context/peer_reconciliation.rs',
        'crates/fe2o3-runtime/src/context/producer_launch.rs',
        'crates/fe2o3-runtime/src/context/tests/copy_custody_tests.rs',
        'crates/fe2o3-runtime/src/context/tests/producer_launch_tests.rs',
        'crates/fe2o3-runtime/src/context/versions/producer_input_preflight_tests.rs',
        'crates/fe2o3-runtime/src/context/versions/producer_readers.rs',
        'crates/fe2o3-runtime/src/context/versions/submissions.rs',
        'crates/fe2o3-runtime/src/kfd_backend.rs',
        'crates/fe2o3-runtime/src/kfd_backend/compute_xgmi/tests.rs',
        'crates/fe2o3-runtime/src/kfd_backend/peer_readback.rs',
        'crates/fe2o3-runtime/src/kfd_backend/peer_readback/tests.rs',
    ],
    'added_tests': [
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capacity_does_not_raise_single_capture_limit_and_accepts_larger_group',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capacity_is_accepted_by_both_transferable_owner_constructors',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_accepts_the_exact_roster_bound',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_allows_overlapping_read_only_ranges_without_reordering',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_checked_extent_overflow_does_not_reserve_or_close',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_closed_admission_refunds_reservation_and_returns_exact_roster',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_current_thread_drop_before_drive_keeps_cutoff_and_completes_capture',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_orders_uneven_ranges_and_retains_one_result_past_owner_shutdown',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_rejection_returns_exact_boxes_and_preserves_open_admission',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_revalidates_the_last_source_before_reading_the_first',
        'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::group_capture_second_read_failure_or_panic_discards_prefix_and_skips_suffix',
        'context::tests::copy_custody_tests::copy_custody_cancellation_releases_only_consumer_leases_and_retains',
        'context::tests::copy_custody_tests::copy_custody_corrupted_parent_or_consumer_fails_closed_before_observation',
        'context::tests::copy_custody_tests::copy_custody_descended_parent_fault_preserves_unknown_or_terminal_roots',
        'context::tests::copy_custody_tests::copy_custody_failed_cancelled_or_unknown_parent_keeps_valid_identity',
        'context::tests::copy_custody_tests::copy_custody_opt_in_and_exact_event_range_are_required_before_issue',
        'context::tests::copy_custody_tests::copy_custody_preissue_rejection_refunds_and_uncertain_issue_retains',
        'context::tests::copy_custody_tests::copy_custody_reconciles_actual_parent_before_readback_commit',
        'context::tests::copy_custody_tests::copy_custody_requires_current_writer_not_previous_completed_event',
        'kfd_backend::compute_xgmi::tests::peer_readback::cancelled_peer_fails_its_readback_without_issuing_a_child_leaf',
        'kfd_backend::compute_xgmi::tests::peer_readback::cancelling_unstarted_readback_keeps_published_peer_and_its_original_owners',
        'kfd_backend::compute_xgmi::tests::peer_readback::peer_readback_authenticates_contained_ranges_and_preserves_capacity_admission',
        'kfd_backend::compute_xgmi::tests::peer_readback::peer_readback_rejects_missing_duplicate_foreign_and_unsupported_profiles_before_effects',
        'kfd_backend::compute_xgmi::tests::peer_readback::peer_readback_terminal_or_unwind_preserves_both_roots_and_never_enters_the_child',
        'kfd_backend::compute_xgmi::tests::peer_readback::pending_native_peer_readback_admits_before_and_after_publication_without_child_custody',
    ],
}
FINAL = dict(PLANNED, attempt='attempt-03', proposal='proposal-05',
             workflow='attempt-04-after', hardware='hardware-03')
WITNESS = 'gfx942-runtime-pending-peer-capture-smoke'

CAPTURE_SHA = 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f'
CAMPAIGN_SHA = 'a831381cd2f5c38498388df0fbf05e59bb15de31041f2a7ea841fa172e2aa864'
PROPOSER_SHA = 'c40f2ac7a73a3d806d5429c3832ac3b8d62defe1f44337d35ebde781fc519c52'
PROPOSER_V1_SHA = '90f389acdf87473c2025e80d81362346cd72628ad6b9275d5f211de20d347210'
SUPPORT_V1_SHA = '9ffec9b88b67a08760c69e5a33f712b21177bd8586ae0df1315258adfd48dcca'
REFERENCE_PROPOSER_SHA = '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50'
IDS = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33', '0x189ca857de1ef2fb',
       '0x54f88318ca05093d', '0xb7baafd0fb173d8e', '0x10a254ce4987e716',
       '0x53691ef168a0147d']
PROFILES = [('pending-2', IDS[5:]), ('pending-3', IDS[4:]), ('pending-5', IDS[2:]),
            ('pending-7', IDS), ('pending-7-reverse', IDS[::-1])]
CASES = [(name + '-round-' + str(round_index), ids, round_index)
         for name, ids in PROFILES for round_index in (0, 1)]
SOURCE_PREFIXES = ('.github/', 'benchmarks/', 'crates/', 'examples/', 'scripts/', 'tests/', 'tools/')
EVIDENCE_PREFIXES = (
    'docs/evidence/dev-completion-reconciliation-proof-2026-09-25/',
    'docs/evidence/dev-completion-leaf-outcomes-2026-09-25/',
    'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/',
    'docs/evidence/dev-xgmi-peer-hot-mi300x-2026-09-19/',
    'docs/evidence/dev-monotonic-wait-arithmetic-2026-10-01/',
)
GUARD_NAMES = {
    'check-request-charge.py', 'check-retained-credit-dispatch.py',
    'check-retained-pair-owned-storage.py', 'check-retained-pair-post-catch.py',
    'check-retained-pair-cadence.py', 'check-producer-input-fold.py',
    'check-producer-input-validate.py', 'check-producer-journal-observers.py',
    'check-retained-pair-routing.py', 'check-producer-input-composition.py',
    'check-producer-journal-composition.py', 'test-producer-input-composition.py',
    'producer-journal-composition-mutations-v1.py',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=REPO)


def manifest(raw):
    pairs = []
    for line in raw.decode().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        assert match, line
        pairs.append(match.groups())
    result = {path: digest for digest, path in pairs}
    assert result and len(result) == len(pairs)
    return result


def roster(raw):
    names = re.findall(r'^(.+): test$', raw.decode(), re.M)
    assert names and len(names) == len(set(names))
    return set(names)


def results(raw):
    pairs = re.findall(r'^test (.+) \.\.\. (ok|ignored)(?:,.*)?$', raw.decode(), re.M)
    result = dict(pairs)
    assert pairs and len(result) == len(pairs)
    return result


def test_result(raw, passed, ignored=0, filtered=0):
    output = raw.decode()
    summaries = [line for line in output.splitlines() if line.startswith('test result:')]
    prefix = f'test result: ok. {passed} passed; 0 failed; {ignored} ignored; 0 measured; {filtered} filtered out; finished in '
    assert len(summaries) == 1 and re.fullmatch(re.escape(prefix) + r'[0-9.]+s', summaries[0])
    observed = results(raw)
    assert list(observed.values()).count('ok') == passed
    assert list(observed.values()).count('ignored') == ignored
    assert not re.search(r'^test .+ \.\.\. FAILED', output, re.M)
    return observed, summaries[0]


def read_json(path):
    return json.loads(path.read_bytes())


def stamp(value):
    result = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    assert result.tzinfo is not None
    return result


def check_sources(sources):
    assert sources
    for name, digest in sources.items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        path = REPO / relative
        assert path.is_file() and not path.is_symlink() and path.resolve() == path
        assert sha(path.read_bytes()) == digest, name


def stage_commands(mode, runtime, kfd):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', '-p', 'fe2o3-runtime']
    compute = 'gfx942-runtime-compute-xgmi-smoke'
    production = 'gfx942-runtime-peer-copy-smoke'
    sharded = 'gfx942-runtime-sharded-peer-copy-smoke'
    pending = WITNESS
    if mode == 'build':
        return {'runtime': (2400, cargo + ['test', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--no-run', '--message-format=json']),
                'kfd-full-list': (60, [kfd, '--list', '--test-threads=1'])}
    if mode in ('focused', 'tests'):
        filters = ('compute_xgmi', 'drain_capture', 'group_tests', 'copy_custody', 'deferred_compute', 'producer_peers', 'multi_open') if mode == 'focused' else ('compute_xgmi', 'packetized', 'full')
        stages = {}
        for selected in filters:
            name = selected if mode == 'focused' else 'fe2o3_runtime-' + selected
            argv = [runtime] + ([] if selected == 'full' else [selected])
            stages[name + '-list'] = (60, argv + ['--list', '--test-threads=1'])
            stages[name] = (1200 if selected == 'full' else 600, argv + ['--test-threads=1'])
        return stages
    assert mode == 'checks'
    patterns = ('crates/fe2o3-kfd/**/*.rs', 'crates/fe2o3-runtime/**/*.rs')
    changed = sorted(set(git('diff', 'HEAD', '--name-only', '--', *patterns).decode().splitlines()) |
                     set(git('ls-files', '--others', '--exclude-standard', '--', *patterns).decode().splitlines()))
    assert changed
    return {
        'rustc': (60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose']),
        'cargo': (60, cargo + ['--version']), 'uname': (60, ['uname', '-a']),
        'clippy': (1200, cargo + ['clippy', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--tests', '--example', compute, '--example', production, '--example', sharded, '--example', pending, '--no-deps', '--', '-D', 'warnings']),
        'no-default': (300, cargo + ['check', *common, '--no-default-features', '--lib', '--example', production, '--example', sharded, '--example', pending]),
        'example': (1200, cargo + ['test', *common, '--all-features', '--example', compute, '--', '--test-threads=1']),
        'production-example': (1200, cargo + ['test', *common, '--no-default-features', '--example', production, '--', '--test-threads=1']),
        'sharded-example': (1200, cargo + ['test', *common, '--example', sharded, '--', '--test-threads=1']),
        'pending-example': (1200, cargo + ['test', *common, '--example', pending, '--', '--test-threads=1']),
        'witness-build': (1200, cargo + ['build', *common, '--all-features', '--profile', 'test', '--example', compute]),
        'production-witness-build': (1200, cargo + ['build', *common, '--no-default-features', '--profile', 'test', '--example', production]),
        'sharded-witness-build': (1200, cargo + ['build', *common, '--profile', 'test', '--example', sharded]),
        'pending-witness-build': (1200, cargo + ['build', *common, '--profile', 'test', '--example', pending]),
        'formatting': (120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *changed]),
        'whitespace': (60, ['git', 'diff', 'HEAD', '--check']),
    }


def audit_cpu(selected, sources, runtime, kfd):
    assert sha((ROOT / 'verify.sh').read_bytes()) == CONTROLLER_SHA
    for mode in ('build', 'focused', 'tests', 'checks'):
        folder = selected / mode
        assert sha((folder / 'controller.sh').read_bytes()) == CONTROLLER_SHA
        assert (folder / 'overall.exit').read_text().strip() == '0'
        assert (folder / 'base.txt').read_text().strip() == BASE
        assert (folder / 'cwd.txt').read_text().strip() == str(REPO)
        environment = dict(line.split('=', 1) for line in (folder / 'environment.txt').read_text().splitlines())
        expected = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', RUST_TEST_THREADS='1', PWD=str(REPO))
        assert all(environment.get(key) == value for key, value in expected.items())
        assert set(environment) <= set(expected) | {'OLDPWD', 'SHLVL', '_'}
        assert manifest((folder / 'source-before.sha256').read_bytes()) == sources
        assert (folder / 'source-before.sha256').read_bytes() == (folder / 'source-after.sha256').read_bytes()
        commands = stage_commands(mode, runtime, kfd)
        assert {path.stem for path in folder.glob('*.exit')} == set(commands) | {'overall'}
        for suffix in ('command', 'started', 'finished', 'stdout', 'stderr'):
            assert {path.stem for path in folder.glob('*.' + suffix)} == set(commands)
        previous = None
        for name, (seconds, argv) in commands.items():
            assert (folder / (name + '.exit')).read_text().strip() == '0'
            assert shlex.split((folder / (name + '.command')).read_text()) == argv
            started = stamp((folder / (name + '.started')).read_text())
            finished = stamp((folder / (name + '.finished')).read_text())
            assert 0 <= (finished - started).total_seconds() <= seconds + 35
            assert previous is None or started >= previous
            previous = finished
    artifacts = [json.loads(line) for line in (selected / 'build/runtime.stdout').read_text().splitlines()]
    assert artifacts[-1].get('reason') == 'build-finished' and artifacts[-1]['success']
    for target, executable in [('fe2o3_runtime', runtime), ('fe2o3_kfd', kfd)]:
        assert Path(executable).parent == REPO / 'target/debug/deps'
        assert re.fullmatch(target + r'-[0-9a-f]+', Path(executable).name)
        emitted = {item['executable'] for item in artifacts if item.get('reason') == 'compiler-artifact'
                   and item.get('target', {}).get('name') == target and item.get('profile', {}).get('test')
                   and item.get('executable')}
        assert emitted == {executable}
        assert manifest((selected / f'build/{target}.sha256').read_bytes()) == {executable: sha(Path(executable).read_bytes())}
    full = roster((selected / 'tests/fe2o3_runtime-full-list.stdout').read_bytes())
    observed, _ = test_result((selected / 'tests/fe2o3_runtime-full.stdout').read_bytes(), FINAL['runtime_passed'], FINAL['runtime_ignored'])
    assert set(observed) == full
    assert set(FINAL['examples']) == {'example', 'production-example', 'sharded-example', 'pending-example'}
    for name, count in FINAL['examples'].items():
        test_result((selected / f'checks/{name}.stdout').read_bytes(), count)
    for mode, prefix, filters in [('focused', '', ('compute_xgmi', 'drain_capture', 'group_tests', 'copy_custody', 'deferred_compute', 'producer_peers', 'multi_open')),
                                  ('tests', 'fe2o3_runtime-', ('compute_xgmi', 'packetized'))]:
        for name in filters:
            listed = roster((selected / mode / (prefix + name + '-list.stdout')).read_bytes())
            assert listed == {test for test in full if name in test}
            actual, _ = test_result((selected / mode / (prefix + name + '.stdout')).read_bytes(), len(listed), filtered=len(full) - len(listed))
            assert set(actual) == listed
    return full, observed


def selected_metadata_node(tree, selector):
    dictionary = re.fullmatch(r"(CHECKER_PINS|HELPERS|PINS)\['([a-z_.-]+)'\]", selector)
    if dictionary:
        name, key = dictionary.groups()
        assert (name == 'PINS' and key == 'producer_readers.rs') or (
            name in ('CHECKER_PINS', 'HELPERS') and re.fullmatch(r'[a-z-]+\.py', key))
        owners = [node.value for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
        assert len(owners) == 1 and isinstance(owners[0], ast.Dict)
        nodes = [value for candidate, value in zip(owners[0].keys, owners[0].values)
                 if isinstance(candidate, ast.Constant) and candidate.value == key]
    elif selector == 'len(implementation) == literal':
        nodes = [node.comparators[0] for node in ast.walk(tree)
                 if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq)
                 and isinstance(node.left, ast.Call) and isinstance(node.left.func, ast.Name)
                 and node.left.func.id == 'len' and len(node.left.args) == 1
                 and isinstance(node.left.args[0], ast.Name) and node.left.args[0].id == 'implementation']
    elif selector.startswith('assertEqual('):
        match = re.fullmatch(r'assertEqual\(len\((native|with_schemas)\), literal\)', selector)
        assert match
        variable = match.group(1)
        nodes = [node.args[1] for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == 'assertEqual'
                 and len(node.args) == 2 and isinstance(node.args[0], ast.Call)
                 and isinstance(node.args[0].func, ast.Name) and node.args[0].func.id == 'len'
                 and len(node.args[0].args) == 1 and isinstance(node.args[0].args[0], ast.Name)
                 and node.args[0].args[0].id == variable]
    else:
        nodes = [node.value for node in tree.body if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == selector for target in node.targets)]
    assert len(nodes) == 1 and isinstance(nodes[0], ast.Constant)
    return nodes[0]


def inverse_observer_sha(owner):
    include = 'include!("producer_journal_observer_bodies.rs");\n'
    assert owner.count(include) == 1
    reconstructed = owner.replace(include, '')
    routes = dict(active_lookup='lookup_producer_read', active_status='producer_read_status',
                  queued_lookup='lookup_queued_producer_read',
                  queued_status='queued_producer_read_status')
    for name, query in routes.items():
        invocation = 'producer_observe_' + name + '_body_v1!(self, reference)'
        assert reconstructed.count(invocation) == 1
        reconstructed = reconstructed.replace(
            invocation, 'self.versions.journal.' + query + '(reference)')
    return sha(reconstructed.encode())


def audit_proposer_extension():
    original = (ROOT / 'source-ci/reference/propose.py').read_text()
    prior = (ROOT / 'source-ci/propose-current-v1.py').read_text()
    current = (ROOT / 'source-ci/propose-current.py').read_text()
    assert sha(original.encode()) == REFERENCE_PROPOSER_SHA
    assert sha(prior.encode()) == PROPOSER_V1_SHA
    assert sha(current.encode()) == PROPOSER_SHA
    hook = """        if hasattr(old, 'NATIVE_PREEXTRACTION_SHA'):
            # Rebind only the surrounding source identity. The unchanged guard
            # still checks every forwarding signature, body, query and proof.
            reconstructed = candidate[old.OWNER].replace(
                'include!("producer_journal_observer_bodies.rs");\\n', '')
            for route, (_reference, _result, query) in old.ROUTES.items():
                reconstructed = reconstructed.replace(
                    'producer_observe_' + route + '_body_v1!(self, reference)',
                    'self.versions.journal.' + query + '(reference)')
            edits.assignment('NATIVE_PREEXTRACTION_SHA', sha(reconstructed.encode()),
                             'content-sha256', 'exact inverse of the unchanged four-call extraction; new Copy adapters are not formally qualified')
"""
    assert prior.count(hook) == 1 and prior.replace(hook, '') == original
    baseline_hook = """
    def baseline_source(name):
        relative = V / name
        original = blobs([relative])[relative]
        current = (ROOT / relative).read_text()
        if current != original:
            receipt = Path(__file__).resolve().parent / 'proposal-03/metadata-report.json'
            raw = receipt.read_bytes()
            need(sha(raw) == '84d49667f2398a73753c57c9140313ee83afc9a25dd8ba2749aaa70a763f6cf1',
                 'exact reviewed already-applied proposal-03 report')
            report = json.loads(raw)
            rows = [row for row in report['changes'] if row['path'] == str(relative)]
            need(report['baseline'] == BASE and len(rows) == 1,
                 'same-baseline exact applied guard identity')
            need(sha(original.encode()) == rows[0]['original_sha256']
                 and sha(current.encode()) == rows[0]['proposed_sha256'],
                 'current guard is exactly the reviewed proposal-03 value')
        return original
"""
    replacements = [
        ('    def pin(self, name, key, value):\n',
         "    def pin(self, name, key, value, rationale='transitive identity of the metadata-only refreshed source guard'):\n"),
        ("        self.constant(selected[0], value, 'content-sha256', f'{name}[{key!r}]',\n"
         "                      'transitive identity of the metadata-only refreshed source guard')\n",
         "        self.constant(selected[0], value, 'content-sha256', f'{name}[{key!r}]', rationale)\n"),
        ('    originals.mkdir()\n', '    originals.mkdir()\n' + baseline_hook),
        ("        original = (ROOT / relative).read_text()\n"
         "        need(original == blobs([relative])[relative], 'unchanged accepted guard: ' + name)\n",
         '        original = baseline_source(name)\n'),
        ("    original = (ROOT / V / name).read_text()\n"
         "    need(original == blobs([V / name])[V / name], 'unchanged duplicate identity tests')\n"
         '    edits = MetadataEdits(original)\n',
         '    original = baseline_source(name)\n    edits = MetadataEdits(original)\n'
         "    edits.pin('PINS', 'producer_readers.rs',\n"
         "              audited[str(RUNTIME / 'context/versions/producer_readers.rs')],\n"
         "              'duplicate whole-native-file identity; new Copy adapters are not formally qualified')\n"),
        ("    original = (ROOT / V / name).read_text()\n"
         "    need(original == blobs([V / name])[V / name], 'unchanged mutation controller')\n",
         '    original = baseline_source(name)\n'),
    ]
    expected = prior
    for before, after in replacements:
        assert expected.count(before) == 1
        expected = expected.replace(before, after)
    assert current == expected
    old_support = (ROOT / 'source-ci/support-v1.py').read_bytes()
    assert sha(old_support) == SUPPORT_V1_SHA
    assert old_support.count(PROPOSER_V1_SHA.encode()) == 1
    assert (ROOT / 'source-ci/support.py').read_bytes() == old_support.replace(
        PROPOSER_V1_SHA.encode(), PROPOSER_SHA.encode())
    prior_report = ROOT / 'source-ci/proposal-03/metadata-report.json'
    assert sha(prior_report.read_bytes()) == '84d49667f2398a73753c57c9140313ee83afc9a25dd8ba2749aaa70a763f6cf1'
    audit_metadata_receipt(prior_report.parent / 'standalone-audit.json', dict(
        changed=9, counts={'content-sha256': 17, 'source-inventory-count': 7},
        audited_files=1032, proof_files=76))


def audit_metadata_receipt(path, expected):
    data = read_json(path)
    recorded = data.pop('recorded_utc_ns')
    assert type(recorded) is int and recorded > 0
    assert data == dict(
        applied_guard_hashes_match_proposal=True,
        ast_identical_except_recorded_metadata_literals=True,
        build_executed=False, changed_files=expected['changed'],
        formal_qualification=False, hash_constants=expected['counts']['content-sha256'],
        solver_executed=False, source_inventory_constants=expected['counts']['source-inventory-count'],
        unchanged_audited_source_files=expected['audited_files'],
        unchanged_proof_files=expected['proof_files'])
    return recorded


def audit_metadata(proposal):
    audit_proposer_extension()
    folder = ROOT / 'source-ci' / proposal
    report = read_json(folder / 'metadata-report.json')
    assert report['baseline'] == BASE
    for flag in ('all_baseline_audits_passed', 'all_proposed_source_audits_passed', 'proof_closures_unchanged',
                 'predicates_contracts_and_proof_counts_unchanged', 'ast_identical_except_listed_metadata_constants'):
        assert report[flag]
    assert not report['solver_executed'] and not report['build_executed'] and not report['formal_qualification']
    counts, changed, patch = {'content-sha256': 0, 'source-inventory-count': 0}, 0, ['*** Begin Patch\n']
    paths = [row['path'] for row in report['changes']]
    assert len(paths) == len(set(paths)) == 13
    assert {Path(path).name for path in paths} == GUARD_NAMES
    for row in report['changes']:
        path = row['path']
        assert Path(path).parent == Path('crates/fe2o3-runtime-model/verus')
        old = (folder / 'originals' / Path(path).name).read_text()
        assert old.encode() == git('show', BASE + ':' + path)
        assert sha(old.encode()) == row['original_sha256']
        tree = ast.parse(old)
        nodes = {(n.lineno, n.col_offset, n.end_lineno, n.end_col_offset): n for n in ast.walk(tree) if isinstance(n, ast.Constant)}
        offsets = [0]
        for line in old.splitlines(keepends=True):
            offsets.append(offsets[-1] + len(line))
        edits = []
        for edit in row['edits']:
            node = nodes[edit['line'], edit['column'], edit['end_line'], edit['end_column']]
            assert node is selected_metadata_node(tree, edit['selector'])
            assert node.value == edit['old']
            category = edit['category']
            counts[category] += 1
            if category == 'content-sha256':
                assert all(isinstance(edit[key], str) and re.fullmatch('[0-9a-f]{64}', edit[key]) for key in ('old', 'new'))
                assert edit['selector'] in {'SOURCE_TREE_SHA', 'RUNTIME_SHA', 'NATIVE_TREE_SHA', 'SCHEMA_TREE_SHA', 'GUARD_SHA', 'NATIVE_PREEXTRACTION_SHA', "PINS['producer_readers.rs']"} or re.fullmatch(r"(?:CHECKER_PINS|HELPERS)\['[a-z-]+\.py'\]", edit['selector'])
                if edit['selector'] == 'NATIVE_PREEXTRACTION_SHA':
                    assert Path(path).name == 'check-producer-journal-observers.py'
                    owner = 'crates/fe2o3-runtime/src/context/versions/producer_readers.rs'
                    assert edit['old'] == inverse_observer_sha(git('show', BASE + ':' + owner).decode())
                    assert edit['new'] == inverse_observer_sha((REPO / owner).read_text())
                elif edit['selector'] == "PINS['producer_readers.rs']":
                    assert Path(path).name == 'test-producer-input-composition.py'
                    owner = 'crates/fe2o3-runtime/src/context/versions/producer_readers.rs'
                    assert edit['old'] == sha(git('show', BASE + ':' + owner))
                    assert edit['new'] == sha((REPO / owner).read_bytes())
            else:
                assert category == 'source-inventory-count'
                assert edit['selector'] in {'SOURCE_FILES', 'RUNTIME_FILES', 'len(implementation) == literal', 'assertEqual(len(native), literal)', 'assertEqual(len(with_schemas), literal)'}
                assert type(edit['old']) is type(edit['new']) is int and edit['new'] > 0
            start = offsets[edit['line'] - 1] + edit['column']
            end = offsets[edit['end_line'] - 1] + edit['end_column']
            assert ast.literal_eval(old[start:end]) == edit['old']
            edits.append((start, end, json.dumps(edit['new'])))
            node.value = edit['new']
        new = old
        for start, end, value in sorted(edits, reverse=True):
            new = new[:start] + value + new[end:]
        assert ast.dump(tree) == ast.dump(ast.parse(new))
        assert sha(new.encode()) == row['proposed_sha256']
        assert (REPO / path).read_bytes() == new.encode()
        if old != new:
            changed += 1
            patch.append('*** Update File: ' + str(REPO / path) + '\n')
            patch.extend(list(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True)))[2:])
    assert ''.join(patch) + '*** End Patch\n' == (folder / 'metadata.patch').read_text()
    expected = FINAL['metadata']
    assert changed == expected['changed'] and counts == expected['counts']
    assert len(report['proof_files']) == expected['proof_files']
    assert len(report['audited_source_sha256']) == expected['audited_files']
    assert report['runtime_source_files'] == expected['runtime_files']
    assert report['runtime_and_schema_files'] == expected['runtime_and_schema_files']
    assert len(list((REPO / 'crates/fe2o3-runtime/src').rglob('*.rs'))) == expected['runtime_files']
    for path, digest in report['proof_files'].items():
        assert sha(git('show', BASE + ':' + path)) == digest, path
    check_sources(report['proof_files'])
    check_sources(report['audited_source_sha256'])
    return report


def audit_workflow(workflow, proposal, report):
    folder = ROOT / 'source-ci' / workflow
    data, inputs = read_json(folder / 'result.json'), read_json(folder / 'inputs.json')
    assert data['accepted'] and data['command_count'] == 32 and data['source_unchanged'] and not data['failed']
    assert not data['solver_invocations'] and not data['build_invocations'] and not data['gpu_invocations']
    assert inputs['head'] == BASE and inputs['workflow_sha256'] == WORKFLOW_SHA
    assert sha((REPO / '.github/workflows/runtime-component-source-guards.yml').read_bytes()) == WORKFLOW_SHA
    reference = ROOT / 'source-ci/reference/inputs.json'
    assert sha(reference.read_bytes()) == REFERENCE_INPUTS_SHA
    assert inputs['commands'] == read_json(reference)['commands']
    assert inputs['source_sha256'] == read_json(folder / 'closing-source.json')
    tracked = git('ls-files', '--cached', '-z').decode().split('\0')
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    names = {name for name in tracked if name and ('/' not in name or name.startswith(SOURCE_PREFIXES + EVIDENCE_PREFIXES))}
    names |= {name for name in untracked if name.endswith('.rs') and name.startswith(SOURCE_PREFIXES)}
    assert set(inputs['source_sha256']) == names
    assert data['source_files'] == len(names)
    check_sources(inputs['source_sha256'])
    assert all(inputs['source_sha256'].get(path) == digest for path, digest in report['audited_source_sha256'].items())
    assert inputs['environment'] == dict(PATH='/usr/bin:/bin', HOME=str(folder / 'home'), TMPDIR=str(folder / 'tmp'), LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_OPTIONAL_LOCKS='0')
    assert len(inputs['commands']) == len(data['commands']) == 32
    previous = None
    for index, (command, record) in enumerate(zip(inputs['commands'], data['commands']), 1):
        stage = folder / f'{index:02}'
        assert record == read_json(stage / 'receipt.json')
        assert [record['step'], record['literal'], record['argv']] == command
        assert record['argv'] == shlex.split(record['literal']) and record['cwd'] == str(REPO)
        assert record['exit'] == 0 and not record['timed_out'] and record['group_absent']
        assert 0 < record['timeout_seconds'] <= 120
        assert 0 <= (record['finished_ns'] - record['started_ns']) / 1e9 <= record['timeout_seconds'] + 10
        assert previous is None or record['started_ns'] >= previous
        previous = record['finished_ns']
        assert sha((stage / 'stdout').read_bytes()) == record['stdout_sha256']
        assert sha((stage / 'stderr').read_bytes()) == record['stderr_sha256']
    support = read_json(folder / 'reused-support.json')
    assert support['metadata_proposal'] == proposal and support['workflow_exit'] == 0 and support['workflow_accepted']
    assert not support['metadata_patch_applied_by_this_support']
    assert sha((ROOT / 'source-ci/support.py').read_bytes()) == SUPPORT_SHA
    proposal_folder = ROOT / 'source-ci' / proposal
    before = proposal_folder / ('before-' + workflow + '-audit.json')
    after = proposal_folder / ('after-' + workflow + '-audit.json')
    assert support['closing_metadata_audit'] == str(after)
    assert audit_metadata_receipt(before, FINAL['metadata']) <= data['commands'][0]['started_ns']
    assert audit_metadata_receipt(after, FINAL['metadata']) >= data['commands'][-1]['finished_ns']



def archive_reader(packet, prefix):
    """Authenticate an archived packet by its SHA256SUMS committed at BASE."""
    pins = manifest(git('show', BASE + ':' + packet + '/SHA256SUMS'))
    path = REPO / packet / 'raw.tar.gz'
    assert path.is_file() and not path.is_symlink()
    digest = sha(path.read_bytes())
    assert digest == pins['raw.tar.gz']
    archive = tarfile.open(path, 'r:gz')
    names = [member.name for member in archive.getmembers()]
    assert len(names) == len(set(names))
    authenticated = {}

    def read(name):
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        member = archive.getmember(prefix + name)
        assert member.isfile() and not member.issym() and not member.islnk()
        raw = archive.extractfile(member).read()
        authenticated[name] = sha(raw)
        return raw

    return archive, read, digest, authenticated


def audit_baseline(runtime_roster, runtime_results, metadata):
    packet = 'docs/evidence/dev-multigpu-shards-2026-10-02'
    archive, prior, digest, authenticated = archive_reader(
        packet, 'fe2o3-multigpu-shards-20261002/')
    try:
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted']
        assert qualification['runtime']['passed'] == 2011
        assert qualification['runtime']['ignored'] == 32
        selected = qualification['attempt']
        old, _ = test_result(prior(selected + '/tests/fe2o3_runtime-full.stdout'), 2011, 32)
        assert set(old) == roster(prior(selected + '/tests/fe2o3_runtime-full-list.stdout'))
        assert set(old) < runtime_roster
        added = runtime_roster - set(old)
        assert added == set(FINAL['added_tests'])
        assert all(name.startswith((
            'kfd_backend::compute_xgmi::tests::peer_readback::',
            'context::tests::copy_custody_tests::',
            'async_engine::tests::owned_tests::drain_tests::capture_tests::group_tests::',
        )) for name in added)
        assert {name for name, state in old.items() if state == 'ignored'} == {
            name for name, state in runtime_results.items() if state == 'ignored'}
        proposal = qualification['source_proposal']
        old_report = json.loads(prior('source-ci/' + proposal + '/metadata-report.json'))
        assert metadata['proof_files'] == old_report['proof_files']
        old_sources = prior(selected + '/build/source-before.sha256')
        assert sha(old_sources) == qualification['source_snapshot_sha256']
        assert old_sources == prior(selected + '/build/source-after.sha256')
        return dict(archive_sha256=digest, added_tests=sorted(added),
                    authenticated_members=authenticated)
    finally:
        archive.close()


def audit_kfd_reuse(selected, current, executable):
    """Reuse is a byte-identical historical run, never a fresh-run claim."""
    if FINAL['kfd_mode'] != 'exact-elf-reuse':
        raise RuntimeError('Fresh KFD schema/roster audit must be implemented before acceptance')
    packet = 'docs/evidence/dev-multigpu-production-peers-2026-10-02'
    archive, prior, digest, authenticated = archive_reader(
        packet, 'fe2o3-multigpu-production-peers-20261002/')
    try:
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted']
        assert qualification['accepted_build_attempt'] == 'attempt-08'
        old_kfd = qualification['kfd']
        assert old_kfd['fresh_full_run'] and old_kfd['disjoint_roster_coverage']
        assert old_kfd['passed'] == 1925 and old_kfd['failed'] == old_kfd['ignored'] == 0
        old_source_raw = prior('attempt-08/build/source-before.sha256')
        assert sha(old_source_raw) == qualification['source_snapshot_sha256']
        assert old_source_raw == prior('attempt-08/build/source-after.sha256')
        old_sources = manifest(old_source_raw)
        kfd_sources = {name: value for name, value in old_sources.items()
                       if name.startswith('crates/fe2o3-kfd/')}
        assert kfd_sources and kfd_sources == {
            name: value for name, value in current.items() if name.startswith('crates/fe2o3-kfd/')}
        executable_hash = sha(executable.read_bytes())
        assert executable_hash == old_kfd['exact_executable_sha256']
        old_executable = prior('attempt-08/build/fe2o3_kfd.path').decode().strip()
        assert manifest(prior('attempt-08/build/fe2o3_kfd.sha256')) == {
            old_executable: executable_hash}
        new_roster_raw = (selected / 'build/kfd-full-list.stdout').read_bytes()
        old_roster_raw = prior('attempt-08/build/kfd-full-list.stdout')
        full = roster(new_roster_raw)
        assert full == roster(old_roster_raw) and len(full) == 1925
        assert prior('attempt-08/build/kfd-full-list.exit').decode().strip() == '0'
        shards = old_kfd['shards']
        assert [part['mode'] for part in shards] == ['0', '1', '2', '3', 'rest']
        heavy = sorted(name for name in full if name.startswith('queue::live::construction_primary::'))
        union = set()
        for part in shards:
            mode = part['mode']
            folder = 'kfd-shard-' + mode + '/'
            raw = prior(folder + 'result.json')
            assert sha(raw) == part['result_sha256']
            data = json.loads(raw)
            inputs = json.loads(prior(folder + 'inputs.json'))
            stdout = prior(folder + 'run.stdout')
            assert data['accepted'] and data['exit_code'] == 0 and not data['timed_out']
            assert data['executable_unchanged'] and data['group_absent']
            assert 0 <= data['elapsed_seconds'] <= 1235
            assert stamp(data['finished']) >= stamp(data['started'])
            assert data['stdout_sha256'] == sha(stdout)
            assert data['stderr_sha256'] == sha(prior(folder + 'run.stderr'))
            expected = sorted(full - set(heavy)) if mode == 'rest' else heavy[int(mode)::4]
            assert inputs['selected'] == expected and len(expected) == part['passed']
            assert roster(prior(folder + 'list.stdout')) == set(expected)
            assert inputs['executable_sha256'] == executable_hash and inputs['cwd'] == str(REPO)
            assert inputs['argv'] == [old_executable, '--test-threads=1', '--exact', *expected]
            assert inputs['environment'] == dict(
                HOME='/home/harsh', PATH='/usr/bin:/bin', LANG='C.UTF-8',
                LC_ALL='C.UTF-8', RUST_TEST_THREADS='1')
            assert inputs['controller_sha256'] == sha(prior('kfd_shard.py'))
            assert inputs['source_manifest_sha256'] == sha(old_source_raw)
            assert inputs['full_roster_sha256'] == sha(old_roster_raw)
            assert inputs['total_roster'] == len(full)
            passed, summary = test_result(stdout, len(expected), filtered=len(full) - len(expected))
            assert data['summary'] == [summary] and set(passed) == set(expected)
            assert set(passed.values()) == {'ok'} and not union.intersection(passed)
            assert not prior(folder + 'run.stderr') and not prior(folder + 'list.stderr')
            union.update(passed)
        assert union == full
        return dict(passed=len(full), failed=0, ignored=0, fresh_run=False,
                    exact_elf_reuse=True, executable_sha256=executable_hash,
                    unchanged_source_files=len(kfd_sources), archive_sha256=digest,
                    authenticated_members=authenticated)
    finally:
        archive.close()


def receipt(folder, seconds):
    data = read_json(folder / 'result.json')
    assert data['exit_code'] == 0 and not data['timed_out']
    assert data['local_process_group_absent']
    assert data['stdout_sha256'] == sha((folder / 'stdout').read_bytes())
    assert data['stderr_sha256'] == sha((folder / 'stderr').read_bytes())
    assert 0 <= data['elapsed_seconds'] <= seconds
    assert stamp(data['finished']) >= stamp(data['started'])
    return data


def parse_pass(raw):
    lines = raw.decode().splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS ')
    pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
    assert pairs and all(len(pair) == 2 and all(pair) for pair in pairs)
    fields = dict(pairs)
    assert len(fields) == len(pairs)
    return fields


def expected_shards(total_bytes, count):
    assert type(total_bytes) is int and total_bytes > 0
    assert type(count) is int and 2 <= count <= 8
    quotient, remainder = divmod(total_bytes, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    assert sizes[0] > 0 and sum(sizes) == total_bytes
    assert all(a + n == b for a, n, b in zip(offsets, sizes, offsets[1:]))
    assert offsets[-1] + sizes[-1] == total_bytes
    return offsets, sizes


def independent_pattern_digests(total_bytes):
    """The existing sharded global-offset pattern; verify new witness before use."""
    first, second = hashlib.sha256(), hashlib.sha256()
    translate = bytes(value ^ 73 for value in range(256))
    mask = (1 << 64) - 1
    for start in range(0, total_bytes, 8192):
        block = bytearray()
        for offset in range(start, min(start + 8192, total_bytes)):
            value = (offset + 0x9e3779b97f4a7c15) & mask
            value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & mask
            value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & mask
            block.append((value ^ (value >> 31)) & 255)
        first.update(block)
        second.update(block.translate(translate))
    assert first.digest() != second.digest()
    return [first.hexdigest(), second.hexdigest()]


def hardware_expected(ids, round_index, digests):
    count = len(ids)
    assert round_index in (0, 1) and len(digests) == 2 and digests[0] != digests[1]
    offsets, sizes = expected_shards(67108901, count)
    return dict(
        schema='fe2o3.pending-peer-capture-smoke.v2', authority='production-deny-all',
        devices=str(count), unique_ids=','.join(ids), round=str(round_index), rounds='1',
        total_bytes_per_round='67108901', total_copied_bytes='67108901',
        shard_ranges=','.join(f'{offset}:{size}' for offset, size in zip(offsets, sizes)),
        peer_copies=str(count), dependent_readbacks=str(count),
        completion_receipts=str(2 * count), capture_ranges=str(count),
        captured_bytes='67108901', launches='0', journal='enabled',
        admission='all-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_initial='full-byte-pass', destination_sentinel='full-byte-pass',
        source_preservation='unobserved', output='full-byte-pass',
        coverage='exact-contiguous-disjoint', round_sha256=digests[round_index],
        allocation_reuse='false', contexts='one-per-process', drain='pending-group',
        capture='coherent-host-group', physical_overlap='unmeasured',
        cleanup='owned-shutdown-explicit', performance_acceptance='false',
        formal_refinement='false')


def audit_hardware(hw, selected):
    data = read_json(hw / 'campaign.json')
    assert data['accepted'] and data['owned_cleanup_complete'] and not data['errors']
    assert not data['performance_acceptance'] and not data['formal_refinement'] and not data['exclusive_reservation']
    assert len(data['completed']) == data['expected_cases'] == 10
    assert [item['name'] for item in data['completed']] == [name for name, _, _ in CASES]
    assert data['limitations'] == [
        'point observations, not continuous attachment census',
        'native completion counter after cutoff is unobserved',
        'one context per process; no allocation reuse across rounds',
        'ACQUIRE_VM admission lasts until process exit; same-process reopen is unsupported',
        'postcopy source preservation is not observed']
    assert sha((hw / 'capture.py').read_bytes()) == CAPTURE_SHA
    assert sha((hw / 'campaign.py').read_bytes()) == CAMPAIGN_SHA
    directory = data['owned_directory']
    assert re.fullmatch(r'/tmp/fe2o3-multigpu-pending-capture-20261002-[A-Za-z0-9]{6}', directory)
    assert set(data['binaries']) == {'pending'}
    binary = data['binaries']['pending']
    path = 'target/debug/examples/gfx942-runtime-pending-peer-capture-smoke'
    assert binary['local'] == str(REPO / path) and binary['remote'] == directory + '/pending-witness'
    assert manifest((selected / 'checks/pending-witness.sha256').read_bytes()) == {path: binary['sha256']}
    assert sha((REPO / path).read_bytes()) == binary['sha256']
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
    receipts, previous = {}, None

    def capture(name, argv, bound='30s', local=False):
        nonlocal previous
        folder = hw / name
        record = receipt(folder, 245)
        expected = argv if local else ssh + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]
        assert record['argv'] == expected, name
        assert previous is None or stamp(record['started']) >= previous, name
        previous = stamp(record['finished'])
        receipts[name] = sha((folder / 'result.json').read_bytes())
        return (folder / 'stdout').read_text()

    availability = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']
    baseline = json.loads(capture('initial-availability', availability))

    def admission(name):
        state = json.loads(capture(name + '-availability', availability))
        buses = ['0000:26:00.0', '0000:46:00.0', '0000:65:00.0', '0000:85:00.0',
                 '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
        for index, (uid, bus) in enumerate(zip(IDS, buses), 1):
            card = 'card' + str(index)
            assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bus
            assert state[card]['GPU use (%)'] == '0'
            assert state[card]['VRAM Total Used Memory (B)'] == baseline[card]['VRAM Total Used Memory (B)']
        assert state['system'] == baseline['system']
        mapping = capture(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        pids = {}
        for item in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = item.groups()
            devices = [] if devices is None else devices.split()
            assert pid not in pids and int(count) == len(devices) == len(set(devices))
            assert bool(colon) == bool(devices)
            assert not {str(index) for index in range(1, 8)}.intersection(devices)
            pids[pid] = devices
        assert {'PID' + pid for pid in pids} == set(state['system'])
        assert all(int(state['system']['PID' + pid].split(',')[1]) == len(devices) for pid, devices in pids.items())
        memory = capture(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024

    admission('baseline')
    assert capture('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-pending-capture-20261002-XXXXXX']).strip() == directory
    capture('upload-pending', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']], local=True)
    assert capture('initial-hash-pending', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    digests = independent_pattern_digests(67108901)
    for reported, (name, ids, round_index) in zip(data['completed'], CASES):
        admission(name)
        argv = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-u', 'HIP_VISIBLE_DEVICES',
                '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES', '-u', 'GPU_DEVICE_ORDINAL', binary['remote'], '--round', str(round_index), *ids]
        lines = capture(name, argv, '180s').splitlines()
        assert len(lines) == 1 and lines[0].startswith('PASS ')
        pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
        assert all(len(pair) == 2 and all(pair) for pair in pairs)
        fields = dict(pairs)
        assert len(fields) == len(pairs) and fields == reported['fields'] == hardware_expected(ids, round_index, digests)
        assert not (hw / name / 'stderr').read_bytes()
    paths = [binary['remote']]
    probe = ('import json,os,sys; from pathlib import Path; '
        'paths=set(sys.argv[1:]); found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    assert json.loads(capture('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])) == {'owned_executable_pids': []}
    assert capture('final-hash-pending', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    assert not capture('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    assert not capture('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    assert not capture('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    admission('final')
    assert {path.name for path in hw.iterdir() if path.is_dir()} == set(receipts)
    return dict(campaign=data, receipt_sha256=receipts)


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1
    assert FINAL is not None, 'Audit scaffold is not finalized; no acceptance may be emitted'
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert not (ROOT / 'qualification.json').exists()
    attempt, proposal, workflow, hardware = [
        FINAL[key] for key in ('attempt', 'proposal', 'workflow', 'hardware')]
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert re.fullmatch(r'proposal-[0-9]+', proposal)
    assert re.fullmatch(r'attempt-[0-9]+-after', workflow)
    assert re.fullmatch(r'hardware-[a-z0-9-]+', hardware)
    selected = ROOT / attempt
    snapshot = (selected / 'build/source-before.sha256').read_bytes()
    sources = manifest(snapshot)
    tracked = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
                  'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo')
    assert set(sources) == {name.decode() for name in tracked.split(b'\0') if name}
    check_sources(sources)
    changed = set(git('diff', BASE, '--name-only', '--', 'crates', 'Cargo.toml',
                      'Cargo.lock', 'rust-toolchain.toml', '.cargo').decode().splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard', '--', 'crates',
                       'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo').decode().splitlines())
    assert changed == set(FINAL['changed_source_paths'])
    runtime = Path((selected / 'build/fe2o3_runtime.path').read_text().strip())
    kfd = Path((selected / 'build/fe2o3_kfd.path').read_text().strip())
    full, observed = audit_cpu(selected, sources, str(runtime), str(kfd))
    runtime_hash = sha(runtime.read_bytes())
    for phase in ('before', 'after'):
        assert manifest((selected / f'tests/fe2o3_runtime-{phase}.sha256').read_bytes()) == {
            str(runtime): runtime_hash}
    metadata = audit_metadata(proposal)
    audit_workflow(workflow, proposal, metadata)
    baseline = audit_baseline(full, observed, metadata)
    kfd_receipt = audit_kfd_reuse(selected, sources, kfd)
    hardware_receipt = audit_hardware(ROOT / hardware, selected)
    check_sources(sources)
    assert sha(runtime.read_bytes()) == runtime_hash
    assert sha(kfd.read_bytes()) == kfd_receipt['executable_sha256']
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    result = dict(
        accepted=True, audited_at=datetime.now(timezone.utc).isoformat(), baseline=BASE,
        attempt=attempt, source_proposal=proposal, source_workflow=workflow, hardware=hardware,
        audit_sha256=sha(Path(__file__).read_bytes()), controller_sha256=CONTROLLER_SHA,
        source_snapshot_sha256=sha(snapshot), source_files=len(sources),
        runtime=dict(passed=FINAL['runtime_passed'], ignored=FINAL['runtime_ignored'],
                     failed=0, exact_roster=True, executable_sha256=runtime_hash),
        added_tests=baseline['added_tests'], kfd=kfd_receipt,
        source_controls=32, strict_clippy=True, no_default_check=True,
        examples=FINAL['examples'], hardware_receipt=hardware_receipt,
        baseline_receipt=baseline, performance_acceptance=False, formal_refinement=False)
    with (ROOT / 'qualification.json').open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
