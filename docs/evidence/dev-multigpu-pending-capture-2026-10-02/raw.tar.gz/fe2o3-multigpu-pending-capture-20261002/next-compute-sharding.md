# Next A3 Gate: Finite Vecadd Compute Shards

Read-only design against `dec70e410699a0fb44ffe4c287e0e2954e1575bd` plus
the in-progress pending-peer/readback/group-capture increment. No repository
source, old qualification policy, compiler artifact, or proof was changed.

## Recommended First Workload

Use the existing repository-owned `vecadd` object to partition exactly **65,537
f32 elements**, independent of the number of selected devices. For ordered,
distinct explicit UIDs, `2 <= N <= 8`, shard `i` has
`n_i = floor(65537/N) + (i < 65537%N)` and the prefix-sum global offset `o_i`.
Each device computes only its own `C_i = A_i + B_i`. Re-running the original
65,536-element fixture independently on N devices is replication, not this gate.

For two finite rounds `r in {0,1}`, use exact integer-valued f32 data:

- `A_i[j] = (o_i + j + 131072*r) as f32`.
- `B_i[j] = (3+r) as f32`.
- `C_i[j]` starts at `-1.0`; expected output is `o_i+j+3+131073*r`.
- These integers and sums are exactly representable as f32, so verify bits,
  not approximate tolerances. No output data may be installed by the host after
  compute admission.

Use one fresh process, one Context, and one one-shot gate per device per round.
Select the round explicitly and aggregate the two process receipts in the
external controller. A fresh Context in the same process is not sufficient:
after `ACQUIRE_VM`, device admission deliberately retains active process-lifetime
model history even after successful queue/allocation/descriptor shutdown.
Default admission already increments generations, but a new generation cannot
replace that active physical-device entry. Do not clear history or weaken
`ActiveDeviceExists`. Separate processes avoid adding replay/reopen semantics
or falsely claiming allocation reuse across cutoffs.

## Important Existing Constraint

The existing `vecadd.ll` bounds every access by all three explicit slice
lengths, so it already supports uneven logical lengths. Its workgroup size is
256. Use grid `ceil(n_i/256)*256`, workgroup `[256,1,1]`, and three exact
little-endian u64 lengths `n_i` in the unchanged 48-byte ABI. Extra lanes exit.

However, `compute_dispatch.rs::three_binding_persistent_ready_source_v1`
requires matching logical and physical allocation extents. Allocating bare
`4*n_i` bytes would fail persistent admission for non-page-sized shards.
Do not relax that existing predicate. Allocate each A/B/C as
`p_i = align_up(4*n_i,4096)`, initialize every byte, and bind each whole
`p_i`-byte allocation at offset zero. Kernel lengths remain `n_i`, not `p_i/4`.
Use exact padding values A=-7, B=-11, C=-1 and verify output padding stays -1.
This preserves the current full-allocation, equal-extent R/R/W shape.

Example sizes: N=2 has element counts `[32769,32768]` and padded byte extents
`[135168,131072]`; N=3 has `[21846,21846,21845]`; N=8 has one 8193-element
shard and seven 8192-element shards. Total padded output is at most 286,720
bytes for N=2..8; meaningful global output is always 262,148 bytes. Padding and
the small variation in launched idle lanes are not additional logical work.

## New Authority, Unchanged Old Policies

Add an independent, feature-gated **qualification** policy. Do not broaden
`qualification_gfx942_r57_n3_v1.rs`, its V1/V2 signatures, fixed extents/data,
two-launch `A+B->C; C+B->D` state machine, or the existing repeat policy.

Suggested new files/API:

- `fixtures/trusted-gfx942-sharded-vecadd-v1/policy-v1.txt`: new profile identity,
  signature, fixed global extent, finite N/index/round domain, padded layout,
  exact data formula, one-shot phase, ABI and geometry rules.
- `src/qualification_gfx942_sharded_vecadd_v1.rs`: checked immutable shard
  recipe; non-cloneable admitted one-shot gate; typed arguments carrying the
  new policy signature and exact full-buffer bindings. A proposed constructor
  is `admit_gfx942_sharded_vecadd_qualification_v1(N,index,round)`; it must
  reject parameters outside the finite 70 recipe combinations.
- `src/lib.rs`: new module only behind `hardware-qualification`.
- `src/kfd_backend.rs`: new independently dispatched launch-gate variant and
  Debug/authorization cases, leaving every existing variant unchanged.
- `src/kfd_backend/multi_qualification.rs` or a narrowly registered sibling:
  `open_gfx942_sharded_vecadd_peer_qualification_v1(unique_ids,round)` constructs
  the per-index gates, validates every recipe and UID before native admission,
  then uses the existing `open_default_with_gate_policy_v1(gates,true)` path.
  The current no-argument gate factory cannot assign shard indices by itself;
  use a dedicated indexed roster construction, not shared mutable gate state.
- `examples/gfx942-runtime-sharded-vecadd-capture-smoke.rs` and a
  `required-features=["hardware-qualification"]` example registration.

Reuse the unchanged `trusted-gfx942-vecadd-v1/{vecadd.ll,vecadd.hsaco}` bytes.
The new admission must independently validate source/object/policy hashes,
AMDHSA envelope and selected-kernel closure, exact six argument rows, required
workgroup size, no hidden args/LDS/scratch, and pinned object identity. At final
authorization require Ordinary semantics, exact module bytes/hash, new signature,
kernel name, complete 48-byte kernarg/template, exact n_i values, exact padded
geometry, three distinct DeviceLocal allocation identities, complete p_i-byte
R/R/W bindings, alignment, and all three initial whole-allocation content
digests. Deny replay after the single accepted launch. Wrong-shard content,
geometry, lengths, aliases, offsets, policy identity or metadata must not consume
a still-unaccepted gate; a consumed gate must never be reset after publication
or an ambiguous error.

This is not a safe implementation of general production
`KfdRuntimeLaunchAuthorityV1`. That unsafe trait explicitly requires authenticated
compiler lineage and invocation-specific device-memory-effect evidence;
descriptive hashes/structural metadata are insufficient. Keep the new gate under
the same explicit trusted-artifact qualification boundary as existing fixtures.
The existing rebuild script pins ROCm clang 22/roc-7.2.4 and proves byte identity,
not compiler correctness or machine-level memory refinement.

## Smallest Working Composition

1. Open all admitted UIDs before any VM/queue. Allocate initialized page-sized
   A/B/C and a distinct incoming peer allocation on every child; incoming size
   equals the predecessor's p_i, not the local child's p_i. Prepare native
   HostVisible upload/output storage and the capture tokens before cutoff.
2. Use existing typed launches/current-thread progress to admit all N shard
   kernels and obtain N exact successful completion receipts. Explicitly join
   compute and restore its allocation owners before admitting peer copies.
3. Admit all N full-extent ring copies `C_i -> incoming_(i+1)` before any peer
   progress. Record their exact events, admit each same-child HostVisible D2H
   continuation on its destination child, register individual callbacks and
   release the public events.
4. Begin the existing group-capture cutoff while every peer/readback remains
   pending; progress only the readback streams. Require N peer and N readback
   success receipts in addition to a Quiescent drain report. Capture full p_i
   ranges in source-shard order. Verify every meaningful output element and
   every padding byte; gather only each range's first 4*n_i bytes to form the
   one global 65,537-element result and compare its independently calculated
   digest. Require explicit owned shutdown and complete native cleanup.

The explicit compute join is important: `compute_xgmi.rs::prepare_compute_xgmi_v1`
chooses the native route at admission and accepts ready/restored owners, not
`ComputeInFlight`. Admitting a peer behind a still-pending compute producer can
select the staged route instead. An entirely prequeued compute->native-peer->D2H
graph is a separate deferred-route-selection and journal gate, not a claim of
this minimal workload. No new scheduler, lower queue primitive, or kernel is
needed for the joined-compute first witness.

The pending capture owner currently cannot expose the final native counter
after cutoff. Keep `native_counter_observed=false`, as in the current pending
witness, unless a separately scoped read-only observer is added later. Exact
pending-readback admission establishes the retained parent profile, not a new
counter observation. Destination capture alone also does not prove post-copy
source preservation or physical execution overlap.

## Qualification Prerequisites

- First close the current backend/Context/pending-capture CPU and hardware gate.
  Preserve its failures and do not label a design note as executed coverage.
- CPU tests enumerate N=2..8 and both rounds: contiguous nonempty coverage,
  fixed logical total, checked padding/grid arithmetic, exact ABI lengths,
  logical/physical distinction, and reference output/padding. In particular
  exercise N=2's unequal physical extents and non-workgroup-multiple tails.
- Authority negatives mutate each authenticated field; test foreign R57/V1/V2/
  repeat signatures in both directions, one-shot replay, wrong shard/index/data,
  duplicate allocations, non-full bindings, wrong length/geometry, partial/stale
  initialization, semantic profile, and altered source/object/policy bytes.
- Compose actual router/Context/owner CPU seams: page-sized R/R/W readiness,
  peer route selection only after compute restoration, unequal ring extents,
  exact pending-parent event retention, D2H/group capture, failures/cancellation,
  callback identity and explicit cleanup. Synthetic native completion is not
  hardware execution or machine-code evidence.
- Rebuild the unchanged object with the existing pinned compiler script and
  preserve exact tool/source/object identities. Run focused tests, strict
  Clippy, feature/no-default checks, full relevant CPU suites and unchanged
  source/proof guards. Any optional new arithmetic proof covers the actual
  recipe arithmetic only; it does not verify GPU execution or the whole adapter.
- Hardware: fresh attachment/PID/memory/activity/topology admission for every
  chosen UID; N=2,3,5 and the largest genuinely free roster, plus reverse order;
  N=8 remains CPU-only unless all eight devices are genuinely available. Verify
  both changed rounds in separate processes and all gathered bytes, record artifact identities and
  per-phase exact receipts, then remove only owned binaries/scratch and confirm
  the baseline device/process state. No resets, warm-up authority broadening,
  reservations inferred only from idle%, or performance/overlap claims.

This is a correctness and finite-artifact sharding checkpoint. It does not
establish broad Rust/device-language authority, machine-code refinement,
arbitrary kernels, HIP/HSA API parity, speedup, or orders-of-magnitude gains.
