#!/usr/bin/env bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo test -p fe2o3-verifier --lib --offline
cargo test -p fe2o3-verifier --doc compiler_proof_broker_v1 --offline
cargo test -p cargo-fe2o3 --bin cargo-fe2o3 capability_broker:: --offline
CARGO_PROFILE_DEV_OPT_LEVEL=1 cargo clippy -p fe2o3-verifier -p cargo-fe2o3 --lib --bins --no-deps --offline -- -D warnings
rustfmt --check --edition 2024 crates/fe2o3-verifier/src/compiler_proof_broker_v1.rs crates/fe2o3-verifier/src/functional_refinement_runtime_v1.rs crates/fe2o3-verifier/src/functional_refinement_receipt_v2.rs crates/fe2o3-verifier/src/retained_functional_refinement_runtime_v1.rs crates/fe2o3-verifier/src/functional_refinement_process_tree_v1_linux.rs crates/fe2o3-verifier/src/retained_functional_refinement_runtime_v1_linux.rs crates/fe2o3-verifier/src/lib.rs crates/cargo-fe2o3/src/capability_broker.rs
git diff --check
