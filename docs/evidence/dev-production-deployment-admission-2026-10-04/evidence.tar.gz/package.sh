#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-production-deployment-20261004-pDEq7AJa
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-production-deployment-admission-2026-10-04"
test "$(<"$scratch/regression.status")" = 0
test "$(<"$scratch/host.status")" = 0
test "$(<"$scratch/qualified-4/status")" = 0
test "$(<"$scratch/remote-observation-probe.status")" = 0
cmp "$scratch/qualified-4/binaries.before.sha256" "$scratch/qualified-4/binaries.after.sha256"
cd "$repo"
git diff --binary HEAD -- Cargo.lock \
    crates/fe2o3-compiler-closure-capability/src/compiler_execution_client_profile.rs \
    crates/fe2o3-compiler-closure-capability/src/compiler_execution_production_deployment.rs \
    crates/fe2o3-compiler-closure-capability/src/compiler_execution_production_deployment/tests.rs \
    crates/fe2o3-compiler-closure-capability/src/lib.rs \
    crates/fe2o3-host/Cargo.toml \
    crates/fe2o3-host/src/compiler_execution_current_record_audit.rs \
    crates/fe2o3-host/src/compiler_execution_current_record_audit/tests.rs \
    crates/fe2o3-host/src/compiler_execution_current_record_audit/tests/production.rs \
    crates/fe2o3-host/src/generated_kfd_arguments.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/pending.rs \
    > "$scratch/code.patch"
cd "$scratch"
sha256sum code.patch cap-config/* host-config/* > evidence-files.sha256
tar --sort=name --mtime=2026-10-04T00:00:00Z --owner=0 --group=0 --numeric-owner \
    -czf "$evidence/evidence.tar.gz" \
    code.patch evidence-files.sha256 package.sh check.sh check-host.sh regression.sh \
    inside-root.sh qualify.sh full-map \
    capability-final.log capability-doc-final.log capability-clippy-final.log \
    capability-build.json capability-build.log \
    host.log host-doc.log host-clippy.log host.status host-build.json host-build.log \
    host-support.log host-tests-clippy.log vertical-regression.log v2-regression.log \
    formatting.log whitespace.log regression.status \
    development-lock.log development-test-api.log development-existing-lint.log \
    remote-observation-probe.c probe.sh remote-observation-build.log \
    remote-observation-probe.log remote-observation-probe.status \
    remote-observation-initial.log remote-observation-initial.status \
    cap-fixture.log host-fixture.log cap-config host-config \
    qualification qualification.status qualified-2 qualified-3 qualified-4
sha256sum code.patch "$evidence/evidence.tar.gz"
