#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-production-deployment-20261004-pDEq7AJa
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly campaign="$scratch/${1:?fresh campaign name}"
readonly cap_binary=$(jq -r 'select(.reason=="compiler-artifact" and .profile.test and .executable!=null) | .executable' "$scratch/capability-build.json")
readonly host_binary=$(jq -r 'select(.reason=="compiler-artifact" and .profile.test and .executable!=null) | .executable' "$scratch/host-build.json")
readonly cap_test=compiler_execution_production_deployment::tests::fixed_production_paths
readonly host_test=compiler_execution_current_record_audit::tests::production::installed_production_audit
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
mkdir -m 700 "$campaign"
if [[ ! -d $scratch/cap-config ]]; then
mkdir -m 700 "$scratch/cap-config" "$scratch/host-config"
FE2O3_PRODUCTION_DEPLOYMENT_FIXTURE_OUT="$scratch/cap-config" "$cap_binary" \
    compiler_execution_production_deployment::tests::write_fixed_path_qualification_fixture --ignored --exact > "$scratch/cap-fixture.log" 2>&1
FE2O3_PRODUCTION_DEPLOYMENT_FIXTURE_OUT="$scratch/host-config" "$host_binary" \
    compiler_execution_current_record_audit::tests::production::write_configuration --ignored --exact > "$scratch/host-fixture.log" 2>&1
fi
trap 'printf "%s\n" "$?" > "$campaign/status"' EXIT
sha256sum "$cap_binary" "$host_binary" > "$campaign/binaries.before.sha256"
run() {
    local name=$1 source=$2 binary=$3 test_name=$4 expected=$5 case_name=$6 mutation=$7
    local run="$campaign/$name"
    mkdir -m 700 "$run" "$run/control"
    timeout --kill-after=5s 60s /mnt/c/Windows/System32/wsl.exe --user root --exec \
        /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
        --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp --tmpfs /etc \
        --bind "$scratch" "$scratch" \
        --setenv LD_LIBRARY_PATH "$LD_LIBRARY_PATH" \
        --setenv FE2O3_PRODUCTION_DEPLOYMENT_CONTROL "$run/control" \
        --setenv FE2O3_PRODUCTION_DEPLOYMENT_EXPECT "$expected" \
        --setenv FE2O3_PRODUCTION_DEPLOYMENT_OVERMAP "$mutation" \
        --setenv FE2O3_PRODUCTION_AUDIT_CASE "$case_name" \
        --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_ADMIN \
        /bin/bash "$scratch/inside-root.sh" "$source" "$binary" "$test_name" "$case_name" "$mutation" \
        > "$run/test.log" 2>&1
    printf '0\n' > "$run/status"
}
run cap-positive "$scratch/cap-config" "$cap_binary" "$cap_test" accept unused none
for mutation in mutable wrongowner symlink wronglink wronglength mismatch root; do
    run "cap-$mutation" "$scratch/cap-config" "$cap_binary" "$cap_test" reject unused "$mutation"
done
run cap-mapped "$scratch/cap-config" "$cap_binary" "$cap_test" reject-map unused mapped
run cap-overmap "$scratch/cap-config" "$cap_binary" "$cap_test" reject unused overmap
for case_name in good supplied policy pre service_failure stale_success stale_failure late_binding retained wrong_signer; do
    run "host-$case_name" "$scratch/host-config" "$host_binary" "$host_test" unused "$case_name" none
done
run host-reject "$scratch/host-config" "$host_binary" "$host_test" unused reject wrongowner
sha256sum "$cap_binary" "$host_binary" > "$campaign/binaries.after.sha256"
cmp "$campaign/binaries.before.sha256" "$campaign/binaries.after.sha256"
