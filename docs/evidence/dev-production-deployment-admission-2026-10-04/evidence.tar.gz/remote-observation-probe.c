#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <linux/capability.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static void require(int ok, const char *what) {
    if (!ok) { perror(what); exit(1); }
}

int main(void) {
    alarm(20);
    require(geteuid() == 0, "private root probe");
    pid_t target = fork();
    require(target >= 0, "fork target");
    if (target == 0) {
        alarm(15);
        require(chdir("/tmp") == 0, "target cwd");
        int fd = open("/dev/null", O_RDONLY);
        require(fd >= 0 && dup2(fd, 199) == 199, "target descriptor");
        if (fd != 199) close(fd);
        require(setgroups(0, NULL) == 0, "target groups");
        require(setresgid(1000, 1000, 1000) == 0, "target gids");
        require(setresuid(1000, 1000, 1000) == 0, "target uids");
        require(prctl(PR_SET_DUMPABLE, 1) == 0, "ordinary target dumpability");
        raise(SIGSTOP);
        _exit(0);
    }
    int status;
    require(waitpid(target, &status, WUNTRACED) == target && WIFSTOPPED(status), "target readiness");
    int pidfd = syscall(SYS_pidfd_open, target, 0);
    require(pidfd >= 0, "open owned target pidfd");
    int fd = syscall(SYS_pidfd_getfd, pidfd, 199, 0);
    require(fd >= 0, "privileged pidfd_getfd control");
    close(fd);
    puts("root observer with CAP_SYS_PTRACE: pidfd_getfd passed");
    fflush(stdout);
    pid_t observer = fork();
    require(observer >= 0, "fork observer");
    if (observer == 0) {
        alarm(10);
        for (int cap = 0; cap < 64; ++cap) {
            if (prctl(PR_CAPBSET_DROP, cap, 0, 0, 0) < 0) require(errno == EINVAL, "drop bounding capability");
        }
        require(prctl(PR_CAP_AMBIENT, PR_CAP_AMBIENT_CLEAR_ALL, 0, 0, 0) == 0, "drop ambient capabilities");
        require(setgroups(0, NULL) == 0, "observer groups");
        require(setresgid(61002, 61002, 61002) == 0, "observer gids");
        require(setresuid(61001, 61001, 61001) == 0, "observer uids");
        struct __user_cap_header_struct header = { _LINUX_CAPABILITY_VERSION_3, 0 };
        struct __user_cap_data_struct caps[2] = {{0}, {0}};
        require(syscall(SYS_capset, &header, caps) == 0, "drop observer capabilities");
        require(syscall(SYS_capget, &header, caps) == 0, "read observer capabilities");
        require(!(caps[0].effective | caps[0].permitted | caps[0].inheritable |
                  caps[1].effective | caps[1].permitted | caps[1].inheritable), "empty observer capabilities");
        require(prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) == 0, "observer no-new-privileges");
        require(prctl(PR_SET_DUMPABLE, 0) == 0, "observer nondumpable");
        errno = 0;
        fd = syscall(SYS_pidfd_getfd, pidfd, 199, 0);
        int getfd_error = errno;
        require(fd == -1 && getfd_error == EPERM, "distinct-UID pidfd_getfd must be denied");
        char path[80];
        snprintf(path, sizeof(path), "/proc/%d/cwd", target);
        errno = 0;
        fd = open(path, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
        int cwd_error = errno;
        require(fd == -1 && (cwd_error == EACCES || cwd_error == EPERM), "distinct-UID cwd inspection must be denied");
        printf("UID61001 empty-cap observer -> UID1000: pidfd_getfd errno=%d; cwd errno=%d\n", getfd_error, cwd_error);
        fflush(stdout);
        _exit(0);
    }
    require(waitpid(observer, &status, 0) == observer, "wait observer");
    int passed = WIFEXITED(status) && WEXITSTATUS(status) == 0;
    require(kill(target, SIGKILL) == 0, "retire owned target");
    require(waitpid(target, &status, 0) == target, "reap owned target");
    close(pidfd);
    require(passed, "observer result");
    puts("owned target and observer reaped; no host ptrace settings changed");
    return 0;
}
