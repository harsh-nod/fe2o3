#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-production-deployment-20261004-pDEq7AJa
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
trap 'printf "%s\n" "$?" > "$scratch/capability.status"' EXIT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export RUST_TEST_THREADS=1 FE2O3_HIP_SYS_DISABLE=1
export LD_LIBRARY_PATH="$PWD/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
cargo +nightly-2026-04-03 test --offline -p fe2o3-compiler-closure-capability --lib > "$scratch/capability.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-compiler-closure-capability --doc > "$scratch/capability-doc.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-compiler-closure-capability --all-targets --no-deps -- -D warnings > "$scratch/capability-clippy.log" 2>&1
