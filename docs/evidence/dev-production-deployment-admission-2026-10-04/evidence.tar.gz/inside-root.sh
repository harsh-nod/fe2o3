#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-production-deployment-20261004-pDEq7AJa
readonly source=$1 binary=$2 test_name=$3 case_name=$4 mutation=$5
readonly config=/etc/fe2o3/compiler-execution
install -d -m 0755 /etc/fe2o3 "$config"
install -m 0444 -o 0 -g 0 "$source/client-profile-v1" "$source/supervisor-deployment-v1" "$source/anchor-deployment-v1" "$config/"
case "$mutation" in
    mutable) chmod 0644 "$config/client-profile-v1" ;;
    wrongowner) chown 1000:1000 "$config/supervisor-deployment-v1" ;;
    symlink) mv "$config/anchor-deployment-v1" "$config/anchor-original"; ln -s anchor-original "$config/anchor-deployment-v1" ;;
    wronglink) ln "$config/client-profile-v1" "$config/client-alias" ;;
    wronglength) truncate -s 0 "$config/anchor-deployment-v1" ;;
    mismatch) install -m 0444 -o 0 -g 0 "$scratch/host-config/anchor-deployment-v1" "$config/anchor-deployment-v1" ;;
    none|root|mapped|overmap) ;;
    *) exit 2 ;;
esac
if [[ $mutation == root ]]; then
    exec "$binary" "$test_name" --ignored --exact --nocapture --test-threads=1
fi
if [[ $mutation == mapped ]]; then
    install -m 0755 "$binary" /tmp/qualification-test
    exec unshare --user --map-user=1000 --map-group=1000 \
        /tmp/qualification-test "$test_name" --ignored --exact --nocapture --test-threads=1
fi
timeout --kill-after=5s 40s setpriv --reuid=1000 --regid=1000 --clear-groups \
    --inh-caps=-all --ambient-caps=-all --bounding-set=-all --no-new-privs \
    "$binary" "$test_name" --ignored --exact --nocapture --test-threads=1 &
child=$!
trap 'kill "$child" 2>/dev/null || true; wait "$child" 2>/dev/null || true' EXIT
while kill -0 "$child" 2>/dev/null; do
    if [[ -f $FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/overmap-request && ! -f $FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/overmapped ]]; then
        read -r pid tid < "$FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/overmap-request"
        [[ $pid =~ ^[0-9]+$ && $tid =~ ^[0-9]+$ ]]
        mount --bind "$scratch/full-map" "/proc/$pid/task/$tid/uid_map"
        touch "$FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/overmapped"
    fi
    if [[ -f $FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/replace-request && ! -f $FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/replaced ]]; then
        mv "$config/client-profile-v1" "$config/client-original"
        install -m 0444 -o 0 -g 0 "$config/client-original" "$config/client-profile-v1"
        touch "$FE2O3_PRODUCTION_DEPLOYMENT_CONTROL/replaced"
    fi
    sleep 0.01
done
wait "$child"
trap - EXIT
