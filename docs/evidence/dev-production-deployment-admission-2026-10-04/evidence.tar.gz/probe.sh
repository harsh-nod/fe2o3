#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-production-deployment-20261004-pDEq7AJa
trap 'printf "%s\n" "$?" > "$scratch/remote-observation-probe.status"' EXIT
cc -std=c11 -O2 -Wall -Wextra -Werror "$scratch/remote-observation-probe.c" -o "$scratch/remote-observation-probe" > "$scratch/remote-observation-build.log" 2>&1
timeout --kill-after=5s 30s /mnt/c/Windows/System32/wsl.exe --user root --exec \
    /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
    --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
    --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
    --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
    "$scratch/remote-observation-probe" > "$scratch/remote-observation-probe.log" 2>&1
