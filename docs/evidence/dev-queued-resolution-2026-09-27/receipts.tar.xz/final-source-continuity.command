git diff --exit-code HEAD -- crates docs/runtime-successor-writer-plan-v1.md docs/runtime-queued-read-resolution-proof-v1.md Cargo.lock rust-toolchain.toml 
