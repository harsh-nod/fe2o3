git diff f0cb2cb34d0fa3e13efadd3e42e91e233deadd63 HEAD -- crates/fe2o3-runtime-model docs/runtime-successor-writer-plan-v1.md docs/runtime-queued-read-resolution-proof-v1.md 
