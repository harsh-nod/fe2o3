git log -2 --format=%H%n%T%n%P%n%an\ \<%ae\>%n%aI%n%B 
