#!/usr/bin/env bash
set -uo pipefail
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
out=/home/harsh/.codex-tmp/fe2o3-bind-recovery-20260928-mNphDGPJ
label=$1
shift
printf '%q ' "$@" > "$out/$label.command"
printf '\n' >> "$out/$label.command"
date -u +%FT%TZ > "$out/$label.started"
"$@" > "$out/$label.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/$label.status"
date -u +%FT%TZ > "$out/$label.finished"
tail -n 30 "$out/$label.log"
exit "$status"
