#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-bind-recovery-20260928-mNphDGPJ
out=/home/harsh/.codex-tmp/fe2o3-r61-execution/docs/evidence/dev-single-bind-recovery-2026-09-28
tar --sort=name -cJf "$out/receipts.tar.xz" -C "$raw" .
cd "$out"
sha256sum receipts.tar.xz > receipts.tar.xz.sha256
sha256sum -c receipts.tar.xz.sha256
