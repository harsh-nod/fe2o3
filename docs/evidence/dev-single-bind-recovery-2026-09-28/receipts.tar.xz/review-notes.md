# Persistent Bind Recovery Review

Two read-only agents reviewed the implementation and test oracles. The primary
agent owns edits, integration and tests. No agent requested permissions.

- The old single-input bind rejection path shared its restore helper with
  completion. That helper allocated a replacement Box after typed custody had
  returned from lower bind. The public scripted H2D test counted one allocation
  in that restoration body before the fix.
- Reuse of the original box through the existing take_restore_shell_v1 helper
  is cheaper than allocating a new recovery shell. H2D and replay extraction
  retain their exact box; initialized storage keeps its existing record-owned
  multi-shape completion shells.
- A non-cloneable restoration ticket carries original admission, submission,
  promotion and shell. Callers cannot accidentally reconstruct another target
  at restore time. Input and ticket remain private runtime custody.
- Native Retryable preserves input variant: initial bind reconstructs from its
  retained initialization, and retained-control retry is allowed only before
  detach. The initialized-storage bind adapter therefore accepts exact storage
  input, unlike successful completion's broader replay-capable adapter.
- The same restore body handles native Retryable, scripted Unsupported and the
  scripted public clean-bind-refusal hook. Queue execution is not simulated as
  real GPU evidence. The empty local shell is dropped after Active indexing on
  success; no published ledger grows to retain it.
- Tests count only extraction/restoration commits, excluding fixture setup,
  diagnostics and assertions. Ready/replay extraction and all successful bind
  restorations allocate zero. Initialized-storage extraction still reserves
  three test-layout shells before consuming input.
- New tests use public H2D transport and admitted pending descriptors. Direct
  helper tests cover nine round trips and 18 malformed-recovery subprocesses;
  public submit/flush tests inject a lower bind refusal and preserve a queued
  successor across all three origins. Exact byte/certificate/promotion/box and
  surviving record-shell identities are checked.
- No blocker remained in review. Native end-to-end bind, initialized-storage
  shell allocation-failure injection, full formal correspondence, and
  completion-time restoration allocation remain separate open boundaries.

The first focused build removed an older test-only extraction helper still used
by three unrelated tests. That helper was restored unchanged. Both this build
failure and the original allocation regression remain in the receipt archive.
