env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-kfd --all-features --lib persistent_ -- --nocapture 
