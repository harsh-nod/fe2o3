rustc --version --verbose 
