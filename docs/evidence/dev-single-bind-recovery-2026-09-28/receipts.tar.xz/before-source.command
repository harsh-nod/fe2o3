git diff --binary 
