git diff --exit-code HEAD -- crates/fe2o3-runtime crates/fe2o3-runtime-model crates/fe2o3-kfd 
