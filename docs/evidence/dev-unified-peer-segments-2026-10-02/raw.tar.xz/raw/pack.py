"""Seal accepted receipts and staged source; never distribute executable files."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
DEST = REPO / 'docs/evidence/dev-unified-peer-segments-2026-10-02'
assert json.loads((RAW / 'audit-final.json').read_text())['accepted'] is True
assert json.loads((RAW / 'audit-native.json').read_text())['accepted'] is True
assert (DEST / 'README.md').is_file()
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=REPO)
assert staged and not any(name.startswith(b'docs/evidence/') for name in staged.split(b'\0'))
patch = subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=REPO)
with (RAW / 'candidate.patch').open('xb') as output:
    output.write(patch)
rows = {}
with (DEST / 'raw.tar.xz').open('xb') as archive:
    with lzma.LZMAFile(archive, mode='w', preset=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as output:
            for path in sorted(RAW.rglob('*')):
                assert not path.is_symlink(), path
                if path.is_dir():
                    continue
                assert path.is_file(), path
                data = path.read_bytes()
                assert not data.startswith(b'\x7fELF'), path
                name = path.relative_to(RAW).as_posix()
                rows[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
                info = tarfile.TarInfo('raw/' + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                output.addfile(info, io.BytesIO(data))
with (DEST / 'raw-manifest.json').open('x') as output:
    json.dump(rows, output, indent=2, sort_keys=True)
    output.write('\n')
for name, row in rows.items():
    data = (RAW / name).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
assert sorted(rows) == sorted(path.relative_to(RAW).as_posix() for path in RAW.rglob('*') if path.is_file())
with tarfile.open(DEST / 'raw.tar.xz', 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(rows)
    assert {member.name for member in members} == {'raw/' + name for name in rows}
    for member in members:
        assert member.isfile()
        row = rows[member.name.removeprefix('raw/')]
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
with (DEST / 'SHA256SUMS').open('x') as output:
    for name in ('README.md', 'raw-manifest.json', 'raw.tar.xz'):
        output.write(hashlib.sha256((DEST / name).read_bytes()).hexdigest() + '  ' + name + '\n')
print(json.dumps(dict(files=len(rows), uncompressed_bytes=sum(row['bytes'] for row in rows.values()),
                     archive_bytes=(DEST / 'raw.tar.xz').stat().st_size), sort_keys=True))
