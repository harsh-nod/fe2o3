#!/usr/bin/env python3
"""Run one exact, disjoint KFD construction shard or the remaining test roster.

The five planned partitions cover the complete captured library roster. One
receipt accepts only its selected partition, never the other four executions.
"""
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'ead9cfab9501d8332bf3f89485dfdafbea51eb7c'
CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
PREFIX = 'queue::live::construction_primary::'
MODES = ('0', '1', '2', '3', 'rest')
ENV = dict(HOME='/home/harsh', PATH='/usr/bin:/bin', LANG='C.UTF-8',
           LC_ALL='C.UTF-8', RUST_TEST_THREADS='1', FE2O3_HIP_SYS_DISABLE='1')
BUILD_ENV = {
    **ENV, 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'CARGO_BUILD_JOBS': '4', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
    'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true',
}
BUILD_COMMAND = ['timeout', '--signal=TERM', '--kill-after=30s', '900s',
    'cargo', 'test', '--locked', '--offline', '-p', 'fe2o3-kfd', '--all-features',
    '--lib', '--no-run', '--message-format=json']
LIST_COMMAND = ['timeout', '--signal=TERM', '--kill-after=30s', '120s',
    'cargo', 'test', '--locked', '--offline', '-p', 'fe2o3-kfd', '--all-features',
    '--lib', '--', '--list']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write('\n')


def capture_inputs(label, command):
    folder = ROOT / label
    receipt = json.loads((folder / 'receipt.json').read_text())
    initial = json.loads((folder / 'command.json').read_text())
    assert receipt['command'] == command and receipt['exit'] == 0
    assert receipt['source_unchanged'] is True
    assert receipt['environment'] == BUILD_ENV
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO)
    assert receipt['controller_sha256'] == sha((ROOT / 'capture.py').read_bytes()) == CAPTURE_SHA
    assert all(receipt[key] == value for key, value in initial.items())
    assert datetime.fromisoformat(receipt['started']) <= datetime.fromisoformat(receipt['finished'])
    for name in ('stdout', 'stderr'):
        assert sha((folder / name).read_bytes()) == receipt[name + '_sha256']
    source = json.loads((folder / 'source-before.json').read_text())
    assert source == json.loads((folder / 'source-after.json').read_text())
    return receipt, source


def current_source():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, env=BUILD_ENV, text=True).strip() == BASE
    listed = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard',
        '-z', '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=REPO, env=BUILD_ENV)
    names = sorted(set(os.fsdecode(listed).rstrip('\0').split('\0')))
    assert names and all(names)
    return {name: sha((REPO / name).read_bytes()) for name in names}


def roster(output):
    names, summaries = [], []
    for line in output.splitlines():
        if not line:
            continue
        entry = re.fullmatch(r'(\S+): test', line)
        summary = re.fullmatch(r'(\d+) tests?, (\d+) benchmarks?', line)
        assert entry or summary, ('unexpected test-list output', line)
        if entry:
            names.append(entry.group(1))
        else:
            summaries.append(tuple(map(int, summary.groups())))
    assert len(names) == len(set(names))
    assert summaries == [(len(names), 0)]
    return sorted(names)


def executable_inputs():
    build, source = capture_inputs('kfd-build-final-01', BUILD_COMMAND)
    listing, list_source = capture_inputs('kfd-list-final-01', LIST_COMMAND)
    assert source == list_source == current_source()
    rows = [json.loads(line) for line in (ROOT / 'kfd-build-final-01/stdout').read_text().splitlines()]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'] is True
    artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
    assert len(artifacts) == 1
    artifact = artifacts[0]
    binary = Path(artifact['executable'])
    assert artifact['target']['name'] == 'fe2o3_kfd'
    assert artifact['target']['kind'] == ['lib'] and artifact['profile']['test'] is True
    assert binary.parent == REPO / 'target/debug/deps'
    assert re.fullmatch(r'fe2o3_kfd-[0-9a-f]+', binary.name)
    assert set(build['executables']) == {str(binary)}
    identity = build['executables'][str(binary)]
    assert identity['target'] == 'fe2o3_kfd' and identity['test'] is True
    assert binary.is_file() and not binary.is_symlink()
    data = binary.read_bytes()
    assert data.startswith(b'\x7fELF')
    assert sha(data) == identity['sha256'] and len(data) == identity['byte_length']
    full = roster((ROOT / 'kfd-list-final-01/stdout').read_text())
    assert len(full) >= 1943
    heavy = [name for name in full if name.startswith(PREFIX)]
    assert len(heavy) >= 4
    partitions = {str(index): heavy[index::4] for index in range(4)}
    partitions['rest'] = [name for name in full if not name.startswith(PREFIX)]
    assert all(partitions.values())
    union = Counter(name for mode in MODES for name in partitions[mode])
    assert union == Counter(full) and all(count == 1 for count in union.values())
    return binary, identity, source, full, partitions, build, listing


def group_absent(pid):
    try:
        os.killpg(pid, 0)
        return False
    except ProcessLookupError:
        return True


def stop_owned_group(process):
    for sig in (signal.SIGTERM, signal.SIGKILL):
        if group_absent(process.pid):
            break
        try:
            os.killpg(process.pid, sig)
        except ProcessLookupError:
            break
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            process.poll()
            if group_absent(process.pid):
                break
            time.sleep(0.02)
    process.wait(timeout=5)


class InterruptedRun(Exception):
    def __init__(self, signum):
        self.signum = signum


def interrupt(signum, _frame):
    raise InterruptedRun(signum)


def run(out, name, argv, seconds):
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    timed_out, interrupted, forced_cleanup = False, None, False
    with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=REPO, env=ENV, stdin=subprocess.DEVNULL,
            stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            status = process.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            status = 124
        except InterruptedRun as error:
            interrupted = error.signum
            status = 128 + error.signum
            signal.signal(signal.SIGTERM, signal.SIG_IGN)
            signal.signal(signal.SIGINT, signal.SIG_IGN)
        finally:
            if not group_absent(process.pid):
                forced_cleanup = True
                stop_owned_group(process)
        absent = group_absent(process.pid)
    result = dict(argv=argv, environment=ENV, cwd=str(REPO), timeout_seconds=seconds,
        started=started, finished=datetime.now(timezone.utc).isoformat(),
        elapsed_seconds=time.monotonic() - clock, exit_code=status, timed_out=timed_out,
        interrupted_signal=interrupted, group_absent=absent, forced_group_cleanup=forced_cleanup,
        stdout_sha256=sha((out / (name + '.stdout')).read_bytes()),
        stderr_sha256=sha((out / (name + '.stderr')).read_bytes()))
    write_json(out / (name + '.json'), result)
    return result


def clean_run(receipt):
    return (receipt['exit_code'] == 0 and receipt['timed_out'] is False
            and receipt['interrupted_signal'] is None and receipt['group_absent'] is True
            and receipt['forced_group_cleanup'] is False)


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2 and sys.argv[1] in MODES
    mode = sys.argv[1]
    out = ROOT / ('kfd-shard-' + mode)
    out.mkdir(mode=0o700)
    deadline = time.monotonic() + 1260
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    signal.signal(signal.SIGTERM, interrupt)
    signal.signal(signal.SIGINT, interrupt)
    result = dict(accepted=False, mode=mode, controller_sha256=sha(Path(__file__).read_bytes()),
                  scope='selected-partition-only', error=None)
    try:
        binary, identity, source, full, partitions, build, listing = executable_inputs()
        selected = partitions[mode]
        argv = [str(binary), '--test-threads=1', '--exact', *selected]
        inputs = dict(argv=argv, environment=ENV, cwd=str(REPO), core_limit_bytes=0,
            native_opt_in_environment={}, executable=str(binary), executable_identity=identity,
            controller_sha256=result['controller_sha256'], selected=selected,
            total_roster=len(full), construction_roster=sum(len(partitions[str(i)]) for i in range(4)),
            partitions=partitions, partition_union_exact=True,
            build_receipt_sha256=sha((ROOT / 'kfd-build-final-01/receipt.json').read_bytes()),
            list_receipt_sha256=sha((ROOT / 'kfd-list-final-01/receipt.json').read_bytes()),
            full_roster_sha256=listing['stdout_sha256'],
            source_manifest_sha256=sha((ROOT / 'kfd-build-final-01/source-after.json').read_bytes()),
            build_command=build['command'], list_command=listing['command'])
        write_json(out / 'inputs.json', inputs)
        # Independently discover the complete immutable ELF, not only the
        # selected filters, so an omitted test cannot disappear from the union.
        discovered = run(out, 'full-list', [str(binary), '--test-threads=1', '--list'], 60)
        assert clean_run(discovered)
        assert roster((out / 'full-list.stdout').read_text()) == full
        discovery = run(out, 'list', [*argv, '--list'], 60)
        assert clean_run(discovery)
        assert roster((out / 'list.stdout').read_text()) == selected
        remaining = min(1200, deadline - time.monotonic())
        assert remaining > 0, 'shard preparation exhausted the outer-safe deadline'
        execution = run(out, 'run', argv, remaining)
        output = (out / 'run.stdout').read_text()
        summary = [line for line in output.splitlines() if line.startswith('test result:')]
        expected = (f'test result: ok. {len(selected)} passed; 0 failed; 0 ignored; '
                    f'0 measured; {len(full) - len(selected)} filtered out;')
        passed = re.findall(r'^test (\S+) \.\.\. ok$', output, re.M)
        other = re.findall(r'^test (\S+) \.\.\. (?!ok$)(.*)$', output, re.M)
        unchanged = sha(binary.read_bytes()) == identity['sha256'] and binary.stat().st_size == identity['byte_length']
        source_unchanged = current_source() == source
        accepted = (clean_run(execution) and unchanged and source_unchanged
                    and Counter(passed) == Counter(selected) and not other
                    and len(summary) == 1 and summary[0].startswith(expected))
        result.update(accepted=accepted, selected_count=len(selected), total_roster=len(full),
            passed=sorted(passed), other_outcomes=other, summary=summary,
            exit_code=execution['exit_code'], timed_out=execution['timed_out'],
            group_absent=execution['group_absent'], executable_unchanged=unchanged,
            source_unchanged=source_unchanged, executable_sha256=identity['sha256'],
            execution_receipt_sha256=sha((out / 'run.json').read_bytes()),
            inputs_sha256=sha((out / 'inputs.json').read_bytes()),
            stdout_sha256=execution['stdout_sha256'], stderr_sha256=execution['stderr_sha256'])
    except (Exception, KeyboardInterrupt) as error:
        result['error'] = repr(error)
    write_json(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
