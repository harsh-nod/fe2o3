"""Close final CPU, metadata, arithmetic-proof, and native evidence together."""
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile

import yaml

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'ead9cfab9501d8332bf3f89485dfdafbea51eb7c'
CAPTURE = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
VERUS = '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus'


def sha(path):
    assert path.is_file() and not path.is_symlink(), path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
assert sha(RAW / 'capture.py') == CAPTURE
for name, digest in {
    'qualify.py': 'b514733ba346a2450eff2dff788f4c9d4d2b6fa112695415442474c700fd865f',
    'qualify_final.py': 'fe88e408d78d1932bb5bf295cb8a65e6fe1fb94f9df7fa9e4cd2d2da72213434',
    'source_controls_baseline.py': 'fb5b67b44ad85fd21792a2fe18f9bac60897033c8a37a51ea2fa5c04e0277a5c',
    'source_controls_final_02.py': '5045334e4b8222b482ad2399ac5a9ff86b4917f3506948eaa04ce7cb11e2f53d',
    'source-ci/proposal-02/verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
    'source-ci/proposal-02/metadata-report.json': 'aea35f9eceaa78e3c117a9d5864c24d0f161f8b808f728a1770259d3ab4532a0',
}.items():
    assert sha(RAW / name) == digest
capture = module('capture', RAW / 'capture.py')
source = capture.snapshot()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
qualify = module('qualify_final', RAW / 'qualify_final.py')
jobs = [*qualify.JOBS,
    ('metadata-final-before-02', '120s', ['python3', '-I', '-B', str(RAW / 'source-ci/proposal-02/verify-applied.py')]),
    ('metadata-final-after-02', '120s', ['python3', '-I', '-B', str(RAW / 'source-ci/proposal-02/verify-applied.py')]),
    ('source-controls-final-02', '600s', ['python3', '-I', '-B', str(RAW / 'source_controls_final_02.py')]),
    ('hardware-final', '1800s', ['python3', '-I', '-B', str(RAW / 'hardware-01/campaign.py')]),
]
for kind, controller in [('packet', 'compute_xgmi_packet_plan_check.py'), ('window', 'compute_xgmi_window_check.py')]:
    jobs.append((kind + '-proof-final-03', '900s', ['python3', '-I', '-B',
        'crates/fe2o3-runtime-model/verus/' + controller, '--verus', VERUS,
        '--output', str(RAW / (kind + '-proof-02'))]))
for mode in ('0', '1', '2', '3', 'rest'):
    jobs.append(('kfd-shard-final-02-' + mode, '1300s', ['python3', '-I', '-B', str(RAW / 'kfd_shard_final.py'), mode]))
selected = {}
for label, bound, command in jobs:
    folder = RAW / label
    receipt, initial = (read(folder / name) for name in ('receipt.json', 'command.json'))
    assert all(receipt[key] == value for key, value in initial.items()), label
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', bound, *command], label
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, label
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO), label
    assert receipt['controller_sha256'] == CAPTURE and receipt['environment'] == capture.ENV, label
    assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == source, label
    assert datetime.fromisoformat(receipt['started']) <= datetime.fromisoformat(receipt['finished'])
    for output in ('stdout', 'stderr'):
        assert sha(folder / output) == receipt[output + '_sha256'], label
    selected[label] = dict(receipt_sha256=sha(folder / 'receipt.json'))

for label, listing, passed, ignored in [
    ('runtime-tests-final-01', 'runtime-list-final-01', 2227, 32),
    ('witness-tests-final-01', 'witness-list-final-01', 3, 0),
    ('deferred-tests-final-01', 'deferred-list-final-01', 13, 0),
]:
    output = (RAW / label / 'stdout').read_text()
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; 0 filtered out;', output, re.M)
    assert summaries == [(str(passed), '0', str(ignored))], (label, summaries)
    outcomes = re.findall(r'^test (.+?) \.\.\. (ok|ignored(?:, [^\n]*)?)$', output, re.M)
    roster = re.findall(r'^(.+): test$', (RAW / listing / 'stdout').read_text(), re.M)
    assert len(roster) == len(set(roster)) == passed + ignored
    assert Counter(name for name, _ in outcomes) == Counter(roster)
    assert sum(status == 'ok' for _, status in outcomes) == passed
    selected[label].update(passed=passed, ignored=ignored)

baseline_archive = 'docs/evidence/dev-cooperative-peer-progress-2026-10-02/raw.tar.xz'
accepted_archive = subprocess.check_output(['git', 'show', BASE + ':' + baseline_archive], cwd=REPO)
assert hashlib.sha256(accepted_archive).hexdigest() == sha(REPO / baseline_archive)
with tarfile.open(fileobj=io.BytesIO(accepted_archive), mode='r:xz') as archive:
    old_runtime = archive.extractfile('raw/runtime-tests-final-04/stdout').read().decode()
ignored_pattern = r'^test (.+?) \.\.\. ignored(?:, [^\n]*)?$'
old_ignored = re.findall(ignored_pattern, old_runtime, re.M)
new_ignored = re.findall(ignored_pattern, (RAW / 'runtime-tests-final-01/stdout').read_text(), re.M)
assert len(old_ignored) == 32 and Counter(old_ignored) == Counter(new_ignored)

assert sha(RAW / 'kfd_shard.py') == 'adb5ed28829748abef3e57c51d3404cd5ee7d8e030167ff3d2622f4d9730509a'
assert sha(RAW / 'kfd_shard_final.py') == 'f6262d5575843228388e3909a4718cc6946390e3332bf63ae1f0ef5e9d34d01b'
parser = read(RAW / 'kfd-parser-final-02/result.json')
assert parser['exit_code'] == 0 and parser['source_unchanged']
assert parser['source_before'] == parser['source_after']
for name, digest in parser['source_after'].items():
    assert sha(RAW / name) == digest
for output in ('stdout', 'stderr'):
    assert sha(RAW / 'kfd-parser-final-02' / output) == parser[output + '_sha256']
assert re.findall(r'^Ran (\d+) tests in [0-9.]+s$', (RAW / 'kfd-parser-final-02/stderr').read_text(), re.M) == ['11']
sharder = module('sharder', RAW / 'kfd_shard_final.py')
binary, identity, _, roster, partitions, _, _ = sharder.executable_inputs()
assert len(roster) == 1943
union = []
for mode, names in partitions.items():
    folder = RAW / ('kfd-shard-02-' + mode)
    result, inputs = read(folder / 'result.json'), read(folder / 'inputs.json')
    assert result['accepted'] is True and result['error'] is None
    assert result['source_unchanged'] and result['executable_unchanged']
    assert result['controller_sha256'] == sha(RAW / 'kfd_shard_final.py')
    assert result['inputs_sha256'] == sha(folder / 'inputs.json')
    assert inputs['selected'] == result['passed'] == names
    assert inputs['partitions'] == partitions and inputs['executable_identity'] == identity
    assert inputs['argv'] == [str(binary), '--test-threads=1', '--exact', *names]
    for stage, argv in [('full-list', [str(binary), '--test-threads=1', '--list']),
                        ('list', [*inputs['argv'], '--list']), ('run', inputs['argv'])]:
        receipt = read(folder / (stage + '.json'))
        assert sharder.clean_run(receipt) and receipt['argv'] == argv
        assert receipt['environment'] == sharder.ENV and receipt['cwd'] == str(REPO)
        for output in ('stdout', 'stderr'):
            assert sha(folder / (stage + '.' + output)) == receipt[output + '_sha256']
    assert sharder.roster((folder / 'full-list.stdout').read_text()) == roster
    assert sharder.roster((folder / 'list.stdout').read_text()) == names
    assert sharder.parse_outcomes((folder / 'run.stdout').read_text(), names, len(roster))['accepted']
    assert result['execution_receipt_sha256'] == sha(folder / 'run.json')
    union.extend(names)
assert Counter(union) == Counter(roster)

proposal = read(RAW / 'source-ci/proposal-02/metadata-report.json')
assert len(proposal['proof_files']) == 76
for path, digest in proposal['proof_files'].items():
    before = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=REPO)
    assert hashlib.sha256(before).hexdigest() == digest == sha(REPO / path)
for label in ('metadata-final-before-02', 'metadata-final-after-02'):
    row = json.loads((RAW / label / 'stdout').read_text())
    assert row['ast_identical_except_recorded_metadata_literals'] and row['applied_guard_hashes_match_proposal']
    assert (row['changed_files'], row['hash_constants'], row['source_inventory_constants']) == (13, 21, 7)
    assert row['unchanged_proof_files'] == 76 and not row['formal_qualification']

workflow = yaml.safe_load((REPO / '.github/workflows/runtime-component-source-guards.yml').read_text())
commands = [(step['name'], shlex.split(line)) for step in workflow['jobs']['source-controls']['steps'] if 'run' in step for line in step['run'].splitlines()]
assert len(commands) == 32
baseline_folder = RAW / 'baseline-source-controls'
baseline_capture = read(baseline_folder / 'receipt.json')
baseline_command = read(baseline_folder / 'command.json')
assert all(baseline_capture[key] == value for key, value in baseline_command.items())
assert baseline_capture['exit'] == 0 and baseline_capture['source_unchanged']
assert baseline_capture['base'] == BASE and baseline_capture['cwd'] == str(REPO)
assert baseline_capture['controller_sha256'] == CAPTURE and baseline_capture['environment'] == capture.ENV
assert baseline_capture['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', '600s',
    'python3', '-I', '-B', str(RAW / 'source_controls_baseline.py')]
for output in ('stdout', 'stderr'):
    assert sha(baseline_folder / output) == baseline_capture[output + '_sha256']
baseline_source = read(baseline_folder / 'source-before.json')
assert baseline_source == read(baseline_folder / 'source-after.json')
baseline_names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '-z', BASE,
    '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'], cwd=REPO).decode().rstrip('\0').split('\0')
assert sorted(baseline_source) == sorted(baseline_names)
blobs = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
    input=''.join(BASE + ':' + name + '\n' for name in sorted(baseline_source)).encode())
offset = 0
for name in sorted(baseline_source):
    end = blobs.index(b'\n', offset)
    _, kind, size = blobs[offset:end].split()
    assert kind == b'blob'
    offset, size = end + 1, int(size)
    assert hashlib.sha256(blobs[offset:offset + size]).hexdigest() == baseline_source[name]
    offset += size
    assert blobs[offset:offset + 1] == b'\n'
    offset += 1
assert offset == len(blobs)
for phase in ('baseline', 'final-02'):
    folder = RAW / ('source-controls-' + phase + '-commands')
    control = read(folder / 'summary.json')
    assert control['accepted'] is True and control['solver_executed'] is False
    assert [(row['name'], row['command']) for row in control['commands']] == commands
    assert control['workflow_sha256'] == sha(REPO / '.github/workflows/runtime-component-source-guards.yml')
    assert control['controller_sha256'] == sha(RAW / 'source_controls_baseline.py')
    for index, row in enumerate(control['commands']):
        assert row['exit'] == 0 and read(folder / f'{index:02d}' / 'receipt.json') == row
        for output in ('stdout', 'stderr'):
            assert sha(folder / f'{index:02d}' / output) == row[output + '_sha256']

proofs = {}
for kind, count, negatives in [('packet', 13, 8), ('window', 16, 11)]:
    folder = RAW / (kind + '-proof-02')
    controller = 'compute_xgmi_packet_plan_check.py' if kind == 'packet' else 'compute_xgmi_window_check.py'
    checker = module(kind + '_proof_audit', REPO / 'crates/fe2o3-runtime-model/verus' / controller)
    original_body = (REPO / checker.BODY).read_text()
    mutants = checker.mutations(original_body)
    row = read(folder / 'result.json')
    assert row['accepted'] and row['full_campaign'] and row['source_unchanged']
    assert row['error'] is None and row['whole_adapter_verified'] is False
    assert len(row['stages']) == count and all(stage['accepted'] for stage in row['stages'])
    assert [stage['name'] for stage in row['stages']] == [
        'controls', 'release-before', 'positive-before',
        *('negative-' + name for name in mutants), 'positive-after', 'release-after']
    assert sum(stage['name'].startswith('negative-') for stage in row['stages']) == negatives
    proof_inputs = {path: hashlib.sha256(data).hexdigest() for path, data in checker.source_snapshot().items()}
    assert read(folder / 'source-before.json') == proof_inputs
    if kind == 'window':
        assert read(folder / 'source-after.json') == proof_inputs
    for path, digest in proof_inputs.items():
        assert sha(REPO / path) == sha(folder / 'inputs' / path) == digest
    for stage in row['stages']:
        receipt = read(folder / stage['name'] / 'record.json')
        assert receipt['group_absent'] is True and receipt['status'] == stage['status']
        assert receipt['started_ns'] <= receipt['finished_ns']
        stdout = (folder / stage['name'] / 'stdout.log').read_text()
        stderr = (folder / stage['name'] / 'stderr.log').read_text()
        if stage['name'].startswith(('positive-', 'negative-')):
            body, focus = (original_body, None) if stage['name'].startswith('positive-') else mutants[stage['name'].removeprefix('negative-')]
            staged = folder / (stage['name'] + '-source')
            proof = staged / checker.PROOF
            assert (staged / checker.BODY).read_text() == body
            assert proof.read_bytes() == (REPO / checker.PROOF).read_bytes()
            focus_name = focus if kind == 'packet' or focus is None else checker.FOCI[focus][0]
            assert receipt['command'] == ['/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5',
                '120', VERUS, '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating',
                '--output-json', '--error-format=json', '--no-report-long-running', '--num-threads', '1',
                '--multiple-errors', '1', *([] if focus is None else ['--verify-function', '*' + focus_name, '--verify-root']), str(proof)]
            assert checker.classify(receipt['status'], stdout, stderr, proof, focus)
        elif stage['name'].startswith('release-'):
            support = checker if kind == 'packet' else checker.support
            assert receipt['command'] == ['/bin/sh', str(REPO / support.CLOSURE), str(Path(VERUS).parent), str(REPO / support.MANIFEST)]
            assert receipt['status'] == 0 and not stderr
            assert stdout == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n'
        else:
            assert stage['name'] == 'controls' and receipt['status'] == 0 and not stdout
            assert receipt['command'] == ['/usr/bin/python3', '-I', '-B', str(REPO / checker.TEST)]
            assert re.findall(r'^Ran (\d+) tests in [0-9.]+s$', stderr, re.M) == [('5' if kind == 'packet' else '7')]
            assert stderr.endswith('\nOK\n')
    proofs[kind] = dict(stages=count, logical_negatives=negatives, scope=row['scope'], result_sha256=sha(folder / 'result.json'))

native = read(RAW / 'audit-native.json')
assert native['accepted'] is True
assert native['base'] == BASE and native['source_files'] == len(source)
assert native['auditor_sha256'] == sha(RAW / 'audit_hardware.py') == '3185524cb5cc20d51a9dceee929f32963ccfa634d124e7fea0bc5aca922941ea'
assert native['source_manifest_sha256'] == sha(RAW / 'build-witness-final-01/source-before.json')
assert native['build_receipt_sha256'] == sha(RAW / 'build-witness-final-01/receipt.json')
assert native['outer_receipt_sha256'] == sha(RAW / 'hardware-final/receipt.json')
assert native['campaign_receipt_sha256'] == sha(RAW / 'hardware-01/campaign.json')
assert native['campaign_controller_sha256'] == sha(RAW / 'hardware-01/campaign.py') == 'd22d7ee70a41a5e588e8c79455c8be7879928e42e59d80225de9cbd832197895'
assert native['transport_sha256'] == sha(RAW / 'hardware-01/capture.py') == '507ba3f408a423d698ebaf2ff8b9c83b4c33ba97a3bda16734643da298d7f20f'
assert native['native_cases'] == native['cancelled_unpublished_lists'] == native['completed_native_lists'] == 10
assert len(native['native_events']) == 96 and native['owned_cleanup_complete']
assert native['final_point_baseline_restored'] and not native['exclusive_reservation']
assert not native['performance_acceptance'] and not native['formal_refinement'] and not native['general_application_authority']
assert native['binary'] == {key: value for key, value in read(RAW / 'hardware-01/campaign.json')['binary'].items() if key != 'remote'}
doctests = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; 0 filtered out;', (RAW / 'doctests-final-01/stdout').read_text(), re.M)
assert doctests == [('4', '0', '0'), ('49', '0', '0'), ('10', '0', '0'), ('51', '0', '0')]
result = dict(accepted=True, base=BASE, source_files=len(source), source_manifest_sha256=sha(RAW / 'build-witness-final-01/source-before.json'),
    qualified_commands=selected, kfd_tests=len(roster), runtime_tests=2227, runtime_ignored=32,
    example_tests=16, doctests=sum(int(passed) for passed, _, _ in doctests),
    unchanged_proof_files=76, arithmetic_campaigns=proofs, native_audit_sha256=sha(RAW / 'audit-native.json'),
    performance_acceptance=False, whole_adapter_verified=False)
with (RAW / 'audit-final.json').open('x') as output:
    json.dump(result, output, indent=2, sort_keys=True)
    output.write('\n')
print(json.dumps(result, sort_keys=True))
