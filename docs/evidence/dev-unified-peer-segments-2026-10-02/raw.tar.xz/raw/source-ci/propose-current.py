"""Bind the strict proposer plus an exact two-export identity review."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
BASE = 'ead9cfab9501d8332bf3f89485dfdafbea51eb7c'
REFERENCES = {
    'propose.py': '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50',
    'verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
}
ADAPTED_SHA = 'd86368e4494d0ae1db74e5027504cf2ce577cd9d447db90a3a16384b98abc97a'


def audit_derivation(reference, adapted):
    tree = ast.parse(adapted)
    helper = [node for node in tree.body if isinstance(node, ast.FunctionDef)
              and node.name == 'cadence_export_identities']
    imports = [node for node in tree.body if isinstance(node, ast.Import)
               and len(node.names) == 1 and node.names[0].name == 're'
               and node.names[0].asname is None]
    assert len(helper) == len(imports) == 1
    tree.body = [node for node in tree.body if node not in helper + imports]
    target = ast.dump(ast.parse("name == 'check-retained-pair-cadence.py'", mode='eval').body)
    body = ast.dump(ast.parse('cadence_export_identities(old, baseline, candidate, edits)').body[0])
    class RemoveReviewedBranch(ast.NodeTransformer):
        count = 0
        def visit_If(self, node):
            if ast.dump(node.test) == target:
                assert len(node.body) == len(node.orelse) == 1
                assert ast.dump(node.body[0]) == body and isinstance(node.orelse[0], ast.If)
                self.count += 1
                return self.visit(node.orelse[0])
            return self.generic_visit(node)
    remove = RemoveReviewedBranch()
    tree = remove.visit(tree)
    assert remove.count == 1
    assert ast.dump(tree, include_attributes=False) == ast.dump(ast.parse(reference), include_attributes=False)


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 2
    label = sys.argv[1]
    assert label.startswith('proposal-') and label[9:].isdigit()
    for name, expected in REFERENCES.items():
        assert hashlib.sha256((HERE / 'reference' / name).read_bytes()).hexdigest() == expected
    adapted = (HERE / 'propose-adapted.py').read_bytes()
    assert hashlib.sha256(adapted).hexdigest() == ADAPTED_SHA
    audit_derivation((HERE / 'reference/propose.py').read_text(), adapted.decode())
    spec = importlib.util.spec_from_file_location('strict_metadata_proposer', HERE / 'propose-adapted.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.BASE = BASE
    module.OUT = HERE / label
    owner = Path('crates/fe2o3-runtime/src/context/versions/producer_readers.rs')
    assert (module.ROOT / owner).read_text() == module.blobs([owner])[owner]
    module.OUT.mkdir(mode=0o700)
    (module.OUT / 'invocation.json').write_text(json.dumps(dict(
        base=BASE, output=str(module.OUT), references=REFERENCES,
        wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        native_owner_unchanged=True, no_custom_metadata_hooks=False,
        adapted_sha256=ADAPTED_SHA, adapted_ast_diff_exact=True,
        custom_metadata_scope='cadence PINS for exact two KFD module/export-only identities',
        solver_executed=False, build_executed=False), sort_keys=True, indent=2) + '\n')
    module.main()
    report = json.loads((module.OUT / 'metadata-report.json').read_bytes())
    edits = [edit for row in report['changes'] for edit in row['edits']]
    assert len(report['proof_files']) == 76
    assert not any(edit['selector'] == 'NATIVE_PREEXTRACTION_SHA' for edit in edits)
    pins = [(row['path'], edit['selector']) for row in report['changes']
            for edit in row['edits'] if edit['selector'].startswith('PINS[')]
    assert pins == [(str(module.V / 'check-retained-pair-cadence.py'), selector)
                    for selector in ("PINS[SRC / 'lib.rs']", "PINS[SRC / 'sdma.rs']")]
    shutil.copyfile(HERE / 'reference/verify-applied.py', module.OUT / 'verify-applied.py')


if __name__ == '__main__':
    main()
