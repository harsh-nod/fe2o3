"""Run the unchanged workflow controller against the final source snapshot."""
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def main():
    spec = importlib.util.spec_from_file_location('source_controls_baseline', ROOT / 'source_controls_baseline.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.OUT = ROOT / 'source-controls-final-commands'
    return module.main()


if __name__ == '__main__':
    sys.exit(main())
