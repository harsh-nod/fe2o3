#!/usr/bin/env python3
"""Offline, source-bound audit of the ten unified native segment cases.

This reads existing receipts and local Git/file identities only. It does not
invoke the campaign, SSH, native code, a compiler, or any test executable.
"""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys


RAW = Path(__file__).resolve().parent
HARDWARE = RAW / 'hardware-01'
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'ead9cfab9501d8332bf3f89485dfdafbea51eb7c'
CAMPAIGN_SHA = 'd22d7ee70a41a5e588e8c79455c8be7879928e42e59d80225de9cbd832197895'
TRANSPORT_SHA = '507ba3f408a423d698ebaf2ff8b9c83b4c33ba97a3bda16734643da298d7f20f'
CAPTURE_SHA = '63088aa54c2bb068cebc7a8e519a36829415ea54f0cbfc5abdf94a23cb21aab1'
TARGET = 'gfx942-runtime-unified-segments-smoke'
PREFIX = '/tmp/fe2o3-unified-segments-20261002-'
BUILD = RAW / 'build-witness-final-01'
OUTER = RAW / 'hardware-final'
OUTPUT = RAW / 'audit-native.json'
IDS = ['0x10a254ce4987e716', '0x53691ef168a0147d']
CARDS = ['card6', 'card7']
BDFS = ['0000:C6:00.0', '0000:E5:00.0']
CASES = [(f'segments-{case}-{direction}', case, ids)
         for case in ('1', '4', '65', '4096', 'packets')
         for direction, ids in (('forward', IDS), ('reverse', IDS[::-1]))]
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
ENV = {
    'HOME': '/home/harsh', 'PATH': '/home/harsh/.cargo/bin:/usr/bin:/bin',
    'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CARGO_BUILD_JOBS': '4',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
    'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS': 'true',
    'CARGO_PROFILE_TEST_OVERFLOW_CHECKS': 'true', 'RUST_TEST_THREADS': '1',
    'FE2O3_HIP_SYS_DISABLE': '1',
}


def content(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()


def sha(path):
    return hashlib.sha256(content(path)).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result


def decode_json(data):
    return json.loads(data, object_pairs_hook=unique_object)


def read(path):
    return decode_json(content(path))


def instant(value):
    result = datetime.fromisoformat(value)
    assert result.tzinfo is not None and result.utcoffset().total_seconds() == 0, value
    return result


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def current_source():
    assert subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPO, env=ENV, text=True,
    ).strip() == BASE
    listing = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z',
         '--', 'crates', 'scripts', '.github', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
        cwd=REPO, env=ENV,
    )
    names = sorted(set(os.fsdecode(listing).rstrip('\0').split('\0')))
    assert names and all(name and not Path(name).is_absolute() and '..' not in Path(name).parts
                         for name in names)
    return {name: sha(REPO / name) for name in names}


def local_receipt(folder, seconds, argv, source):
    receipt, command = read(folder / 'receipt.json'), read(folder / 'command.json')
    assert set(command) == {'command', 'environment', 'cwd', 'base',
                            'controller_sha256', 'started'}, folder
    assert all(receipt[key] == value for key, value in command.items()), folder
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s',
                                  seconds, *argv], folder
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, folder
    assert receipt['base'] == BASE and receipt['cwd'] == str(REPO), folder
    assert receipt['controller_sha256'] == CAPTURE_SHA and receipt['environment'] == ENV, folder
    assert read(folder / 'source-before.json') == read(folder / 'source-after.json') == source, folder
    for name in ('stdout', 'stderr'):
        assert sha(folder / name) == receipt[name + '_sha256'], (folder, name)
    assert instant(receipt['started']) <= instant(receipt['finished']), folder
    return receipt


def build_identity(source):
    receipt = local_receipt(BUILD, '900s', [
        'cargo', 'build', '--locked', '--offline', '-p', 'fe2o3-runtime',
        '--no-default-features', '--features', 'hardware-qualification',
        '--example', TARGET, '--profile', 'test', '--message-format=json',
    ], source)
    local = REPO / 'target/debug/examples' / TARGET
    executable = content(local)
    assert executable.startswith(b'\x7fELF')
    identity = {
        'sha256': hashlib.sha256(executable).hexdigest(),
        'byte_length': len(executable), 'target': TARGET, 'test': False,
    }
    assert receipt['executables'] == {str(local): identity}
    rows = [decode_json(line) for line in content(BUILD / 'stdout').splitlines()]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'] is True
    artifacts = [row for row in rows
                 if row.get('reason') == 'compiler-artifact' and row.get('executable')]
    assert len(artifacts) == 1
    artifact = artifacts[0]
    assert artifact['executable'] == str(local)
    assert artifact['target']['name'] == TARGET and artifact['target']['kind'] == ['example']
    assert artifact['profile']['test'] is False
    return receipt, {
        'local': str(local), 'sha256': identity['sha256'],
        'byte_length': identity['byte_length'],
        'build_receipt_sha256': sha(BUILD / 'receipt.json'),
        'source_manifest_sha256': sha(BUILD / 'source-before.json'),
    }


class NativeReceipts:
    def __init__(self, started, finished):
        self.last = started
        self.finished = finished
        self.events = {}

    def event(self, name, argv):
        assert name not in self.events
        folder = HARDWARE / name
        receipt = read(folder / 'result.json')
        assert receipt['argv'] == argv, (name, receipt['argv'], argv)
        assert receipt['exit_code'] == 0 and receipt['timed_out'] is False, name
        assert receipt['local_process_group_absent'] is True, name
        assert receipt['transport_timeout_seconds'] == 360, name
        assert isinstance(receipt['elapsed_seconds'], (int, float))
        assert 0 <= receipt['elapsed_seconds'] <= 370, name
        started, finished = (instant(receipt[key]) for key in ('started', 'finished'))
        assert self.last <= started <= finished <= self.finished, name
        assert (finished - started).total_seconds() <= 370, name
        self.last = finished
        for item in ('stdout', 'stderr'):
            assert sha(folder / item) == receipt[item + '_sha256'], (name, item)
        assert content(folder / 'stderr') == b'', name
        self.events[name] = {
            'receipt_sha256': sha(folder / 'result.json'),
            'started': receipt['started'], 'finished': receipt['finished'],
            'argv': argv,
        }
        return content(folder / 'stdout').decode('utf-8')

    def remote(self, name, argv, bound='30s'):
        return self.event(name, remote_argv(argv, bound))

    def fresh(self, names, at):
        for name in names:
            age = (at - instant(self.events[name]['finished'])).total_seconds()
            assert 0 <= age <= 300, (name, age)

    def admission(self, name, baseline):
        state = decode_json(self.remote(name + '-availability', AVAILABILITY))
        for card, uid, bdf in zip(CARDS, IDS, BDFS, strict=True):
            assert state[card]['Unique ID'] == baseline[card]['Unique ID'] == uid, name
            assert state[card]['PCI Bus'] == baseline[card]['PCI Bus'] == bdf, name
            assert state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0', name
            for field in ('VRAM Total Memory (B)', 'VRAM Total Used Memory (B)'):
                assert state[card][field] == baseline[card][field], (name, card, field)
            assert int(state[card]['VRAM Total Used Memory (B)']) <= 512 * 1024 * 1024, name
            assert int(state[card]['VRAM Total Memory (B)']) >= 16 * 1024 * 1024 * 1024, name
        assert state['system'] == baseline['system'], (name, 'PID roster drift')
        mapping = self.remote(name + '-attachments',
                              ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        records = {}
        for match in re.finditer(
            r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M,
        ):
            pid, count, colon, devices = match.groups()
            devices = [] if devices is None else devices.split()
            assert int(count) == len(devices) == len(set(devices)), name
            assert bool(colon) == bool(devices), name
            assert pid not in records and not {'6', '7'}.intersection(devices), name
            records[pid] = devices
        assert {'PID' + pid for pid in records} == set(state['system']), name
        for pid, devices in records.items():
            assert int(state['system']['PID' + pid].split(',')[1]) == len(devices), name
        memory = self.remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024, name
        names = [name + '-' + suffix for suffix in ('availability', 'attachments', 'host-memory')]
        self.fresh(names, self.last)
        return names


def fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    result = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in result, token
        result[key] = value
    assert len(result) == 28
    return result


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1 and not OUTPUT.exists()
    assert (HARDWARE / 'campaign.json').is_file() and (OUTER / 'receipt.json').is_file()
    started = datetime.now(timezone.utc).isoformat()
    assert sha(HARDWARE / 'campaign.py') == CAMPAIGN_SHA
    assert sha(HARDWARE / 'capture.py') == TRANSPORT_SHA
    assert sha(RAW / 'capture.py') == CAPTURE_SHA
    # The pinned controller's independently written oracle is reusable; none of
    # its subprocess/capture/admission helpers are invoked by this auditor.
    spec = importlib.util.spec_from_file_location('reviewed_unified_segments_campaign', HARDWARE / 'campaign.py')
    campaign = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(campaign)
    assert campaign.BASE == BASE and campaign.REPO == REPO and campaign.ENV == ENV
    assert campaign.IDS == IDS and campaign.CARDS == CARDS and campaign.BDFS == BDFS
    assert campaign.CASES == CASES and len(CASES) == len({name for name, _, _ in CASES}) == 10
    requirements = {name: campaign.expected(case, ids) for name, case, ids in CASES}
    assert all(len(expected) == 28 for expected in requirements.values())
    source = current_source()
    build, binary = build_identity(source)
    outer = local_receipt(OUTER, '1800s', [
        'python3', '-I', '-B', str(HARDWARE / 'campaign.py'),
    ], source)
    assert content(OUTER / 'stderr') == b''
    assert instant(build['finished']) <= instant(outer['started'])
    native = read(HARDWARE / 'campaign.json')
    assert native['accepted'] is True and native['errors'] == []
    assert native['expected_cases'] == len(native['completed']) == 10
    assert native['owned_cleanup_complete'] is True
    assert native['native_process_timeout_seconds'] == 300 and native['transport_timeout_seconds'] == 360
    assert native['exclusive_reservation'] is False
    assert native['performance_acceptance'] is False and native['formal_refinement'] is False
    assert native['controller_sha256'] == CAMPAIGN_SHA and native['transport_sha256'] == TRANSPORT_SHA
    assert native['selected_cards'] == CARDS and native['selected_unique_ids'] == IDS
    assert native['selected_bdfs'] == BDFS and native['limitations'] == campaign.LIMITATIONS
    directory = native['owned_directory']
    assert re.fullmatch(re.escape(PREFIX) + '[A-Za-z0-9]{6}', directory)
    remote_binary = directory + '/unified-segments-witness'
    assert native['binary'] == {**binary, 'remote': remote_binary}
    log = content(OUTER / 'stdout').decode('utf-8').splitlines()
    assert len(log) == 11 and log[:-1] == [name + ' PASS' for name, _, _ in CASES]
    assert decode_json(log[-1]) == native

    receipts = NativeReceipts(instant(outer['started']), instant(outer['finished']))
    baseline = decode_json(receipts.remote('initial-availability', AVAILABILITY))
    baseline_sources = receipts.admission('baseline', baseline)
    assert receipts.remote('create-scratch', ['/usr/bin/mktemp', '-d', PREFIX + 'XXXXXX']).strip() == directory
    receipts.fresh(['initial-availability', *baseline_sources],
                   instant(receipts.events['create-scratch']['started']))
    receipts.event('upload-witness', [
        'scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes',
        binary['local'], 'mi300x:' + remote_binary,
    ])
    assert receipts.remote('initial-hash', ['/usr/bin/sha256sum', remote_binary]).split() == [binary['sha256'], remote_binary]
    total_bytes = total_segments = total_packets = 0
    for (name, case, ids), accepted in zip(CASES, native['completed'], strict=True):
        preflight = receipts.admission(name, baseline)
        assert receipts.remote(name + '-hash', ['/usr/bin/sha256sum', remote_binary]).split() == [binary['sha256'], remote_binary]
        output = receipts.remote(name, [
            '/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i',
            'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8',
            remote_binary, *ids, case,
        ], '300s')
        receipts.fresh(preflight, instant(receipts.events[name]['started']))
        observed = fields(output)
        assert observed == requirements[name], (name, observed, requirements[name])
        assert accepted == {'name': name, 'case': case, 'unique_ids': ids, 'fields': observed}
        total_bytes += int(observed['useful_bytes'])
        total_segments += int(observed['segments'])
        total_packets += int(observed['packets'])
        receipts.admission(name + '-post', baseline)

    probe = ('import json,os,sys; from pathlib import Path; '
        'target=sys.argv[1]; found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe.removesuffix(" (deleted)")==target: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    assert decode_json(receipts.remote('final-owned-processes', [
        '/usr/bin/python3', '-I', '-B', '-c', probe, remote_binary,
    ])) == {'owned_executable_pids': []}
    assert decode_json(receipts.remote('owned-executable-exists', [
        '/usr/bin/python3', '-I', '-B', '-c',
        'import json,os,sys; print(json.dumps({"exists":os.path.lexists(sys.argv[1])}))', remote_binary,
    ])) == {'exists': True}
    assert receipts.remote('final-hash', ['/usr/bin/sha256sum', remote_binary]).split() == [binary['sha256'], remote_binary]
    assert receipts.remote('remove-owned-executable', ['/usr/bin/rm', '--', remote_binary]) == ''
    assert receipts.remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory]) == ''
    assert receipts.remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory]) == ''
    receipts.admission('final', baseline)
    assert len(receipts.events) == 96
    assert set(receipts.events) == {path.parent.name for path in HARDWARE.glob('*/result.json')}
    assert current_source() == source
    assert build_identity(source) == (build, binary)
    assert sha(HARDWARE / 'campaign.py') == CAMPAIGN_SHA
    assert sha(HARDWARE / 'capture.py') == TRANSPORT_SHA
    assert read(HARDWARE / 'campaign.json') == native
    result = {
        'accepted': True, 'started': started,
        'finished': datetime.now(timezone.utc).isoformat(),
        'base': BASE, 'source_files': len(source),
        'source_manifest_sha256': sha(BUILD / 'source-before.json'),
        'build_receipt_sha256': sha(BUILD / 'receipt.json'),
        'outer_receipt_sha256': sha(OUTER / 'receipt.json'),
        'campaign_receipt_sha256': sha(HARDWARE / 'campaign.json'),
        'auditor_sha256': sha(Path(__file__)), 'campaign_controller_sha256': CAMPAIGN_SHA,
        'transport_sha256': TRANSPORT_SHA, 'capture_sha256': CAPTURE_SHA,
        'binary': binary, 'native_events': receipts.events,
        'native_cases': 10, 'cancelled_unpublished_lists': 10, 'completed_native_lists': 10,
        'ordered_descriptors': total_segments, 'planned_packets': total_packets,
        'copied_descriptor_bytes': total_bytes,
        'selected_cards': CARDS, 'selected_unique_ids': IDS, 'selected_bdfs': BDFS,
        'owned_directory': directory, 'owned_cleanup_complete': True,
        'final_point_baseline_restored': True, 'exclusive_reservation': False,
        'performance_acceptance': False, 'formal_refinement': False,
        'general_application_authority': False, 'gpu_payload_oracle': 'full-logical-source-and-destination',
        'limitations': native['limitations'],
    }
    with OUTPUT.open('x') as output:
        json.dump(result, output, sort_keys=True, indent=2)
        output.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'native_events'}, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
