"""Repeat source-bound qualification after the witness hex-format correction."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qualify_initial', RAW / 'qualify.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
REPEAT = {'format', 'whitespace', 'kfd-build', 'kfd-list', 'clippy-kfd', 'clippy-runtime', 'clippy-witness'}
JOBS = [(label.removesuffix('-01') + '-02' if label.removesuffix('-final-01') in REPEAT else label, bound, command)
        for label, bound, command in prior.JOBS]


def main():
    results = []
    for label, bound, command in JOBS:
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'), label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    with (RAW / 'qualification-final-summary.json').open('x') as output:
        json.dump(results, output, indent=2)
        output.write('\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
