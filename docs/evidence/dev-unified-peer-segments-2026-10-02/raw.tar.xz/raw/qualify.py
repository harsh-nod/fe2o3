"""Run complete source-bound CPU qualification on a frozen candidate."""
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
C = ['--locked', '--offline']
R = [*C, '-p', 'fe2o3-runtime']
K = [*C, '-p', 'fe2o3-kfd']
WITNESS = 'gfx942-runtime-unified-segments-smoke'
W = [*R, '--no-default-features', '--features', 'hardware-qualification', '--example', WITNESS]
changed = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=ACMR'], cwd=REPO, text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
RUST = sorted(name for name in set(changed + new) if name.startswith('crates/') and name.endswith('.rs'))
JOBS = [
    ('format-final-01', '120s', ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *RUST]),
    ('whitespace-final-01', '60s', ['git', 'diff', '--check']),
    ('kfd-build-final-01', '900s', ['cargo', 'test', *K, '--all-features', '--lib', '--no-run', '--message-format=json']),
    ('kfd-list-final-01', '120s', ['cargo', 'test', *K, '--all-features', '--lib', '--', '--list']),
    ('clippy-kfd-final-01', '900s', ['cargo', 'clippy', *K, '--all-features', '--lib', '--tests', '--', '-D', 'warnings']),
    ('clippy-runtime-final-01', '900s', ['cargo', 'clippy', *R, '--all-features', '--lib', '--tests', '--', '-D', 'warnings']),
    ('clippy-witness-final-01', '900s', ['cargo', 'clippy', *W, '--', '-D', 'warnings']),
    ('runtime-tests-final-01', '900s', ['cargo', 'test', *R, '--all-features', '--lib']),
    ('runtime-list-final-01', '120s', ['cargo', 'test', *R, '--all-features', '--lib', '--', '--list']),
    ('witness-tests-final-01', '900s', ['cargo', 'test', *W]),
    ('witness-list-final-01', '120s', ['cargo', 'test', *W, '--', '--list']),
    ('deferred-tests-final-01', '900s', ['cargo', 'test', *R, '--no-default-features', '--features', 'hardware-qualification', '--example', 'gfx942-runtime-deferred-peer-chain-smoke']),
    ('deferred-list-final-01', '120s', ['cargo', 'test', *R, '--no-default-features', '--features', 'hardware-qualification', '--example', 'gfx942-runtime-deferred-peer-chain-smoke', '--', '--list']),
    ('doctests-final-01', '900s', ['cargo', 'test', *C, '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--doc']),
    ('check-no-default-final-01', '900s', ['cargo', 'check', *C, '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--no-default-features', '--lib']),
    ('build-witness-final-01', '900s', ['cargo', 'build', *W, '--profile', 'test', '--message-format=json']),
]


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    results = []
    for label, bound, command in JOBS:
        result = subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'), label, bound, *command], check=False)
        results.append(dict(label=label, exit=result.returncode))
        if result.returncode:
            break
    with (RAW / 'qualification-summary.json').open('x') as output:
        json.dump(results, output, indent=2)
        output.write('\n')
    return results[-1]['exit']


if __name__ == '__main__':
    sys.exit(main())
