# Unified Multi GPU Segments

Baseline: ead9cfab9501d8332bf3f89485dfdafbea51eb7c.
Previous turn classification: progress. The cooperative stream-progress SPI,
native one-leaf quantum, tests, final-source native matrix, and evidence were
committed and pushed to both remotes. Full parity remains incomplete.

Current work joins the existing ordered segment API to the unified compute/XGMI
backend. Reuse a single native queue and mapping pair for an immutable, wholly
prevalidated descriptor list. Retain one logical result and exact original
allocation owners until the entire ordered list and closing checks complete.
There must be no silent staged fallback or per-segment public submission.

Source_ci owns runtime admission/root integration. Integration_review owns the
lower checked plan/begin/transfer implementation and lower tests. Host_admission
owns real scripted native runtime lifecycle/owner tests. Root owns review,
hardware witness, qualification, evidence and Git. No Qwen is used.

The refreshed origin/main remains 40509db14eac58a3075cb5c9b34273eaef098648.
Production protected-verifier and semantic-machine providers remain absent.
The ordinary segment Context path has scalar:None and does not yet carry
pending compute provenance; implementing transport does not close that gap.
No authority widening, synthetic production provider, whole-adapter proof,
performance parity, or completion of the overall goal is claimed.

Shared-host execution uses fresh idle/unattached-device admission, bounded
commands, process-owned cleanup, and postchecks. No reset or foreign kill.

## Qualification Attempts

The first lower diagnostic ran nine passing tests, but its capture wrapper was
given Cargo JSON mode together with ordinary test output and failed parsing that
mixed stream. It has no accepted receipt. Final test runs separate artifact JSON
from test output. The first runtime build caught a too-narrow private helper;
the corrected diagnostic passed all twelve new runtime tests.

The witness initially formatted the current sha2 byte array with unsupported
LowerHex. The only source change between final snapshots01 and02 is explicit
bytewise hexadecimal formatting in that example. All final commands are bound
to snapshot 02; no runtime or KFD behavior changed in that correction.

The first metadata proposal rejected the two changed KFD export-file identities.
The adapted proposer permits only exact reviewed module/export additions in
lib.rs and sdma.rs, with fixed pre/post hashes and unchanged other bytes. It
refreshes 13 checker files, 21 SHA literals and 7 source counts, preserving 76 proof
files and all checker predicates. It does not extend any formal proof scope.

The first arithmetic-controller invocations rejected a symlinked verifier path
before executing Verus. Subsequent campaigns use the canonical pinned release
path, with positive proofs, all logical negatives and closing tool checks.

The first KFD remainder ran 1618 successful tests, but its stricter new parser
mistook three empty subprocess progress headers for terminal outcomes. Eleven
offline controls validate the narrowly paired-header correction, including
missing/duplicate/failed/ignored/unknown-header negatives. The initial four
heavy runs were explicitly stopped through their own runner PIDs before the
witness edit; their process groups closed, and their rejected results remain.
No interrupted or rejected run is counted toward the accepted final roster.
