#!/usr/bin/env python3
"""Bounded primary transport, immutable outputs, and local process-group closure."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
name = sys.argv[1]
assert re.fullmatch(r"[a-z0-9-]+", name)
out = Path(__file__).resolve().parent / name
out.mkdir(mode=0o700)
argv = sys.argv[2:]
assert argv and argv[0] in {"ssh", "scp"}
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
timed_out = False
process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
try:
    stdout, stderr = process.communicate(timeout=360)
    status = process.returncode
except subprocess.TimeoutExpired:
    timed_out = True
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        stdout, stderr = process.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate()
    status = 124
try:
    os.killpg(process.pid, 0)
    group_absent = False
except ProcessLookupError:
    group_absent = True
(out / "stdout").write_bytes(stdout)
(out / "stderr").write_bytes(stderr)
receipt = dict(argv=argv, started=started, elapsed_seconds=time.monotonic() - clock,
               finished=datetime.now(timezone.utc).isoformat(), exit_code=status,
               timed_out=timed_out, local_process_group_absent=group_absent,
               transport_timeout_seconds=360,
               stdout_sha256=hashlib.sha256(stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(stderr).hexdigest())
(out / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
print(stdout.decode("utf-8", "replace"))
print(stderr.decode("utf-8", "replace"), file=sys.stderr)
sys.exit(status if status != 0 else (0 if group_absent else 125))
