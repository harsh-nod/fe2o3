#!/usr/bin/env python3
"""Offline outcome-parser regression controls; never launches a Rust test ELF."""
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('shard_final', ROOT / 'kfd_shard_final.py')
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)
KNOWN = sorted(RUNNER.EMPTY_PROGRESS_NAMES)


def summary(count, total=10):
    return (f'test result: ok. {count} passed; 0 failed; 0 ignored; '
            f'0 measured; {total - count} filtered out; finished in 0.01s\n')


def transcript(names, progress=()):
    rows = [f'running {len(names)} tests\n']
    for name in names:
        if name in progress:
            rows.append(f'test {name} ... \nrunning 1 test\n')
        rows.append(f'test {name} ... ok\n')
    return ''.join(rows) + summary(len(names))


class ParserControls(unittest.TestCase):
    def test_plain_success_has_exact_terminal_roster(self):
        names = ['ordinary::a', 'ordinary::b']
        result = RUNNER.parse_outcomes(transcript(names), names, 10)
        self.assertTrue(result['accepted'])
        self.assertEqual(result['empty_progress'], [])

    def test_only_three_known_headers_with_exact_adjacent_success_are_accepted(self):
        names = [*KNOWN, 'ordinary::a']
        result = RUNNER.parse_outcomes(transcript(names, KNOWN), names, 10)
        self.assertTrue(result['accepted'])
        self.assertEqual(result['empty_progress'], KNOWN)
        self.assertEqual(result['other_outcomes'], [])

    def test_real_preserved_remainder_accepts_without_modifying_old_rejection(self):
        old = ROOT / 'kfd-shard-rest'
        receipt = json.loads((old / 'result.json').read_text())
        inputs = json.loads((old / 'inputs.json').read_text())
        output = (old / 'run.stdout').read_bytes()
        self.assertFalse(receipt['accepted'])
        self.assertEqual(receipt['exit_code'], 0)
        self.assertEqual(hashlib.sha256(output).hexdigest(), receipt['stdout_sha256'])
        result = RUNNER.parse_outcomes(output.decode(), inputs['selected'], inputs['total_roster'])
        self.assertTrue(result['accepted'])
        self.assertEqual(sorted(result['empty_progress']), KNOWN)
        self.assertEqual(len(result['passed']), 1618)

    def test_missing_terminal_success_rejects_even_with_success_summary(self):
        names = [KNOWN[0], 'ordinary::a']
        output = transcript(names, [KNOWN[0]]).replace(f'test {KNOWN[0]} ... ok\n', '')
        self.assertFalse(RUNNER.parse_outcomes(output, names, 10)['accepted'])

    def test_duplicate_terminal_success_rejects(self):
        names = [KNOWN[0], 'ordinary::a']
        output = transcript(names, [KNOWN[0]]) + f'test {KNOWN[0]} ... ok\n'
        self.assertFalse(RUNNER.parse_outcomes(output, names, 10)['accepted'])

    def test_failed_ignored_and_other_nonempty_statuses_never_become_progress(self):
        names = [KNOWN[0], 'ordinary::a']
        for status in ('FAILED', 'ignored', 'ignored, native device unavailable', 'ok extra', ' ', 'measured'):
            with self.subTest(status=status):
                output = transcript(names, [KNOWN[0]]).replace(f'test {KNOWN[0]} ... ok\n', f'test {KNOWN[0]} ... {status}\n')
                result = RUNNER.parse_outcomes(output, names, 10)
                self.assertFalse(result['accepted'])
                self.assertTrue(result['other_outcomes'])

    def test_unknown_empty_header_is_not_whitelisted_by_success(self):
        names = ['ordinary::a', 'ordinary::b']
        self.assertFalse(RUNNER.parse_outcomes(transcript(names, names[:1]), names, 10)['accepted'])

    def test_known_header_cannot_pair_with_a_different_test(self):
        names = KNOWN[:2]
        output = (f'test {names[0]} ... \nrunning 1 test\n'
                  f'test {names[1]} ... ok\ntest {names[0]} ... ok\n' + summary(2))
        self.assertFalse(RUNNER.parse_outcomes(output, names, 10)['accepted'])

    def test_duplicate_or_orphan_progress_rejects(self):
        names = KNOWN[:1]
        ordinary = transcript(names, names)
        for addition in (f'test {names[0]} ... \n', f'test {names[0]} ... \nrunning 1 test\ntest {names[0]} ... ok\n'):
            with self.subTest(addition=addition):
                self.assertFalse(RUNNER.parse_outcomes(ordinary + addition, names, 10)['accepted'])

    def test_bad_summary_or_extra_terminal_rows_reject(self):
        names = ['ordinary::a']
        output = transcript(names)
        for mutation in (
            output.replace('1 passed', '2 passed'),
            output.replace('0 ignored', '1 ignored'),
            output + summary(1),
            output + 'test unexpected::b ... ok\n',
            output + 'test ordinary::a ... FAILED\n',
            output + 'test ordinary::a ...\n',
        ):
            with self.subTest(mutation=mutation):
                self.assertFalse(RUNNER.parse_outcomes(mutation, names, 10)['accepted'])

    def test_all_nonparser_safety_and_capture_logic_is_byte_identical(self):
        old = (ROOT / 'kfd_shard.py').read_text()
        self.assertEqual(hashlib.sha256(old.encode()).hexdigest(),
                         'adb5ed28829748abef3e57c51d3404cd5ee7d8e030167ff3d2622f4d9730509a')
        reconstructed = (ROOT / 'kfd_shard_final.py').read_text()
        start = reconstructed.index('EMPTY_PROGRESS_NAMES = frozenset(')
        end = reconstructed.index('def main():\n', start)
        reconstructed = reconstructed[:start] + reconstructed[end:]
        reconstructed = reconstructed.replace('kfd-build-final-02', 'kfd-build-final-01')
        reconstructed = reconstructed.replace('kfd-list-final-02', 'kfd-list-final-01')
        reconstructed = reconstructed.replace("('kfd-shard-02-' + mode)", "('kfd-shard-' + mode)")
        reconstructed = reconstructed.replace(
            "        outcomes = parse_outcomes(output, selected, len(full))\n"
            "        summary, passed, other = (outcomes[key] for key in ('summary', 'passed', 'other_outcomes'))\n",
            "        summary = [line for line in output.splitlines() if line.startswith('test result:')]\n"
            "        expected = (f'test result: ok. {len(selected)} passed; 0 failed; 0 ignored; '\n"
            "                    f'0 measured; {len(full) - len(selected)} filtered out;')\n"
            "        passed = re.findall(r'^test (\\S+) \\.\\.\\. ok$', output, re.M)\n"
            "        other = re.findall(r'^test (\\S+) \\.\\.\\. (?!ok$)(.*)$', output, re.M)\n")
        reconstructed = reconstructed.replace(
            "        accepted = clean_run(execution) and unchanged and source_unchanged and outcomes['accepted']\n",
            "        accepted = (clean_run(execution) and unchanged and source_unchanged\n"
            "                    and Counter(passed) == Counter(selected) and not other\n"
            "                    and len(summary) == 1 and summary[0].startswith(expected))\n")
        reconstructed = reconstructed.replace(
            "            empty_progress=outcomes['empty_progress'], progress_problems=outcomes['progress_problems'],\n", '')
        self.assertEqual(reconstructed, old)


if __name__ == '__main__':
    unittest.main()
