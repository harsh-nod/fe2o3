"""Repeat unchanged workflow controls after the witness-only correction."""
import importlib.util
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('controls', RAW / 'source_controls_baseline.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.OUT = RAW / 'source-controls-final-02-commands'

if __name__ == '__main__':
    sys.exit(module.main())
