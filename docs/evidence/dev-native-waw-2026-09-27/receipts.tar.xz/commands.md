# Native Full-Output Reuse Qualification

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Signed implementation: `527be1ea1b49e5de5c48eb98e08f2b34f5ef52cc`.
CPU tests ran on the code subsequently signed in that commit. These are
development build results, not a hermetic build or native hardware proof.

Cargo checks used `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1` and offline mode.

| Command | Log | Exit/result |
| --- | --- | --- |
| `cargo test --offline -p fe2o3-runtime --all-features --lib native_waw -- --nocapture` | `native-waw-development.log` | 101; fixture borrow-check error |
| Same focused command after compile correction | `native-waw-first-run.log` | 101; 3 passed, 5 fixture/assertion failures |
| Same focused command after fixture corrections and WAR matrix expansion | `native-waw-second-run.log` | 101; 7 passed, 1 scheduling-hint assertion failure |
| `cargo test --offline -p fe2o3-runtime --all-features --lib` | `runtime-all-features.log` | 101; 1673 passed, 3 existing failures, 28 ignored |
| `cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings` | `clippy.log` | 0 |
| `cargo test --offline -p fe2o3-runtime --all-features --doc` | `doctests.log` | 0; 8 + 44 passed |
| `cargo check --offline -p fe2o3-runtime --no-default-features` | `minimal.log` | 0 |
| `cargo fmt -p fe2o3-runtime -- --check` | `fmt.log` | 0 |
| `git diff --check` | `whitespace.log` | 0 |

All eight added native groups and the new Context group passed in the final full
run. The positive native group covers all three predecessor binding positions
times FIFO, same-stream explicit and cross-stream explicit ordering. The Context
group covers same/cross-stream rejection before producer reconciliation and
success afterwards. The existing three `InspectSocket(PermissionDenied)` failures
at `authorized_execution.rs:1317` are not waived or counted as passing.

## Corrected Development Assumptions

- Split fixture borrowing explicitly for the ordinary-submit rejection check.
- Install pending-observation control before FIFO admission, which can progress
  its predecessor during submit; this avoids assuming it remains pending.
- Inspect the pending/active maps, not an absent completed-submission record.
  Keep exact physical-owner, retained-roster and no-publication assertions.
- ReadWrite is excluded from the exact persistent R/R/W shape, but has an
  existing generic admission path; it is not a blanket public rejection.
- `pending_compute_can_publish_under_deadline_v1` permits a progress attempt.
  It is not publication authority. The erroneous assertion was removed while
  retaining pending-launch, absent active-lane, exact-owner and publication checks.

No additional production behavior was changed in response to these fixture
failures. The final implementation broadens only exact full-output wait eligibility.

## Identity and Remote Scope

The signed source patch and signature verification are retained. Compiler,
test-binary and relevant source hashes were measured after qualification; the
test executable is `target/debug/deps/fe2o3_runtime-e03b9552edb097b6`.

`ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x 'hostname'` exited 255 before
connection with a DNS failure, preserved in `mi300x-connection.log`.
No remote files or jobs were created. No GPU, ELF, new Verus or matched HIP/HSA
performance campaign ran. Publication attempts occur after these receipts freeze
and are recorded separately.
