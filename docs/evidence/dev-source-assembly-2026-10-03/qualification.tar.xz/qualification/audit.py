"""Independently replay final qualification receipts without granting authority."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import subprocess

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '38da718e5eef2793f113a1f6a3f1f183d64cbf70'
VERUS = Path('/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


capture = module('normalization_capture', RAW / 'capture.py')
batch = module('normalization_batch', RAW / 'final_cpu.py')
check = module('normalization_check', ROOT / 'crates/fe2o3-verifier/verus/checked_u32_prefix_check.py')
commands = dict(batch.COMMANDS)
commands['proof-02'] = f'python3 -I -B crates/fe2o3-verifier/verus/checked_u32_prefix_check.py --verus {VERUS} --output {RAW}/solver-02'
cohort = capture.snapshot()
for label, command in commands.items():
    folder = RAW / label
    receipt = read(folder / 'receipt.json')
    assert receipt['exit'] == 0 and receipt['source_unchanged'] is True, label
    assert receipt['base'] == BASE and receipt['cwd'] == str(ROOT)
    assert receipt['environment'] == capture.ENV
    assert receipt['controller_sha256'] == sha((RAW / 'capture.py').read_bytes())
    assert receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s',
                                  '2400s' if label == 'proof-02' else '1200s', *shlex.split(command)]
    assert read(folder / 'source-before.json') == cohort == read(folder / 'source-after.json'), label
    for stream in ('stdout', 'stderr'):
        assert sha((folder / stream).read_bytes()) == receipt[stream + '_sha256']

tests = (RAW / 'verifier-02/stdout').read_text()
for summary in ('129 passed; 0 failed; 4 ignored;', '7 passed; 0 failed; 0 ignored;'):
    assert summary in tests
roster = re.findall(r'^(.+): test$', (RAW / 'roster-verifier-02/stdout').read_text(), re.M)
outcomes = re.findall(r'^test (\S+) \.\.\. (ok|ignored)(?:,.*)?$', tests, re.M)
assert len(roster) == len(set(roster)) == 140
assert len(outcomes) == 140 and set(roster) == {name for name, _ in outcomes}
assert sum(outcome == 'ok' for _, outcome in outcomes) == 136
assert '30 passed; 0 failed; 0 ignored;' in (RAW / 'docs-02/stdout').read_text()
assert '1 passed; 0 failed; 0 ignored;' in (RAW / 'extraction-02/stdout').read_text()
extraction = (RAW / 'extraction-02/stderr').read_text()
assert len(re.findall(r'^checked-u32 case=.*status=exit status: 0$', extraction, re.M)) == 2
assert len(re.findall(r'^checked-u32 case=.*status=exit status: 101$', extraction, re.M)) == 4
for reason in ('MissingEntryHelperCheckedAdd', 'AmbiguousEntryHelperCheckedAdd',
               'RootCount', 'unsupported checked-u32 entry prefix: Source'):
    assert reason in extraction
reports = [json.loads(line.split(': ', 1)[1]) for line in extraction.splitlines()
           if line.startswith('fe2o3 checked-u32-prefix extraction: ')]
assert len(reports) == 2
for i, report in enumerate(reports):
    assert report['origin'] == {'argument': i}
    assert report['source_prefix_kinds'] == (['copy', 'copy'] if i == 0 else [])
    for key in ('artifact_or_launch_authority', 'authenticates_compiler_execution',
                'continuation_verified', 'normalization_adapters_proved'):
        assert report[key] is False
    assert report['canonical_kir_version'] == 8 and report['literal'] == 17
    for evaluation in report['conditional_evaluations']:
        value = evaluation['arguments'][i] + 17
        assert evaluation['value'] == value % (1 << 32)
        assert evaluation['overflow'] is (value >= (1 << 32))
for key in ('semantic_mir_sha256', 'kir_identity_sha256'):
    assert reports[0][key] != reports[1][key]
scratch = set(re.findall(r'/tmp/fe2o3-production-extraction-\d+-\d+', extraction))
assert len(scratch) == 1 and all(not Path(path).exists() for path in scratch)

artifacts = {}
for label in ('artifacts-verifier-02', 'artifacts-extraction-02'):
    receipt = read(RAW / label / 'receipt.json')
    assert receipt['executables']
    for path, identity in receipt['executables'].items():
        assert Path(path).stat().st_size == identity['byte_length']
        assert sha(Path(path).read_bytes()) == identity['sha256']
        artifacts[path] = identity
assert {(r['target'], r['test']) for r in artifacts.values()} == {
    ('fe2o3_verifier', True), ('gfx942_local_checked_u32_add_v1', True),
    ('fe2o3-verifier-machine-effect-worker-fixture', False),
    ('fe2o3-verifier-test-recorder', False), ('fe2o3-verus-execution-v2-fixture', False),
    ('production_extraction_driver_v1', True), ('fe2o3-rustc-extract', False),
    ('fe2o3-export-sim', False)}

proof = RAW / 'solver-02'
result = read(proof / 'result.json')
assert result['accepted'] is True and result['source_unchanged'] is True and result['error'] is None
assert result['verified_obligations'] == 71 and result['logical_mutants'] == 48 and result['controls'] == 12
assert result['grants_application_authority'] is False and result['proves_normalization_adapters'] is False
assert result['proves_typed_source_statement_normalization'] is True
assert result['proves_actual_source_span_assembly'] is True and result['proves_terminal_source_statement'] is False
sources = check.snapshot()
proof_hashes = {path: sha(data) for path, data in sources.items()}
assert read(proof / 'source-before.json') == proof_hashes == read(proof / 'source-after.json')
for path, data in sources.items():
    assert (proof / 'inputs' / path).read_bytes() == data
expected = [('positive-before', None, 'fold', None)]
expected += [('negative-' + name, body, 'fold', 'loop' if invariant else 'post')
             for name, (body, invariant) in check.mutants(sources[str(check.BODY)].decode()).items()]
expected += [('negative-basis-' + name, body, 'basis', failure)
             for name, (body, failure) in check.basis_mutants(sources[str(check.BASIS_BODY)].decode()).items()]
expected += [('negative-normalization-' + name, body, target, 'post')
             for name, (body, target) in check.normalization_mutants(sources[str(check.NORMALIZE_BODY)].decode()).items()]
expected += [('negative-assembly-' + name, body, 'assemble', failure)
             for name, (body, failure) in check.assembly_mutants(sources[str(check.ASSEMBLE_BODY)].decode()).items()]
expected += [('positive-after', None, 'fold', None)]
assert [r['name'] for r in result['stages']] == ['controls', 'release-before', *[r[0] for r in expected], 'release-after']
assert len(result['stages']) == 53
for row in result['stages']:
    receipt = read(proof / row['name'] / 'record.json')
    assert row['accepted'] is True and receipt['group_absent'] is True
    assert receipt['status'] == row['status']
for name in ('release-before', 'release-after'):
    folder = proof / name
    assert read(folder / 'record.json')['command'] == [
        '/bin/sh', str(ROOT / check.support.CLOSURE), str(VERUS.parent), str(ROOT / check.support.MANIFEST)]
    assert (folder / 'stdout.log').read_text() == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n'
    assert not (folder / 'stderr.log').read_bytes()
control = proof / 'controls'
assert read(control / 'record.json')['command'] == ['/usr/bin/python3', '-I', '-B', str(ROOT / check.TEST)]
assert not (control / 'stdout.log').read_bytes()
assert '\nRan 12 tests in ' in (control / 'stderr.log').read_text()
assert (control / 'stderr.log').read_text().endswith('\nOK\n')
for name, mutation, target, failure in expected:
    folder = proof / name
    staged = proof / (name + '-source')
    for path in (check.PROOF, check.BODY, check.BASIS_BODY, check.NORMALIZE_BODY, check.ASSEMBLE_BODY, check.base.BODY):
        data = mutation.encode() if mutation is not None and path == check.TARGETS[target]['body'] else sources[str(path)]
        assert (staged / path).read_bytes() == data
    selected = check.TARGETS[target]
    receipt = read(folder / 'record.json')
    assert receipt['command'] == [
        '/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5', '120', str(VERUS),
        '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating', '--output-json',
        '--error-format=json', '--no-report-long-running', '--num-threads', '1', '--multiple-errors', '1',
        *(['--verify-function', '*' + selected['function'],
           *(['--verify-only-module', selected['module']] if 'module' in selected else ['--verify-root'])]
          if mutation is not None else []), str(staged / check.PROOF)]
    assert check.classify(receipt['status'], (folder / 'stdout.log').read_text(),
                          (folder / 'stderr.log').read_text(), staged / check.PROOF, target, failure), name
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
report = dict(accepted=True, base=BASE, accepted_captures=list(commands), source_files=len(cohort),
              proof_files=len(sources), obligations=71, logical_mutants=48, runner_controls=12,
              verifier_passed=136, verifier_ignored=4, doc_tests=30, extraction_cases=6,
              compiler_scratch_absent=sorted(scratch), executables=artifacts,
              full_normalization_proof=False, application_authority=False, gpu_execution=False,
              audit_sha256=sha(Path(__file__).read_bytes()))
(RAW / 'audit-report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'executables'}, sort_keys=True))
