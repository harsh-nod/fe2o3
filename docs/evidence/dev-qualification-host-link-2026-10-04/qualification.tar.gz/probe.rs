fn main() {
    let input = vec![1u64, 2, 3];
    let total = std::thread::spawn(move || input.iter().sum::<u64>()).join().unwrap();
    assert_eq!(total, 6);
}
