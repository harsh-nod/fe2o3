#!/bin/bash
set -Eeuo pipefail
trap 'printf "probe failed at line %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
scratch=/dev/shm/fe2o3-host-link-20261004-5VZugxxg
rust=/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu
if [[ ${1:-} == compile ]]; then
  /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups \
    --bounding-set=-all --inh-caps=-all --ambient-caps=-all \
    /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C FE2O3_TEST_HOST_LINK_PROXY=/usr/bin/cc \
    /usr/bin/python3 -E -s -B "$repo/scripts/tests/qualification_host_link_test.py"
  /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups \
    --bounding-set=-all --inh-caps=-all --ambient-caps=-all \
    /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C \
    "$rust/bin/rustc" "$scratch/probe.rs" --edition=2024 -Ctarget-feature=+crt-static \
    -Crelocation-model=static -Clink-arg=-no-pie -o /run/application-target/probe
  /usr/bin/python3 -E -s -B -c 'import sys,json; from pathlib import Path; sys.path.insert(0,sys.argv[1]); import qualification_host_link as q; p=json.loads((q.ROOT/"premises.json").read_bytes()); assert q.measure(Path(p["rust_root"]))==p; records=list(q.RECORDS.iterdir()); assert len(records)==1; result=q.audit_capture(records[0],p); assert not result["final_application"]; print(json.dumps(result,sort_keys=True))' "$repo/scripts"
  exit
fi
install -d -m 0700 -o 1000 -g 1000 /run/application-target /run/qualification-host-link-records
pin=$(sha256sum "$scratch/cc-proxy")
/usr/bin/python3 -E -s -B "$repo/scripts/qualification_host_link.py" prepare "$rust" "$scratch/cc-proxy" "${pin%% *}"
exec bwrap --die-with-parent --bind / / \
  --ro-bind /run/qualification-host-link-v1/proxy /usr/bin/x86_64-linux-gnu-gcc-13 \
  --cap-add CAP_CHOWN --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
  /bin/bash "$0" compile
