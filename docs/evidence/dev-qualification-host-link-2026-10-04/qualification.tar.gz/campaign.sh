#!/bin/bash
set -Eeuo pipefail
trap 'printf "campaign failed at line %s: %s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR
export PATH=/usr/bin:/bin LANG=C LC_ALL=C PYTHONDONTWRITEBYTECODE=1
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/dev/shm/fe2o3-host-link-20261004-5VZugxxg
install -d -o 1000 -g 1000 -m 0700 "$scratch/storage/work"
setpriv --reuid=1000 --regid=1000 --clear-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all \
  /usr/bin/python3 -E -s -B "$repo/scripts/qualification_input_bundle.py" prepare-application \
  "$repo" "$scratch/genuine-env.json" "$scratch/storage/work/bundle" > "$scratch/bundle-sha256.log"
FE2O3_GENUINE_INPUT_BUNDLE="$scratch/storage/work/bundle"
FE2O3_GENUINE_INPUT_SHA256=$(<"$scratch/bundle-sha256.log")
export FE2O3_GENUINE_INPUT_BUNDLE FE2O3_GENUINE_INPUT_SHA256
[[ $FE2O3_GENUINE_INPUT_SHA256 =~ ^[0-9a-f]{64}$ ]]
chown -R 1002:1002 "$scratch/storage/work"
chmod 0700 "$scratch/storage/work"
cp "$FE2O3_GENUINE_INPUT_BUNDLE/MANIFEST.json" "$scratch/bundle-manifest.json"
printf 'bundle complete; independent copies now owned by UID1002\n'
/usr/bin/time -p /bin/bash "$repo/scripts/qualify-proof-resource-inspection.sh"
