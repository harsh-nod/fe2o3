git diff --exit-code e55af4cae1be9ee67c962706cd2ee933aa550a97 -- crates/fe2o3-runtime crates/fe2o3-runtime-model crates/fe2o3-kfd 
