#!/usr/bin/env bash
set -uo pipefail
root=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-prepared-cancellation-20260927-DnlMPe5J
label=$1
shift
cd "$root" || exit 1
printf '%q ' "$@" > "$out/$label.command"
printf '\n' >> "$out/$label.command"
date -u +%FT%TZ > "$out/$label.started"
"$@" > "$out/$label.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/$label.status"
date -u +%FT%TZ > "$out/$label.finished"
tail -n 30 "$out/$label.log"
exit "$status"
