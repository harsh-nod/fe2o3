# Prepared Cancellation Review Notes

Baseline: 0d7c4a59f26ba0462c51411089de4daf017879fc.

Primary owns all edits/integration/tests. Two native read-only agents reviewed
ownership and test boundaries. Neither ran builds or requested permissions.

The initial regression test added to the baseline failed: after a private
ComputeInFlight marker mutation and public cancellation, active.id was None
instead of Some(6). The before-fix command/log/status record that failure.

Reviews identified and resolved:

- The old code took active and execution before consuming native cancellation,
  losing the outer descriptor on terminal return or native/runtime unwind.
- Keeping active indexed requires stream-tail restoration to exclude the removed
  submission. The shared helper now does so; settlement removes active last.
- Source alone does not determine retained control. Exact same-shape control can
  survive InitializedStorage conversion or a fresh authenticated H2D. Validation
  uses the recorded persistent-control reuse bit; single replay also requires it.
- An inline cancellation root would enlarge every fixed compute pipeline slot.
  A fallibly preallocated box keeps this cancellation-only cost out of published
  slots. It is allocated before any custody move or native effect.
- Unwind uses the existing payload-preserving poison/resume helper.
- Final failure tests explicitly check original Prepared phase/markers on
  preflight rejection and exact cancellation slot/prefix/marker occupancy after
  consuming failure, in addition to owner identities and accounting.

No blocking legal-path defect remained in either final read-only review. This is
code review, not formal verification or proof of complete outcome coverage.

Evidence boundaries:

- 44 child cases are initialized-storage scripted ownership tests, not native
  cancellation execution. Each inspects ownership, then actually drops an
  unrepaired backend and requires SIGABRT with core dumps disabled.
- The synthetic consuming terminal/unwind seam runs with returned typed scripted
  inputs rooted. It does not instantiate native Retryable or ProcessTeardown
  receipts or qualify those outer native return-mapping branches directly.
- Eight healthy cancellation cases cover 1/3 bindings and seeded H2D,
  initialized, replay, and initialized-after-replay origins. Four three-binding
  positive polling cases confirm Prepared remains publishable. The seeded H2D
  fixture is not an upload witness; existing actual write/copy/poll single-input
  H2D cancellation tests are included in the regression suite.
- Native KFD constructed-cancellation tests are separate lower-body evidence,
  not end-to-end runtime/native correspondence or GPU execution.
- Local membership checks rely on private monotone indexes. Callback-free
  restoration/settlement and no reentry are premises, not arbitrary corruption
  recovery. Allocation exhaustion, full conservation, Context composition and
  executable formal refinement remain unproved.
- No shared remote files/jobs were created: the MI300X probe failed DNS.

Developmental failures retained in this directory include the original lost
descriptor regression, test compilation diagnostics, and a positive fixture
which incorrectly expected all H2D read bindings to lose their authentication
on replay. The final fixture intentionally starts three-binding replay controls
from initialized storage, preserving exact typed origins rather than weakening
the source assertion.
