git show -s --format=fuller HEAD 
