git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD 
