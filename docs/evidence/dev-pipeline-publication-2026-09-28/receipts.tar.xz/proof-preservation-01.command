/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus --crate-type lib --no-cheating --triggers-mode silent crates/fe2o3-runtime-model/verus/compute_pipeline_publication_v1.rs 
