python3 -I -B crates/fe2o3-runtime-model/verus/test-compute-pipeline-publication.py 
