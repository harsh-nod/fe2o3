git diff --exit-code HEAD -- crates tools Cargo.toml Cargo.lock 
