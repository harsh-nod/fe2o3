gh issue view 182 --repo harsh-nod/fe2o3 --json number\,title\,state\,updatedAt\,body 
