# Pipeline Publication Review

Source: c012c6fcd955b9d970ecb49ea4ca140ab653c131
Tree: 8c6f03aff50efd1d14cbdc30b5c515e1ba1e9660

Primary owned all edits, integration, builds, tests and solver runs. Two read-only
agents reviewed equivalence/ownership and proof contracts/caller boundaries.
No permission or escalation requests were made. The previous implementation
turn had added unwired bodies; this turn inspected, wired, tested and proved them.

The final serial qualification finished with aggregate status 1. Formal campaign,
14 focused tests, all-target/all-feature runtime Clippy, no-default check,
format and source continuity passed. Full runtime: 1800 passed, 3 failed, 28 ignored,
197.60 seconds. The three authorized_execution telemetry failures are unwaived
InspectSocket(PermissionDenied) at authorized_execution.rs:1317. KFD's separate
library suite, model Rust suites, doctests and native tests were not rerun.
No source edits overlapped builds/tests/format/solver qualification. Earlier
preflights and their errors are retained, not substituted for final receipts.

Preflight history: initial 13 CPU tests passed; review added a sixth new test
covering accepted zero metadata, distant epoch gaps/duplicates and exact zero
lookup. Verus first rejected ambiguous int literals, then a generic Debug bound
from witness unwraps, then missing recursive-count unfolding in a concrete
success witness. These were fixed without assumptions or weakening contracts.
The new general stage-to-settlement theorem and count lemmas bring the final
proof to 26 obligations. Initial Clippy rejected two question-mark opportunities;
both shared lookups now use ?. Initial mutation calibration caught an ambiguous
frontier replacement site; the selector was narrowed to the complete assignment.

The signed authenticated campaign passed original, relocated and closing
26-obligation proofs; all 18 isolated executable-body mutants produced genuine
logical failures. No proof hooks or proof files were mutated. The strict inherited
classifier rejects compile/frontend/resource/internal errors and unknown notes,
and each mutant allows only its selected function's note. Actual diagnostics in
mutation-diagnostics-02.log were inspected: generation/capacity/owner and
transition mutations fail postconditions; scan mutations fail the matching
prefix/uniqueness/candidate invariants. A preliminary jq summary included plain
signature stderr and failed parsing; the corrected summary uses only the 18
mutation stderr logs. It does not alter or replace campaign classification.

Proof scope: shared executable bodies over borrowed mirrored metadata types and
generic opaque Active payloads, with no Copy/Clone bound. Raw acceptance/refusal,
exact returned owner, all-slot/head framing, uniqueness/occupancy preservation,
stage-to-settlement admissibility and a MAX-epoch retry witness are established.
The proof does not mechanically bind the RuntimeComputePipeline/HostMetadataTable
adapters, prove complete contiguous epochs, or authenticate any native outcome.
CPU snapshots observe every populated fixture field and stable Arc/vector
addresses, not native receipt internals. Proof mutants are solver controls,
not executed Rust test mutants. Focused and full CPU results overlap.

Next: model exclusive logical head H=next.unwrap_or(MAX+1) with mathematical
integers. Confirmed entries must cover [frontier,H) exactly; the optional staged
entry is at H, excluded from that interval. Share/prove take_commit_frontier and
quarantine_all. Promotion returns the next Active owner, not proof of physical
retirement or logical completion. Quarantine preserves staged markers and all
custody while changing phases; include outer require_live and AUX restoration.
The current unique_roster predicate alone admits a published epoch 5/frontier 5
with next 100; stage 100/confirm succeeds but leaves an invalid immediate successor.
Do not claim a full inductive pipeline invariant from this packet.

Native bridge remains ordered_publication accepted-custody/recipe/lane guards,
actual classified submit receipt stored before successful outer callback close,
Retryable-only withdrawal, Published-only confirmation, and the transient
Published metadata/Attempt::Published state before completion-cell conversion.
Connect lower no-side-effect retry, Pending/explicit/deferred retains, result
reservations, completion, logical commit, profiling and untargeted lanes next.

Only this task's generated target/debug/incremental and target/debug/examples
caches were removed to recover local disk space. No source, evidence archives or
other worktree artifacts were removed. Unrelated owner-inspection evidence was
preserved. MI300X DNS failed before connection; no remote files/jobs were created.
GitHub API read and both source pushes failed connectivity/DNS. No remote
synchronization, current issue refresh, GPU execution or performance gain claimed.

Freeze this raw directory only after receipt audit and documentation review.
Subsequent documentation-commit checks/push attempts must be outside its archive.
