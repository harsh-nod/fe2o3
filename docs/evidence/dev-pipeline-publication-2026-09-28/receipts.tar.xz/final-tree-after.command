git rev-parse HEAD HEAD\^\{tree\} 
