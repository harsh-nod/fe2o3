bash /home/harsh/.codex-tmp/fe2o3-pipeline-publication-20260928-pg2wu96k/audit.sh 
