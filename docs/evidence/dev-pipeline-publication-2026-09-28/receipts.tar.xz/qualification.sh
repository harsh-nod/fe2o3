#!/usr/bin/env bash
set -uo pipefail
ulimit -c 0
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
raw=/home/harsh/.codex-tmp/fe2o3-pipeline-publication-20260928-pg2wu96k
failed=0
run() {
    bash "$raw/run.sh" "$@" || failed=1
}
run final-source-before git show -s --format=fuller HEAD
run final-tree-before git rev-parse HEAD HEAD^{tree}
run final-signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run final-proof python3 -I -B crates/fe2o3-runtime-model/verus/check-compute-pipeline-publication.py \
    --verus /home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus \
    --output "$raw/proof-campaign"
run final-runtime-focused cargo test -p fe2o3-runtime --all-features --lib compute_state:: -- --test-threads=1
run final-runtime cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1
run final-clippy cargo clippy -p fe2o3-runtime --all-features --all-targets -- -D warnings
run final-no-default cargo check -p fe2o3-runtime --no-default-features
run final-format cargo fmt --all -- --check
run final-whitespace git diff --check
run final-source-continuity git diff --exit-code HEAD -- crates tools Cargo.toml Cargo.lock
run final-tree-after git rev-parse HEAD HEAD^{tree}
exit "$failed"
