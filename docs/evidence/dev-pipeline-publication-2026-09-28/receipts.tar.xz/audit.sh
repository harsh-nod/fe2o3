#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-pipeline-publication-20260928-pg2wu96k
for command in "$raw"/*.command; do
    label=${command%.command}
    if test "$label" = "$raw/receipt-audit"; then continue; fi
    for suffix in log started finished status; do
        test -f "$label.$suffix"
    done
    rg -q '^[0-9]+$' "$label.status"
done
for label in final-proof final-runtime-focused final-clippy final-no-default final-format \
    final-whitespace final-source-continuity final-signature mutation-diagnostics-02; do
    test "$(<"$raw/$label.status")" = 0
done
test "$(<"$raw/final-runtime.status")" = 101
test "$(<"$raw/qualification.status")" = 1
rg -q '^test result: ok\. 14 passed; 0 failed; 0 ignored;' "$raw/final-runtime-focused.log"
rg -q '^test result: FAILED\. 1800 passed; 3 failed; 28 ignored;' "$raw/final-runtime.log"
test "$(rg -c '^test .* \.\.\. FAILED$' "$raw/final-runtime.log")" = 3
test "$(rg -c 'InspectSocket\(Os \{ code: 1, kind: PermissionDenied' "$raw/final-runtime.log")" = 3
cmp "$raw/final-tree-before.log" "$raw/final-tree-after.log"
cmp "$raw/proof-campaign/source-before.json" "$raw/proof-campaign/source-after.json"
jq -e 'length == 26 and all(.[]; .passed == true)
    and ([.[] | select(.status == 1)] | length) == 18
    and ([.[] | select(.status == 0)] | length) == 8' "$raw/proof-campaign/results.json"
for phase in proof-before relocated-proof proof-after; do
    jq -e '."verification-results" == {
        "encountered-error": false, "encountered-vir-error": false,
        "errors": 0, "is-verifying-entire-crate": true, "success": true, "verified": 26
    }' "$raw/proof-campaign/$phase/stdout.log"
done
test "$(<"$raw/source-push-origin.status")" = 128
test "$(<"$raw/source-push-upstream.status")" = 128
test "$(<"$raw/mi300x-connect.status")" = 255
printf 'PASS: final receipts, expected unwaived failures and source continuity audited\n'
