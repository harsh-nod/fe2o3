git diff --exit-code c012c6fcd955b9d970ecb49ea4ca140ab653c131 -- crates tools Cargo.toml Cargo.lock 
