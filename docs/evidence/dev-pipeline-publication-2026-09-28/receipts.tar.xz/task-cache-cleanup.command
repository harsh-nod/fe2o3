rm -rf -- /home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/incremental /home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/examples 
