# Runtime Source-Event Custody Development

Base: fd7a5efece4926d993025a4f62565a46705ca4d5, branch
codex/r65-runtime-drain-versions. The unrelated untracked directory
docs/evidence/dev-owner-inspection-2026-09-23/ was preserved.

The first cargo check --all-features --tests failed with three borrowing errors:
the new helper took an owned OrdinaryLaneIoV1, while with_lane lends a mutable
reference. Both new source submit methods now use the existing mutable-loan
convention. That check's output was observed through the tool, not retained as
a raw log.

focused-1.log is the first compiled five-group run. It failed because the new
subprocess selector included the crate name, and another test aborted during
panic cleanup after assuming CPU cache replacement could run while its unrelated
primary blocker remained live. Direct exact runs of the absent/late and Prepared
tests passed. ordered-failure.log retains the diagnostic backtrace for the cache
replacement assumption. The test now drains that blocker before replacement.

focused-2.log is the nine-group run. It aborted when the ordered test assumed the
dependent would retain its original AUX lane after the blocker was drained.
focused-2-rest.log reruns the other eight exact groups successfully on that ELF.
The dependent's completion now uses the actual runtime stream-to-lane assignment.
Neither test correction weakened production lane/custody checks.

The source-release policy was tightened during independent review: every release
error is terminal at runtime. Exact returned event custody is restored into the
original retained vector first. A returned event proves no consumption, not
transient backpressure. Before/after-release unwind retains an indeterminate
marker and never recycles the completed batch.

The final source also covers injected no-effect native ring refusal through the
real lower rollback body and ordered request resampling. This is CPU I/O, not a
native ring-capacity or GPU execution observation. completion_signal_recycle now
includes unused source-event release on successful completion.

Local cleanup, after independent exact-path/stat/open-handle audit, removed only
five stale, untracked, one-link ELF build products in this worktree:
target/debug/deps/fe2o3_runtime-5709e9f765fa5c9f
target/debug/deps/fe2o3_runtime-84865fc0c8221886
target/debug/deps/fe2o3_runtime-e03b9552edb097b6
target/debug/deps/fe2o3_kfd-0a982ce424b91297
target/debug/deps/fe2o3_kfd-9280442e7aa71d90
Allocated bytes reclaimed: 1,376,145,408. The current runtime/KFD/host binaries
and all frozen evidence were preserved. No remote jobs or roots were created.

Independent read-only review found no blocking custody defect after the release
policy correction. Direct Requested cancellation, runtime-side in-submit terminal
failure/unwind, and native GPU qualification remain coverage boundaries. No new
Verus qualification was run. The historical ordered-settlement shared bodies,
proof files and checkers are unchanged; their changed callers and new source
event state are not covered by that historical source binding.
