#!/usr/bin/env bash
set -euo pipefail
repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
out=/home/harsh/.codex-tmp/fe2o3-application-startup-20261004-WzQnXAxz
cd "$repo"
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
packages=(-p fe2o3-process-identity -p fe2o3-runtime-protocol -p fe2o3-broker-authority-service -p fe2o3-compiler-execution-client -p fe2o3-compiler-execution-supervisor -p cargo-fe2o3)
snapshot() {
    git ls-files --cached --others --exclude-standard -z -- '*.rs' '*.c' '*.toml' '*.lock' '*.json' '*.sh' ':(exclude)docs/**' |
        LC_ALL=C sort -z | xargs -0 sha256sum
}
roots() {
    local artifacts=$1 broker name
    broker=$(jq -Rr 'fromjson? | select(.reason == "compiler-artifact" and .profile.test == true and .target.name == "fe2o3_broker_authority_service") | .executable' "$artifacts" | tail -n 1)
    test -x "$broker"
    for name in \
        linux::observer_channel::application::tests::root_application_session_campaign \
        linux::observer_channel::registry::tests::root_application_registry_transitions \
        linux::observer_channel::registry::tests::root_application_registry_transport \
        linux::application_observation::tests::root_application_observation_campaign; do
        timeout --kill-after=5s 180s /mnt/c/Windows/System32/wsl.exe --user root --exec \
            /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
            --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp --cap-drop ALL \
            --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN \
            --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL \
            /usr/bin/env LD_LIBRARY_PATH="$LD_LIBRARY_PATH" "$broker" --exact "$name" \
            --ignored --nocapture --test-threads=1 > "$out/${name##*::}.log" 2>&1
        tail -n 3 "$out/${name##*::}.log"
    done
    local client
    client=$(jq -Rr 'fromjson? | select(.reason == "compiler-artifact" and .profile.test == true and .target.name == "fe2o3_compiler_execution_client") | .executable' "$artifacts" | tail -n 1)
    test -x "$client"
    timeout --kill-after=5s 180s /mnt/c/Windows/System32/wsl.exe --user root --exec /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp --cap-drop ALL --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP --cap-add CAP_CHOWN --cap-add CAP_DAC_OVERRIDE --cap-add CAP_SYS_PTRACE --cap-add CAP_KILL /usr/bin/env LD_LIBRARY_PATH=/home/harsh/.codex-tmp/fe2o3-r61-execution/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib "$client" --exact application_channel::registration::tests::root_registration_transport_campaign \
        --ignored --nocapture --test-threads=1 > "$out/root_registration_transport_campaign.log" 2>&1
    tail -n 3 "$out/root_registration_transport_campaign.log"
}
if [[ ${1:-all} == roots ]]; then
    roots "$out/qualified-tests.jsonl"
    exit
fi
if [[ ${1:-all} == all ]]; then
    snapshot > "$out/source-before.sha256"
    cargo +nightly-2026-04-03 test --offline --locked "${packages[@]}" --lib --bins \
        --test client --test child_channel --test inherited_child --test static_image --message-format=json \
        > "$out/qualified-tests.jsonl" 2> "$out/qualified-build.log"
fi
cargo +nightly-2026-04-03 clippy --offline --locked --no-deps "${packages[@]}" --all-targets -- -D warnings > "$out/clippy-selected.log" 2>&1
cargo +nightly-2026-04-03 test --offline --locked "${packages[@]}" --doc > "$out/docs.log" 2>&1
rustfmt --edition 2024 --config skip_children=true --check \
    crates/fe2o3-broker-authority-service/src/linux/observer_channel.rs \
    crates/fe2o3-broker-authority-service/src/linux/observer_channel/application.rs \
    crates/fe2o3-broker-authority-service/src/linux/observer_channel/registry.rs \
    crates/fe2o3-broker-authority-service/src/linux/observer_channel/registry/tests.rs \
    crates/fe2o3-compiler-execution-client/src/supervisor_handoff.rs \
    crates/fe2o3-compiler-execution-client/src/supervisor_handoff/application.rs \
    crates/fe2o3-compiler-execution-client/src/supervisor_handoff/application/tests.rs \
    crates/fe2o3-compiler-execution-supervisor/src/handoff.rs \
    crates/fe2o3-compiler-execution-supervisor/src/handoff/application.rs \
    crates/fe2o3-compiler-execution-supervisor/src/launch.rs \
    crates/fe2o3-compiler-execution-supervisor/src/process.rs \
    crates/fe2o3-compiler-execution-supervisor/src/session.rs \
    crates/fe2o3-compiler-execution-supervisor/src/tests/application.rs \
    crates/fe2o3-runtime-protocol/src/application_registration_v1.rs \
    crates/fe2o3-runtime-protocol/src/application_registration_v1/tests.rs \
    crates/fe2o3-runtime-protocol/src/application_registration_v1/ready.rs > "$out/fmt.log" 2>&1
roots "$out/qualified-tests.jsonl"
snapshot > "$out/source-after.sha256"
cmp "$out/source-before.sha256" "$out/source-after.sha256"
sha256sum --quiet --check "$out/source-before.sha256"
git diff --check
git diff --cached --check
jq -Rr 'fromjson? | select(.reason == "compiler-artifact" and .profile.test == true and .executable != null) | .executable' "$out/qualified-tests.jsonl" |
    LC_ALL=C sort -u | xargs sha256sum > "$out/test-binaries.sha256"
