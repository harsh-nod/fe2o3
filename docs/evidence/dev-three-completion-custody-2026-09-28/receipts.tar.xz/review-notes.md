# Review And Qualification Notes

Baseline: 69be2b64ed51a7317f98deda852b814139698972.
Implementation: b74c074cbb379c023c8e90e6dfdf1c38c5f4657f.
Final source including updated regression expectations:
d4bfdea2a949ecf80351f8667360b6215a6a9a2f.
Final source tree: ff3234814fc4824fe6eb2ffe7c916ac92c32f232.

The original slot-failure regression reproduced missing Active before the fix.
The nonfinal focused compile found test snapshot moves of Vec metadata; these
were corrected to borrowed/cloned snapshots outside allocation-counted regions.
The first matrix passed all 162 children, but one reserve-refusal oracle wrongly
expected no preparation calls for initialized storage. Its three promotion
steps run before root reservation; exact storage identity was already unchanged.
Strict Clippy then identified an inline scripted enum and a nonminimal test
predicate. Inline owners intentionally remain inside the already allocated root;
the allowance is restricted to cfg(test), and the predicate was simplified.

The first full campaign against b74c074c aborted in an older producer test that
expected terminal_sdma_custody rather than indexed Published ownership. Another
WAW test had the same stale expectation. Both now compare original published
owner IDs, byte addresses and digests after pre-consumption rejection. A serial
run against 70e3c2f passed 491 tests and found a Context assertion for the old
restoration-time error text. Its updated pre-consumption diagnostic is the only
change in d4bfdea2. None of these nonfinal campaigns is final qualification.

All qualified-* checks ran sequentially on d4bfdea2, without source edits during
builds, tests or formatting. The full runtime/model command exited 101 for the
same three InspectSocket(PermissionDenied) failures at authorized_execution.rs:1317.
They are not waived. Backend serial tests, lower selections, strict Clippy,
no-default check, formatting, signatures and source continuity passed.

Two read-only reviewers found no legal-path ownership defect in the final flow.
The production path keeps exact typed native receipts; all-three restoration
preflight and logical commit preflight precede detached-control release. Data
already restored during a release failure is not claimed unchanged/retryable
control: lower code retains partial cleanup custody. Active is removed last.

The native type audit confirms initialized-storage completion is accepted:
fe2o3-kfd/src/persistent_compute.rs:848-872 returns Initialized for authenticated
initialized data, InitializedAfterDispatch for initialized data without a digest,
and Uninitialized otherwise. Exact-three retirement preflights then maps this
conversion at :888-910. It never returns InitializedStorage after completion.
Runtime restores InitializedAfterDispatch to PersistentReplay, an admitted
post-restoration state. This is source review, not executable refinement.

Remaining concrete boundary work:
- Genuine foreign-session poll and detach rejections returning Some(receipt),
  followed by recovery on the original session, with exact identity/no mutation.
- Atomic three-frontier retirement Err(Self), exact roster retention and retry.
- Production-shared concrete result reducers coupling returned Some to exact
  TerminalRooted custody, None to LowerTerminalOwned, and retirement rejection
  to the exact Detached completed roster.

Existing lower tests cover poll None/currentness (queue_live.rs:16658-16756),
detach None/scope failure (queue_live/persistent_restore_tests.rs:265-343), and
healthy exact detach (:245-262). The runtime's scripted Poll/Detach/Retire labels
share one owner-retaining failure branch; they do not cover those native results.
No confirmed additional ordinary materialized ownership defect was found; its
terminal-without-receipt branches rely on lower poisoned custody and need their
own boundary witnesses before any defect or completeness claim.

MI300X DNS resolution failed. No remote jobs or files were created. Local cleanup
removed only explicitly listed stale test executables in this task's target tree.
No permission requests, escalation, Qwen workers, or unrelated cleanup occurred.
