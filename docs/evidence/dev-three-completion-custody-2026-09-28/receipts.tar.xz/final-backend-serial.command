env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features kfd_backend::tests --lib -- --test-threads=1 --nocapture 
