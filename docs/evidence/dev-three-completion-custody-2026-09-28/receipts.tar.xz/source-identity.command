git show -s --format=fuller --format=%H%n%T%n%B HEAD 
