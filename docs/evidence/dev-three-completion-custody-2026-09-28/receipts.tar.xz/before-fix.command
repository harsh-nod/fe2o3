env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-runtime --all-features three_completion_slot_failure_retains_active --lib -- --nocapture 
