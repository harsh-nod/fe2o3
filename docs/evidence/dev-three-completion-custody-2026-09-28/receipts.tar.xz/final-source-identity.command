git show -s --format=%H%n%T%n%B HEAD 
