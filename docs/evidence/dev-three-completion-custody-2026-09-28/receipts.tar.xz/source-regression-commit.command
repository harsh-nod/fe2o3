git -c gpg.format=ssh -c user.signingkey=/home/harsh/.ssh/id_ed25519 commit -q -S -s -m test\(runtime\):\ check\ indexed\ producer\ custody\ after\ completion\ preflight\ failure 
