# Allocation-Free Event Binding Qualification

Repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Raw output: this directory. No SSH/GPU command was run for this packet.
Source was frozen throughout final proof and CPU qualification.

Initial signed implementation: `dfcb5f8c932949773331494e15012fa918a689ac`.
Final signed source: `a9d3f4ff531a074eefb1f0bc954c5f1783a254e4`.
The second commit only changes the new checker and its calibration.

## Development

All eight `proof-dev-*` stdout/stderr pairs are retained. Runs 1-4 encountered,
respectively, missing Debug for Result::expect, an unsupported wildcard closure
parameter, missing HashMap::get_mut specification, and unsupported panic_fmt.
Run 5 verified 40 obligations with one packet-arithmetic postcondition error.
Explicit checked arithmetic replaced chained closures; run 6 passed 41/0.
Run 7 added the actual inline publication join and reached 42/1; run 8 passed
43/0 after adding proved postconditions to the error-normalization closures.
These observations are not substitutes for the signed campaigns below.

Development used the pinned Verus executable below with sibling Z3 in
VERUS_Z3_PATH, a foreground 120-second timeout, TERM then KILL after five
seconds, and the following verifier flags:

```text
--crate-type lib --triggers-mode silent --no-cheating --output-json
--error-format=json --no-report-long-running --num-threads 4 --multiple-errors 2
crates/fe2o3-runtime-model/verus/completion_event_bind_v1.rs
```

`kfd-bind-development.log` contains the initial three focused binding tests.
`kfd-development-final.log` contains the final development KFD run (1424 passed,
320 construction tests filtered). Final Cargo reruns are separately recorded.

## Signed Campaigns

`VERUS` is `/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus`.
`RAW` is `/home/harsh/.codex-tmp/fe2o3-event-bind-20260928-cmldz2IE`.

The initial `binding-final` campaign at the first source stopped at its original
whole-crate positive: Verus returned status 0, 43 verified, zero errors, but the
strict publication-controller classifier rejected a bitvector informational
note. The final checker inherits the unchanged SHA-authenticated bound-cancel
controller, which already calibrates that exact note. Additional calibration
checks exact notes and rejects unknown/mixed/foreign/nested forms. No ancestor
controller was changed. The initial refusal remains failed evidence.

Run the following sequentially at the final source:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-event-bind.py \
  --output "$RAW/binding-final-2" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-event-bind.py \
  --source --output "$RAW/source-final" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-bound-cancel.py \
  --output "$RAW/bound-final" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-event-batch-release.py \
  --output "$RAW/release-final" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-source-rollback.py \
  --output "$RAW/rollback-final" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-source-rollback.py \
  --adapters --output "$RAW/adapters-final" --verus "$VERUS"
python3 -I -B "$RAW/qualify.py" /home/harsh/.codex-tmp/fe2o3-r61-execution \
  binding-final-2 cpu-final
python3 -I -B "$RAW/audit-final.py"
```

Binding, source publication and bound cancellation use --no-cheating. Release
and both rollback campaigns retain the two explicit hash-table reservation
contracts, so they do not use --no-cheating. Obligation counts overlap between
campaigns; they are not distinct operations or a complete runtime proof.
The shared schema/core changes are why the four older campaigns are rerun.
Historical dispatch-epoch and native-source-failure mutants are not rerun.

Campaigns and the CPU driver retain exact argv, environment, stdout/stderr,
source hashes, status and owned process-group records. The CPU driver checks
exact test summary counts. The independent final audit compares all six final
source snapshots and CPU snapshots, checks whole-crate results and trust flags,
and probes process-group absence, including the initially stopped campaign.
Development commands outside these drivers are not counted as owned campaign
process groups.

## Issue State and Scope

On 2026-09-28 America/Los_Angeles (2026-09-29 UTC),
`gh issue view 182 --repo harsh-nod/fe2o3 --json
number,title,state,updatedAt,body,url` was checked with the configured TLS CA.
It remained OPEN, titled `Runtime: build an asynchronous distributed direct-KFD
execution plane`, last updated `2026-09-27T10:25:24Z`.

The zero-allocation observation scopes only the binder call. Its old explicit
O(N) scratch Vec and post-publication allocation-refusal branch are removed;
algorithmic work remains O(N). The later lane-event collection still allocates.
No timing, HIP/HSA, native receipt, GPU overlap or distributed result is claimed.

## Follow-On Boundaries

Read-only review identified `record_unbound_compute_event_batch` and its
forwarders as the next provenance boundary: fresh event IDs, exact positional
rows, selected-slot pin increments and unchanged neighbors. The current issuer
reserves an occurrence Vec, ledger capacity, then an output Vec. Refusal may
preserve logical state while an earlier successful reservation has changed
capacity; a future proof must not promise physical allocation identity. Its
collision debug assertion relies on private counter freshness, not a demonstrated
reachable public-API fault. Available-slot pin provenance is another caller
invariant and must not silently become an assumption of complete source flow.

The outer source caller's lane-event collect enlarges each element and cannot
reuse the inner Vec allocation in place on the pinned compiler. Pre-reserving
that output before native publication is separate hardening work and requires
an explicit early-error precedence contract. Neither that work nor full outer
terminalization is implemented or proved by this packet.

## Archive

After all commands terminate, copy this owned raw tree, generate an inner
SHA256SUMS for every file, and produce raw.tar.gz. Independently restore to a
new owned directory, verify every hash and recursively compare it to the sealed
source tree. Remove only that owned restored tree and verify its absence.
