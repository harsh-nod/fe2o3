git rev-parse HEAD\^\{tree\} 
