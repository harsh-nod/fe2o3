# Ordered Publication Review and Scope

Qualified source is 0811e1100ff6bde17d6b5da33bc7c567dec971de, tree
67fff1a8590da3d7306b04fdf62c663a84a68501. See the qualified-* receipts for actual
results; preliminary passes are not substituted for the final-source run.

## Implementation and Review

The primary agent owns edits and serialized builds/tests. Two read-only native
collaboration agents reviewed ownership and tests. Neither requested permissions,
edited files, ran builds/tests or invoked external Qwen workers. Final ownership
review found no actionable blocker; this is review, not formal refinement.

The physical pipeline slot is staged before submit with a distinct Publishing
phase and indexed publication root. Staging reserves occupancy and advances the
slot generation, but does not advance the logical epoch or commit frontier.
Only an actually returned retry after successful outer close permits withdrawal.
Published outcomes are installed inside the native lane callback before its
outer close. Before-attempt, consuming, returned-retry and returned-published
failure states remain distinct. Terminal handling preserves the predecessor,
accepted resource/module/deferred-order retains and one indexed target, while
settling only Pending FIFO and explicit-dependency handoff metadata once.

The shared Attempt::submit body also serves initial binding and Prepared retry;
those workflows require regression qualification. Native predecessor admission,
recipe identity and shape, and single-packet retirement metadata remain checked.
There is no new public API, fake public native receipt, compatibility fallback,
or exception to ordinary constructors' fail-closed authority.

Review corrections integrated before signing:
- Capture published_at before confirm, preserving the prior publication boundary.
- Move the old source-wiring audit to the new adapter.
- Snapshot every untouched lane/frontier/pipeline owner and Pending recipe.
- Add public preflight corruption and identity-exhaustion controls.
- Account for primary, AUX and repeated predecessor observations in AUX public
  polling scripts. Require script exhaustion, no submission, and an explicitly
  complete dependency cursor before the corruption is introduced.

The initial six focused groups passed. Expanded tests exposed two fixture-script
failures on AUX because public polling first visits both occupied lanes and then
visits the ordered predecessor again. The correction changes only the scripts,
not production polling. All nine corrected groups passed before the final
dependency-cursor assertion. A preliminary strict Clippy failure was the test's
manual modulo predicate; it was replaced with is_multiple_of. These failed
receipts remain archived.

## Test Accounting

Nine registered groups comprise four container groups and five runtime workflow
groups. Workflow instances are 40 write-binding fault cases (two lanes, frontier
or Published-pipeline predecessor, ten faults), 40 matching unrepaired-Drop
children, 13 corrupt-custody refusals, four slot/epoch-exhaustion controls, and
12 read/write retry-publication-ordered-completion controls with Published,
Completed or PhysicallyRetired pipelined predecessors. These 109 instances are
not 109 registered tests or native launches. Fault coverage does not include all
predecessor phases or both access modes. Successful B/C/D publication originates
from public Pending admission and flush but uses explicit scripted receipts.

Container tests include 128 withdrawals in each of empty/older configurations,
stale identities, ten corrupt/quarantined metadata cases, checked exhaustion,
and two allocation-counted controls. The zero-allocation claim excludes owner
construction, preparation, public flush, profiling and native submission.

Staging/confirmation preflight scans configured slots. Custody checks and staging
occur before the publication timer. No end-to-end latency, high-depth asymptotic
improvement, hardware throughput, or HIP/HSA performance claim follows.

## Next Refinement and Receipt Work

The existing R60 model is not correspondence evidence for this implementation:
- Rust enqueue_model_only allocates identity and advances the epoch before
  publication; Verus retry_publication_v1 is an identity transition. Model
  physical staging separately from confirmed epochs and preserve Pending's
  accounting across a withdrawal that burns only slot generation. Publishing
  must not be equated with cancellable Prepared.
- R60 HostCommitted requires profile_visible and host_commit_v1 changes both
  atomically. Runtime logical settlement precedes optional/fallible observation.
  Separate those effects and retain the committed prefix on reporting failure.
- Existing R60 has capacity 64. It does not qualify the 1024-slot development
  profile merely because the slot representation is shared.
- The recycled observation carries packet_count, not an independent target
  identity. Exact correspondence must follow consuming and returning custody at
  the same indexed target, with lower completion identity checks and outer-close
  success. Test mutations must redirect a receipt to a sibling, commit before
  outer close, and advance a frontier while publication is staged.

A minimal native-receipt bridge can extract the concrete submission Attempt
enum and its submit implementation to a private runtime source file, reexport it
at its old path, and compile that exact source in KFD queue_live unit tests.
Existing private multi-inflight fixtures produce real typed batches, completed
receipts, classified retry/rejection/terminal errors and recycle observations.
Use them for success/complete/recycle, signal-capacity retry and recovery,
typed terminal failure, no-dispatch rejection and AUX unwind after storing the
returned batch. No public constructors, dependency cycle or generic framework
are needed. This would qualify the receipt cell with real lower CPU receipts,
not the whole runtime Active/Pending handoff or GPU execution. Completion needs
a separately scoped extraction; do not move the large execution enum solely to
make testing convenient.

Use the existing shared-source/checker approach in
crates/fe2o3-runtime-model/verus/check-compute-peer-gate.py with mutations of
production transition bodies, not only independent-model counterexamples.

The final proof review recommends a new narrow indexed-transition packet instead
of revising the historical independent R60 46-obligation/26-negative claim.
Additional adapter obligations are the distinction between NativeOwned, returned
state and terminal quarantine; actual Some(completed) authority for recycle
retry; and FIFO/explicit-retain settlement versus deferred-order conservation.
R60 permits an Exact(Failed) result, whereas this ordinary native path commits
Succeeded on Ready. Abstract failed-completion cases are not proof of native
failed-completion support. Classifier proofs alone cannot establish correct
caller wiring, native contracts, callback ordering or concrete resource custody.

The read-only review found a pinned local verifier at
/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus,
version 0.2026.08.09.92f466f, with accompanying rust_verify and z3 files.
This campaign did not execute those tools. The peer-gate runner uses python3 -I -B,
a new canonical output path, authenticated closure, signed clean source, and
exact positive/logical-negative classification. The historical verify-verus.sh
has no focused R60 CLI filter.

## External State

MI300X SSH failed name resolution before connection. No remote jobs/files or GPU
use occurred. GitHub API issue refresh failed. The separate web reader retrieved
https://github.com/harsh-nod/fe2o3/issues/182 on 2026-09-28 UTC, displaying Open
but identifying its content as crawled last week. That cached view reiterates
direct-KFD async and distributed ownership, generated launches, bounded
resources, authenticated multi-host execution, collectives and mechanically
verified transitions. It is not a live API status confirmation.

Native R125, Admission R118B, Resources R116/V3 and all milestone acceptance
statuses remain unchanged. No full parity, protected Worker application, native
execution, formal correspondence, or matched-performance acceptance is claimed.

## Final Qualification

The signed source's ordered selection passed 9 and materialized selection passed 35.
The full runtime library finished 1794 passed, 3 failed, 28 ignored. All failures are
the same three authorized_execution telemetry fixtures at line 1317 with
InspectSocket(PermissionDenied). They are unwaived. Parsing that completed log
gives 897 backend passes and 28 ignored, with no unresolved backend records.
Strict all-feature/all-target runtime+KFD Clippy, runtime no-default check,
workspace formatting, source continuity and signature verification all passed.
The aggregate runner returns 1 because the full runtime test returns 101.

Both source push attempts failed DNS for github.com. Their exact commands and
statuses are archived. No remote publication is implied. Final documentation
push attempts occur after this archive is frozen and are reported separately.
