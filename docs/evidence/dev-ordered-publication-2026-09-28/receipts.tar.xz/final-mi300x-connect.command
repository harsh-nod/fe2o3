timeout 20 ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x true 
