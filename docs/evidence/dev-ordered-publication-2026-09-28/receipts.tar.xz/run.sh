#!/usr/bin/env bash
set -uo pipefail
ulimit -c 0
raw=/home/harsh/.codex-tmp/fe2o3-ordered-publication-20260928-i82Seew1
label=$1
shift
if test -e "$raw/$label.command"; then
    printf 'receipt already exists: %s\n' "$label" >&2
    exit 2
fi
printf '%q ' "$@" > "$raw/$label.command"
printf '\n' >> "$raw/$label.command"
date -u +%FT%TZ > "$raw/$label.started"
"$@" > "$raw/$label.log" 2>&1
status=$?
printf '%s\n' "$status" > "$raw/$label.status"
date -u +%FT%TZ > "$raw/$label.finished"
cat "$raw/$label.log"
exit "$status"
