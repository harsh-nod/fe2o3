bash /home/harsh/.codex-tmp/fe2o3-ordered-publication-20260928-i82Seew1/qualify.sh 0811e1100ff6bde17d6b5da33bc7c567dec971de 
