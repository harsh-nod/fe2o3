timeout 60 git push origin HEAD 
