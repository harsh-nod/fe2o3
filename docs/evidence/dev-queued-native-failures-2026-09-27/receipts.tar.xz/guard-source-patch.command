git show --format=fuller --binary HEAD 
