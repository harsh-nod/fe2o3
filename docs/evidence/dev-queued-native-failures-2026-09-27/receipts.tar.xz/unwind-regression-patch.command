git diff --binary HEAD -- crates/fe2o3-runtime/src/kfd_backend/tests/queued_producer_context_tests/failure_tests.rs 
