git log -1 --format=%H%n%T%n%P%n%B 
