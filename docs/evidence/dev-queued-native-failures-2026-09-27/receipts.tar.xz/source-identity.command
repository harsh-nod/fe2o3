git log -1 --format=fuller --format=%H%n%T%n%P%n%B 
