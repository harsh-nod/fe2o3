git diff --exit-code 84417cfec88563cee57ad69c0625ec27a51ee411 -- crates docs/runtime-successor-writer-plan-v1.md 
