#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-root-occurrence-20261004-IxSRF18F
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly evidence="$repo/docs/evidence/dev-root-occurrence-observation-2026-10-04"
cd "$scratch"
for status in final check artifact qualify consumers; do
    test "$(<"$status.status")" = 0
done
cmp binary.before.sha256 binary.after.sha256
cd "$repo"
git diff --binary HEAD -- \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff.rs \
    crates/fe2o3-artifact-transaction/src/compiler_module_handoff/semantic_v3/tests/observation.rs \
    crates/fe2o3-artifact-transaction/src/lib.rs \
    crates/fe2o3-artifact-transaction/src/retained_durable_directory.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_occurrence.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_supervision.rs \
    crates/fe2o3-broker-authority-service/src/compiler_execution_supervision/tests/observer.rs \
    crates/fe2o3-broker-authority-service/src/lib.rs \
    crates/fe2o3-broker-authority-service/src/linux.rs \
    crates/fe2o3-broker-authority-service/src/linux/client_session.rs > "$scratch/code.patch"
cd "$scratch"
tar --sort=name --mtime=2026-10-04T00:00:00Z --owner=0 --group=0 --numeric-owner \
    -czf "$evidence/evidence.tar.gz" \
    code.patch package.sh final.sh check.sh check-artifact.sh check-consumers.sh inside-root.sh qualify.sh \
    broker.log broker-doc.log broker-clippy.log broker-build.json broker-build.log \
    artifact.log artifact-doc.log artifact-clippy.log artifact-all-target-clippy.log \
    consumers.log host.log formatting.log whitespace.log \
    binary.before.sha256 binary.after.sha256 \
    cross_uid_owned_occurrence.log cross_uid_publication_lock_contention.log \
    final.status check.status artifact.status qualify.status consumers.status \
    development-existing-lint.log development-root-fixture-mode.log initial intermediate
sha256sum code.patch "$evidence/evidence.tar.gz"
