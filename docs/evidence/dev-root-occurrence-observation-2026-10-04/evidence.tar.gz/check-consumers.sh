#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-root-occurrence-20261004-IxSRF18F
trap 'printf "%s\n" "$?" > "$scratch/consumers.status"' EXIT
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-compiler-execution-issuer -p fe2o3-compiler-execution-supervisor -p fe2o3-compiler-execution-coordinator --lib -- --test-threads=1 > "$scratch/consumers.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-host --lib -- --test-threads=1 > "$scratch/host.log" 2>&1
rustfmt +nightly-2026-04-03 --edition 2024 --check crates/fe2o3-artifact-transaction/src/lib.rs crates/fe2o3-artifact-transaction/src/compiler_module_handoff.rs crates/fe2o3-artifact-transaction/src/retained_durable_directory.rs crates/fe2o3-broker-authority-service/src/lib.rs crates/fe2o3-broker-authority-service/src/linux.rs crates/fe2o3-broker-authority-service/src/compiler_execution_supervision.rs crates/fe2o3-broker-authority-service/src/compiler_execution_occurrence.rs > "$scratch/formatting.log" 2>&1
git diff --check > "$scratch/whitespace.log" 2>&1
