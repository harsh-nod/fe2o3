#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-root-occurrence-20261004-IxSRF18F
trap 'printf "%s\n" "$?" > "$scratch/check.status"' EXIT
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1 CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_DISABLE_HIP_DISCOVERY=1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service --lib -- --test-threads=1 > "$scratch/broker.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service --doc > "$scratch/broker-doc.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline -p fe2o3-broker-authority-service --all-targets -- -D warnings > "$scratch/broker-clippy.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline -p fe2o3-broker-authority-service --lib --no-run --message-format=json > "$scratch/broker-build.json" 2> "$scratch/broker-build.log"
