#!/bin/bash
set -euo pipefail
cd /home/harsh/.codex-tmp/fe2o3-root-occurrence-20261004-IxSRF18F
trap 'printf "%s\n" "$?" > final.status' EXIT
bash check.sh
bash check-artifact.sh
bash qualify.sh
bash check-consumers.sh
