#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-compiler-closure-20261004-vdZEvhT3
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly destination="$repo/docs/evidence/dev-compiler-closure-check-2026-10-04"
readonly source=e10b93ca7001f5ca4fb52348d0f104db3ce58106
test "$(<"$scratch/final.status")" = 0
test "$(<"$scratch/check.status")" = 0
test "$(<"$scratch/qualified-1/status")" = 0
test "$(<"$scratch/qualified-2/status")" = 0
cd "$scratch"
printf '%s\n' \
    '4acc9acc76d5079515b46346a485974457b5a79893cfb01112423c89aeb5aa10  rustup-init' \
    '3b8d5391b6b484a4c81fd000b6064885ad967ec3cb966bc57603f3fb3ebf0ed5  libc.deb' \
    '7074b6a2f6367a10d280c00a1cb02e74277709180bab4f2491a2f355ab2d6c20  zlib.deb' \
    "fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715  $repo/target/qualification-native-workers/fb020a09969938d7fa849e106a146e81668d9d0b0d7dd40ded0e2145e6836715/fe2o3-llvm-link-worker" \
    | sha256sum -c - > "$scratch/runtime-inputs.log"
cd "$repo"
sha256sum -c "$scratch/final-source-files.sha256" > "$scratch/source-final.log"
git diff --binary 95aa35708e68fbd25fdbc76c9aa00231f3ce349e "$source" > "$scratch/source.patch"
git rev-parse "$source" > "$scratch/source-commit.txt"
git -c gpg.ssh.allowedSignersFile=/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers \
    log -1 --show-signature --format=fuller "$source" > "$scratch/source-signature.log" 2>&1
rustfmt +nightly-2026-04-03 --edition 2024 --check --config skip_children=true \
    crates/fe2o3-host/src/lib.rs crates/fe2o3-host/src/recovered_worker_v3_admission.rs \
    crates/fe2o3-host/src/recovered_worker_v3_admission/compiler_closure.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/subject.rs \
    crates/cargo-fe2o3/tests/fixtures/compiler_closure.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_pending.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs > "$scratch/rustfmt.log" 2>&1
git diff --check > "$scratch/whitespace.log"
cmp "$scratch/qualified-2/captures/Good/independent-subject.bin" \
    "$scratch/qualified-2/captures/Good/subject.bin"
test -z "$(ls -A "$scratch/qualified-1/tmp")"
test -z "$(ls -A "$scratch/qualified-2/tmp")"
test ! -e /opt/fe2o3/verus-runtime-v2/functional-refinement-0.2026.08.02-b677dd5
/mnt/c/Windows/System32/wsl.exe --user root --exec /bin/rm -r -- "$scratch/root"
test ! -e "$scratch/root"
printf '%s\n' 'Both native campaigns exited successfully; test TMPDIRs empty.' \
    'Private runtime namespace gone; no host protected runtime installation.' \
    'Owned root library overlay removed. No MI300X resources used.' > "$scratch/cleanup.log"
mkdir "$scratch/evidence"
mkdir -p "$destination"
cp "$scratch/"*.sh "$scratch/"*.log "$scratch/"*.status "$scratch/source.patch" \
    "$scratch/source-commit.txt" "$scratch/final-source-files.sha256" "$scratch/evidence/"
cp -r "$scratch/initial-check" "$scratch/qualified-1" "$scratch/qualified-2" "$scratch/evidence/"
cd "$scratch/evidence"
find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum -c MANIFEST.sha256 > "$scratch/manifest-verification.log"
tar -czf "$destination/evidence.tar.gz" -C "$scratch/evidence" .
tar -df "$destination/evidence.tar.gz" -C "$scratch/evidence"
sha256sum "$destination/evidence.tar.gz" "$scratch/source.patch"
