#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-compiler-closure-20261004-vdZEvhT3
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly home=/home/harsh
readonly libs="$scratch/root/usr/lib/x86_64-linux-gnu"
readonly installed=/opt/fe2o3/verus-runtime-v2/functional-refinement-0.2026.08.02-b677dd5
[[ $EUID == 0 ]]
if [[ ${1:-} == inside ]]; then
    shift
    /bin/bash "$repo/scripts/functional-refinement-verus-runtime-v1.sh" provision \
        "$home/factory/.tools/verus-0.2026.08.02.b677dd5/verus-x86-linux" \
        "$home/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu" "$scratch/rustup-init" "$installed"
    exec /usr/bin/setpriv --reuid=1000 --regid=1000 --clear-groups \
        --inh-caps=-all --ambient-caps=-all --bounding-set=-all "$@"
fi
if [[ ! -e "$libs" ]]; then
    install -d -m 0755 "$libs"
    for source in /usr/lib/x86_64-linux-gnu/*; do
        ln -s "/host-lib/${source##*/}" "$libs/${source##*/}"
    done
    for name in ld-linux-x86-64.so.2 libc.so.6 libdl.so.2 libm.so.6 libpthread.so.0 librt.so.1; do
        cp --remove-destination -- "$scratch/glibc/usr/lib/x86_64-linux-gnu/$name" "$libs/$name"
    done
    cp --remove-destination -- "$scratch/zlib/usr/lib/x86_64-linux-gnu/libz.so.1.3" "$libs/libz.so.1.3"
    cp --remove-destination -- /usr/lib/x86_64-linux-gnu/libgcc_s.so.1 "$libs/libgcc_s.so.1"
    cp --remove-destination -- /usr/lib/x86_64-linux-gnu/libstdc++.so.6.0.33 "$libs/libstdc++.so.6.0.33"
    ln -sf libz.so.1.3 "$libs/libz.so.1"
    ln -sf libstdc++.so.6.0.33 "$libs/libstdc++.so.6"
fi
exec bwrap \
    --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
    --proc /proc --dev /dev --perms 1777 --tmpfs /tmp --dir /run \
    --perms 0755 --tmpfs /opt --dir /usr --dir /usr/lib --dir /home \
    --ro-bind /usr/bin /usr/bin --ro-bind /usr/share /usr/share \
    --ro-bind /usr/lib/gcc /usr/lib/gcc --ro-bind /usr/libexec /usr/libexec \
    --ro-bind /usr/lib/x86_64-linux-gnu /host-lib \
    --ro-bind "$libs" /usr/lib/x86_64-linux-gnu \
    --symlink usr/bin /bin --symlink usr/lib /lib --symlink usr/lib64 /lib64 \
    --dir /usr/lib64 --symlink ../lib/x86_64-linux-gnu/ld-linux-x86-64.so.2 /usr/lib64/ld-linux-x86-64.so.2 \
    --ro-bind /etc /etc --ro-bind "$home" "$home" \
    --bind "$home/.cargo" "$home/.cargo" --bind "$repo/target" "$repo/target" \
    --bind "$scratch" "$scratch" --chdir "$repo" \
    --setenv HOME "$home" --setenv CARGO_HOME "$home/.cargo" --setenv RUSTUP_HOME "$home/.rustup" \
    --setenv PATH "$home/.cargo/bin:/usr/bin:/bin" \
    --setenv LD_LIBRARY_PATH "/usr/lib/x86_64-linux-gnu:$home/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib:$repo/target/debug/deps" \
    --setenv CARGO_BUILD_JOBS 4 --setenv CARGO_INCREMENTAL 0 \
    --setenv CARGO_PROFILE_DEV_DEBUG 0 --setenv CARGO_PROFILE_TEST_DEBUG 0 \
    --setenv CARGO_PROFILE_TEST_OPT_LEVEL 1 --setenv CARGO_PROFILE_TEST_DEBUG_ASSERTIONS true \
    --setenv CARGO_PROFILE_TEST_OVERFLOW_CHECKS true --setenv RUST_TEST_THREADS 1 \
    --setenv FE2O3_HIP_SYS_DISABLE 1 --setenv FE2O3_DISABLE_HIP_DISCOVERY 1 \
    --setenv FE2O3_FUNCTIONAL_REFINEMENT_TEST_RUNTIME_ROOT "$installed" \
    --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
    /bin/bash "$scratch/isolated-runtime.sh" inside "$@"
