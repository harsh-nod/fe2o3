#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-compiler-closure-20261004-vdZEvhT3
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
sha256sum crates/fe2o3-host/src/lib.rs \
    crates/fe2o3-host/src/recovered_worker_v3_admission.rs \
    crates/fe2o3-host/src/recovered_worker_v3_admission/compiler_closure.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill.rs \
    crates/fe2o3-host/src/worker_v3_verification_admission/conditional_fill/subject.rs \
    crates/cargo-fe2o3/tests/fixtures/compiler_closure.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_host.rs \
    crates/cargo-fe2o3/tests/fixtures/conditional_fill_pending.rs \
    crates/cargo-fe2o3/tests/worker_v3_load_envelope_vertical.rs \
    > "$scratch/final-source-files.sha256"
