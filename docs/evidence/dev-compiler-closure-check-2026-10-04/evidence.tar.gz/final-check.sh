#!/bin/bash
set -euo pipefail
readonly scratch=/home/harsh/.codex-tmp/fe2o3-compiler-closure-20261004-vdZEvhT3
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
test "$(<"$scratch/check.status")" = 0
mkdir "$scratch/initial-check"
mv "$scratch/host-tests.log" "$scratch/host-doc-tests.log" "$scratch/vertical-tests.log" \
    "$scratch/v2-tests.log" "$scratch/host-clippy.log" "$scratch/vertical-clippy.log" \
    "$scratch/check.status" "$scratch/initial-check/"
trap 'printf "%s\n" "$?" > "$scratch/final.status"' EXIT
sha256sum -c "$scratch/final-source-files.sha256" > "$scratch/source-before.log"
bash "$scratch/check.sh"
sha256sum -c "$scratch/final-source-files.sha256" > "$scratch/source-after.log"
