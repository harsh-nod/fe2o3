# Native SDMA ancestry development receipts

Worktree: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Baseline: `f8a460b5bc6e6ad535d31b726212f1db037cb69d`.
Qualified source: `ce6075a75e80fc96d5d4bf3c27cc6f449a369d23`.
Branch: `codex/r65-runtime-drain-versions`.

All Cargo build/check/test commands used `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1`
and `--offline`. No dependency update or network fallback was used for builds.
Some commands waited for the same Cargo build lock; their elapsed times are not
performance measurements. All execution handles were observed through completion.

## Final qualification

- `cargo test --offline -p fe2o3-runtime --all-features --lib`:
  `runtime-qualified.log`, exit 101, 1662 passed, 3 failed, 28 ignored.
  All six newly added tests pass. The three failures are unchanged telemetry
  tests failing `InspectSocket(PermissionDenied)` at authorized_execution.rs:1317.
- `cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings`:
  `clippy-qualified.log`, exit 0.
- `cargo test --offline -p fe2o3-runtime --all-features --doc`:
  `doctests.log`, exit 0, 52 passed (8 merged and 44 individual).
- `cargo check --offline -p fe2o3-runtime --no-default-features`:
  `minimal-check.log`, exit 0. This is a compile check, not minimal-feature tests.
- `cargo fmt -p fe2o3-runtime -- --check`: `formatting.log`, exit 0.
- `git diff --cached --check`: `whitespace.log`, exit 0 before source commit.
- `git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD`:
  `signature.log`, exit 0 for the source commit. The commit was SSH-signed and
  signed off with the configured author. `source-commit.txt` is its git object.
- `sha256sum -c source-sha256.txt` from the worktree passed for all five source
  files after compilation and commit. `source.patch` includes the new test module
  and is relative to the baseline. `test-binary-sha256.txt` identifies the library
  test binary; `compiler.log` records `rustc --version --verbose`.

## Retained development outcomes

- `focused-initial.log`: `cargo test ... --lib native_sdma_ -- --nocapture`,
  exit 101, 2 passed and 1 failed. The D2D fixture incorrectly scripted directional
  Poll/Retire instead of PollSameDevice/RetireSameDevice. Corrected the fixture.
- `focused-expanded.log`: same filter, exit 0, all five SDMA test groups passed
  before the last integrity/index optimization and peer regression were added.
- `runtime-full.log`: intermediate full suite, exit 101, 1661 passed, 3 known
  socket-permission failures, 28 ignored. `clippy.log`: intermediate strict pass.
- `runtime-final.log`: superseded candidate, exit 101, SIGABRT during the full
  suite. All six new groups passed, but a broader FIFO preflight check changed an
  existing injected missing-predecessor failure from post-admission to pre-admission.
- `runtime-serial-diagnostic.log`: `cargo test ... --lib -- --test-threads=1 --nocapture`,
  exit 101, identifies that abort in
  `scripted_initial_compute_progress_rejection_preserves_accepted_custody`.
  The guard now rejects positively identified foreign streams, preserving the
  established missing-record terminal path and its accepted custody.
- `source-before-missing-tail-fix.sha256` identifies that superseded source;
  `clippy-final.log` is its successful strict check, not the final source receipt.
- `peer-focused.log`: the new private-DMA bypass test passed on the superseded
  candidate and again in the final full suite.

No test was skipped, weakened, or modified to conceal the three environment
failures. No permission escalation or sandbox bypass was requested.

## External access and limits

`ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname` exited 255; see
`mi300x-access.log`. DNS failed before connection, so no remote artifacts or jobs
were created. There was no GPU run, Verus campaign, ELF audit, distributed-host
qualification, or KFD/HIP/HSA performance comparison. Scripted owners validate CPU
scheduling and custody, not machine-code execution or physical memory ordering.

Publication receipts are kept separately so this qualification directory can be
frozen before the documentation commit and both final push attempts.
