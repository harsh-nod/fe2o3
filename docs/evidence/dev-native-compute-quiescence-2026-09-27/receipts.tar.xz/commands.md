# Native Compute Quiescence Development Receipts

Working directory: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Base: `5bec483449281ccc60d818de6587db91cb5f3268`.
Branch: `codex/r65-runtime-drain-versions`.
All Cargo commands use `CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1` and `--offline`.
The primary agent owns edits and execution. Two read-only agents reviewed
ownership, mixed FIFO/copy behavior, integrity, fixtures, and proof boundaries.
Unrelated `docs/evidence/dev-owner-inspection-2026-09-23/` is preserved.

Final implementation: `f1ec522a4ed217d0a293d5dcb501a41c72e8000a`.
SSH signing and `git verify-commit` passed. `source-sha256.txt` and
`runtime-test-binary-sha256.txt` identify the final source and runtime test binary.

## Final Qualification

- `cargo test --offline -p fe2o3-runtime --all-features --lib`, exit 101:
  **1656 passed / 3 existing failures / 28 ignored**, `final-runtime-full.log`.
  All 13 added tests passed, including ten native quiescence tests, two peer
  lookup/integrity tests, and the scaled pending-admission regression.
- `cargo test --offline -p fe2o3-runtime --all-features --doc`, exit 0:
  **52 passed** (8 merged and 44 individual), `final-doctests.log`.
- `cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings`,
  exit 0, `final-clippy.log`.
- `cargo check --offline -p fe2o3-runtime --no-default-features`, exit 0,
  `final-minimal-check.log`. This is a check, not a minimal-feature test suite.
- `cargo fmt -p fe2o3-runtime -- --check`, source SHA-256 continuity, and staged
  whitespace checks all exited 0. `source-signature.log` records the signature check.

The full runtime suite is **not green** because of the three failures listed
below. No test was waived, rewritten, or skipped to hide those failures.

`ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname` exited 255 before
connection: `sharkmi300x-1` DNS resolution failed. No remote files or jobs were
created. GitHub CLI and initial remote-read attempts also failed DNS; their
receipts are included. Final publication attempts are recorded separately after
this qualification packet is frozen.

## Development Runs

- `cargo test --offline -p fe2o3-runtime --all-features --lib native_quiescence -- --nocapture`:
  `first-native-quiescence.log`, exit 101, 2 passed and 2 failed. The two failures
  assumed public polling would not retire an occupied producer lane. A test-only
  scripted Pending observation now keeps the real active owner nonquiescent.
- Same command: `second-native-quiescence.log`, exit 0, 5 passed.
- `cargo test --offline -p fe2o3-runtime --all-features --lib inherited_peer_ -- --nocapture`:
  `first-inherited-peer.log`, exit 101, 8 passed and 1 failed. The new ordinary
  intermediate fixture lacked native backing. It now uses a genuine scripted
  host owner with the required recycle step during teardown.
- `cargo test --offline -p fe2o3-runtime --all-features --lib`:
  `first-runtime-full.log`, exit 101, 1652 passed / 3 existing failures / 28 ignored.
- Same command: `second-runtime-full.log`, exit 101, 1652 / 3 / 28 after the
  empty-peer-ledger service/drain fixes and five-ingress corruption coverage.
- Same command: `third-runtime-full.log`, exit 101, 1653 / 3 / 28. This preceded
  the mixed-SDMA review correction. The original output filename was
  `final-runtime-full.log`; it was renamed because that source was not final.
- `pre-mixed-source-sha256.txt` is an intermediate source snapshot, not the final
  source identity. The broad same-stream optimization was subsequently narrowed:
  only exact owners in an authenticated uninterrupted pending-compute FIFO suffix
  can be omitted; cancelled SDMA intermediates are separate custody boundaries.
- `mixed-native-quiescence.log`, exit 0, 10 passed. The printed injected unwind
  is caught and checked by its passing fault-injection test.
- `pre-lint/final-runtime-full.log`, exit 101, 1655 / 3 / 28; corresponding
  doctests passed 8 merged plus 44 individual tests. Source and test-binary hashes
  in `pre-lint/` identify that pre-lint source, not the final source.
- `first-clippy.log`, exit 101: `nonminimal_bool` in the new custody authorization
  expression. Rewritten as an explicit Compute/Sdma match, without an allow flag.
- `pre-capacity-clippy.log`, exit 0: strict all-feature/all-target Clippy after
  that rewrite. A later review found the fixed default owner bound incorrectly
  rejected the supported 1024-owner capacity profile. Owner and quiescence bounds
  now derive from the admitted capacity; a public pending-admission regression
  checks the default 256-owner boundary. Final qualification follows.
- `first-capacity-runtime-full.log`, exit 101, 1655 / 4 / 28: the added scale
  fixture initially left `native_available` false and rejected its first public
  admission. It now enables the same CPU-only admission switch as adjacent
  qualification tests and disables it again before teardown. No GPU publication
  is added. The other three failures were the existing socket-permission cases.
- `pre-dirty-fixture/final-runtime-full.log`, exit 101, 1655 / 4 / 28: clean
  HostVisible inputs took the intended eager-progress path and did not remain
  pending. The scale regression now injects synthetic dirty-shadow state, uses
  only public submit/cancel/release, and checks that queue, active compute, and
  admitted device remain absent. This does not fabricate native completion.
  The doctests, strict Clippy, minimal-feature check, formatting, source continuity,
  and whitespace checks in that directory passed for that intermediate source.

The three existing failures are the `authorized_execution::tests` cases
`cooperative_debug_telemetry_emits_only_bounded_logical_records`,
`failed_session_end_is_explicit_and_terminal`, and
`pre_native_telemetry_failure_is_returned_and_poisoned`.
They fail at unchanged `authorized_execution.rs:1317` with
`InspectSocket(PermissionDenied)`. They are not waived or reported as passing.

## Evidence Boundary

All new native-owner tests use scripted owners and the real runtime admission,
retention, cancellation, observation, and flush paths. They do not execute GPU
machine code or prove kernel outputs. Injected callback error/unwind tests prove
only consumer-local restoration and original panic propagation; their callbacks
never enter a native owner. Deliberately corrupted CPU metadata is restored only
for fixture cleanup, not as an implemented native terminal-recovery protocol.

Zero allocations are asserted only for inherited-peer lookup on a real pending
native prefix before this child has admitted a peer gate. A sticky-bit slow-path
control traverses the same prefix and allocates. This is not a latency or
HIP/HSA speedup measurement. After the first peer gate, the conservative child
latch forces authenticated traversal even after router peer custody retires.

No new Verus, native KFD campaign, ELF audit, GPU execution, distributed-host
campaign, or matched HIP/HSA benchmark is claimed by this packet. The earlier
gate-decision proof does not prove the new roster, cursor, or physical owners.
The full runtime parity objective and issue #182 remain open.
