#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-proof-launch-20261004-Z6zEVbBJ
cd "$repo"
trap 'printf "%s\n" "$?" > "$scratch/final.status"' EXIT
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
unset FE2O3_CRATE_BINDING_ID_V1 FE2O3_SIMULATION_MODE FE2O3_SIMULATION_ATTEMPT
export CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_NET_OFFLINE=true
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
export FE2O3_HIP_SYS_DISABLE=1 FE2O3_DISABLE_HIP_DISCOVERY=1 RUST_TEST_THREADS=1
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
git ls-files -z -- crates scripts Cargo.lock Cargo.toml rust-toolchain.toml .cargo \
    | sort -z | xargs -0 sha256sum > "$scratch/source-before.sha256"
git diff --cached --binary > "$scratch/source.patch"
git diff --check > "$scratch/whitespace.log"
rustfmt +nightly-2026-04-03 --check --edition 2024 \
    crates/fe2o3-protected-service-profile/src/lib.rs \
    crates/fe2o3-protected-service-spawn/src/lib.rs \
    crates/fe2o3-protected-service-spawn/src/bin/proof_controller_profile_fixture.rs > "$scratch/rustfmt.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-protected-service-profile -p fe2o3-protected-service-spawn --all-features \
    > "$scratch/final-profile-spawn.log" 2>&1
cargo +nightly-2026-04-03 test --locked --offline \
    -p fe2o3-compiler-execution-coordinator -p fe2o3-external-anchor-coordinator \
    > "$scratch/final-coordinators.log" 2>&1
cargo +nightly-2026-04-03 clippy --locked --offline \
    -p fe2o3-protected-service-profile -p fe2o3-protected-service-spawn \
    --all-targets --all-features -- -D warnings > "$scratch/final-clippy.log" 2>&1
CARGO_TARGET_DIR=target/qualification-static-deployment/cargo \
    cargo +nightly-2026-04-03 rustc --locked --offline --release --target x86_64-unknown-linux-musl \
    -p fe2o3-protected-service-spawn --features test-support --bin fe2o3-proof-controller-profile-fixture -- \
    -C target-feature=+crt-static -C relocation-model=static -C link-arg=-static -C link-arg=-no-pie \
    -C link-arg=-Wl,-e,fe2o3_secure_start_v1 > "$scratch/final-static-build.log" 2>&1
readonly executable="$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-proof-controller-profile-fixture"
readelf -hW -lW -dW -sW "$executable" > "$scratch/static.readelf.txt"
entry=$(awk '/Entry point address:/ { print $4 }' "$scratch/static.readelf.txt")
secure=$(nm -n --defined-only "$executable" | awk '$3 == "fe2o3_secure_start_v1" { print "0x" $1 }')
[[ -n $entry && -n $secure && $((entry)) -eq $((secure)) ]]
! grep -Eq 'INTERP|DYNAMIC|\(NEEDED\)|\(RPATH\)|\(RUNPATH\)' "$scratch/static.readelf.txt"
grep -Eq 'Type:[[:space:]]+EXEC' "$scratch/static.readelf.txt"
grep -Eq 'GNU_STACK.*RW[[:space:]]' "$scratch/static.readelf.txt"
[[ -z $(nm -u "$executable") ]]
binary=$(sed -n 's/.*Running unittests src\/lib.rs (\(target\/debug\/deps\/fe2o3_protected_service_spawn-[a-z0-9]*\)).*/\1/p' "$scratch/final-profile-spawn.log")
[[ -x $binary ]]
bash "$scratch/qualify-root.sh" "$repo/$binary" > "$scratch/final-root.log" 2>&1
sha256sum "$executable" "$binary" > "$scratch/binaries.sha256"
sha256sum --check "$scratch/source-before.sha256" > "$scratch/source-recheck.log"
git diff --cached --binary > "$scratch/source-after.patch"
cmp "$scratch/source.patch" "$scratch/source-after.patch"
printf 'all focused qualification stages passed\n'
