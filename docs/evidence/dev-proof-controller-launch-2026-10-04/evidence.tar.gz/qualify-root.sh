#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-proof-launch-20261004-Z6zEVbBJ
readonly binary=${1:?exact test binary}
if [[ ${2:-} != inside ]]; then
    exec timeout --kill-after=5s 180s /mnt/c/Windows/System32/wsl.exe --user root --exec \
        /usr/bin/bwrap --die-with-parent --unshare-pid --unshare-ipc --unshare-uts --unshare-net \
        --ro-bind / / --proc /proc --dev /dev --tmpfs /tmp \
        --bind "$scratch" "$scratch" --chdir "$repo" \
        --cap-add CAP_SETUID --cap-add CAP_SETGID --cap-add CAP_SETPCAP \
        /bin/bash "$scratch/qualify-root.sh" "$binary" inside
fi
[[ $EUID == 0 ]]
export LD_LIBRARY_PATH="$repo/target/debug/deps:/home/harsh/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib"
export FE2O3_PROOF_PROFILE_FIXTURE="$repo/target/qualification-static-deployment/cargo/x86_64-unknown-linux-musl/release/fe2o3-proof-controller-profile-fixture"
for case in native enosys handler drop_retry eperm einval eagain legacy_eperm restore_once; do
    FE2O3_ROOT_CLONE_CASE=$case timeout --kill-after=2s 15s "$binary" \
        --exact syscall::tests::root_atomic_pidfd_launch --ignored --nocapture --test-threads=1
done
timeout --kill-after=2s 20s "$binary" --exact syscall::tests::root_restore_failure_is_contained \
    --ignored --nocapture --test-threads=1
for case in seccomp securebits; do
    FE2O3_PROOF_PARENT_CASE=$case timeout --kill-after=2s 15s "$binary" \
        --exact syscall::proof_controller_tests::root_incompatible_proof_parent_is_rejected \
        --ignored --nocapture --test-threads=1
done
timeout --kill-after=2s 60s "$binary" --exact syscall::proof_controller_tests::root_parent_death_matrix \
    --ignored --nocapture --test-threads=1
timeout --kill-after=2s 60s "$binary" --exact syscall::proof_controller_tests::root_static_proof_profile_matrix \
    --ignored --nocapture --test-threads=1
