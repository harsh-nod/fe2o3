#!/bin/bash
set -euo pipefail
readonly repo=/home/harsh/.codex-tmp/fe2o3-r61-execution
readonly scratch=/home/harsh/.codex-tmp/fe2o3-proof-launch-20261004-Z6zEVbBJ
readonly destination="$repo/docs/evidence/dev-proof-controller-launch-2026-10-04"
cd "$repo"
[[ $(<"$scratch/final.status") == 0 ]]
git diff --quiet
git diff --cached --quiet
git rev-parse HEAD > "$scratch/source-commit.txt"
git show --format= --binary HEAD > "$scratch/committed-source.patch"
cmp "$scratch/source.patch" "$scratch/committed-source.patch"
git -c gpg.format=ssh -c gpg.ssh.allowedSignersFile="$scratch/allowed-signers" \
    verify-commit HEAD > "$scratch/source-signature.log" 2>&1
sha256sum --check "$scratch/source-before.sha256" > "$scratch/final-source-check.log"
sha256sum --check "$scratch/binaries.sha256" > "$scratch/final-binary-check.log"
sha256sum "$scratch/source.patch" > "$scratch/source-patch.sha256"
mkdir -p "$destination"
cd "$scratch"
find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum --check MANIFEST.sha256
tar -czf "$destination/evidence.tar.gz" .
tar -dzf "$destination/evidence.tar.gz"
sha256sum "$destination/evidence.tar.gz"
