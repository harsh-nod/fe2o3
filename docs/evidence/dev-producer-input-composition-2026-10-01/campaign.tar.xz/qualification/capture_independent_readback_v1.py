#!/usr/bin/env python3
"""Capture one authorized read-only audit outside the immutable proof packet."""
import hashlib
import json
from pathlib import Path
import sys
import types

BASE = Path(__file__).resolve().parent
OWNER_SHA = "e3e27dc88cc80891fccfe6d2203759b8c638f97d2f07badd289098ab4163ee6d"
AUDIT_SHA = "b9d4b1920bd6167108d0a5d25ff050f6500453bcee03ef90fe34cf77da90ae9d"
TEST_SHA = "f35ed76e60066b90fa3acdc780de26ac6c5cb8d2f2016e5ffe247cf9bc6de5c9"
OUT = BASE / "independent-readback-attempt-1"


def main():
    if len(sys.argv) != 1 or not sys.flags.isolated or not sys.dont_write_bytecode or sys.flags.optimize:
        raise ValueError("one explicit isolated capture, no retry options")
    owner_path = BASE / "signed_composition_campaign_v1.py"
    raw = owner_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != OWNER_SHA:
        raise ValueError("reviewed owned-process loader source")
    owner = types.ModuleType("readback_process_capture")
    owner.__file__ = str(owner_path)
    exec(compile(raw, str(owner_path), "exec"), owner.__dict__)
    c = owner.components()
    auditor = BASE / "audit_signed_composition_v1.py"
    c.h.need(c.h.sha(auditor) == AUDIT_SHA and c.h.sha(BASE / "test_audit_signed_composition_v1.py") == TEST_SHA,
             "reviewed exact independent auditor and controls")
    results = json.loads(c.h.raw(owner.OUTPUT / "results.json"))
    closure = json.loads(c.h.raw(owner.OUTPUT / "fresh-process-closure.json"))
    c.h.need(results["signed_campaign_qualified"] is True and len(results["stages"]) == 102
             and results["errors"] == [] and closure["all_recorded_groups_absent"] is True
             and len(closure["recorded_groups"]) == 102, "original campaign terminal acceptance and closure prerequisites")
    c.h.need(OUT.resolve() == OUT and not OUT.exists(), "new never-reused audit capture outside proof packet")
    OUT.mkdir()
    (OUT / "tmp").mkdir()
    folder = OUT / "001-audit"
    folder.mkdir()
    argv = ["/usr/bin/python3", "-I", "-B", str(auditor)]
    env = c.d.environment(OUT)
    c.h.save(folder / "command.json", {"argv": argv, "timeout": 180, "environment": env,
             "auditor_sha256": AUDIT_SHA, "controls_sha256": TEST_SHA, "capture_sha256": c.h.sha(Path(__file__).resolve())})
    managed = c.loader.load()
    c.loader.archive(OUT)
    status, stdout, stderr = managed.run_owned(argv, 180, folder / "owned", env)
    c.base.owned_record(json.loads(c.h.raw(folder / "owned/record.json")), status, argv)
    c.h.need(c.h.raw(folder / "owned/stdout.log").decode() == stdout
             and c.h.raw(folder / "owned/stderr.log").decode() == stderr, "exact captured auditor streams")
    c.h.save(folder / "result.json", {"returncode": status, "stderr_empty": stderr == "", "group_absent": True})
    print(stdout, end="", flush=True)
    print(stderr, end="", file=sys.stderr, flush=True)
    raise SystemExit(status if status != 0 else 0 if stderr == "" else 1)


if __name__ == "__main__":
    main()
