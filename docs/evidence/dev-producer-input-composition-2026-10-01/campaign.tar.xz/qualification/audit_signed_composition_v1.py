#!/usr/bin/env python3
"""Read-only independent readback of the exact signed102-stage campaign."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import types

BASE = Path(__file__).resolve().parent
REPO = Path("/home/harsh/.codex-tmp/fe2o3-a2-producer-composition-20260930-qualified")
PACKET = BASE / "signed-composition-attempt-1"
SIGNED = "6b9e5d87c4386692f7c213a95dd786ccdf42cb45"
V = Path("crates/fe2o3-runtime-model/verus")
COUNTS = {"leaf": 42, "fold": 13, "composition": 64}
ROSTERS = {"leaf": "d93b43692de73a490b43149b4f6016542980aa68e069775a364bd67f9b757703",
           "fold": "202fb6a329bcaac514974e915a48e348aeabadb4feee45b5b664cc0bbdd9aba2",
           "composition": "3568fd947902e7db6f3b556b1a39e851ef49501932896fbfe6ae1482fefe4fb2"}
PINS = {
    "signed_composition_campaign_v1.py": "e3e27dc88cc80891fccfe6d2203759b8c638f97d2f07badd289098ab4163ee6d",
    "test_signed_composition_campaign_v1.py": "a6df9ec519689150350f48e93b000787c27064ac9607af2a80c4032addc73ade",
    "prepared-signed-composition-v1.json": "62f5718616a574224aa7119839188959fc8e0e54ee29c2c4cc2f6a8384cc515e",
    "candidate-source-before-signing-v1.json": "74de648c10955d7b71682c96658765fc2b3eaba8fbc7d5939ce5dd0acbaaf4d6",
    "bind_candidate_v1.py": "0f865d4ec4930280214ba6a86f28c588248abd2c6cefea4437ecb13388de578a",
}


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(path):
    need(path.is_file() and not path.is_symlink() and path.resolve() == path, "ordinary canonical file")
    return path.read_bytes()


def sha(path):
    return hashlib.sha256(raw(path)).hexdigest()


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def data(path):
    return json.loads(raw(path), object_pairs_hook=pairs, parse_constant=lambda _: need(False, "nonfinite JSON"))


def same(left, right):
    return json.dumps(left, sort_keys=True, separators=(",", ":")) == json.dumps(right, sort_keys=True, separators=(",", ":"))


def cpu_custody(artifact):
    need(artifact["sha256"] == "693f870199f0dbf0be4963f4501285de460d9681d65c024cc9e4ea503499e153"
         and artifact["bytes"] == 43514320 and all(sha(Path(artifact[key])) == artifact["sha256"]
         and len(raw(Path(artifact[key]))) == artifact["bytes"] for key in ("source", "retained")),
         "original and retained CPU executable bytes remain identical")


def load(path, digest, name):
    need(sha(path) == digest, "authenticated source helper")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(raw(path), str(path), "exec"), module.__dict__)
    return module


def tree(root):
    need(root.is_dir() and root.resolve() == root and not root.is_symlink(), "ordinary canonical directory")
    entries = list(root.rglob("*"))
    need(all(path.resolve() == path and not path.is_symlink() for path in entries), "no redirected tree entries")
    return {str(path.relative_to(root)): sha(path) for path in entries if path.is_file()}


def signed_source(h, review, prepared):
    need(h.git("rev-parse", "HEAD").decode().strip() == SIGNED
         and h.git("rev-parse", "HEAD^").decode().strip() == review["base_commit"]
         and not h.git("status", "--porcelain=v1", "--untracked-files=all"), "clean exact signed candidate and parent")
    need(hashlib.sha256(h.git("cat-file", "commit", SIGNED)).hexdigest() == prepared["commit_sha256"], "exact signed commit object")
    names = {os.fsdecode(path) for path in h.git("ls-files", "--cached", "--others", "--exclude-standard", "-z",
             "--", *review["selectors"]).split(b"\0") if path}
    source = {path: {"sha256": sha(REPO / path), "bytes": len(raw(REPO / path))} for path in sorted(names)}
    need(source == review["source"] == prepared["source"] and len(source) == 6480, "entire retained pre-sign source binding")
    need(h.git("rev-parse", "--show-object-format") == b"sha1\n", "exact Git object format")
    bound = {}
    for entry in h.git("ls-tree", "-r", "-z", "--full-tree", SIGNED, "--", *review["selectors"]).split(b"\0"):
        if not entry:
            continue
        header, name = entry.split(b"\t", 1)
        mode, kind, oid = header.split()
        path = os.fsdecode(name)
        need(mode in (b"100644", b"100755") and kind == b"blob" and path in source and path not in bound,
             "exact ordinary signed blob membership")
        content = raw(REPO / path)
        need(hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest() == oid.decode(),
             "raw Git blob byte identity, not index/clean-filter equivalence")
        bound[path] = {"git_blob": oid.decode(), "sha256": source[path]["sha256"]}
    need(set(bound) == set(source) and bound == prepared["signed_blobs"], "complete6480 signed blob binding")
    return source


def include_closure(root, proof, files):
    reached, pending = set(), [proof]
    while pending:
        path = pending.pop()
        if path in reached:
            continue
        need(path in files, "closed proof dependency membership")
        reached.add(path)
        text = raw(root / path).decode()
        children = re.findall(r'\binclude!\(\s*"([^"\n]+)"\s*\)\s*;', text)
        children += [name + ".rs" for name in re.findall(r"^\s*mod\s+(\w+)\s*;", text, re.M)]
        pending += [(root / path.parent / child).resolve().relative_to(root) for child in children]
    need(reached == set(files), "exact recursively complete include/module closure")


def context():
    need(all(sha(BASE / name) == digest for name, digest in PINS.items()), "reviewed controller/control/preparation/pre-sign pins")
    prepared = data(BASE / "prepared-signed-composition-v1.json")
    review = data(BASE / "candidate-source-before-signing-v1.json")
    binder = load(BASE / "bind_candidate_v1.py", PINS["bind_candidate_v1.py"], "readback_binder")
    continuation = load(BASE / "calibration_continuation_v1.py", binder.CONTINUATION_SHA, "readback_continuation")
    old = continuation.load_old()
    base, parts, old_checks, history, history_metadata = old.components()
    prior, f, original_h, old_h, s, loader, d, classifier, identity, original, original_blobs, calibrated, _pins, preserved = parts
    h = load(Path(old_h.__file__), sha(Path(old_h.__file__)), "readback_source_helpers")
    h.REPO = REPO
    source = signed_source(h, review, prepared)
    need(original == review["signed_baseline_source"] and original_blobs == review["signed_baseline_blobs"]
         and calibrated == review["calibrated_source"], "authenticated unchanged predecessor and calibration sources")
    changed = {path for path in source if source[path] != calibrated.get(path)}
    need(changed == binder.METADATA and not any(path.endswith(".rs") for path in changed), "only reviewed metadata delta after calibration")
    signed_delta = {os.fsdecode(path) for path in h.git("diff-tree", "--no-commit-id", "--name-only", "-r", "-z", SIGNED).split(b"\0") if path}
    need(signed_delta == set(old.PINS) | binder.NEW_FILES, "exact16-path signed delta")
    checks, snapshots, cases = {}, {}, {}
    for family, name in (("leaf", "validate"), ("fold", "fold"), ("composition", "composition")):
        path = V / ("check-producer-input-" + name + ".py")
        check = load(REPO / path, source[str(path)]["sha256"], "readback_check_" + family)
        snapshots[family] = check.snapshot()
        check.audit(snapshots[family])
        need(check.FILES == old_checks[family].FILES and check.EXPECTED_VERIFIED == COUNTS[family]
             and check.MUTATION_ROSTER_SHA == ROSTERS[family], "exact inherited proof closure/count/roster")
        include_closure(REPO, check.PROOF, set(check.FILES))
        need({str(path): source[str(path)] for path in check.FILES} == review["proof_closures"][family]
             == prepared["proof_closures"][family], "unchanged complete3/3/4 proof source buffers")
        checks[family] = check
        rows = check.mutations(snapshots[family]) if family == "composition" else check.mutations(snapshots[family][check.BODY])
        for name, row in rows.items():
            if family != "composition":
                text, selector = row
                row = {"text": text, "selector": selector, "path": check.BODY}
            cases[family + "/" + name] = dict(row, family=family, name=name)
    need({family: sum(row["family"] == family for row in cases.values()) for family in COUNTS}
         == {"leaf": 38, "fold": 22, "composition": 21}, "all81 unchanged actual-body mutations")
    facts = {key: {name: str(value) if isinstance(value, Path) else value for name, value in row.items()
                   if name not in ("text", "before", "after")}
             | {"sha256": hashlib.sha256(row["text"].encode()).hexdigest()} for key, row in cases.items()}
    need(facts == prepared["cases"] and prepared["expected_full_counts"] == COUNTS
         and prepared["mutation_roster_hashes"] == ROSTERS, "exact reviewed mutation facts and full counts")
    artifact = review["retained_cpu_artifact"]
    need(artifact == prepared["retained_cpu_artifact"] == data(prior.STATIC / "inputs.json")["retained_cpu_artifact"],
         "original/retained CPU custody metadata")
    cpu_custody(artifact)
    need(history == review["preserved_discovery_trees"] and history_metadata == review["preserved_discovery_metadata"], "immutable discovery history")
    trees = dict(history) | {str(continuation.PREVIOUS): review["preserved_interrupted_tree"],
             str(BASE / "calibration-continuation-attempt-1"): review["preserved_continuation_tree"], str(base.PRIOR_PACKET): preserved}
    need(trees == prepared["historical_trees"] and all(tree(Path(path)) == rows for path, rows in trees.items()), "all historical packets unchanged")
    need(d.tool_inventory(s) == prepared["tools"] == review["tools"]
         and all(sha(Path(path)) == digest for path, digest in prepared["raw_pins"].items()), "tool/helper/source/fixture provenance continuity")
    return types.SimpleNamespace(prepared=prepared, review=review, checks=checks, cases=cases, snapshots=snapshots,
        source=source, h=h, base=base, s=s, d=d, classifier=classifier, identity=identity,
        diagnostics=checks["composition"].diagnostic_classifier())


def commands(c):
    signature = ["/usr/bin/git", "--no-replace-objects", "-c", "gc.auto=0", "-c", "gpg.format=ssh",
        "-c", "gpg.ssh.program=/usr/bin/ssh-keygen", "-c", "gpg.ssh.allowedSignersFile="
        "/home/harsh/.codex-tmp/fe2o3-preflight-repeat-20260929-nnNtgZnS/preflight-final/allowed-signers", "verify-commit", SIGNED]
    rows = [{"name": "001-signature", "kind": "signature", "argv": signature, "timeout": 60}]
    for label, suffix, count in (("leaf-controls", "validate", 5), ("fold-controls", "fold", 4),
        ("source-controls", "composition", 12), ("mutation-controls", "composition-qualification", 5),
        ("diagnostic-controls", "diagnostics", 14)):
        rows.append({"name": f"{len(rows) + 1:03d}-" + label, "kind": "control", "count": count,
            "fold_control": suffix == "fold", "timeout": 60,
            "argv": ["/usr/bin/python3.12", "-I", "-B", str(REPO / V / ("test-producer-input-" + suffix + ".py"))]})
    release = ["/bin/sh", str(REPO / c.d.CLOSURE), str(c.d.VERUS.parent), str(REPO / c.d.MANIFEST)]
    for family in COUNTS:
        rows.append({"name": f"{len(rows) + 1:03d}-{family}-release-before", "kind": "release", "argv": release, "timeout": 130})
        labels = [("full-before", None), ("relocated", None)] + [(row["name"], key) for key, row in c.cases.items()
            if row["family"] == family] + [("full-after", None)]
        for label, key in labels:
            name = f"{len(rows) + 1:03d}-{family}-{label}"
            root = REPO if label in ("full-before", "full-after") else PACKET / (name + "-source")
            selected = c.cases[key]["selector"] if key else None
            need(not key or (selected is None) is (family == "composition"), "unfiltered21 and exactly selected38/22")
            argv = ["/usr/bin/timeout", "--foreground", "--signal=TERM", "--kill-after=5", "120", str(c.d.VERUS),
                "--crate-type", "lib", "--triggers-mode", "silent", "--no-cheating", "--output-json", "--error-format=json",
                "--no-report-long-running", "--num-threads", "4", "--multiple-errors", "1"]
            if selected is not None:
                argv += ["--verify-function", selected, "--verify-root"]
            argv.append(str(root / c.checks[family].PROOF))
            row = {"name": name, "kind": "negative" if key else "positive", "family": family, "root": str(root),
                   "timeout": 130, "expected_verified": None if key else COUNTS[family], "argv": argv}
            if key:
                row["case"] = key
            rows.append(row)
        rows.append({"name": f"{len(rows) + 1:03d}-{family}-release-after", "kind": "release", "argv": release, "timeout": 130})
    need(len(rows) == len({row["name"] for row in rows}) == 102 and rows == c.prepared["commands"], "independently reconstructed exact102 commands")
    return rows


def projection(c, spec):
    check = c.checks[spec["family"]]
    expected = {path: c.snapshots[spec["family"]][path] for path in check.FILES}
    if spec["kind"] == "negative":
        case = c.cases[spec["case"]]
        need(expected[case["path"]] != case["text"], "actual non-vacuous declared mutation")
        expected[case["path"]] = case["text"]
    root = Path(spec["root"])
    actual = {path: raw(root / path).decode() for path in check.FILES}
    need(actual == expected, "every projected byte is exactly the declared actual-body variant")
    hashes = {str(path): hashlib.sha256(text.encode()).hexdigest() for path, text in actual.items()}
    if root != REPO:
        need(root.parent == PACKET and tree(root) == hashes, "minimal exact3/3/4-file relocation or mutation projection")
    include_closure(root, check.PROOF, set(check.FILES))
    return actual, hashes


def receipt(record, spec, status):
    need(set(record) == {"command", "started_ns", "process_group", "group_absent", "finished_ns", "status"}
         and type(status) is int and type(record["status"]) is int and record["status"] == status
         and record["command"] == spec["argv"] and record["group_absent"] is True,
         "exact terminal owned receipt, no exception or open group")
    need(all(type(record[key]) is int for key in ("started_ns", "finished_ns", "process_group"))
         and 0 < record["started_ns"] <= record["finished_ns"] and record["process_group"] > 1,
         "typed positive recorder timestamps and process group")


def classify(c, spec, sources, status, stdout, stderr):
    need(type(status) is int and status == (1 if spec["kind"] == "negative" else 0), "exact success/logical exit, not timeout/frontend/Boolean")
    if spec["kind"] == "signature":
        need(stdout == "" and stderr == c.s.SIGNATURE, "exact pinned signer output")
    elif spec["kind"] == "release":
        need(stdout == c.d.CLOSURE_OK and stderr == "", "exact190-file release closure check")
    elif spec["kind"] == "control":
        if spec["fold_control"]:
            need(stderr == "" and stdout == "PASS: producer-input fold source/controller calibration (4 groups; 22 logical mutants constructed, not executed)\n", "exact fold source controls")
        else:
            pattern = r"\.{{{0}}}\n-{{70}}\nRan {0} tests in [0-9]+\.[0-9]+s\n\nOK\n".format(spec["count"])
            need(stdout == "" and re.fullmatch(pattern, stderr), "exact source control count/footer, no warnings")
    elif spec["kind"] == "positive":
        paths = {str(Path(spec["root"]) / path) for path in sources}
        result = c.d.classify(c.classifier, c.identity.VERIFIER, paths, status, stdout, stderr)
        need(result["candidate_accepted"] is True and result["observed_verified"] == COUNTS[spec["family"]]
             and stderr == "", "complete unfiltered full/relocated positive")
        return result
    else:
        need(spec["kind"] == "negative", "known stage kind")
        result = c.diagnostics.negative(c.identity.VERIFIER, sources, Path(spec["root"]), c.cases[spec["case"]], status, stdout, stderr)
        need(result["logical_diagnostic_accepted"] is True and result["signed_campaign_qualified"] is False
             and result["source_and_process_binding_required"] is True, "recursive source-bound logical primary and selected/full diagnostic join")
        return result
    return None


def census(inputs, closing, closure, roster, groups, expected):
    namespace = inputs["namespace"]
    need(namespace == closing["namespace"] == closure["namespace"] and set(namespace)
         == {"child_pid_namespace", "pid_namespace", "procfs_self_pid", "recorder_pid"}
         and type(namespace["recorder_pid"]) is int and namespace["recorder_pid"] > 1
         and namespace["procfs_self_pid"] == str(namespace["recorder_pid"])
         and namespace["pid_namespace"] == namespace["child_pid_namespace"]
         and re.fullmatch(r"pid:\[\d+\]", namespace["pid_namespace"]), "original recorder's unchanged namespace identity")
    need(roster == expected and len(groups) == len(set(groups)) == 102 and namespace["recorder_pid"] not in groups,
         "exact102 fresh receipt/group bijection")
    need(set(closure) == {"all_recorded_groups_absent", "host_wide_absence_claimed", "members", "namespace",
                          "observation_scope", "recorded_groups", "uncertain"}
         and closure["all_recorded_groups_absent"] is True and closure["recorded_groups"] == groups
         and closure["host_wide_absence_claimed"] is False and closure["members"] == closure["uncertain"] == []
         and closure["observation_scope"] == "fresh child groups created by this live recorder in its unchanged PID namespace; not historical-group or host-wide absence evidence",
         "original fresh closure receipt only; no live probing of historical PIDs")


def archive_binding(index, pins):
    need(isinstance(index, dict) and set(index) == set(pins), "archive contains exactly the complete prepared pin roster")
    expected = {}
    for source, digest in pins.items():
        path = Path(source)
        need(path.is_absolute() and path.resolve() == path, "canonical absolute pinned archive source")
        relative = Path("raw-helpers") / path.relative_to("/")
        expected[source] = {"archive": str(relative.with_name(relative.name + ".source")), "sha256": digest}
    need(same(index, expected), "exact archive path mapping, per-entry schema and prepared digest")
    need(len({row["archive"] for row in index.values()}) == len(index), "distinct archive paths for distinct pinned sources")


def audit():
    c = context()
    plan = commands(c)
    before = tree(PACKET)
    inputs, closing, results = (data(PACKET / name) for name in ("inputs.json", "closing-inputs.json", "results.json"))
    prepared = c.prepared
    pins = dict(prepared["raw_pins"]) | {str(BASE / "prepared-signed-composition-v1.json"): PINS["prepared-signed-composition-v1.json"]}
    expected = dict(prepared, raw_pins=pins, namespace=inputs["namespace"], environment=c.d.environment(PACKET))
    need(same(inputs, expected), "exact reviewed inputs and minimal recorded environment")
    need(same(closing, {"source": c.source, "signed_commit": SIGNED, "tools": prepared["tools"], "namespace": inputs["namespace"]}), "exact closing source/tool/namespace binding")
    expected_summary = {"signed_campaign_qualified": True, "stages": results["stages"], "errors": [], "scope": prepared["scope"],
        "logical_negatives_qualified": True, "fresh_native_cpu_execution": False, "prior_captures_promoted": False,
        "original33_campaign_complete": False, "native_context_or_hardware_qualified": False}
    need(same(results, expected_summary) and len(results["stages"]) == 102, "complete reported packet with explicit conditional scope")
    generated, groups, previous_finish, summaries = {}, [], 0, {family: {"positives": [], "negatives": 0} for family in COUNTS}
    for spec, row in zip(plan, results["stages"]):
        folder = PACKET / spec["name"]
        need(set(tree(folder)) == {"command.json", "result.json", "owned/record.json", "owned/stdout.log", "owned/stderr.log"}, "exact five-file owned stage")
        need(same(data(folder / "command.json"), dict(spec, cwd=str(REPO), environment=inputs["environment"]))
             and same(data(folder / "result.json"), row), "exact command/environment and independent individual receipt")
        record = data(folder / "owned/record.json")
        status = row["returncode"]
        receipt(record, spec, status)
        need(record["started_ns"] >= previous_finish, "sequential original stage order")
        previous_finish = record["finished_ns"]
        groups.append(record["process_group"])
        sources = None
        if "root" in spec:
            sources, hashes = projection(c, spec)
            if spec["root"] != str(REPO):
                generated[spec["root"]] = hashes
        classification = classify(c, spec, sources, status, raw(folder / "owned/stdout.log").decode(), raw(folder / "owned/stderr.log").decode())
        expected_row = {"name": spec["name"], "kind": spec["kind"], "accepted": True, "owned_launch_attempted": True,
                        "returncode": status, "group_absent": True} | {key: spec[key] for key in ("family", "case") if key in spec}
        if classification is not None:
            expected_row["classification"] = classification
        need(same(row, expected_row), "raw classification and all exact result fields agree")
        if spec["kind"] == "positive":
            summaries[spec["family"]]["positives"].append(classification["observed_verified"])
        elif spec["kind"] == "negative":
            summaries[spec["family"]]["negatives"] += 1
    need(data(PACKET / "generated-inputs.json") == generated and len(generated) == 84, "all84 exact minimal source projections")
    directories = {path.name for path in PACKET.iterdir() if path.is_dir() and re.match(r"\d{3}-", path.name)}
    need(directories == {spec["name"] for spec in plan} | {Path(path).name for path in generated}, "no unplanned owned stage or projection")
    expected_roster = [spec["name"] + "/owned/record.json" for spec in plan]
    census(inputs, closing, data(PACKET / "fresh-process-closure.json"), data(PACKET / "fresh-census-inputs.json"), groups, expected_roster)
    archive = data(PACKET / "raw-archive-index.json")
    archive_binding(archive, pins)
    c.h.validate_raw_archive(PACKET, archive)
    need(tree(PACKET / "raw-helpers") == {str(Path(row["archive"]).relative_to("raw-helpers")): row["sha256"]
         for row in archive.values()}, "no extra or missing archived source buffers")
    need(all(sha(Path(path)) == digest for path, digest in pins.items()), "all live referenced raw sources and prior evidence remain unchanged")
    cpu_custody(c.review["retained_cpu_artifact"])
    need(signed_source(c.h, c.review, prepared) == c.source and c.d.tool_inventory(c.s) == prepared["tools"]
         and all(tree(Path(path)) == entries for path, entries in prepared["historical_trees"].items())
         and tree(PACKET) == before, "read-only audit and closing signed source/tool continuity")
    return {"independent_readback_accepted": True, "signed_commit": SIGNED, "stages": 102, "families": summaries,
            "packet_tree_sha256": hashlib.sha256(json.dumps(before, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "packet_files": len(before), "historical_pid_probes": False, "new_solver_or_native_cpu_execution": False,
            "prior_captures_promoted": False, "native_context_or_hardware_qualified": False, "scope": prepared["scope"]}


if __name__ == "__main__":
    need(len(sys.argv) == 1 and sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize,
         "reviewed read-only audit via python3 -I -B; no execution/retry options")
    print(json.dumps(audit(), indent=2, sort_keys=True))
