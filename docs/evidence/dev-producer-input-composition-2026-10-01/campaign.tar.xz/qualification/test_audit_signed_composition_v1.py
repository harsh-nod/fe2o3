#!/usr/bin/env python3
"""Read-only auditor controls; never execute the terminal packet audit here."""
import copy
import hashlib
import json
from pathlib import Path
import types
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
path = BASE / "audit_signed_composition_v1.py"
audit = types.ModuleType("independent_composition_audit_controls")
audit.__file__ = str(path)
exec(compile(path.read_bytes(), str(path), "exec"), audit.__dict__)


def materialize(value, root):
    if isinstance(value, dict):
        return {key: materialize(item, root) for key, item in value.items()}
    if isinstance(value, list):
        return [materialize(item, root) for item in value]
    return value.replace("$SOURCE", str(root)) if type(value) is str else value


class AuditControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = audit.context()
        cls.commands = audit.commands(cls.c)
        cls.fixtures = audit.data(audit.REPO / audit.V / "producer-input-diagnostic-fixtures-v1.json")

    def test_independent102_plan_and_all81_mutants(self):
        self.assertEqual(self.commands, self.c.prepared["commands"])
        self.assertEqual(len(self.commands), 102)
        self.assertEqual(len(self.c.cases), 81)
        for family, count in (("leaf", 38), ("fold", 22), ("composition", 21)):
            self.assertEqual(sum(row.get("family") == family and row["kind"] == "negative" for row in self.commands), count)
        self.assertEqual(sum(row["kind"] == "positive" for row in self.commands), 9)
        self.assertEqual(sum(row["kind"] == "release" for row in self.commands), 6)

    def test_prepared_plan_cannot_hide_selection_timeout_or_omitted_case(self):
        for mutation in ("timeout", "selection", "omit"):
            prepared = copy.deepcopy(self.c.prepared)
            if mutation == "timeout":
                prepared["commands"][8]["timeout"] = 1000
            elif mutation == "selection":
                prepared["commands"][79]["argv"][-1:-1] = ["--verify-function", "*Composition::validate", "--verify-root"]
            else:
                prepared["commands"].pop(79)
            modified = types.SimpleNamespace(**(vars(self.c) | {"prepared": prepared}))
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                audit.commands(modified)

    def test_candidate_commit_and_all_signed_blobs_bound(self):
        self.assertEqual(audit.signed_source(self.c.h, self.c.review, self.c.prepared), self.c.source)
        modified = copy.deepcopy(self.c.prepared)
        modified["signed_blobs"]["Cargo.toml"]["git_blob"] = "0" * 40
        with self.assertRaises(ValueError):
            audit.signed_source(self.c.h, self.c.review, modified)

    def test_all_complete_include_closures_and_hidden_dependency_rejected(self):
        for check in self.c.checks.values():
            audit.include_closure(audit.REPO, check.PROOF, set(check.FILES))
        check = self.c.checks["composition"]
        original = audit.raw
        with patch.object(audit, "raw", side_effect=lambda path: original(path) + b"\nmod hidden_unbound;\n" if path == audit.REPO / check.PROOF else original(path)):
            with self.assertRaises(ValueError):
                audit.include_closure(audit.REPO, check.PROOF, set(check.FILES))
        with self.assertRaises(ValueError):
            audit.include_closure(audit.REPO, check.PROOF, set(check.FILES) | {Path("unreached.rs")})

    def test_all81_projection_buffers_exact_without_reading_live_campaign(self):
        for spec in (row for row in self.commands if row["kind"] == "negative"):
            case = self.c.cases[spec["case"]]
            sources = {path: self.c.snapshots[case["family"]][path] for path in self.c.checks[case["family"]].FILES}
            sources[case["path"]] = case["text"]
            hashes = {str(path): hashlib.sha256(text.encode()).hexdigest() for path, text in sources.items()}
            root = Path(spec["root"])
            with patch.object(audit, "raw", side_effect=lambda path: sources[path.relative_to(root)].encode()), \
                    patch.object(audit, "tree", return_value=hashes):
                actual, bound = audit.projection(self.c, spec)
                self.assertEqual(actual, sources)
                self.assertEqual(bound, hashes)
            with patch.object(audit, "raw", side_effect=lambda path: sources[path.relative_to(root)].encode() + b"\n"), \
                    patch.object(audit, "tree", return_value=hashes):
                with self.assertRaises(ValueError):
                    audit.projection(self.c, spec)

    def test_auditor_does_not_call_campaign_qualifier_or_pid_liveness(self):
        source = path.read_text()
        for forbidden in ("run_owned(", "independent_absence(", "os.kill(", "owner.classify(", "owner.qualified(", "binder.capture("):
            self.assertNotIn(forbidden, source)

    def test_raw_receipt_exact_types_command_and_closed_group(self):
        spec = self.commands[0]
        record = {"command": spec["argv"], "started_ns": 10, "finished_ns": 20, "process_group": 42, "group_absent": True, "status": 0}
        audit.receipt(record, spec, 0)
        for key, value in (("status", False), ("process_group", True), ("group_absent", 1),
                           ("command", []), ("finished_ns", 9), ("exception", "timeout")):
            with self.subTest(key=key), self.assertRaises(ValueError):
                audit.receipt(record | {key: value}, spec, 0)
        with self.assertRaises(ValueError):
            audit.receipt(record, spec, False)

    def test_exact102_original_census_without_pid_probes(self):
        namespace = {"child_pid_namespace": "pid:[123]", "pid_namespace": "pid:[123]", "procfs_self_pid": "42", "recorder_pid": 42}
        groups = list(range(100, 202))
        roster = [row["name"] + "/owned/record.json" for row in self.commands]
        closure = {"all_recorded_groups_absent": True, "host_wide_absence_claimed": False, "members": [],
            "namespace": namespace, "observation_scope": "fresh child groups created by this live recorder in its unchanged PID namespace; not historical-group or host-wide absence evidence",
            "recorded_groups": groups, "uncertain": []}
        audit.census({"namespace": namespace}, {"namespace": namespace}, closure, roster, groups, roster)
        for key, value in (("all_recorded_groups_absent", 1), ("host_wide_absence_claimed", True),
                           ("members", [100]), ("uncertain", [100]), ("recorded_groups", groups[:-1]),
                           ("namespace", namespace | {"recorder_pid": True})):
            with self.subTest(key=key), self.assertRaises(ValueError):
                audit.census({"namespace": namespace}, {"namespace": namespace}, closure | {key: value}, roster, groups, roster)
        with self.assertRaises(ValueError):
            audit.census({"namespace": namespace}, {"namespace": namespace}, closure, roster[:-1], groups, roster)
        with self.assertRaises(ValueError):
            audit.census({"namespace": namespace}, {"namespace": namespace}, closure, roster, groups[:-1] + [100], roster)

    def fixture(self, key):
        spec = next(row for row in self.commands if row.get("case") == key)
        item = materialize(copy.deepcopy(self.fixtures["fixtures"][key]), Path(spec["root"]))
        case = self.c.cases[key]
        sources = {path: self.c.snapshots[case["family"]][path] for path in self.c.checks[case["family"]].FILES}
        sources[case["path"]] = case["text"]
        return spec, sources, item

    def test_all25_fixture_replays_still_not_qualified_kills(self):
        for key in self.fixtures["fixtures"]:
            spec, sources, item = self.fixture(key)
            result = audit.classify(self.c, spec, sources, 1, json.dumps(item["result"]),
                "\n".join(json.dumps(row) for row in item["diagnostics"]))
            self.assertTrue(result["logical_diagnostic_accepted"])
            self.assertFalse(result["signed_campaign_qualified"])
            self.assertTrue(result["source_and_process_binding_required"])
        self.assertFalse(self.fixtures["qualified_kills"])

    def test_wrong_exit_foreign_nested_span_and_selector_rejected(self):
        spec, sources, item = self.fixture("leaf/bound-root-ignored")
        stdout = json.dumps(item["result"])
        stderr = "\n".join(json.dumps(row) for row in item["diagnostics"])
        for status in (0, True, 101, 124, -9):
            with self.assertRaises(ValueError):
                audit.classify(self.c, spec, sources, status, stdout, stderr)
        row = next(row for row in item["diagnostics"] if row["level"] == "error" and row["spans"])
        row["spans"][0]["expansion"]["span"]["file_name"] = "/tmp/unbound.rs"
        with self.assertRaises(ValueError):
            audit.classify(self.c, spec, sources, 1, stdout, "\n".join(json.dumps(row) for row in item["diagnostics"]))
        spec, sources, item = self.fixture("composition/per-input-answer-index-zero")
        item["result"]["verification-results"]["is-verifying-entire-crate"] = False
        with self.assertRaises(ValueError):
            audit.classify(self.c, spec, sources, 1, json.dumps(item["result"]), "\n".join(json.dumps(row) for row in item["diagnostics"]))

    def test_exact_control_release_and_signature_outputs(self):
        for spec, stdout, stderr in ((self.commands[0], "", self.c.s.SIGNATURE), (self.commands[-1], self.c.d.CLOSURE_OK, "")):
            self.assertIsNone(audit.classify(self.c, spec, None, 0, stdout, stderr))
            with self.assertRaises(ValueError):
                audit.classify(self.c, spec, None, 0, stdout, stderr + "warning")
        for spec in (row for row in self.commands if row["kind"] == "control"):
            stdout = "PASS: producer-input fold source/controller calibration (4 groups; 22 logical mutants constructed, not executed)\n" if spec["fold_control"] else ""
            stderr = "" if spec["fold_control"] else "." * spec["count"] + "\n" + "-" * 70 + "\nRan " + str(spec["count"]) + " tests in 0.010s\n\nOK\n"
            self.assertIsNone(audit.classify(self.c, spec, None, 0, stdout, stderr))
            with self.assertRaises(ValueError):
                audit.classify(self.c, spec, None, 0, stdout + "warning", stderr)

    def test_positive_count_still_exact(self):
        spec = next(row for row in self.commands if row["kind"] == "positive")
        sources = {path: self.c.snapshots["leaf"][path] for path in self.c.checks["leaf"].FILES}
        modified_d = types.SimpleNamespace(**(vars(self.c.d) | {"classify": lambda *args: {"candidate_accepted": True, "observed_verified": 41}}))
        modified = types.SimpleNamespace(**(vars(self.c) | {"d": modified_d}))
        with self.assertRaises(ValueError):
            audit.classify(modified, spec, sources, 0, "", "")

    def test_cpu_custody_checks_both_paths(self):
        artifact = self.c.review["retained_cpu_artifact"]
        audit.cpu_custody(artifact)
        with self.assertRaises(ValueError):
            audit.cpu_custody(artifact | {"bytes": artifact["bytes"] + 1})
        original = audit.sha
        with patch.object(audit, "sha", side_effect=lambda path: "0" * 64 if str(path) == artifact["retained"] else original(path)):
            with self.assertRaises(ValueError):
                audit.cpu_custody(artifact)

    def test_json_types_and_duplicate_keys_fail_closed(self):
        self.assertTrue(audit.same({"ok": True, "count": 1}, {"count": 1, "ok": True}))
        self.assertFalse(audit.same({"ok": 1}, {"ok": True}))
        self.assertFalse(audit.same({"count": True}, {"count": 1}))
        with self.assertRaises(ValueError):
            audit.pairs([("x", 1), ("x", 1)])

    def test_archive_exact_roster_hash_schema_and_unique_expected_paths(self):
        pins = {str(BASE / "audit_signed_composition_v1.py"): "a" * 64,
                str(BASE / "test_audit_signed_composition_v1.py"): "b" * 64}
        index = {source: {"archive": "raw-helpers/" + source.removeprefix("/") + ".source", "sha256": digest}
                 for source, digest in pins.items()}
        audit.archive_binding(index, pins)
        first, second = list(pins)
        for mutation in ("missing", "extra", "wrong-hash", "path-alias", "wrong-path", "extra-field"):
            changed = copy.deepcopy(index)
            if mutation == "missing":
                del changed[first]
            elif mutation == "extra":
                changed[str(BASE / "unexpected.py")] = dict(changed[first])
            elif mutation == "wrong-hash":
                changed[first]["sha256"] = "0" * 64
            elif mutation == "path-alias":
                changed[first]["archive"] = changed[second]["archive"]
            elif mutation == "wrong-path":
                changed[first]["archive"] = "raw-helpers/../../outside.source"
            else:
                changed[first]["extra"] = True
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                audit.archive_binding(changed, pins)


if __name__ == "__main__":
    unittest.main()
