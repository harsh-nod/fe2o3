#!/usr/bin/env python3
"""Independently replay the reviewed A2 campaign auditor after agent readback."""

import hashlib
import json
from pathlib import Path
import sys
import types

BASE = Path('/home/harsh/.codex-tmp')
RECORDS = BASE / 'fe2o3-a2-producer-composition-records-20260930-audit'
AUDIT = RECORDS / 'audit_signed_composition_v1.py'
OUTPUT = BASE / 'fe2o3-a2-composition-root-readback-20261001.json'
AUDIT_SHA = 'b9d4b1920bd6167108d0a5d25ff050f6500453bcee03ef90fe34cf77da90ae9d'
CONTROLS_SHA = 'f35ed76e60066b90fa3acdc780de26ac6c5cb8d2f2016e5ffe247cf9bc6de5c9'
CAPTURE_SHA = '756e2b4848cb16b3e989378f45d254184c06b527cce41b7e15f69114c2bddf1e'


def need(value, message):
    if not value:
        raise ValueError(message)


need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize,
     'python3 -I -B required')
need(not OUTPUT.exists(), 'fresh root receipt')
for path, digest in ((AUDIT, AUDIT_SHA),
                     (RECORDS / 'test_audit_signed_composition_v1.py', CONTROLS_SHA),
                     (RECORDS / 'capture_independent_readback_v1.py', CAPTURE_SHA)):
    need(path.resolve() == path and not path.is_symlink() and
         hashlib.sha256(path.read_bytes()).hexdigest() == digest, 'reviewed audit and capture bytes')
capture = RECORDS / 'independent-readback-attempt-1/001-audit'
receipt = json.loads((capture / 'owned/record.json').read_bytes())
command = json.loads((capture / 'command.json').read_bytes())
argv = ['/usr/bin/python3', '-I', '-B', str(AUDIT)]
need(receipt['status'] == 0 and type(receipt['status']) is int and
     receipt['group_absent'] is True and receipt['command'] == argv,
     'agent readback closed successfully')
need(command['argv'] == argv and command['timeout'] == 180 and
     command['auditor_sha256'] == AUDIT_SHA and command['controls_sha256'] == CONTROLS_SHA and
     command['capture_sha256'] == CAPTURE_SHA, 'exact independently reviewed capture command')
need((capture / 'owned/stderr.log').read_bytes() == b'' and
     json.loads((capture / 'result.json').read_bytes()) ==
     {'returncode': 0, 'stderr_empty': True, 'group_absent': True}, 'accepted empty-stderr readback')
module = types.ModuleType('root_a2_campaign_audit')
module.__file__ = str(AUDIT)
sys.modules[module.__name__] = module
exec(compile(AUDIT.read_bytes(), str(AUDIT), 'exec'), module.__dict__)
result = module.audit()
need(result == json.loads((capture / 'owned/stdout.log').read_bytes()),
     'independent agent and root readbacks agree')
with OUTPUT.open('x', encoding='ascii') as stream:
    stream.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'output': str(OUTPUT), 'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
                  **result}, sort_keys=True))
