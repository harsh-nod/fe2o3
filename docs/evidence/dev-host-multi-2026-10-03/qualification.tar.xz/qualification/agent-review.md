# Read-Only Native Agent Review

Primary integrated all source changes and ran all tests. Agents performed no
edits or hardware runs. These are review conclusions, not independent execution
or formal verification receipts.

- multigpu_host_admission found no concrete API/fixture blocker: the positive
  library uses real generated arguments for old/new sync/async paths, and four
  new negative bins check executable consumption and wrong-kernel arguments.
  There is no CPU constructor for a genuine concrete multi-KFD Context plus a
  protected executable; compile/source checks are not new executed admission
  rejection or positive native evidence.
- xgmi_source_ci found no gate, API or documentation blocker. Keep the three
  concrete forwarding methods because semantic preparation already shares its
  implementation. The renamed test causes one removed and three added roster
  names, a net gain of two. No runtime pin or unsafe-inventory refresh is needed.
- xgmi_integration_review confirmed that existing async reservation, activation,
  issue/readback/retirement hooks provide the complete lifecycle. The absent
  positive path is authentic compiler/verification/semantic-machine evidence,
  not an unconditional multi-backend reject. Positive provider implementations
  remain test-only; a complete refinement verifier is implementation work, while
  approved measurements/ledger/rollback policy are deployment inputs.

Follow-up shortest-path review found reusable semantic/physical ABI joins already
in compiler_descriptor.rs, production_semantic_fn_abi_v1.rs and the HSACO finalizer.
The checked-prefix extraction branch drops entry bindings; retain them alongside
the same semantic KIR owner instead of creating another parser. Start ABI discovery
from the real fill output-slice fixture, then scalar-plus-output.

The existing checked-prefix Rust fixture is not a complete checked-add kernel:
its helper continues with XOR/return, while the entry has indexing, bounds, call
and store semantics. Its accepted extraction mode does not emit final LLVM/HSACO.
The checked-in hand-authored LLVM transform fixture has real emitted code but no
Rust lineage, and uses v_alignbit_b32/v_xad_u32 rather than the local S_ADD_U32
profile. Neither can be relabeled as a complete admitted Rust kernel. Prioritize
the actual selected device entry, argument loads, complete effects and termination.
