"""Replay the final host-only qualification; never promote intermediate runs."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = '2761f359468d60c6814e265ddaa21bff50b0c499'
PRIOR = Path('/home/harsh/.codex-tmp/fe2o3-result-staging-20261003')
sys.path.insert(0, str(HERE))
import capture


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipt(label):
    folder = HERE / label
    row = read(folder / 'receipt.json')
    assert row['exit'] == 0 and row['source_unchanged'], label
    assert row['base'] == BASE and row['environment'] == capture.ENV
    assert row['controller_sha256'] == sha(HERE / 'capture.py')
    assert read(folder / 'source-before.json') == source == read(folder / 'source-after.json')
    for name in ('stdout', 'stderr'):
        assert row[name + '_sha256'] == sha(folder / name)
    return row


def counts(label):
    output = (HERE / label / 'stdout').read_text()
    matches = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', output)
    assert matches and 'FAILED' not in output
    return [sum(int(row[index]) for row in matches) for index in range(2)]


source = capture.snapshot()
stages = ['host-artifact', 'host-roster', 'host-tests', 'host-docs', 'host-clippy',
          'host-no-default', 'macros-lib', 'generated-fixtures', 'format', 'whitespace']
labels = ['final-' + stage for stage in stages]
labels += [f'controls-02-{index:02}' for index in range(33)]
receipts = {label: receipt(label) for label in labels}
controls = read(HERE / 'controls-02.json')
assert len(controls) == 33
for item in controls:
    assert item['exit'] == 0
    assert receipts[item['label']]['command'][4:] == item['command']

assert counts('final-host-tests') == [315, 5]
assert counts('final-host-docs') == [35, 0]
assert counts('final-host-no-default') == [198, 1]
assert counts('final-macros-lib') == [64, 0]
assert counts('final-generated-fixtures') == [2, 0]
roster = set(re.findall(r'^(.+): test$', (HERE / 'final-host-roster/stdout').read_text(), re.M))
tested = set(re.findall(r'^test (.+) \.\.\. (?:ok|ignored[^\n]*)$',
                        (HERE / 'final-host-tests/stdout').read_text(), re.M))
assert tested == roster and len(roster) == 320
old_roster = set(re.findall(r'^(.+): test$', (PRIOR / 'host-roster/stdout').read_text(), re.M))
prefix = 'generated_kfd_invocation::generated_runtime_invocation::'
assert old_roster - roster == {
    prefix + 'async_preparation_tests::async_preparation_reuses_protected_constructor_and_original_account'}
assert roster - old_roster == {prefix + 'preparation_tests::' + name for name in (
    'async_preparation_reuses_protected_constructor_and_original_account',
    'both_sync_preparation_paths_gate_before_exact_child_callback_and_share_payload',
    'both_validation_paths_delegate_only_original_private_preparation')}

fixture_source = (ROOT / 'crates/fe2o3-macros/tests/typed_kernel_fixtures.rs').read_text()
case_table = fixture_source.split('fn generated_worker_v3_adapter_rejects_unsafe_escape_hatches()', 1)[1]
case_table = case_table.split('let cases:', 1)[1].split('\n    ];', 1)[0]
expected_cases = re.findall(r'\(\s*"([a-z0-9_]+)"\s*,', case_table)
accepted_cases = re.findall(r'^generated adapter compile-fail accepted: (\w+)$',
                           (HERE / 'final-generated-fixtures/stderr').read_text(), re.M)
assert len(expected_cases) == len(set(expected_cases)) == 37
assert accepted_cases == expected_cases

prior_source = read(PRIOR / 'host-artifact/source-before.json')
fixture = 'crates/fe2o3-macros/tests/fixtures/generic-worker-v3-adapter/src/'
added = {fixture + 'multi_context.rs'} | {fixture + 'bin/' + name + '.rs' for name in (
    'multi_context_consumes_executable', 'multi_context_async_consumes_executable',
    'multi_context_wrong_kernel', 'multi_context_async_wrong_kernel')}
modified = {
    'crates/fe2o3-host/src/generated_runtime_invocation.rs',
    fixture + 'lib.rs', 'crates/fe2o3-macros/tests/typed_kernel_fixtures.rs'}
assert set(source) - set(prior_source) == added
assert set(prior_source) <= set(source)
assert {path for path in prior_source if source[path] != prior_source[path]} == modified
tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', BASE], cwd=ROOT)
blobs = {}
for entry in tree.split(b'\0'):
    if entry:
        metadata, path = entry.split(b'\t', 1)
        blobs[path.decode()] = metadata.split()[2].decode()
for path, digest in prior_source.items():
    original = (subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
                if path in modified else (ROOT / path).read_bytes())
    assert hashlib.sha256(original).hexdigest() == digest, path
    blob = b'blob ' + str(len(original)).encode() + b'\0' + original
    assert hashlib.sha1(blob).hexdigest() == blobs[path], path

proofs = read(PRIOR / 'metadata-01/metadata-report.json')['proof_files']
assert len(proofs) == 76
assert all(source[path] == digest for path, digest in proofs.items())
(HERE / 'unchanged-proof-files.json').write_text(json.dumps(proofs, sort_keys=True, indent=2) + '\n')

path = 'crates/fe2o3-host/src/generated_runtime_invocation.rs'
old = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT, text=True)
new = (ROOT / path).read_text()
for name in ('require_runtime_evidence(', 'prepare_context_payload<Arguments>(', 'project_persistent('):
    def method(text):
        return text.split('fn ' + name, 1)[1].split('\n    }\n', 1)[0]
    assert method(old) == method(new), name

artifacts = receipts['final-host-artifact']['executables']
assert len(artifacts) == 1
for path, identity in artifacts.items():
    assert identity['target'] == 'fe2o3_host' and identity['test']
    assert sha(Path(path)) == identity['sha256']
    assert Path(path).stat().st_size == identity['byte_length']

report = dict(base=BASE, source_files=len(source), accepted_receipts=len(receipts),
              host_tests=counts('final-host-tests'), host_roster=len(roster),
              host_doctests=counts('final-host-docs'),
              host_no_default=counts('final-host-no-default'),
              macros_library=counts('final-macros-lib'),
              fixture_harness=counts('final-generated-fixtures'),
              accepted_negative_cases=accepted_cases, source_control_commands=len(controls),
              added_source_files=sorted(added), modified_source_files=sorted(modified),
              unchanged_selected_proof_files=len(proofs), host_artifacts=artifacts,
              native_runs=0, solver_runs=0,
              boundary='Compile and source-wiring coverage; no new positive Worker application admission')
(HERE / 'audit-report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report, sort_keys=True))
