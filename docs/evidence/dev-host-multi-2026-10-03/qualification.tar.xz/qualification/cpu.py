"""Host API and downstream generated-argument qualification; no GPU execution."""
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PREFIX = sys.argv[1] if len(sys.argv) == 2 else ''
assert not PREFIX or PREFIX == 'final-'
CARGO = ['cargo', '+nightly-2026-04-03']
HOST = ['-p', 'fe2o3-host', '--all-features']
STAGES = [
    ('host-artifact', 900, CARGO + ['test', *HOST, '--lib', '--no-run', '--message-format=json']),
    ('host-roster', 900, CARGO + ['test', *HOST, '--lib', '--', '--list']),
    ('host-tests', 900, CARGO + ['test', *HOST, '--lib']),
    ('host-docs', 900, CARGO + ['test', *HOST, '--doc']),
    ('host-clippy', 900, CARGO + ['clippy', *HOST, '--lib', '--', '-D', 'warnings']),
    ('host-no-default', 900, CARGO + ['test', '-p', 'fe2o3-host', '--no-default-features', '--lib']),
    ('macros-lib', 900, CARGO + ['test', '-p', 'fe2o3-macros', '--lib']),
    ('generated-fixtures', 1800, CARGO + ['test', '-p', 'fe2o3-macros', '--test', 'typed_kernel_fixtures', 'generated_worker_v3_adapter_', '--', '--nocapture']),
    ('format', 60, CARGO + ['fmt', '-p', 'fe2o3-host', '-p', 'fe2o3-macros', '--', '--check']),
    ('whitespace', 60, ['git', 'diff', '--check']),
]
for name, seconds, command in STAGES:
    result = subprocess.run(['python3', '-I', '-B', str(HERE / 'capture.py'), PREFIX + name, f'{seconds}s', *command])
    if result.returncode:
        sys.exit(result.returncode)
