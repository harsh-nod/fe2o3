env CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2 cargo test -p fe2o3-kfd --lib persistent_completed_restore -- --test-threads=1 
