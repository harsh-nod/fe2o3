rm -- target/debug/deps/fe2o3_kfd-9280442e7aa71d90 
