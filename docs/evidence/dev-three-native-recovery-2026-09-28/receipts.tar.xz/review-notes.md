# Native Exact-Three Recovery Review

Primary source baseline: 37cdd7513fed18126c7f9dcf2ef82c2a86cc9dbc.
Implementation: 71f939ebb2d8cd3197b2a5c016c982746a524408.
Final source: 9f9e4de8196efaad3ce8a9b6f5701de92003efda.
Final source tree: 44779501984b8872a6151eb264d1022e250bcc19.

Two read-only collaboration agents reviewed fixture design and source. Primary
owned edits, integration and serialized builds/tests. No Qwen worker, permission
request, escalation, remote file or remote job was used.

The design rejects a cross-crate dev-only constructor feature: Cargo feature
unification would expose synthetic authority beyond the private fixture. Lower
tests instead create real owned dispatch/control/data through existing
registered-memory fixtures, while completion observations remain CPU-injected.

The Published fixture now stops before completion and preserves the original
batch. A foreign public poll must return Some of that exact receipt without
changing either populated session. Epoch and completion occurrence are compared
before and after original-session Pending continuation; owner, control, arena,
attachment, initialization, memory bytes and detached-ledger snapshots must match.
Both sessions then CPU-complete/recycle, publicly detach, retire and clean up.
The recycled foreign-detach case similarly preserves both populated sessions,
binding and recycle observation, then finishes each through its original session.
The recycle observation contains only packet count; exactness is additionally
supported by unchanged owner/lease/control snapshots and original-session success.

For retirement, each ordinal receives an authentic extra full-range ComputeWrite
reservation using that member's exact frontier. Reservation without the frontier
must reject DependencyRequired. Aggregate retirement must return Err(Self),
preserving every owner's identity, boxed ledger, allocation attachment, frontier
identity, digest and initialization. No earlier member may retire. The retained
reservation is cancelled and aggregate retry must succeed, clearing all settled
entries and preserving read digests/write initialization before native cleanup.
Snapshots deliberately compare across rejection, not across cancellation:
reservation generation/sequence counters are monotonic and do not roll back.

Review caught the distinction between Recycled's completed-use lease and a later
detached dependency frontier. The first compile independently caught that and
an unwrap_err Debug bound; both were corrected in tests. Review also required
retained_settled_use_count == 0 on successful retirement. Strict Clippy required
the existing narrow result_large_err allowance on the receipt-returning callback.
All nonfinal attempts remain in this packet.

The production runtime now calls concrete private poll-failure, detach-failure
and retirement handlers. Their ownership ordering is unchanged: park Some
receipts in terminal custody, classify None as lower-owned, and reindex exact
Detached(Self) on retirement rejection before formatting/reporting errors.
These are production-connected functions, not publicly constructible receipts.
The lower tests do NOT pass their native receipts through the runtime handlers.
Existing scripted runtime faults remain separate evidence; no end-to-end native
fault execution, GPU execution, executable formal refinement or performance
acceptance follows from this packet.

A follow-up read-only unwind audit found no healthy returned-error owner loss.
Poll/recycle catches callback panics and reinstalls quarantined lower custody.
Detach/retirement have a separate structural panic-only boundary: the runtime
marks NativeOwned while the lower function owns its local roster. Their normal
tails are preflighted, allocation-free and callback-free, but an internal panic
is not established to retain that roster in an indexed owner. This is an open
qualification boundary, not a demonstrated reachable healthy-path defect.
No public callback fold was added merely to share test branches; that would
expand the production API without executing runtime custody callbacks with the
genuine fixture receipts. Direct end-to-end native fault coupling stays open.

The previous permission-relay turn did not change runtime implementation.
This continuation revalidated the signed worktree and made source/test progress;
the full goal remains active. DNS failure prevents MI300X access but does not
prevent these meaningful local checks, so the goal is not marked blocked.
