git show -s --format=commit\ %H%ntree\ %T HEAD 
