git show -s --format=commit\ %H%ntree\ %T%nauthor\ %an\ \<%ae\>%nsubject\ %s HEAD 
