import socket
import sys

left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
failures = 0
with left, right:
    checks = [
        ("SO_DOMAIN", lambda: left.getsockopt(socket.SOL_SOCKET, socket.SO_DOMAIN)),
        ("SO_TYPE", lambda: left.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE)),
        ("getpeername", left.getpeername),
        ("SO_PEERCRED", lambda: left.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12)),
    ]
    for name, check in checks:
        try:
            print(f"{name}: {check()!r}")
        except OSError as error:
            failures += 1
            print(f"{name}: errno={error.errno} {error.strerror}")
sys.exit(1 if failures else 0)
