python3 /home/harsh/.codex-tmp/fe2o3-three-native-recovery-20260928-bHBL27Pe/socket_probe.py 
