# Frozen Developer Receipts

This directory is frozen after every qualification command reached a terminal
status. Do not append subsequent publication or follow-up results here.

Baseline: 37cdd7513fed18126c7f9dcf2ef82c2a86cc9dbc.
Final source: 9f9e4de8196efaad3ce8a9b6f5701de92003efda.
Source tree: 44779501984b8872a6151eb264d1022e250bcc19.
Signed source identity and exact post-test source continuity are recorded.
Only final-* checks, plus exact-source-continuity, qualify that final source;
earlier compile/lint attempts are retained as nonfinal evidence.

All checks ran serially with no concurrent source edits. Final results:
- Full KFD: 1687 passed, 1 failed, 0 ignored; exit 101.
- Serial runtime backend selection: 858 passed, 28 ignored; exit 0.
- Full runtime: 1755 passed, 3 failed, 28 ignored.
- Runtime model: 1080 passed, 19 ignored.
- Integration: 11 passed, 3 ignored.
- Doctests: 52 runtime and 29 model passed.
- Runtime/model combined command: exit 101.
- Strict KFD/runtime all-feature/all-target Clippy, no-default runtime,
  formatting, signature verification and source continuity: passed.

All six persistent_completed_restore tests passed on the final source. This is
CPU-injected lower receipt/control/data evidence, not GPU execution or runtime
delivery of genuine native failures. Formal refinement and performance are not
qualified. Four telemetry failures remain unwaived; the full suites are not
green. The separate AF_UNIX SEQPACKET probe returned EPERM for SO_DOMAIN,
SO_TYPE, getpeername and SO_PEERCRED. The failing KFD telemetry source is outside
this change; its V2 adapter masks shared socket validation failures as
SocketAdmission. Runtime failures directly report InspectSocket(PermissionDenied).

Both MI300X connection attempts failed at hostname resolution. No remote jobs or
files were created. Local cleanup removed only the default-feature test binary
created by this task, not the all-feature qualified executable or other owners'
files. Existing unrelated untracked evidence was preserved.

The broader goal remains active. Accepted milestones, A1/A2, #182 and HIP/HSA
parity have not been promoted. next-action-review.md records the separately
identified generated retry/Stop mismatch; it is not an implemented fix here.
