git diff --exit-code HEAD -- 
