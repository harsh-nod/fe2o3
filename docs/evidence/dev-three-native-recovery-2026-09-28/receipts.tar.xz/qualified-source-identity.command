git log -1 --format=fuller 
