# Next Implementation Audit: Generated Retry Then Stop

Read-only agent finding, not an implemented or end-to-end reproduced fix in
this packet. The primary qualification source remains unchanged.

Primary independently read the receipt transition, generated retirement routing
and lower pristine-abort contract and confirmed this classification mismatch.
This remains source evidence, not a joined native generated reproduction.

The current generated ISSUE/Stop contract has a concrete availability gap:

1. Ordinary classified submission reserves an epoch in bind_templates.
2. A RetryableBeforeSideEffect failure cancels that epoch, preserving its
   recipe queue, slot generation and next-generation history.
3. generated_adoption/receipt.rs restores the generated receipt to Ready.
4. generated_adoption/issue.rs considers Ready retireable; Context Stop calls
   retire_generated_data_v1.
5. generated_adoption.rs routes Ready retirement to pristine abort.
6. queue_live/pristine_abort.rs correctly rejects any reservation history.
   Stop terminalizes a retained, unpublished workload instead of disposing it.

Relevant source at 9f9e4de8196efaad3ce8a9b6f5701de92003efda:
- crates/fe2o3-runtime/src/kfd_backend/generated_adoption/receipt.rs:36
- crates/fe2o3-runtime/src/kfd_backend/generated_adoption/issue.rs:215
- crates/fe2o3-runtime/src/context/generated_issue.rs:350
- crates/fe2o3-runtime/src/kfd_backend/generated_adoption.rs:462,500
- crates/fe2o3-kfd/src/queue_live/fixed_dispatch.rs:4495
- crates/fe2o3-kfd/src/queue_dispatch_binding.rs:1615,1718
- crates/fe2o3-kfd/src/queue_live/pristine_abort.rs:62
- docs/runtime-generated-issue-v1.md:27,61

Candidate sound repair, to be checked against source before implementation:
distinguish never-attempted Ready from cancelled-only unpublished history; keep
pristine abort unchanged; admit a separate history-aware ordinary abort only
after exact queue/attachment validation, vacant epochs, no completion pins and
no publication/recycle history. Preserve exact continuation generation and
capacity/account identity. Reuse rooted control cleanup, retake transport and
returned-data disposal; never invent a recycled generation or retry publication
as part of Stop.

Focused validation should join real reserve/cancel history to the new lower
abort and cover repeated retries, successful later publication, unsafe-history
rejections, cleanup/retake failures and exact next-generation rebind. Existing
native generated fixtures are hardware-only; separate CPU receipt and native
custody tests must not be represented as protected Worker/native execution.

Ordinary MaterializedPrepared cancellation returning TooLate is a separate
conservative limitation, not the same documented generated Stop mismatch.
