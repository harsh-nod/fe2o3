# Retained Window Arithmetic Campaign

`proof-attempt-02/` is a byte-identical copy of the complete accepted campaign
from `/home/harsh/.codex-tmp/fe2o3-compute-xgmi-window-20261002/proof-attempt-02`.
The original remains untouched. Recursive comparison found no differences.

The packet retains all 14 source/support inputs, exact staged positive and
mutated shared bodies, both source manifests, clean environment, 16 process
receipts and raw stdout/stderr. It includes the pinned controller, seven-test
controller controls, inherited process owner, closure checker and complete
190-file verifier closure manifest. The Verus distribution itself is not
redistributed. `run-compute-xgmi-window.sh` is the additive CI entrypoint.

Accepted result SHA-256:
`f7f72fad691a14997aa59d0a7d54b840c5a6a95cae3e5b18bf6c7babb2fa49cd`.

The two actual shared bodies and their arithmetic composition verified three
functions; all 11 logical mutants failed their selected postconditions. This
does not verify the allocation/mapping/native adapter, physical GPU address
arithmetic, initialization, custody, ticket ordering, restoration or DMA.

Diagnostic file paths retain their original recording locations. The offline
auditor maps only diagnostic `file_name` paths to this copied packet in memory
before using the exact archived classifier. No raw record is rewritten and no
solver reruns during audit.
