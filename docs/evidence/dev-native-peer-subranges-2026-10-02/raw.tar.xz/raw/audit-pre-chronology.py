#!/usr/bin/env python3
"""Read retained qualification receipts; never run Cargo, hardware or a solver."""
import ast
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import sys
import tarfile

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
BASE = 'bdc9b7b3c000b4b9094b7e4226e6eb198b6d57d6'
ATTEMPT = 'attempt-01'
PINS = {
    'cpu.py': '03e38463d2c4bacd21289a76e9312cbab23b15f2e6aba05b0dfe6c52fbfe1991',
    'cpu-concurrent.py': '75febcb52f6a15deda92eeb392874d03bc1e9bb302aa3a2b2d0085786f59d5ec',
    'capture.py': '84b5f1e88a891c42562613d3fdf178ea41ef1228324f0d2d2f09c0b621f1eac1',
    'hardware-01/campaign.py': 'b7ea1899491a636820193ca6940d0b6bcfb42dada10533e3ead04b523594526d',
    'hardware-01/capture.py': 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f',
    'source-ci/support.py': 'badb1506bebbb402f5104bbbedd963225b846e025475edf33103401e95452d40',
    'source-ci/reference/inputs.json': '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e',
    'source-ci/proposal-04/metadata-report.json': '80654f0e7135584d54038f899c562e71b625c9701e2b81a564df4dc0088b649c',
    'source-ci/proposal-04/metadata.patch': '69b817e4708f9a3b78ee991f2cbeb0cf83990398469d8fcafa1242be58d8052c',
    'proof/proof-attempt-02/result.json': 'f7f72fad691a14997aa59d0a7d54b840c5a6a95cae3e5b18bf6c7babb2fa49cd',
    'proof/proof-attempt-02/source-before.json': '16b40831c30526a4f831930126bc8844725f89d73e26faaa8f29222cd37f2080',
}
PRIOR = ROOT / 'docs/evidence/dev-multigpu-late-admission-2026-10-02/raw.tar.gz'
PRIOR_SHA = '0596dfd7d030be49a7e66d86e3e3883699f8815124a77537ec5f4af3f22ebb6c'
PRIOR_PREFIX = 'fe2o3-multigpu-late-admission-20261002/attempt-01/'
PROOF_ORIGIN = '/home/harsh/.codex-tmp/fe2o3-compute-xgmi-window-20261002/proof-attempt-02'


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def raw(path):
    need(path.is_file() and not path.is_symlink(), 'ordinary input: ' + str(path))
    return path.read_bytes()


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def read(path):
    return json.loads(raw(path), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def sources(manifest):
    need(manifest and all(not Path(name).is_absolute() and '..' not in Path(name).parts
                          for name in manifest), 'relative source roster')
    for name, digest in manifest.items():
        need(sha(raw(ROOT / name)) == digest, 'current source identity: ' + name)


def outputs(folder, record, names=('stdout', 'stderr')):
    for name in names:
        need(record[name + '_sha256'] == sha(raw(folder / name)), 'raw output identity: ' + str(folder / name))


def owned(folder, argv, env, controller):
    result = read(folder / 'result.json')
    command = read(folder / 'command.json')
    need(all(result[key] == value for key, value in command.items()), 'immutable owned invocation')
    need(result['command'] == argv and result['environment'] == env and result['cwd'] == str(ROOT)
         and result['controller_sha256'] == controller, 'exact owned command/environment/controller')
    need(result['accepted'] is True and result['exit'] == 0 and result['error'] is None
         and not result['timed_out'] and not result['interrupted']
         and not result['retained_session_members'] and result['group_absent'] is True
         and result['session_absent'] is True, 'complete owned success')
    need(datetime.fromisoformat(result['finished']) >= datetime.fromisoformat(result['started']), 'receipt times')
    outputs(folder, result)
    return result


def captured(step, expected, seconds, manifest, env, controller):
    folder = RAW / step['capture']
    receipt = read(folder / 'receipt.json')
    invocation = read(folder / 'command.json')
    need(all(receipt[key] == value for key, value in invocation.items()), 'capture invocation retained')
    need(sha(raw(folder / 'receipt.json')) == step['receipt_sha256'], 'capture receipt binding')
    need(receipt['command'] == ['timeout', '--signal=TERM', '--kill-after=30s', str(seconds) + 's', *expected]
         and receipt['exit'] == 0 and receipt['environment'] == env and receipt['cwd'] == str(ROOT)
         and receipt['base'] == BASE and receipt['controller_sha256'] == PINS['capture.py']
         and receipt['source_unchanged'] is True, 'exact successful source capture')
    need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == manifest,
         'capture source continuity')
    outputs(folder, receipt)
    outer = RAW / step['controller']
    invocation = read(outer / 'command.json')['command']
    need(invocation[1:] == ['-I', '-B', str(RAW / 'capture.py'), step['capture'], str(seconds) + 's', *expected]
         and Path(invocation[0]).name.startswith('python3'), 'exact capture wrapper')
    result = owned(outer, invocation, env, controller)
    need(result['timeout_seconds'] == seconds + 45, 'owned outer bound')
    return folder, receipt


def prior_outputs():
    need(sha(raw(PRIOR)) == PRIOR_SHA, 'authenticated prior archive')
    with tarfile.open(PRIOR, 'r:gz') as archive:
        names = archive.getnames()
        need(len(names) == len(set(names)), 'unique prior archive members')
        def member(name):
            item = archive.getmember(PRIOR_PREFIX + name)
            need(item.isfile(), 'ordinary prior result member')
            return archive.extractfile(item).read().decode()
        runtime = member('tests/fe2o3_runtime-full.stdout')
        need(sha(runtime.encode()) == '22420c9de69702584632d1aa32c53cb1a3e9b8d792d1378624f130dd8b38e60c',
             'exact accepted prior runtime output')
        ignored = sorted(re.findall(r'^test (.+?) \.\.\. ignored(?:, [^\n]*)?$', runtime, re.M))
        need(len(ignored) == len(set(ignored)) == 32, 'historical exact ignore roster')
        examples = {name: sorted(re.findall(r'^test (.+?) \.\.\. ok$', member('checks/' + name + '-example.stdout'), re.M))
                    for name in ['deferred', 'live-sharded']}
    return ignored, examples


def audit_cpu():
    cpu = module(RAW / 'cpu.py', 'audited_cpu')
    capture = module(RAW / 'capture.py', 'audited_capture')
    modes = {mode: read(RAW / ATTEMPT / mode / 'result.json') for mode in ['build', 'tests', 'checks']}
    manifest = read(RAW / ATTEMPT / 'build/source-before.json')
    sources(manifest)
    # Fresh inventory, not just a subset of files that happen to remain present.
    need(capture.snapshot() == manifest, 'complete current source inventory')
    for mode, result in modes.items():
        folder = RAW / ATTEMPT / mode
        script = 'cpu.py' if mode == 'build' else 'cpu-concurrent.py'
        need(result['accepted'] is True and result['error'] is None and result['source_unchanged'] is True
             and result['mode'] == mode and result['attempt'] == ATTEMPT and result['base'] == BASE
             and result['controller_sha256'] == PINS[script] and result['capture_sha256'] == PINS['capture.py']
             and result['argv'] == [str(RAW / script), mode, ATTEMPT]
             and result['environment'] == capture.ENV and result['cwd'] == str(ROOT), 'selected successful CPU mode')
        need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == manifest, 'mode source identity')
        command = read(folder / 'command.json')
        need(all(result[key] == value for key, value in command.items()), 'mode invocation retained')
    build = read(RAW / ATTEMPT / 'build/build.json')
    need(build['executables'] == modes['build']['results']['executables']
         and build['steps'] == modes['build']['results']['steps'] and len(build['steps']) == 5, 'complete build stages')
    build_folder, build_receipt = captured(build['steps'][0], cpu.cargo('test', *cpu.PACKAGES, '--all-features', '--lib', '--no-run',
                                          '--message-format=json'), 2400, manifest, capture.ENV, PINS['cpu.py'])
    messages = [json.loads(line) for line in raw(build_folder / 'stdout').decode().splitlines()]
    need([row for row in messages if row.get('reason') == 'build-finished']
         == [{'reason': 'build-finished', 'success': True}], 'actual Cargo build success')
    built = build['executables']
    old_ignored, old_examples = prior_outputs()
    for index, (target, total) in enumerate([('fe2o3_kfd', 1934), ('fe2o3_runtime', 2177)]):
        identity = built[target]
        paths = {row['executable'] for row in messages if row.get('reason') == 'compiler-artifact'
                 and row.get('executable') and row['target']['name'] == target and row['profile']['test'] is True}
        need(paths == {identity['path']} and build_receipt['executables'][identity['path']]
             == {key: identity[key] for key in ['sha256', 'byte_length']} | {'target': target, 'test': True},
             'exact library artifact captured at build')
        need(cpu.executable(identity['path']) == {k: identity[k] for k in ['path', 'sha256', 'byte_length']}, 'final library ELF')
        need(len(identity['list']) == len(set(identity['list'])) == total
             and identity['list'] == sorted(identity['list']), 'reviewed complete suite count')
        need(identity['ignored'] == ([] if target == 'fe2o3_kfd' else old_ignored), 'no newly ignored tests')
        for offset, ignored in enumerate([False, True]):
            argv = [identity['path'], '--list', '--test-threads=1', *(['--ignored'] if ignored else [])]
            folder, _ = captured(build['steps'][1 + 2 * index + offset], argv, 60, manifest, capture.ENV, PINS['cpu.py'])
            need(cpu.roster(raw(folder / 'stdout').decode()) == identity['ignored' if ignored else 'list'], 'retained full discovery')
    kfd, runtime = built['fe2o3_kfd'], built['fe2o3_runtime']
    new_kfd = [name for name in kfd['list'] if 'compute_xgmi_subrange_' in name or '::compute_xgmi_window::' in name]
    new_runtime = [name for name in runtime['list'] if name.split('::')[-1].startswith(('native_subrange_', 'native_subranges_'))]
    need(len(new_kfd) == 9 and len(new_runtime) == 7, 'nonempty complete new-test profiles')
    heavy = [name for name in kfd['list'] if name.startswith(cpu.PREFIX)]
    groups = {f'kfd-heavy-{i}': heavy[i::4] for i in range(4)}
    groups['kfd-rest'] = [name for name in kfd['list'] if not name.startswith(cpu.PREFIX)]
    need([len(groups[name]) for name in groups] == [82, 81, 81, 81, 1609]
         and Counter(n for values in groups.values() for n in values) == Counter(kfd['list']), 'complete disjoint reviewed partitions')
    parts = read(RAW / ATTEMPT / 'tests/partitions.json')
    need(parts == dict(prefix=cpu.PREFIX, groups=groups, runtime=runtime['list'],
                       runtime_ignored=old_ignored, build_attempt=ATTEMPT), 'exact partition manifest')
    totals = {}
    for label, selected in {**groups, 'runtime-full': runtime['list']}.items():
        identity = runtime if label == 'runtime-full' else kfd
        ignored = old_ignored if label == 'runtime-full' else []
        folder = RAW / ATTEMPT / 'tests' / label
        selection = read(folder / 'selection.json')
        need(selection == dict(selected=selected, ignored=ignored, full_roster=identity['list'],
                               executable={k: identity[k] for k in ['path', 'sha256', 'byte_length']}), 'exact test selection')
        argv = [identity['path'], '--test-threads=1'] + ([] if label == 'runtime-full' else ['--exact', *selected])
        owned(folder / 'list', [*argv, '--list'], capture.ENV, PINS['cpu-concurrent.py'])
        need(cpu.roster(raw(folder / 'list/stdout').decode()) == selected, 'independent exact shard discovery')
        run = owned(folder / 'run', argv, capture.ENV, PINS['cpu-concurrent.py'])
        need(run['timeout_seconds'] == (1800 if label.startswith('kfd-heavy-') else 1200), 'test bounds')
        counts = cpu.test_results(raw(folder / 'run/stdout').decode(), selected, ignored, len(identity['list']))
        result = read(folder / 'result.json')
        need(result['accepted'] is True and result['error'] is None and result['source_unchanged'] is True
             and result['executable_unchanged'] is True and result['counts'] == counts and result['run'] == run
             and result['selection_sha256'] == sha(raw(folder / 'selection.json')), 'exact shard receipt')
        need(read(folder / 'source-before.json') == read(folder / 'source-after.json') == manifest, 'shard source binding')
        need(modes['tests']['results']['results'][label] == result, 'aggregate uses exact shard')
        totals[label] = counts
    checks = modes['checks']['results']
    need(len(checks['steps']) == 18, 'complete checks stage count')
    expected = {}
    def stage(name, seconds, argv):
        expected[name] = (seconds, argv)
    examples = [item for name in cpu.EXAMPLES.values() for item in ['--example', name]]
    stage('clippy', 1800, cpu.cargo('clippy', *cpu.PACKAGES, '--all-features', '--lib', '--tests', *examples, '--no-deps', '--', '-D', 'warnings'))
    stage('directed-clippy', 1200, cpu.cargo('clippy', '-p', 'fe2o3-runtime', '--no-default-features', '--example', cpu.EXAMPLES['directed'], '--no-deps', '--', '-D', 'warnings'))
    stage('no-default', 600, cpu.cargo('check', *cpu.PACKAGES, '--no-default-features', '--lib', '--example', cpu.EXAMPLES['directed']))
    stage('hardware-feature', 600, cpu.cargo('check', '-p', 'fe2o3-runtime', '--no-default-features', '--features', 'hardware-qualification', '--lib', '--example', cpu.EXAMPLES['deferred'], '--example', cpu.EXAMPLES['live-sharded']))
    for kind, name in cpu.EXAMPLES.items():
        args = ['-p', 'fe2o3-runtime', '--no-default-features' if kind == 'directed' else '--all-features', '--example', name]
        stage(kind + '-list', 1200, cpu.cargo('test', *args, '--', '--list', '--test-threads=1'))
        stage(kind + '-tests', 1200, cpu.cargo('test', *args, '--', '--test-threads=1'))
        stage(kind + '-build', 1200, cpu.cargo('build', *args, '--profile', 'test', '--message-format=json'))
    stage('rustc', 60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose'])
    stage('cargo', 60, ['cargo', '+nightly-2026-04-03', '--version'])
    stage('uname', 60, ['uname', '-a'])
    stage('format', 120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *cpu.changed_rust()])
    stage('whitespace', 60, ['git', 'diff', 'HEAD', '--check'])
    records = {}
    for step, (name, (seconds, argv)) in zip(checks['steps'], expected.items()):
        need(step['capture'] == ATTEMPT + '-checks-' + name, 'exact ordered check stages')
        records[name] = captured(step, argv, seconds, manifest, capture.ENV, PINS['cpu-concurrent.py'])
    for kind, count in [('directed', 11), ('deferred', 6), ('live-sharded', 5)]:
        listed = cpu.roster(raw(records[kind + '-list'][0] / 'stdout').decode())
        need(len(listed) == count and (kind not in old_examples or listed == old_examples[kind]), 'reviewed example roster')
        result = cpu.test_results(raw(records[kind + '-tests'][0] / 'stdout').decode(), listed, [], count)
        witness = checks['witnesses'][kind]
        need(witness['tests'] == result and cpu.executable(witness['executable']['path']) == witness['executable'], 'final example identity/results')
        identity = witness['executable']
        receipt = records[kind + '-build'][1]
        need(receipt['executables'][identity['path']] == {k: identity[k] for k in ['sha256', 'byte_length']} | {'target': cpu.EXAMPLES[kind], 'test': False}, 'witness from exact build')
    return dict(kfd_passed=1934, runtime_passed=2145, runtime_ignored=32, examples_passed=22,
                new_kfd_tests=new_kfd, new_runtime_tests=new_runtime, partitions=totals,
                library_executables={name: {k: row[k] for k in ['path', 'sha256', 'byte_length']} for name, row in built.items()},
                witnesses=checks['witnesses'], source_manifest_sha256=sha(raw(RAW / ATTEMPT / 'build/source-before.json')))


def audit_source_controls():
    folder = RAW / 'source-ci/attempt-02-after'
    result, inputs = read(folder / 'result.json'), read(folder / 'inputs.json')
    need(result['accepted'] is True and result['source_unchanged'] is True and not result['failed']
         and result['command_count'] == len(result['commands']) == 32 and inputs['head'] == BASE, 'exact32 success')
    sources(inputs['source_sha256'])
    need(read(folder / 'closing-source.json') == inputs['source_sha256'], 'source controls closing identity')
    prior = read(RAW / 'source-ci/reference/inputs.json')
    need(len(inputs['commands']) == len(prior['commands']) == 32
         and inputs['commands'] == prior['commands'] and sha(raw(ROOT / '.github/workflows/runtime-component-source-guards.yml'))
         == inputs['workflow_sha256'] == prior['workflow_sha256'], 'unchanged exact workflow commands')
    for index, (entry, (step, literal, argv)) in enumerate(zip(result['commands'], inputs['commands']), 1):
        stage = folder / f'{index:02}'
        need(read(stage / 'receipt.json') == entry and entry['step'] == step and entry['literal'] == literal
             and entry['argv'] == argv and entry['exit'] == 0 and entry['group_absent'] is True
             and not entry['timed_out'], 'actual source-control receipt')
        outputs(stage, entry)
    proposal = RAW / 'source-ci/proposal-04'
    report = read(proposal / 'metadata-report.json')
    need(report['baseline'] == BASE and report['predicates_contracts_and_proof_counts_unchanged'] is True
         and report['proof_closures_unchanged'] is True, 'reviewed metadata scope')
    sources(report['audited_source_sha256'])
    sources(report['proof_files'])
    changed, hashes, counts = 0, 0, 0
    for row in report['changes']:
        source = raw(proposal / 'originals' / Path(row['path']).name)
        need(sha(source) == row['original_sha256'], 'metadata preimage')
        tree = ast.parse(source)
        nodes = {(node.lineno, node.col_offset): node for node in ast.walk(tree) if isinstance(node, ast.Constant)}
        for edit in row['edits']:
            node = nodes[edit['line'], edit['column']]
            need(node.value == edit['old'], 'exact metadata old literal')
            if edit['category'] == 'content-sha256':
                need(all(re.fullmatch(r'[0-9a-f]{64}', value) for value in [edit['old'], edit['new']]), 'SHA-only metadata')
                hashes += 1
            else:
                need(edit['category'] == 'source-inventory-count' and type(edit['old']) is type(edit['new']) is int, 'inventory-only metadata')
                counts += 1
            node.value = edit['new']
        actual = raw(ROOT / row['path'])
        need(sha(actual) == row['proposed_sha256'] and ast.dump(tree, include_attributes=False)
             == ast.dump(ast.parse(actual), include_attributes=False), 'exact applied AST metadata only')
        changed += bool(row['edits'])
    need((changed, hashes, counts, len(report['proof_files']), len(report['audited_source_sha256']),
          report['runtime_source_files'], report['runtime_and_schema_files']) == (12, 20, 7, 76, 1059, 375, 380), 'fixed metadata inventory')
    return dict(commands=32, changed_files=changed, hash_literals=hashes, inventory_literals=counts,
                unchanged_proof_files=76, result_sha256=sha(raw(folder / 'result.json')))


def audit_proof():
    folder = RAW / 'proof/proof-attempt-02'
    before = read(folder / 'source-before.json')
    need(read(folder / 'source-after.json') == before and len(before) == 14, 'proof source closure')
    sources(before)
    for name, digest in before.items():
        need(sha(raw(folder / 'inputs' / name)) == digest, 'self-contained exact proof inputs')
    proof = module(folder / 'inputs/crates/fe2o3-runtime-model/verus/compute_xgmi_window_check.py', 'archived_window_check')
    result = read(folder / 'result.json')
    need(result['accepted'] is True and result['full_campaign'] is True and result['source_unchanged'] is True
         and result['error'] is None and result['whole_adapter_verified'] is False, 'bounded arithmetic proof acceptance')
    mutations = proof.mutations(raw(folder / 'inputs' / proof.BODY).decode())
    expected = ['controls', 'release-before', 'positive-before', *['negative-' + name for name in mutations], 'positive-after', 'release-after']
    need([row['name'] for row in result['stages']] == expected and len(expected) == 16, 'exact proof stages')
    def rebase(value):
        if isinstance(value, dict):
            return {k: (v.replace(PROOF_ORIGIN, str(folder), 1) if k == 'file_name' and isinstance(v, str)
                        else rebase(v)) for k, v in value.items()}
        return [rebase(v) for v in value] if isinstance(value, list) else value
    for row in result['stages']:
        name = row['name']
        record = read(folder / name / 'record.json')
        stdout, stderr = (raw(folder / name / part).decode() for part in ['stdout.log', 'stderr.log'])
        need(row['accepted'] is True and row['status'] == record['status'] and record['group_absent'] is True
             and record['finished_ns'] >= record['started_ns'], 'proof process receipt')
        if name.startswith(('positive-', 'negative-')):
            selected = mutations.get(name.removeprefix('negative-'))
            family = selected[1] if selected else None
            staged = folder / (name + '-source')
            need(raw(staged / proof.PROOF) == raw(folder / 'inputs' / proof.PROOF), 'unchanged proof contract')
            need(raw(staged / proof.BODY).decode() == (selected[0] if selected else raw(folder / 'inputs' / proof.BODY).decode()), 'exact shared body or single logical mutant')
            transformed = '\n'.join(json.dumps(rebase(json.loads(line))) for line in stderr.splitlines() if line)
            need(proof.classify(record['status'], stdout, transformed, staged / proof.PROOF, family), 'actual archived diagnostic classifier')
            command = ['/usr/bin/timeout', '--foreground', '--signal=TERM', '--kill-after=5', '120',
                       '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus',
                       '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating',
                       '--output-json', '--error-format=json', '--no-report-long-running',
                       '--num-threads', '1', '--multiple-errors', '1',
                       *(['--verify-function', '*' + proof.FOCI[family][0], '--verify-root'] if family else []),
                       PROOF_ORIGIN + '/' + name + '-source/' + str(proof.PROOF)]
            need(record['command'] == command, 'exact proof command and selected contract')
        elif name.startswith('release-'):
            need(record['status'] == 0 and not stderr and stdout == 'PASS: pinned Verus release closure matched at this measurement (190 files, 129019839 bytes)\n', 'full pinned verifier closure')
            need(record['command'] == ['/bin/sh', str(ROOT / proof.support.CLOSURE),
                 '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f', str(ROOT / proof.support.MANIFEST)], 'exact closure command')
        else:
            need(record['status'] == 0 and not stdout and re.findall(r'^Ran (\d+) tests in [0-9.]+s$', stderr, re.M) == ['7']
                 and stderr.endswith('\nOK\n'), 'seven proof-controller controls')
            need(record['command'][1:] == ['-I', '-B', str(ROOT / proof.TEST)]
                 and Path(record['command'][0]).name.startswith('python3'), 'exact controls command')
    return dict(verified_functions=3, logical_negative_mutants=11, controller_tests=7, stages=16,
                source_files=14, tool_closure_files=190, whole_adapter_verified=False)


def audit_hardware(cpu):
    folder = RAW / 'hardware-01'
    hw = module(folder / 'campaign.py', 'reviewed_hardware_campaign')
    result = read(folder / 'campaign.json')
    need(result['accepted'] is True and result['errors'] == [] and result['expected_cases'] == 28
         and result['owned_cleanup_complete'] is True and result['selected_build_attempt'] == ATTEMPT
         and not result['formal_refinement'] and not result['performance_acceptance'], 'complete hardware campaign')
    need(len(hw.CASES) == 28 and [row['name'] for row in result['completed']] == [row[0] for row in hw.CASES], 'exact reviewed hardware roster')
    need(set(result['binaries']) == {'directed', 'deferred', 'live-sharded'}, 'exact three hardware witnesses')
    def receipt(name, argv):
        stage = folder / name
        row = read(stage / 'result.json')
        need(row['argv'] == argv and row['exit_code'] == 0 and not row['timed_out']
             and row['local_process_group_absent'] is True, 'actual hardware transport receipt: ' + name)
        outputs(stage, row)
        return raw(stage / 'stdout').decode()
    def remote(name, argv, bound='30s'):
        return receipt(name, hw.SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])])
    baseline = json.loads(remote('initial-availability', hw.AVAILABILITY))
    def admission(name):
        state = json.loads(remote(name + '-availability', hw.AVAILABILITY))
        for card, uid, bdf in zip(hw.CARDS, hw.IDS, hw.BD):
            need(state[card]['Unique ID'] == baseline[card]['Unique ID'] == uid
                 and state[card]['PCI Bus'] == baseline[card]['PCI Bus'] == bdf
                 and state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0', 'exact idle admitted GPU')
            for field in ['VRAM Total Memory (B)', 'VRAM Total Used Memory (B)']:
                need(state[card][field] == baseline[card][field], 'unchanged memory baseline')
        need(state['system'] == baseline['system'], 'same PID census')
        mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        records = {}
        for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = match.groups()
            devices = [] if devices is None else devices.split()
            need(int(count) == len(devices) == len(set(devices)) and bool(colon) == bool(devices)
                 and pid not in records and not {card.removeprefix('card') for card in hw.CARDS}.intersection(devices), 'attachment exclusion')
            records[pid] = devices
        need({'PID' + pid for pid in records} == set(state['system']), 'complete mapped PID roster')
        for pid, devices in records.items():
            need(int(state['system']['PID' + pid].split(',')[1]) == len(devices), 'attachment count agreement')
        memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        need(len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024, 'host memory floor')
    admission('baseline')
    first = read(folder / 'initial-availability/result.json')
    baseline_start = read(folder / 'baseline-availability/result.json')['started']
    age = (datetime.fromisoformat(baseline_start) - datetime.fromisoformat(first['finished'])).total_seconds()
    need(0 <= age <= 300, 'fresh initial hardware admission')
    directory = result['owned_directory']
    need(re.fullmatch(r'/tmp/fe2o3-native-peer-subranges-20261002-[A-Za-z0-9]{6}', directory), 'exact owned remote directory')
    need(remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-native-peer-subranges-20261002-XXXXXX']).strip() == directory, 'actual allocated owned directory')
    for kind, binary in result['binaries'].items():
        expected = cpu['witnesses'][kind]['executable']
        need(binary == dict(local=expected['path'], sha256=expected['sha256'], remote=directory + '/' + kind + '-witness'), 'exact uploaded CPU-built witness')
        receipt('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
        for prefix in ['initial', 'final']:
            need(remote(prefix + '-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']], 'remote binary identity')
    for actual, (name, kind, flags, ids) in zip(result['completed'], hw.CASES):
        admission(name)
        argv = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', 'LANG=C.UTF-8', 'LC_ALL=C.UTF-8', result['binaries'][kind]['remote'], *flags, *ids]
        fields = hw.pass_fields(remote(name, argv, '180s'))
        need(not raw(folder / name / 'stderr') and fields == actual['fields'] == hw.expected(kind, flags, ids), 'exact reviewed PASS schema/oracle: ' + name)
        admission(name + '-post')
    paths = [result['binaries'][kind]['remote'] for kind in ['directed', 'deferred', 'live-sharded']]
    tree = ast.parse(raw(folder / 'campaign.py'))
    probes = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == 'probe' for target in node.targets)]
    need(len(probes) == 1, 'one reviewed exact owned process probe')
    probe = ast.literal_eval(probes[0])
    need(json.loads(remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths]))
         == {'owned_executable_pids': []}, 'no owned remote processes')
    remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    admission('final')
    return dict(cases=28, subrange_cases=12, controls=16, owned_cleanup=True,
                oracle='reuses pinned reviewed campaign pure expected(); independently implemented from Rust witness',
                performance_acceptance=False, formal_refinement=False)


def main():
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'python3 -I -B required')
    need(len(sys.argv) == 2 and re.fullmatch(r'audit-[0-9]+\.json', sys.argv[1]), 'fresh audit output name')
    output = RAW / sys.argv[1]
    need(not output.exists(), 'never overwrite an audit')
    result = {'accepted': False, 'error': None, 'baseline': BASE, 'build_attempt': ATTEMPT,
              'controller_sha256': sha(raw(Path(__file__))), 'pins': PINS,
              'executed_builds': 0, 'executed_hardware_commands': 0, 'executed_solvers': 0}
    try:
        for name, digest in PINS.items():
            need(sha(raw(RAW / name)) == digest, 'pinned reviewed input: ' + name)
        result['cpu'] = audit_cpu()
        result['source_controls'] = audit_source_controls()
        result['proof'] = audit_proof()
        result['hardware'] = audit_hardware(result['cpu'])
        result['accepted'] = True
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    with output.open('x') as target:
        json.dump(result, target, indent=2, sort_keys=True)
        target.write('\n')
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
