# Next Increment: Pending Compute Output to a Native Window

Prepared 2026-10-02 from the frozen native-subrange candidate in
`/home/harsh/.codex-tmp/fe2o3-r61-execution`. This is a next-checkpoint plan,
not an acceptance claim for the hardware campaign currently running.

## Bounded Contract

Permit the existing ordinary scalar `peer_copy` to consume a checked subrange
of one pending producer-aware compute output and write an independently checked
window in an already initialized PUBLIC DeviceLocal destination. Keep the
producer's sole source-allocation binding an exact full-allocation `Write`.
Support both existing native queued/eager producers and router-deferred
producers; do not admit partial compute writes, ReadWrite aliases, new kernel
semantics, new directed-compute profiles, or concurrent access to either owner.

No public API, support hook, launch authority or KFD transfer algorithm is needed.
Use `supports_pending_compute_peer_copy_v1`, the existing exact event, ordinary
`peer_copy` ranges, and `Gfx942ComputeXgmiCopyWindowV1`. Production constructors
already accept genuine caller authorities. This work does not supply the missing
compiled semantic/effects evidence provider or turn R57 qualification into
application authority.

## Concrete Source Changes

1. `src/context/peer_custody/compute_peer.rs`: replace the admission and retained
   validation dependency on `full_device_endpoints` with positive, equal-length,
   checked contained DeviceLocal Read/Write regions. Strengthen/retain
   `exact_written_source` so a smaller requested read cannot accidentally admit
   a partial writer: authenticate the original allocation record and one sole
   full-allocation Write binding, then prove it covers the requested source
   window. Do not weaken the selected producer, extra successful controls,
   journal requirement, retained events, rank-before-recursion or terminal
   validation rules.
2. `src/context/versions/producer_readers.rs`: first demonstrate that the existing
   ComputePeer adapter needs no production change. Its single active input
   already retains the exact source offset/length, allocation extent, writer
   reference, attempt/lineage and producer event; its preflight calls
   `producer.covers_input_v1(source)`. Keep the shared journal/planner bodies and
   whole-allocation writer semantics unchanged. Add normal-observation tests
   proving the smaller active read remains tied to the full compute writer.
3. `src/kfd_backend/compute_peer.rs`: admit bounded endpoint windows rather than
   `full_extent`, while preserving all route/PUBLIC/custody/readiness checks.
   Both native and deferred producer branches must compare the original Write
   binding length with the source allocation's full logical length, not the
   copy length. Retain the immutable typed window alongside the existing exact
   producer Arc, endpoint identities, stream and depth. Authenticate it against
   the copy's exact regions on subsequent validation; never inspect/extract the
   active producer's storage to manufacture a ready source.
4. `src/kfd_backend/compute_xgmi.rs` and the call in
   `src/kfd_backend.rs::submit_cooperative_copy`: replace the pending-compute
   plan constructor's synthetic `(bytes, bytes, 0, 0, bytes)` with the admitted
   window containing both real logical lengths and independent offsets.
   Pass this same window into `Root::prepare`; retain the existing exact-window
   checks and typed lower range begin. Keep generic ordinary/directed selectors
   and the full-extent helper's other uses unchanged. Live owner checks and
   transfer errors must stay inside the existing paired poison envelope.

The current relevant boundaries are Context `compute_peer.rs:11,36,102`,
backend `compute_peer.rs:202,248,338`, `compute_xgmi.rs:448`, and
`kfd_backend.rs:9260`. Line numbers are snapshot references, not source pins.

## Invariants That Must Not Move

- Admission retains metadata, exact dependency results, allocation indexes and
  the original charged launch Arc only. No child copy custody, source extraction,
  queue creation, host staging or native counter increment precedes exact producer
  success and restored/quiescent compute ownership.
- Both complete physical owners remain rooted through mapping, every packet,
  queue retirement and both restorations. A smaller window grants no additional
  concurrency. Shadow invalidation and allocation versioning remain conservative
  at whole-allocation granularity.
- Source/destination IDs, children, logical extents, offsets and copy length must
  agree with the same retained window. Checked arithmetic rejects zero, overflow,
  out-of-bounds and packet-count excess before effects.
- Public event release cannot release the producer result or launch debit while
  the peer retains it. Final Context success still requires actual parent
  reconciliation; backend completion alone is not logical success.
- Poll/wait remain observational. Explicit bounded flush/drain services only the
  exact retained producer prefix and necessary authenticated resource blockers;
  recheck child occupancy before native child operations, and never publish an
  unrelated trailing launch.
- Keep pre-effect cancellation, TooLate after physical custody, target-specific
  Quiescent attribution, native error precedence, terminal/unwind quarantine,
  checked depth/capacity and reverse release behavior unchanged. Unsupported
  pending producer profiles must not fall through to an unsafe host read.

## Focused CPU Cases

Use existing Context MockBackend operations and scripted native fixtures, with
their actual scope stated; neither proves GPU arithmetic or payload execution.

- Context pending full Write -> contained peer -> contained D2H: exact bytes from
  real mock operations, released public events, parent observation before child
  commit, unchanged surrounding destination/host bytes and final lease refunds.
- Native queued, eager persistent and deferred producers: unequal logical owner
  lengths, independent nonzero offsets, exact immutable window and original owner
  identities; only final readback stream drives the full retained graph.
- Boundary lengths 1, exact endpoint end, packet cap and cap+tail where fixture
  sizes permit; preserve existing full-extent compatibility and packet resume.
- Reject partial Write, ReadWrite/mixed aliases, wrong/stale event, wrong child,
  uncovered source, zero/overflow/out-of-bounds/mismatched lengths, private or
  uninitialized destination, missing route and exceeded capacities pre-effect.
- Corrupt source/destination offset, logical extent or retained producer/window
  identity before and after publication; require appropriate failstop and rooted
  owners, never a mismatched copy or premature release.
- Cancel before extraction, producer cancel/failure, helper-level Quiescent
  attribution, expired/resumed deadline, Pending observers, native error/unwind,
  retained compute cache retirement, exact event/result/Arc accounting refunds.
- Preserve mixed prefix/occupancy regression: a retained peer -> deferred compute
  -> window peer -> D2H makes progress from the final stream without observing or
  publishing an unrelated child operation.

Do not count table cases as separate test functions or claim scripted packet
completion is native data movement. Reuse the existing lower subrange tests;
no generic IO or proof framework is needed for this runtime profile change.

## Minimal Native Witness

Extend `gfx942-runtime-deferred-peer-chain-smoke` with an optional return-window
mode, preserving the accepted legacy mode and unchanged R57 V2 gates. Its existing
full incoming peer -> deferred full `C+B->D` compute -> ordinary return peer -> D2H
chain already exercises the harder producer origin without adding kernel launches.

- Keep all R57 A/B/C/D allocations, bindings, initialization, exact compute
  geometry and expected arithmetic unchanged (`D` is 262144 bytes).
- Copy `D[20..262100]` (262080 bytes) into an auxiliary initialized allocation
  `E[131..262211]`, where E has 262913 logical bytes. Read back exactly that
  produced interval into `Host[97..262177]`, with Host length 263297. These
  offsets and lengths are byte ranges, not widened kernel bindings.
- Initialize all E bytes and Host bytes with distinct fixed sentinels. Never
  install computed expected D bytes from the host. Build the independent oracle
  from the existing arithmetic reference, then splice only the exact windows.
- Admit the same four roots and release their public events before progress;
  drive only the final D2H stream. Require all four actual success receipts and
  both final native logical-copy completions after owner restoration.
- Validate the complete D allocation, complete E allocation and complete Host
  allocation after settlement, including D's 20-byte prefix/44-byte suffix,
  E's 131-byte prefix/702-byte suffix, and Host's 97-byte prefix/1120-byte suffix.
  Use a length-framed digest covering observed/fully-compared outputs and guards.
- Run both ordered GPU directions plus an unchanged full-extent control, with
  fresh availability checks, exact ELF identity and explicit reverse result/
  allocation/stream cleanup. Preserve the process's original finite authority;
  no same-process authority reset, expected-output upload or hidden host join.

## Acceptance

All focused/new tests, the full runtime suite, prior full/subrange routes,
strict lint/feature/format checks and unchanged source-control predicates must
pass against the same frozen source. The native witness must demonstrate exact
window bytes and every surrounding guard, final-only progress, retained results
after event release, final restored native counters and complete owned cleanup.
Retain negative diagnostic receipts. Update source identities mechanically,
without claiming a new adapter refinement from the existing window arithmetic
proof. No overlap, performance, arbitrary-kernel, eight-device or broader failure
isolation claim follows from this checkpoint.
