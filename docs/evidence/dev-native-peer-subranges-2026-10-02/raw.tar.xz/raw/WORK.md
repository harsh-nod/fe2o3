# Native Peer Subranges

Baseline: bdc9b7b3c000b4b9094b7e4226e6eb198b6d57d6.

Current goal turn follows a completed, signed, dual-remote arithmetic checkpoint.
This increment implements actual independent-offset native peer transfers;
acceptance requires current-source CPU, bounded arithmetic and native evidence.
No acceptance or parity is claimed by this work note.

Root owns Cargo, Git, native execution and the directed-peer example. Lower KFD
is owned by multigpu_host_admission, runtime source by xgmi_integration_review,
and arithmetic proof/CI plus reviewed metadata proposal by xgmi_source_ci.
Preserve foreign docs/evidence/dev-owner-inspection-2026-09-23.
