#!/usr/bin/env bash
set -u
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 1
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=1
receipts=/home/harsh/.codex-tmp/fe2o3-pending-peer-context-20260926-Zs8vYRV4
run() {
    name=$1
    shift
    printf '%s: %s\n' "$name" "$*"
    "$@" >"$receipts/$name.log" 2>&1
    status=$?
    printf '%s exit=%s\n' "$name" "$status" | tee -a "$receipts/results.txt"
    tail -8 "$receipts/$name.log"
}
git rev-parse HEAD >"$receipts/implementation-commit.txt"
git show --format=fuller --binary HEAD >"$receipts/implementation.patch"
git ls-files -z crates/fe2o3-runtime/src crates/fe2o3-runtime-model/verus | xargs -0 sha256sum >"$receipts/source.sha256"
run signature git -c gpg.ssh.allowedSignersFile=docs/evidence/dev-mixed-observers-2026-09-25/raw/allowed-signers verify-commit HEAD
run rustc-version rustc --version --verbose
run cargo-version cargo --version
run focused-final cargo test --offline -p fe2o3-runtime --all-features --lib producer_launch_tests -- --test-threads=1
run runtime-final cargo test --offline -p fe2o3-runtime --all-features --lib -- --test-threads=1
run doctests-final cargo test --offline -p fe2o3-runtime --all-features --doc
run clippy-final cargo clippy --offline -p fe2o3-runtime --all-features --all-targets -- -D warnings
run minimal-final cargo check --offline -p fe2o3-runtime --no-default-features
run fmt-final cargo fmt --all -- --check
run continuity-final sha256sum -c "$receipts/source.sha256"
run whitespace-final git diff --check
run mi300x ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x hostname
run issue-182 gh issue view 182 --repo harsh-nod/fe2o3 --json number,state,title,updatedAt
