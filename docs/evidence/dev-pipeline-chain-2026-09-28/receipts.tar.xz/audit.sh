#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-pipeline-chain-20260928-jwh2qJ5W
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
for label in qualification2 final2-calibration final2-proof final2-runtime-focused \
    final2-runtime final2-clippy final2-no-default final2-format final2-whitespace \
    final2-source-continuity final2-signature native-campaign mutation-diagnostics \
    source-push-origin source-push-upstream source-origin-observed source-upstream-observed; do
    test "$(<"$raw/$label.status")" = 0
done
jq -e 'all(.[]; .passed == true)' "$raw/proof-campaign2/results.json"
cmp "$raw/proof-campaign2/source-before.json" "$raw/proof-campaign2/source-after.json"
cmp "$raw/final2-tree-before.log" "$raw/final2-tree-after.log"
git diff --exit-code 6d55282a7beeb44f11c25725bb287ecab2fab383 -- crates Cargo.toml Cargo.lock rust-toolchain.toml
test "$(<"$raw/native-source.commit")" = 6d55282a7beeb44f11c25725bb287ecab2fab383
test "$(<"$raw/native-remote.status")" = 0
test -s "$raw/native-results/r60-ordinary-pipeline.profile"
test -s "$raw/native-cleaned"
for remote in origin upstream; do
    test "$(cut -f 1 "$raw/source-$remote-observed.log")" = 6d55282a7beeb44f11c25725bb287ecab2fab383
done
printf 'PASS: signed-source, formal, CPU, native, cleanup and both source publications audited\n'
