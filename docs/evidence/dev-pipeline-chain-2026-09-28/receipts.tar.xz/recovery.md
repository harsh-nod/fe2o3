# Qualification Interruption

The environment changed from restricted filesystem/network access to unrestricted
access while qualification session 18674 was running. On continuation, the tool
reported `Unknown process id 18674`. An authoritative process listing contained
no cargo, Rust compiler, Verus, runtime test binary or qualification controller.
The first full runtime log is incomplete and has no exit-status receipt. It is
not counted as a completed suite. Existing partial files are retained unchanged.

The completed first proof campaign on signed source 19de214 stopped at the
promotion-ignores-stage mutant. Its genuine precondition diagnostic included a
relative vstd/std_specs/option.rs span, which the pinned classifier rejects. The
classifier allows precondition failures but requires absolute source spans. The
revised mutant preserves staged refusal for live==0 and breaks it for positive
live counts, isolating staged admission without introducing a subtraction panic.
Neither the production body nor the proof nor the classifier is weakened.

Qualification2 repeats all phases on a new signed source revision. The initial
synthetic calibration ran during formatting; it is preparatory evidence only.
Final qualification runs are serialized.
