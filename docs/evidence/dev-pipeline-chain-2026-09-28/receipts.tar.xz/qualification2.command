bash /home/harsh/.codex-tmp/fe2o3-pipeline-chain-20260928-jwh2qJ5W/qualification2.sh 
