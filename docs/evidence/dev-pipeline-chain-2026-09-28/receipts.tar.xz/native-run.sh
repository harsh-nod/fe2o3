#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-pipeline-chain-20260928-jwh2qJ5W
cd /home/harsh/.codex-tmp/fe2o3-r61-execution
test "$(git rev-parse HEAD)" = 6d55282a7beeb44f11c25725bb287ecab2fab383
test ! -e "$raw/native-results"
git diff --exit-code HEAD -- crates Cargo.toml Cargo.lock rust-toolchain.toml
git archive --format=tar HEAD Cargo.toml Cargo.lock rust-toolchain.toml crates examples > "$raw/native-source.tar"
sha256sum "$raw/native-source.tar" > "$raw/native-source.sha256"
git get-tar-commit-id < "$raw/native-source.tar" > "$raw/native-source.commit"
task=$(ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x 'mktemp -d /home/harsh/.codex-tmp/fe2o3-pipeline-chain-20260928.XXXXXXXX')
case "$task" in /home/harsh/.codex-tmp/fe2o3-pipeline-chain-20260928.????????) ;; *) exit 2;; esac
printf '%s\n' "$task" > "$raw/native-task-path"
scp -q "$raw/native-source.tar" "mi300x:$task/source.tar"
scp -q "$raw/native-remote.sh" "mi300x:$task/run.sh"
status=0
ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x "cd '$task' && bash run.sh '$task'" || status=$?
printf '%s\n' "$status" > "$raw/native-remote.status"
scp -q -r "mi300x:$task/results" "$raw/native-results"
test "$(cut -d ' ' -f 1 "$raw/native-source.sha256")" = "$(cut -d ' ' -f 1 "$raw/native-results/source.sha256")"
ssh -o BatchMode=yes -o ConnectTimeout=10 mi300x "rm -rf -- '$task' && test ! -e '$task'"
date -u +%FT%TZ > "$raw/native-cleaned"
exit "$status"
