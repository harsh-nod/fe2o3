#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
task=$1
test "$(pwd)" = "$task"
mkdir results src
date -u +%FT%TZ > results/started
sha256sum source.tar > results/source.sha256
tar -xf source.tar -C src
export PATH="$HOME/.cargo/bin:$PATH"
export RUSTUP_TOOLCHAIN=nightly-2026-04-03
export CARGO_TARGET_DIR="$task/target" CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS
cd src
rustc -Vv > ../results/rustc.txt
cargo -Vv > ../results/cargo.txt
run() {
    local label=$1
    shift
    printf '%q ' "$@" > "../results/$label.command"
    printf '\n' >> "../results/$label.command"
    date -u +%FT%TZ > "../results/$label.started"
    local status=0
    "$@" > "../results/$label.log" 2>&1 || status=$?
    printf '%s\n' "$status" > "../results/$label.status"
    date -u +%FT%TZ > "../results/$label.finished"
    cat "../results/$label.log"
    return "$status"
}
run build timeout --signal=TERM --kill-after=10 900 cargo build --locked --offline \
    -p fe2o3-runtime --features hardware-qualification --example gfx942-runtime-r60-ordinary-pipeline
binary="$CARGO_TARGET_DIR/debug/examples/gfx942-runtime-r60-ordinary-pipeline"
sha256sum "$binary" > ../results/binary.sha256
readelf -d "$binary" > ../results/dynamic.txt
/opt/rocm/bin/rocm-smi --showuse --showmemuse --showuniqueid --showpids --json > ../results/gpu-before.json
python3 -c 'import json,sys; d=json.load(sys.stdin)["card1"]; assert d["Unique ID"]=="0xab83d2ffef0d3cdf"; assert d["GPU use (%)"]=="0"; assert d["GPU Memory Allocated (VRAM%)"]=="0"' < ../results/gpu-before.json
run qualify timeout --signal=TERM --kill-after=10 120 "$binary" 0xab83d2ffef0d3cdf qualify "$task/results/r60-ordinary-pipeline.profile"
/opt/rocm/bin/rocm-smi --showuse --showmemuse --showuniqueid --showpids --json > ../results/gpu-after.json
date -u +%FT%TZ > ../results/finished
