timeout --signal=TERM --kill-after=10 900 cargo build --locked --offline -p fe2o3-runtime --features hardware-qualification --example gfx942-runtime-r60-ordinary-pipeline 
