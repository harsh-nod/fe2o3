"""Diagnostic only; the full owned campaign remains authoritative."""
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
RAW = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('probe_check', ROOT / 'crates/fe2o3-verifier/verus/checked_u32_prefix_check.py')
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)
sources = check.snapshot()
out = RAW / 'kernel-probes-01'
out.mkdir()
for name, (changed, target, failure) in check.kernel_mutants(sources[str(check.KERNEL_BODY)].decode()).items():
    folder = out / name
    for path in (check.PROOF, check.BODY, check.BASIS_BODY, check.NORMALIZE_BODY, check.ASSEMBLE_BODY, check.KERNEL_PROOF, check.KERNEL_BODY, check.base.BODY):
        destination = folder / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(changed.encode() if path == check.KERNEL_BODY else sources[str(path)])
    command = ['timeout', '--kill-after=5s', '120s', '/home/harsh/.local/opt/verus-0.2026.08.09.92f466f/verus',
               '--crate-type', 'lib', '--triggers-mode', 'silent', '--no-cheating', '--output-json',
               '--error-format=json', '--no-report-long-running', '--num-threads', '1', '--multiple-errors', '1',
               '--verify-function', '*' + check.TARGETS[target]['function'], '--verify-only-module', 'kernel_assembly', str(folder / check.PROOF)]
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    (folder / 'stdout').write_text(result.stdout)
    (folder / 'stderr').write_text(result.stderr)
    (folder / 'command.json').write_text(json.dumps(dict(command=command, status=result.returncode), indent=2))
    accepted = check.classify(result.returncode, result.stdout, result.stderr, folder / check.PROOF, target, failure)
    print(json.dumps(dict(name=name, classified=accepted, result=json.loads(result.stdout).get('verification-results'),
                         diagnostics=[json.loads(line)['message'] for line in result.stderr.splitlines()])), flush=True)
