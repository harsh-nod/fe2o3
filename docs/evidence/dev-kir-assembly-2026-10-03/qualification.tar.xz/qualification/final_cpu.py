"""Run the bounded final CPU cohort serially; stop on the first failed receipt."""
from pathlib import Path
import shlex
import subprocess
import sys

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
CARGO = 'cargo +nightly-2026-04-03 '
VERIFIER = '--locked --offline -p fe2o3-verifier --all-features '
COMMANDS = {
    'verifier-03': CARGO + 'test ' + VERIFIER + '--lib --test gfx942_local_checked_u32_add_v1',
    'docs-03': CARGO + 'test ' + VERIFIER + '--doc',
    'clippy-library-03': CARGO + 'clippy ' + VERIFIER + '--lib -- -D warnings',
    'no-default-03': CARGO + 'check --locked --offline -p fe2o3-verifier --no-default-features --lib',
    'format-03': 'rustfmt +nightly-2026-04-03 --check --edition 2024 --config skip_children=true ' + ' '.join(
        'crates/fe2o3-verifier/src/gfx942_local_checked_u32_add_v1/' + path for path in (
            'source_prefix.rs', 'source_prefix/assemble.rs', 'source_prefix/assemble_body.rs', 'source_prefix/fold.rs',
            'source_prefix/tests.rs', 'source_prefix/tests/assembly.rs', 'source_prefix/kernel.rs',
            'source_prefix/kernel_body.rs', 'source_prefix/tests/kernel.rs')),
    'ci-dispatch-03': 'bash scripts/tests/ci-local-test-gate.sh',
    'shell-syntax-03': 'bash -n crates/fe2o3-verifier/verus/run-checked-u32-prefix.sh',
    'diff-check-03': 'git diff --check',
    'artifacts-verifier-03': CARGO + 'test ' + VERIFIER + '--lib --test gfx942_local_checked_u32_add_v1 --no-run --message-format=json',
    'roster-verifier-03': CARGO + 'test ' + VERIFIER + '--lib --test gfx942_local_checked_u32_add_v1 -- --list',
    'artifacts-extraction-03': CARGO + 'test --locked --offline -p rustc-codegen-fe2o3 --test production_extraction_driver_v1 --no-run --message-format=json',
    'extraction-03': CARGO + 'test --locked --offline -p rustc-codegen-fe2o3 --test production_extraction_driver_v1 checked_u32_prefix_extraction_v1::genuine_checked_u32_prefix_extraction_uses_actual_sources_and_rejects_unsupported_profiles -- --ignored --exact --nocapture --test-threads=1',
}

if __name__ == '__main__':
    for label, command in COMMANDS.items():
        subprocess.run([sys.executable, '-I', '-B', str(RAW / 'capture.py'), label, '1200s',
                        *shlex.split(command)], cwd=ROOT, check=True)
