"""Seal replay-audited records and the staged candidate source patch."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
OUT = ROOT / 'docs/evidence/dev-kir-assembly-2026-10-03'
assert json.loads((RAW / 'audit-report.json').read_text())['accepted'] is True
patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', '--', 'crates', '.github'], cwd=ROOT)
assert patch and b'kernel_body.rs' in patch and b'checked_u32_kernel_schema.py' in patch
(RAW / 'candidate-source.patch').write_bytes(patch)
manifest = {str(path.relative_to(RAW)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(RAW.rglob('*')) if path.is_file() and path.name != 'MANIFEST.json'}
(RAW / 'MANIFEST.json').write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
archive = OUT / 'qualification.tar.xz'
assert not archive.exists()
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for path in sorted(RAW.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            tar.add(path, arcname='qualification/' + str(path.relative_to(RAW)), recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    members = tar.getmembers()
    assert len(members) == len(manifest) + 1
    for member in members:
        name = member.name.removeprefix('qualification/')
        if name != 'MANIFEST.json':
            assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == manifest[name]
(OUT / 'SHA256SUMS').write_text(''.join(
    hashlib.sha256((OUT / name).read_bytes()).hexdigest() + '  ' + name + '\n'
    for name in ('README.md', 'qualification.tar.xz')))
print(json.dumps(dict(archive=str(archive), bytes=archive.stat().st_size, files=len(manifest))))
