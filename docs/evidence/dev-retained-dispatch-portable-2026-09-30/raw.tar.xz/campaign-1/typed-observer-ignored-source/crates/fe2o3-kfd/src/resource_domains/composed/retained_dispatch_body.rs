macro_rules! composed_retained_credit_dispatch_body_v1 {
    ($this:ident, $credit:ident, $bytes:ident) => {{
        Arc::ptr_eq(&$this.0, &$credit.account.0)
            && { let _ = $bytes; true }
    }};
}
