#!/usr/bin/env bash
set -uo pipefail
ulimit -c 0
cd /home/harsh/.codex-tmp/fe2o3-r61-execution || exit 2
raw=/home/harsh/.codex-tmp/fe2o3-native-publication-cell-20260928-JrwXrxpI
expected=ccc0bd278a0bc0aca1868d528edff336ff211b0f
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
failed=0
run() {
    bash "$raw/run.sh" "$@" || failed=1
}
test "$(git rev-parse HEAD)" = "$expected" || exit 2
git diff --quiet HEAD -- crates tools Cargo.toml Cargo.lock || exit 2
run qualified-source git show -s --format=fuller HEAD
run qualified-tree git rev-parse 'HEAD^{tree}'
run qualified-rustc rustc -Vv
run qualified-cargo cargo -V
run qualified-cell cargo test -p fe2o3-kfd --all-features --lib runtime_publication_cell_ -- --test-threads=1
run qualified-kfd cargo test -p fe2o3-kfd --all-features --lib -- --test-threads=1
run qualified-materialized cargo test -p fe2o3-runtime --all-features --lib materialized_ -- --test-threads=1
run qualified-runtime cargo test -p fe2o3-runtime --all-features --lib -- --test-threads=1
run qualified-clippy cargo clippy -p fe2o3-runtime -p fe2o3-kfd --all-features --all-targets -- -D warnings
run qualified-no-default cargo check -p fe2o3-runtime -p fe2o3-kfd --no-default-features
run qualified-format cargo fmt --all -- --check
run qualified-mutations bash "$raw/check-mutations.sh"
run qualified-source-continuity git diff --exit-code "$expected" -- crates tools Cargo.toml Cargo.lock
test "$(git rev-parse HEAD)" = "$expected" || failed=1
exit "$failed"
