#!/usr/bin/env bash
set -euo pipefail
raw=/home/harsh/.codex-tmp/fe2o3-native-publication-cell-20260928-JrwXrxpI
prefix='test queue::live::tests::runtime_publication_tests::'
check() {
    local name=$1 passed=$2 failed=$3
    test "$(<"$raw/$name.status")" = 101
    rg -Fq 'Finished `test` profile' "$raw/$name.log"
    rg -xq 'running 6 tests' "$raw/$name.log"
    rg -Fq "test result: FAILED. $passed passed; $failed failed; 0 ignored; 0 measured; 1698 filtered out;" "$raw/$name.log"
}
failed_test() {
    rg -Fxq "$prefix$2 ... FAILED" "$raw/$1.log"
}
check mutant-missing-marker 3 3
failed_test mutant-missing-marker runtime_publication_cell_rejection_is_not_a_retry
failed_test mutant-missing-marker runtime_publication_cell_typed_terminal_retains_consuming_state
failed_test mutant-missing-marker runtime_publication_cell_unwind_preserves_exact_returned_or_consuming_state
rg -Fq 'assertion failed: matches!(cell, Attempt::NativeOwned)' "$raw/mutant-missing-marker.log"
check mutant-rejection-retry 5 1
failed_test mutant-rejection-retry runtime_publication_cell_rejection_is_not_a_retry
rg -Fq 'called `Result::unwrap_err()` on an `Ok` value: ()' "$raw/mutant-rejection-retry.log"
check mutant-drop-outcome 3 3
failed_test mutant-drop-outcome runtime_publication_cell_retains_real_batches_through_out_of_order_recycle
failed_test mutant-drop-outcome runtime_publication_cell_signal_capacity_retry_preserves_custody_then_reuses
failed_test mutant-drop-outcome runtime_publication_cell_unwind_preserves_exact_returned_or_consuming_state
rg -Fq 'assertion failed: matches!(cell, Attempt::Published(_))' "$raw/mutant-drop-outcome.log"
rg -Fq 'assertion failed: matches!(cell, Attempt::Retryable)' "$raw/mutant-drop-outcome.log"
for name in restored-after-marker restored-after-rejection restored-after-outcome; do
    test "$(<"$raw/$name.status")" = 0
    test ! -s "$raw/$name.log"
done
test "$(<"$raw/qualified-cell.status")" = 0
rg -Fq 'test result: ok. 6 passed; 0 failed; 0 ignored;' "$raw/qualified-cell.log"
printf '%s\n' 'PASS: three compiled behavioral mutations and restored six-test baseline'
