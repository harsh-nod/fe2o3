git diff --exit-code ccc0bd278a0bc0aca1868d528edff336ff211b0f -- crates tools Cargo.toml Cargo.lock 
