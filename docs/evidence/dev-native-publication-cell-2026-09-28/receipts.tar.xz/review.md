# Shared Native Publication Receipt Cell

Source commit: ccc0bd278a0bc0aca1868d528edff336ff211b0f.
Source tree: 2845c25cb5637e5dbae1b88dca8a430ff411ac7c.

## Implementation

The runtime's concrete MaterializedSubmissionAttemptV1 enum and consuming/store
body now live in a private source file. The existing runtime path reexports the
type, and both native call sites use its closure-taking submit_classified API
inside with_compute_lane_v1. Initial binding and Prepared retry already share
one of those call sites; the other is ordered-successor publication. The closure
boundary ensures NativeOwned is installed before the lower call is evaluated.
Only RetryableBeforeSideEffect is stored as Retryable; rejection and terminal
failure preserve consuming state and propagate unchanged. Successful batches
are stored before the native lane callback closes.

The existing KFD private-to-public three-way failure conversion was extracted
without changing classification or poison behavior. Both the public facade and
the new fixture call paths use that production conversion. No mapping is copied
into tests. No public receipt constructor, Cargo dependency or production
compatibility path was added. KFD's tests compile the exact private runtime source
in the repository checkout; KFD remains publish=false.

## Review and Test Scope

The primary made all edits and ran serialized commands. Two read-only native
agents reviewed semantics and test oracles. They found no blocking ownership or
oracle issue. They did not request permissions, edit source, execute builds/tests,
or invoke external Qwen workers. Review is not formal proof.

Six registered groups include fourteen lane/outcome workflows plus source-wiring
smoke checks. Primary and AUX each exercise three actual typed batches followed
by out-of-order CPU completion/recycle, full-signal retry and successful reuse,
actual public no-dispatch rejection, typed lower terminal failure, and three
unwind states: Published deposited before unwind, Retryable returned before
unwind, and NativeOwned during an injected native-callback unwind.

The lower fixtures wrap production dispatch-generation ownership and use the
production completion arena, classification and typed batch/receipt types. Their
native submission callback and completion observations are injected. These are
not GPU execution, native completion-load, code/kernarg/memory authority, or
full runtime Active/Pending handoff tests. Existing runtime scripts remain a
separate qualification of indexed slots, FIFO and retain accounting.

Successful controls explicitly recycle all test receipts, including the arena
filler. Terminal and unwind controls do not clear poison or call CPU recycle
helpers to simulate native recovery. Fixtures have no device resources; their
Drop or failed destroy is not healthy native teardown evidence. AUX unwind
restores both lanes before poisoning the restored primary owner; tests do not
incorrectly require the AUX completion owner itself to be poisoned in that case.
Custody snapshots cover slot records, identity, counters and backing pointers,
not complete dependency-ledger contents.

The source-wiring group checks use of the shared classifier, not callback
placement or a Rust-to-Verus refinement. Both call sites were also read directly.

## Preliminary Corrections

Initial formatting refused the test module path: this source's inline tests
resolve under src/tests, not src/queue_live/tests. The file and include paths
were corrected, then formatting, all six focused tests and strict runtime+KFD
all-feature/all-target Clippy passed. No production guard was relaxed.

Local scratch space was low. Only this task's preceding runtime test executable
target/debug/deps/fe2o3_runtime-e03b9552edb097b6 was removed before rebuilding;
its committed source and prior frozen evidence were preserved. No unrelated
worktree changes or user files were removed.

## Compiled Mutations

Three deliberate mutations target the shared production cell, not a duplicate
model: omit the pre-call consuming marker; misclassify rejection as retry; and
discard the returned outcome. Exact diffs, compile/test logs, statuses and
restoration checks are retained. Accept a mutation result only after successful
compilation and the expected named behavioral assertion failures. Aborts,
timeouts, compile errors or unrelated failures are not accepted mutation kills.
Loops stop at the first failure, generally on primary; this is not separate
mutant-specific AUX qualification. The final unchanged source must pass the
focused selection after all mutations are restored.

## Remaining Scope

This closes the isolated shared submission receipt-cell coupling gap, not the
entire runtime/native composition. Completion consume/restore and exact indexed
target association remain separate work. A recycled observation contains only
packet-count metadata; identity follows consuming/returning custody and lower
checks, not a fabricated generation-bound observation.

Next implement production-shared decisions/refinement for staged identity,
confirmation/withdrawal, Pending handoff and contiguous commit. R60's historical
independent proof lacks physical staging, returned-state versus outer-close
failure, explicit/deferred retain distinctions, optional profiling after commit,
and the 1024-slot development capacity. Preserve its historical claim rather
than treating it as source correspondence. No new formal campaign, hardware
execution, native cleanup, allocation/latency benchmark or matched HIP/HSA
measurement is established by this packet. Protected Worker, Context composition,
multi-device/resource closure and A0-A7 acceptance remain open/unchanged.

MI300X SSH again failed name resolution before connection. No remote resources
were created. No permissions or escalation were requested.

## Implementation-Ready Next Work

The final read-only design review favors a real shared completion Receipt enum
over a test-only lookalike of the large Active enum. Published, Completed, Retired
and Consuming(Poll/Recycle) can replace four real Active variants with one
Materialized(Receipt) variant. The reviewer identified eleven production edit
sites across seven existing files, plus four direct test references. Critical
migration checks: Materialized(_) must no longer imply Published; ordered
eligibility/native-depth must explicitly select Receipt::Published, and Consuming
must never map to a completion phase. Guard the input phase before replacing it,
store returned receipts immediately, and leave phase/timing, exact target lookup,
outer-close handling, accounting and commit in the indexed adapter.

KFD's private NativeCompletionSignalBackendV1 and production completion-owner
observe_once_with_progress/recycle_retaining can support Pending/Ready,
currentness, real pin refusal and reset-error controls. Existing direct CPU
complete/recycle helpers only cover their narrower fixture behavior. Do not
label an injected classified failure as actual pin detection. Preserve exact
lower occurrence checks and keep receipt constructors private.

The follow-up review rejects a staged-metadata proof fed trusted booleans such
as frontier_valid or metadata_intact: that would leave the interesting roster
obligations outside the shared source. Instead share the complete entry lookup,
frontier scan, stage validation and vacant-slot selection, staged-integrity scan,
and stage/confirm/withdraw mutations. Operate on the actual borrowed slot slice
and scalar head fields, without copied rosters or runtime allocation. Existing
completion reconciliation and selected-reader proofs provide indexed loop and
opaque generic payload precedents; solver performance remains untested.

Prove exact scan characterization and selected-slot frame conditions. Rejection
preserves the table, heads and exact returned Active. Stage changes physical
generation and occupancy but preserves next logical epoch; confirm advances it
once with checked overflow; withdrawal preserves epoch/frontier and the burned
physical generation while returning the exact payload. Restaging cannot reuse
the withdrawn physical identity. Cover both capacity profiles and exhaustion.
Keep native-outcome authorization and the opaque Active projection explicit as
remaining adapter boundaries. Existing finish checks do not revalidate every
older entry's phase/identity: distinguish guard characterization from invariant
preservation on a well-formed roster. Mutate the shared scan predicates and
mutation assignments, plus callers that bypass the shared body or withdraw after
unknown submission. No such new proof is claimed by this packet.

For completion tests, use the private signal backend's default currentness
envelope. Construct a genuine event pin by bind_batch, recording the bound event,
mark_published, then binding the dependency event to that completion batch.
After actual observe_once_with_progress returns Ready, recycle_retaining must
return SignalPinned and the exact Completed receipt before any currentness or
reset call. Release the event on the same lane and retry: exactly one slot
generation increment and drained dispatch/dependency ledgers are required.
Opening-currentness, reset and closing-currentness errors must separately retain
Consuming custody, never counterfeit retry authority. This is still test-only
occurrence plumbing, not execution of the full Linux native facade. Ordinary
observe_once_with_progress allocates slot_indices and its batch backend returns
a Vec; receipt-state sharing would not establish allocation-free lower polling.

Direct source inspection also found a published-batch destructure in
kfd_backend/retained_release_tests.rs in addition to the previously listed
mixed_duration.rs test. Migration must audit all Materialized patterns again,
not rely on the earlier edit-site count.

## Source Publication

Both source pushes (origin and upstream, HEAD ccc0bd278) failed with exit 128:
github.com could not be resolved. No successful synchronization is claimed.
Both were retried after qualification with the same result. The final MI300X
connection retry returned 255 before connection because sharkmi300x-1 could not
be resolved. No remote jobs or files were created, and no permissions or
escalation were requested.

## Qualification Cost Review

The prior full KFD log in dev-three-native-recovery records 3630.30 seconds,
1687 passes and one socket-admission failure. It and this campaign's harness lack
per-test timings. The following are source-inspection candidates, not profiled
attribution, runtime latency results or justification to skip fault cases.

Each fresh constructed primary fixture allocates and zeroes the real
0xb167000-byte gfx942 context (about 177.4 MiB). Its complete zero check already
uses allocation-free 4096-byte comparisons, including the final remainder, with
an existing every-byte corruption differential test. No new byte-loop fix is
needed there. The shared-memory FakeBackend unmap also clones the entire mapping
into last_unmapped_bytes. Measure whether explicitly opt-in content capture can
retain all cleanup/order/pointer and failure oracles without repeatedly copying
large context storage. Do not change production native memory semantics.

The immutable fixture recipe also validates the same HSACO three times per
construction. A test-only cached validated envelope might retain real validation
while producing fresh ABI-reconciled descriptors; arbitrary-image/corruption
tests must remain uncached. No full-context cryptographic signing/hash was found:
CWSR handling checks eight small headers and shadow pages, while sealing checks
currentness/protection. Whole-model scans already remain at certificate mint and
final restoration; ordinary authentication and memory transitions are local.

After frozen qualification, time the healthy six-construction group, borrowed
preflight failure matrix and release matrix separately. Attribute setup, context
initialization/check, admission and teardown capture before choosing an edit.
Reuse a parent only across proved no-effect and exactly restored preflight cases;
never clone live owners, reset poison or reuse terminal custody. This read-only
review changed no tests, production checks or implementation source.

## Final Qualification

The original serialized process terminated with aggregate exit 1. It was polled
to completion without restarting for slow output. Shared receipt-cell tests:
6 passed. Full KFD: 1703 passed, 1 failed, 0 ignored, harness time 3751.08 seconds.
Materialized selection: 35 passed. Full runtime: 1794 passed, 3 failed, 28 ignored,
harness time 193.08 seconds. The backend subset parsed from that full runtime log
is 925 registered, 897 passed, 0 failed, 28 ignored, no unresolved results; this
is not a separate test invocation. Selections overlap and must not be summed.

KFD's failure is target_debug_telemetry_v2::tests::
credential_bound_channel_accepts_typed_failure_before_publication at line 1173,
SocketAdmission. Runtime's three failures are authorized_execution::tests::
cooperative_debug_telemetry_emits_only_bounded_logical_records,
failed_session_end_is_explicit_and_terminal, and
pre_native_telemetry_failure_is_returned_and_poisoned. All fail at
authorized_execution.rs:1317 with InspectSocket(PermissionDenied), OS error 1.
These match prior recorded boundaries; none is waived, skipped or bypassed.

Strict runtime+KFD all-feature/all-target Clippy, no-default-feature checking,
workspace formatting, compiled-mutation receipt audit and final source
continuity all returned 0. Source remained ccc0bd278 throughout. No runtime-model,
Verus, doctest, profiler-protocol, native GPU or matched-performance campaign ran.
The debug suite times cannot establish device-runtime performance or parity.

The final read-only evidence review found no blocking claim or extraction
regression. This is development evidence, not native acceptance or formal
correspondence. Freeze this raw directory only after all final receipts and review
notes are complete; do not append documentation-commit push output after freeze.
