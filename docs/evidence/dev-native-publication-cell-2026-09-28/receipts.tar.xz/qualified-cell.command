cargo test -p fe2o3-kfd --all-features --lib runtime_publication_cell_ -- --test-threads=1 
