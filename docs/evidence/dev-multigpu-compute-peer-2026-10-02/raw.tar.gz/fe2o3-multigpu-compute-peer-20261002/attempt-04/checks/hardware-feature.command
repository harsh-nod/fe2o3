cargo +nightly-2026-04-03 check --locked --offline -p fe2o3-runtime --no-default-features --features hardware-qualification --lib --example gfx942-runtime-sharded-vecadd-capture-smoke 
