# Prequeued Compute / Peer / Readback Witness

Implementation contract for
`crates/fe2o3-runtime/examples/gfx942-runtime-sharded-vecadd-capture-smoke.rs`.
This note is not an execution or qualification receipt.

## CLI and Unchanged Authority

Joined default, unchanged:

`gfx942-runtime-sharded-vecadd-capture-smoke --round <0|1> <UID> <UID> ...`

Opt-in queued mode:

`gfx942-runtime-sharded-vecadd-capture-smoke --queued-compute --round <0|1> <UID> <UID> ...`

The optional flag must be first and occur once. Both modes accept the same
ordered 2..8 distinct nonzero explicit hexadecimal UIDs and exactly round 0 or
1. One fresh process and Context per round remain required. Neither mode changes
the 70-recipe finite qualification policy, source/object bytes, kernel authority,
65,537-element total, per-shard logical lengths, page-sized full bindings,
geometry, initial input/padding patterns, or output oracle.

Setup still completes all 4N full uploads before reverse-order result release.
The initial A/B/C device owners remain H2dReady: no device readback normalizes
them before exact authorization. Incoming peer sentinels are fully read back.
No host upload contains computed expected output.

## Queued Mode Ordering

1. Submit all N typed kernels using `launch_producer_aware_v1` with empty
   dependencies. Install each exact completion callback and record its compute
   event. Admission may eagerly publish compute; no all-pending or no-native-
   effects assertion is made about compute.
2. Do not explicitly flush, poll, wait, join, or release these compute results.
   Admit every full-buffer `C_i -> incoming_(i+1)` peer copy with its source's
   exact compute event. Install each peer callback and record its event.
3. Release the public compute events only after their peer consumers have been
   admitted. Admit every same-child D2H readback using the corresponding exact
   peer event; install each readback callback. Release the public peer events
   only after readback admission. Context/backend roots retain dependencies.
4. Check only that all N peers and N readbacks are logically Pending, and the
   completed native-copy counter is zero. No separate compute observation is
   introduced. Transfer observation may reconcile dependency state according to
   the adapter contract; it is not permission to claim that compute has not run.
5. Move the same Context into the existing current-thread owner, register only
   the N readback streams, and begin the one final group-capture cutoff before
   the first owner drive. Dependent stream progress must service the retained
   compute -> peer -> readback chain. No compute-stream registration or manual
   compute join substitutes for that behavior.
6. Retain all 3N logical submissions through drain. Require the drain's exact
   retained counts to be total=3N, succeeded=3N, with no Pending/Failed/Unknown
   result, and separately require all 3N original callbacks exactly once with
   their original IDs and Succeeded. Quiescence alone is insufficient.
7. Preserve one absolute 30-second owner deadline, the 30,000-tick limit,
   aggregate capture credit checks, full gathered byte/padding validation,
   independent global digest, and explicit successful owned shutdown.

Joined mode continues to join and release its N compute submissions before
peer admission, requires exactly 2N transfer results during drain, and checks
its original N compute callbacks before admitting peers.

## PASS Schemas

The joined default keeps its exact existing 45-key output, including
`schema=fe2o3.sharded-vecadd-capture-smoke.v1`,
`compute_admission=all-before-explicit-progress`, and
`compute_join=exact-succeeded-restored`.

Queued output has the same common fields with only these substitutions:

- `schema=fe2o3.sharded-vecadd-queued-capture-smoke.v1`
- `compute_admission=may-publish-before-cutoff`
- `compute_join=owned-drain`

Queued output appends four additional fields, for 49 total:

- `compute_api=producer-aware`
- `compute_dependency=exact-event`
- `compute_progress=dependent-readback-streams`
- `retained_submissions=3N` (the decimal integer, not the expression)

Both modes report N launches, N compute receipts, 2N transfer receipts, and 3N
total completion receipts. `admission=all-transfers-pending-before-cutoff`
deliberately refers only to transfers. Public events are released before cutoff.
The same global digest is required regardless of count, order, or mode:

- Round 0: `d394636ce117fedd8452e72f433c276198314fa52eb1c464449a894505a4103c`
- Round 1: `297de3086d3bd8894cf3c46925e48b5e6e1d3a16f183c6682ea96f4f3772b866`

The independent reference is SHA-256 over little-endian f32 values
`g + 3 + 131073*round` for every `g` from 0 through 65,536. Logical bytes stay
262,148; full capture includes every padded shard in source-global order.
Per-shard records are `offset:elements:padded_bytes`. Existing limits remain
explicit: final native counter and post-copy source preservation are unobserved;
allocation reuse, measured overlap, performance acceptance, and formal machine
refinement are not claimed.

## Focused Local Tests

The prior eight tests remain, with joined mode explicit in the parser assertion.
Three new tests cover only pure CLI/report/receipt behavior, not GPU execution:

- `queued_compute_is_an_explicit_leading_mode_with_unchanged_round_and_uid_validation`
- `mode_report_preserves_joined_schema_and_marks_all_queued_compute_custody`
- `receipt_validation_requires_each_exact_id_once_and_success_not_quiescence`

The receipt test uses generic test IDs rather than forging runtime submission
identities. No mock GPU output is installed by these additions. Actual queued
dependency/ownership execution belongs to the adapter CPU tests and the primary
agent's separately recorded hardware campaign.
