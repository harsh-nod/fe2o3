# Next Multi-GPU Increment

This is a design, not implementation or qualification evidence.

Reuse one live Context, owner, module/kernel, allocation set and stream set for
two changed-content compute -> native peer -> D2H batches before one final drain.
Do not reopen a physical device or reset process-lifetime ACQUIRE_VM admission.

Add a separate qualification-only two-phase authority and fixture, leaving the
existing one-shot policy unchanged. Authenticate each complete recipe and latch
exact A/B/C allocation IDs atomically with First -> Second -> Exhausted. Rejected
authorization does not consume a phase; accepted authorization never resets on
failure or uncertain completion. Add narrow dispatch/constructor/export hooks.
No Context, journal or scheduler API change is currently expected.

For each batch, refresh the entire padded A/B/C and incoming sentinel allocations
through explicitly progressed uploads. Preserve native input digests until
authorization. Admit all compute/peer/readback chains within one bounded
enqueue_with_context command before scheduler flushing. Retain registration
guards for readback-stream progress; drop completed acknowledgment futures to
refund reply credits. Keep the same outer future across deadline expiry.

Poll the original readbacks to actual success, reconcile all ancestors, then
read settled HostVisible outputs in one explicitly byte-bounded Context command.
Discard any partial snapshot on error. Release D2H -> peer -> compute results,
reversing same-stream predecessors, before refreshing batch two. Do not begin
drain between batches. Final shutdown occurs only once.

Test phase/identity/replay/concurrency rejection, non-consuming rejection,
deadline resumption, stale events, premature mutation/release, bounded partial
snapshot failure and complete cleanup. Scripted tests establish custody, not
GPU arithmetic. Hardware must check both changed outputs and all padding, 6N
exact pipeline callbacks, stable handles, native count 0 -> N -> 2N and cleanup
inside one process. No overlap, benchmark or formal-refinement claim follows.
