#!/usr/bin/env python3
"""Fail-closed final audit for queued compute -> native peer -> captured D2H.

Acceptance requires every selected CPU, source and hardware receipt to validate.
This file does not invoke Cargo, SSH, GPU work or proofs.
"""
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
BASE = 'f0eaff8efc2cd53e4f8da4e12a56881a74537ca9'
CONTROLLER_SHA = '1cbedc5de9e0d53d3b915d1e2925622f5358c2ae70de324401afb19439ff4923'
SUPPORT_SHA = 'b2d8867561131e5cc1dc4e294a0bc08972fdd57e21802cb220aee630797db2f0'
PROPOSER_SHA = '216e5c0ffee958caf2e7bd8a7025f7d6a7f0cf4f89c75ec73c9edc17a19362d8'
WORKFLOW_SHA = '33c8eb8b3bac347669f15e36aadbc736062a635812a95b908dbaba43ef5fae08'
REFERENCE_INPUTS_SHA = '7e71f9bef410664c582927e0e900e2145ca92bc8bc269a9677fe9d156fd3b16e'
# Final source, test and receipt selection must be reviewed before acceptance.
# FINAL must additionally supply attempt/proposal/workflow/hardware, runtime_passed,
# exact added_tests/changed_source_paths and metadata cardinalities.
PLANNED = {
    'runtime_ignored': 32,
    'examples': {'example': 9, 'production-example': 3,
                 'sharded-example': 7, 'pending-example': 4, 'compute-sharded-example': 11},
    'kfd_mode': 'exact-elf-reuse',
}
FINAL = {
    **PLANNED,
    'attempt': 'attempt-04',
    'proposal': 'proposal-02',
    'workflow': 'attempt-04-after',
    'hardware': 'hardware-01',
    'runtime_passed': 2069,
    'metadata': {
        'changed': 9,
        'counts': {'content-sha256': 18, 'source-inventory-count': 7},
        'proof_files': 76,
        'audited_files': 1039,
        'runtime_files': 358,
        'runtime_and_schema_files': 363,
    },
    'added_tests': [
        'context::tests::compute_peer_tests::compute_peer_cancellation_and_preissue_errors_refund_only_consumer_custody',
        'context::tests::compute_peer_tests::compute_peer_descended_compute_fault_preserves_unknown_or_terminal_custody',
        'context::tests::compute_peer_tests::compute_peer_exact_writer_lease_and_actual_parent_observation_precede_commit',
        'context::tests::compute_peer_tests::compute_peer_failed_or_cancelled_parent_does_not_invalidate_retained_identity',
        'context::tests::compute_peer_tests::compute_peer_forward_and_self_edges_reject_before_recursive_validation',
        'context::tests::compute_peer_tests::compute_peer_inconsistent_backward_ranks_reject_before_recursive_validation',
        'context::tests::compute_peer_tests::compute_peer_journal_and_current_nonqueued_producer_are_required',
        'context::tests::compute_peer_tests::compute_peer_missing_snapshot_rejects_direct_and_depth_masked_observation',
        'context::tests::compute_peer_tests::compute_peer_nested_pending_root_drift_is_rejected_before_backend_observation',
        'context::tests::compute_peer_tests::compute_peer_nested_readback_reconciles_all_three_original_roots',
        'context::tests::compute_peer_tests::compute_peer_opt_in_full_write_coverage_and_exact_events_are_required',
        'context::tests::compute_peer_tests::compute_peer_ordinary_writer_and_retain_overflow_reject_before_issue',
        'kfd_backend::tests::compute_peer_tests::compute_peer_cancel_before_native_custody_and_failed_producer_release_retains',
        'kfd_backend::tests::compute_peer_tests::compute_peer_completed_producer_stream_can_retire_without_publishing_trailing_compute',
        'kfd_backend::tests::compute_peer_tests::compute_peer_deeper_successful_control_and_retain_overflow_are_checked_before_admission',
        'kfd_backend::tests::compute_peer_tests::compute_peer_final_readback_stream_alone_drives_pending_compute_and_native_restore',
        'kfd_backend::tests::compute_peer_tests::compute_peer_helper_attributes_quiescence_only_after_exact_producer_cancellation',
        'kfd_backend::tests::compute_peer_tests::compute_peer_native_error_and_unwind_preserve_producer_and_both_children',
        'kfd_backend::tests::compute_peer_tests::compute_peer_producer_completion_error_and_unwind_keep_native_plan_unpublished',
        'kfd_backend::tests::compute_peer_tests::compute_peer_queued_and_eager_persistent_keep_exact_owners_and_one_payload_charge',
        'kfd_backend::tests::compute_peer_tests::compute_peer_unsupported_profiles_reject_without_staging_or_owner_extraction',
    ],
    'changed_source_paths': [
        'crates/fe2o3-runtime-model/verus/check-producer-input-composition.py',
        'crates/fe2o3-runtime-model/verus/check-producer-input-fold.py',
        'crates/fe2o3-runtime-model/verus/check-producer-input-validate.py',
        'crates/fe2o3-runtime-model/verus/check-producer-journal-composition.py',
        'crates/fe2o3-runtime-model/verus/check-producer-journal-observers.py',
        'crates/fe2o3-runtime-model/verus/check-retained-credit-dispatch.py',
        'crates/fe2o3-runtime-model/verus/check-retained-pair-routing.py',
        'crates/fe2o3-runtime-model/verus/producer-journal-composition-mutations-v1.py',
        'crates/fe2o3-runtime-model/verus/test-producer-input-composition.py',
        'crates/fe2o3-runtime/examples/gfx942-runtime-sharded-vecadd-capture-smoke.rs',
        'crates/fe2o3-runtime/src/context.rs',
        'crates/fe2o3-runtime/src/context/copy_custody.rs',
        'crates/fe2o3-runtime/src/context/peer_custody.rs',
        'crates/fe2o3-runtime/src/context/peer_custody/compute_peer.rs',
        'crates/fe2o3-runtime/src/context/peer_reconciliation.rs',
        'crates/fe2o3-runtime/src/context/producer_launch.rs',
        'crates/fe2o3-runtime/src/context/tests/compute_peer_tests.rs',
        'crates/fe2o3-runtime/src/context/versions/producer_readers.rs',
        'crates/fe2o3-runtime/src/context/versions/submissions.rs',
        'crates/fe2o3-runtime/src/kfd_backend.rs',
        'crates/fe2o3-runtime/src/kfd_backend/compute_peer.rs',
        'crates/fe2o3-runtime/src/kfd_backend/compute_peer/tests.rs',
        'crates/fe2o3-runtime/src/kfd_backend/compute_xgmi.rs',
        'crates/fe2o3-runtime/src/kfd_backend/multi_qualification.rs',
    ],
}
WITNESS = 'gfx942-runtime-sharded-vecadd-capture-smoke'
SHARDED_EXAMPLE_TESTS = {
    'tests::cli_preserves_each_explicit_round_and_device_order',
    'tests::cli_rejects_implicit_round_duplicate_and_out_of_domain_ids',
    'tests::every_finite_recipe_matches_independent_fixed_total_and_page_partition',
    'tests::abi_lengths_are_logical_and_grid_tail_does_not_expand_bindings',
    'tests::independent_inputs_match_authority_without_using_its_expected_outputs',
    'tests::gathered_output_is_fixed_global_work_with_all_padding_verified',
    'tests::output_rejects_unchanged_c_wrong_round_bit_errors_padding_and_order',
    'tests::incoming_sentinel_differs_from_both_computed_data_and_preserved_padding',
    'tests::queued_compute_is_an_explicit_leading_mode_with_unchanged_round_and_uid_validation',
    'tests::mode_report_preserves_joined_schema_and_marks_all_queued_compute_custody',
    'tests::receipt_validation_requires_each_exact_id_once_and_success_not_quiescence',
}
CAPTURE_SHA = 'b7bb23095b8327fa16cc6db42d7703205112257cce7292a9cb8081637bf2430f'
CAMPAIGN_SHA = '8d9e34a16ee26c1ecb6dcbef0ded6942b7939f64189485d39bacf41fce3aae7d'
REBUILD_SHA = '8be7fb7b9d71322a7af4cb6fc7bc1c38d38114d2cb050b07d3ed0014499dd5fc'
REFERENCE_PROPOSER_SHA = '0fe3f05844cc0a3b15b8c81057136a027703e6a874c265ae62f4d8e07d444d50'
IDS = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33', '0x189ca857de1ef2fb',
       '0x54f88318ca05093d', '0xb7baafd0fb173d8e', '0x10a254ce4987e716',
       '0x53691ef168a0147d']
PROFILES = [('compute-sharded-2', IDS[5:]), ('compute-sharded-3', IDS[4:]),
            ('compute-sharded-5', IDS[2:]), ('compute-sharded-7', IDS),
            ('compute-sharded-7-reverse', IDS[::-1])]
CASES = [(name + '-queued-round-' + str(round_index), ids, round_index, True)
         for name, ids in PROFILES for round_index in (0, 1)] + [
    ('compute-sharded-2-joined-round-0', IDS[5:], 0, False),
    ('compute-sharded-7-joined-round-1', IDS, 1, False),
]

SOURCE_PREFIXES = ('.github/', 'benchmarks/', 'crates/', 'examples/', 'scripts/', 'tests/', 'tools/')
EVIDENCE_PREFIXES = (
    'docs/evidence/dev-completion-reconciliation-proof-2026-09-25/',
    'docs/evidence/dev-completion-leaf-outcomes-2026-09-25/',
    'docs/evidence/dev-xgmi-settled-mi300x-2026-09-18/',
    'docs/evidence/dev-xgmi-peer-hot-mi300x-2026-09-19/',
    'docs/evidence/dev-monotonic-wait-arithmetic-2026-10-01/',
)
GUARD_NAMES = {
    'check-request-charge.py', 'check-retained-credit-dispatch.py',
    'check-retained-pair-owned-storage.py', 'check-retained-pair-post-catch.py',
    'check-retained-pair-cadence.py', 'check-producer-input-fold.py',
    'check-producer-input-validate.py', 'check-producer-journal-observers.py',
    'check-retained-pair-routing.py', 'check-producer-input-composition.py',
    'check-producer-journal-composition.py', 'test-producer-input-composition.py',
    'producer-journal-composition-mutations-v1.py',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=REPO)


def manifest(raw):
    pairs = []
    for line in raw.decode().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        assert match, line
        pairs.append(match.groups())
    result = {path: digest for digest, path in pairs}
    assert result and len(result) == len(pairs)
    return result


def roster(raw):
    names = re.findall(r'^(.+): test$', raw.decode(), re.M)
    assert names and len(names) == len(set(names))
    return set(names)


def results(raw):
    pairs = re.findall(r'^test (.+) \.\.\. (ok|ignored)(?:,.*)?$', raw.decode(), re.M)
    result = dict(pairs)
    assert pairs and len(result) == len(pairs)
    return result


def test_result(raw, passed, ignored=0, filtered=0):
    output = raw.decode()
    summaries = [line for line in output.splitlines() if line.startswith('test result:')]
    prefix = f'test result: ok. {passed} passed; 0 failed; {ignored} ignored; 0 measured; {filtered} filtered out; finished in '
    assert len(summaries) == 1 and re.fullmatch(re.escape(prefix) + r'[0-9.]+s', summaries[0])
    observed = results(raw)
    assert list(observed.values()).count('ok') == passed
    assert list(observed.values()).count('ignored') == ignored
    assert not re.search(r'^test .+ \.\.\. FAILED', output, re.M)
    return observed, summaries[0]


def read_json(path):
    return json.loads(path.read_bytes())


def stamp(value):
    result = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    assert result.tzinfo is not None
    return result


def check_sources(sources):
    assert sources
    for name, digest in sources.items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        path = REPO / relative
        assert path.is_file() and not path.is_symlink() and path.resolve() == path
        assert sha(path.read_bytes()) == digest, name


def stage_commands(mode, runtime, kfd):
    cargo = ['cargo', '+nightly-2026-04-03']
    common = ['--locked', '--offline', '-p', 'fe2o3-runtime']
    compute = 'gfx942-runtime-compute-xgmi-smoke'
    production = 'gfx942-runtime-peer-copy-smoke'
    sharded = 'gfx942-runtime-sharded-peer-copy-smoke'
    pending = 'gfx942-runtime-pending-peer-capture-smoke'
    compute_sharded = WITNESS
    if mode == 'build':
        return {'runtime': (2400, cargo + ['test', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--no-run', '--message-format=json']),
                'kfd-full-list': (60, [kfd, '--list', '--test-threads=1'])}
    if mode in ('focused', 'tests'):
        filters = ('compute_peer', 'sharded_vecadd', 'multi_qualification', 'compute_xgmi', 'drain_capture', 'group_tests', 'copy_custody', 'deferred_compute', 'producer_peers', 'multi_open') if mode == 'focused' else ('compute_xgmi', 'packetized', 'full')
        stages = {}
        for selected in filters:
            name = selected if mode == 'focused' else 'fe2o3_runtime-' + selected
            argv = [runtime] + ([] if selected == 'full' else [selected])
            stages[name + '-list'] = (60, argv + ['--list', '--test-threads=1'])
            stages[name] = (1200 if selected == 'full' else 600, argv + ['--test-threads=1'])
        return stages
    assert mode == 'checks'
    patterns = ('crates/fe2o3-kfd/**/*.rs', 'crates/fe2o3-runtime/**/*.rs')
    changed = sorted(set(git('diff', 'HEAD', '--name-only', '--', *patterns).decode().splitlines()) |
                     set(git('ls-files', '--others', '--exclude-standard', '--', *patterns).decode().splitlines()))
    assert changed
    return {
        'rustc': (60, ['rustc', '+nightly-2026-04-03', '--version', '--verbose']),
        'cargo': (60, cargo + ['--version']), 'uname': (60, ['uname', '-a']),
        'clippy': (1200, cargo + ['clippy', '--locked', '--offline', '-p', 'fe2o3-kfd', '-p', 'fe2o3-runtime', '--all-features', '--lib', '--tests', '--example', compute, '--example', production, '--example', sharded, '--example', pending, '--example', compute_sharded, '--no-deps', '--', '-D', 'warnings']),
        'no-default': (300, cargo + ['check', *common, '--no-default-features', '--lib', '--example', production, '--example', sharded, '--example', pending]),
        'hardware-feature': (300, cargo + ['check', *common, '--no-default-features', '--features', 'hardware-qualification', '--lib', '--example', compute_sharded]),
        'example': (1200, cargo + ['test', *common, '--all-features', '--example', compute, '--', '--test-threads=1']),
        'production-example': (1200, cargo + ['test', *common, '--no-default-features', '--example', production, '--', '--test-threads=1']),
        'sharded-example': (1200, cargo + ['test', *common, '--example', sharded, '--', '--test-threads=1']),
        'pending-example': (1200, cargo + ['test', *common, '--example', pending, '--', '--test-threads=1']),
        'compute-sharded-example': (1200, cargo + ['test', *common, '--all-features', '--example', compute_sharded, '--', '--test-threads=1']),
        'witness-build': (1200, cargo + ['build', *common, '--all-features', '--profile', 'test', '--example', compute]),
        'production-witness-build': (1200, cargo + ['build', *common, '--no-default-features', '--profile', 'test', '--example', production]),
        'sharded-witness-build': (1200, cargo + ['build', *common, '--profile', 'test', '--example', sharded]),
        'pending-witness-build': (1200, cargo + ['build', *common, '--profile', 'test', '--example', pending]),
        'compute-sharded-witness-build': (1200, cargo + ['build', *common, '--all-features', '--profile', 'test', '--example', compute_sharded]),
        'formatting': (120, ['rustfmt', '+nightly-2026-04-03', '--check', '--edition', '2024', '--config', 'skip_children=true', *changed]),
        'whitespace': (60, ['git', 'diff', 'HEAD', '--check']),
    }


def audit_cpu(selected, sources, runtime, kfd):
    assert sha((ROOT / 'verify.sh').read_bytes()) == CONTROLLER_SHA
    build_finished = stamp((selected / 'build/kfd-full-list.finished').read_text())
    for mode in ('build', 'focused', 'tests', 'checks'):
        folder = selected / mode
        assert sha((folder / 'controller.sh').read_bytes()) == CONTROLLER_SHA
        assert (folder / 'overall.exit').read_text().strip() == '0'
        assert (folder / 'base.txt').read_text().strip() == BASE
        assert (folder / 'cwd.txt').read_text().strip() == str(REPO)
        environment = dict(line.split('=', 1) for line in (folder / 'environment.txt').read_text().splitlines())
        expected = dict(HOME='/home/harsh', PATH='/home/harsh/.cargo/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', RUST_TEST_THREADS='1', PWD=str(REPO))
        assert all(environment.get(key) == value for key, value in expected.items())
        assert set(environment) <= set(expected) | {'OLDPWD', 'SHLVL', '_'}
        assert manifest((folder / 'source-before.sha256').read_bytes()) == sources
        assert (folder / 'source-before.sha256').read_bytes() == (folder / 'source-after.sha256').read_bytes()
        commands = stage_commands(mode, runtime, kfd)
        assert {path.stem for path in folder.glob('*.exit')} == set(commands) | {'overall'}
        for suffix in ('command', 'started', 'finished', 'stdout', 'stderr'):
            assert {path.stem for path in folder.glob('*.' + suffix)} == set(commands)
        if mode in ('focused', 'tests'):
            assert stamp((folder / (next(iter(commands)) + '.started')).read_text()) >= build_finished
        previous = None
        for name, (seconds, argv) in commands.items():
            assert (folder / (name + '.exit')).read_text().strip() == '0'
            assert shlex.split((folder / (name + '.command')).read_text()) == argv
            started = stamp((folder / (name + '.started')).read_text())
            finished = stamp((folder / (name + '.finished')).read_text())
            assert 0 <= (finished - started).total_seconds() <= seconds + 35
            assert previous is None or started >= previous
            previous = finished
    artifacts = [json.loads(line) for line in (selected / 'build/runtime.stdout').read_text().splitlines()]
    assert artifacts[-1].get('reason') == 'build-finished' and artifacts[-1]['success']
    for target, executable in [('fe2o3_runtime', runtime), ('fe2o3_kfd', kfd)]:
        assert Path(executable).parent == REPO / 'target/debug/deps'
        assert re.fullmatch(target + r'-[0-9a-f]+', Path(executable).name)
        emitted = {item['executable'] for item in artifacts if item.get('reason') == 'compiler-artifact'
                   and item.get('target', {}).get('name') == target and item.get('profile', {}).get('test')
                   and item.get('executable')}
        assert emitted == {executable}
        assert manifest((selected / f'build/{target}.sha256').read_bytes()) == {executable: sha(Path(executable).read_bytes())}
    full = roster((selected / 'tests/fe2o3_runtime-full-list.stdout').read_bytes())
    observed, _ = test_result((selected / 'tests/fe2o3_runtime-full.stdout').read_bytes(), FINAL['runtime_passed'], FINAL['runtime_ignored'])
    assert set(observed) == full
    assert set(FINAL['examples']) == {'example', 'production-example', 'sharded-example', 'pending-example', 'compute-sharded-example'}
    for name, count in FINAL['examples'].items():
        example_results, _ = test_result((selected / f'checks/{name}.stdout').read_bytes(), count)
        if name == 'compute-sharded-example':
            assert set(example_results) == SHARDED_EXAMPLE_TESTS
    witnesses = {
        'witness': 'gfx942-runtime-compute-xgmi-smoke',
        'production-witness': 'gfx942-runtime-peer-copy-smoke',
        'sharded-witness': 'gfx942-runtime-sharded-peer-copy-smoke',
        'pending-witness': 'gfx942-runtime-pending-peer-capture-smoke',
        'compute-sharded-witness': WITNESS,
    }
    for name, executable in witnesses.items():
        path = 'target/debug/examples/' + executable
        assert manifest((selected / ('checks/' + name + '.sha256')).read_bytes()) == {
            path: sha((REPO / path).read_bytes())}
    for mode, prefix, filters in [('focused', '', ('compute_peer', 'sharded_vecadd', 'multi_qualification', 'compute_xgmi', 'drain_capture', 'group_tests', 'copy_custody', 'deferred_compute', 'producer_peers', 'multi_open')),
                                  ('tests', 'fe2o3_runtime-', ('compute_xgmi', 'packetized'))]:
        for name in filters:
            listed = roster((selected / mode / (prefix + name + '-list.stdout')).read_bytes())
            assert listed == {test for test in full if name in test}
            actual, _ = test_result((selected / mode / (prefix + name + '.stdout')).read_bytes(), len(listed), filtered=len(full) - len(listed))
            assert set(actual) == listed
    return full, observed


def selected_metadata_node(tree, selector):
    dictionary = re.fullmatch(r"(CHECKER_PINS|HELPERS|PINS)\['([a-z_.-]+)'\]", selector)
    if dictionary:
        name, key = dictionary.groups()
        assert (name in ('CHECKER_PINS', 'HELPERS') and re.fullmatch(r'[a-z-]+\.py', key)) or (name == 'PINS' and key == 'producer_readers.rs')
        owners = [node.value for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
        assert len(owners) == 1 and isinstance(owners[0], ast.Dict)
        nodes = [value for candidate, value in zip(owners[0].keys, owners[0].values)
                 if isinstance(candidate, ast.Constant) and candidate.value == key]
    elif selector == 'len(implementation) == literal':
        nodes = [node.comparators[0] for node in ast.walk(tree)
                 if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq)
                 and isinstance(node.left, ast.Call) and isinstance(node.left.func, ast.Name)
                 and node.left.func.id == 'len' and len(node.left.args) == 1
                 and isinstance(node.left.args[0], ast.Name) and node.left.args[0].id == 'implementation']
    elif selector.startswith('assertEqual('):
        match = re.fullmatch(r'assertEqual\(len\((native|with_schemas)\), literal\)', selector)
        assert match
        variable = match.group(1)
        nodes = [node.args[1] for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute) and node.func.attr == 'assertEqual'
                 and len(node.args) == 2 and isinstance(node.args[0], ast.Call)
                 and isinstance(node.args[0].func, ast.Name) and node.args[0].func.id == 'len'
                 and len(node.args[0].args) == 1 and isinstance(node.args[0].args[0], ast.Name)
                 and node.args[0].args[0].id == variable]
    else:
        nodes = [node.value for node in tree.body if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == selector for target in node.targets)]
    assert len(nodes) == 1 and isinstance(nodes[0], ast.Constant)
    return nodes[0]


def inverse_observer_sha(owner):
    include = 'include!("producer_journal_observer_bodies.rs");\n'
    assert owner.count(include) == 1
    reconstructed = owner.replace(include, '')
    routes = dict(active_lookup='lookup_producer_read', active_status='producer_read_status',
                  queued_lookup='lookup_queued_producer_read',
                  queued_status='queued_producer_read_status')
    for name, query in routes.items():
        invocation = 'producer_observe_' + name + '_body_v1!(self, reference)'
        assert reconstructed.count(invocation) == 1
        reconstructed = reconstructed.replace(
            invocation, 'self.versions.journal.' + query + '(reference)')
    return sha(reconstructed.encode())


def audit_proposer_extension():
    """Only the declared metadata hooks may differ from the pinned proposer."""
    original = (ROOT / 'source-ci/reference/propose.py').read_text()
    current = (ROOT / 'source-ci/propose-current.py').read_text()
    assert sha(original.encode()) == REFERENCE_PROPOSER_SHA
    assert sha(current.encode()) == PROPOSER_SHA
    hook = """        if hasattr(old, 'NATIVE_PREEXTRACTION_SHA'):
            # Rebind only the surrounding source identity. The unchanged guard
            # still checks every forwarding signature, body, query and proof.
            reconstructed = candidate[old.OWNER].replace(
                'include!("producer_journal_observer_bodies.rs");\\n', '')
            for route, (_reference, _result, query) in old.ROUTES.items():
                reconstructed = reconstructed.replace(
                    'producer_observe_' + route + '_body_v1!(self, reference)',
                    'self.versions.journal.' + query + '(reference)')
            edits.assignment('NATIVE_PREEXTRACTION_SHA', sha(reconstructed.encode()),
                             'content-sha256', 'exact inverse of the unchanged four-call extraction; new compute-peer adapters are not formally qualified')
"""
    replacements = [
        ('    def pin(self, name, key, value):\n',
         "    def pin(self, name, key, value, rationale='transitive identity of the metadata-only refreshed source guard'):\n"),
        ("        self.constant(selected[0], value, 'content-sha256', f'{name}[{key!r}]',\n"
         "                      'transitive identity of the metadata-only refreshed source guard')\n",
         "        self.constant(selected[0], value, 'content-sha256', f'{name}[{key!r}]', rationale)\n"),
        ("        for attribute in ('CHECKER_PINS', 'HELPERS'):\n",
         hook + "        for attribute in ('CHECKER_PINS', 'HELPERS'):\n"),
        ("    need(original == blobs([V / name])[V / name], 'unchanged duplicate identity tests')\n"
         '    edits = MetadataEdits(original)\n',
         "    need(original == blobs([V / name])[V / name], 'unchanged duplicate identity tests')\n"
         '    edits = MetadataEdits(original)\n'
         "    edits.pin('PINS', 'producer_readers.rs',\n"
         "              audited[str(RUNTIME / 'context/versions/producer_readers.rs')],\n"
         "              'duplicate whole-native-file identity; new compute-peer adapters are not formally qualified')\n"),
    ]
    expected = original
    for before, after in replacements:
        assert expected.count(before) == 1
        expected = expected.replace(before, after)
    assert current == expected
    assert ast.dump(ast.parse(current)) == ast.dump(ast.parse(expected))
    assert 'baseline_source' not in current and 'proposal-03' not in current


def audit_proposer():
    pins = {
        'propose.py': REFERENCE_PROPOSER_SHA,
        'verify-applied.py': '04e51da42b114a207d15564093ad608e828c5a0c23c3865662a240bfd707b243',
        'run.py': '9e8b7c1601cb73bc09a405e2df3cee1dc00deb31ab6830115e8d1d0d2e920be1',
        'inputs.json': REFERENCE_INPUTS_SHA,
        'result.json': 'f18598d8a126f3ae6ce39ab7d0b35801fbed9483be58738a90bd14ca8bfaa0e8',
    }
    for name, digest in pins.items():
        assert sha((ROOT / 'source-ci/reference' / name).read_bytes()) == digest
    assert sha((ROOT / 'source-ci/support.py').read_bytes()) == SUPPORT_SHA
    audit_proposer_extension()


def audit_metadata_receipt(path, expected):
    data = read_json(path)
    recorded = data.pop('recorded_utc_ns')
    assert type(recorded) is int and recorded > 0
    assert data == dict(
        applied_guard_hashes_match_proposal=True,
        ast_identical_except_recorded_metadata_literals=True,
        build_executed=False, changed_files=expected['changed'],
        formal_qualification=False, hash_constants=expected['counts']['content-sha256'],
        solver_executed=False, source_inventory_constants=expected['counts']['source-inventory-count'],
        unchanged_audited_source_files=expected['audited_files'],
        unchanged_proof_files=expected['proof_files'])
    return recorded


def audit_metadata(proposal):
    audit_proposer()
    folder = ROOT / 'source-ci' / proposal
    report = read_json(folder / 'metadata-report.json')
    assert report['baseline'] == BASE
    for flag in ('all_baseline_audits_passed', 'all_proposed_source_audits_passed', 'proof_closures_unchanged',
                 'predicates_contracts_and_proof_counts_unchanged', 'ast_identical_except_listed_metadata_constants'):
        assert report[flag]
    assert not report['solver_executed'] and not report['build_executed'] and not report['formal_qualification']
    counts, changed, patch = {'content-sha256': 0, 'source-inventory-count': 0}, 0, ['*** Begin Patch\n']
    paths = [row['path'] for row in report['changes']]
    assert len(paths) == len(set(paths)) == 13
    assert {Path(path).name for path in paths} == GUARD_NAMES
    for row in report['changes']:
        path = row['path']
        assert Path(path).parent == Path('crates/fe2o3-runtime-model/verus')
        old = (folder / 'originals' / Path(path).name).read_text()
        assert old.encode() == git('show', BASE + ':' + path)
        assert sha(old.encode()) == row['original_sha256']
        tree = ast.parse(old)
        nodes = {(n.lineno, n.col_offset, n.end_lineno, n.end_col_offset): n for n in ast.walk(tree) if isinstance(n, ast.Constant)}
        offsets = [0]
        for line in old.splitlines(keepends=True):
            offsets.append(offsets[-1] + len(line))
        edits = []
        for edit in row['edits']:
            node = nodes[edit['line'], edit['column'], edit['end_line'], edit['end_column']]
            assert node is selected_metadata_node(tree, edit['selector'])
            assert node.value == edit['old']
            category = edit['category']
            owner_path = 'crates/fe2o3-runtime/src/context/versions/producer_readers.rs'
            if edit['selector'] == 'NATIVE_PREEXTRACTION_SHA':
                assert Path(path).name == 'check-producer-journal-observers.py'
                assert edit['old'] == inverse_observer_sha(git('show', BASE + ':' + owner_path).decode())
                assert edit['new'] == inverse_observer_sha((REPO / owner_path).read_text())
            if edit['selector'] == "PINS['producer_readers.rs']":
                assert Path(path).name == 'test-producer-input-composition.py'
                assert edit['old'] == sha(git('show', BASE + ':' + owner_path))
                assert edit['new'] == sha((REPO / owner_path).read_bytes())
            counts[category] += 1
            if category == 'content-sha256':
                assert all(isinstance(edit[key], str) and re.fullmatch('[0-9a-f]{64}', edit[key]) for key in ('old', 'new'))
                assert edit['selector'] in {'SOURCE_TREE_SHA', 'RUNTIME_SHA', 'NATIVE_TREE_SHA', 'SCHEMA_TREE_SHA', 'GUARD_SHA', 'NATIVE_PREEXTRACTION_SHA', "PINS['producer_readers.rs']"} or re.fullmatch(r"(?:CHECKER_PINS|HELPERS)\['[a-z-]+\.py'\]", edit['selector'])
            else:
                assert category == 'source-inventory-count'
                assert edit['selector'] in {'SOURCE_FILES', 'RUNTIME_FILES', 'len(implementation) == literal', 'assertEqual(len(native), literal)', 'assertEqual(len(with_schemas), literal)'}
                assert type(edit['old']) is type(edit['new']) is int and edit['new'] > 0
            start = offsets[edit['line'] - 1] + edit['column']
            end = offsets[edit['end_line'] - 1] + edit['end_column']
            assert ast.literal_eval(old[start:end]) == edit['old']
            edits.append((start, end, json.dumps(edit['new'])))
            node.value = edit['new']
        new = old
        for start, end, value in sorted(edits, reverse=True):
            new = new[:start] + value + new[end:]
        assert ast.dump(tree) == ast.dump(ast.parse(new))
        assert sha(new.encode()) == row['proposed_sha256']
        assert (REPO / path).read_bytes() == new.encode()
        if old != new:
            changed += 1
            patch.append('*** Update File: ' + str(REPO / path) + '\n')
            patch.extend(list(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True)))[2:])
    assert ''.join(patch) + '*** End Patch\n' == (folder / 'metadata.patch').read_text()
    expected = FINAL['metadata']
    assert changed == expected['changed'] and counts == expected['counts']
    assert len(report['proof_files']) == expected['proof_files']
    assert len(report['audited_source_sha256']) == expected['audited_files']
    assert report['runtime_source_files'] == expected['runtime_files']
    assert report['runtime_and_schema_files'] == expected['runtime_and_schema_files']
    assert len(list((REPO / 'crates/fe2o3-runtime/src').rglob('*.rs'))) == expected['runtime_files']
    for path, digest in report['proof_files'].items():
        assert sha(git('show', BASE + ':' + path)) == digest, path
    check_sources(report['proof_files'])
    check_sources(report['audited_source_sha256'])
    return report


def audit_workflow(workflow, proposal, report):
    folder = ROOT / 'source-ci' / workflow
    data, inputs = read_json(folder / 'result.json'), read_json(folder / 'inputs.json')
    assert data['accepted'] and data['command_count'] == 32 and data['source_unchanged'] and not data['failed']
    assert not data['solver_invocations'] and not data['build_invocations'] and not data['gpu_invocations']
    assert inputs['head'] == BASE and inputs['workflow_sha256'] == WORKFLOW_SHA
    assert sha((REPO / '.github/workflows/runtime-component-source-guards.yml').read_bytes()) == WORKFLOW_SHA
    reference = ROOT / 'source-ci/reference/inputs.json'
    assert sha(reference.read_bytes()) == REFERENCE_INPUTS_SHA
    assert inputs['commands'] == read_json(reference)['commands']
    assert inputs['source_sha256'] == read_json(folder / 'closing-source.json')
    tracked = git('ls-files', '--cached', '-z').decode().split('\0')
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    names = {name for name in tracked if name and ('/' not in name or name.startswith(SOURCE_PREFIXES + EVIDENCE_PREFIXES))}
    names |= {name for name in untracked if name.endswith('.rs') and name.startswith(SOURCE_PREFIXES)}
    assert set(inputs['source_sha256']) == names
    assert data['source_files'] == len(names)
    check_sources(inputs['source_sha256'])
    assert all(inputs['source_sha256'].get(path) == digest for path, digest in report['audited_source_sha256'].items())
    assert inputs['environment'] == dict(PATH='/usr/bin:/bin', HOME=str(folder / 'home'), TMPDIR=str(folder / 'tmp'), LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_OPTIONAL_LOCKS='0')
    assert len(inputs['commands']) == len(data['commands']) == 32
    previous = None
    for index, (command, record) in enumerate(zip(inputs['commands'], data['commands']), 1):
        stage = folder / f'{index:02}'
        assert record == read_json(stage / 'receipt.json')
        assert [record['step'], record['literal'], record['argv']] == command
        assert record['argv'] == shlex.split(record['literal']) and record['cwd'] == str(REPO)
        assert record['exit'] == 0 and not record['timed_out'] and record['group_absent']
        assert 0 < record['timeout_seconds'] <= 120
        assert 0 <= (record['finished_ns'] - record['started_ns']) / 1e9 <= record['timeout_seconds'] + 10
        assert previous is None or record['started_ns'] >= previous
        previous = record['finished_ns']
        assert sha((stage / 'stdout').read_bytes()) == record['stdout_sha256']
        assert sha((stage / 'stderr').read_bytes()) == record['stderr_sha256']
    support = read_json(folder / 'reused-support.json')
    assert support['metadata_proposal'] == proposal and support['workflow_exit'] == 0 and support['workflow_accepted']
    assert not support['metadata_patch_applied_by_this_support']
    assert sha((ROOT / 'source-ci/support.py').read_bytes()) == SUPPORT_SHA
    proposal_folder = ROOT / 'source-ci' / proposal
    before = proposal_folder / ('before-' + workflow + '-audit.json')
    after = proposal_folder / ('after-' + workflow + '-audit.json')
    assert support['closing_metadata_audit'] == str(after)
    assert audit_metadata_receipt(before, FINAL['metadata']) <= data['commands'][0]['started_ns']
    assert audit_metadata_receipt(after, FINAL['metadata']) >= data['commands'][-1]['finished_ns']



def archive_reader(packet, prefix):
    """Authenticate an archived packet by its SHA256SUMS committed at BASE."""
    pins = manifest(git('show', BASE + ':' + packet + '/SHA256SUMS'))
    path = REPO / packet / 'raw.tar.gz'
    assert path.is_file() and not path.is_symlink()
    digest = sha(path.read_bytes())
    assert digest == pins['raw.tar.gz']
    archive = tarfile.open(path, 'r:gz')
    names = [member.name for member in archive.getmembers()]
    assert len(names) == len(set(names))
    for member in archive.getmembers():
        relative = Path(member.name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert member.isfile() or member.isdir()
        assert member.name == prefix.rstrip('/') or member.name.startswith(prefix)
    authenticated = {}

    def read(name):
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        member = archive.getmember(prefix + name)
        assert member.isfile() and not member.issym() and not member.islnk()
        raw = archive.extractfile(member).read()
        authenticated[name] = sha(raw)
        return raw

    return archive, read, digest, authenticated


def audit_baseline(runtime_roster, runtime_results, metadata):
    packet = 'docs/evidence/dev-multigpu-compute-shards-2026-10-02'
    archive, prior, digest, authenticated = archive_reader(
        packet, 'fe2o3-multigpu-compute-shards-20261002/')
    try:
        assert digest == '03bd750675e9a9b2a31a3dc8d3afe3c3921e3b4d243d7ebc9f3077122e49245f'
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted'] and qualification['baseline'] == '76dbbb03d65529d28bb6d15d2970d020cc7ef48b'
        assert qualification['runtime']['passed'] == 2048
        assert qualification['runtime']['ignored'] == 32
        selected = qualification['attempt']
        assert selected == 'attempt-03'
        old, _ = test_result(prior(selected + '/tests/fe2o3_runtime-full.stdout'), 2048, 32)
        assert set(old) == roster(prior(selected + '/tests/fe2o3_runtime-full-list.stdout'))
        assert set(old) < runtime_roster
        added = runtime_roster - set(old)
        assert added == set(FINAL['added_tests']) and len(added) == len(FINAL['added_tests'])
        assert FINAL['runtime_passed'] == 2048 + len(added)
        assert {name for name, state in old.items() if state == 'ignored'} == {
            name for name, state in runtime_results.items() if state == 'ignored'}
        proposal = qualification['source_proposal']
        old_report = json.loads(prior('source-ci/' + proposal + '/metadata-report.json'))
        assert metadata['proof_files'] == old_report['proof_files']
        runtime_prefix = 'crates/fe2o3-runtime/src/'
        old_audited = set(old_report['audited_source_sha256'])
        runtime_sources = {str(path.relative_to(REPO))
                           for path in (REPO / runtime_prefix).rglob('*.rs')}
        assert set(metadata['audited_source_sha256']) == (
            {name for name in old_audited if not name.startswith(runtime_prefix)} |
            runtime_sources)
        for name in ('example', 'production-example', 'sharded-example', 'pending-example'):
            count = FINAL['examples'][name]
            old_example, _ = test_result(prior(selected + '/checks/' + name + '.stdout'), count)
            new_example, _ = test_result(
                (ROOT / FINAL['attempt'] / 'checks' / (name + '.stdout')).read_bytes(), count)
            assert old_example == new_example
        old_example, _ = test_result(prior(selected + '/checks/compute-sharded-example.stdout'), 8)
        extra_examples = {
            'tests::queued_compute_is_an_explicit_leading_mode_with_unchanged_round_and_uid_validation',
            'tests::mode_report_preserves_joined_schema_and_marks_all_queued_compute_custody',
            'tests::receipt_validation_requires_each_exact_id_once_and_success_not_quiescence',
        }
        assert set(old_example) | extra_examples == SHARDED_EXAMPLE_TESTS
        assert not set(old_example).intersection(extra_examples)
        old_sources = prior(selected + '/build/source-before.sha256')
        assert sha(old_sources) == qualification['source_snapshot_sha256']
        assert old_sources == prior(selected + '/build/source-after.sha256')
        return dict(archive_sha256=digest, added_tests=sorted(added),
                    authenticated_members=authenticated)
    finally:
        archive.close()


def audit_original_kfd_reuse(selected, current, executable):
    """Reuse is a byte-identical historical run, never a fresh-run claim."""
    if FINAL['kfd_mode'] != 'exact-elf-reuse':
        raise RuntimeError('Fresh KFD schema/roster audit must be implemented before acceptance')
    packet = 'docs/evidence/dev-multigpu-production-peers-2026-10-02'
    archive, prior, digest, authenticated = archive_reader(
        packet, 'fe2o3-multigpu-production-peers-20261002/')
    try:
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted']
        assert qualification['accepted_build_attempt'] == 'attempt-08'
        old_kfd = qualification['kfd']
        assert old_kfd['fresh_full_run'] and old_kfd['disjoint_roster_coverage']
        assert old_kfd['passed'] == 1925 and old_kfd['failed'] == old_kfd['ignored'] == 0
        old_source_raw = prior('attempt-08/build/source-before.sha256')
        assert sha(old_source_raw) == qualification['source_snapshot_sha256']
        assert old_source_raw == prior('attempt-08/build/source-after.sha256')
        old_sources = manifest(old_source_raw)
        kfd_sources = {name: value for name, value in old_sources.items()
                       if name.startswith('crates/fe2o3-kfd/')}
        assert kfd_sources and kfd_sources == {
            name: value for name, value in current.items() if name.startswith('crates/fe2o3-kfd/')}
        executable_hash = sha(executable.read_bytes())
        assert executable_hash == old_kfd['exact_executable_sha256']
        old_executable = prior('attempt-08/build/fe2o3_kfd.path').decode().strip()
        assert manifest(prior('attempt-08/build/fe2o3_kfd.sha256')) == {
            old_executable: executable_hash}
        new_roster_raw = (selected / 'build/kfd-full-list.stdout').read_bytes()
        old_roster_raw = prior('attempt-08/build/kfd-full-list.stdout')
        full = roster(new_roster_raw)
        assert full == roster(old_roster_raw) and len(full) == 1925
        assert prior('attempt-08/build/kfd-full-list.exit').decode().strip() == '0'
        shards = old_kfd['shards']
        assert [part['mode'] for part in shards] == ['0', '1', '2', '3', 'rest']
        heavy = sorted(name for name in full if name.startswith('queue::live::construction_primary::'))
        union = set()
        for part in shards:
            mode = part['mode']
            folder = 'kfd-shard-' + mode + '/'
            raw = prior(folder + 'result.json')
            assert sha(raw) == part['result_sha256']
            data = json.loads(raw)
            inputs = json.loads(prior(folder + 'inputs.json'))
            stdout = prior(folder + 'run.stdout')
            assert data['accepted'] and data['exit_code'] == 0 and not data['timed_out']
            assert data['executable_unchanged'] and data['group_absent']
            assert 0 <= data['elapsed_seconds'] <= 1235
            assert stamp(data['finished']) >= stamp(data['started'])
            assert data['stdout_sha256'] == sha(stdout)
            assert data['stderr_sha256'] == sha(prior(folder + 'run.stderr'))
            expected = sorted(full - set(heavy)) if mode == 'rest' else heavy[int(mode)::4]
            assert inputs['selected'] == expected and len(expected) == part['passed']
            assert roster(prior(folder + 'list.stdout')) == set(expected)
            assert inputs['executable_sha256'] == executable_hash and inputs['cwd'] == str(REPO)
            assert inputs['argv'] == [old_executable, '--test-threads=1', '--exact', *expected]
            assert inputs['environment'] == dict(
                HOME='/home/harsh', PATH='/usr/bin:/bin', LANG='C.UTF-8',
                LC_ALL='C.UTF-8', RUST_TEST_THREADS='1')
            assert inputs['controller_sha256'] == sha(prior('kfd_shard.py'))
            assert inputs['source_manifest_sha256'] == sha(old_source_raw)
            assert inputs['full_roster_sha256'] == sha(old_roster_raw)
            assert inputs['total_roster'] == len(full)
            passed, summary = test_result(stdout, len(expected), filtered=len(full) - len(expected))
            assert data['summary'] == [summary] and set(passed) == set(expected)
            assert set(passed.values()) == {'ok'} and not union.intersection(passed)
            assert not prior(folder + 'run.stderr') and not prior(folder + 'list.stderr')
            union.update(passed)
        assert union == full
        return dict(passed=len(full), failed=0, ignored=0, fresh_run=False,
                    exact_elf_reuse=True, executable_sha256=executable_hash,
                    unchanged_source_files=len(kfd_sources), archive_sha256=digest,
                    authenticated_members=authenticated)
    finally:
        archive.close()


def audit_kfd_reuse(selected, current, executable):
    """Authenticate both the immediate baseline reuse and its original full run."""
    packet = 'docs/evidence/dev-multigpu-compute-shards-2026-10-02'
    archive, prior, digest, authenticated = archive_reader(
        packet, 'fe2o3-multigpu-compute-shards-20261002/')
    try:
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted'] and qualification['attempt'] == 'attempt-03'
        recorded = qualification['kfd']
        assert recorded['passed'] == 1925 and recorded['failed'] == recorded['ignored'] == 0
        assert recorded['exact_elf_reuse'] and not recorded['fresh_run']
        executable_hash = sha(executable.read_bytes())
        assert executable_hash == recorded['executable_sha256']
        old_executable = prior('attempt-03/build/fe2o3_kfd.path').decode().strip()
        assert manifest(prior('attempt-03/build/fe2o3_kfd.sha256')) == {old_executable: executable_hash}
        assert prior('attempt-03/build/kfd-full-list.exit').decode().strip() == '0'
        old_roster = roster(prior('attempt-03/build/kfd-full-list.stdout'))
        assert old_roster == roster((selected / 'build/kfd-full-list.stdout').read_bytes())
        assert len(old_roster) == 1925
        old_source_raw = prior('attempt-03/build/source-before.sha256')
        assert old_source_raw == prior('attempt-03/build/source-after.sha256')
        assert sha(old_source_raw) == qualification['source_snapshot_sha256']
        old_sources = manifest(old_source_raw)
        old_kfd_sources = {name: value for name, value in old_sources.items()
                           if name.startswith('crates/fe2o3-kfd/')}
        assert old_kfd_sources == {name: value for name, value in current.items()
                                  if name.startswith('crates/fe2o3-kfd/')}
        assert len(old_kfd_sources) == recorded['unchanged_source_files'] == 344
        original = audit_original_kfd_reuse(selected, current, executable)
        for key in ('passed', 'failed', 'ignored', 'fresh_run', 'exact_elf_reuse',
                    'executable_sha256', 'unchanged_source_files', 'archive_sha256',
                    'authenticated_members'):
            assert original[key] == recorded[key], key
        return dict(original, immediate_baseline_archive_sha256=digest,
                    immediate_baseline_authenticated_members=authenticated)
    finally:
        archive.close()


def receipt(folder, seconds):
    data = read_json(folder / 'result.json')
    assert data['exit_code'] == 0 and not data['timed_out']
    assert data['local_process_group_absent']
    assert data['stdout_sha256'] == sha((folder / 'stdout').read_bytes())
    assert data['stderr_sha256'] == sha((folder / 'stderr').read_bytes())
    assert 0 <= data['elapsed_seconds'] <= seconds
    assert stamp(data['finished']) >= stamp(data['started'])
    return data


def audit_artifacts_and_rebuild():
    """Reuse the authenticated historical rebuild; no fresh compiler claim."""
    packet = 'docs/evidence/dev-multigpu-compute-shards-2026-10-02'
    archive, prior, digest, authenticated = archive_reader(
        packet, 'fe2o3-multigpu-compute-shards-20261002/')
    try:
        qualification = json.loads(prior('qualification.json'))
        assert qualification['accepted']
        recorded = qualification['artifact_rebuild']
        check_sources(recorded['unchanged_source_sha256'])
        runtime = 'crates/fe2o3-runtime/'
        old_paths = [
            runtime + 'src/qualification_gfx942_vecadd_v1.rs',
            runtime + 'src/qualification_gfx942_vecadd_repeat_v1.rs',
            runtime + 'src/qualification_gfx942_r57_n3_v1.rs',
            runtime + 'src/qualification_gfx942_r57_n3_v1',
            runtime + 'src/qualification_gfx942_sharded_vecadd_v1.rs',
            runtime + 'src/qualification_gfx942_sharded_vecadd_v1',
            runtime + 'fixtures/trusted-gfx942-vecadd-v1',
            runtime + 'fixtures/trusted-gfx942-r57-n3-v1',
            runtime + 'fixtures/trusted-gfx942-r57-n3-v2',
            runtime + 'fixtures/trusted-gfx942-sharded-vecadd-v1',
        ]
        tracked = git('ls-tree', '-r', '--name-only', BASE, '--', *old_paths).decode().splitlines()
        assert tracked and len(tracked) == len(set(tracked))
        current = set()
        for name in old_paths:
            path = REPO / name
            assert path.exists() and not path.is_symlink()
            if path.is_dir():
                current.update(str(item.relative_to(REPO)) for item in path.rglob('*') if item.is_file())
            else:
                current.add(name)
        assert current == set(tracked)
        unchanged = {}
        for name in tracked:
            original = git('show', BASE + ':' + name)
            assert (REPO / name).read_bytes() == original
            unchanged[name] = sha(original)
        assert all(unchanged.get(name) == value for name, value in recorded['unchanged_source_sha256'].items())
        policy = runtime + 'fixtures/trusted-gfx942-sharded-vecadd-v1/policy-v1.txt'
        policy_sha = 'e1d35c9a266d0c66347df1892ccf7df8811b457356e7b028fb406d71ca061015'
        assert unchanged[policy] == recorded['policy_sha256'] == policy_sha
        fixture = runtime + 'fixtures/trusted-gfx942-vecadd-v1/'
        names = ['build-and-verify.sh', 'policy-v1.txt', 'vecadd.ll', 'vecadd.hsaco']
        expected = {
            'build-and-verify.sh': 'd0f9375bef9c85bee33e27db66a80c14d4d531b92db4655c804882b3eef2f79d',
            'policy-v1.txt': '558897b2c24edacb9a0d83a630d6f8480a74095771211fafc0fdb823d476c9a7',
            'vecadd.ll': 'b3412c050ce2182feb669d267e3e7208400c4d16f0865efb7aeafd118c8f7e51',
            'vecadd.hsaco': '3a25e364dd1e1931d1a16c24b37aa998df2c6ef1cbcf0ec2afb6372cbc878bab',
        }
        assert {name: unchanged[fixture + name] for name in names} == expected
        compiler = 'AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.4 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)'
        data = json.loads(prior('rebuild-01/rebuild.json'))
        assert data == recorded['rebuild'] and data['accepted'] and not data['errors']
        assert data['baseline'] == '76dbbb03d65529d28bb6d15d2970d020cc7ef48b'
        assert data['input_sha256'] == expected and data['compiler'] == compiler
        assert data['object_sha256'] == expected['vecadd.hsaco']
        assert data['owned_cleanup_complete'] and not data['gpu_execution']
        assert not data['compiler_correctness_proof']
        assert sha(prior('rebuild-01/capture.py')) == recorded['capture_sha256'] == CAPTURE_SHA
        assert sha(prior('rebuild-01/rebuild.py')) == recorded['rebuild_controller_sha256'] == REBUILD_SHA
        directory = data['owned_directory']
        assert re.fullmatch(r'/tmp/fe2o3-sharded-vecadd-build-20261002-[A-Za-z0-9]{6}', directory)
        ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
               '-o', 'StrictHostKeyChecking=yes', 'mi300x']
        receipts, previous = {}, None

        def capture(name, argv, bound='30s', local=False):
            nonlocal previous
            stage = 'rebuild-01/' + name + '/'
            raw = prior(stage + 'result.json')
            record = json.loads(raw)
            stdout, stderr = prior(stage + 'stdout'), prior(stage + 'stderr')
            command = argv if local else ssh + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]
            assert record['argv'] == command and record['exit_code'] == 0, name
            assert not record['timed_out'] and record['local_process_group_absent']
            assert 0 <= record['elapsed_seconds'] <= 245
            assert stamp(record['finished']) >= stamp(record['started'])
            assert record['stdout_sha256'] == sha(stdout) and record['stderr_sha256'] == sha(stderr)
            assert previous is None or stamp(record['started']) >= previous, name
            previous = stamp(record['finished'])
            assert not stderr, name
            receipts[name] = sha(raw)
            return stdout.decode()

        assert capture('compiler', ['/opt/rocm/llvm/bin/clang', '--version']).splitlines()[0] == compiler
        assert capture('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-sharded-vecadd-build-20261002-XXXXXX']).strip() == directory
        assert not capture('upload-inputs', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
            '-o', 'StrictHostKeyChecking=yes', *[str(REPO / fixture / name) for name in names],
            'mi300x:' + directory + '/'], local=True)
        paths = [directory + '/' + name for name in names]
        hashes = [expected[name] + '  ' + path for name, path in zip(names, paths)]
        assert capture('initial-input-hashes', ['/usr/bin/sha256sum', *paths]).splitlines() == hashes
        assert capture('rebuild', ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
            'ROCM_PATH=/opt/rocm', 'TMPDIR=' + directory, '/bin/bash',
            directory + '/build-and-verify.sh'], '120s') == (
                'verified trusted-gfx942-vecadd-v1 ' + expected['vecadd.hsaco'] + '\n')
        assert capture('final-input-hashes', ['/usr/bin/sha256sum', *paths]).splitlines() == hashes
        assert not capture('remove-owned-inputs', ['/usr/bin/rm', '-f', '--', *paths])
        assert not capture('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
        assert not capture('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
        assert receipts == recorded['receipt_sha256'] and len(receipts) == 9
        check_sources(unchanged)
        return dict(unchanged_source_sha256=unchanged, policy_sha256=policy_sha,
                    historical_archive_sha256=digest, historical_rebuild=data,
                    receipt_sha256=receipts, authenticated_members=authenticated,
                    rebuild_controller_sha256=REBUILD_SHA, capture_sha256=CAPTURE_SHA,
                    fresh_rebuild=False, compiler_correctness_proof=False,
                    kernel_correctness_proof=False)
    finally:
        archive.close()


def parse_pass(raw):
    lines = raw.decode().splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS ')
    pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
    assert pairs and all(len(pair) == 2 and all(pair) for pair in pairs)
    fields = dict(pairs)
    assert len(fields) == len(pairs)
    return fields


def expected_shards(total_bytes, count):
    assert type(total_bytes) is int and total_bytes > 0
    assert type(count) is int and 2 <= count <= 8
    quotient, remainder = divmod(total_bytes, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    assert sizes[0] > 0 and sum(sizes) == total_bytes
    assert all(a + n == b for a, n, b in zip(offsets, sizes, offsets[1:]))
    assert offsets[-1] + sizes[-1] == total_bytes
    return offsets, sizes


def independent_vecadd_digests():
    outputs = [b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                        for global_index in range(65537)) for round_index in (0, 1)]
    assert all(len(output) == 262148 for output in outputs)
    digests = [sha(output) for output in outputs]
    assert digests[0] != digests[1]
    return digests


def hardware_expected(ids, round_index, digests, queued):
    count = len(ids)
    assert round_index in (0, 1) and len(digests) == 2 and digests[0] != digests[1]
    offsets, sizes = expected_shards(65537, count)
    padded = [((size * 4 + 4095) // 4096) * 4096 for size in sizes]
    fields = dict(
        schema='fe2o3.sharded-vecadd-capture-smoke.v1',
        authority='qualification-sharded-vecadd-v1', devices=str(count),
        unique_ids=','.join(ids), round=str(round_index), rounds='1',
        logical_elements='65537', logical_bytes='262148',
        shard_ranges=','.join(f'{offset}:{size}:{physical}'
                             for offset, size, physical in zip(offsets, sizes, padded)),
        padded_bytes=str(sum(padded)), launches=str(count), compute_receipts=str(count),
        transfer_receipts=str(2 * count), completion_receipts=str(3 * count),
        compute_admission='all-before-explicit-progress', compute_join='exact-succeeded-restored',
        peer_copies=str(count), dependent_readbacks=str(count), capture_ranges=str(count),
        captured_bytes=str(sum(padded)), abi_bytes='48', kernel='vecadd', journal='enabled',
        host_output_installations='0', c_initial='-1', incoming_sentinel='full-byte-pass',
        output='full-byte-pass', padding='full-byte-pass', coverage='exact-contiguous-disjoint',
        global_sha256=digests[round_index],
        admission='all-transfers-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_preservation='unobserved', allocation_reuse='false', contexts='one-per-process',
        drain='pending-group', capture='coherent-host-group', physical_overlap='unmeasured',
        cleanup='owned-shutdown-explicit', performance_acceptance='false', formal_refinement='false')
    if queued:
        fields.update(schema='fe2o3.sharded-vecadd-queued-capture-smoke.v1',
                      compute_admission='may-publish-before-cutoff', compute_join='owned-drain',
                      compute_api='producer-aware', compute_dependency='exact-event',
                      compute_progress='dependent-readback-streams', retained_submissions=str(3 * count))
    assert len(fields) == (49 if queued else 45)
    return fields


def audit_hardware(hw, selected):
    data = read_json(hw / 'campaign.json')
    assert data['accepted'] and data['owned_cleanup_complete'] and not data['errors']
    assert data['selected_build_attempt'] == selected.name
    assert not data['performance_acceptance'] and not data['formal_refinement'] and not data['exclusive_reservation']
    assert len(data['completed']) == data['expected_cases'] == 12
    assert [item['name'] for item in data['completed']] == [name for name, _, _, _ in CASES]
    assert data['limitations'] == [
        'point observations, not continuous attachment census',
        'finite trusted-artifact qualification, not general kernel authority',
        'finite ordinary producer chain, not arbitrary dependency graph support',
        'compute may eagerly publish before cutoff; physical overlap is unmeasured',
        'native completion counter after cutoff is unobserved',
        'one context per process; no allocation reuse across rounds',
        'ACQUIRE_VM admission lasts until process exit; same-process reopen is unsupported',
        'postcopy source preservation is not observed']
    assert sha((hw / 'capture.py').read_bytes()) == CAPTURE_SHA
    assert sha((hw / 'campaign.py').read_bytes()) == CAMPAIGN_SHA
    directory = data['owned_directory']
    assert re.fullmatch(r'/tmp/fe2o3-multigpu-compute-peer-20261002-[A-Za-z0-9]{6}', directory)
    assert set(data['binaries']) == {'compute-sharded'}
    binary = data['binaries']['compute-sharded']
    path = 'target/debug/examples/' + WITNESS
    assert binary['local'] == str(REPO / path) and binary['remote'] == directory + '/compute-sharded-witness'
    assert manifest((selected / 'checks/compute-sharded-witness.sha256').read_bytes()) == {path: binary['sha256']}
    assert sha((REPO / path).read_bytes()) == binary['sha256']
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', 'mi300x']
    receipts, previous = {}, None

    def capture(name, argv, bound='30s', local=False):
        nonlocal previous
        folder = hw / name
        record = receipt(folder, 245)
        expected = argv if local else ssh + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]
        assert record['argv'] == expected, name
        assert previous is None or stamp(record['started']) >= previous, name
        previous = stamp(record['finished'])
        receipts[name] = sha((folder / 'result.json').read_bytes())
        return (folder / 'stdout').read_text()

    availability = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram', '--showuniqueid', '--showbus', '--showpids', '--json']
    baseline = json.loads(capture('initial-availability', availability))
    assert not (hw / 'initial-availability/stderr').read_bytes()

    def admission(name):
        state = json.loads(capture(name + '-availability', availability))
        buses = ['0000:26:00.0', '0000:46:00.0', '0000:65:00.0', '0000:85:00.0',
                 '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
        for index, (uid, bus) in enumerate(zip(IDS, buses), 1):
            card = 'card' + str(index)
            assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bus
            assert baseline[card]['Unique ID'] == uid and baseline[card]['PCI Bus'] == bus
            assert state[card]['GPU use (%)'] == baseline[card]['GPU use (%)'] == '0'
            assert state[card]['VRAM Total Memory (B)'] == baseline[card]['VRAM Total Memory (B)']
            assert state[card]['VRAM Total Used Memory (B)'] == baseline[card]['VRAM Total Used Memory (B)']
        assert state['system'] == baseline['system']
        mapping = capture(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
        pids = {}
        for item in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
            pid, count, colon, devices = item.groups()
            devices = [] if devices is None else devices.split()
            assert pid not in pids and int(count) == len(devices) == len(set(devices))
            assert bool(colon) == bool(devices)
            assert not {str(index) for index in range(1, 8)}.intersection(devices)
            pids[pid] = devices
        assert {'PID' + pid for pid in pids} == set(state['system'])
        assert all(int(state['system']['PID' + pid].split(',')[1]) == len(devices) for pid, devices in pids.items())
        memory = capture(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
        available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
        assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024

    admission('baseline')
    assert 0 <= (stamp(read_json(hw / 'baseline-availability/result.json')['started']) - stamp(read_json(hw / 'initial-availability/result.json')['finished'])).total_seconds() <= 300
    assert capture('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-compute-peer-20261002-XXXXXX']).strip() == directory
    capture('upload-compute-sharded', ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']], local=True)
    assert capture('initial-hash-compute-sharded', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    digests = independent_vecadd_digests()
    for reported, (name, ids, round_index, queued) in zip(data['completed'], CASES):
        admission(name)
        argv = ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env', '-u', 'HIP_VISIBLE_DEVICES',
                '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES', '-u', 'GPU_DEVICE_ORDINAL', binary['remote'], *(['--queued-compute'] if queued else []), '--round', str(round_index), *ids]
        lines = capture(name, argv, '180s').splitlines()
        assert len(lines) == 1 and lines[0].startswith('PASS ')
        pairs = [token.split('=', 1) for token in lines[0].split()[1:]]
        assert all(len(pair) == 2 and all(pair) for pair in pairs)
        fields = dict(pairs)
        assert len(fields) == len(pairs) and fields == reported['fields'] == hardware_expected(ids, round_index, digests, queued)
        assert not (hw / name / 'stderr').read_bytes()
        admission(name + '-post')
    paths = [binary['remote']]
    probe = ('import json,os,sys; from pathlib import Path; '
        'paths=set(sys.argv[1:]); found=[]\n'
        'for item in Path("/proc").iterdir():\n'
        ' if item.name.isdigit():\n'
        '  try:\n'
        '   exe=os.readlink(item/"exe")\n'
        '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
        '   continue\n'
        '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
        'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
    assert json.loads(capture('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])) == {'owned_executable_pids': []}
    assert capture('final-hash-compute-sharded', ['/usr/bin/sha256sum', binary['remote']]).split() == [binary['sha256'], binary['remote']]
    assert not capture('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
    assert not capture('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
    assert not capture('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
    admission('final')
    assert {path.name for path in hw.iterdir() if path.is_dir()} == set(receipts)
    return dict(campaign=data, receipt_sha256=receipts)


def main():
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) == 1
    assert FINAL is not None, 'Audit scaffold is not finalized; no acceptance may be emitted'
    assert all(FINAL.get(key) == value for key, value in PLANNED.items())
    assert type(FINAL['runtime_passed']) is int and FINAL['runtime_passed'] > 2048
    assert FINAL['added_tests'] and len(FINAL['added_tests']) == len(set(FINAL['added_tests']))
    assert FINAL['changed_source_paths'] and len(FINAL['changed_source_paths']) == len(set(FINAL['changed_source_paths']))
    assert FINAL['metadata']['proof_files'] == 76
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert not (ROOT / 'qualification.json').exists()
    attempt, proposal, workflow, hardware = [
        FINAL[key] for key in ('attempt', 'proposal', 'workflow', 'hardware')]
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert re.fullmatch(r'proposal-[0-9]+', proposal)
    assert re.fullmatch(r'attempt-[0-9]+-after', workflow)
    assert re.fullmatch(r'hardware-[a-z0-9-]+', hardware)
    selected = ROOT / attempt
    snapshot = (selected / 'build/source-before.sha256').read_bytes()
    sources = manifest(snapshot)
    tracked = git('ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
                  'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo')
    assert set(sources) == {name.decode() for name in tracked.split(b'\0') if name}
    check_sources(sources)
    changed = set(git('diff', BASE, '--name-only', '--', 'crates', 'Cargo.toml',
                      'Cargo.lock', 'rust-toolchain.toml', '.cargo').decode().splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard', '--', 'crates',
                       'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo').decode().splitlines())
    assert changed == set(FINAL['changed_source_paths'])
    runtime = Path((selected / 'build/fe2o3_runtime.path').read_text().strip())
    kfd = Path((selected / 'build/fe2o3_kfd.path').read_text().strip())
    full, observed = audit_cpu(selected, sources, str(runtime), str(kfd))
    runtime_hash = sha(runtime.read_bytes())
    for phase in ('before', 'after'):
        assert manifest((selected / f'tests/fe2o3_runtime-{phase}.sha256').read_bytes()) == {
            str(runtime): runtime_hash}
    metadata = audit_metadata(proposal)
    audit_workflow(workflow, proposal, metadata)
    baseline = audit_baseline(full, observed, metadata)
    kfd_receipt = audit_kfd_reuse(selected, sources, kfd)
    rebuild_receipt = audit_artifacts_and_rebuild()
    hardware_receipt = audit_hardware(ROOT / hardware, selected)
    check_sources(sources)
    assert sha(runtime.read_bytes()) == runtime_hash
    assert sha(kfd.read_bytes()) == kfd_receipt['executable_sha256']
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    result = dict(
        accepted=True, audited_at=datetime.now(timezone.utc).isoformat(), baseline=BASE,
        attempt=attempt, source_proposal=proposal, source_workflow=workflow, hardware=hardware,
        audit_sha256=sha(Path(__file__).read_bytes()), controller_sha256=CONTROLLER_SHA,
        source_snapshot_sha256=sha(snapshot), source_files=len(sources),
        runtime=dict(passed=FINAL['runtime_passed'], ignored=FINAL['runtime_ignored'],
                     failed=0, exact_roster=True, executable_sha256=runtime_hash),
        added_tests=baseline['added_tests'], kfd=kfd_receipt,
        source_controls=32, strict_clippy=True, no_default_check=True,
        examples=FINAL['examples'], hardware_receipt=hardware_receipt,
        baseline_receipt=baseline, artifact_rebuild=rebuild_receipt,
        hardware_feature_check=True, performance_acceptance=False, formal_refinement=False)
    with (ROOT / 'qualification.json').open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
