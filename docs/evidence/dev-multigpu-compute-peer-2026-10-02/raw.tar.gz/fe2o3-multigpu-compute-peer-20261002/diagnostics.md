# Diagnostic Attempts

Only the final audit's selected attempt and hardware campaign can qualify this
checkpoint. Earlier outputs are retained to explain the corrections, not counted
as passing qualification.

- Precheck attempt-01: a new backend test lacked the BackendCancellationV1 import.
- Attempt-02: Context incorrectly expected the mock's direct host-buffer read to
  enforce an ordinary submission read lease. It now tests ordinary typed Read
  submission exclusion and unchanged backend submit count. Backend queued fixtures
  incorrectly dirtied authenticated H2dReady inputs. They now use a real disjoint
  persistent FIFO predecessor. Scripted peer completion must not increment the
  native-DMA counter; exact owner restoration and successful status are checked
  independently. No production readiness or counter rule was weakened.
- The old attempt-02 executable's diagnostic full suite finished with 2,061 passed,
  eight failed and 32 ignored. The failures were exactly the focused failures.
  This run deliberately was not a source-stable qualification attempt.
- Attempt-03: 31 of 32 compute_peer-filter tests passed. The remaining cancellation
  test used a success-only flush helper after cancelling its producer. It now
  requires the exact Quiescent Native diagnostic and independently checks failed
  result status, root quiescence and released dependency retention.
- All other focused filters passed in both diagnostic builds.

The initial diagnostic controller inherited its parent's environment. Before
packaging, three diagnostic environment.txt files were mechanically restricted
to the documented non-secret build-variable allowlist; removed variable names,
not values, are listed in diagnostic-environment-redaction.json. These diagnostic
files cannot satisfy the selected-attempt audit. The final controller starts
through env -i and the auditor requires the exact minimal environment allowlist.
No non-allowlisted inherited environment values are part of the published packet.

The first attempt to apply the generated metadata patch was rejected because
apply_patch does not accept unified-diff hunk line numbers. Removing only those
hunk coordinates allowed the identical proposed content to apply; the original
verifier independently confirmed every byte and permitted AST literal edit.

The manual metadata verifier label "applied" collided with its own temporary
applied-audit.json filename. That receipt was preserved as
manual-applied-audit.json. A workflow invocation refused to start until it was
renamed; no guard ran in that refused invocation. Acceptance requires the fresh
before/after workflow receipts, not this manual receipt.

All agents were limited to scoped source edits, formatting or read-only review.
The primary exclusively executed builds, tests, source controls, SSH and Git writes.

A late read-only review questioned initialized/storage checks at metadata-only
admission. Full-path review withdrew the suspected release blocker: successful
native allocation zeroes and initializes storage before return, no production
transition resets that flag, destination compute custody is rejected, and exact
ordered pending copy custody must settle first. Progress rechecks initialization,
full extents and both concrete Device owner slots before extracting either.
Recovered failed-recycle storage fails that pre-extraction check conclusively.
No normal successful-public-operation failure was demonstrated and no frozen
source was changed. This is code review, not new exhaustive private-state proof.
