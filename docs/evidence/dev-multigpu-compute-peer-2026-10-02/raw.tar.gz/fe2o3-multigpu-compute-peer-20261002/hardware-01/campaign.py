#!/usr/bin/env python3
"""Queued compute/peer/readback correctness on freshly idle GPUs, not a benchmark."""
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/harsh/.codex-tmp/fe2o3-r61-execution')
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
       '-o', 'StrictHostKeyChecking=yes', 'mi300x']
IDS = ['0xab83d2ffef0d3cdf', '0xd2e26fef80cf5c33', '0x189ca857de1ef2fb',
       '0x54f88318ca05093d', '0xb7baafd0fb173d8e', '0x10a254ce4987e716',
       '0x53691ef168a0147d']
CARDS = ['card' + str(index) for index in range(1, 8)]
BD = ['0000:26:00.0', '0000:46:00.0', '0000:65:00.0', '0000:85:00.0',
      '0000:A6:00.0', '0000:C6:00.0', '0000:E5:00.0']
AVAILABILITY = ['/opt/rocm/bin/rocm-smi', '--showuse', '--showmeminfo', 'vram',
                '--showuniqueid', '--showbus', '--showpids', '--json']
BASELINE = None
PROFILES = [
    ('compute-sharded-2', IDS[5:]),
    ('compute-sharded-3', IDS[4:]),
    ('compute-sharded-5', IDS[2:]),
    ('compute-sharded-7', IDS),
    ('compute-sharded-7-reverse', IDS[::-1]),
]
CASES = [(name + '-queued-round-' + str(round_index), 'compute-sharded',
          ['--queued-compute', '--round', str(round_index)], ids)
         for name, ids in PROFILES for round_index in (0, 1)] + [
    ('compute-sharded-2-joined-round-0', 'compute-sharded', ['--round', '0'], IDS[5:]),
    ('compute-sharded-7-joined-round-1', 'compute-sharded', ['--round', '1'], IDS),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_receipt(name, argv):
    folder = ROOT / name
    receipt = json.loads((folder / 'result.json').read_text())
    stdout = (folder / 'stdout').read_bytes()
    stderr = (folder / 'stderr').read_bytes()
    assert receipt['argv'] == argv
    assert receipt['stdout_sha256'] == sha(stdout) and receipt['stderr_sha256'] == sha(stderr)
    assert receipt['exit_code'] == 0, (name, receipt, stderr)
    assert not receipt['timed_out'] and receipt['local_process_group_absent'], (name, receipt)
    return receipt, stdout, stderr


def capture(name, argv):
    process = subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'capture.py'), name, *argv],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    receipt, stdout, stderr = read_receipt(name, argv)
    assert process.returncode == receipt['exit_code'], (name, receipt, stderr)
    return stdout.decode()


def remote_argv(argv, bound='30s'):
    return SSH + [shlex.join(['/usr/bin/timeout', '--kill-after=5s', bound, *argv])]


def remote(name, argv, bound='30s'):
    return capture(name, remote_argv(argv, bound))


def initial_baseline():
    # Primary must capture a new receipt here immediately before this campaign.
    receipt, stdout, stderr = read_receipt('initial-availability', remote_argv(AVAILABILITY))
    assert not stderr
    finished = datetime.fromisoformat(receipt['finished'])
    age = (datetime.now(timezone.utc) - finished).total_seconds()
    assert 0 <= age <= 300, 'initial availability is stale; capture a fresh campaign packet'
    return json.loads(stdout)


def admit(name):
    assert BASELINE is not None
    state = json.loads(remote(name + '-availability', AVAILABILITY))
    for card, uid, bdf in zip(CARDS, IDS, BD):
        assert state[card]['Unique ID'] == uid and state[card]['PCI Bus'] == bdf
        assert BASELINE[card]['Unique ID'] == uid and BASELINE[card]['PCI Bus'] == bdf
        assert state[card]['GPU use (%)'] == BASELINE[card]['GPU use (%)'] == '0'
        assert state[card]['VRAM Total Memory (B)'] == BASELINE[card]['VRAM Total Memory (B)']
        assert state[card]['VRAM Total Used Memory (B)'] == BASELINE[card]['VRAM Total Used Memory (B)']
    assert state['system'] == BASELINE['system'], 'changed PID roster; stop and re-admit'
    mapping = remote(name + '-attachments', ['/opt/rocm/bin/rocm-smi', '--showpids', '--showpidgpus'])
    # JSON omits the PID->GPU map; require the counted text records independently.
    records = {}
    for match in re.finditer(r'^PID (\d+) is using (\d+) DRM device\(s\)(:)?\n(?:([0-9 ]+)\n)?', mapping, re.M):
        pid, count, colon, devices = match.groups()
        devices = [] if devices is None else devices.split()
        assert int(count) == len(devices) and bool(colon) == bool(devices)
        assert pid not in records and not {str(index) for index in range(1, 8)}.intersection(devices)
        records[pid] = devices
    assert {'PID' + pid for pid in records} == set(state['system']), (records, state['system'])
    for pid, devices in records.items():
        assert int(state['system']['PID' + pid].split(',')[1]) == len(devices)
    memory = remote(name + '-host-memory', ['/usr/bin/cat', '/proc/meminfo'])
    available = re.findall(r'^MemAvailable:\s+(\d+) kB$', memory, re.M)
    assert len(available) == 1 and int(available[0]) >= 8 * 1024 * 1024
    return state


@lru_cache(maxsize=1)
def global_digests():
    # Independent little-endian f32 reference; no Rust output is used as input.
    digests = tuple(sha(b''.join(struct.pack('<f', global_index + 3 + 131073 * round_index)
                               for global_index in range(65537)))
                    for round_index in (0, 1))
    assert digests[0] != digests[1]
    return digests


def expected(kind, flags, ids):
    assert kind == 'compute-sharded'
    queued = flags[0] == '--queued-compute'
    round_flags = flags[1:] if queued else flags
    assert round_flags in (['--round', '0'], ['--round', '1'])
    round_index = int(round_flags[1])
    count = len(ids)
    assert 2 <= count <= 8 and len(set(ids)) == count
    quotient, remainder = divmod(65537, count)
    sizes = [quotient + int(index < remainder) for index in range(count)]
    offsets = [index * quotient + min(index, remainder) for index in range(count)]
    padded = [((size * 4 + 4095) // 4096) * 4096 for size in sizes]
    assert sum(sizes) == 65537 and offsets[-1] + sizes[-1] == 65537
    assert all(size > 0 for size in sizes) and sum(padded) <= 286720
    fields = dict(schema='fe2o3.sharded-vecadd-capture-smoke.v1',
        authority='qualification-sharded-vecadd-v1', devices=str(count),
        unique_ids=','.join(ids), round=str(round_index), rounds='1',
        logical_elements='65537', logical_bytes='262148',
        shard_ranges=','.join(f'{offset}:{size}:{physical}'
                              for offset, size, physical in zip(offsets, sizes, padded)),
        padded_bytes=str(sum(padded)), launches=str(count), compute_receipts=str(count),
        transfer_receipts=str(2 * count), completion_receipts=str(3 * count),
        compute_admission='all-before-explicit-progress', compute_join='exact-succeeded-restored',
        peer_copies=str(count), dependent_readbacks=str(count), capture_ranges=str(count),
        captured_bytes=str(sum(padded)), abi_bytes='48', kernel='vecadd', journal='enabled',
        host_output_installations='0', c_initial='-1', incoming_sentinel='full-byte-pass',
        output='full-byte-pass', padding='full-byte-pass', coverage='exact-contiguous-disjoint',
        global_sha256=global_digests()[round_index],
        admission='all-transfers-pending-before-cutoff', public_events='released-before-cutoff',
        native_transport='authenticated-pending-peer', native_counter_before='0',
        native_counter_observed='false', native_counter_after='unobserved',
        source_preservation='unobserved', allocation_reuse='false', contexts='one-per-process',
        drain='pending-group', capture='coherent-host-group', physical_overlap='unmeasured',
        cleanup='owned-shutdown-explicit', performance_acceptance='false', formal_refinement='false')
    if queued:
        fields.update(schema='fe2o3.sharded-vecadd-queued-capture-smoke.v1',
                      compute_admission='may-publish-before-cutoff', compute_join='owned-drain',
                      compute_api='producer-aware', compute_dependency='exact-event',
                      compute_progress='dependent-readback-streams', retained_submissions=str(3 * count))
    return fields


def pass_fields(output):
    lines = output.splitlines()
    assert len(lines) == 1 and lines[0].startswith('PASS '), output
    fields = {}
    for token in lines[0].split()[1:]:
        key, value = token.split('=', 1)
        assert key and value and key not in fields
        fields[key] = value
    return fields


def main():
    global BASELINE
    assert sys.flags.isolated and sys.flags.dont_write_bytecode and not sys.flags.optimize
    assert len(sys.argv) in (1, 2)
    attempt = sys.argv[1] if len(sys.argv) == 2 else 'attempt-01'
    assert re.fullmatch(r'attempt-[0-9]+', attempt)
    assert not (ROOT / 'campaign.json').exists()
    BASELINE = initial_baseline()
    checks = ROOT.parent / attempt / 'checks'
    binaries = {}
    for kind, receipt, basename in [
        ('compute-sharded', 'compute-sharded-witness.sha256', 'gfx942-runtime-sharded-vecadd-capture-smoke')]:
        digest, path = (checks / receipt).read_text().strip().split(maxsplit=1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest)
        local = REPO / path
        assert local == REPO / 'target/debug/examples' / basename
        assert sha(local.read_bytes()) == digest
        binaries[kind] = dict(local=str(local), sha256=digest)
    completed, errors = [], []
    directory = None
    cleaned = False
    try:
        admit('baseline')
        candidate = remote('create-scratch', ['/usr/bin/mktemp', '-d', '/tmp/fe2o3-multigpu-compute-peer-20261002-XXXXXX']).strip()
        assert re.fullmatch(r'/tmp/fe2o3-multigpu-compute-peer-20261002-[A-Za-z0-9]{6}', candidate)
        directory = candidate
        for kind, binary in binaries.items():
            binary['remote'] = directory + '/' + kind + '-witness'
            capture('upload-' + kind, ['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=yes', binary['local'], 'mi300x:' + binary['remote']])
            hashed = remote('initial-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
            assert hashed.split() == [binary['sha256'], binary['remote']]
        for name, kind, flags, ids in CASES:
            admit(name)
            output = remote(name, ['/usr/bin/prlimit', '--core=0', '--', '/usr/bin/env',
                '-u', 'HIP_VISIBLE_DEVICES', '-u', 'ROCR_VISIBLE_DEVICES', '-u', 'CUDA_VISIBLE_DEVICES',
                '-u', 'GPU_DEVICE_ORDINAL', binaries[kind]['remote'], *flags, *ids], '180s')
            fields = pass_fields(output)
            required = expected(kind, flags, ids)
            assert fields == required, (name, fields, required)
            assert not (ROOT / name / 'stderr').read_bytes()
            admit(name + '-post')
            completed.append(dict(name=name, fields=fields))
            print(name + ' PASS', flush=True)
    except Exception as error:
        errors.append(repr(error))
    finally:
        if directory is not None:
            try:
                paths = [directory + '/compute-sharded-witness']
                probe = ('import json,os,sys; from pathlib import Path; '
                    'paths=set(sys.argv[1:]); found=[]\n'
                    'for item in Path("/proc").iterdir():\n'
                    ' if item.name.isdigit():\n'
                    '  try:\n'
                    '   exe=os.readlink(item/"exe")\n'
                    '  except (FileNotFoundError,PermissionError,ProcessLookupError):\n'
                    '   continue\n'
                    '  if exe in paths or exe.removesuffix(" (deleted)") in paths: found.append(int(item.name))\n'
                    'print(json.dumps({"owned_executable_pids":found})); sys.exit(bool(found))')
                observed = remote('final-owned-processes', ['/usr/bin/python3', '-I', '-B', '-c', probe, *paths])
                assert json.loads(observed) == {'owned_executable_pids': []}
                for kind, binary in binaries.items():
                    if 'remote' in binary:
                        try:
                            hashed = remote('final-hash-' + kind, ['/usr/bin/sha256sum', binary['remote']])
                            assert hashed.split() == [binary['sha256'], binary['remote']]
                        except Exception as error:
                            errors.append('final hash ' + kind + ': ' + repr(error))
                remote('remove-owned-executables', ['/usr/bin/rm', '-f', '--', *paths])
                remote('remove-owned-directory', ['/usr/bin/rmdir', '--', directory])
                remote('confirm-owned-directory-absent', ['/usr/bin/test', '!', '-e', directory])
                cleaned = True
            except Exception as error:
                errors.append('cleanup: ' + repr(error))
        try:
            admit('final')
        except Exception as error:
            errors.append('final admission: ' + repr(error))
        result = dict(accepted=not errors and len(completed) == len(CASES) and cleaned,
            errors=errors, completed=completed, expected_cases=len(CASES), binaries=binaries,
            selected_build_attempt=attempt, owned_directory=directory,
            owned_cleanup_complete=cleaned, exclusive_reservation=False,
            performance_acceptance=False, formal_refinement=False,
            limitations=['point observations, not continuous attachment census',
                        'finite trusted-artifact qualification, not general kernel authority',
                        'finite ordinary producer chain, not arbitrary dependency graph support',
                        'compute may eagerly publish before cutoff; physical overlap is unmeasured',
                        'native completion counter after cutoff is unobserved',
                        'one context per process; no allocation reuse across rounds',
                        'ACQUIRE_VM admission lasts until process exit; same-process reopen is unsupported',
                        'postcopy source preservation is not observed'])
        with (ROOT / 'campaign.json').open('x') as target:
            json.dump(result, target, indent=2)
            target.write('\n')
        print(json.dumps(result), flush=True)
    return 0 if result['accepted'] else 1


if __name__ == '__main__':
    sys.exit(main())
