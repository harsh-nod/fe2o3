# Bound-Batch Preparation Qualification

Working repository: `/home/harsh/.codex-tmp/fe2o3-r61-execution`.
Final source: `fdff00d15abc68b73a1cad905985522fbde59578`.
Production implementation parent: `b416a79f99230836a8c52ec623c8560efc5d7204`.
Toolchain: CPU `nightly-2026-04-03`; pinned Verus
`0.2026.08.09.92f466f` with Rust 1.97.1 and its sibling Z3.

The new proof has a ten-file closure and two explicit trusted standard-library
conversion contracts. It does not use `--no-cheating`. The exact supplement
SHA-256 is `5822ed2870b5c5572d0a97045bcb78b0a8b8966f123ee4267a121fca6a8eceea`.
Vec-to-box preserves the sequence; boxed-slice-to-array succeeds exactly at N
and otherwise returns its input. Neither contract constrains allocation, address,
cost, allocator failure/panic behavior or termination. Both installed std source
versions are retained under `std-audit/`; their hashes are in `final-audit.json`.
The executable loop proves each conversion's exact cardinality, rather than
assuming a prepared packet/retention authority.

From the signed source checkout, choose NEW absolute output directories:

```sh
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-batch-bind.py --output "$BIND_OUT" --verus "$VERUS"
python3 -I -B crates/fe2o3-runtime-model/verus/check-completion-batch-bind.py --aql --output "$AQL_OUT" --verus "$VERUS"
```

The retained `qualify.py` runs 15 CPU/static stages and five affected-root
positive regressions, with before/after source equality and exact test counts.
Its arguments are repository, sibling reference campaign directory name and NEW
sibling output directory name. Recorded commands are authoritative in each
`record.json`. Builds and solvers were serialized; all use owned process groups.

The five old roots keep their prior trust profiles: cancellation and event
binding use `--no-cheating`; issuer, batch release and source rollback retain
their own two standard-library reservation contracts. Their old mutation suites
are NOT rerun in this packet. No new box assumption is imported into them.

`bind-final-1` is deliberately retained as REJECTED: Verus caught the short-packet
mutation but also emitted a recommendation diagnostic for a proof-side index.
The classifier was not relaxed. The follow-up source adds a length assertion
and a bounds guard before that ghost index, then reruns the complete campaign.
`dev-full-*` are development iterations, not qualification. Initial development
compile errors are available in the tool transcript, not claimed as retained
campaigns. `dev-aql` and `dev-clippy` are also development checks.

`audit-final.py` independently checks signed Git blobs, source equality, exact
relocation/mutant membership and hashes, selector/command linkage, trust flags,
positive counts and live absence of every recorded process group. Replaying its
process-ID checks later can fail on PID reuse; retained timestamps distinguish
the original observation from a later host state.

Scope: exact host preparation/refusal/commit semantics and scoped CPU allocation
observations. Not proved: native address/code ownership, geometry-constructor
reachability, byte serialization, native publication/receipt truth, firmware,
device memory ordering, allocator abort/unwind recovery or HIP/HSA performance.
No MI300X work or remote artifacts were created by this qualification.
