#!/usr/bin/env python3
"""Serial signed-source CPU/static and affected-root positive qualification."""
import json
import os
from pathlib import Path
import re
import runpy
import signal
import sys

assert len(sys.argv) == 4
repo = Path(sys.argv[1]).resolve()
root = Path(__file__).resolve().parent
reference_name, output_name = sys.argv[2:]
assert all(Path(name).name == name and name not in (".", "..") for name in (reference_name, output_name))
out = root / output_name
assert out.parent == root
out.mkdir()
os.chdir(repo)
v = Path("crates/fe2o3-runtime-model/verus")
campaign = runpy.run_path(str(repo / v / "check-completion-batch-bind.py"))["campaign"]()
classifier = campaign.inherited()
leaf = classifier.inherited()
prior = leaf.load("cpu_source", repo / leaf.PRIOR, leaf.PRIOR_SHA)
prior.INPUTS = ["Cargo.toml", "Cargo.lock", "rust-toolchain.toml", ".cargo", "crates", "examples", "tests",
               str(classifier.LEAF), str(classifier.LEAF.with_name("test-run.py")), str(leaf.PRIOR)]
owner = leaf.load("cpu_owner", repo / prior.CONTROLLER, prior.CONTROLLER_SHA)
for number in owner.SIGNALS:
    signal.signal(number, owner.interrupted)
before = json.loads((root / reference_name / "source-before.json").read_text())


def current():
    prior.clean_source()
    measured = dict(commit=prior.git("rev-parse", "HEAD").decode().strip(), inputs=prior.snapshot())
    prior.need(measured == before, "signed source continuity")
    return measured


prior.save(out / "source-before.json", current())
env = dict(os.environ, CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="2")
prior.save(out / "environment.json", {key: env.get(key) for key in (
    "PATH", "CARGO_TARGET_DIR", "CARGO_INCREMENTAL", "CARGO_BUILD_JOBS", "RUSTFLAGS", "RUSTDOCFLAGS", "RUSTUP_TOOLCHAIN")})
cargo = ["prlimit", "--core=0:0", "--", "cargo", "+nightly-2026-04-03"]
phases = [
    ("prepare-calibration", [sys.executable, "-I", "-B", str(v / "test-completion-batch-bind.py")], "PASS: completion batch preparation calibration (5 groups)\n"),
    ("issue-calibration", [sys.executable, "-I", "-B", str(v / "test-completion-event-issue.py")], "PASS: completion event issuance calibration (6 groups)\n"),
    ("binding-calibration", [sys.executable, "-I", "-B", str(v / "test-completion-event-bind.py")], "PASS: completion event binding calibration (6 groups)\n"),
    ("release-calibration", [sys.executable, "-I", "-B", str(v / "test-completion-event-batch-release.py")], "PASS: completion event batch release calibration (6 groups)\n"),
    ("rollback-calibration", [sys.executable, "-I", "-B", str(v / "test-completion-source-rollback.py")], "PASS: completion source rollback calibration (7 groups)\n"),
    ("rustc", ["rustc", "+nightly-2026-04-03", "--version", "--verbose"], None),
    ("aql", cargo + ["test", "-p", "fe2o3-aql", "--all-targets"], [(16, 0, 0, 0, 0), (31, 0, 0, 0, 0)]),
    ("kfd", cargo + ["test", "-p", "fe2o3-kfd", "--all-features", "--lib", "--", "--skip", "construction_primary", "--test-threads=2"], [(1439, 0, 0, 0, 320)]),
    ("runtime", cargo + ["test", "-p", "fe2o3-runtime", "--all-features", "--lib", "--", "--test-threads=2"], [(1828, 0, 30, 0, 0)]),
    ("doctests", cargo + ["test", "-p", "fe2o3-kfd", "-p", "fe2o3-runtime", "-p", "fe2o3-runtime-model", "--all-features", "--doc"], [(42, 0, 0, 0, 0), (9, 0, 0, 0, 0), (44, 0, 0, 0, 0), (29, 0, 0, 0, 0)]),
    ("clippy", cargo + ["clippy", "-p", "fe2o3-aql", "-p", "fe2o3-kfd", "-p", "fe2o3-runtime", "--all-features", "--all-targets", "--", "-D", "warnings"], None),
    ("production", cargo + ["check", "-p", "fe2o3-kfd", "-p", "fe2o3-runtime", "--no-default-features", "--lib"], None),
    ("format", cargo + ["fmt", "--all", "--", "--check"], None),
    ("included-format", ["rustfmt", "+nightly-2026-04-03", "--edition", "2024", "--check", "--config", "skip_children=true",
        "crates/fe2o3-aql/src/preparation_body.rs", "crates/fe2o3-kfd/src/queue_completion/batch_bind_body.rs",
        "crates/fe2o3-kfd/src/queue_completion/batch_bind_tests.rs"], None),
    ("diff", ["git", "diff", "--check"], None),
]
results = {}
for name, command, expected in phases:
    current()
    status, stdout, stderr = owner.run_owned(command, 600, out / name, env)
    summaries = [tuple(map(int, row)) for row in re.findall(
        r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", stdout)]
    passed = status == 0 and (expected is None or (stdout == expected and not stderr if isinstance(expected, str) else summaries == expected))
    results[name] = dict(passed=passed, status=status, test_summaries=summaries)
    prior.save(out / (name + "-result.json"), results[name])
    print(name + (": PASS" if passed else ": FAIL"), flush=True)
    current()
    prior.need(passed, "failed qualification: " + name)

verus = Path("/home/harsh/.codex-tmp/r56-verus-0.2026.08.09/install/verus-x86-linux/verus")
for name, trusted in (("completion-bound-cancel", False), ("completion-event-bind", False),
                      ("completion-event-issue", True), ("completion-event-batch-release", True),
                      ("completion-source-rollback", True)):
    current()
    old = runpy.run_path(str(repo / v / ("check-" + name + ".py")))["campaign"]()
    command = ["/usr/bin/timeout", "--foreground", "--signal=TERM", "--kill-after=5", "120", str(verus),
               "--crate-type", "lib", "--triggers-mode", "silent", "--output-json", "--error-format=json",
               "--no-report-long-running", "--num-threads", "4", "--multiple-errors", "0",
               *([] if trusted else ["--no-cheating"]), str(repo / old.PROOF)]
    status, stdout, stderr = owner.run_owned(command, 130, out / name, dict(env, VERUS_Z3_PATH=str(verus.parent / "z3")))
    passed = old.inherited().proof_positive(status, stdout, stderr, prior.VERIFIER, old.EXPECTED,
                                           {str((repo / path).resolve()) for path in old.FILES})
    results[name] = dict(passed=passed, status=status, expected=old.EXPECTED, no_cheating=not trusted,
                         files={str(path): before["inputs"][str(path)] for path in old.FILES})
    prior.save(out / (name + "-result.json"), results[name])
    print(name + (": PASS" if passed else ": FAIL"), flush=True)
    current()
    prior.need(passed, "failed proof regression: " + name)
prior.save(out / "source-after.json", current())
prior.save(out / "results.json", results)
