#!/usr/bin/env python3
"""Source/offline calibration controls only; never a compiler or solver launch."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('numeric_qualification_controls', HERE / 'qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)


class Controls(unittest.TestCase):
    def test_all_final_bindings_are_unbound(self):
        self.assertIsNone(q.CANDIDATE)
        self.assertIsNone(q.SIGNED_SOURCE)
        self.assertIsNone(q.CPU_REFERENCES)
        with self.assertRaisesRegex(ValueError, 'remains unbound'):
            q.snapshot()

    def test_no_cli_or_environment_pin_override(self):
        data = (HERE / 'qualify.py').read_text()
        self.assertNotIn('os.environ', data)
        self.assertNotIn("add_argument('--candidate", data)
        self.assertNotIn("add_argument('--cpu", data)

    def test_complete_closed_plan(self):
        value = q.plan()
        self.assertEqual(len(value['stages']), 23)
        self.assertEqual(len(value['negative_candidates']), 17)
        self.assertEqual(len(value['equivalent_controls']), 1)
        self.assertEqual(value['projection_bytes'], 93698)
        self.assertEqual(value['command_bounds_sum_seconds'], 2990)
        self.assertEqual(value['solver_invocations_if_complete'], 21)
        self.assertLess(value['calculated_physical_allowance_bytes'], q.b.OUTPUT_LIMIT)
        self.assertEqual([row['kind'] for row in value['stages']].count('positive'), 3)
        for row in value['stages']:
            if row['kind'] == 'release':
                continue
            argv = row['argv']
            self.assertIn('--no-cheating', argv)
            self.assertNotIn('--no-verify', argv)
            self.assertNotIn('--verify-function', argv)
            self.assertNotIn('--verify-root', argv)
            self.assertEqual(argv[argv.index('--num-threads') + 1], '4')
            self.assertEqual(argv[argv.index('--multiple-errors') + 1], '1')

    def test_all_complete_two_input_projections_unchanged(self):
        negatives, equivalents, projections = q.constructed()
        self.assertEqual(len(projections), 20)
        self.assertTrue(all(set(files) == set(q.b.FILES) for files in projections.values()))
        self.assertEqual(projections['case'], projections['relocated'])
        original = q.original_constructed()
        self.assertEqual((negatives, equivalents, projections), original)

    def test_actual_seventeen_calibrated_raw_rows(self):
        cases = q.plan()['negative_candidates']
        with patch.object(q, 'HERE', q.AC):
            for case in cases:
                folder = q.AC / 'capture-attempt-1/commands' / case
                value = q.observe_mutant(folder, q.b.verifier())
                self.assertTrue(value['signed_numeric_negative_accepted'])
                self.assertFalse(value['calibration']['qualified_kill'])
                self.assertEqual((value['calibration']['verified'], value['calibration']['errors']), (6, 1))
                self.assertEqual(value['calibration']['helper_only_unreachable_adapter_case'],
                                 case == 'sleep-absent-remaining-selected')

    def test_equivalent_not_a_negative(self):
        case = next(iter(q.plan()['equivalent_controls']))
        with self.assertRaisesRegex(ValueError, 'seventeen'):
            q.observe_mutant(q.AC / 'capture-attempt-1/commands' / case, q.b.verifier())

    def test_historical_raw_capture_cannot_be_qualified_directly(self):
        value = json.loads((q.AC / 'capture-attempt-1/result.json').read_bytes())
        with self.assertRaises((ValueError, KeyError)):
            q.qualification_summary(value, '0' * 64)

    def synthetic_result(self):
        rows = []
        for item in q.plan()['stages']:
            row = {**item, 'accepted': True}
            if item['kind'] == 'observation':
                row['observation'] = {'signed_numeric_negative_accepted': True, 'case': item['case'],
                                      'calibration': {'qualified_kill': False}}
            rows.append(row)
        return {'raw_capture_completed': True, 'rows': rows, 'errors': [], 'positive_counts': [7] * 4,
                'qualified_kills': 0, 'signed_qualification_accepted': False}

    def test_summary_exact_scope_and_counts(self):
        value = q.qualification_summary(self.synthetic_result(), '0' * 64)
        self.assertEqual(value['qualified_numeric_negatives'], 17)
        self.assertEqual(len(value['equivalent_controls']), 1)
        self.assertFalse(value['std_adapter_proved'] or value['whole_cursor_proved'] or value['scheduler_proved'])
        self.assertEqual(value['historical_raw_qualified_kills'], 0)

    def test_partial_wrong_count_duplicate_false_or_promoted_history_rejects(self):
        original = self.synthetic_result()
        changes = [dict(positive_counts=[7] * 3), dict(positive_counts=[6] * 4), dict(qualified_kills=17),
                   dict(errors=['failure']), dict(rows=original['rows'][:-1])]
        for change in changes:
            with self.assertRaises(ValueError):
                q.qualification_summary({**original, **change}, '0' * 64)
        for mutation in ('duplicate', 'false', 'historical'):
            value = copy.deepcopy(original)
            negative = next(row for row in value['rows'] if row['kind'] == 'observation')
            if mutation == 'duplicate':
                value['rows'].append(copy.deepcopy(negative))
            elif mutation == 'false':
                negative['observation']['signed_numeric_negative_accepted'] = False
            else:
                negative['observation']['calibration']['qualified_kill'] = True
            with self.assertRaises(ValueError):
                q.qualification_summary(value, '0' * 64)

    def test_complete_signed_tree_byte_mode_and_roster_bridge(self):
        tree = {'a': {'mode': '100644', 'kind': 'blob', 'blob': '1' * 40},
                'b': {'mode': '100755', 'kind': 'blob', 'blob': '2' * 40}}
        raw = b'100644 blob ' + b'1' * 40 + b'\ta\0' + b'100755 blob ' + b'2' * 40 + b'\tb\0'
        q.tree_bridge(raw, tree)
        for bad in (raw + raw, raw.split(b'\0')[0] + b'\0', raw.replace(b'100755', b'100644'),
                    raw.replace(b'2' * 40, b'3' * 40), raw.replace(b'\tb\0', b'\tc\0')):
            with self.assertRaises(ValueError):
                q.tree_bridge(bad, tree)

    def test_original_managed_lifecycle_and_classifiers_are_reused(self):
        self.assertEqual(q.b.sha(q.AC / 'capture.py'), q.AC_SHA)
        self.assertIs(q.ac.execute, q.original_execute)
        self.assertIs(q.ac.observe_mutant, q.observe_mutant)
        self.assertIs(q.ac.snapshot, q.snapshot)
        self.assertEqual(q.ac.TOTAL, 3600)
        self.assertEqual(q.ac.STREAM_LIMIT, 256 * 1024)
        self.assertEqual(q.ac.STAGE_METADATA_LIMIT, 64 * 1024)


if __name__ == '__main__':
    unittest.main(verbosity=2)
