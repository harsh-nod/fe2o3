# Signed Numeric Qualification Scaffold

Source-only, unprepared, unsigned and unexecuted. CANDIDATE, SIGNED_SOURCE and
CPU_REFERENCES are literal None. No command-line or environment override can
satisfy them. Their final revision requires root review after fresh final
candidate CPU qualification and separately reviewed signing. R5 is NS3
development evidence and cannot satisfy the NS4 source bridge.

This three-file adapter reuses the exact frozen AC capture module and changes
only its namespace, plan, snapshot, constructed-source check and negative
classifier callbacks. The original managed execute function remains exact:
signals, process groups, explicit environment, release-finally, independently
attempted closing continuity/census, raw handling, resource gates, and limits
are inherited. It writes its honest raw lifecycle result with zero historical
qualified kills and signed acceptance false. A separate, compact final result
can award fresh signed numeric qualification only after all strict callbacks,
all 23 stages, complete continuity and four full 7/0 positives pass. It does
not rewrite or promote any historical capture.

The plan uses 20 complete two-input projections, 17 intended 6/1 negatives,
one result-equivalent 7/0 control, canonical and independently relocated full
7/0 positives, closing full 7/0 positive and release brackets. There are 21
verifier invocations, no selected function/root flags, no std trust bridge,
four threads, reporting threshold one and --no-cheating. Commands retain
120-second inner/130-second managed limits, summing 2,990 seconds, with the
3,600-second owner plus external 30-second grace. Metadata preparation uses
four bounded 30-second Git groups under 900 seconds plus external grace.

CPU inputs must be complete accepted final-candidate evidence, not a prefix:
20 accepted stages, distinct 1,841/1,847 complete feature rosters and retained
ELF/dep-info, original collected source/raw and complete durable archive.
Both archives are validated using the existing reviewed transport helper.
Root's full CPU command/raw/census replay and outer plus direct-inner security
scans are separately pinned external prerequisites; this owner does not add
another generic CPU replay/parser framework or infer inspection of tar data
from the stdout filename. These references are intentionally unresolved.

The complete 6,398-entry source record is checked against every transported
and collected source byte/mode, then every materialized signed-source byte and
Git executable bit. The selected signed Git tree must match all corresponding
blob identities, not merely the six overlay paths. The final native buffers
must equal NS4. Linked detached HEAD/index and the signature are bound. The
two numeric proof inputs must still equal the original builder's preimages.

Per-stage snapshots repeat only source inventory digest/count and reference
digests, never the huge complete CPU or archive manifest. The physical
allowance counts each stage's classification twice (beside its receipt/raw
and in the final result), bounded raw streams and four compact snapshot
copies. The final extra qualification record is checked against the actual
64 MiB combined footprint; final binding changes must remeasure encoded
snapshots before metadata preparation. Bounds remain boundary checks, not
continuous quotas. No automatic CPU/solver next phase or cleanup exists.

The strict existing calibration is unchanged, including source spans and
6/1 full schema. Its qualified_kill flag remains false inside each observation;
fresh signed authority comes only from the new complete campaign. The absent
None case tests the broader numeric helper contract and is unreachable through
the current native adapter. Every other mutation remains a numeric-result
claim, not proof of reachable native faults. Duration/Instant conversion,
the complete cursor/constructor, scheduler, hardware and performance remain
outside this formal claim. The original 16,800-case native oracle is unchanged.

Only source/offline controls may be run before root reviews the complete draft.
No signing, metadata preparation, CPU, compiler, solver, GPU or remote command
is authorized by this scaffold.

Initial source-control invocation b4de15 rejected one test-fixture namespace
error: the test changed HERE before computing the owner-file budget. The
production owner was unexecuted. The fixture now computes its case roster
before the historical-source path override; no acceptance predicate changed.
