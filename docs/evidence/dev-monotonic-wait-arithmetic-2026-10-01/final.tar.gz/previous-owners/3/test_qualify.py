#!/usr/bin/env python3
"""Source/offline calibration controls only; never a compiler or solver launch."""
import copy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('numeric_qualification_controls', HERE / 'qualify.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)


class Controls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.refs = {name: {'path': str(path), 'sha256': value}
                    for name, (path, value) in q.RECOVERED_REFERENCES.items()}
        cls.transport = json.loads(Path(cls.refs['transport-result']['path']).read_bytes())
        cls.collection = json.loads(Path(cls.refs['collection']['path']).read_bytes())
        cls.record = json.loads(Path(cls.refs['source-record']['path']).read_bytes())
        cls.prepared = json.loads(Path(cls.refs['transport-prepared']['path']).read_bytes())
        cls.root = json.loads(Path(cls.refs['root-readback']['path']).read_bytes())
        archived = q.archive_metadata(Path(cls.refs['inner-archive']['path']),
                                      {'cpu-prepared/record.json', 'cpu-execution/result.json'})
        cls.cpu_prepared = json.loads(archived['cpu-prepared/record.json'])
        cls.cpu_result = json.loads(archived['cpu-execution/result.json'])

    def setUp(self):
        self.previous_cache = q.CPU_VALIDATION_CACHE
        q.CPU_VALIDATION_CACHE = None

    def tearDown(self):
        q.CPU_VALIDATION_CACHE = self.previous_cache

    def test_all_final_bindings_are_unbound(self):
        self.assertIsNone(q.CANDIDATE)
        self.assertIsNone(q.SIGNED_SOURCE)
        self.assertIsNone(q.CPU_REFERENCES)
        self.assertIsNone(q.CPU_EVIDENCE_MODE)
        with self.assertRaisesRegex(ValueError, 'remains unbound'):
            q.snapshot()

    def test_actual_elf_size_and_depinfo_bytes_schemas(self):
        row = {'size': 100, 'cargo_record': {}, 'mode': 0o700, 'sha256': 'a' * 64}
        expected = {'bytes': 100, 'mode': 0o700, 'sha256': 'a' * 64}
        self.assertEqual(q.artifact_archive_row(row), expected)
        self.assertEqual(q.artifact_archive_row(expected), expected)
        for size in (True, 0, -1, '100'):
            with self.assertRaises(ValueError):
                q.artifact_archive_row({**row, 'size': size})

    def test_no_cli_or_environment_pin_override(self):
        data = (HERE / 'qualify.py').read_text()
        self.assertNotIn('os.environ', data)
        self.assertNotIn("add_argument('--candidate", data)
        self.assertNotIn("add_argument('--cpu", data)

    def test_complete_closed_plan(self):
        value = q.plan()
        self.assertEqual(len(value['stages']), 23)
        self.assertEqual(len(value['negative_candidates']), 17)
        self.assertEqual(len(value['equivalent_controls']), 1)
        self.assertEqual(value['projection_bytes'], 93698)
        self.assertEqual(value['command_bounds_sum_seconds'], 2990)
        self.assertEqual(value['solver_invocations_if_complete'], 21)
        self.assertLess(value['calculated_physical_allowance_bytes'], q.b.OUTPUT_LIMIT)
        self.assertEqual([row['kind'] for row in value['stages']].count('positive'), 3)
        for row in value['stages']:
            if row['kind'] == 'release':
                continue
            argv = row['argv']
            self.assertIn('--no-cheating', argv)
            self.assertNotIn('--no-verify', argv)
            self.assertNotIn('--verify-function', argv)
            self.assertNotIn('--verify-root', argv)
            self.assertEqual(argv[argv.index('--num-threads') + 1], '4')
            self.assertEqual(argv[argv.index('--multiple-errors') + 1], '1')

    def test_all_complete_two_input_projections_unchanged(self):
        negatives, equivalents, projections = q.constructed()
        self.assertEqual(len(projections), 20)
        self.assertTrue(all(set(files) == set(q.b.FILES) for files in projections.values()))
        self.assertEqual(projections['case'], projections['relocated'])
        original = q.original_constructed()
        self.assertEqual((negatives, equivalents, projections), original)

    def test_actual_seventeen_calibrated_raw_rows(self):
        cases = q.plan()['negative_candidates']
        with patch.object(q, 'HERE', q.AC):
            for case in cases:
                folder = q.AC / 'capture-attempt-1/commands' / case
                value = q.observe_mutant(folder, q.b.verifier())
                self.assertTrue(value['signed_numeric_negative_accepted'])
                self.assertFalse(value['calibration']['qualified_kill'])
                self.assertEqual((value['calibration']['verified'], value['calibration']['errors']), (6, 1))
                self.assertEqual(value['calibration']['helper_only_unreachable_adapter_case'],
                                 case == 'sleep-absent-remaining-selected')

    def test_equivalent_not_a_negative(self):
        case = next(iter(q.plan()['equivalent_controls']))
        with self.assertRaisesRegex(ValueError, 'seventeen'):
            q.observe_mutant(q.AC / 'capture-attempt-1/commands' / case, q.b.verifier())

    def test_historical_raw_capture_cannot_be_qualified_directly(self):
        value = json.loads((q.AC / 'capture-attempt-1/result.json').read_bytes())
        with self.assertRaises((ValueError, KeyError)):
            q.qualification_summary(value, '0' * 64)

    def synthetic_result(self):
        rows = []
        for item in q.plan()['stages']:
            row = {**item, 'accepted': True}
            if item['kind'] == 'observation':
                row['observation'] = {'signed_numeric_negative_accepted': True, 'case': item['case'],
                                      'calibration': {'qualified_kill': False}}
            rows.append(row)
        return {'raw_capture_completed': True, 'rows': rows, 'errors': [], 'positive_counts': [7] * 4,
                'qualified_kills': 0, 'signed_qualification_accepted': False}

    def test_summary_exact_scope_and_counts(self):
        value = q.qualification_summary(self.synthetic_result(), '0' * 64)
        self.assertEqual(value['qualified_numeric_negatives'], 17)
        self.assertEqual(len(value['equivalent_controls']), 1)
        self.assertFalse(value['std_adapter_proved'] or value['whole_cursor_proved'] or value['scheduler_proved'])
        self.assertEqual(value['historical_raw_qualified_kills'], 0)

    def test_partial_wrong_count_duplicate_false_or_promoted_history_rejects(self):
        original = self.synthetic_result()
        changes = [dict(positive_counts=[7] * 3), dict(positive_counts=[6] * 4), dict(qualified_kills=17),
                   dict(errors=['failure']), dict(rows=original['rows'][:-1])]
        for change in changes:
            with self.assertRaises(ValueError):
                q.qualification_summary({**original, **change}, '0' * 64)
        for mutation in ('duplicate', 'false', 'historical'):
            value = copy.deepcopy(original)
            negative = next(row for row in value['rows'] if row['kind'] == 'observation')
            if mutation == 'duplicate':
                value['rows'].append(copy.deepcopy(negative))
            elif mutation == 'false':
                negative['observation']['signed_numeric_negative_accepted'] = False
            else:
                negative['observation']['calibration']['qualified_kill'] = True
            with self.assertRaises(ValueError):
                q.qualification_summary(value, '0' * 64)

    def test_complete_signed_tree_byte_mode_and_roster_bridge(self):
        tree = {'a': {'mode': '100644', 'kind': 'blob', 'blob': '1' * 40},
                'b': {'mode': '100755', 'kind': 'blob', 'blob': '2' * 40}}
        raw = b'100644 blob ' + b'1' * 40 + b'\ta\0' + b'100755 blob ' + b'2' * 40 + b'\tb\0'
        q.tree_bridge(raw, tree)
        for bad in (raw + raw, raw.split(b'\0')[0] + b'\0', raw.replace(b'100755', b'100644'),
                    raw.replace(b'2' * 40, b'3' * 40), raw.replace(b'\tb\0', b'\tc\0')):
            with self.assertRaises(ValueError):
                q.tree_bridge(bad, tree)

    def test_original_managed_lifecycle_and_classifiers_are_reused(self):
        self.assertEqual(q.b.sha(q.AC / 'capture.py'), q.AC_SHA)
        self.assertIs(q.ac.execute, q.original_execute)
        self.assertIs(q.ac.observe_mutant, q.observe_mutant)
        self.assertIs(q.ac.snapshot, q.snapshot)
        self.assertEqual(q.ac.TOTAL, 3600)
        self.assertEqual(q.ac.STREAM_LIMIT, 256 * 1024)
        self.assertEqual(q.ac.STAGE_METADATA_LIMIT, 64 * 1024)

    def test_memo_validates_once_and_rechecks_all_references_on_every_call(self):
        with patch.object(q, 'final_bindings') as pins, \
                patch.object(q, 'validate_cpu_bridge', return_value=({'a': {'sha256': 'x'}}, {'references': {}})) as validate:
            first = q.cpu_bridge()
            second = q.cpu_bridge()
            self.assertEqual(first, second)
            self.assertEqual(validate.call_count, 1)
            self.assertEqual(pins.call_count, 3)
            self.assertIsInstance(q.CPU_VALIDATION_CACHE[0], bytes)
            self.assertIsInstance(q.CPU_VALIDATION_CACHE[1], bytes)

    def test_cached_reference_drift_rejects_before_reuse(self):
        with patch.object(q, 'final_bindings') as pins, \
                patch.object(q, 'validate_cpu_bridge', return_value=({'a': 1}, {})) as validate:
            q.cpu_bridge()
            pins.side_effect = ValueError('changed pinned evidence')
            with self.assertRaisesRegex(ValueError, 'changed pinned evidence'):
                q.cpu_bridge()
            self.assertEqual(validate.call_count, 1)

    def test_post_validation_drift_never_installs_cache(self):
        with patch.object(q, 'final_bindings', side_effect=[None, ValueError('post-validation drift')]), \
                patch.object(q, 'validate_cpu_bridge', return_value=({'a': 1}, {})):
            with self.assertRaisesRegex(ValueError, 'post-validation drift'):
                q.cpu_bridge()
            self.assertIsNone(q.CPU_VALIDATION_CACHE)

    def test_changed_candidate_path_or_reference_key_rejects(self):
        with patch.object(q, 'final_bindings'), \
                patch.object(q, 'validate_cpu_bridge', return_value=({'a': 1}, {})):
            q.cpu_bridge()
            for name, value in (('CANDIDATE', '1' * 40), ('SIGNED_SOURCE', Path('/fresh-path')),
                                ('CPU_EVIDENCE_MODE', 'recovered-r6'),
                                ('CPU_REFERENCES', {'changed': {'path': '/new', 'sha256': '2' * 64}})):
                with patch.object(q, name, value), self.assertRaisesRegex(ValueError, 'cannot cross'):
                    q.cpu_bridge()

    def test_reference_key_drift_during_validation_never_installs_cache(self):
        with patch.object(q, 'final_bindings'), patch.object(q, 'CPU_REFERENCES', {'initial': 'value'}):
            def validate():
                q.CPU_REFERENCES['initial'] = 'changed'
                return {'a': 1}, {}
            with patch.object(q, 'validate_cpu_bridge', side_effect=validate), \
                    self.assertRaisesRegex(ValueError, 'identity drift'):
                q.cpu_bridge()
            self.assertIsNone(q.CPU_VALIDATION_CACHE)

    def test_returned_mutation_cannot_modify_immutable_cache(self):
        with patch.object(q, 'final_bindings'), \
                patch.object(q, 'validate_cpu_bridge', return_value=({'a': {'value': 1}}, {'references': {'x': 2}})):
            first = q.cpu_bridge()
            first[0]['a']['value'] = 3
            first[1]['references'].clear()
            self.assertEqual(q.cpu_bridge(), [{'a': {'value': 1}}, {'references': {'x': 2}}])

    def test_actual_snapshot_calls_source_bridge_after_each_cpu_binding(self):
        class StopSource(Exception):
            pass
        with patch.object(q, 'cpu_bridge', return_value=({'a': 1}, {})) as cpu, \
                patch.object(q, 'source_bridge', side_effect=StopSource) as source:
            for _ in range(2):
                with self.assertRaises(StopSource):
                    q.snapshot()
            self.assertEqual(cpu.call_count, 2)
            self.assertEqual(source.call_count, 2)

    def test_exact_recovery_reference_roster_and_root_identity(self):
        self.assertEqual(set(self.refs), q.REFERENCE_NAMES)
        self.assertEqual(q.digest(Path(self.refs['root-readback']['path']).read_bytes()),
                         'dcef9a937af969c8f59125f5e7529393c585c1f33e36c19e347dcca7f6e052f6')
        with patch.object(q, 'CPU_REFERENCES', self.refs):
            q.recovery_bindings()
        for name in ('source-record', 'transport-census', 'inner-archive', 'root-readback'):
            value = copy.deepcopy(self.refs)
            value[name]['sha256'] = '0' * 64
            with patch.object(q, 'CPU_REFERENCES', value), self.assertRaises(ValueError):
                q.recovery_bindings()
        with patch.object(q, 'CPU_REFERENCES', self.refs), patch.object(q.b, 'sha', return_value='0' * 64), \
                self.assertRaisesRegex(ValueError, 'auditor'):
            q.recovery_bindings()

    def test_original_transport_rejection_never_promoted(self):
        with patch.object(q, 'CPU_REFERENCES', self.refs):
            q.recovered_transport_gate(self.transport, self.collection)
            for update in ({'accepted': True}, {'errors': []}, {'received': False}, {'cleanup_performed': True}):
                with self.assertRaises(ValueError):
                    q.recovered_transport_gate({**self.transport, **update}, self.collection)
            value = copy.deepcopy(self.transport)
            value['collection']['rejected'] = False
            with self.assertRaises(ValueError):
                q.recovered_transport_gate(value, self.collection)

    def test_rejected_collection_must_be_complete_and_stay_unqualified(self):
        with patch.object(q, 'CPU_REFERENCES', self.refs):
            for key in ('missing_payload_files', 'changed_payload_files'):
                value = copy.deepcopy(self.collection)
                value['partial_custody'][key] = ['candidate-attempt-1/source/Cargo.toml']
                with self.assertRaises(ValueError):
                    q.recovered_transport_gate(self.transport, value)
            for update in ({'qualification_accepted': True}, {'partial_custody': None}):
                with self.assertRaises(ValueError):
                    q.recovered_transport_gate(self.transport, {**self.collection, **update})

    def test_actual_complete_stages_reject_prefix_failed_duplicate_and_reordered_rows(self):
        q.complete_cpu_stages(self.cpu_result, self.cpu_prepared)
        for mutation in ('prefix', 'failed', 'duplicate', 'reordered', 'error', 'rejected'):
            value = copy.deepcopy(self.cpu_result)
            if mutation == 'prefix':
                value['rows'].pop()
            elif mutation == 'failed':
                value['rows'][12]['accepted'] = False
            elif mutation == 'duplicate':
                value['rows'][12] = copy.deepcopy(value['rows'][11])
            elif mutation == 'reordered':
                value['rows'][11:13] = reversed(value['rows'][11:13])
            elif mutation == 'error':
                value['errors'] = ['late failure']
            else:
                value['accepted'] = False
            with self.assertRaises(ValueError):
                q.complete_cpu_stages(value, self.cpu_prepared)

    def test_actual_complete_source_rejects_wrong_candidate_missing_blob_and_mode(self):
        source = q.cpu_source_inventory(self.record, self.prepared, self.collection)
        self.assertEqual(len(source), 6398)
        for mutation in ('hash', 'bytes', 'mode', 'missing'):
            record = copy.deepcopy(self.record)
            name = 'crates/fe2o3-kfd/src/wait.rs'
            if mutation == 'missing':
                del record['candidate_inventory'][name]
            elif mutation == 'hash':
                record['candidate_inventory'][name]['sha256'] = '0' * 64
            elif mutation == 'bytes':
                record['candidate_inventory'][name]['bytes'] += 1
            else:
                record['candidate_inventory'][name]['mode'] ^= 0o100
            with self.assertRaises(ValueError):
                q.cpu_source_inventory(record, self.prepared, self.collection)

    def test_recovery_requires_existing_full_replay_and_all_closure_identities(self):
        with patch.object(q, 'CPU_REFERENCES', self.refs), patch.object(q, 'json_reference', return_value=self.root), \
                patch.object(q, 'load', return_value=SimpleNamespace(main=lambda: self.root)) as replay:
            q.recovered_readback(self.cpu_result)
            replay.assert_called_once_with(q.RECOVERY_AUDITOR, q.RECOVERY_AUDITOR_SHA, 'signed_numeric_recovered_cpu')
            for update in ({'cpu_groups': 19}, {'cache_groups': 3}, {'transport_groups': 6},
                           {'remote_cpu_all_twenty_stages_accepted': False}, {'transport_accepted': True},
                           {'inner_archive_sha256': '0' * 64}, {'adoption_performed': True}):
                replay.return_value = SimpleNamespace(main=lambda update=update: {**self.root, **update})
                with self.assertRaises(ValueError):
                    q.recovered_readback(self.cpu_result)
            replay.return_value = SimpleNamespace(main=lambda: self.root)
            value = copy.deepcopy(self.cpu_result)
            value['artifacts']['no-default']['sha256'] = '0' * 64
            with self.assertRaises(ValueError):
                q.recovered_readback(value)

    def test_recovery_replay_exception_cannot_install_memo(self):
        with patch.object(q, 'final_bindings'), \
                patch.object(q, 'validate_cpu_bridge', side_effect=ValueError('raw closure rejected')):
            with self.assertRaisesRegex(ValueError, 'raw closure rejected'):
                q.cpu_bridge()
            self.assertIsNone(q.CPU_VALIDATION_CACHE)


if __name__ == '__main__':
    unittest.main(verbosity=2)
