#!/usr/bin/env python3
"""Read-only rejected R6 transport/complete remote CPU replay; no adoption."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import tarfile
import tomllib
from types import SimpleNamespace

OWNER = Path('/run/shm/fe2o3-wait-arithmetic-remote-cpu-owner-20261001-attempt-6')
OUTPUT = Path('/run/shm/fe2o3-wait-arithmetic-remote-cpu-transport-20261001-attempt-6')
DURABLE = Path('/mnt/c/fe2o3-wait-arithmetic-remote-cpu-20261001-attempt-6')
PREPARED = '7326ffd99eb9e934eeeaaa2ffbe7c4aa092c8e4b24b44f2ab1667f29dd1e935d'
TRANSPORT = 'f1a861ab219d2dfb03a0885ce14309ce15f96467f55cf0f347cbcd626f262bb8'
CPU = '4923e9e007d44777e48fbf111c41d1d2255bc0db1c1d6fc0b832c894d0cbb56c'
FINAL = 'fc6978a0244ca8c192bc6f6662674c30a49214910261ed9fb4c8042939c576c6'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path, digest, name):
    assert sha(path.read_bytes()) == digest
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def archive_data(path, files, t):
    t.validate_archive(path, files)
    result = {}
    with tarfile.open(path, 'r:gz') as stream:
        for member in stream:
            if member.isdir():
                continue
            assert member.isfile() and member.name not in result and member.name in files
            data = stream.extractfile(member).read()
            assert {'bytes': len(data), 'mode': member.mode, 'sha256': sha(data)} == files[member.name]
            result[member.name] = data
    assert set(result) == set(files)
    return result


class SavedMember:
    """Only the two byte-reading path operations used by the existing census join."""
    def __init__(self, files, name):
        self.files, self.name = files, name

    def __truediv__(self, name):
        return SavedMember(self.files, self.name + '/' + name)

    def read_bytes(self):
        return self.files[self.name]


def main():
    transport = load(OWNER / 'transport.py', TRANSPORT, 'r5_readback_transport')
    cpu = load(OWNER / 'cpu.py', CPU, 'r5_readback_cpu')
    c = transport.c
    p, _, _ = c.helpers()
    t, _ = transport.archive_helpers()
    saved = c.load(OWNER / 'helpers/census.py', transport.EXTRA['census.py'][1], 'r5_saved_census')
    assert t.sha(OUTPUT / 'prepared.json') == PREPARED and t.sha(DURABLE / 'result.json') == FINAL
    prepared = t.parse_json((OUTPUT / 'prepared.json').read_bytes())
    transport.current(prepared, t, p)
    execution = t.parse_json((OUTPUT / 'execution/result.json').read_bytes())
    assert execution['accepted'] is False and execution['errors'] == ['RuntimeError: cpu failed'] and execution['received'] is True
    assert execution['cleanup_performed'] is False and execution['collection']['rejected'] is True
    durable = t.parse_json((DURABLE / 'result.json').read_bytes())
    outer = t.parse_json((DURABLE / 'final.manifest.json').read_bytes())
    assert durable['cpu_transport_accepted'] is False and durable['file_and_directory_fsync_returned'] is True
    assert durable['archive_member_hash_mode_readback'] is True
    assert durable['archive_sha256'] == outer['archive_sha256'] == t.sha(DURABLE / 'final.tar.gz')
    assert durable['manifest_sha256'] == t.sha(DURABLE / 'final.manifest.json')
    outer_data = archive_data(DURABLE / 'final.tar.gz', outer['files'], t)
    for name, data in outer_data.items():
        assert data == (OUTPUT / name).read_bytes() and t.inventory_row(OUTPUT / name) == outer['files'][name]
    collection = t.parse_json((OUTPUT / 'execution/collection.json').read_bytes())
    assert execution['collection']['manifest'] == collection and collection['qualification_accepted'] is False
    assert collection['partial_custody'] == {'missing_payload_files': [], 'changed_payload_files': [],
                                           'qualification_accepted': False,
                                           'partial_records_preserved_without_reclassification': True}
    assert collection['marker_sha256'] == prepared['marker_sha256']
    inner = Path(execution['collection']['archive_path'])
    assert inner == OUTPUT / 'execution/commands/pull-rejected/stdout'
    assert sha(outer_data[inner.relative_to(OUTPUT).as_posix()]) == collection['archive_sha256'] == t.sha(inner)
    data = archive_data(inner, collection['files'], t)
    assert len(data) == 6580 and len(outer_data) == 29 and len(prepared['files']) == 6474
    for name, row in prepared['files'].items():
        assert collection['files'][name] == row and data[name] == (OWNER / name).read_bytes()

    remote = Path(prepared['remote_root'])
    base = ['/usr/bin/python3', '-I', '-B', str(remote / 'custody.py')]
    script = (OUTPUT / 'install.py').read_bytes()
    header = (OUTPUT / 'wire-header.json').read_bytes()
    bootstrap = 'import sys; n=int(sys.argv.pop(1)); s=sys.stdin.buffer.read(n); assert len(s)==n; exec(compile(s,"<owned-cpu-install>","exec"))'
    receive_argv = ['/usr/bin/python3', '-I', '-B', '-c', bootstrap, str(len(script)), str(remote), prepared['marker_sha256']]
    ready = t.parse_json((OUTPUT / 'execution/commands/ready/stdout').read_bytes())
    local = [
        ('receive', transport.ssh(receive_argv, 600), 660),
        ('cache', transport.ssh(transport.remote_mode(prepared, 'cache', prepared['marker_sha256']), 660), 700),
        ('prepare', transport.ssh(transport.remote_mode(prepared, 'prepare', prepared['marker_sha256']), 660), 700),
        ('ready', transport.ssh(base + ['ready', prepared['marker_sha256']], 60), 90),
        ('cpu', transport.SSH + [shlex.join(['exec', *transport.remote_mode(prepared, 'execute', ready['cpu_prepared_sha256'])])], 14500),
        ('collect-rejected', transport.ssh(base + ['collect', prepared['marker_sha256'], '--rejected'], 600), 660),
        ('pull-rejected', transport.ssh(base + ['pull', prepared['marker_sha256'], '--manifest-sha256',
                                      execution['collection']['manifest_sha256'], '--rejected'], 300), 360),
    ]
    saved.census_join(OUTPUT / 'execution', [name for name, _, _ in local], t,
                      {name: 255 if name == 'cpu' else 0 for name, _, _ in local})
    assert (OUTPUT / 'execution/commands/cpu/stderr').read_bytes() == b'client_loop: send disconnect: Broken pipe\r\n'
    stdin = hashlib.sha256()
    for part in (script, len(header).to_bytes(8, 'big'), header, (OUTPUT / 'payload.tar.gz').read_bytes()):
        stdin.update(part)
    previous_end = 0
    for name, argv, seconds in local:
        receipt = t.parse_json((OUTPUT / 'execution/commands' / name / 'receipt.json').read_bytes())
        assert receipt['command'] == argv and receipt['timeout_seconds'] == seconds
        assert receipt['cwd'] == str(OWNER) and receipt['environment'] == prepared['environment']
        assert receipt['stdin_sha256'] == (stdin.hexdigest() if name == 'receive' else None)
        assert type(receipt['started_ns']) is int and previous_end <= receipt['started_ns'] <= receipt['finished_ns']
        previous_end = receipt['finished_ns']

    parsed = lambda name: t.parse_json(data[name])
    cpu_prepared = parsed('cpu-prepared/record.json')
    result = parsed('cpu-execution/result.json')
    assert sha(data['cpu-prepared/record.json']) == collection['cpu_prepared_sha256'] == ready['cpu_prepared_sha256']
    assert sha(data['cpu-execution/result.json']) == collection['cpu_result_sha256']
    assert result['accepted'] is True and result['errors'] == [] and len(result['rows']) == 20
    assert all(row['accepted'] is True for row in result['rows'])
    assert result['gpu_invocations'] == result['solver_invocations'] == 0
    assert result['source_signed'] is False and result['performance_acceptance'] is False
    assert parsed('cpu-execution/inputs.json') == cpu_prepared
    closing_resources = parsed('cpu-execution/continuity-after.json')
    assert closing_resources['ram_checked_for_admission'] is False
    assert closing_resources['disk_available_bytes'] >= c.DISK
    assert closing_resources['target_bytes'] <= c.TARGET_LIMIT
    assert closing_resources['cache_bytes'] <= c.CACHE_LIMIT
    assert closing_resources['source_bytes'] <= c.SOURCE_LIMIT
    assert closing_resources['records_bytes'] <= c.RECORD_LIMIT
    record = parsed('candidate-attempt-1/record.json')
    assert sha(data['candidate-attempt-1/record.json']) == c.RECORD_SHA
    source_rows = {name: {key: row[key] for key in ('bytes', 'mode', 'sha256')}
                   for name, row in record['candidate_inventory'].items()}
    assert len(source_rows) == 6398 and sum(row['bytes'] for row in source_rows.values()) == 88907726
    assert cpu_prepared['snapshot']['source'] == {'record_sha256': c.RECORD_SHA,
                                                'sources': source_rows, 'controls': record['controls']}
    for name, row in source_rows.items():
        assert collection['files']['candidate-attempt-1/source/' + name] == row
    for name, row in record['controls'].items():
        assert collection['files']['candidate-attempt-1/controls/' + name] == row
    old_tools = t.parse_json(Path('/run/shm/fe2o3-wait-arithmetic-remote-cpu-diagnostic-20261001-attempt-1/raw/cpu-prepared/record.json').read_bytes())['snapshot']['tools']
    assert cpu_prepared['snapshot']['tools'] == old_tools
    assert cpu_prepared['snapshot']['expected_rosters'] == prepared['expected_rosters']
    memory_t = SimpleNamespace(parse_json=t.parse_json, sha=lambda path: sha(path.read_bytes()))
    cache_names = ('git-cache-0-commit', 'git-cache-0-tree', 'git-cache-1-commit', 'git-cache-1-tree')
    saved.census_join(SavedMember(data, 'cache-preparation'), cache_names, memory_t)
    saved.census_join(SavedMember(data, 'cpu-prepared'), (), memory_t)
    stages = cpu_prepared['plan']['stages']
    assert len(stages) == 20 and [row['name'] for row in result['rows']] == [stage['name'] for stage in stages]
    saved.census_join(SavedMember(data, 'cpu-execution'), [stage['name'] for stage in stages], memory_t)
    cpu.c.HERE = remote
    cpu.c.CANDIDATE = remote / 'candidate-attempt-1'
    cpu.c.SOURCE = cpu.c.CANDIDATE / 'source'
    assert cpu.plan() == cpu_prepared['plan']
    manifest = tomllib.loads(data['candidate-attempt-1/source/crates/fe2o3-kfd/Cargo.toml'].decode())
    workspace = c.load(OWNER / 'candidate-attempt-1/controls/workspace.py', record['controls']['workspace.py']['sha256'], 'r5_workspace_replay')
    previous_end, counts, elapsed = 0, {}, {}
    for stage, row in zip(stages, result['rows']):
        name, mode, kind = stage['name'], stage['mode'], stage['kind']
        folder = 'cpu-execution/commands/' + name + '/'
        receipt = parsed(folder + 'receipt.json')
        argv = list(stage['argv'])
        if argv[0].startswith('@'):
            argv[0] = result['artifacts'][argv[0][1:]]['path']
        assert receipt['command'] == argv and receipt['environment'] == cpu.c.environment(mode)
        assert receipt['timeout_seconds'] == stage['seconds'] and receipt['cwd'] == str(cpu.c.SOURCE)
        assert receipt['stdin_sha256'] is None and previous_end <= receipt['started_ns'] <= receipt['finished_ns']
        previous_end = receipt['finished_ns']
        stdout, stderr = data[folder + 'stdout'], data[folder + 'stderr']
        assert parsed('cpu-execution/' + name + '-result.json') == row
        if kind == 'attest':
            assert not stderr and t.parse_json(stdout) == {'immutable_snapshot_sha256': sha(c.canonical(cpu_prepared['snapshot']))}
        elif kind == 'version':
            assert stdout and not stderr
        elif kind == 'loader-smoke':
            cpu.loader_smoke(stdout, stderr, data['cpu-execution/commands/rustc-version/stdout'])
        elif kind == 'metadata':
            assert not stderr and workspace.metadata(record['workspace'], cpu.c.SOURCE, remote / 'target-metadata', t.parse_json(stdout)) == row['classification']
        elif kind == 'controls':
            cpu.source_controls_output(stdout, stderr)
        elif kind in ('cargo', 'build'):
            messages = p.cargo_output(stdout, stderr)
            if kind == 'build':
                artifact = result['artifacts'][mode]
                assert row['classification'] == artifact
                selected = [item for item in messages if item.get('reason') == 'compiler-artifact' and
                            item.get('target', {}).get('name') == 'fe2o3_kfd' and
                            item.get('profile', {}).get('test') is True and item.get('executable') is not None]
                assert selected == [artifact['cargo_record']] and selected[0]['fresh'] is False
                cargo = selected[0]
                assert cargo['manifest_path'] == str(cpu.c.SOURCE / 'crates/fe2o3-kfd/Cargo.toml')
                assert cargo['target']['kind'] == ['lib'] and cargo['executable'] == artifact['path']
                assert cargo['features'] == ([] if mode == 'no-default' else sorted(manifest['features']))
                assert type(cargo['features']) is list and len(cargo['features']) == len(set(cargo['features']))
                for item, size in ((artifact, artifact['size']), (artifact['dep_info'], artifact['dep_info']['bytes'])):
                    path = Path(item['path'])
                    assert path.is_relative_to(remote / ('target-' + mode))
                    key = path.relative_to(remote).as_posix()
                    assert collection['files'][key] == {'bytes': size, 'mode': item['mode'], 'sha256': item['sha256']}
                assert data[Path(artifact['path']).relative_to(remote).as_posix()].startswith(b'\x7fELF')
                assert artifact['newly_built_in_this_attempt'] is True and artifact['mode'] & 0o111
        elif kind == 'list':
            assert not stderr and p.test_list(stdout) == result['actual_test_rosters'][mode] == prepared['expected_rosters'][mode]
        elif kind == 'ignored':
            assert cpu.ignored(stdout, stderr) == result['ignored_rosters'][mode] == []
        elif kind == 'full':
            names = result['actual_test_rosters'][mode]
            assert not stderr and p.libtest_output(stdout, set(names), len(names)) == row['classification']
            counts[mode] = {key: row['classification'][key] for key in ('passed', 'ignored', 'filtered_out')}
            elapsed[mode] = (receipt['finished_ns'] - receipt['started_ns']) / 1e9
        else:
            raise AssertionError('unrecognized CPU stage')
    assert counts == {'no-default': {'passed': 1841, 'ignored': 0, 'filtered_out': 0},
                      'all-features': {'passed': 1847, 'ignored': 0, 'filtered_out': 0}}
    assert len({row['path'] for row in result['artifacts'].values()}) == 2
    assert transport.c.sha(OUTPUT / 'prepared.json') == PREPARED and t.sha(DURABLE / 'result.json') == FINAL
    return {'readback_accepted': True, 'source': 'NS4', 'transport_accepted': False,
            'remote_cpu_all_twenty_stages_accepted': True, 'adoption_performed': False,
            'outer_members': len(outer_data), 'inner_members': len(data), 'payload_members': len(prepared['files']),
            'source_files': len(source_rows), 'cpu_groups': len(stages), 'cache_groups': 4, 'transport_groups': 7,
            'counts': counts, 'full_suite_elapsed_seconds': elapsed,
            'elf_sha256': {name: row['sha256'] for name, row in result['artifacts'].items()},
            'inner_archive_sha256': collection['archive_sha256'], 'durable_result_sha256': FINAL,
            'no_remote_calls': True, 'no_historical_pid_probes': True, 'cleanup_performed': False}


if __name__ == '__main__':
    print(json.dumps(main(), sort_keys=True, indent=2))
