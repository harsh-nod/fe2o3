# Signed Wait-Arithmetic Qualification Proposal

Source-only proposal while remote CPU R5 original 85905 is active. No signing,
solver, compiler, main edit, or qualification preparation is authorized here.
All previous failed/unsigned campaigns and original source/ELFs stay retained.

## Existing Components

- Reuse the arithmetic capture owner lifecycle, not the selector proof:
  `/run/shm/fe2o3-wait-arithmetic-capture-20261001-attempt-1/capture.py`,
  SHA `d4eb2d381602e0a099f1fe4aedec616f9796df6cde27cec0af67021397ea6e0a`.
- Keep its existing ND common/managed recorder/normal-exit handler, explicit
  environment, namespace checks, tool closure, release check and positive parser.
- Reuse the signed-source/preparation binding pattern from the accepted
  `/home/harsh/.codex-tmp/fe2o3-cadence-selector-qualification-20261001/qualify.py`,
  SHA `5b313c9493f563aaf7ec6d3adb5f7cdc1e5a21a59f4d3c510548e9b573400ff3`.
  No selector body, contract, count or mutant is imported into this campaign.
- Exact unchanged mutation builder:
  `/run/shm/fe2o3-wait-arithmetic-mutations-20261001-attempt-1/mutations.py`,
  SHA `c111410b8fa3fff49dc60b40d276575326ec9ff99fb1f0ec782724ba5308c9c2`.
  Its 17-negative/one-equivalent roster digest remains
  `9013aabfdaf867acc67f4e570e04cbaeba9038ac8ea028a09284677b6a3542ff`.
- Exact unchanged strict calibration:
  `/run/shm/fe2o3-wait-arithmetic-diagnostics-20261001-attempt-1/diagnostics.py`,
  SHA `aa4ab2d4626837317a9a52cecfdf8f91655ceff670a7c23882135bf3a6fe2ee8`.
  Its parser and builder pins remain enforced internally.

The minimal new namespace contains `qualify.py`, `test_qualify.py`, and
`REVIEW.md`. It is a narrow successor of the existing capture runner. Do not
introduce another raw parser, process owner, archive format, or general binder.

## Source And CPU Gate

The six reviewed NS3 source buffers are at
`/run/shm/fe2o3-wait-arithmetic-source-20261001-attempt-3`. Only wait.rs changed
from NS2: the native deadline conversion uses Option::map. Its SHA is
`fcc925e4a538390813d1b3fdfc732be5658810732ca59285c062a75f3062a2c0`.

Both complete proof inputs are byte-identical to the accepted unsigned captures:

| Input | SHA256 |
| --- | --- |
| crates/fe2o3-kfd/src/wait_arithmetic_body.rs | 1d4e8a628e42cf8dd7607f6902d55f92dc0df8a4d1e4fc69afd3f6844f006c57 |
| crates/fe2o3-runtime-model/verus/monotonic_wait_arithmetic_v1.rs | 43ec6bf0c1e2a3bdd561818502b1b63325d3f0c8d4002e871a8ded80288a008b |

Require accepted complete R5 CPU result, both actual ELF/dep-info identities,
unfiltered 1,841/1,847 passing test rosters, both strict Clippy stages, closing
source/tool attestation and saved command/census joins. Bind the durable outer
and full inner archive/manifest/scan identities, not just an SSH exit code.
The R5 export record is
`a6fe8f70cd871c04313703d277e702fedd514da4838633d245cdac9e3f4d46b0`;
the prepared transport is
`0da5fc8fa29127a978efac53dfc414d135399528cf3cb673e7d1bd5c30a386b7`.
No final CPU result or signed candidate SHA is guessed while R5 is running.

After CPU acceptance and root review, bind a real signed clean candidate with
these exact six files atop the reviewed signed base. The signing bridge must
join the complete selected Git source inventory to the 6,398-file CPU-qualified
source snapshot from the export, preserving Git executable semantics versus private
filesystem modes. Record all 36 supplemental control inputs separately. Reject
any unrelated staged/source change. Signing is a later explicit action, not
part of the qualification runner and not authorized by this proposal.

Metadata preparation uses four existing-pattern 30-second Git groups: signed
HEAD, clean status, exact SSH signature, and selected signed tree. Require all
four and their saved raw/census joins. Check actual signed source and all six
NS3 buffers against the CPU bridge. The builder may retain its original NS2
source path only after exact equality of both signed proof buffers is checked;
all projected cases are authenticated again against the signed two-input pair.

## Proof Plan

Keep the existing 23-stage order:

1. Pinned release closure check.
2. Canonical copied full positive and separately relocated full positive.
3. Result-equivalent backoff-tie positive.
4. All 17 actual-body negative cases in the unchanged roster order.
5. Closing full positive, then pinned release closure check.

There are 20 complete two-input projections and 21 verifier invocations. No
`--verify-function`, `--verify-root`, selected obligation, or weakened contract.
The existing verifier invocation retains `--crate-type lib`, silent triggers,
`--no-cheating`, JSON output/diagnostics, four threads, and `--multiple-errors 1`.
Each command retains the inner 120-second timeout with five-second kill grace
and outer managed 130-second command bound. Command allowances total 2,990 s;
the proof owner remains 3,600 s plus 30 s outer grace. Metadata preparation is
separate, bounded by 900 s plus 30 s, with no solver. No retries.

All four positives require the strict full-unfiltered 7 verified / 0 errors
result, including derived obligations; do not relabel this as seven new cursor
theorems. Each negative must exit normally with code 1, match exact full 6/1
summary and function-note roster, and pass the unchanged complete recursive
diagnostic/source-span/macro-expansion classifier. Resource/timeout/frontend,
unknown schema, wrong case, wrong source, and equivalent-control failures reject.

Keep calibration output unchanged: the calibration helper and historical raw
captures do not independently confer qualified kills. A separate fresh signed
campaign result may count 17 accepted numeric-contract negatives only after
all signed-source, command, classifier, closure and custody gates pass. The
None-input negative remains broader helper-contract-only and unreachable via
the current native adapter. Three ceiling primaries and the lowered match-pattern
primaries retain their reviewed exact attribution, not broader runtime claims.

## Resources, Closure And Custody

Retain the existing 64 MiB combined owner/preparation/output limit, 4 GiB disk
floor, 16 GiB internal RAM floor, 8 GiB address-space limit, 32 MiB per-file cap,
zero core dumps, and 256 KiB each raw stream with no truncation. Root schedules
the local proof lane and its extra 24 GiB admission separately from remote CPU.
No solver runs beside another root-owned local compiler/proof workload.

Keep complete raw records, release brackets, namespace/owner identity,
source/tool/case continuity, and unconditional fresh census even after another
closing check fails. Signed-source metadata, CPU packets and histories are
bound by complete inventories/digests and external prerequisites, not copied
repeatedly into every stage row. Before preparation, calculate actual snapshot,
duplicated terminal rows and archive overhead against the existing cap; do not
describe the old logical estimate as a physical quota or waive a final bound.

Reuse the existing full-member durable archive/fsync/readback owner as a separate
reviewed custody step. Preserve originals and every rejection. Bind the root
independent readback and sensitive scans, including direct inner archives where
filenames do not expose their format. No GPU, cleanup, default cadence change,
performance claim, native Duration/Instant proof or whole-cursor proof follows.

## Focused Controls

Retain existing owner controls and add exact CPU-to-signed-source drift,
unsigned/wrong candidate, missing CPU stage/ELF/roster, altered retained raw,
complete two-input projection drift, missing/duplicate mutant, equivalent-as-
negative, actual calibrated 6/1 versus unrelated failure, and full7/0 count
controls. Exercise the actual fresh classification branch, not a duplicated
literal. Keep preparation stable PID-namespace binding distinct from each
execution's fresh owner identity, and test unconditional closing census.

This proposal leaves final CPU result, signing bridge, owner pins, calculated
record size and qualification preparation digest unbound until measured and
reviewed. It cannot authorize preparation or execution by itself.
