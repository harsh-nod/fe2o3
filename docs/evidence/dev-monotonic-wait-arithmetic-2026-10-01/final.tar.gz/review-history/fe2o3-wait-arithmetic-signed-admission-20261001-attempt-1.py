#!/usr/bin/env python3
"""One authorized scheduling window followed by at most one signed numeric campaign."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/run/shm/fe2o3-wait-arithmetic-signed-qualification-20261001-attempt-4')
LOG = Path('/run/shm/fe2o3-wait-arithmetic-signed-admission-20261001-attempt-1.json')
PINS = {
    'qualify.py': '642eebe056e6bcf97d1aca2033f359d300c7e9a02935722b623759ed2c131777',
    'test_qualify.py': 'f6069d005df7fcf556c6239c7bf3e58a36de60411c0a650dd479cbd8db9ffdb6',
    'REVIEW.md': 'f9e16fbc4c1438d6037a7899d621ac249aed8f7a154a62aebe369ffbd5f60be5',
    'prepared/record.json': 'ac439ba25bc5b15b2b095bde0387e8825416ece0ba1a38561c7c8496c0ac9f5c',
}


def check():
    assert not os.path.lexists(ROOT / 'capture-attempt-1')
    for name, expected in PINS.items():
        path = ROOT / name
        assert path.is_file() and not path.is_symlink()
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    assert json.loads((ROOT / 'prepared/result.json').read_bytes()) == {'accepted': True, 'errors': []}


assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
os.umask(0o077)
assert not os.path.lexists(LOG)
check()
started = time.monotonic()
rows = []
ready = False
while True:
    elapsed = time.monotonic() - started
    memory = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                      if line.startswith('MemAvailable:'))) * 1024
    rows.append({'elapsed_seconds': elapsed, 'mem_available_bytes': memory})
    print(json.dumps(rows[-1], sort_keys=True), flush=True)
    if elapsed <= 300 and memory >= 24 * 1024**3:
        ready = True
        break
    if elapsed >= 300:
        break
    time.sleep(min(5, 300 - elapsed))
if ready:
    check()
argv = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=30s', '3600s',
        '/usr/bin/python3', '-I', '-B', str(ROOT / 'qualify.py'), '--execute', PINS['prepared/record.json']]
with LOG.open('x') as output:
    json.dump({'schema': 'fe2o3.signed-numeric-admission.v1', 'threshold_bytes': 24 * 1024**3,
               'window_seconds': 300, 'sample_interval_seconds': 5, 'samples': rows,
               'admitted': ready, 'at_most_one_launch': True, 'pinned_inputs': PINS,
               'proposed_execute_argv': argv, 'note': 'Admission record precedes exec; actual launch is in the owned capture records.'},
              output, sort_keys=True, indent=2)
    output.write('\n')
    output.flush()
    os.fsync(output.fileno())
if not ready:
    raise SystemExit(3)
os.execve(argv[0], argv, {'HOME': '/home/harsh', 'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'})
