# Signed Numeric Qualification Custody

Source-only proposal after Q4 original 49532 ended with exit 0. Preserve the
complete Q4 owner and all predecessor attempts unchanged. No new compiler,
solver, SSH, Git command, cleanup, signing or publication is part of this step.

## Existing Logic

Adapt only the existing arithmetic capture archive owner at
/run/shm/fe2o3-wait-arithmetic-capture-archive-owner-20261001-attempt-1/archive.py.
Keep its bounded ordinary-file roster, exact original-index, copy2 mode/byte
preservation, existing archive validator, explicit fsync/readback and startup
resource checks. Keep 300 seconds plus 30 seconds grace, 64 MiB combined owned
packet/durable allowance, 16 GiB plus allowance available RAM, and 4 GiB disk
floors on both output filesystems. No generic archive framework or mode-policy
relaxation. Failed or refused custody remains retained, not retried automatically.

Fresh source namespace:
/run/shm/fe2o3-wait-arithmetic-signed-archive-owner-20261001-attempt-1
Fresh staging:
/run/shm/fe2o3-wait-arithmetic-signed-archive-20261001-attempt-1
Fresh durable destination:
/mnt/c/fe2o3-wait-arithmetic-signed-qualification-20261001-attempt-1

## Closed Roster

- All 158 Q4 owner files, currently 1,780,050 logical bytes: exact three owner
  buffers, four preparation Git command groups, 20 complete two-input case
  projections, every raw stream/receipt and classification from 23 execution
  groups, saved preparation/execution censuses and both distinct final results.
- The exact six NS4 source buffers from signed a7d110af1ff14bf71a82799c6224abc7894149e9,
  verified against the frozen NS4 checker and the full CPU source record. Include
  NS4 checker/review as provenance, without claiming its ancestors self-contained.
- Original Q1, Q2 and Q3 owner/control/review buffers, unchanged and separately
  indexed; the original signed-qualification proposal; actual admission wrapper
  2d16c485 and admission record 48882c96; the new three archive-owner files and
  existing archive ancestor buffer.
- Exact root R6 CPU readback dcef9a93 and full auditor ac5c05ce, plus outer scan
  d0fba0ff and direct-inner scan 82b937f5. These keep recovered CPU adoption
  explicit while the original SSH transport remains rejected.
- A compact twelve-reference CPU prerequisite table with original absolute
  paths/hash/size/mode, and the earlier AC durable triplet reference table.
  Do not duplicate the full CPU archive, build caches or retained ELFs: they
  already have durable custody and remain explicit external replay prerequisites.
- Constructed original-index and summary only; exclude private Git metadata,
  signing keys, arbitrary environment/config and unrelated histories.

## Acceptance And Scope

Bind prepared ac439ba2, managed result ae60323f, census a3cc443e and signed result
b2b569c5. Preserve managed zero historical qualified kills and signed:false.
The separate signed result is accepted only for the complete 23-stage campaign:
four full 7/0 positives, 17 intended 6/1 diagnostic negatives, exact two-input
projections, full signed source/CPU bridge and all 27 saved command-group joins.
Replay the existing strict negative classifier on the retained raw cases and
use the existing summary checker; no new raw parser. The archive makes no new
verification claim beyond those records.

Controls must reject missing/extra owner files, altered raw/summary/census,
wrong final candidate/source, promotion of historical raw flags, absent or
changed external references, symlinks/invalid paths and unsupported modes.
Include an actual completed-Q4 roster/classification read-only control.

The Duration/Instant adapter, whole cursor/constructor, scheduler, hardware and
performance remain outside the numeric-helper proof. The None mutation is a
broader helper-contract case unreachable through the native adapter. The CPU
evidence is recovered complete remote execution, not successful SSH transport.
All originals remain retained until separate root custody and security review.
Final packet is not self-contained: pinned tools/std, managed helpers, signed
Git objects, full CPU archives/ELFs and predecessor histories remain required.
