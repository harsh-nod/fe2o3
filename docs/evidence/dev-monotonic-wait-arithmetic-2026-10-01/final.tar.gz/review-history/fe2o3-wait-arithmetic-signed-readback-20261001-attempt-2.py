#!/usr/bin/env python3
"""Read-only full Q4 source/raw/classification replay; never launches a command."""
import hashlib
import importlib.util
import json
from pathlib import Path

OWNER = Path('/run/shm/fe2o3-wait-arithmetic-signed-qualification-20261001-attempt-4')
OWNER_SHA = '642eebe056e6bcf97d1aca2033f359d300c7e9a02935722b623759ed2c131777'
PREPARED = 'ac439ba25bc5b15b2b095bde0387e8825416ece0ba1a38561c7c8496c0ac9f5c'
RAW = 'ae60323f01b7b4f044e358ea529d7a48ae9b9506ae4dc017567b346cb55c07ba'
CENSUS = 'a3cc443e7db9661eea551b6d5ff52add82d55b8cdcefd1591e25c1c6e08d197e'
QUALIFIED = 'b2b569c5bb4708c605052df00097a3c4566fe1ba47247e9e5dfddc679e562e91'


def load_owner():
    path = OWNER / 'qualify.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == OWNER_SHA
    spec = importlib.util.spec_from_file_location('signed_arithmetic_replay_owner', path)
    q = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(q)
    return q


def receipt_check(receipt, argv, env, cwd, seconds, status, previous):
    assert receipt['command'] == argv and receipt['environment'] == env
    assert receipt['cwd'] == str(cwd) and receipt['timeout_seconds'] == seconds
    assert receipt['stdin_sha256'] is None and receipt['error'] is None
    assert type(receipt['exit']) is int and receipt['exit'] == status and receipt['group_absent'] is True
    assert type(receipt['started_ns']) is int and type(receipt['finished_ns']) is int
    assert previous <= receipt['started_ns'] <= receipt['finished_ns']
    assert receipt['finished_ns'] - receipt['started_ns'] <= seconds * 1_000_000_000
    return receipt['finished_ns']


def resource_check(value, q):
    assert set(value) == {'free_bytes', 'mem_available_bytes', 'owned_bytes', 'guard'}
    assert value['guard'] == 'stage-boundary-only-not-continuous-not-quota'
    assert all(type(value[key]) is int for key in ('free_bytes', 'mem_available_bytes', 'owned_bytes'))
    assert value['free_bytes'] >= q.b.FLOOR and value['mem_available_bytes'] >= q.b.RAM_FLOOR
    assert 0 <= value['owned_bytes'] + 64 * 1024 <= q.b.OUTPUT_LIMIT


def main():
    q = load_owner()
    p = q.b.prior()
    t = q.load(q.ARCHIVE_HELPER, q.ARCHIVE_SHA, 'signed_arithmetic_readback_archive')
    saved = q.load(q.CENSUS_HELPER, q.CENSUS_SHA, 'signed_arithmetic_readback_census')
    prep, output = OWNER / 'prepared', OWNER / 'capture-attempt-1'
    expected_pins = {prep / 'record.json': PREPARED, output / 'result.json': RAW,
                     output / 'fresh-census.json': CENSUS, output / 'qualification-result.json': QUALIFIED}
    assert all(q.b.sha(path) == value for path, value in expected_pins.items())
    parsed = lambda path: p.parse_json(q.b.raw(path))
    frozen = parsed(prep / 'record.json')
    raw, qualified = parsed(output / 'result.json'), parsed(output / 'qualification-result.json')
    current = q.snapshot()
    q.ac.prepared_matches(frozen, current)
    q.ac.cases_match(frozen['projected_inputs'])
    assert parsed(output / 'inputs.json') == frozen
    assert current['signed_tree_count'] == 6398 and len(current['projected_inputs']) == 20
    assert all(len(files) == 2 for files in current['projected_inputs'].values())
    for directory in (prep, output):
        assert q.b.stable_namespaces(parsed(directory / 'owner-identity.json')) == current['stable_namespaces']
    q.prepared_binding()
    source, _ = q.cpu_bridge()
    tree, _ = q.source_bridge(source)
    git = ['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false']
    commands = [
        ('signed-head', git + ['rev-parse', 'HEAD']),
        ('signed-status', git + ['status', '--porcelain=v1', '-z', '--untracked-files=all']),
        ('signed-signature', git + ['-c', 'gpg.format=ssh', '-c', 'gpg.ssh.program=/usr/bin/ssh-keygen',
         '-c', 'gpg.ssh.allowedSignersFile=' + str(q.b.SIGNERS), 'verify-commit', q.CANDIDATE]),
        ('signed-tree', git + ['ls-tree', '-rz', '--full-tree', q.CANDIDATE, '--', *q.SOURCE_ROOTS]),
    ]
    env = {**q.b.discovery().environment(prep), 'GIT_OPTIONAL_LOCKS': '0'}
    previous = 0
    for name, argv in commands:
        folder = prep / 'commands' / name
        previous = receipt_check(parsed(folder / 'receipt.json'), argv, env, q.SIGNED_SOURCE, 30, 0, previous)
        stdout, stderr = q.b.raw(folder / 'stdout'), q.b.raw(folder / 'stderr')
        if name == 'signed-head':
            assert stdout == (q.CANDIDATE + '\n').encode() and not stderr
        elif name == 'signed-status':
            assert not stdout and not stderr
        elif name == 'signed-signature':
            assert not stdout and stderr == q.b.SIGNATURE
        else:
            assert not stderr
            q.tree_bridge(stdout, tree)
    saved.census_join(prep, q.PREPARATION_NAMES, t)
    stages = frozen['plan']['stages']
    assert len(stages) == 23 and len(raw['rows']) == 23
    saved.census_join(output, [stage['name'] for stage in stages], t,
                      {stage['name']: int(stage['kind'] == 'observation') for stage in stages})
    env = q.b.discovery().environment(output)
    assert parsed(output / 'environment.json') == env
    positives, negatives, first = [], [], None
    for stage, row in zip(stages, raw['rows']):
        name, kind = stage['name'], stage['kind']
        assert row['name'] == name and row['kind'] == kind and row['case'] == stage['case']
        assert row['accepted'] is True and parsed(output / (name + '-result.json')) == row
        folder = output / 'commands' / name
        receipt = parsed(folder / 'receipt.json')
        previous = receipt_check(receipt, stage['argv'], env, output, 130,
                                 int(kind == 'observation'), previous)
        if first is None:
            first = receipt['started_ns']
        stdout, stderr = q.ac.bounded_streams(folder)
        resource_check(row['before'], q)
        resource_check(row['after'], q)
        q.ac.metadata_bound(folder, row)
        if kind == 'release':
            assert stdout.decode() == q.b.discovery().CLOSURE_OK and not stderr
        else:
            assert row['raw'] == q.ac.normal_capture(receipt, stage['argv'], env)
            if kind == 'observation':
                assert row['observation'] == q.observe_mutant(folder, frozen['plan']['verifier_identity'])
                key = 'helper_only_none_scope' if name == frozen['plan']['helper_only_none_case'] else 'all_other_cases_scope'
                assert row['scope'] == frozen['plan'][key]
                negatives.append(name)
            else:
                actual = q.ac.classify_positive(folder, stage['case'], frozen['plan']['verifier_identity'])
                assert row['candidate'] == actual
                positives.append(q.ac.measured_count(actual))
    assert previous - first <= 3600 * 1_000_000_000
    resource_check(parsed(output / 'continuity-after.json'), q)
    assert positives == [7] * 4 and negatives == [stage['name'] for stage in stages if stage['kind'] == 'observation']
    assert raw['qualified_kills'] == 0 and raw['signed_qualification_accepted'] is False
    expected = q.qualification_summary(raw, PREPARED)
    expected.update(managed_result_sha256=RAW, fresh_census_sha256=CENSUS, errors=[])
    assert qualified == expected
    q.ac.prepared_matches(frozen, q.snapshot())
    assert all(q.b.sha(path) == value for path, value in expected_pins.items())
    return {'readback_accepted': True, 'candidate': q.CANDIDATE, 'preparation_groups': 4,
            'execution_groups': 23, 'positive_counts': positives, 'qualified_numeric_negatives': len(negatives),
            'qualified_result_sha256': QUALIFIED, 'managed_result_sha256': RAW, 'census_sha256': CENSUS,
            'snapshot_sha256': q.digest(q.encoded(current)), 'source_files': 6398, 'tool_files': len(current['tools']),
            'projected_cases': 20, 'proof_inputs_per_case': 2, 'original_transport_accepted': False,
            'historical_raw_qualified_kills': 0, 'std_adapter_proved': False, 'whole_cursor_proved': False,
            'scheduler_proved': False, 'performance_acceptance': False,
            'no_new_commands': True, 'no_historical_pid_probes': True, 'owned_bytes': q.b.footprint(OWNER)}


if __name__ == '__main__':
    print(json.dumps(main(), sort_keys=True, indent=2))
