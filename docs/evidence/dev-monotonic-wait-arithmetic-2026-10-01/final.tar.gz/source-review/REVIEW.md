# NS4 Native Formatting Successor

Source-only successor of the frozen NS3 candidate. No CPU, solver, export,
signing or remote operation is authorized by this record. R5 remains a run
over NS3 and cannot be relabeled as fresh NS4 qualification.

The pinned nightly-2026-04-03 rustfmt binary has SHA-256
`a9137d0c198ceb6c72193d517d3c9007b3ec7a90d3d10ec6889773eca48261b4`.
The read-only `--check --edition 2024 wait.rs` invocation on the actual R5
candidate reported only wait.rs and wait_arithmetic_tests.rs (tool receipt
ca352b, exit 1). The five native source hashes were unchanged before/after.
An earlier explicit five-file check (e40695) also reported shared-body
formatting; that shared include is not visited by normal wait.rs module
traversal and is deliberately preserved byte-for-byte, with no skip/allow.

Only the new NS4 copy was formatted via the same pinned rustfmt, edition
2024, entrypoint wait.rs. Exactly four closed textual changes occur:
one map-expression wrap, one test-array wrap with a trailing comma, and two
assert-expression wraps. The inverse checker restores the complete NS3
buffers and rejects any additional byte change. Existing tests, values,
constructors, sampling order and closures are unchanged.

The wrapper arithmetic source, shared included body, proof root and original
16,800-case differential oracle are byte-identical to NS3. The exact two
proof inputs, raw capture, 17-negative/one-equivalent mutation builder and
calibrated diagnostics retain their original byte/span identities.

The new checker runs all 12 NS2 controls, all seven NS3 controls, and eight
new NS4 controls: 27 total. Prior checker buffers remain in .review-ns2 and
.review-ns3 unchanged; their relative ROOT is historical metadata, not an
invocation claim. Authoritative predecessor checks load the original frozen
NS3/NS2 paths and verify their exact hashes.

Native formatter success is formatting evidence only. Adapter and whole
cursor formal refinement, scheduler/hardware/performance acceptance and
fresh full KFD CPU qualification are not claimed.
