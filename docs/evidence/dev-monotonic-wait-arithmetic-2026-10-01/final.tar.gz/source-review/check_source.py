#!/usr/bin/env python3
"""Closed formatter-only inverse; the shared numeric proof inputs stay exact."""
import hashlib
import importlib.util
from pathlib import Path
import stat
import unittest

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = Path('/run/shm/fe2o3-wait-arithmetic-source-20261001-attempt-3')
PREVIOUS_CHECKER_SHA = '543be8e5cdda8167424bc3fda8a5542738aa9e32115694326ab281a2bbc596bb'
KFD = 'crates/fe2o3-kfd/src/'
WAIT, NATIVE, BODY, TEST, ORACLE = [KFD + name for name in (
    'wait.rs', 'wait_arithmetic.rs', 'wait_arithmetic_body.rs',
    'wait_arithmetic_tests.rs', 'wait_cursor_differential_tests.rs')]
PROOF = 'crates/fe2o3-runtime-model/verus/monotonic_wait_arithmetic_v1.rs'
PINS = {
    WAIT: '6c586d97d7dbb4cf9be4f06d279f80758afe05d4d6b772ae85d372d8c28aac0c',
    NATIVE: '1d4dc372f72480f102aaa07f2f6fc81b3034cf561b85849bb81ff292f90ad605',
    BODY: '1d4e8a628e42cf8dd7607f6902d55f92dc0df8a4d1e4fc69afd3f6844f006c57',
    TEST: '74451f25f1067ce6d90e5866b6c0a4a5e68cd1d19cfe4cdf86289d238f98f8b8',
    ORACLE: 'f671ac749f28800f51e82670994531aa950ca36113441f98139262760d90bfc5',
    PROOF: '43ec6bf0c1e2a3bdd561818502b1b63325d3f0c8d4002e871a8ded80288a008b',
}
EDITS = {
    WAIT: ((
        '        let remaining = self.deadline.map(|deadline| deadline.saturating_duration_since(now));\n',
        '        let remaining = self\n            .deadline\n'
        '            .map(|deadline| deadline.saturating_duration_since(now));\n'),),
    TEST: ((
        '        [0, 1, 499_999_999, 500_000_000, 500_000_001, 999_999_998, 999_999_999]\n'
        '            .into_iter()\n            .map(move |nanos| Duration::new(seconds, nanos))\n',
        '        [\n            0,\n            1,\n            499_999_999,\n'
        '            500_000_000,\n            500_000_001,\n            999_999_998,\n'
        '            999_999_999,\n        ]\n        .into_iter()\n'
        '        .map(move |nanos| Duration::new(seconds, nanos))\n'), (
        '    assert_eq!(wait_backoff_pair_v1((0, 25_000), (0, 1_000_000)), (0, 50_000));\n',
        '    assert_eq!(\n        wait_backoff_pair_v1((0, 25_000), (0, 1_000_000)),\n'
        '        (0, 50_000)\n    );\n'), (
        '    assert_eq!(wait_backoff_pair_v1((1, 0), (0, 999_999_999)), (0, 999_999_999));\n',
        '    assert_eq!(\n        wait_backoff_pair_v1((1, 0), (0, 999_999_999)),\n'
        '        (0, 999_999_999)\n    );\n')),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_previous():
    path = PREVIOUS / '.review/check_source.py'
    assert digest(path.read_bytes()) == PREVIOUS_CHECKER_SHA
    spec = importlib.util.spec_from_file_location('previous_map_source', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    contents, previous = module.load()
    module.inverse(contents, previous)
    return module, contents


def inverse(contents, previous):
    assert set(contents) == set(previous) == set(PINS)
    for name in PINS:
        restored = contents[name]
        for old, new in EDITS.get(name, ()):
            assert restored.count(new) == previous[name].count(old) == 1
            assert old not in restored and new not in previous[name]
            restored = restored.replace(new, old, 1)
        assert restored == previous[name]
    assert {name for name in PINS if contents[name] != previous[name]} == {WAIT, TEST}


def load():
    _, previous = load_previous()
    assert {path.relative_to(ROOT).as_posix() for path in (ROOT / 'crates').rglob('*')
            if path.is_file()} == set(PINS)
    contents = {}
    for name, expected in PINS.items():
        path = ROOT / name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not path.is_symlink()
        assert stat.S_IMODE(info.st_mode) == 0o644
        data = path.read_bytes()
        assert digest(data) == expected
        contents[name] = data.decode('ascii')
    inverse(contents, previous)
    return contents, previous


class SourceControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.contents, cls.previous = load()

    def test_exact_four_formatting_edits(self):
        inverse(self.contents, self.previous)
        self.assertEqual(sum(map(len, EDITS.values())), 4)

    def test_extra_native_edit_rejects(self):
        changed = {**self.contents, WAIT: self.contents[WAIT].replace('attempts: 0,', 'attempts: 1,', 1)}
        with self.assertRaises(AssertionError):
            inverse(changed, self.previous)

    def test_partial_or_duplicate_format_rejects(self):
        for name, edits in EDITS.items():
            for old, new in edits:
                for replacement in (old, new + new):
                    with self.assertRaises(AssertionError):
                        inverse({**self.contents, name: self.contents[name].replace(new, replacement, 1)}, self.previous)

    def test_test_value_drift_rejects(self):
        changed = {**self.contents, TEST: self.contents[TEST].replace('499_999_999', '499_999_998', 1)}
        with self.assertRaises(AssertionError):
            inverse(changed, self.previous)

    def test_sampling_or_map_change_rejects(self):
        for old, new in (('saturating_duration_since(now)', 'saturating_duration_since(Instant::now())'),
                         ('.map(', '.and_then(')):
            with self.assertRaises(AssertionError):
                inverse({**self.contents, WAIT: self.contents[WAIT].replace(old, new, 1)}, self.previous)

    def test_shared_proof_native_and_oracle_drift_rejects(self):
        for name in (BODY, PROOF, NATIVE, ORACLE):
            with self.assertRaises(AssertionError):
                inverse({**self.contents, name: self.contents[name] + '\n'}, self.previous)

    def test_extra_or_missing_source_rejects(self):
        for changed in ({**self.contents, 'extra.rs': ''},
                        {name: data for name, data in self.contents.items() if name != PROOF}):
            with self.assertRaises(AssertionError):
                inverse(changed, self.previous)

    def test_no_allow_skip_or_contract_change(self):
        for name in PINS:
            for token in ('allow(', 'rustfmt::skip', 'external_body', 'assume('):
                self.assertEqual(self.contents[name].count(token), self.previous[name].count(token))


if __name__ == '__main__':
    previous, _ = load_previous()
    ns2, _ = previous.load_previous()
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(module.SourceControls)
                               for module in (ns2, previous))
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(SourceControls))
    assert suite.countTestCases() == 27
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() and result.testsRun == 27 else 1)
