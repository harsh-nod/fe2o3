# Signed Numeric Qualification Scaffold

## Q4 Final Binding

Q4 preserves Q3 at its original path and changes only final binding constants,
the corresponding bound-state control and this review note. The signed candidate
is a7d110af1ff14bf71a82799c6224abc7894149e9 in the linked detached worktree
/run/shm/fe2o3-wait-arithmetic-signed-source-20261001-attempt-1. CPU evidence mode
is recovered-r6 with the exact twelve closed references already reviewed in Q3.
The altered memo-key test now changes that bound mode to accepted-transport,
so it still exercises actual mode drift rather than its former unbound value.

The original R6 SSH failure remains rejected; this binding only enables the
separate complete-CPU adoption checks. No proof plan, source, contracts, mutation,
diagnostic parser, lifecycle or threshold changes. The full read-only snapshot
is measured before metadata preparation, which still needs root review. Q3's
unbound-state description below is retained as predecessor provenance.

## Q3 Recovered CPU Branch

Q3 preserves Q2 byte-for-byte in its original namespace. This is a source-only
successor; CANDIDATE, SIGNED_SOURCE, CPU_REFERENCES and CPU_EVIDENCE_MODE remain
unbound. Root's signed NS4 candidate and linked worktree will be bound only
after this recovery branch is reviewed. No metadata, solver, compiler, remote
query or cleanup is performed by these controls.

The accepted-transport branch remains available with its original requirements.
The new recovered-r6 branch accepts only one closed twelve-reference mapping
for R6, including root's independent report dcef9a93 and full read-only auditor
ac5c05ce. It retains original transport accepted:false, exact CPU SSH failure,
received:true, rejected collection and qualification_accepted:false. Missing
or changed payload members, a partial CPU prefix or any failed stage reject.
It does not reinterpret Broken pipe as successful SSH and never writes an old
result. Cleanup is a separately authorized operation, not CPU acceptance.

On the first full CPU validation in each process, Q3 invokes the existing
read-only R6 auditor once. That auditor replays the actual 20 CPU groups, four
cache groups and seven transport groups, including raw commands/environment,
both complete feature rosters/suites, Clippy, source/tool identities, two fresh
ELFs and dep-info, all saved closure/census joins, outer and inner archives.
It never probes historical PIDs or calls SSH. Its returned identities must
match the exact independent root report and this wrapper's actual CPU result.
The original SSH 255 and CRLF Broken pipe remain a rejection in both records.
The root report also binds separate outer and direct-inner inspection hashes;
their documented scanner limitations are not broadened by this adoption.

Q2's first full archive/source validation and before/after reference rehashes
remain. Its immutable in-process memo now includes the evidence-mode value.
Every subsequent snapshot rehashes all twelve references and the recovery
auditor before reuse and redoes the complete signed-source bridge; this avoids
repeated raw replay without accepting mutable cached aliases or candidate drift.
Summary metadata labels recovered CPU adoption separately and records original
transport acceptance as false. The complete 6,398-file source bridge to the
future signed candidate remains mandatory, including exact NS4 native buffers.

Seven additional offline groups exercise the actual R6 metadata, closed pins,
source-byte/mode mismatch, missing/failed/duplicate/reordered stages, incomplete
collection, transport promotion, replay/census count mismatch, ELF mismatch,
and failure before memo installation. The full replay call is mocked only in
these unit controls; they are not themselves new CPU qualification. Root's
already accepted independent full replay remains the recorded authority until
the reviewed final-bound owner performs its own first validation.

The unchanged 23-stage numeric proof plan, actual two-input bodies, calibrated
17 negatives plus equivalent control, resources and managed lifecycle remain
as described below. No adapter, whole-cursor, GPU or performance inference is
added. Previous Q2 design/history follows for provenance; its unbound-source
and acceptance statements describe that preserved predecessor.

## Preserved Q2 Design

Q2 preserves Q1 at its original path. Its narrow difference is one in-process
CPU validation memo; the full validator body is unchanged except its name.
Every call still rehashes every pinned final reference before considering
reuse. The first call fully validates both archives and all CPU/source joins,
then rehashes all references again before installing an immutable encoded
buffer. Candidate, signed-worktree path and the entire reference mapping
form the exact key. A changed key rejects, rather than refreshing implicitly.
Each return decodes a fresh copy, preventing mutable aliases to the memo.
The complete signed-source byte/blob/mode bridge still runs each snapshot.
No persistent cache or cross-process acceptance exists: metadata preparation
and execution independently perform their first full validation.

Seven additional direct controls cover one full validation, every-call
reference checking, cached and post-validation drift rejection, key drift
with no stale install, immutable-copy behavior, and actual snapshot dispatch
through source_bridge every time. No final pins have been bound.

After R5 closed, reading its actual artifact schema found an unexecuted Q1
bridge mismatch: the reviewed inherited ELF record calls its byte count
`size`, while dep-info and archive inventory use `bytes`. Q2 corrects that
one literal schema association and directly tests both actual forms plus
wrongly typed/invalid sizes. No prior qualification was run or accepted.

Source-only, unprepared, unsigned and unexecuted. CANDIDATE, SIGNED_SOURCE and
CPU_REFERENCES are literal None. No command-line or environment override can
satisfy them. Their final revision requires root review after fresh final
candidate CPU qualification and separately reviewed signing. R5 is NS3
development evidence and cannot satisfy the NS4 source bridge.

This three-file adapter reuses the exact frozen AC capture module and changes
only its namespace, plan, snapshot, constructed-source check and negative
classifier callbacks. The original managed execute function remains exact:
signals, process groups, explicit environment, release-finally, independently
attempted closing continuity/census, raw handling, resource gates, and limits
are inherited. It writes its honest raw lifecycle result with zero historical
qualified kills and signed acceptance false. A separate, compact final result
can award fresh signed numeric qualification only after all strict callbacks,
all 23 stages, complete continuity and four full 7/0 positives pass. It does
not rewrite or promote any historical capture.

The plan uses 20 complete two-input projections, 17 intended 6/1 negatives,
one result-equivalent 7/0 control, canonical and independently relocated full
7/0 positives, closing full 7/0 positive and release brackets. There are 21
verifier invocations, no selected function/root flags, no std trust bridge,
four threads, reporting threshold one and --no-cheating. Commands retain
120-second inner/130-second managed limits, summing 2,990 seconds, with the
3,600-second owner plus external 30-second grace. Metadata preparation uses
four bounded 30-second Git groups under 900 seconds plus external grace.

CPU inputs must be complete accepted final-candidate evidence, not a prefix:
20 accepted stages, distinct 1,841/1,847 complete feature rosters and retained
ELF/dep-info, original collected source/raw and complete durable archive.
Both archives are validated using the existing reviewed transport helper.
Root's full CPU command/raw/census replay and outer plus direct-inner security
scans are separately pinned external prerequisites; this owner does not add
another generic CPU replay/parser framework or infer inspection of tar data
from the stdout filename. These references are intentionally unresolved.

The complete 6,398-entry source record is checked against every transported
and collected source byte/mode, then every materialized signed-source byte and
Git executable bit. The selected signed Git tree must match all corresponding
blob identities, not merely the six overlay paths. The final native buffers
must equal NS4. Linked detached HEAD/index and the signature are bound. The
two numeric proof inputs must still equal the original builder's preimages.

Per-stage snapshots repeat only source inventory digest/count and reference
digests, never the huge complete CPU or archive manifest. The physical
allowance counts each stage's classification twice (beside its receipt/raw
and in the final result), bounded raw streams and four compact snapshot
copies. The final extra qualification record is checked against the actual
64 MiB combined footprint; final binding changes must remeasure encoded
snapshots before metadata preparation. Bounds remain boundary checks, not
continuous quotas. No automatic CPU/solver next phase or cleanup exists.

The strict existing calibration is unchanged, including source spans and
6/1 full schema. Its qualified_kill flag remains false inside each observation;
fresh signed authority comes only from the new complete campaign. The absent
None case tests the broader numeric helper contract and is unreachable through
the current native adapter. Every other mutation remains a numeric-result
claim, not proof of reachable native faults. Duration/Instant conversion,
the complete cursor/constructor, scheduler, hardware and performance remain
outside this formal claim. The original 16,800-case native oracle is unchanged.

Only source/offline controls may be run before root reviews the complete draft.
No signing, metadata preparation, CPU, compiler, solver, GPU or remote command
is authorized by this scaffold.

Initial source-control invocation b4de15 rejected one test-fixture namespace
error: the test changed HERE before computing the owner-file budget. The
production owner was unexecuted. The fixture now computes its case roster
before the historical-source path override; no acceptance predicate changed.
