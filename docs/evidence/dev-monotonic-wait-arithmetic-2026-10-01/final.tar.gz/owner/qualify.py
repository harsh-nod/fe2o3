#!/usr/bin/env python3
"""Signed numeric qualification over the unchanged managed arithmetic capture."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
AC = Path('/run/shm/fe2o3-wait-arithmetic-capture-20261001-attempt-1')
AC_SHA = 'd4eb2d381602e0a099f1fe4aedec616f9796df6cde27cec0af67021397ea6e0a'
CALIBRATION = Path('/run/shm/fe2o3-wait-arithmetic-diagnostics-20261001-attempt-1/diagnostics.py')
CALIBRATION_SHA = 'aa4ab2d4626837317a9a52cecfdf8f91655ceff670a7c23882135bf3a6fe2ee8'
CALIBRATION_TESTS_SHA = 'd848dfa49cea24ce166aa277dbfd7e7eefa5b11ac4411941cf47513ddf5f0af2'
PARSER = Path('/run/shm/fe2o3-a2-concrete-journal-composition-20261001-qualified/crates/fe2o3-runtime-model/verus/producer-input-diagnostics-v1.py')
PARSER_SHA = '318a29f9067618c2168a8e1d3585b1e8e3f8c78abe40359d52b0a20458238be4'
AC_DURABLE = Path('/mnt/c/fe2o3-wait-arithmetic-capture-20261001-attempt-1')
CENSUS_HELPER = Path('/run/shm/fe2o3-wait-arithmetic-discovery-archive-owner-20261001-attempt-1/archive.py')
CENSUS_SHA = '7fddeef723edd5197dbf094a89a0fa2f4ab06f6739373611bed471bc250dc51d'
ARCHIVE_HELPER = Path('/run/shm/fe2o3-native36-1cfb7580f-20261001-attempt-1/source/benchmarks/runtime_gfx942/xgmi_peer_series_transport.py')
ARCHIVE_SHA = 'b0f6f3be586f91261889d1a22aa38470da52f8072820827f017b70e84bbdc675'
NS4 = Path('/run/shm/fe2o3-wait-arithmetic-source-20261001-attempt-4')
NS4_CHECKER_SHA = '5e4bc0792c57b765c07c98b074a2e416c52969b4659f9d63ecd6e116baee18f3'
PROPOSAL = Path('/run/shm/fe2o3-wait-arithmetic-signed-qualification-plan-20261001.md')
PROPOSAL_SHA = '5478660f2dd341ca86ab8ed7dd12cdcd797c3ef31a5299451846ae0e1466826d'

# These reviewed final pins cannot be supplied on the command line or inferred from R5.
CANDIDATE = 'a7d110af1ff14bf71a82799c6224abc7894149e9'
SIGNED_SOURCE = Path('/run/shm/fe2o3-wait-arithmetic-signed-source-20261001-attempt-1')
CPU_EVIDENCE_MODE = 'recovered-r6'
CPU_VALIDATION_CACHE = None
RECOVERY_AUDITOR = Path('/run/shm/fe2o3-wait-arithmetic-r6-readback-20261001-attempt-2.py')
RECOVERY_AUDITOR_SHA = 'ac5c05ce6ac19bab82041fc6f54ce24bbb33d3b62d96359041b05fd24bb76432'
R6_OUTPUT = Path('/run/shm/fe2o3-wait-arithmetic-remote-cpu-transport-20261001-attempt-6')
R6_DURABLE = Path('/mnt/c/fe2o3-wait-arithmetic-remote-cpu-20261001-attempt-6')
RECOVERED_REFERENCES = {
    'source-record': (Path('/run/shm/fe2o3-wait-arithmetic-remote-cpu-owner-20261001-attempt-6/candidate-attempt-1/record.json'), '3021b82149596a562b3c06d1496ba9043cdf4da137583cdb5705074f059fbc01'),
    'transport-prepared': (R6_OUTPUT / 'prepared.json', '7326ffd99eb9e934eeeaaa2ffbe7c4aa092c8e4b24b44f2ab1667f29dd1e935d'),
    'transport-result': (R6_OUTPUT / 'execution/result.json', '0149dffe0a6c53cc2670d8f71c2c0c5d169098e18178a0991545a9c43ea10e53'),
    'transport-census': (R6_OUTPUT / 'execution/fresh-census.json', 'cdb25380577b5b0ea911c23bc6689ae5c3306c6e8def78c186e61041e14c6289'),
    'collection': (R6_OUTPUT / 'execution/collection.json', 'fabc4baa6bd97a957954631a30ac3ea6e85488a555cb0900e1a1f7e11c8ebea6'),
    'inner-archive': (R6_OUTPUT / 'execution/commands/pull-rejected/stdout', 'cbdc7826d9aa2ab5045613ebf2a9ea5c6b15f981ae131e1bdb4bb0878841391b'),
    'durable-result': (R6_DURABLE / 'result.json', 'fc6978a0244ca8c192bc6f6662674c30a49214910261ed9fb4c8042939c576c6'),
    'durable-manifest': (R6_DURABLE / 'final.manifest.json', '5261a37ba0b179f5cab550b70fa86c704c3cd48f1008ae05493927b03d607a2c'),
    'durable-archive': (R6_DURABLE / 'final.tar.gz', 'beab2c40b89967126bd9e5632e3534c065c7073fe5e5b43f81bbd72d0855fb67'),
    'root-readback': (Path('/run/shm/fe2o3-wait-arithmetic-r6-root-readback-20261001.json'), 'dcef9a937af969c8f59125f5e7529393c585c1f33e36c19e347dcca7f6e052f6'),
    'outer-scan': (Path('/run/shm/fe2o3-sensitive-remote-cpu-rejected-agent-20261001-attempt-6.json'), 'd0fba0ff647a56074e5dfc9ef590c1b989974d766eb6965c2f0774f026985d03'),
    'inner-scan': (Path('/run/shm/fe2o3-sensitive-remote-cpu-rejected-inner-agent-20261001-attempt-6.json'), '82b937f53740f142bf1cacb130f042323f4a26b927476952bcd2017c4df24b97'),
}
CPU_REFERENCES = {name: {'path': str(path), 'sha256': value}
                  for name, (path, value) in RECOVERED_REFERENCES.items()}
PREPARATION_NAMES = ('signed-head', 'signed-status', 'signed-signature', 'signed-tree')
REFERENCE_NAMES = {'source-record', 'transport-prepared', 'transport-result', 'transport-census',
                   'collection', 'inner-archive', 'durable-result', 'durable-manifest',
                   'durable-archive', 'root-readback', 'outer-scan', 'inner-scan'}
SOURCE_PREFIX = 'candidate-attempt-1/source/'
SOURCE_ROOTS = ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'examples', '.cargo')
OWN_FILES = ('qualify.py', 'test_qualify.py', 'REVIEW.md')


def need(value, message):
    if not value:
        raise ValueError(message)


def load(path, digest, name):
    need(path.resolve() == path and not path.is_symlink() and
         hashlib.sha256(path.read_bytes()).hexdigest() == digest, 'exact reviewed module: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ac = load(AC / 'capture.py', AC_SHA, 'signed_numeric_capture')
b = ac.b
original_constructed = ac.constructed
original_execute = ac.execute
ac.HERE = HERE


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def source_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def final_bindings():
    need(type(CANDIDATE) is str and re.fullmatch('[0-9a-f]{40}', CANDIDATE),
         'final signed candidate remains unbound until reviewed signing')
    need(isinstance(SIGNED_SOURCE, Path) and SIGNED_SOURCE.resolve() == SIGNED_SOURCE and
         SIGNED_SOURCE.is_dir() and not SIGNED_SOURCE.is_symlink(), 'canonical final signed worktree')
    need(type(CPU_REFERENCES) is dict and set(CPU_REFERENCES) == REFERENCE_NAMES,
         'all reviewed final-candidate CPU/custody/inspection references are required')
    need(CPU_EVIDENCE_MODE in ('accepted-transport', 'recovered-r6'), 'explicit reviewed CPU evidence basis')
    if CPU_EVIDENCE_MODE == 'recovered-r6':
        recovery_bindings()
    for name, row in CPU_REFERENCES.items():
        need(type(row) is dict and set(row) == {'path', 'sha256'} and
             type(row['path']) is str and Path(row['path']).is_absolute() and
             type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']),
             'closed final reference identity: ' + name)
        need(b.sha(Path(row['path'])) == row['sha256'], 'exact final evidence: ' + name)


def reference(name):
    return Path(CPU_REFERENCES[name]['path'])


def json_reference(name):
    return b.prior().parse_json(b.raw(reference(name)))


def archive_metadata(archive, names):
    values = {}
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            if member.name not in names:
                continue
            need(member.isfile() and member.name not in values and member.size <= 16 * 1024**2,
                 'bounded unique ordinary metadata member')
            values[member.name] = stream.extractfile(member).read()
    need(set(values) == set(names), 'complete requested archived metadata')
    return values


def artifact_archive_row(row):
    size = row['size'] if 'cargo_record' in row else row['bytes']
    need(type(size) is int and size > 0, 'actual artifact byte-count schema')
    return {'bytes': size, 'mode': row['mode'], 'sha256': row['sha256']}


def recovery_bindings():
    need(CPU_REFERENCES == {name: {'path': str(path), 'sha256': value}
                           for name, (path, value) in RECOVERED_REFERENCES.items()},
         'recovery is limited to the exact independently inspected R6 evidence')
    need(b.sha(RECOVERY_AUDITOR) == RECOVERY_AUDITOR_SHA, 'unchanged full R6 raw replay auditor')


def recovered_transport_gate(transport, collection):
    recovery_bindings()
    need(transport['accepted'] is False and transport['errors'] == ['RuntimeError: cpu failed'] and
         transport['received'] is True and transport['cleanup_performed'] is False and
         transport['collection']['rejected'] is True and
         collection['qualification_accepted'] is False and collection['partial_custody'] == {
             'missing_payload_files': [], 'changed_payload_files': [], 'qualification_accepted': False,
             'partial_records_preserved_without_reclassification': True},
         'retain the exact SSH-failed transport and complete rejected custody without promotion')


def recovered_readback(cpu_result):
    recovery_bindings()
    root = json_reference('root-readback')
    replay = load(RECOVERY_AUDITOR, RECOVERY_AUDITOR_SHA, 'signed_numeric_recovered_cpu').main()
    expected = {'readback_accepted': True, 'source': 'NS4', 'transport_accepted': False,
                'remote_cpu_all_twenty_stages_accepted': True, 'adoption_performed': False,
                'outer_members': 29, 'inner_members': 6580, 'payload_members': 6474,
                'source_files': 6398, 'cpu_groups': 20, 'cache_groups': 4, 'transport_groups': 7,
                'counts': {'no-default': {'passed': 1841, 'ignored': 0, 'filtered_out': 0},
                           'all-features': {'passed': 1847, 'ignored': 0, 'filtered_out': 0}},
                'elf_sha256': {name: row['sha256'] for name, row in cpu_result['artifacts'].items()},
                'inner_archive_sha256': CPU_REFERENCES['inner-archive']['sha256'],
                'durable_result_sha256': CPU_REFERENCES['durable-result']['sha256'],
                'no_remote_calls': True, 'no_historical_pid_probes': True, 'cleanup_performed': False}
    need(all(root.get(key) == value and replay.get(key) == value for key, value in expected.items()),
         'independent root and fresh read-only replay join every complete R6 CPU/closure identity')
    need(root['audit_script_sha256'] == RECOVERY_AUDITOR_SHA and root['root_exit_code'] == 0 and
         root['transport_cpu_ssh_exit_code'] == 255 and
         root['outer_scan_sha256'] == CPU_REFERENCES['outer-scan']['sha256'] and
         root['inner_scan_sha256'] == CPU_REFERENCES['inner-scan']['sha256'],
         'root acceptance binds the actual failed SSH and both distinct inspection scopes')


def cpu_source_inventory(record, prepared, collection):
    source = record['candidate_inventory']
    need(len(source) == 6398 and record['base_signature_verified'] is True and
         record['source_signed'] is False, 'complete selected CPU source inventory')
    for name, row in source.items():
        key = SOURCE_PREFIX + name
        need(collection['files'][key] == prepared['files'][key] ==
             {field: row[field] for field in ('bytes', 'mode', 'sha256')},
             'every collected CPU source equals the transported source record')
    return source


def complete_cpu_stages(cpu_result, cpu_prepared):
    need(cpu_result['accepted'] is True and cpu_result['errors'] == [] and
         len(cpu_result['rows']) == 20 and all(row['accepted'] is True for row in cpu_result['rows']) and
         [row['name'] for row in cpu_result['rows']] == [row['name'] for row in cpu_prepared['plan']['stages']],
         'all twenty CPU stages accepted in the exact prepared order')


def validate_cpu_bridge():
    """Bind inspected complete CPU custody, not a second generic CPU replay engine."""
    final_bindings()
    p = b.prior()
    transport = json_reference('transport-result')
    collection = json_reference('collection')
    record = json_reference('source-record')
    prepared = json_reference('transport-prepared')
    recovered = CPU_EVIDENCE_MODE == 'recovered-r6'
    if recovered:
        recovered_transport_gate(transport, collection)
    else:
        need(transport['accepted'] is True and transport['errors'] == [] and
             transport['received'] is True and transport['collection']['rejected'] is False and
             collection['qualification_accepted'] is True and collection['partial_custody'] is None,
             'fully accepted final-candidate CPU transport, never a rejected prefix')
    need(transport['collection']['manifest'] == collection and collection['source_signed'] is False and
         collection['gpu_invocations'] == 0 and collection['performance_acceptance'] is False,
         'exact complete unsigned CPU collection with no performance inference')
    need(collection['archive_sha256'] == CPU_REFERENCES['inner-archive']['sha256'] and
         prepared['marker_sha256'] == collection['marker_sha256'], 'CPU source/raw/archive/marker join')
    source = cpu_source_inventory(record, prepared, collection)
    helpers = load(ARCHIVE_HELPER, ARCHIVE_SHA, 'signed_numeric_archive')
    helpers.validate_archive(reference('inner-archive'), collection['files'])
    durable = json_reference('durable-result')
    manifest = json_reference('durable-manifest')
    need(durable['archive_sha256'] == manifest['archive_sha256'] ==
         CPU_REFERENCES['durable-archive']['sha256'] and
         durable['manifest_sha256'] == CPU_REFERENCES['durable-manifest']['sha256'],
         'complete durable archive and manifest binding')
    helpers.validate_archive(reference('durable-archive'), manifest['files'])
    for key, name in (('execution/result.json', 'transport-result'),
                      ('execution/fresh-census.json', 'transport-census'),
                      ('execution/collection.json', 'collection'), ('prepared.json', 'transport-prepared')):
        need(manifest['files'][key]['sha256'] == CPU_REFERENCES[name]['sha256'], 'durable raw/reference join')
    inner_name = str(Path(transport['collection']['archive_path']).relative_to(reference('transport-prepared').parent))
    need(manifest['files'][inner_name]['sha256'] == CPU_REFERENCES['inner-archive']['sha256'],
         'durable complete inner archive, not a filename-based inspection assumption')
    files = archive_metadata(reference('inner-archive'),
                             {'cpu-prepared/record.json', 'cpu-execution/result.json'})
    cpu_prepared = p.parse_json(files['cpu-prepared/record.json'])
    cpu_result = p.parse_json(files['cpu-execution/result.json'])
    need(digest(files['cpu-prepared/record.json']) == collection['cpu_prepared_sha256'] and
         digest(files['cpu-execution/result.json']) == collection['cpu_result_sha256'], 'exact CPU record joins')
    complete_cpu_stages(cpu_result, cpu_prepared)
    for mode, count in (('no-default', 1841), ('all-features', 1847)):
        names = cpu_result['actual_test_rosters'][mode]
        need(len(names) == len(set(names)) == count and
             names == cpu_prepared['snapshot']['expected_rosters'][mode] and
             cpu_result['ignored_rosters'][mode] == [], 'complete feature-specific CPU rosters')
        artifact = cpu_result['artifacts'][mode]
        for row in (artifact, artifact['dep_info']):
            key = str(Path(row['path']).relative_to(Path(transport['remote_root'])))
            need(collection['files'][key] == artifact_archive_row(row),
                 'retained exact feature ELF/dep-info archive join')
    if recovered:
        recovered_readback(cpu_result)
    # Root's separately pinned full readback and both scans remain prerequisites.
    # This wrapper does not reinterpret their formats or substitute summary tests.
    return source, {'references': CPU_REFERENCES, 'source_count': len(source),
                    'source_inventory_sha256': digest(encoded(source)),
                    'cpu_evidence_basis': CPU_EVIDENCE_MODE,
                    'original_transport_accepted': transport['accepted'],
                    'recovered_cpu_adoption_checked': recovered,
                    'recovery_auditor_sha256': RECOVERY_AUDITOR_SHA if recovered else None,
                    'full_cpu_independent_readback_required': True,
                    'outer_and_direct_inner_inspection_required': True}


def cpu_bridge():
    global CPU_VALIDATION_CACHE
    final_bindings()
    key = encoded({'candidate': CANDIDATE, 'signed_source': str(SIGNED_SOURCE), 'mode': CPU_EVIDENCE_MODE,
                   'references': CPU_REFERENCES})
    if CPU_VALIDATION_CACHE is not None:
        saved_key, data = CPU_VALIDATION_CACHE
        need(key == saved_key, 'in-process CPU memo cannot cross candidate/path/reference identities')
        return json.loads(data)
    source, summary = validate_cpu_bridge()
    final_bindings()
    need(key == encoded({'candidate': CANDIDATE, 'signed_source': str(SIGNED_SOURCE), 'mode': CPU_EVIDENCE_MODE,
                         'references': CPU_REFERENCES}), 'no reference identity drift during full validation')
    data = encoded([source, summary])
    CPU_VALIDATION_CACHE = (key, data)
    return json.loads(data)


def source_bridge(source):
    checker = load(NS4 / '.review/check_source.py', NS4_CHECKER_SHA, 'signed_numeric_native_source')
    latest, _ = checker.load()
    expected = {}
    for name, row in source.items():
        path = SIGNED_SOURCE / name
        data = b.raw(path)
        mode = stat.S_IMODE(path.stat().st_mode)
        need(digest(data) == row['sha256'] and len(data) == row['bytes'] and
             bool(mode & 0o111) == bool(row['mode'] & 0o111), 'signed materialization equals every CPU byte/mode')
        expected[name] = {'mode': '100755' if row['mode'] & 0o111 else '100644',
                          'kind': 'blob', 'blob': source_blob(data)}
    for name, text in latest.items():
        need(b.raw(SIGNED_SOURCE / name) == text.encode('ascii'),
             'final signed CPU native buffers are NS4, never silently relabeled NS3')
    git = b.raw(SIGNED_SOURCE / '.git').decode('ascii')
    match = re.fullmatch(r'gitdir: (/[^\n]+)\n', git)
    need(match is not None, 'explicit linked signed worktree')
    gitdir = Path(match[1])
    need(b.raw(gitdir / 'HEAD') == (CANDIDATE + '\n').encode(), 'frozen detached signed HEAD')
    return expected, {str(path): b.sha(path) for path in
                      (SIGNED_SOURCE / '.git', gitdir / 'HEAD', gitdir / 'index')}


def tree_bridge(data, expected):
    observed = {}
    for line in data.split(b'\0'):
        if not line:
            continue
        fields, raw_name = line.split(b'\t')
        mode, kind, oid = fields.decode('ascii').split()
        name = raw_name.decode('utf-8')
        need(name not in observed, 'unique selected signed Git path')
        observed[name] = {'mode': mode, 'kind': kind, 'blob': oid}
    need(observed == expected, 'complete selected signed Git tree equals all CPU bytes')


def constructed():
    negatives, equivalents, projections = original_constructed()
    if SIGNED_SOURCE is not None:
        need(all(b.raw(SIGNED_SOURCE / path) == data for path, data in projections['case'].items()),
             'both signed numeric proof inputs are the unchanged actual mutation preimages')
    return negatives, equivalents, projections


def plan():
    d = b.discovery()
    negatives, equivalents, projections = constructed()
    command = d.command(b.PROOF)
    command[command.index('--multiple-errors') + 1] = '1'
    release = ['/bin/sh', str(b.SIGNED / d.CLOSURE), str(d.VERUS.parent), str(b.SIGNED / d.MANIFEST)]
    stages = [{'name': 'release-before', 'kind': 'release', 'case': None, 'argv': release}]
    for name, kind, case in ([('positive', 'positive', 'case'), ('relocated-positive', 'positive', 'relocated')] +
                             [(name, 'equivalent-positive', name) for name in equivalents] +
                             [(name, 'observation', name) for name in negatives] +
                             [('closing-positive', 'positive', 'case')]):
        stages.append({'name': name, 'kind': kind, 'case': case,
                       'argv': [*command[:-1], str(HERE / 'prepared' / case / b.PROOF)]})
    stages.append({'name': 'release-after', 'kind': 'release', 'case': None, 'argv': release})
    projection_bytes = sum(sum(map(len, files.values())) for files in projections.values())
    own = sum((HERE / name).stat().st_size for name in OWN_FILES)
    # Per-stage classifications appear once beside raw and once in the final result.
    budget = projection_bytes + len(stages) * (2 * ac.STREAM_LIMIT + 2 * ac.STAGE_METADATA_LIMIT) + 8 * 1024**2 + own
    need(len(stages) == 23 and len(projections) == 20 and projection_bytes == 93698 and
         budget < b.OUTPUT_LIMIT, 'closed 23-stage/20-projection physical output allowance')
    return {'stages': stages, 'verifier_identity': b.verifier(), 'negative_candidates': negatives,
            'equivalent_controls': equivalents, 'expected_positive_verified': 7,
            'negative_expected_verified': 6, 'negative_expected_errors': 1,
            'helper_only_none_case': 'sleep-absent-remaining-selected',
            'helper_only_none_scope': 'broader numeric Option contract; native adapter bypasses helper for None',
            'all_other_cases_scope': 'numeric result only; native adapter reachability/refinement unproved',
            'stage_seconds': 130, 'inner_seconds': 120, 'owner_seconds': ac.TOTAL,
            'metadata_owner_seconds': 900, 'metadata_command_seconds': 30,
            'command_bounds_sum_seconds': 2990, 'solver_invocations_if_complete': 21,
            'threads': 4, 'reporting_threshold': 1, 'no_cheating': True, 'no_verify': False,
            'requires_signed_source': True, 'candidate': CANDIDATE,
            'projection_bytes': projection_bytes, 'calculated_physical_allowance_bytes': budget,
            'output_bytes': b.OUTPUT_LIMIT, 'whole_cursor_proved': False, 'std_adapter_proved': False,
            'cpu_invocations': 0, 'gpu_invocations': 0, 'performance_acceptance': False,
            'automatic_next_phase': False, 'cleanup_performed': False}


def snapshot():
    if (HERE / 'prepared/record.json').exists():
        prepared_binding()
    source, cpu = cpu_bridge()
    signed_tree, git_metadata = source_bridge(source)
    p = b.prior()
    pins = {**b.pins(p), **{str(path): value for path, value in ac.HISTORY.items()},
            str(AC / 'capture.py'): AC_SHA, str(CALIBRATION): CALIBRATION_SHA,
            str(PARSER): PARSER_SHA,
            str(CENSUS_HELPER): CENSUS_SHA,
            str(ARCHIVE_HELPER): ARCHIVE_SHA,
            str(CALIBRATION.with_name('test_diagnostics.py')): CALIBRATION_TESTS_SHA,
            str(PROPOSAL): PROPOSAL_SHA, str(NS4 / '.review/check_source.py'): NS4_CHECKER_SHA,
            str(AC / 'prepared/record.json'): '39936af7cb19415e502f424cdb676da11a8c44125340574c349eec148b27bb91',
            str(AC / 'capture-attempt-1/result.json'): '61323a56d2933b27ebb2bf2a7f7d6d4add705657d5c4ee95fc67a50455d382e8',
            str(AC / 'capture-attempt-1/fresh-census.json'): 'f05d1a90f0bd58503f666a9b5c4badf90f34bbf7fe1b385903011e47e17440ce'}
    pins.update({str(AC_DURABLE / name): value for name, value in {
        'final.tar.gz': '7d1feb152f991b559b4dfb0a16823b1a69c828b5c3cf0311e8b3063dcb9b5e91',
        'manifest.json': '6ed00bf7bc5740976dff0072ad3cd30c677d1924444966481ca26c7aa52ab2ac',
        'result.json': '9cdb21add037477c250617b6ac163972f6d7f8b5313b9f905bed1eec1aadb7f0',
    }.items()})
    pins.update({str(HERE / name): b.sha(HERE / name) for name in OWN_FILES})
    need(all(b.sha(Path(path)) == value for path, value in pins.items()), 'all inherited and current source/helper history')
    _, _, projections = constructed()
    value = {'plan': plan(), 'source': b.sources(), 'owners': pins, 'tools': b.tools(p),
             'candidate': CANDIDATE, 'cpu': cpu, 'signed_tree_sha256': digest(encoded(signed_tree)),
             'signed_tree_count': len(signed_tree), 'git_metadata': git_metadata,
             'stable_namespaces': b.stable_namespaces(b.identity()),
             'projected_inputs': {name: {str(path): digest(data) for path, data in files.items()}
                                  for name, files in projections.items()}}
    need(4 * len(encoded(value)) < 8 * 1024**2, 'four compact snapshot copies within fixed allowance')
    return value


def prepare():
    p = b.prior()
    native, hot = b.helpers(p)
    ac.resources(startup=True)
    frozen = snapshot()
    os.umask(0o077)
    output = native.fresh_output(HERE / 'prepared')
    (output / 'tmp').mkdir(mode=0o700)
    recorder = native.FreshRecorder(output / 'commands', SIGNED_SOURCE, hot)
    owner, started = b.identity(), time.monotonic()
    hot.B.write_json(output / 'owner-identity.json', owner)
    env = {**b.discovery().environment(output), 'GIT_OPTIONAL_LOCKS': '0'}
    git = ['/usr/bin/git', '--no-replace-objects', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false']
    commands = [
        ('signed-head', git + ['rev-parse', 'HEAD']),
        ('signed-status', git + ['status', '--porcelain=v1', '-z', '--untracked-files=all']),
        ('signed-signature', git + ['-c', 'gpg.format=ssh', '-c', 'gpg.ssh.program=/usr/bin/ssh-keygen',
          '-c', 'gpg.ssh.allowedSignersFile=' + str(b.SIGNERS), 'verify-commit', CANDIDATE]),
        ('signed-tree', git + ['ls-tree', '-rz', '--full-tree', CANDIDATE, '--', *SOURCE_ROOTS]),
    ]
    errors, completed = [], []
    try:
        with p.handlers(hot.B):
            for name, argv in commands:
                need(time.monotonic() - started + 30 <= 900 and b.identity() == owner, 'bounded metadata owner')
                ac.resources()
                folder = recorder.run(name, argv, 30, env=env)
                stdout, stderr = b.raw(folder / 'stdout'), b.raw(folder / 'stderr')
                if name == 'signed-head':
                    need(stdout == (CANDIDATE + '\n').encode() and not stderr, 'exact signed candidate HEAD')
                elif name == 'signed-status':
                    need(not stdout and not stderr, 'clean signed candidate including untracked paths')
                elif name == 'signed-signature':
                    need(not stdout and stderr == b.SIGNATURE, 'exact permitted SSH signing identity')
                else:
                    source, _ = cpu_bridge()
                    expected, _ = source_bridge(source)
                    need(not stderr, 'signed selected-tree stderr empty')
                    tree_bridge(stdout, expected)
                completed.append(name)
        for name, files in constructed()[2].items():
            for relative, data in files.items():
                destination = output / name / relative
                destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                with destination.open('xb') as stream:
                    stream.write(data)
        ac.cases_match(frozen['projected_inputs'])
        need(snapshot() == frozen and b.identity() == owner and completed == list(PREPARATION_NAMES),
             'all four groups and complete source/tool/case continuity')
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
    finally:
        try:
            b.census(native, hot, recorder, owner['pid_namespace'], output)
        except BaseException as error:
            errors.append('closing census: ' + str(error))
        hot.B.write_json(output / 'result.json', {'accepted': not errors, 'errors': errors})
    need(not errors, 'signed metadata preparation rejected: ' + repr(errors))
    pins = {name: b.sha(output / name) for name in ('result.json', 'fresh-census.json')}
    for name in PREPARATION_NAMES:
        pins.update({'commands/' + name + '/' + leaf: b.sha(output / 'commands' / name / leaf)
                     for leaf in ('receipt.json', 'stdout', 'stderr')})
    record = {**frozen, 'resources': {**ac.resources(), 'preparation_records': pins}}
    need(time.monotonic() - started <= 900 and b.footprint(HERE) + len(encoded(record)) <= b.OUTPUT_LIMIT,
         'metadata final record inside elapsed/physical bounds')
    hot.B.write_json(output / 'record.json', record)
    print(json.dumps({'prepared_sha256': b.sha(output / 'record.json'), 'source_files': 6398,
                      'proof_inputs_each': 2, 'projected_cases': 20}), flush=True)


def prepared_binding():
    p = b.prior()
    output = HERE / 'prepared'
    record = p.parse_json(b.raw(output / 'record.json'))
    names = {'result.json', 'fresh-census.json'} | {
        'commands/' + name + '/' + leaf for name in PREPARATION_NAMES
        for leaf in ('receipt.json', 'stdout', 'stderr')}
    pins = record['resources']['preparation_records']
    need(set(pins) == names and all(b.sha(output / name) == pins[name] for name in names),
         'exact signed metadata records and saved four-group raw joins')
    need(p.parse_json(b.raw(output / 'result.json')) == {'accepted': True, 'errors': []},
         'accepted signed metadata preparation')
    saved = load(CENSUS_HELPER, CENSUS_SHA, 'numeric_saved_preparation_census')
    saved.census_join(output, PREPARATION_NAMES,
                      load(ARCHIVE_HELPER, ARCHIVE_SHA, 'numeric_preparation_archive'))


def observe_mutant(folder, verifier):
    module = load(CALIBRATION, CALIBRATION_SHA, 'signed_numeric_diagnostics')
    builder = load(ac.BUILDER / 'mutations.py', ac.BUILDER_SHA, 'signed_numeric_mutations')
    original = builder.sources()
    case = folder.name
    negatives, _, projections = original_constructed()
    need(case in negatives, 'one of the seventeen closed intended negatives')
    receipt = b.prior().parse_json(b.raw(folder / 'receipt.json'))
    stdout, stderr = ac.bounded_streams(folder)
    root = HERE / 'prepared' / case
    value = module.negative(PARSER, ac.BUILDER / 'mutations.py', verifier,
                            original, projections[case], root, negatives[case], receipt['exit'],
                            stdout.decode(), stderr.decode())
    need(value['qualified_kill'] is False, 'historical classifier never awards fresh signed authority')
    return {'calibration': value, 'signed_numeric_negative_accepted': True,
            'case': case, 'native_adapter_proved': False}


def qualification_summary(raw, prepared_sha):
    expected = plan()
    need(raw['raw_capture_completed'] is True and raw['errors'] == [] and
         raw['positive_counts'] == [7] * 4 and raw['qualified_kills'] == 0 and
         raw['signed_qualification_accepted'] is False, 'unchanged managed raw lifecycle completed')
    need([row['name'] for row in raw['rows']] == [row['name'] for row in expected['stages']] and
         all(row['accepted'] is True for row in raw['rows']), 'all exact fresh stages accepted')
    cases = [row['case'] for row in raw['rows'] if row['kind'] == 'observation']
    need(cases == list(expected['negative_candidates']), 'exact seventeen negative classification rows')
    for row in raw['rows']:
        if row['kind'] == 'observation':
            need(row['observation']['signed_numeric_negative_accepted'] is True and
                 row['observation']['case'] == row['case'] and
                 row['observation']['calibration']['qualified_kill'] is False,
                 'fresh strict classification separate from historical no-kill observations')
    return {'signed_qualification_accepted': True, 'candidate': CANDIDATE,
            'prepared_sha256': prepared_sha, 'fresh_numeric_negative_cases': cases,
            'qualified_numeric_negatives': 17, 'positive_counts': [7] * 4,
            'equivalent_controls': list(expected['equivalent_controls']),
            'historical_raw_qualified_kills': 0, 'whole_cursor_proved': False,
            'std_adapter_proved': False, 'scheduler_proved': False,
            'performance_acceptance': False, 'gpu_invocations': 0,
            'helper_only_none_case': expected['helper_only_none_case']}


def execute(prepared_sha):
    started = time.monotonic()
    status = original_execute(prepared_sha)
    output = HERE / 'capture-attempt-1'
    errors, result = [], {'signed_qualification_accepted': False}
    try:
        need(status == 0, 'managed numeric campaign rejected')
        result = qualification_summary(b.prior().parse_json(b.raw(output / 'result.json')), prepared_sha)
        frozen = b.prior().parse_json(b.raw(HERE / 'prepared/record.json'))
        ac.prepared_matches(frozen, snapshot())
        ac.cases_match(frozen['projected_inputs'])
        need(time.monotonic() - started <= ac.TOTAL, 'qualification finalization inside owner bound')
        result['managed_result_sha256'] = b.sha(output / 'result.json')
        result['fresh_census_sha256'] = b.sha(output / 'fresh-census.json')
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
        result = {'signed_qualification_accepted': False}
    result['errors'] = errors
    data = encoded(result)
    need(len(data) <= 64 * 1024 and b.footprint(HERE) + len(data) <= b.OUTPUT_LIMIT,
         'exact physical aggregate terminal metadata budget')
    with (output / 'qualification-result.json').open('xb') as stream:
        stream.write(data)
    print(data.decode(), end='', flush=True)
    return 0 if result['signed_qualification_accepted'] else 1


# Deliberate, closed adapter points; all managed signals, limits, raw ownership,
# release-finally, separate continuity/census closure and stream bounds stay AC's.
ac.constructed = constructed
ac.plan = plan
ac.snapshot = snapshot
ac.observe_mutant = observe_mutant


if __name__ == '__main__':
    need(sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize, 'python3 -I -B required')
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--prepare', action='store_true')
    modes.add_argument('--execute')
    modes.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        prepare()
    elif args.execute:
        raise SystemExit(execute(args.execute))
    else:
        print(encoded(plan()).decode(), end='')
