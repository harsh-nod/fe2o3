#!/usr/bin/env python3
import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_archive_controls', HERE / 'archive.py')
o = importlib.util.module_from_spec(spec)
spec.loader.exec_module(o)
t = o.old.load(o.old.TRANSPORT, o.old.TRANSPORT_SHA, 'capture_transport_controls')
a = o.old.load(o.old.ARCHIVE, o.old.ARCHIVE_SHA, 'capture_fsync_controls')


class Controls(unittest.TestCase):
    def setUp(self):
        self.prepared = t.parse_json((o.OWNER / 'prepared/record.json').read_bytes())
        self.result = t.parse_json((o.OWNER / 'capture-attempt-1/result.json').read_bytes())

    def test_exact_actual_owner_roster(self):
        self.assertEqual(t.sha(o.OWNER / 'prepared/record.json'), o.PREPARED)
        self.assertEqual(set(t.inventory(o.OWNER)), o.owner_roster(self.prepared))
        self.assertEqual(len(self.prepared['projected_inputs']), 20)
        self.assertTrue(all(len(value) == 2 for value in self.prepared['projected_inputs'].values()))

    def test_exact_all_27_saved_groups_and_raw_joins(self):
        o.old.census_join(o.OWNER / 'prepared', o.q.PREPARATION_NAMES, t)
        stages = self.prepared['plan']['stages']
        o.old.census_join(o.OWNER / 'capture-attempt-1', [row['name'] for row in stages], t,
                          {row['name']: int(row['kind'] == 'observation') for row in stages})
        self.assertEqual(t.sha(o.OWNER / 'capture-attempt-1/result.json'), o.RESULT)
        self.assertEqual(t.sha(o.OWNER / 'capture-attempt-1/fresh-census.json'), o.CENSUS)
        o.captured(self.result, self.prepared)
        qualified = t.parse_json((o.OWNER / 'capture-attempt-1/qualification-result.json').read_bytes())
        o.qualified_result(self.result, qualified)
        self.assertEqual(t.sha(o.OWNER / 'capture-attempt-1/qualification-result.json'), o.QUALIFIED)

    def test_missing_duplicate_or_swapped_result_stage_rejects(self):
        for rows in (self.result['rows'][:-1], self.result['rows'] + self.result['rows'][:1],
                     [self.result['rows'][1], self.result['rows'][0]] + self.result['rows'][2:]):
            value = copy.deepcopy(self.result)
            value['rows'] = rows
            with self.assertRaises(AssertionError):
                o.captured(value, self.prepared)

    def test_result_is_not_qualification(self):
        for key in ('negative_qualification', 'signed_qualification_accepted', 'whole_cursor_proved',
                    'std_adapter_proved', 'automatic_next_phase', 'cleanup_performed'):
            value = copy.deepcopy(self.result)
            value[key] = True
            with self.assertRaises(AssertionError):
                o.captured(value, self.prepared)
        value = copy.deepcopy(self.result)
        value['qualified_kills'] = 17
        with self.assertRaises(AssertionError):
            o.captured(value, self.prepared)

    def test_calibrated_observations_keep_historical_flags_false(self):
        for key in ('qualified_kill', 'signed_campaign_qualified', 'historical_capture_is_qualified_kill'):
            value = copy.deepcopy(self.result)
            value['rows'][4]['observation']['calibration'][key] = True
            with self.assertRaises(AssertionError):
                o.captured(value, self.prepared)

    def test_four_positive_counts_and_raw_negative_counts(self):
        for index in (1, 2, 3, 21):
            value = copy.deepcopy(self.result)
            value['rows'][index]['candidate']['observed_verified'] = 6
            with self.assertRaises(AssertionError):
                o.captured(value, self.prepared)
        value = copy.deepcopy(self.result)
        value['rows'][4]['observation']['calibration']['verified'] = 7
        with self.assertRaises(AssertionError):
            o.captured(value, self.prepared)

    def test_prior_refusal_admission_and_external_custody_pins(self):
        for path, digest in o.HISTORY.items():
            self.assertEqual(t.sha(path), digest)
        prior = t.inventory(o.PREDECESSOR)
        self.assertEqual({name: row['sha256'] for name, row in prior.items()}, o.PRIOR)
        self.assertEqual(set(o.old.predecessor_references(prior)), set(o.PRIOR))

    def test_separate_qualification_wrong_candidate_count_or_census_rejects(self):
        original = t.parse_json((o.OWNER / 'capture-attempt-1/qualification-result.json').read_bytes())
        for update in ({'candidate': '0' * 40}, {'qualified_numeric_negatives': 16},
                       {'fresh_census_sha256': '0' * 64}, {'signed_qualification_accepted': False},
                       {'std_adapter_proved': True}):
            with self.assertRaises(AssertionError):
                o.qualified_result(self.result, {**original, **update})

    def test_exact_cpu_external_references_and_changed_pin_rejection(self):
        rows = o.cpu_references(t)
        self.assertEqual(set(rows), o.q.REFERENCE_NAMES)
        self.assertTrue(all(row['sha256'] == o.q.CPU_REFERENCES[name]['sha256'] for name, row in rows.items()))
        value = copy.deepcopy(o.q.CPU_REFERENCES)
        value['inner-archive']['sha256'] = '0' * 64
        with patch.object(o.q, 'CPU_REFERENCES', value), self.assertRaises(ValueError):
            o.cpu_references(t)

    def test_original_predecessor_owner_buffers_preserved(self):
        for attempt, pins in o.PREVIOUS_OWNERS.items():
            root = Path(str(o.OWNER).replace('attempt-4', 'attempt-' + str(attempt)))
            for name, expected in zip(('qualify.py', 'test_qualify.py', 'REVIEW.md'), pins):
                self.assertEqual(t.sha(root / name), expected)

    def test_unsupported_file_mode_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            path = Path(temporary) / 'data'
            path.write_bytes(b'public')
            path.chmod(0o601)
            with self.assertRaises(ValueError):
                a.public_files(path.parent, t.inventory(path.parent), {'data'}, t)

    def test_missing_or_extra_archive_members_reject(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            (root / 'data').write_bytes(b'public')
            for allowed in (set(), {'data', 'extra'}):
                with self.assertRaises(ValueError):
                    a.public_files(root, t.inventory(root), allowed, t)

    def test_symlink_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            (root / 'data').symlink_to('/dev/null')
            with self.assertRaises(ValueError):
                t.inventory(root)

    def test_private_key_name_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            (root / 'id_ed25519').write_bytes(b'not secret material')
            with self.assertRaises(ValueError):
                a.public_files(root, t.inventory(root), {'id_ed25519'}, t)

    def test_archive_readback_drift(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            source = root / 'source'
            source.mkdir()
            (source / 'data').write_bytes(b'public original bytes')
            files = t.inventory(source)
            archive = root / 'archive.tar.gz'
            t.make_archive(archive, source, files)
            t.validate_archive(archive, files)
            files['data']['sha256'] = '0' * 64
            with self.assertRaises(ValueError):
                t.validate_archive(archive, files)

    def test_path_escape_rejected(self):
        for path in ('../escape', '/absolute', 'a/../escape', 'a\\b'):
            with self.assertRaises(ValueError):
                t.canonical_name(path)


if __name__ == '__main__':
    unittest.main()
