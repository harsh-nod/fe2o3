#!/usr/bin/env python3
"""Retain unsigned numeric discovery source/records; no workloads or cleanup."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
OWNER = Path('/run/shm/fe2o3-wait-arithmetic-discovery-20261001-attempt-1')
SOURCE = Path('/run/shm/fe2o3-wait-arithmetic-source-20261001-attempt-2')
STAGE = Path('/run/shm/fe2o3-wait-arithmetic-discovery-archive-20261001-attempt-1')
DURABLE = Path('/mnt/c/fe2o3-wait-arithmetic-discovery-20261001-attempt-1')
HANDLER = Path('/run/shm/fe2o3-wait-cursor-frontend-handler-controls-20261001-attempt-1')
PREDECESSOR = Path('/mnt/c/fe2o3-wait-arithmetic-frontend-20261001-attempt-2')
TRANSPORT = Path('/run/shm/fe2o3-native36-1cfb7580f-20261001-attempt-1/source/benchmarks/runtime_gfx942/xgmi_peer_series_transport.py')
TRANSPORT_SHA = 'b0f6f3be586f91261889d1a22aa38470da52f8072820827f017b70e84bbdc675'
ARCHIVE = Path('/home/harsh/.codex-tmp/fe2o3-native36-execute-durability-20261001/archive.py')
ARCHIVE_SHA = '5c042d4e953ec29f949c5a42c72d022473789f2cc067521998faa9da7a82ae08'
PREPARED = '10ca03c2c6cddd93a1e56e161de8f3cf240a5a1a1d8d2d5daad2d1042ffda0a4'
RESULT = 'dfd1df926086a45e65e67754252b082d5282c62d310951b3ec1255f9bc3af353'
CENSUS = 'd28388e5900aeaa3784a91c59ecd6feb30281b4b9a6a946115ee1c26ed118726'
POSITIVE_STDOUT = {
    'positive': '1f1ea0713d0ba57a7361d22c74827945472ba42cb0dbef7c3bc312a683ffc59f',
    'relocated-positive': '32bfdc3c465e6afaebfe68ce999e3f0001b5917f4dc67a864d1bb5e47feabea3',
}
BUDGET = 64 * 1024**2


def resources(startup=False):
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    total = sum(max(path.stat().st_size, path.stat().st_blocks * 512)
                for root in (HERE, STAGE, DURABLE) if root.exists()
                for path in root.rglob('*') if path.is_file())
    row = {'tmpfs_free_bytes': shutil.disk_usage(STAGE.parent).free,
           'durable_free_bytes': shutil.disk_usage(DURABLE.parent).free,
           'mem_available_bytes': int(memory['MemAvailable'].split()[0]) * 1024,
           'owned_file_bytes': total, 'guard': 'stage-boundary-only-not-continuous-not-quota'}
    assert min(row['tmpfs_free_bytes'], row['durable_free_bytes']) >= 4 * 1024**3 + (BUDGET if startup else 0)
    assert row['mem_available_bytes'] >= 16 * 1024**3 + (BUDGET if startup else 0)
    assert total + 64 * 1024 <= BUDGET
    return row


def load(path, digest, name):
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def owner_roster(proof_files):
    names = {'common.py', 'discovery.py', 'test_discovery.py', 'PLAN.md', 'REVIEW.md'}
    names |= {'prepared/' + name for name in ('record.json', 'result.json', 'fresh-census.json', 'owner-identity.json')}
    names |= {'prepared/' + case + '/' + name for case in ('case', 'relocated') for name in proof_files}
    for prefix, groups in (('prepared', ('head', 'signature')),
                           ('discovery-attempt-1', ('release-before', 'positive', 'relocated-positive', 'release-after'))):
        names |= {prefix + '/commands/' + group + '/' + leaf
                  for group in groups for leaf in ('receipt.json', 'stdout', 'stderr')}
    names |= {'discovery-attempt-1/' + name for name in (
        'inputs.json', 'environment.json', 'owner-identity.json', 'release-before-result.json',
        'positive-result.json', 'relocated-positive-result.json', 'release-after-result.json', 'continuity-after.json',
        'fresh-census.json', 'result.json')}
    return names


def census_join(root, expected, t, exits=None):
    value = t.parse_json((root / 'fresh-census.json').read_bytes())
    assert value['attempt_order'] == list(expected)
    assert len(value['records']) == len(expected) and {row['name'] for row in value['records']} == set(expected)
    assert set(value['raw_sha256']) == set(expected)
    pids = set()
    for row in value['records']:
        folder = root / 'commands' / row['name']
        assert row['receipt_sha256'] == t.sha(folder / 'receipt.json')
        assert value['raw_sha256'][row['name']] == {leaf: t.sha(folder / leaf) for leaf in ('receipt.json', 'stdout', 'stderr')}
        receipt = t.parse_json((folder / 'receipt.json').read_bytes())
        assert type(receipt['pid']) is int and receipt['pid'] > 0 and receipt['pid'] not in pids
        assert receipt['pid'] == row['pid'] and receipt['group_absent'] is True and receipt['error'] is None
        expected_exit = exits[row['name']] if exits is not None else 0
        assert type(receipt['exit']) is int and receipt['exit'] == expected_exit
        assert receipt['stdout_sha256'] == t.sha(folder / 'stdout') and receipt['stderr_sha256'] == t.sha(folder / 'stderr')
        pids.add(receipt['pid'])
    return value


def captured_discovery(result):
    assert result['unsigned_discovery_completed'] is True and result['errors'] == []
    for key in ('signed_qualification_accepted', 'whole_cursor_proved', 'std_adapter_proved',
                'automatic_next_phase', 'cleanup_performed'):
        assert result[key] is False
    assert type(result['verified_count']) is int and result['verified_count'] == 7
    assert result['cpu_invocations'] == result['gpu_invocations'] == 0
    assert [row['name'] for row in result['rows']] == [
        'release-before', 'positive', 'relocated-positive', 'release-after']
    assert all(row['accepted'] is True for row in result['rows'])
    for row in result['rows'][1:3]:
        assert row['raw'] == {'normal_exit': 0, 'exit_zero': True,
                              'raw_capture_only': True, 'proof_acceptance': False}
        assert row['candidate'] == {
            'candidate_accepted': True, 'candidate_verified': 7, 'observed_verified': 7,
            'expected_result': {'encountered-error': False, 'encountered-vir-error': False,
                                'errors': 0, 'is-verifying-entire-crate': True,
                                'success': True, 'verified': 7}}


def predecessor_references(files):
    assert set(files) == {'final.tar.gz', 'manifest.json', 'result.json'}
    return {name: {'original_path': str(PREDECESSOR / name), **row} for name, row in files.items()}


def main():
    assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
    t = load(TRANSPORT, TRANSPORT_SHA, 'cursor_archive_transport')
    a = load(ARCHIVE, ARCHIVE_SHA, 'cursor_archive_fsync')
    os.umask(0o077)
    for path in (STAGE, DURABLE):
        assert path.parent.resolve() == path.parent and not path.exists() and not path.is_symlink()
    opening_resources = resources(startup=True)
    assert t.sha(OWNER / 'prepared/record.json') == PREPARED
    assert t.sha(OWNER / 'discovery-attempt-1/result.json') == RESULT
    assert t.sha(OWNER / 'discovery-attempt-1/fresh-census.json') == CENSUS
    prepared = t.parse_json((OWNER / 'prepared/record.json').read_bytes())
    result = t.parse_json((OWNER / 'discovery-attempt-1/result.json').read_bytes())
    captured_discovery(result)
    for name, digest in POSITIVE_STDOUT.items():
        assert t.sha(OWNER / 'discovery-attempt-1/commands' / name / 'stdout') == digest
        assert not (OWNER / 'discovery-attempt-1/commands' / name / 'stderr').read_bytes()
    assert all(t.sha(Path(path)) == digest for path, digest in prepared['owners'].items())
    for root, expected in ((OWNER / 'prepared', ('head', 'signature')),
                           (OWNER / 'discovery-attempt-1', ('release-before', 'positive', 'relocated-positive', 'release-after'))):
        census_join(root, expected, t)
    census_join(HANDLER / 'records', ('exit-0', 'exit-1', 'exit-2'), t,
                {'exit-0': 0, 'exit-1': 1, 'exit-2': 2})
    original_owner = t.inventory(OWNER)
    assert set(original_owner) == owner_roster(prepared['two_inputs'])
    originals = {'owner/' + name: (OWNER / name, row) for name, row in original_owner.items()}
    for row in prepared['source']['records']:
        path = SOURCE / row['path']
        expected = {key: row[key] for key in ('sha256', 'bytes', 'mode')}
        assert t.inventory_row(path) == expected
        originals['source/' + row['path']] = (path, expected)
    for name, row in t.inventory(SOURCE / '.review').items():
        originals['source-review/' + name] = (SOURCE / '.review' / name, row)
    for name in ('archive.py', 'test_archive.py', 'REVIEW.md'):
        originals['archive-owner/' + name] = (HERE / name, t.inventory_row(HERE / name))
    handler_files = t.inventory(HANDLER)
    expected_handler = {'handler.py', 'exercise.py', 'records/result.json', 'records/fresh-census.json'}
    expected_handler |= {'records/commands/' + group + '/' + leaf for group in ('exit-0', 'exit-1', 'exit-2')
                         for leaf in ('receipt.json', 'stdout', 'stderr')}
    assert set(handler_files) == expected_handler
    for name, row in handler_files.items():
        originals['handler-custody/' + name] = (HANDLER / name, row)
    prior_files = t.inventory(PREDECESSOR)
    prior_references = predecessor_references(prior_files)
    assert sum(row['bytes'] for _, row in originals.values()) < BUDGET // 4
    STAGE.mkdir(mode=0o700)
    DURABLE.mkdir(mode=0o700)
    packet = STAGE / 'packet'
    packet.mkdir(mode=0o700)
    for name, (path, row) in originals.items():
        resources()
        destination = packet / name
        destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        assert path.resolve() == path and path.stat().st_nlink == 1 and t.inventory_row(path) == row
        shutil.copy2(path, destination)
    t.save(packet / 'original-index.json', {name: {'original_path': str(path), **row} for name, (path, row) in originals.items()})
    t.save(packet / 'summary.json', {
        'schema': 'fe2o3.wait-arithmetic-unsigned-discovery.v1', 'base': prepared['source']['base'],
        'prepared_sha256': PREPARED, 'unsigned_discovery_result_sha256': RESULT, 'discovery_census_sha256': CENSUS,
        'source_files': len(prepared['source']['records']), 'proof_inputs': len(prepared['two_inputs']),
        'tool_identities': len(prepared['tools']), 'prepare_groups': 2, 'discovery_groups': 4,
        'observed_errors': [], 'positive_stdout_sha256': POSITIVE_STDOUT,
        'observed_positive_exits': [0, 0], 'no_verify': False, 'observed_verified': [7, 7],
        'no_cheating_not_relaxed': True,
        'source_patch_header_note': 'predecessor.patch labels numeric attempt-1/attempt-2; all six predecessor sources remain external pinned prerequisites',
        'unsigned_discovery_completed': True, 'signed_qualification_accepted': False,
        'whole_cursor_proved': False, 'std_adapter_proved': False,
        'handler_exercise_groups': 3, 'predecessor_archive_references': prior_references,
        'predecessor_owner_rejection_preserved': True,
        'prior_attempts': 'All four std-contract frontends remain rejected; numeric frontend attempt-1 remains unlaunched; prior archive rejection and all original custody remain retained.',
        'negative_cases_run': 0, 'source_signed': False,
        'cpu_builds': 0, 'gpu_runs': 0, 'cleanup_performed': False, 'resources_before': opening_resources,
        'not_self_contained': 'Tool binaries/std closure, inherited managed helpers, signed Git ancestor objects, numeric attempt-1 source/owner/preparation paths, the complete NF2 predecessor source/records and the three explicitly referenced predecessor archive files remain external pinned prerequisites. Source/control absolute paths require explicit relocation. No private Git metadata or build caches are archived.'})
    files = t.inventory(packet)
    t.bounded_manifest(files, BUDGET // 2)
    allowed = set(originals) | {'original-index.json', 'summary.json'}
    a.public_files(packet, files, allowed, t)
    resources()
    archive = DURABLE / 'final.tar.gz'
    t.make_archive(archive, packet, files)
    a.fsync_file(archive)
    manifest = {'schema': 'fe2o3.wait-cursor-full-member-archive.v1', 'archive_sha256': t.sha(archive),
                'archive_bytes': archive.stat().st_size, 'files': files, 'signed_qualification_accepted': False,
                'source_and_owner_rejections_preserved': True, 'tmpfs_cleanup_performed': False}
    manifest_sha = a.save_durable(DURABLE / 'manifest.json', manifest, t)
    resources()
    readback = t.parse_json((DURABLE / 'manifest.json').read_bytes())
    assert readback == manifest and t.sha(DURABLE / 'manifest.json') == manifest_sha
    t.validate_archive(archive, readback['files'])
    assert t.sha(archive) == readback['archive_sha256']
    assert t.inventory(OWNER) == original_owner
    assert all(t.inventory_row(path) == row for path, row in originals.values())
    assert t.inventory(packet) == files
    assert t.inventory(PREDECESSOR) == prior_files
    closing_resources = resources()
    a.fsync_directory(DURABLE)
    a.fsync_directory(DURABLE.parent)
    receipt = {'archived_unsigned_discovery': True, 'unsigned_discovery_completed': True,
               'members': len(files), 'manifest_sha256': manifest_sha,
               'archive_sha256': t.sha(archive), 'archive_bytes': archive.stat().st_size,
               'full_member_hash_mode_readback': True, 'file_directory_parent_fsync_returned': True,
               'signed_qualification_accepted': False, 'verified_counts': [7, 7],
               'whole_cursor_proved': False, 'std_adapter_proved': False,
               'tmpfs_originals_retained': True,
               'resources_after': closing_resources}
    a.save_durable(DURABLE / 'result.json', receipt, t)
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
