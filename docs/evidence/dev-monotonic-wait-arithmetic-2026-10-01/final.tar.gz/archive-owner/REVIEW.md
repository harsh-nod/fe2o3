# Signed Numeric Custody

Narrow successor of the reviewed AC archive owner c9dc7d74, retaining its ND
ancestor, ordinary-file copy2 roster, mode/hash checks, archive/final readback,
fsync and resource bounds. Fresh source/staging/durable namespaces are distinct
from all existing attempts. Execution remains pending root source review.

The packet retains exactly all 158 Q4 owner files, six actual signed NS4 source
buffers, the two NS4 review files, Q1/Q2/Q3 owner buffers, admission and review
history, root R6 recovery readback/scans, and this archive owner/ancestor. The
summary contains exact external CPU and AC prerequisite references; full CPU
archives/ELFs and build caches are not duplicated. No private Git metadata or
credential material is selected. Every original is retained.

Q4's four metadata groups and 23 execution groups are replayed using existing
saved-census and strict diagnostic helpers. The pinned full readback f5680cb5
additionally reconstructs argv, environment, deadline, positive/release results,
source/tool/Git/CPU joins and all 20 two-input projections before archival.
Its predecessor 07b57632 is retained: its final caller incorrectly compared
JSON-sorted negative object keys with the explicitly ordered execution stages.
The corrected readback changes only that comparison. An earlier inline caller
also mistook continuity-after resources for a full snapshot; no original was
changed and neither audit rejection implied a campaign rerun.

The managed result remains signed:false with zero historical qualified kills.
Only the separate complete signed result b2b569c5 records 17 qualified numeric
negatives with four full 7/0 positives. R6 SSH transport remains rejected;
its complete CPU evidence is recovered under the separately reviewed branch.
No std adapter, whole-cursor, constructor, scheduler, GPU or performance claim
is added. The absent-None case remains a broader numeric-helper contract case.

Bounds remain 300 seconds plus 30 seconds grace, 64 MiB combined owned staging
and durable output, 16 GiB plus allowance startup RAM and 4 GiB disk floors on
both filesystems, with the ancestor's stage-boundary enforcement. Members are
bounded below 16 MiB before copying, and the archive roster below 32 MiB.
No retries or cleanup; rejected partial custody stays preserved. The packet is
explicitly not self-contained: signed Git objects, pinned tool/std binaries,
managed helper and native checker ancestors, raw CPU/ELF durable archives and
earlier AC/ND/NF/std-boundary histories remain external replay prerequisites.

Controls cover actual complete Q4 roster/raw/census/diagnostics, result-scope
and candidate/count/census changes, source/recovery pins and predecessor buffers,
missing/extra members, symlinks, private-key names, wrong modes, archive drift
and path escapes. Tests use only local owned fixtures; no compiler or solver.

The first control run (24730, terminal fb89f9) rejected a fixture assumption:
inventory records arbitrary ordinary-file permission bits; the existing
bounded_manifest/public_files archive gate rejects unsupported modes. The
control now calls that actual production gate. No production policy changed,
no archive was executed and no original file was modified.
