#!/usr/bin/env python3
"""Retain complete signed numeric evidence while preserving historical rejections."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ANCESTOR = Path('/run/shm/fe2o3-wait-arithmetic-discovery-archive-owner-20261001-attempt-1/archive.py')
ANCESTOR_SHA = '7fddeef723edd5197dbf094a89a0fa2f4ab06f6739373611bed471bc250dc51d'
assert hashlib.sha256(ANCESTOR.read_bytes()).hexdigest() == ANCESTOR_SHA
spec = importlib.util.spec_from_file_location('capture_archive_ancestor', ANCESTOR)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
OWNER = Path('/run/shm/fe2o3-wait-arithmetic-signed-qualification-20261001-attempt-4')
SOURCE = Path('/run/shm/fe2o3-wait-arithmetic-signed-source-20261001-attempt-1')
STAGE = Path('/run/shm/fe2o3-wait-arithmetic-signed-archive-20261001-attempt-1')
DURABLE = Path('/mnt/c/fe2o3-wait-arithmetic-signed-qualification-20261001-attempt-1')
PREDECESSOR = Path('/mnt/c/fe2o3-wait-arithmetic-capture-20261001-attempt-1')
PREPARED = 'ac439ba25bc5b15b2b095bde0387e8825416ece0ba1a38561c7c8496c0ac9f5c'
RESULT = 'ae60323f01b7b4f044e358ea529d7a48ae9b9506ae4dc017567b346cb55c07ba'
CENSUS = 'a3cc443e7db9661eea551b6d5ff52add82d55b8cdcefd1591e25c1c6e08d197e'
QUALIFIED = 'b2b569c5bb4708c605052df00097a3c4566fe1ba47247e9e5dfddc679e562e91'
REPLAY = Path('/run/shm/fe2o3-wait-arithmetic-signed-readback-20261001-attempt-2.py')
REPLAY_SHA = 'f5680cb5300a2bc4b05fd4866235d6581903e3575f4f79d510137586e5c53adf'
q = old.load(OWNER / 'qualify.py', '642eebe056e6bcf97d1aca2033f359d300c7e9a02935722b623759ed2c131777', 'signed_custody_owner')
BUDGET = old.BUDGET
HISTORY = {
    Path('/run/shm/fe2o3-wait-arithmetic-signed-admission-20261001-attempt-1.py'):
        '2d16c485815f8704f9b2cf79e2340e2ba9c552c8210a56e4ba0ed0a345b7047d',
    Path('/run/shm/fe2o3-wait-arithmetic-signed-admission-20261001-attempt-1.json'):
        '48882c965cd7418481407e1dc332193aee20cb88ef49c4856365a02d3d159992',
    Path('/run/shm/fe2o3-wait-arithmetic-signed-custody-plan-20261001.md'):
        '6b548cd721547c2b92a2ede45f5595a149a78de452fc613bf827e913d6989135',
    q.PROPOSAL: q.PROPOSAL_SHA,
    REPLAY: REPLAY_SHA,
    q.RECOVERY_AUDITOR: q.RECOVERY_AUDITOR_SHA,
}
PREVIOUS_OWNERS = {
    1: ('aae7c6805794dad17e4135cf3b898a28108a88b045ee48a0b4e341e2c5476efc',
        'c650e453d57f81f396d0514f54b78faf033827e4e82cdb7742828be03bf428fc',
        'abe5436cec0b1c0fa0574e5123d4bd10601c88d01c14719727bafbe9e145ff3d'),
    2: ('0ed184289ca9896210b8d09b7b5c48c3cf4c0e2255777ad989ad2283aeb7f0d9',
        'abfa3df6dd4788eb8c4ea2e38f23666ef2cd039e244c280a0350113b2999e978',
        '50036d9bf540e1eab8ddb8576d9d689fe35054fe5df00a4cbaf1ba4d4e4c9789'),
    3: ('f937174576b8d8cc2850202e611fb8ce97f2d6a914e38b34314ba4505f377c1e',
        '0bbe515c30711bc61dc08266734d6ced75d26c7165707c608f791e4e34d8c2f7',
        'f09c6a043d57c4d136816b5c436f8312f8daee2ab0f74397a0d4450d77cf433b'),
}
PRIOR = {
    'final.tar.gz': '7d1feb152f991b559b4dfb0a16823b1a69c828b5c3cf0311e8b3063dcb9b5e91',
    'manifest.json': '6ed00bf7bc5740976dff0072ad3cd30c677d1924444966481ca26c7aa52ab2ac',
    'result.json': '9cdb21add037477c250617b6ac163972f6d7f8b5313b9f905bed1eec1aadb7f0',
}
old.HERE, old.STAGE, old.DURABLE = HERE, STAGE, DURABLE
old.PREDECESSOR = PREDECESSOR


def owner_roster(prepared):
    names = {'qualify.py', 'test_qualify.py', 'REVIEW.md'}
    names |= {'prepared/' + name for name in ('record.json', 'result.json', 'fresh-census.json', 'owner-identity.json')}
    for case, files in prepared['projected_inputs'].items():
        names |= {'prepared/' + case + '/' + name for name in files}
    stages = prepared['plan']['stages']
    for prefix, groups in (('prepared', q.PREPARATION_NAMES),
                           ('capture-attempt-1', tuple(row['name'] for row in stages))):
        names |= {prefix + '/commands/' + group + '/' + leaf
                  for group in groups for leaf in ('receipt.json', 'stdout', 'stderr')}
    names |= {'capture-attempt-1/' + name for name in (
        'inputs.json', 'environment.json', 'owner-identity.json', 'continuity-after.json',
        'fresh-census.json', 'result.json', 'qualification-result.json')}
    names |= {'capture-attempt-1/' + row['name'] + '-result.json' for row in stages}
    return names


def captured(result, prepared):
    assert result['raw_capture_completed'] is True and result['errors'] == []
    assert result['positive_counts'] == [7, 7, 7, 7]
    assert type(result['qualified_kills']) is int and result['qualified_kills'] == 0
    for key in ('negative_qualification', 'signed_qualification_accepted', 'whole_cursor_proved',
                'std_adapter_proved', 'automatic_next_phase', 'cleanup_performed'):
        assert result[key] is False
    assert result['cpu_invocations'] == result['gpu_invocations'] == 0
    stages = prepared['plan']['stages']
    assert len(stages) == 23 and [row['name'] for row in result['rows']] == [row['name'] for row in stages]
    assert all(row['accepted'] is True for row in result['rows'])
    for row, stage in zip(result['rows'], stages):
        assert row['kind'] == stage['kind'] and row['case'] == stage['case']
        if row['kind'] == 'release':
            continue
        negative = row['kind'] == 'observation'
        assert row['raw'] == {'normal_exit': int(negative), 'exit_zero': not negative,
                              'raw_capture_only': True, 'proof_acceptance': False}
        if negative:
            observation = row['observation']
            assert observation == q.observe_mutant(OWNER / 'capture-attempt-1/commands' / row['name'],
                                                   prepared['plan']['verifier_identity'])
        else:
            assert row['candidate'] == {
                'candidate_accepted': True, 'candidate_verified': 7, 'observed_verified': 7,
                'expected_result': {'encountered-error': False, 'encountered-vir-error': False,
                                    'errors': 0, 'is-verifying-entire-crate': True, 'success': True, 'verified': 7}}


def qualified_result(result, qualified):
    expected = q.qualification_summary(result, PREPARED)
    expected.update(managed_result_sha256=RESULT, fresh_census_sha256=CENSUS, errors=[])
    assert qualified == expected


def cpu_references(t):
    q.final_bindings()
    return {name: {'original_path': str(q.reference(name)), **t.inventory_row(q.reference(name))}
            for name in q.REFERENCE_NAMES}


def main():
    assert sys.flags.isolated and sys.dont_write_bytecode and not sys.flags.optimize
    t = old.load(old.TRANSPORT, old.TRANSPORT_SHA, 'capture_transport')
    a = old.load(old.ARCHIVE, old.ARCHIVE_SHA, 'capture_fsync')
    os.umask(0o077)
    for path in (STAGE, DURABLE):
        assert path.parent.resolve() == path.parent and not path.exists() and not path.is_symlink()
    opening = old.resources(startup=True)
    assert t.sha(OWNER / 'prepared/record.json') == PREPARED
    assert t.sha(OWNER / 'capture-attempt-1/result.json') == RESULT
    assert t.sha(OWNER / 'capture-attempt-1/fresh-census.json') == CENSUS
    assert t.sha(OWNER / 'capture-attempt-1/qualification-result.json') == QUALIFIED
    prepared = t.parse_json((OWNER / 'prepared/record.json').read_bytes())
    result = t.parse_json((OWNER / 'capture-attempt-1/result.json').read_bytes())
    captured(result, prepared)
    qualified_result(result, t.parse_json((OWNER / 'capture-attempt-1/qualification-result.json').read_bytes()))
    replay = old.load(REPLAY, REPLAY_SHA, 'signed_numeric_full_custody_replay').main()
    assert replay['readback_accepted'] is True and replay['qualified_numeric_negatives'] == 17
    assert all(t.sha(Path(path)) == digest for path, digest in prepared['owners'].items())
    old.census_join(OWNER / 'prepared', q.PREPARATION_NAMES, t)
    stages = prepared['plan']['stages']
    old.census_join(OWNER / 'capture-attempt-1', [row['name'] for row in stages], t,
                    {row['name']: int(row['kind'] == 'observation') for row in stages})
    owner_files = t.inventory(OWNER)
    assert len(owner_files) == 158 and set(owner_files) == owner_roster(prepared)
    originals = {'owner/' + name: (OWNER / name, row) for name, row in owner_files.items()}
    checker = old.load(q.NS4 / '.review/check_source.py', q.NS4_CHECKER_SHA, 'signed_custody_native_source')
    native, _ = checker.load()
    source_record = q.json_reference('source-record')['candidate_inventory']
    for name, text in native.items():
        path = SOURCE / name
        row = t.inventory_row(path)
        expected = source_record[name]
        assert path.read_bytes() == text.encode('ascii') and row['sha256'] == expected['sha256']
        assert row['bytes'] == expected['bytes'] and bool(row['mode'] & 0o111) == bool(expected['mode'] & 0o111)
        originals['source/' + name] = (path, row)
    assert len(native) == 6
    for name, expected in (('check_source.py', q.NS4_CHECKER_SHA),
                           ('REVIEW.md', '88416a59208624e115f75cb63b6ca25fcae7683bfc8744ee4ba7bb3d89cea065')):
        path = q.NS4 / '.review' / name
        assert t.sha(path) == expected
        originals['source-review/' + name] = (path, t.inventory_row(path))
    for name in ('archive.py', 'test_archive.py', 'REVIEW.md'):
        originals['archive-owner/' + name] = (HERE / name, t.inventory_row(HERE / name))
    originals['archive-owner/ancestor.py'] = (ANCESTOR, t.inventory_row(ANCESTOR))
    for path, digest in HISTORY.items():
        assert t.sha(path) == digest
        originals['review-history/' + path.name] = (path, t.inventory_row(path))
    for attempt, pins in PREVIOUS_OWNERS.items():
        root = Path(str(OWNER).replace('attempt-4', 'attempt-' + str(attempt)))
        for name, expected in zip(('qualify.py', 'test_qualify.py', 'REVIEW.md'), pins):
            path = root / name
            assert t.sha(path) == expected
            originals['previous-owners/' + str(attempt) + '/' + name] = (path, t.inventory_row(path))
    for name in ('root-readback', 'outer-scan', 'inner-scan'):
        path = q.reference(name)
        assert t.sha(path) == q.CPU_REFERENCES[name]['sha256']
        originals['cpu-recovery/' + name + '.json'] = (path, t.inventory_row(path))
    cpu = cpu_references(t)
    prior = t.inventory(PREDECESSOR)
    assert {name: row['sha256'] for name, row in prior.items()} == PRIOR
    references = old.predecessor_references(prior)
    assert sum(row['bytes'] for _, row in originals.values()) < BUDGET // 4
    STAGE.mkdir(mode=0o700)
    DURABLE.mkdir(mode=0o700)
    packet = STAGE / 'packet'
    packet.mkdir(mode=0o700)
    for name, (path, row) in originals.items():
        old.resources()
        destination = packet / name
        destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        assert path.resolve() == path and path.stat().st_nlink == 1 and t.inventory_row(path) == row
        shutil.copy2(path, destination)
    t.save(packet / 'original-index.json', {name: {'original_path': str(path), **row} for name, (path, row) in originals.items()})
    t.save(packet / 'summary.json', {
        'schema': 'fe2o3.wait-arithmetic-signed-qualification.v1', 'candidate': q.CANDIDATE,
        'prepared_sha256': PREPARED, 'result_sha256': RESULT, 'census_sha256': CENSUS,
        'qualified_result_sha256': QUALIFIED, 'source_files': 6, 'full_cpu_source_files': 6398,
        'two_input_cases': 20, 'prepare_groups': 4, 'capture_groups': 23,
        'observed_positive_counts': [7, 7, 7, 7], 'qualified_numeric_negatives': 17,
        'observed_negative_counts': [[6, 1]] * 17, 'historical_raw_qualified_kills': 0,
        'signed_qualification_accepted': True, 'original_transport_accepted': False,
        'whole_cursor_proved': False, 'std_adapter_proved': False,
        'scope': 'numeric results only; no native-reachability claim; None case is broader helper contract only',
        'prior_attempts_preserved': True, 'predecessor_archive_references': references,
        'cpu_prerequisite_references': cpu, 'full_readback': replay,
        'resources_before': opening, 'cpu_builds': 0, 'gpu_runs': 0, 'cleanup_performed': False,
        'not_self_contained': 'Pinned tool/std binaries, managed helpers, mutation builder and controls, signed Git objects, full CPU source/raw/ELF archives, native checker predecessors, Q1-Q4 std-boundary failures and AC/ND/NF2 histories remain external replay prerequisites. Paths require explicit relocation. No private Git metadata, credentials, or build caches are archived.'})
    files = t.inventory(packet)
    t.bounded_manifest(files, BUDGET // 2)
    a.public_files(packet, files, set(originals) | {'original-index.json', 'summary.json'}, t)
    old.resources()
    archive = DURABLE / 'final.tar.gz'
    t.make_archive(archive, packet, files)
    a.fsync_file(archive)
    manifest = {'schema': 'fe2o3.wait-cursor-full-member-archive.v1', 'archive_sha256': t.sha(archive),
                'archive_bytes': archive.stat().st_size, 'files': files, 'signed_qualification_accepted': True,
                'source_and_owner_rejections_preserved': True, 'tmpfs_cleanup_performed': False}
    manifest_sha = a.save_durable(DURABLE / 'manifest.json', manifest, t)
    old.resources()
    assert t.parse_json((DURABLE / 'manifest.json').read_bytes()) == manifest
    assert t.sha(DURABLE / 'manifest.json') == manifest_sha
    t.validate_archive(archive, files)
    assert t.sha(archive) == manifest['archive_sha256']
    assert t.inventory(OWNER) == owner_files and t.inventory(packet) == files and t.inventory(PREDECESSOR) == prior
    assert all(t.inventory_row(path) == row for path, row in originals.values())
    assert cpu_references(t) == cpu
    closing = old.resources()
    a.fsync_directory(DURABLE)
    a.fsync_directory(DURABLE.parent)
    receipt = {'archived_signed_numeric_qualification': True, 'members': len(files), 'manifest_sha256': manifest_sha,
               'archive_sha256': t.sha(archive), 'archive_bytes': archive.stat().st_size,
               'full_member_hash_mode_readback': True, 'file_directory_parent_fsync_returned': True,
               'historical_raw_qualified_kills': 0, 'qualified_numeric_negatives': 17,
               'signed_qualification_accepted': True, 'original_transport_accepted': False,
               'whole_cursor_proved': False, 'std_adapter_proved': False,
               'tmpfs_originals_retained': True, 'resources_after': closing}
    a.save_durable(DURABLE / 'result.json', receipt, t)
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
