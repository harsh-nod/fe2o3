#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
tar -xf "$root/registry-cache.tar" -C "$root/cargo-home"
tar -xzf "$root/cpu-overlay.tar.gz" -C "$root/source"
cd "$root/source"
sha256sum -c "$root/cpu-overlay.sha256"
export RUST_TEST_THREADS=4
run() {
    name=$1
    shift
    date -u '+%Y-%m-%dT%H:%M:%SZ'
    printf 'BEGIN %s\n' "$name"
    printf '%s\n' "$@" > "$root/logs/$name.arguments"
    date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs/$name.started"
    if sh "$root/run-cargo.sh" "$@" > "$root/logs/$name.log" 2>&1; then
        printf '0\n' > "$root/logs/$name.exit"
        date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs/$name.finished"
        tail -n 4 "$root/logs/$name.log"
        printf 'PASS %s\n' "$name"
    else
        status=$?
        printf '%s\n' "$status" > "$root/logs/$name.exit"
        date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs/$name.finished"
        tail -n 100 "$root/logs/$name.log"
        printf 'FAIL %s status=%s\n' "$name" "$status"
        exit "$status"
    fi
}
run uapi test --locked --offline -p fe2o3-kfd-uapi -j2
run a1-scale test --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 retained_launch_context_scale_1024 -- --test-threads=1
run a1-payload test --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 kfd_backend::compute_launch_payload::tests -- --test-threads=1
run a1-runtime-lib test --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 -- --test-threads=4
run a3-doorbell test --locked --offline -p fe2o3-kfd --lib -j2 gfx950_doorbell_plan -- --test-threads=1
run a3-kfd-doc test --locked --offline -p fe2o3-kfd --doc -j2
run a3-kfd-lib test --locked --offline -p fe2o3-kfd --lib -j2 -- --test-threads=4
run a1-runtime-doc test --locked --offline -p fe2o3-runtime --doc --features scale-qualification -j2
run a1-runtime-clippy clippy --locked --offline -p fe2o3-runtime --lib --tests --features scale-qualification -j2 -- -D warnings
run a3-uapi-clippy clippy --locked --offline -p fe2o3-kfd-uapi --all-targets -j2 -- -D warnings
run a3-kfd-clippy clippy --locked --offline -p fe2o3-kfd --lib -j2 -- -D warnings
sha256sum -c "$root/cpu-overlay.sha256"
printf 'CPU_CAMPAIGN_COMPLETE\n'
