#!/bin/sh
set -eu
archive=/dev/shm/fe2o3-a123-20261006-Q1vIEpGg/agent-evidence.tar.gz
expected=4561551dbcd4adfa4b2562144ee4b3cf97244a9ed24916e631fc7b7eb1d46e82
actual=$(sha256sum "$archive" | awk '{print $1}')
test "$actual" = "$expected"
tar -dzf "$archive" -C /dev/shm
for path in /dev/shm/fe2o3-a1-scale-note-20261006.Z8qeEyQ5 /dev/shm/fe2o3-a2-reader-20261006.yWrwWG /dev/shm/fe2o3-gfx950-output-source-20261006-9DGORPRZ; do
    test -d "$path"
    rm -r -- "$path"
    test ! -e "$path"
    printf 'OWNED_AGENT_SCRATCH_REMOVED %s\n' "$path"
done
date -u '+%Y-%m-%dT%H:%M:%SZ'
