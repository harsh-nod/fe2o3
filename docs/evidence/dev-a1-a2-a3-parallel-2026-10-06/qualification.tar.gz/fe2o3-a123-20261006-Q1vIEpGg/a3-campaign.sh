#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
mkdir "$root/logs.a3"
cd "$root/source"
sha256sum -c "$root/cpu-overlay.sha256"
export RUST_TEST_THREADS=4
run() {
    name=$1
    shift
    printf 'BEGIN %s\n' "$name"
    printf '%s\n' "$@" > "$root/logs.a3/$name.arguments"
    date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs.a3/$name.started"
    if sh "$root/run-cargo.sh" "$@" > "$root/logs.a3/$name.log" 2>&1; then
        printf '0\n' > "$root/logs.a3/$name.exit"
        date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs.a3/$name.finished"
        tail -n 5 "$root/logs.a3/$name.log"
        printf 'PASS %s\n' "$name"
    else
        status=$?
        printf '%s\n' "$status" > "$root/logs.a3/$name.exit"
        date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs.a3/$name.finished"
        tail -n 100 "$root/logs.a3/$name.log"
        exit "$status"
    fi
}
run a3-doorbell test --locked --offline -p fe2o3-kfd --lib -j2 gfx950_doorbell_plan -- --test-threads=1
run a3-kfd-doc test --locked --offline -p fe2o3-kfd --doc -j2
run a3-kfd-lib test --locked --offline -p fe2o3-kfd --lib -j2 -- --test-threads=4
run a3-uapi-clippy clippy --locked --offline -p fe2o3-kfd-uapi --all-targets -j2 -- -D warnings
run a3-kfd-clippy clippy --locked --offline -p fe2o3-kfd --lib -j2 -- -D warnings
sha256sum -c "$root/cpu-overlay.sha256"
printf 'A3_CPU_CAMPAIGN_COMPLETE\n'
