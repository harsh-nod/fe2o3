#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
test -d "$root"
if pgrep -af "$root/(target|cargo-home|tmp|source)"; then
    printf 'ERROR: owned build or test processes remain\n' >&2
    exit 1
else
    status=$?
    test "$status" = 1
fi
for entry in /proc/[0-9]*/cwd; do
    pid=${entry#/proc/}
    pid=${pid%/cwd}
    test "$pid" != "$$" || continue
    owned_cwd=$(readlink "$entry" 2>/dev/null || true)
    case "$owned_cwd" in
        "$root"|"$root/"*)
            printf 'ERROR: process %s retains owned cwd %s\n' "$pid" "$owned_cwd" >&2
            exit 1
            ;;
    esac
done
cd /dev/shm
rm -r -- "$root"
test ! -e "$root"
printf 'OWNED_REMOTE_SCRATCH_REMOVED %s\n' "$root"
date -u '+%Y-%m-%dT%H:%M:%SZ'
