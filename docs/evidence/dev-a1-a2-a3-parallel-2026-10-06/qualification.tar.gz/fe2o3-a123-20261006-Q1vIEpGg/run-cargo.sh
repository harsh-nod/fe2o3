#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
export PATH=/home/harmenon/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin
export LD_LIBRARY_PATH=/home/harmenon/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/lib
export CARGO_HOME="$root/cargo-home"
export CARGO_TARGET_DIR="$root/target"
export TMPDIR="$root/tmp"
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TERM_COLOR=never
export RUST_BACKTRACE=1
cd "$root/source"
exec nice -n 10 cargo "$@"
