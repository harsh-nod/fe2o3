#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
cd "$root/source"
sha256sum -c "$root/final-overlay.sha256"
sha256sum "$root/run-cargo.sh" "$root/a1-campaign.sh" "$root/a3-campaign.sh"
toolchain=/home/harmenon/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu
"$toolchain/bin/rustc" -Vv
"$toolchain/bin/cargo" -Vv
sha256sum "$toolchain/bin/rustc" "$toolchain/bin/cargo"
if pgrep -af "$root/(target|cargo-home|tmp|source)"; then
    printf 'ERROR: owned build or test processes remain\n' >&2
    exit 1
else
    status=$?
    test "$status" = 1
fi
for entry in /proc/[0-9]*/cwd; do
    pid=${entry#/proc/}
    pid=${pid%/cwd}
    test "$pid" != "$$" || continue
    owned_cwd=$(readlink "$entry" 2>/dev/null || true)
    case "$owned_cwd" in
        "$root"|"$root/"*)
            printf 'ERROR: process %s retains owned cwd %s\n' "$pid" "$owned_cwd" >&2
            exit 1
            ;;
    esac
done
printf 'NO_OWNED_BUILD_OR_TEST_PROCESSES\n'
du -sh "$root"
date -u '+%Y-%m-%dT%H:%M:%SZ'
