#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
test -d "$root"
test ! -e "$root/source"
mkdir "$root/source" "$root/cargo-home" "$root/target" "$root/tmp" "$root/logs"
tar -xzf "$root/source-base.tar.gz" -C "$root/source"
cp -a /home/harmenon/.cargo/registry /home/harmenon/.cargo/git "$root/cargo-home/"
export PATH=/home/harmenon/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin:/usr/bin:/bin
export CARGO_HOME="$root/cargo-home"
export CARGO_TARGET_DIR="$root/target"
export TMPDIR="$root/tmp"
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_TERM_COLOR=never
cd "$root/source"
rustc -Vv
cargo -Vv
nice -n 10 cargo test --locked --offline -p fe2o3-runtime --lib --features scale-qualification --no-run -j2
