#!/bin/sh
set -eu
root=/dev/shm/fe2o3-a123-cpu-20261006-cmDUs5kT
test "$(id -u)" = 9661
mkdir "$root/logs.a1"
tar -xzf "$root/a1-fixed.tar.gz" -C "$root/source"
cd "$root/source"
sha256sum -c "$root/final-overlay.sha256"
export RUST_TEST_THREADS=4
run() {
    name=$1
    shift
    printf 'BEGIN %s\n' "$name"
    printf '%s\n' "$@" > "$root/logs.a1/$name.arguments"
    date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs.a1/$name.started"
    if sh "$root/run-cargo.sh" "$@" > "$root/logs.a1/$name.log" 2>&1; then
        printf '0\n' > "$root/logs.a1/$name.exit"
        date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs.a1/$name.finished"
        tail -n 5 "$root/logs.a1/$name.log"
        printf 'PASS %s\n' "$name"
    else
        status=$?
        printf '%s\n' "$status" > "$root/logs.a1/$name.exit"
        date -u '+%Y-%m-%dT%H:%M:%SZ' > "$root/logs.a1/$name.finished"
        tail -n 100 "$root/logs.a1/$name.log"
        exit "$status"
    fi
}
run a1-scale test --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 retained_launch_context_scale_1024 -- --test-threads=1
run a1-payload test --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 kfd_backend::compute_launch_payload::tests -- --test-threads=1
run a1-runtime-lib test --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 -- --test-threads=4
run a1-runtime-fixtures test --locked --offline -p fe2o3-runtime --lib --features scale-qualification,cpu-runtime-fixtures -j2 -- --test-threads=4
run a1-runtime-doc test --locked --offline -p fe2o3-runtime --doc --features scale-qualification -j2
run a1-runtime-lib-clippy clippy --locked --offline -p fe2o3-runtime --lib --features scale-qualification -j2 -- -D warnings
run a1-runtime-test-clippy clippy --locked --offline -p fe2o3-runtime --lib --tests --features scale-qualification,cpu-runtime-fixtures -j2 -- -D warnings
sha256sum -c "$root/final-overlay.sha256"
printf 'A1_CPU_CAMPAIGN_COMPLETE\n'
